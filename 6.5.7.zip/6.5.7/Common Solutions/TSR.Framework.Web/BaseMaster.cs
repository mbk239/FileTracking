using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Web
{
    /// <summary>
    /// Class
    /// Name: BaseMaster
    /// Description: This class is a custom MasterPage
    /// who inherits  System.Web.UI.MasterPage,
    /// handles MasterPage related general, properties & functions for TSR Administration
    /// This page will be inherited by all master pages
    /// </summary>
    public class BaseMaster : System.Web.UI.MasterPage
    {
        private ArrayList _Parameters;

        /// <summary>
        /// To pass values between pages or in same page but between page refresh, 
        /// this is used basically for messages [error or success]
        /// </summary>
        public ArrayList Parameters
        {
            get
            {
                if (_Parameters == null)
                    _Parameters = new ArrayList();
                return _Parameters;
            }
        }
    }
}
