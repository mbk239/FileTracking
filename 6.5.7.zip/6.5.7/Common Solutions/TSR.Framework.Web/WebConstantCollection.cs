using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Web
{
    /// <summary>
    /// Class
    /// Name: WebConstantCollection
    /// Description: This class stores all constants of application which using by TSR Webadmin
    /// </summary>
    public partial class WebConstantCollection
    {
        //constants used in asp.net pages        
        public const string USERCONTEXTKEY = "MyUserContext";
        public const string CURRENTSESSIONID = "CurrentSessionID";
        internal const string RESOURCEPOOLKEY = "MyResourcePool";
        public const string MESSAGESESSIONKEY = "MyMessage";
        public const string SECURED_KEY = "Secured";

        public const string CULTUREINFOSESSIONKEY = "MyCultureInfo";
        public const string SESSION_CURRENTLANGUAGENAME = "MyLanguageName";
        //public static string SESSION_CURRENTLANGUAGENAME = System.Web.HttpContext.Current.Session.SessionID + "MyLanguageName";
        //public static string SESSION_LANGUAGERESOURCEFORMENU = System.Web.HttpContext.Current.Session.SessionID + "ListLanguageResourcesForMenu";
        public const string SESSION_LANGUAGERESOURCEFORMENU = "ListLanguageResourcesForMenu";
        public const string APPLICATION_ALLRESOURCES = "ApplicationAllResources";

        public const string LOGGEDINSESSIONKEY = "MyLoggedIn";
        public const string ISNEUTRALCULTURESESSIONKEY = "IsNeutral";
        public const string ISSPECIFICCULTURESESSIONKEY = "IsSpecific";
        public const string ERRORSESSIONKEY = "MyError";
        public const string SEARCHLISTSESSIONKEY = "MySearchList";
        public const string SEARCHCOMPONENTSESSIONKEY = "MySearchComponent";

        public const string CHECKLISTPERMISSION = "0";
        public const string KEYROLEPERMION = "";
        public const string LBLNAM = "lblName";
        public const string LNKHELP = "lnkHelp";
        public const string MASTERPAGE_LNKCHANGEPASS = "hlkChangePassword";
        public const string MASTERPAGE_LNKLOGOUT = "hlkLogout";
        public const string MASTERPAGE_LNKABOUT = "lnkCheckVersion";
        
        public const string DEFAULTAPPROVERKEY = "MyDefaultApprover";
        public const string ADDOBJECTSESSIONKEY = "MyAddObject";
        public const string ADDCOMPONENTSESSIONKEY = "MyAddComponent";
        public const string SETTINGVALUESESSIONKEY = "MySettingValue";
        public const string SETTINGKEYSESSIONKEY = "MySettingKey";
        public const string ROPORSELECTVALUES = "0";

        ///constants used for replacement of Hard Code Value
        ///
        public const string PREVIOUSPAGEURLKEY = "RefUrl";
        public const string SETTINGSKEY_QUERYSTRING = "SettingsKey";
        public const string SELECTED_TAB_STYLENAME = "SelectedTab";
        public const string NAVIGATION_PAGE_CONTROL_NAME = "tdPageNavigation";

        

        public const string NAVIGATION_TBDROPLIST = "ddlLanguage";
        public const string NAVIGATION_LBMENU = "tdlnkHelp";
        public const string MASTER_PAGE_HEADER_CONTROL_NAME = "cntPHHeader";
        public const string MASTER_MENU_BREADCRUMB_NAME = "ucBreadCRumbControl";
        public const string CHECKPRMISSION = "0";
        public const string JAVASCRIPT_PARAM_FOR_CLOSE = "Close";
        
        public const string QUERYSTRING_USERID = "UserID";
        public const string QUERYSTRING_USERGROUPID = "UserGroupID";
        public const string MESSEGA_INFOR = "UserID";
        public const string QUERYSTRING_ORGID = "OrgID";
        public const string QUERYSTRING_PROJID = "ProjId";
        public const string QUERYSTRING_ACTID = "ActID";
        public const string QUERYSTRING_STATUSID = "StatusID";
        public const string QUERYSTRING_START = "Start";
        public const string QUERYSTRING_END = "End";
        public const string QUERYSTRING_SEARCHTERM = "SearchTerm";
        public const string QUERYSTRING_URLKEEPSEARCHVALUES = "URLKeepSearchValues";

        public const string QUERYSTRING_SEARCHVALUE = "SearchValue";
        public const string QUERYSTRING_OLDERPARAMATERS = "OlderParamaters";

        public const string QUERYSTRING_TIMEENTRYID = "TimeEntryID";
        public const string QUERYSTRING_EXPENSESHEETID = "ExpenseSheetID";
        public const string QUERYSTRING_EXPVALUE = "ExpenseValue";
        public const string QS_LOGINACTIVE = "LoginActive";
        public const string QS_LOGINACTIVE_LOGOUT = "0";
        public const string QS_LOGINACTIVE_SAVEMAILSERVER = "1";
        public const string QUERYSTRING_EMPLOYEE = "Employee";

        //Add 20160222
        public const string QUERYSTRING_SHOWONLYLOCKED = "ShowOnlyLocked";
        public const string QUERYSTRING_SHOWZEROHOURS = "ShowZeroHours";

        //feature 99 - Inactive Usergroup
        public const string STATUSOFUSER_ACTIVE = "Active";
        public const string STATUSOFUSER_INACTIVE = "Inactive";
        public const string COMMANDNAME_REMOVE = "Remove";
        
        public const string MENUTSRWEBADMIN = "menuTSRWebAdmin";

        public const string VISIBLE = "visible";        

	//added by tsrdev2 - 26 Sep 2012
        public const string STATUS_ACTIVE = "Active";
        public const string STATUS_INACTIVE = "Inactive"; 
	
        //version 5.4
        public const string COOKIE_GRIDCONTROL_PAGESIZE = "gridcontrolpagesize";

        #region Messages
        //contsant messages. it does not mean these are fixed for all languages. these are stored here
        //only because some messages are used repeatedly in many pages. to keep consistency, these 
        //messages are stored as constants
        public const string REQUIRED_MESSAGE_SUMMARY_KEY = "REQUIRED_MESSAGE_SUMMARY_KEY";
        public const string REQUIRED_MESSAGE_SUMMARY_VALUE = "Data Modified please Update/Cancel before continuing.";
        public const string ADUSER_MISSING_KEY = "ADUSER_MISSING_KEY";
        public const string ADUSER_MISSING_VALUE = "User does not exist in the current domain.";

        public const string REQUIRED_MESSAGE_DETAIL_KEY = "REQUIRED_MESSAGE_DETAIL_KEY";
        public const string REQUIRED_MESSAGE_DETAIL_VALUE = "Please check required information or complete unsaved operation.";

        public const string REQUIRED_MESSAGE_DETAIL_VALUE_FOR_PROJECT = "Please check required information. Start Date should be greater than End Date.";

        public const string DUPLICATE_OBJECT_MESSAGE_KEY = "DUPLICATE_MESSAGE_KEY";
        public const string DUPLICATE_OBJECT_MESSAGE_VALUE = "Object with same name already exists.";
        
        #endregion
        public const string AdressType = "Standard";
        #region Validate
        public const String VALIDATE_EMAIL = @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,8}$";
        //@"^([_-0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([-_0-9a-zA-Z][-\w]*[0-9a-zA-Z_-]\.)+[a-zA-Z]{2,9})$";//"^\\w+[\\w-\\.]*\\@([\\w]+\\.)+[\\w]+$";
        //public const String VALIDATE_EMAIL = @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
        //                                     + @"([\w-]+\.)+[\w-]+$";
        public const String VALIDATE_PHONE = "^([\\+0-9\\(][+]{0,1}[0-9\\s]*[0-9\\)][0-9\\s\\-]*)";
        public const String VALIDATE_WEBSITE = "^(((h|H?)(t|T?)(t|T?)(p|P?)(s|S?))\\://)?(w{3}\\.)?[a-zA-Z0-9\\-]+\\.([a-zA-Z]+\\.)*[a-zA-Z/]+$";
        #endregion

        //"Only Personal Reporting" permission name
        public const string ONLYPERSONALREPORTING_PERMISSION = "ONLY_PERSONAL_REPORTING";
    }

}
