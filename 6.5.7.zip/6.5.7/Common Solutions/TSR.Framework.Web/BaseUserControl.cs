using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Web;
using TSR.Framework.Web.Security;

namespace TSR.Framework.Web
{
    /// <summary>
    /// Class
    /// Name: BasePage
    /// Description: This class is a custom UserControl
    /// who inherits  System.Web.UI.UserControl,
    /// handles UserControl related general, properties & functions for TSR Administration
    /// This class will be inherited by all user control of TSR Webadmin
    /// </summary>
    public class BaseUserControl : System.Web.UI.UserControl
    {
        /// <summary>
        /// method OnLoad
        /// defines what to do in case of a loading of a User control
        /// </summary>
        /// <param name="e">event args</param>
        protected override void OnLoad(EventArgs e)
        {
            //if (!IsPostBack) // if not a post back
            //{
            //    SetLocalText(); // set localized text to labels and buttons
            //}
            base.OnLoad(e); // call the base class's event handler
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (!IsPostBack) // if not a post back
            {
                SetLocalText(); // set localized text to labels and buttons
            }
        }

        /// <summary>
        /// method SetLocalText
        /// sets localized text to labels and buttons on a page
        /// </summary>
        public virtual void SetLocalText()
        {
        }

        /// <summary>
        /// gets the current UserContext
        /// </summary>
        public UserContext UserContext
        {
            get
            {
                BaseSecuredPage parentPage = Page as BaseSecuredPage;

                if (parentPage != null)
                    return parentPage.UserContext;

                return null;
            }
        }

        /// <summary>
        /// gets the Decrypted Query String
        /// </summary>
        public System.Collections.Specialized.NameValueCollection DecryptedQueryString
        {
            get
            {
                BaseSecuredPage parentPage = Page as BaseSecuredPage;

                if (parentPage != null)
                    return parentPage.DecryptedQueryString;
                else
                    return new System.Collections.Specialized.NameValueCollection();
            }
        }

        public void RedirectKeepSearchValue(string newURL, NameValueCollection parameters, string SearchValues)
        {
            BaseSecuredPage parentPage = Page as BaseSecuredPage;
            NameValueCollection backParams = new NameValueCollection();

            foreach (var temp in DecryptedQueryString.AllKeys)
            {
                backParams.Add(temp, DecryptedQueryString[temp]);
            }
            if (string.IsNullOrEmpty(backParams.Get(WebConstantCollection.QUERYSTRING_SEARCHVALUE)))
            {
                backParams.Add(WebConstantCollection.QUERYSTRING_SEARCHVALUE, SearchValues);
            }
            else
            {
                backParams[WebConstantCollection.QUERYSTRING_SEARCHVALUE] = SearchValues;
            }
            string backURL = SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url + UIHelper.BuildQueryString(backParams));

            if (string.IsNullOrEmpty(parameters.Get(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES)))
            {
                parameters.Add(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES, backURL);
            }
            else
            {
                parameters[WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES] = backURL;
            }            

            Response.Redirect(SecurityManager.BuildEncryptedUri(newURL + UIHelper.BuildQueryString(parameters)));
        }

        public string BuildNewURLKeepSearchValue(string newURL, NameValueCollection parameters, string SearchValues)
        {
            string result = string.Empty;
            BaseSecuredPage parentPage = Page as BaseSecuredPage;
            NameValueCollection backParams = new NameValueCollection();

            foreach (var temp in DecryptedQueryString.AllKeys)
            {
                backParams.Add(temp, DecryptedQueryString[temp]);
            }
            if (string.IsNullOrEmpty(backParams.Get(WebConstantCollection.QUERYSTRING_SEARCHVALUE)))
            {
                backParams.Add(WebConstantCollection.QUERYSTRING_SEARCHVALUE, SearchValues);
            }
            else
            {
                backParams[WebConstantCollection.QUERYSTRING_SEARCHVALUE] = SearchValues;
            }
            string backURL = SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url + UIHelper.BuildQueryString(backParams));

            if (string.IsNullOrEmpty(parameters.Get(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES)))
            {
                parameters.Add(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES, backURL);
            }
            else
            {
                parameters[WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES] = backURL;
            }   

            result = SecurityManager.BuildEncryptedUri(newURL +  UIHelper.BuildQueryString(parameters));
            return result;
        }
    }
}
