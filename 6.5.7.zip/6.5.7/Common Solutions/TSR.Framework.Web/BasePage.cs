using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Diagnostics;
using System.Collections.Specialized;

using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework;
using System.Globalization;
using System.Threading;
using System.Data.SqlClient;
using System.Data;
using TSR.Framework.Security;
using TSR.Framework.Web.Security;

namespace TSR.Framework.Web
{
    /// <summary>
    /// Class
    /// Name: BasePage
    /// Description: This class is a custom Page
    /// who inherits  System.Web.UI.Page,
    /// handles Page related general 
    /// properties & functions for TSR Administration
    /// This page will be inherited by all page of TSR WebAdmin
    /// </summary>
    public class BasePage : System.Web.UI.Page
    {
        //public UserContext UserContext
        //{
        //    get { return new UserContext(-1, String.Empty, String.Empty); }
        //}

        /// <summary>
        /// gets or sets the Url of the previous page
        /// </summary>
        protected string PreviousPageUrl
        {
            get
            {
                if (ViewState[WebConstantCollection.PREVIOUSPAGEURLKEY] == null)
                {
                    return UIHelper.SECURED_HOME;
                }
                return (string)ViewState[WebConstantCollection.PREVIOUSPAGEURLKEY];
            }
            set
            {
                ViewState[WebConstantCollection.PREVIOUSPAGEURLKEY] = value;
            }
        }

        /// <summary>
        /// gets the Master page 
        /// </summary>
        public BaseMaster CustomMaster
        {
            get
            {
                if (Page.Master != null)
                    return Page.Master as BaseMaster;

                return null;
            }
        }

        /// <summary>
        /// method OnLoadComplete
        /// this method is invoked when the Load event is completed
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoadComplete(EventArgs e)
        {

            base.OnLoadComplete(e);
            Page.MaintainScrollPositionOnPostBack = true;
            if (!IsPostBack)
            {
                SetLocalText();

            }
            
        }

        protected void Page_PreInit(object sender, EventArgs e)
        {
            //if (Session[HttpContext.Current.Session.SessionID.ToString() + TSR.Framework.Web.WebConstantCollection.SESSION_CURRENTLANGUAGENAME] != null)
            //{
            //    string currLangName = Session[HttpContext.Current.Session.SessionID.ToString() + TSR.Framework.Web.WebConstantCollection.SESSION_CURRENTLANGUAGENAME].ToString();
            //    if (currLangName.Equals("Dansk/Danish"))
            //    {
            //        Page.Theme = "RTLTheme";
            //    }
            //    else
            //    {
            //        Page.Theme = "Default";
            //    }
            //}
        }


        /// <summary>
        /// Pages without back/cancel does not require previous page url, and for them
        /// no need to waste viewstate, whoever needs this, will save it on page load
        /// </summary>
        public void SavePreviousPageUrl()
        {
            if (SiteMap.RootNode != null && !String.IsNullOrEmpty(SiteMap.RootNode.Url))
            {
                PreviousPageUrl = SiteMap.RootNode.Url;
            }

            if (SiteMap.CurrentNode != null && SiteMap.CurrentNode.ParentNode != null)
            {
                if (!String.IsNullOrEmpty(SiteMap.CurrentNode.ParentNode.Url))
                    PreviousPageUrl = SiteMap.CurrentNode.ParentNode.Url;
            }
        }

        /// <summary>
        /// method SetLocalText
        /// this method is invoked to set page specific culture specific labels ans texts
        /// </summary>
        public virtual void SetLocalText()
        {
        }

        #region Page redirection methods

        /// <summary>
        /// method RedirectCurrentPage
        /// redirects the current page to it's self with the given parameters
        /// </summary>
        /// <param name="parameters"></param>
        public void RedirectCurrentPage(NameValueCollection parameters)
        {
            if (SiteMap.CurrentNode != null && !String.IsNullOrEmpty(SiteMap.CurrentNode.Url))
            {
                Response.Redirect(Framework.Web.Security.SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url + UIHelper.BuildQueryString(parameters)));
            }
        }

        /// <summary>
        /// method RedirectCurrentPage
        /// redirects the current page to it's self with the given parameters
        /// </summary>
        /// <param name="parameters"></param>
        public void RedirectCurrentPage(string parameterName, string parameterValue)
        {
            if (SiteMap.CurrentNode != null && !String.IsNullOrEmpty(SiteMap.CurrentNode.Url))
            {
                parameterValue = (string)Security.SecurityManager.EncryptHTMLQueryString(parameterValue);
                Response.Redirect(Framework.Web.Security.SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url + "?" + parameterName + "=" + parameterValue));
            }
        }

        /// <summary>
        /// method RedirectCurrentPage
        /// redirects the current page to it's self
        /// </summary>
        /// <param name="parameters"></param>
        public void RedirectCurrentPage()
        {
            if (SiteMap.CurrentNode != null && !String.IsNullOrEmpty(SiteMap.CurrentNode.Url))
            {
                Response.Redirect(Framework.Web.Security.SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url));
            }
        }

        #endregion



        //public string BuildQueryString(NameValueCollection values)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    for (int i = 0; i < values.Count; ++i)
        //    {
        //        sb.Append(i == 0 ? "?" : "&");
        //        sb.Append(values.Keys[i]);
        //        sb.Append("=");
        //        sb.Append(values[i]);
        //    }
        //    return sb.ToString();
        //}


        /// <summary>
        /// All errors that are not handled in a page, at first dealt in this event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        void Page_Error(Object sender, EventArgs args)
        {

            HttpContext ctx = HttpContext.Current;
            Exception exception = ctx.Server.GetLastError();

            // Building Error Information string
            string errorInfo = null;
            errorInfo = "\n" + ConstantCollection.REQUEST_URL_KEY_TO_LOG_EXCEPTION + ctx.Request.Url.ToString() +
                   "\n" + ConstantCollection.EXCEPTION_SOURCE_KEY_TO_LOG_EXCEPTION + exception.Source +
                   "\n" + ConstantCollection.EXCEPTION_MESSAGE_KEY_TO_LOG_EXCEPTION + exception.Message +
                   "\n" + ConstantCollection.EXCEPTION_STACKTRACE_KEY_TO_LOG_EXCEPTION + exception.StackTrace;
            TSR.Framework.Logging.Log logObject = new TSR.Framework.Logging.Log()
            {
                StackTrace = exception.StackTrace,
                LoggingTime = DateTime.Now,
                CreatedTimeStamp = DateTime.Now,
                SessionID = string.Empty,
                Priority = 1,
                MessageSummary = !string.IsNullOrEmpty(exception.Message) ? 
                        exception.Message : (exception.InnerException != null ? exception.InnerException.Message : ""), 
                MessageDetail = exception.ToString()
            };

            //Some erros are handled here, where as some are thrown again to deal globally [in global.asax file]
            TSR.Framework.Logging.LoggingHandler.LogError(logObject);

            if (exception is UniqueConstraintException)
            {
                //errorInfo = ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE;// "Object with same name already exists.";
                errorInfo = ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
            }
            else if (exception is SecurityException)
            {
                throw exception;
                //errorInfo = ConstantCollection.AUTHORIZATION_EXCEPTION_MESSAGE;
            }
            else if (exception is LicenseException)
            {
                throw exception;
                //errorInfo = ConstantCollection.LICENSE_EXCEPTION_MESSAGE;
            }
            else if (exception is ObjectInsertException || exception is ObjectUpdateException)
            {
                //errorInfo = ConstantCollection.DATABASE_INSERTION_EXCEPTION_MESSAGE;
                errorInfo = ResourceManager.GetResourceString("ErrorInsertionIntoDatabase","There is a problem while performing insertion into database.");
            }
            else if (exception is DatabaseConnectionException)
            {
                throw exception;
                //errorInfo = ConstantCollection.DATABASE_CONNECTION_EXCEPTION_MESSAGE;
            }
            else if (exception is HttpRequestValidationException)
            {
                //throw exception;                
                string messageHttpRequestValidationException = string.Empty;
                MessageContainer messageContainer = null;

                messageHttpRequestValidationException = ResourceManager.GetResourceString("HttpRequestValidationException", "The user can not input HTML characters.");

                messageContainer = new MessageContainer(MessageTypeEnum.Failure, messageHttpRequestValidationException, null);

                ctx.Cache[Framework.Web.WebConstantCollection.ERRORSESSIONKEY] = messageContainer;

                Response.Redirect(Request.RawUrl);
            }
            //added by tsrdev2
            else if (exception is HttpUnhandledException)
            {
                string message1 = TSR.Framework.Resource.ResourceManager.GetResourceString("HttpUnhandledException", "Exception of type HttpUnhandledException was thrown");
                MessageContainer messageContainer = new TSR.Framework.MessageContainer(TSR.Framework.MessageTypeEnum.Failure, message1, null);
                ctx.Cache[Framework.Web.WebConstantCollection.ERRORSESSIONKEY] = messageContainer;

                Response.Redirect(Request.RawUrl);
            }            
            else
            {                
                throw exception;                
            }
            ctx.ClearError();
            string message = string.Empty;
            MessageContainer msgContainer = null;
            
            msgContainer = new MessageContainer (MessageTypeEnum.GlobalError, errorInfo, null);

            ctx.Cache[Framework.Web.WebConstantCollection.ERRORSESSIONKEY] = msgContainer;

            Response.Redirect(Request.RawUrl);
            //Session[Framework.Web.ConstantCollection.LOGGEDINSESSIONKEY] = null;
            //OnError(args);
        }

        protected override void InitializeCulture()
        {            
            //if (Session[TSR.Framework.Web.WebConstantCollection.CULTUREINFOSESSIONKEY] != null && !String.IsNullOrEmpty(Session[TSR.Framework.Web.WebConstantCollection.CULTUREINFOSESSIONKEY].ToString()))
            //{
            //    if (!Session[TSR.Framework.Web.WebConstantCollection.CULTUREINFOSESSIONKEY].ToString().Equals(System.Threading.Thread.CurrentThread.CurrentUICulture.Name))
            //    {
            //        System.Globalization.CultureInfo currCultureInfo = new System.Globalization.CultureInfo(Session[TSR.Framework.Web.WebConstantCollection.CULTUREINFOSESSIONKEY].ToString());
            //        //currCultureInfo.DateTimeFormat.Calendar = new System.Globalization.GregorianCalendar();
            //        System.Threading.Thread.CurrentThread.CurrentUICulture = currCultureInfo;
            //        System.Threading.Thread.CurrentThread.CurrentCulture = currCultureInfo;
            //        System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.Calendar = new System.Globalization.GregorianCalendar();
            //        if (currCultureInfo.DateTimeFormat.ShortDatePattern == "dd/MM yyyy")
            //        {
            //            System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";                        
            //        }
            //        if (currCultureInfo.DateTimeFormat.DateSeparator.Equals(". "))  //in case language is Slovakia
            //        {
            //            System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.DateSeparator = ".";
            //            System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd.MM.yyyy";
            //        }
            //    }                
            //}
            if (System.Threading.Thread.CurrentThread.CurrentCulture != null)
            {
                //System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.Calendar = new System.Globalization.GregorianCalendar();
                //System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.Calendar = new System.Globalization.GregorianCalendar();
                //if (System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern == "dd/MM yyyy")
                //{
                //    System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                //    System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
                //}
                //if (System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.DateSeparator.Equals(". "))  //in case language is Slovakia
                //{
                //    System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.DateSeparator = ".";
                //    System.Threading.Thread.CurrentThread.CurrentCulture.DateTimeFormat.ShortDatePattern = "dd.MM.yyyy";
                //    System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.DateSeparator = ".";
                //    System.Threading.Thread.CurrentThread.CurrentUICulture.DateTimeFormat.ShortDatePattern = "dd.MM.yyyy";
                //}

                if (Session[WebConstantCollection.USERCONTEXTKEY] != null)
                {
                    UserContext userContext = Session[WebConstantCollection.USERCONTEXTKEY] as UserContext;
                    if (userContext != null)
                    {
                        string dateFormat = GetUserDefaultSettingOfUserBySettingName(userContext.UserID, "TSRDateFormat");
                        dateFormat = dateFormat.Replace("mm", "MM");
                        string timeFormat = GetUserDefaultSettingOfUserBySettingName(userContext.UserID, "TSRTimeFormat");

                        CultureInfo culture = (CultureInfo)CultureInfo.CurrentCulture.Clone();
                        //CultureInfo uiCulture = (CultureInfo)CultureInfo.CurrentUICulture.Clone();

                        if ((!string.IsNullOrEmpty(dateFormat) && !dateFormat.Equals("NA"))
                            || (!string.IsNullOrEmpty(timeFormat) && !timeFormat.Equals("NA")))
                        {                            
                            CultureInfo enUsCulture = CultureInfo.GetCultureInfo("en-US");
                            culture.DateTimeFormat = (DateTimeFormatInfo)enUsCulture.DateTimeFormat.Clone();

                            if (!string.IsNullOrEmpty(dateFormat) && !dateFormat.Equals("NA"))
                            {
                                culture.DateTimeFormat.ShortDatePattern = dateFormat;
                                string dateSeparator = getDateSeparator(dateFormat);
                                if (dateFormat.Length > 0)
                                    culture.DateTimeFormat.DateSeparator = dateSeparator;
                                //culture.DateTimeFormat.LongDatePattern = dateFormat;
                                //uiCulture.DateTimeFormat.ShortDatePattern = dateFormat;
                            }
                            if (!string.IsNullOrEmpty(timeFormat) && !timeFormat.Equals("NA"))
                            {
                                if (timeFormat.Contains("hh")) timeFormat = timeFormat.Replace("hh", "h");

                                culture.DateTimeFormat.ShortTimePattern = timeFormat.Replace(":ss", "");
                                culture.DateTimeFormat.LongTimePattern = timeFormat;
                            }                            
                        }
                        culture.DateTimeFormat.AMDesignator = "AM";
                        culture.DateTimeFormat.PMDesignator = "PM";
                        Thread.CurrentThread.CurrentCulture = culture;
                    }
                }                
            }
            //call base class
            base.InitializeCulture();
        }

        private string getDateSeparator(string dateFormat)
        {
            string str = dateFormat.ToLower();
            str = str.Trim(new char[] { 'm', 'd', 'y'});
            if (str.Length > 0)
                return str[0].ToString();
            else return string.Empty;
        }

        private string GetUserDefaultSettingOfUserBySettingName(long userID, string settingName)
        {
            string values = string.Empty;
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = "GetUserDefaultSettingByUserID_SettingName";
            command.CommandType = CommandType.StoredProcedure;
            ///set parameters                        
            SqlParameter parameter = new SqlParameter("@SettingsName", SqlDbType.NText, 255);
            parameter.Value = settingName;
            command.Parameters.Add(parameter);

            parameter = new SqlParameter("@UserID", SqlDbType.BigInt);
            parameter.Value = userID;
            command.Parameters.Add(parameter);

            try
            {
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    if (reader.Read())
                    {
                        values = reader.GetString(3);
                    }

                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return TSR.Framework.BaseBusinessEntity.ReverseToHTMLCode(values);
        }

        protected bool IsLicenseFoundationExpiry()
        {
            ApplicationLicense license = LicenseManager.GetLicense();
            if (license != null && license.FoundationExpiry < DateTime.Today)
                return true;

            return false;
        }
    }
}
