﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework.Security;
using System.ServiceModel;

namespace TSR.Framework.Web.Security
{   
    /// <summary>
    /// interface IBaseSecuredServiceLibrary
    /// provides the basis of secured service library
    /// </summary>
    public interface IBaseSecuredServiceLibrary
    {   
        bool IsInstantiateAllowed();
        bool IsInvokeAllowed(int methodID);
    }
}
