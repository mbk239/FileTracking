﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Web;
using TSR.Framework.Security;
using TSR.Framework;


namespace TSR.Framework.Web.Security
{   
    /// <summary>
    /// class BaseSecuredServiceLibrary
    /// extends IBaseSecuredServiceLibrary
    /// This class contains properties and methods for handles security on WCF service.
    /// This class will be inherited by classes in TSR.AdvancedService
    /// </summary>
   public class BaseSecuredServiceLibrary : IBaseSecuredServiceLibrary
    {
        //private string _ApplicationKey;  

        /// <summary>
        /// gets the User contexc
        /// </summary>
        public UserContext UserContext
        {
            get
            {
                if (HttpContext.Current.Session[WebConstantCollection.USERCONTEXTKEY] == null)
                    //Session[ConstantCollection.USERCONTEXTKEY] = new UserContext(-1, String.Empty, String.Empty);
                    return null;

                return HttpContext.Current.Session[WebConstantCollection.USERCONTEXTKEY] as UserContext;
            }
        }
    
        public SecurityEnabledAttribute SecurityEnabledAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                    return att as SecurityEnabledAttribute;

                return null;
            }
        }

        /// <summary>
        /// gets the permission key
        /// </summary>
        public virtual string PermissionKey
        {
            get
            {
                return this.GetType().Name.ToUpper();
            }
        }

        /// <summary>
        /// whether security is enabled or not 
        /// </summary>
        public bool SecurityEnabled
        {
            get { return false; }
        }
        
       /// <summary>
        /// whether some action is allowed or not
        /// </summary>      
        public bool IsAllowed
        {
            get { return true; }
        }

        //public string ApplicationKey
        //{
        //    get
        //    {
        //        return _ApplicationKey;
        //    }
        //}

        /// <summary>
        /// whether instantiating some class is allowed
        /// </summary>
        /// <returns></returns>
        public bool IsInstantiateAllowed()
        {
            return true;
        }

        /// <summary>
        /// returns whether invoking method with methodID is allowed
        /// </summary>
        /// <param name="methodID"></param>
        /// <returns></returns>
        public bool IsInvokeAllowed(int methodID)
        {
            return true;
        }     
       
    }
}
