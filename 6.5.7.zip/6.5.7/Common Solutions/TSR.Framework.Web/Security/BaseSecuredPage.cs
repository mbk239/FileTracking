using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Reflection;

using TSR.Framework.Resource;
using TSR.Framework.Exceptions;
using TSR.Framework.Security;
using TSR.Framework.Web;
using TSR.Framework;
using System.Globalization;
using System.Collections.Specialized;

namespace TSR.Framework.Web.Security
{
    /// <summary>
    /// Class
    /// Name: BaseSecuredPage
    /// Description: This class is a custom BasePage
    /// who inherits Framework.Web.BaseUserControl,
    /// imeplements ISecurity and handles Page security 
    /// related properties & functions for TSR Administration
    /// This class will be inherited by pages which need security of WebAdmin
    /// </summary>
    public class BaseSecuredPage : BasePage, ISecurity
    {
        private System.Collections.Specialized.NameValueCollection _DecryptedQueryString;
        #region Constants
        private const string TYPELIST_PERMISSION = "secured_setupdata_typelist_aspx";
        private const string TYPETEMPLATE_PERMISSION = "secured_setupdata_typetemplate_aspx";
        private const string TYPELIST = "typelist";
        private const string TYPETEMPLATE = "typetemplate";

        private const string USERDETAILTYPELIST_PERMISSION = "secured_security_userdetailtypelist_aspx";
        private const string USERDETAILTYPE_PERMISSION = "secured_security_userdetailtype_aspx";

        #endregion
        //System.Web.UI.WebControls.HiddenField hiddenField = new System.Web.UI.WebControls.HiddenField();

        /// <summary>
        /// gets or sets the UserContext
        /// </summary>
        public UserContext UserContext
        {
            get
            {
                if (Session[WebConstantCollection.USERCONTEXTKEY] == null)
                    //Session[ConstantCollection.USERCONTEXTKEY] = new UserContext(-1, String.Empty, String.Empty);
                    return null;

                return Session[WebConstantCollection.USERCONTEXTKEY] as UserContext;
            }
            set { Session[WebConstantCollection.USERCONTEXTKEY] = value; }
        }

        /// <summary>
        /// checks if some attribute is under security control
        /// </summary>
        public SecurityEnabledAttribute SecurityEnabledAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                    return att as SecurityEnabledAttribute;

                return null;
            }
        }

        /// <summary>
        /// gets the permission key
        /// </summary>
        public virtual string PermissionKey
        {
            get
            {
                string permission = string.Empty;
                if (this.GetType().Name.ToLower().Contains(TYPELIST) || this.GetType().Name.ToLower().Contains(USERDETAILTYPELIST_PERMISSION))
                {
                    permission = TYPELIST_PERMISSION;
                }
                else if (this.GetType().Name.ToLower().Contains(TYPETEMPLATE) || this.GetType().Name.ToLower().Contains(USERDETAILTYPE_PERMISSION))
                {
                    permission = TYPETEMPLATE_PERMISSION;
                }
                else
                    permission = this.GetType().Name;
                //edited by tsrdev2
                //convert permission key to CultureInfo("en-US")
                return permission.ToUpper(new CultureInfo("en-US"));
            }
        }

        public bool IsAllowed
        {
            get { return true; }
        }

        /// <summary>
        /// chechks if Security is Enabled
        /// </summary>
        public virtual bool SecurityEnabled
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                {
                    SecurityEnabledAttribute secAtt = att as SecurityEnabledAttribute;
                    if (secAtt != null)
                    {
                        return secAtt.SecurityEnabled;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// gets the Decrypted Query String
        /// </summary>
        public System.Collections.Specialized.NameValueCollection DecryptedQueryString
        {
            get
            {
                if (_DecryptedQueryString == null)
                    _DecryptedQueryString = new System.Collections.Specialized.NameValueCollection();
                return _DecryptedQueryString;
            }
        }

        /// <summary>
        /// class specific implementation of OnPreInit
        /// it is called to handle the preInit event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreInit(EventArgs e)
        {
            if (!String.IsNullOrEmpty(Request.Url.Query))
            {
                string query = Request.Url.Query.Substring(1);
                                
                if (!String.IsNullOrEmpty(query))
                {
                    query = System.Web.HttpUtility.UrlDecode(query);
                    SecurityManager.DecryptQueryString(query, DecryptedQueryString);
                }
            }

            if (SecurityManager.GetCurrentUserContext() == null)
            {
                Response.Redirect(UIHelper.LOGIN_PAGE);
            }

            base.OnPreInit(e);
        }

        /// <summary>
        /// class specific implementation of OnInitComplete
        /// it is called when the initialization is complete
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInitComplete(EventArgs e)
        {
            base.OnInitComplete(e);

            if (SecurityEnabled)
            {
                if (UserContext != null)
                {
                    //TODO: Comment code for test - Need removing after finish
                    //if (!UserContext.HasPermission(PermissionKey))
                    //    throw new SecurityException();
                }
                //else
                //{
                //    Response.Redirect(UIHelper.LOGIN_PAGE);
                //    //throw new Exception("User Object is null");
                //}
            }
        }

        /// <summary>
        /// class specific implementation of OnLoad
        /// handles the load event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnLoad(EventArgs e)
        {
            Trace.Write("Begin OnLoad [BaseSecuredPage]");
            base.OnLoad(e);
            SetTitle();
            if ((Request.UserAgent.IndexOf("AppleWebKit") > 0) || (Request.UserAgent.ToString().Equals(string.Empty)))
            {
                Request.Browser.Adapters.Clear();
            }
            //if (Form.FindControl("hiddenField") != null)
            //{
            //    hiddenField = Form.FindControl("hiddenField") as System.Web.UI.WebControls.HiddenField;
            //    bool value;
            //    if(bool.TryParse(hiddenField.Value,
            //}
            //else
            //{
            //    CreateHiddenField();
            //}
            Trace.Write("End OnLoad [BaseSecuredPage]");
        }

        //private void CreateHiddenField()
        //{
        //    hiddenField.ID = "hiddenField";
        //    hiddenField.Value = "NULL";
        //    Form.Controls.Add(hiddenField);
        //}

        /// <summary>
        /// wrapper method for SecurityManager.BuildEncryptedUri
        /// returns an encrypted string for the provided url
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string EncryptURL(string url)
        {
            Session[TSR.Framework.Web.WebConstantCollection.KEYROLEPERMION] = SearchComponentEnum.Permission;
            return SecurityManager.BuildEncryptedUri(url);
        }      

        /// <summary>
        /// wrapper method for ResourceManager.GetResourceString
        /// gets a string in the current culture for the given key
        /// </summary>
        /// <param name="key"></param>
        /// <param name="defaultText"></param>
        /// <returns></returns>
        public string GetResourceString(string key, string defaultText)
        {
            return ResourceManager.GetResourceString(key, defaultText);
        }

        public string GetResourceString(string key, string defaultText, bool forJSAlert)
        {
            string str = ResourceManager.GetResourceString(key, defaultText);
            if (forJSAlert)
            {
                str = str.Replace("'", "\\'");
            }
            return str;
        }

        /// <summary>
        /// Sets the title of a page
        /// </summary>
        private void SetTitle()
        {
            string title = ResourceManager.GetResourceString("WelcomeTSRAdmin", "Welcome to TSR Administration"); //default title
            try
            {
                if (SiteMap.CurrentNode != null) // if the node is in the site map
                {
                    SiteMapNode current = SiteMap.CurrentNode;
                    title = current.Title;
                    current = current.ParentNode;
                    while (current != null)//show the full path to the current page in the title 
                    {
                        //added by tsrdev2
                        //string parentTitle = ResourceManager.GetResourceString(current.ResourceKey, current.Title);

                        title = string.Concat(current.Title, " > ", title);
                        current = current.ParentNode;
                    }
                }
            }
            catch(Exception ex)            
            {
                TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                Title = title;
            }
        }


        public void RedirectKeepSearchValue(string newURL, NameValueCollection parameters, string SearchValues)
        {
            NameValueCollection backParams = new NameValueCollection();

            foreach (var temp in DecryptedQueryString.AllKeys)
            {
                backParams.Add(temp, DecryptedQueryString[temp]);
            }
            if (string.IsNullOrEmpty(backParams.Get(WebConstantCollection.QUERYSTRING_SEARCHVALUE)))
            {
                backParams.Add(WebConstantCollection.QUERYSTRING_SEARCHVALUE, SearchValues);
            }
            else
            {
                backParams[WebConstantCollection.QUERYSTRING_SEARCHVALUE] = SearchValues;
            }
            string backURL = SecurityManager.BuildEncryptedUri(SiteMap.CurrentNode.Url + UIHelper.BuildQueryString(backParams));

            if (string.IsNullOrEmpty(parameters.Get(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES)))
            {
                parameters.Add(WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES, backURL);
            }
            else
            {
                parameters[WebConstantCollection.QUERYSTRING_URLKEEPSEARCHVALUES] = backURL;
            }

            Response.Redirect(SecurityManager.BuildEncryptedUri(newURL + UIHelper.BuildQueryString(parameters)));
        }

        //public void SetJSMessageBox(string _message, string _retrunValue)
        //{

        //    string script = "function ShowConfirmation(){ if(confirm('" + _message + "')==true) return true; else return false;}";
        //    script = "javascript:ShowConfirmMessage('" + _message + "','" + _retrunValue + "');";
        //    script = "javascript:ShowConfirmMessage('" + _message + "');";
        //    ClientScript.RegisterStartupScript(this.GetType(), "MyJSMessageBox", script, true);

        //    //if (IsPostBack && Request["__EVENTTARGET"] != null)
        //    //{



        //    //}
        //}
    }
}
