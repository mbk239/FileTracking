using System;
using System.Collections.Generic;
using System.Text;
using TSR.Framework;

namespace TSR.Framework.Web.Security
{
    /// <summary>
    /// Class
    /// Name: SecurityManager
    /// Description: This class is a custom security
    /// handles Page security related general properties & functions for TSR Administration
    /// </summary>
    public class SecurityManager
    {
        public const string STRQUERYSTRINGHTML = "~@~%#~%#~@~";
        public static long DEFAULT_USERID = 1;

        //public static bool SetLoggedIn(String isLoggedIn)
        //{
        //    if (isLoggedIn != null)
        //    {
        //        System.Web.HttpContext.Current.Session[ConstantCollection.LOGGEDINSESSIONKEY] = isLoggedIn;
        //    }
        //    else
        //    {
        //        System.Web.HttpContext.Current.Session.Remove(ConstantCollection.LOGGEDINSESSIONKEY);
        //    }

        //    return true;
        //}

        //public static String GetLoggedIn()
        //{
        //    return (System.Web.HttpContext.Current.Session[ConstantCollection.LOGGEDINSESSIONKEY] != null) ? System.Web.HttpContext.Current.Session[ConstantCollection.LOGGEDINSESSIONKEY].ToString() : null;
        //}

        /// <summary>
        /// method SetUserContext
        /// sets the user context, it basically overrides when needed to 
        /// make it available in subsequent retrieval of user context in asp.net pages
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static bool SetUserContext(UserContext context)
        {
            if (context != null)
            {               
                System.Web.HttpContext.Current.Session[WebConstantCollection.USERCONTEXTKEY] = context;
            }
            else
            {
                System.Web.HttpContext.Current.Session.Remove(WebConstantCollection.USERCONTEXTKEY);
            }

            return true;
        }

        /// <summary>
        /// method GetCurrentUserContext 
        /// gets the current user context
        /// </summary>
        /// <returns></returns>
        public static UserContext GetCurrentUserContext()
        {
            return System.Web.HttpContext.Current.Session[WebConstantCollection.USERCONTEXTKEY] as UserContext;
        }

        /// <summary>
        /// method SetCurrentCultureInfo
        /// sets the current culture info based on the culture name provided
        /// </summary>
        /// <param name="cultureInfoName"></param>
        /// <returns></returns>
        public static bool SetCurrentCultureInfo(String cultureInfoName)
        {
            if (!String.IsNullOrEmpty(cultureInfoName))
            {
                System.Web.HttpContext.Current.Session[WebConstantCollection.CULTUREINFOSESSIONKEY] = cultureInfoName;
            }
            else
            {
                System.Web.HttpContext.Current.Session.Remove(WebConstantCollection.CULTUREINFOSESSIONKEY);
            }

            return true;
        }
        
        /// <summary>
        /// method GetCurrentCultureInfo
        /// gets the current culture info
        /// </summary>
        /// <returns></returns>
        public static String GetCurrentCultureInfo()
        {
            return (System.Web.HttpContext.Current.Session[WebConstantCollection.CULTUREINFOSESSIONKEY]!=null)? System.Web.HttpContext.Current.Session[WebConstantCollection.CULTUREINFOSESSIONKEY].ToString(): null;
        }


        //public static bool CheckPermission(UserContext context, string permissionKey)
        //{
        //    return context.HasPermission(permissionKey);
        //}

        /// <summary>
        /// method BuildEncryptedUri
        /// returns a string that contains the url in encrypted form
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string BuildEncryptedUri(string url)
        {
            if (url.Contains("?")) //  dose it have any query parameters
            {
                string path = url.Substring(0, url.IndexOf('?')); // get the path
                string query = url.Substring(url.IndexOf('?') + 1); // get the query parameters
                string encryptedQuery = String.Empty;
                if (!String.IsNullOrEmpty(query))
                    encryptedQuery = TSR.Framework.Cryptography.TripleDESCrypto.Encrypt(query); // encrypt the query parameters

                return path + (String.IsNullOrEmpty(encryptedQuery) ? string.Empty : "?" + System.Web.HttpUtility.UrlEncode(encryptedQuery));
            }

            return url;
        }

        //public static System.Collections.Specialized.NameValueCollection GetDecryptedQueryString(string queryString)
        //{
        //    System.Collections.Specialized.NameValueCollection collection = new System.Collections.Specialized.NameValueCollection();

        //    if (!String.IsNullOrEmpty(queryString))
        //    {
        //        string decryptedQuery = Cryptography.TripleDESCrypto.Decrypt(queryString);
        //        string[] parameters = decryptedQuery.Split('&');
        //        foreach (string parameter in parameters)
        //        {
        //            string[] nameValuePair = parameter.Split('=');
        //            if (nameValuePair.Length == 2)
        //            {
        //                collection.Add(nameValuePair[0], nameValuePair[1]);
        //            }
        //        }
        //    }

        //    return collection;
        //}

        /// <summary>
        /// method DecryptQueryString
        /// returns a Decrypted Query String
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="collection"></param>
        public static void DecryptQueryString(string queryString, System.Collections.Specialized.NameValueCollection collection)
        {
            if (!String.IsNullOrEmpty(queryString))
            {
                string decryptedQuery = TSR.Framework.Cryptography.TripleDESCrypto.Decrypt(queryString);
                //at first splitting query string depending on aspersand character to get the name value pairs
                string[] parameters = decryptedQuery.Split('&');

                foreach (string parameter in parameters)
                {
                    //separating name and value in query string
                    string[] nameValuePair = parameter.Split('=');
                    if (nameValuePair.Length == 1)
                    {
                        collection.Add(nameValuePair[0], String.Empty);
                    }
                    else if (nameValuePair.Length == 2)
                    {
                        collection.Add(nameValuePair[0], DeEncryptHTMLQueryString(nameValuePair[1]));
                    }
                    //added by tsrdev2
                    //when the value of queryString contains '='
                    else if (nameValuePair.Length > 2)
                    {
                        string qParam = nameValuePair[0];
                        string qValue = parameter.Substring(qParam.Length + 1);
                        collection.Add(qParam, DeEncryptHTMLQueryString(qValue));
                    }
                }
            }
        }

        public static System.Collections.Specialized.NameValueCollection DecryptQueryString(string queryString)
        {
            System.Collections.Specialized.NameValueCollection collection = new System.Collections.Specialized.NameValueCollection();
            if (!String.IsNullOrEmpty(queryString))
            {
                try
                {
                    string decryptedQuery = TSR.Framework.Cryptography.TripleDESCrypto.Decrypt(queryString);
                    if (decryptedQuery.StartsWith("?"))
                    {
                        decryptedQuery = decryptedQuery.Remove(0, 1);
                    }
                    //at first splitting query string depending on aspersand character to get the name value pairs
                    string[] parameters = decryptedQuery.Split('&');

                    foreach (string parameter in parameters)
                    {
                        //separating name and value in query string
                        string[] nameValuePair = parameter.Split('=');
                        if (nameValuePair.Length == 1)
                        {
                            collection.Add(nameValuePair[0], String.Empty);
                        }
                        else if (nameValuePair.Length == 2)
                        {
                            collection.Add(nameValuePair[0], DeEncryptHTMLQueryString(nameValuePair[1]));
                        }
                        //added by tsrdev2
                        //when the value of queryString contains '='
                        else if (nameValuePair.Length > 2)
                        {
                            string qParam = nameValuePair[0];
                            string qValue = parameter.Substring(qParam.Length + 1);
                            collection.Add(qParam, DeEncryptHTMLQueryString(qValue));
                        }
                    }
                }
                catch { }
            }
            return collection;
        }

        private static string DeEncryptHTMLQueryString(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                value = value.Replace(TSR.Framework.Web.Security.SecurityManager.STRQUERYSTRINGHTML, "&");
            }
            return value;
        }

        //added by tsrdev2
        public static object EncryptHTMLQueryString(object value)
        {
            if (value != null && value.GetType() == typeof(string) && !string.IsNullOrEmpty(value.ToString()))
            {
                value = value.ToString().Replace("&", TSR.Framework.Web.Security.SecurityManager.STRQUERYSTRINGHTML);
            }
            return value;
        }
    }
}
