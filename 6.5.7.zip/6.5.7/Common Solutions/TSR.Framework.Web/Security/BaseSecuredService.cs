using System;
using System.Collections.Generic;
using System.Text;

using TSR.Framework.Security;
using TSR.Framework;

namespace TSR.Framework.Web.Security
{
    /// <summary>
    /// Class
    /// Name: BaseSecuredService
    /// Description: This class is a custom WebService
    /// who inherits System.Web.Services.WebService,
    /// imeplements ISecurity and handles WebService security 
    /// related properties & functions for TSR Web Services
    /// </summary>
    public class BaseSecuredService : System.Web.Services.WebService, ISecurity
    {
        //private string _ApplicationKey;
        
        /// <summary>
        /// gets the User contexc
        /// </summary>
        public UserContext UserContext
        {
            get
            {
                if (Session[WebConstantCollection.USERCONTEXTKEY] == null)
                    //Session[ConstantCollection.USERCONTEXTKEY] = new UserContext(-1, String.Empty, String.Empty);
                    return null;

                return Session[WebConstantCollection.USERCONTEXTKEY] as UserContext;
            }
        }

        public SecurityEnabledAttribute SecurityEnabledAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                    return att as SecurityEnabledAttribute;

                return null;
            }
        }

        /// <summary>
        /// gets the permission key
        /// </summary>
        public virtual string PermissionKey
        {
            get
            {
                return this.GetType().Name.ToUpper();
            }
        }

        /// <summary>
        /// whether security is enabled or not 
        /// </summary>
        public bool SecurityEnabled
        {
            get { return false; }
        }

        /// <summary>
        /// whether some action is allowed or not
        /// </summary>
        public bool IsAllowed
        {
            get { return true; }
        }

        //public string ApplicationKey
        //{
        //    get
        //    {
        //        return _ApplicationKey;
        //    }
        //}

        /// <summary>
        /// wrapper method for parent class's GetService
        /// gets the service of type 'service'
        /// </summary>
        /// <param name="service"></param>
        /// <returns></returns>
        public override object GetService(Type service)
        {
            return base.GetService(service);
        }

        /// <summary>
        /// whether instantiating some class is allowed
        /// </summary>
        /// <returns></returns>
        public bool IsInstantiateAllowed()
        {
            return true;
        }

        /// <summary>
        /// returns whether invoking method with methodID is allowed
        /// </summary>
        /// <param name="methodID"></param>
        /// <returns></returns>
        public bool IsInvokeAllowed(int methodID)
        {
            return true;
        }
    }
}
