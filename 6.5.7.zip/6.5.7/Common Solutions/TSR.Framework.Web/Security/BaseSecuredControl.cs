using System;
using System.Collections.Generic;
using System.Text;
using TSR.Framework.Resource;

using TSR.Framework.Security;
using TSR.Framework;

namespace TSR.Framework.Web.Security
{
    /// <summary>
    /// Class
    /// Name: BaseSecuredControl
    /// Description: This class is a custom BaseUserControl
    /// who inherits Framework.Web.BaseUserControl,
    /// imeplements ISecurity and handles UserControl security 
    /// related properties & functions for TSR Administration
    /// This class will be inherited by all user controls of WebAdmin
    /// </summary>
    public class BaseSecuredControl : Framework.Web.BaseUserControl, ISecurity
    {
        /// <summary>
        /// gets the whether some class is under security control or not
        /// </summary>
        public SecurityEnabledAttribute SecurityEnabledAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                    return att as SecurityEnabledAttribute;

                return null;
            }
        }

        /// <summary>
        /// gets the Master page 
        /// </summary>
        public BaseMaster CustomMasterUserControl
        {
            get
            {
                if (Page.Master != null)
                    return Page.Master as BaseMaster;

                return null;
            }
        }

        /// <summary>
        /// gets or sets info whether this object has been modified
        /// </summary>
        public bool IsEdited
        {
            get { return DataTypeHelper.GetBooleanValue(ViewState["IsEdited"]); }
            set { ViewState["IsEdited"] = value; }
        }

        /// <summary>
        /// has any instance been created
        /// </summary>
        public bool IsCreated
        {
            get { return DataTypeHelper.GetBooleanValue(ViewState["IsCreated"]); }
            set { ViewState["IsCreated"] = value; }
        }

        /// <summary>
        /// has this object been marked as deleted
        /// </summary>
        public bool IsDeleted
        {
            get { return DataTypeHelper.GetBooleanValue(ViewState["IsDeleted"]); }
            set { ViewState["IsDeleted"] = value; }
        }


        /// <summary>
        /// has the changes made to this object been saved
        /// </summary>
        public bool IsSaved
        {
            get { return DataTypeHelper.GetBooleanValue(ViewState["IsSaved"]); }
            set { ViewState["IsSaved"] = value; }
        }

        /// <summary>
        /// gets the current UserContext
        /// </summary>
        public UserContext UserContext
        {
            get
            {
                BaseSecuredPage parentPage = Page as BaseSecuredPage;

                if (parentPage != null)
                    return parentPage.UserContext;

                return null;
            }
        }

        /// <summary>
        /// gets the permission key
        /// </summary>
        public virtual string PermissionKey
        {
            get
            {
                return this.GetType().Name.ToUpper();
            }
        }

        public bool IsAllowed
        {
            get { return true; }
        }

        /// <summary>
        /// is security enabled
        /// </summary>
        public bool SecurityEnabled
        {
            get { return false; }
        }

        /// <summary>
        /// wrapper class for SecurityManager.BuildEncryptedUri method
        /// returns an encrypted Url
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string EncryptURL(string url)
        {
            Session[TSR.Framework.Web.WebConstantCollection.MESSEGA_INFOR] = url.ToString();
            return SecurityManager.BuildEncryptedUri(url);
        }

        /// <summary>
        /// wrapper class for ResourceManager.GetResourceString method
        /// </summary>
        /// <param name="key"></param>
        /// <param name="defaultText"></param>
        /// <returns></returns>
        public string GetResourceString(string key, string defaultText)
        {
            return ResourceManager.GetResourceString(key, defaultText);
        }

        public string GetResourceString(string key, string defaultText, bool forJSAlert)
        {
            string str = ResourceManager.GetResourceString(key, defaultText);
            if (forJSAlert)
            {
                str = str.Replace("'", "\\'");
            }
            return str;
        }

        public object EncryptHTMLQueryString(object value)
        {
            return SecurityManager.EncryptHTMLQueryString(value);
        }
    }
}
