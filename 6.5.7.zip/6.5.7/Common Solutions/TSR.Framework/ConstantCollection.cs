using System;
using System.Collections.Generic;
using System.Text;
using TSR.Framework.Resource;
using System.Text.RegularExpressions;
using System.Drawing;

namespace TSR.Framework
{
    /// <summary>
    /// Class ConstantCollection
    /// holds all the constants that are used all over the system
    /// </summary>
    public partial class ConstantCollection
    {
        //general exception message used in all over the application
        //public const string UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE = "Object with same name already exists.";
        //public const string DATABASE_INSERTION_EXCEPTION_MESSAGE = "There have been a problem while performing insertion into Database.";
        //public const string AUTHORIZATION_EXCEPTION_MESSAGE = "You are not authorized for this action.";        
        //public const string LICENSE_EXCEPTION_MESSAGE = "License is unavailable for this module";
        //public readonly string LICENSE_EXCEPTION_MESSAGE = ResourceManager.GetResourceString("LicenseUnavailableForThisModule", "License is unavailable for this module");
        //public const string DATABASE_CONNECTION_EXCEPTION_MESSAGE = "Error connecting to Database";
                     

        public const string CULTUREINFOSESSIONKEY = "MyCultureInfo";
        public const string SESSION_CURRENTLANGUAGENAME = "MyLanguageName";
        //public static string SESSION_CURRENTLANGUAGENAME = System.Web.HttpContext.Current.Session.SessionID + "MyLanguageName";
        public const string SESSION_LANGUAGERESOURCEFORMENU = "ListLanguageResourcesForMenu";
        //public static string SESSION_LANGUAGERESOURCEFORMENU = System.Web.HttpContext.Current.Session.SessionID + "ListLanguageResourcesForMenu";
        public const string SESSION_LEFTMENU_LATESTSELECTEDID = "SessionLeftMenuLatestSelectedId";
        public const string LANGUAGENAME_DEFAULT = "US English";
        public const string LANGUAGEID_DEFAULT = "en";
        public const string LANGUAGENAME_LANGUAGEID_SEPERATOR = "#";
        public const string PREFERLANGUAGES_SEPERATOR = "|";
        public const string APPLICATION_ALLRESOURCES = "ApplicationAllResources";

        public const string DEFAULT_PASSWORD = "Welcome_123";
        public const string GRIDFOOTERFIRSTNAME = "Total";
        public const string GRIDFOOTERSECONDNAME = "Avg";
        public const short MAXIMUMREQUESTS = 1;
        public const string FACADEASSEMBLYPATH = "~/bin/TSR.Facade.dll";
        public const string FACADEASSEMBLYNAMESPACE = "TSR.Facade";
        internal const string USERCONTEXTKEY = "MyUserContext";

        //keys to log exception
        public const string REQUEST_URL_KEY_TO_LOG_EXCEPTION = "Offending URL: ";
        public const string EXCEPTION_SOURCE_KEY_TO_LOG_EXCEPTION = "Source: ";
        public const string EXCEPTION_MESSAGE_KEY_TO_LOG_EXCEPTION = "Application Message: ";
        public const string EXCEPTION_STACKTRACE_KEY_TO_LOG_EXCEPTION = "Stack trace: ";

        ///constants
        public const string AdressTypeName = "Standard";
        public const long AdressTypeID = 1;

        public const string START_TAG = "[";
        public const string END_TAG = "]";

        //pattern convert datetime to string
        //public const string PATTERN_STANDARD_DATETIME = "yyyy/MM/dd hh:mm:ss tt";
        public const string PATTERN_STANDARD_DATETIME = "yyyy/MM/dd";

        public const string YES_STATUS = "Yes";
        public const string NO_STATUS = "No";

        public const string DEFAULT_USERGROUP_NAME = "DEFAULT_APPROVER_UG_";

        public const string DEFAULT_MAXLENGTH_TEXT_FIELD = "255";
        public const string BACK_COLOR_MISSINGDATA_ROW = "#D2D2D2";
        public static string STRING_ENTER = "\r\n";
        public static string REPLACE_ENTER = " ";
        public static long? CONTACT_ID;     
        //public static string VERSION = "5.1";
        //time entry
        //if edit value of TIMEENTRY_NOTCHANGER has to edit on OUA
        public const string TIMEENTRY_NOTCHANGED = "TIMEENTRY_NOTCHANGED";
        public const string TIMEENTRY_USER_CHANGED = "TimeEntry_User_Changed";

        public const string OUAChangeTimeEntryInLockPeriod = "OUAChangeTimeEntryInLockPeriod";
        public const string OUADeleteTimeEntryInLockPeriod = "OUADeleteTimeEntryInLockPeriod";
        public const string OUASubmitTimeEntryInLockPeriod = "OUASubmitTimeEntryInLockPeriod";

        public static string SPECIALCHARACTERS = "+/\\[]:;|=,+*?<>@\"";
        //added by tsrdev2
        //hosted version
        public const int LOGIN_DELAY = 10;

        //added by tsrdev2
        //feature 177
        // "Only show own projects" permisson name
        public const string ONLYSHOWOWNPROJECTS_PERMISSION = "ONLY_SHOW_OWN_PROJECTS";
        //"Only Personal Reporting" permission name
        public const string ONLYPERSONALREPORTING_PERMISSION = "ONLY_PERSONAL_REPORTING";
        //"Standard Report Page" permission name
        public const string SECURED_REPORTS_ALLREPORTS_PERMISSION = "SECURED_REPORTS_ALLREPORTS_ASPX";
        public const string SECURED_LICENSING_UPDATELICENSE_PERMISSION = "SECURED_LICENSING_UPDATELICENSE_ASPX";
        //"Project Manager" permission name
        public const string PROJECTMANAGER_PERMISSION = "PROJECT_MANAGER";

        public const string SMARTPHONE_ACCESS_PERMISSION = "SMARTPHONE_ACCESS";

        public const string EXPENSE_SUFIX_PERMISSION = "EXPENSE";

        public const string EXPENSEREPORTINGALL_PERMISSION = "ExpenseReportingAll";
        public const string EXPENSEREPORTINGPERSONAL_PERMISSION = "ExpenseReportingPersonal";
        public const string PRINTEXPENSEREPORTFORSIGNING_PERMISSION = "PrintExpenseReportForSigning";
        public const string ADDEXPENSES_PERMISSION = "AddExpenses";
        public const string SECURED_EXPENSES_EXPENSEREPORTING_PERMISSION = "SECURED_EXPENSES_EXPENSEREPORTING_ASPX";
        public const string SECURED_SETUPDATA_USERGROUPLIST_ASPX = "SECURED_SETUPDATA_USERGROUPLIST_ASPX";
        public const string SECURED_SETUPDATA_USERGROUP_ASPX = "SECURED_SETUPDATA_USERGROUP_ASPX";

        public const string RATES_SUFIX_PERMISSION = "Rate";
        public const string RATEADMIN_PERMISSION = "RatesAdmin";
        public const string RATEREPORTINGALL_PERMISSION = "RatesReportingAll";
        public const string SECURED_RATES_RATESREPORTING_ASPX = "SECURED_RATES_RATESREPORTING_ASPX";
        public const string SECURED_RATES_RATESREPORTRESULT_ASPX = "SECURED_RATES_RATESREPORTRESULT_ASPX";

        public const int LOADING_COUNT_ITEMS = 50;
        public const int LOADING_COUNT_ITEMS_2 = 100;
        public const int LOADING_COUNT_ITEMS_5000 = 5000;

        public static string Version
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;

                string strVersion = v.ToString();
                string[] arrSubVersion = strVersion.Split('.');
                if (arrSubVersion.Length == 1)
                {
                    strVersion = strVersion + ".0";
                }
                else if (arrSubVersion.Length == 2)
                {

                }
                else if (arrSubVersion.Length > 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                }
                return strVersion;
            }
        }
        public static string ExtractHexDigits(string input)
        {
            // remove any characters that are not digits (like #)
            Regex isHexDigit
               = new Regex("[abcdefABCDEF\\d]+", RegexOptions.Compiled);
            string newnum = "";
            foreach (char c in input)
            {
                if (isHexDigit.IsMatch(c.ToString()))
                    newnum += c.ToString();
            }
            return newnum;
        }
        public static Color GetColor(String strColor)
        {
            string hc = ExtractHexDigits(strColor);
            if (hc.Length != 6)
            {
                // you can choose whether to throw an exception
                //throw new ArgumentException("hexColor is not exactly 6 digits.");
                return Color.Empty;
            }
            string r = hc.Substring(0, 2);
            string g = hc.Substring(2, 2);
            string b = hc.Substring(4, 2);
            Color color = Color.Empty;
            try
            {
                int ri
                   = Int32.Parse(r, System.Globalization.NumberStyles.HexNumber);
                int gi
                   = Int32.Parse(g, System.Globalization.NumberStyles.HexNumber);
                int bi
                   = Int32.Parse(b, System.Globalization.NumberStyles.HexNumber);
                color = Color.FromArgb(ri, gi, bi);
            }
            catch
            {
                // you can choose whether to throw an exception
                //throw new ArgumentException("Conversion failed.");
                return Color.Empty;
            }
            return color;

        }
        public static string SubVersion
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;                
                string strVersion = v.ToString();
                string[] arrSubVersion = strVersion.Split('.');
                if (arrSubVersion.Length == 1)
                {
                    strVersion = strVersion + ".0";
                }
                else if (arrSubVersion.Length == 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                }
                else if (arrSubVersion.Length > 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1] + "." + arrSubVersion[2];
                }
                return strVersion;
            }
        }

        public static string BuildVersion
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;
                return v.Revision.ToString();
            }
        }

        //added by tsrdev2
        /// <summary>
        /// gets rolling loggin file
        /// </summary>
        public static string RollingFileName
        {
            get
            {
                return "TSRLog";
            }
        }

        public static string RollingFailedLoginFileName
        {
            get
            {
                return string.IsNullOrEmpty(ConfigurationBlock.CustomerNo) ? "TSRLog" : "TSRLog\\" + ConfigurationBlock.CustomerNo;
            }
        }

        //added by tsrdev2
        /// <summary>
        /// Gets filename of mail server setting
        /// </summary>
        public static string MailServerSettingFileName;
        public static string LicenseDemoFileName;

        public const string _strTimeInterval_Approval_From = "TimeIntervalApprovalFrom";
        public const string _strTimeInterval_Approval_To = "TimeIntervalApprovalTo";
        public const string _strTimeInterval_TimeSheetWeb_From = "TimeIntervalTimeSheetWebFrom";
        public const string _strTimeInterval_TimeSheetWeb_To = "TimeIntervalTimeSheetWebTo";
        public const string _strTimeInterval_TimeSheetMobile_From = "TimeIntervalTimeSheetMobileFrom";
        public const string _strTimeInterval_TimeSheetMobile_To = "TimeIntervalTimeSheetMobileTo";
        public const string _strTimeInterval_NotifiTimeUser_From = "TimeIntervalNotifiTimeUserFrom";
        public const string _strTimeInterval_NotifiTimeUser_To = "TimeIntervalNotifiTimeUserTo";
        public const string _strTimeInterval_NotifiApprover_From = "TimeIntervalNotifiApproverFrom";
        public const string _strTimeInterval_NotifiApprover_To = "TimeIntervalNotifiApproverTo";
        public const string _strTimeInterval_NotifiApprovedRejected_From = "TimeIntervalNotifiApprovedRejectedFrom";
        public const string _strTimeInterval_NotifiApprovedRejected_To = "TimeIntervalNotifiApprovedRejectedTo";

        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_APPROVAL_FROM = 45;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_APPROVAL_TO = 10;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_TIMESHEETWEB_FROM = 45;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_TIMESHEETWEB_TO = 10;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_TIMESHEETMOBILE_FROM = 10;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_TIMESHEETMOBILE_TO = 0;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFITIMEUSER_FROM = 90;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFITIMEUSER_TO = -1;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFIAPPROVER_FROM = 90;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFIAPPROVER_TO = -1;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFIAPPROVEDREJECTED_FROM = 90;
        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_NOTIFIAPPROVEDREJECTED_TO = 10;

        public const int DEFAULTSETTINGVALUE_TIMEINTERVAL_AUTOMACTIC_SYNC = 10;
        public const int MINIMUM_TIMEINTERVAL_AUTOMACTIC_SYNC = 5;

        public const string FORMAT_DATETIME_STRING = "yyyyMMddhhmmss";

        //User Setting Key
        public const string DefaultSettingKey_WeekStartsOn = "WeekStartsOn";
        public const string DefaultSettingKey_TSRLockPeriod = "TSRLockPeriod";

        //For form Download
        public const string NOACCESSTO_OUADOWNLOAD = "NoAccessToOUADownload";

        public const string DefaultSettingKey_DurationWarning = "DurationWarning";
        public const string DefaultSettingKey_DurationWarningEnable = "IsDurationWarningEnable";

        public const string DefaultSettingKey_Enforce = "Enforce";
    }
}
