using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Runtime.CompilerServices;

using TSR.Framework.Scheduling;
using TSR.Framework.Exceptions;
using System.Net;

namespace TSR.Framework
{
    /// <summary>
    /// Class
    /// Name: Email
    /// Description: This class is a custom Email 
    /// who handles Email related properties & methods
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class Email : IDisposable
    {
        [MethodImpl(MethodImplOptions.Synchronized)]        
        public void SendMail(Notification notificationObject)
        {
            MailMessage message = new MailMessage();
            message.From= new MailAddress(notificationObject.FromAddress);
            message.To.Add(notificationObject.ToAddress);
            if (!(string.IsNullOrEmpty(notificationObject.CCAddress)))
                message.CC.Add(notificationObject.CCAddress);
            string subject = notificationObject.Subject.Replace(TSR.Framework.ConstantCollection.STRING_ENTER, TSR.Framework.ConstantCollection.REPLACE_ENTER);
            message.Subject = subject;
            message.Body = notificationObject.Body;
            message.IsBodyHtml = true;
            
            ///modified by tsrdev2
            //SmtpClient smtpClient = new SmtpClient();
            MailServerSetting mailSetting = ConfigurationBlock.MailSettingsXML;
            if (mailSetting == null)
            {
                return;
            }
            SmtpClient smtpClient = new SmtpClient(mailSetting.Host, mailSetting.Port);            
            //smtpClient.EnableSsl = true;
            //smtpClient.UseDefaultCredentials = true; 
            bool anonymousLogin = false;
            if (mailSetting.AnonymousLogin)
            {                
                smtpClient.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
            }
            else
            {
                smtpClient.Credentials = new NetworkCredential(mailSetting.UserName, mailSetting.Password);
                smtpClient.EnableSsl = mailSetting.EnableSsl;
                if (mailSetting.EnableSsl)
                    System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);                
            }

            Object userState = notificationObject;
            
            //Attach event handler for async callback
            smtpClient.SendCompleted += new SendCompletedEventHandler(smtpClient_SendCompleted);

            try
            {
                //Send the email asynchronously                
                smtpClient.SendAsync(message, userState);
                //smtpClient.Send(message);
            }
            catch (SmtpException smtpEx)
            {
                Logging.LoggingHandler.LogUnhandledException(smtpEx);
                //throw smtpEx;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
                //throw ex;
            }
        }

        private bool RemoteServerCertificateValidationCallback(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }

        /// <summary>
        /// This methods send email by passing from address, to address, subject and body parameters
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// 
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void SendMail(string from, string to, string subject, string body)
        {
            MailMessage message = new MailMessage(from, to, subject, body);

            ///modified by tsrdev2
            //SmtpClient smtpClient = new SmtpClient();
            MailServerSetting mailSetting = ConfigurationBlock.MailSettingsXML;
            if (mailSetting == null)
            {
                return;
            }
            SmtpClient smtpClient = new SmtpClient(mailSetting.Host, mailSetting.Port);
            smtpClient.Credentials = new NetworkCredential(mailSetting.UserName, mailSetting.Password);
            //smtpClient.UseDefaultCredentials = true; 

            Object userState = message;
           
            //Attach event handler for async callback
            smtpClient.SendCompleted += new SendCompletedEventHandler(smtpClient_SendCompleted);

            try
            {
                //Send the email asynchronously
                smtpClient.SendAsync(message, userState);
                //smtpClient.Send(message);
            }
            catch (SmtpException smtpEx)
            {
                Logging.LoggingHandler.LogUnhandledException(smtpEx);
                //throw smtpEx;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
                //throw ex;
            }
        }


        /// <summary>
        /// Event handler for processing completion information after asynchronous email sent.
        /// </summary>
        private void smtpClient_SendCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {

            //Get UserState as MailMessage instance from SendMail()
            MailMessage mailMessage = e.UserState as MailMessage;
            Notification notificationObject = null;
            if (mailMessage == null)
            {
                notificationObject = e.UserState as Notification;
                if (notificationObject != null)
                {
                    mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress(notificationObject.FromAddress);
                    mailMessage.To.Add(notificationObject.ToAddress);
                    if (!(string.IsNullOrEmpty(notificationObject.CCAddress)))
                        mailMessage.CC.Add(notificationObject.CCAddress);
                    string subject = notificationObject.Subject.Replace(TSR.Framework.ConstantCollection.STRING_ENTER, TSR.Framework.ConstantCollection.REPLACE_ENTER);
                    mailMessage.Subject = subject;
                    mailMessage.Body = notificationObject.Body;
                    mailMessage.IsBodyHtml = true;
                }
            }

            if (e.Cancelled) // is it cancelled..
            {
                SetTrycount(notificationObject); // set the try count 
                Logging.LoggingHandler.LogUnhandledException(new Exception("Sending mail was cancelled.")); // log the exception
            }

            if (e.Error != null) // if there are some errors
            {
                SetTrycount(notificationObject); //set the try count 
                Logging.LoggingHandler.LogUnhandledException(e.Error); // and log the error
            }
            else // if no error
            {
                try
                {
                    using (NotificationData data = new NotificationData())
                    {
                        notificationObject.IsSent = true; //mark the notification as sent
                        notificationObject.TryCount += 1; // increment the try count 
                        notificationObject.ExecutionTimeStamp = DateTime.Now;
                        long result = data.Update(notificationObject); // update database with changes
                    }
                }
                catch (Exception exp) // catch the exception
                {
                    Logging.LoggingHandler.LogUnhandledException(exp); // log the exception..
                }
            }
        }

        /// <summary>
        /// Method : SetTrycount
        /// sets the number of attempts made to send an e-mail
        /// </summary>
        /// <param name="_object">an object of Notification class</param>
        private void SetTrycount(Notification _object)
        {
            try
            {
                if (_object != null)// if the object is not null
                {
                    using (NotificationData data = new NotificationData())
                    {
                        _object.TryCount += 1; // increment the try count
                        _object.IsSent = false; //mark the message as 'NOT SENT' 
                        long result = data.Update(_object); //update the database
                    }
                }
            }
            catch (DatabaseConnectionException exp) // catch DatabaseConnectionException
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the database connection error

            }
            catch (Exception exp) // catch generic error
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the error
            }
        }

        #region IDisposable Members


        public void Dispose()
        {

        }

        #endregion
    }    
}
