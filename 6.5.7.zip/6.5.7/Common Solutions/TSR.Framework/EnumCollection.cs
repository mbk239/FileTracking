using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework
{
    /// <summary>
    /// Message types shown in Web Admin
    /// </summary>
    public enum MessageTypeEnum
    {
        Failure = 0,
        Success = 1,
        DatabaseConnectionError = 2,
        Required = 3,
        GlobalError=4,
        None = 5
    }

    /// <summary>
    /// Enumeration of months
    /// </summary>
    public enum MonthTypeEnum
    {
        Jan= 1,
        Feb,
        Mar,
        Apr,
        May,
        Jun,
        Jul,
        Aug,
        Sep,
        Oct,
        Nov,
        Dec
    }


    /// <summary>
    /// Enumeration of Search control
    /// </summary>
    public enum SearchComponentEnum
    { 
        None=0,
        User_Group,
        Activity,
        User,
        Role,
        Permission
    }

    public enum AddComponentEnum
    {
        None = 0,
        Organization,
        Project,
        Activity
    }
    public enum TransferMediumEnum
    {
        Email = 0,
        SMS,
        Postal
    }

    public enum SettingKeysEnum
    {
        None,
        TSRMiscSyncRemovedData,
        TSRMiscNotSyncCompletedData,
        TSRMiscNotSyncTECreatedViaWeb,
        TSRMiscFuturePeriod,
        TSRMiscPastPeriod,
        TSRSyncRangeIndexFuture,
        TSRPreferredLanguages,
        TSRLanguageId,
        TSRSyncRangeIndex,
        TSRSyncRangePeriodFuture,
        TSRSyncRangePeriod,
        TSROutlookFolderToSync, //not used
        SynchronizeTSRSetupData,
        SynchronizeTSREntries,
        TSRAutoSyncPeriodOption,
        TSRAutoSyncWhenOutlookClose,
        TSRAutoSyncWhenOutlookOpen,
        TSRAutoSyncOption,
        TSRAutoSyncPeriod,
        TSRMiscLaunch,
        TSRMiscPastIndex,
        TSRMiscFutureIndex,
        TSRAutoSyncIndex,
        TSRLanguageName
    }

    public enum TemplateStatusEnum
    { 
        New,
        Editable,
        ReadOnly
    }
    public enum LockStatusEnum
    {
        No = 0,
        Yes = 1
    }
    /// <summary>
    /// tsr dev4 
    /// add rejected = 3
    /// </summary>
    public enum NotificationTypeEnum
    {
        None = 0,
        TimeEntryUser = 1,
        Approver = 2 ,
        Rejected = 3
    }

    public class EnumListItem
    {
        public static string COL_ID = "ID";
        public static string COL_NAME = "Name";

        public string ID { get; set; }
        public string Name { get; set; }

    }

    //added by tsrdev2
    /// <summary>
    /// type of event of log for failed login
    /// </summary>
    public enum TypeOfEventEnum1
    {
        WrongPassword = 0,
        AccountLocked = 1,
        AccountUnlocked = 2,
        PasswordChanged = 3,
        UnknownUser = 4,
        Success = 99
    }
    //added by tsrdev2
    /// <summary>
    /// source of log for failed login
    /// </summary>
    public enum SourceType1
    {
        WebAdmin = 0,
        WebServices = 1,
        OUA = 2,
        DataBridge = 3
    }
    public enum PageState
    { 
        None = 0,
        SubmitEntry = 1,
        Approval = 2
    }

    /// <summary>
    /// Enumeration of types of report
    /// </summary>
    public enum ReportTypeEnum
    {
        General = 1,
        CompareUsers = 2,
        CompareUserGroups = 3,
        CompareProjects = 4,
        CompareActivities = 5,
        User = 6,
        UserGroup = 7,
        ProjectSummary = 8, 
        None = 99
    }
    public enum UserDetailFormatEnum
    {
        Text = 0,
        Date = 1
    }
}
