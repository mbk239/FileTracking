﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework
{
    public class DownloadOUAProperties
    {
        private string urlRoot;
        private string urlInstallationGuide;
        private string urlDownload;

        public string UrlRoot
        {
            get { return urlRoot; }
            set { urlRoot = value; }
        }
        
        public string UrlInstallationGuide
        {
            get { return urlInstallationGuide; }
            set { urlInstallationGuide = value; }
        }
        
        public string UrlDownload
        {
            get { return urlDownload; }
            set { urlDownload = value; }
        }

    }
}
