using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework
{
    /// <summary>
    /// class AttributeHelper
    /// contains helper methods for retriving attributes
    /// </summary>
    public static class AttributeHelper
    {
        /// <summary>
        /// mathod : GetAttribute
        /// gets the attribute based on object type and attribute type
        /// </summary>
        /// <param name="objectType">the object type</param>
        /// <param name="attributeType">the type of the attribute</param>
        /// <returns>the attribute</returns>
        public static Attribute GetAttribute(Type objectType, Type attributeType)
        {
            Attribute att = Attribute.GetCustomAttribute(objectType, attributeType);

            if (att != null)
                return att;

            if (objectType.BaseType != null)
                return GetAttribute(objectType.BaseType, attributeType);

            return null;
        }
    }
}
