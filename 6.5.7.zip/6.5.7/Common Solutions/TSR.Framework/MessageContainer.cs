using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework
{
    /// <summary>
    /// Message container class used for showing Message in Web Admin. 
    /// The structure of Message is customized
    /// </summary>
    [Serializable]
    public class MessageContainer
    {
        private MessageTypeEnum _MessageType;
        private string _Subject;
        private string _Detail;

        /// <summary>
        /// Type of message
        /// </summary>
        public MessageTypeEnum MessageType
        {
            get { return _MessageType; }
            set { _MessageType = value; }
        }

        /// <summary>
        /// Subject of message
        /// </summary>
        public string Subject
        {
            get { return _Subject; }
            set { _Subject = value; }
        }

        /// <summary>
        /// Message Details text
        /// </summary>
        public string Detail
        {
            get { return _Detail; }
            set { _Detail = value; }
        }

        /// <summary>
        /// the default constructor for MessageContainer
        /// </summary>
        public MessageContainer() { }

        /// <summary>
        /// constructor for MessageContainer class
        /// sets the message type, subject and detail of a message
        /// </summary>
        /// <param name="type">any value from MessageTypeEnum</param>
        /// <param name="subject">string name of subject</param>
        /// <param name="detail">representing the details of the message</param>
        public MessageContainer(MessageTypeEnum type, string subject, string detail)
        {
            _MessageType = type;
            _Subject = subject;
            _Detail = detail;
        }
    }
}
