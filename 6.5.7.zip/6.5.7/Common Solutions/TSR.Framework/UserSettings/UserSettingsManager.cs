﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.Threading;
using TSR.Framework.Exceptions;
using System.Collections.Specialized;

namespace TSR.Framework.UserSettings
{
    /// <summary>
    /// Class
    /// Name: UserSettingsManager
    /// Description: This class is a static Class     
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class UserSettingsManager
    {
        #region Constant
        private const string GETALLUSERSETTINGSBYSETTINGKEY = "GetAllUserSettingsBySettingKey";
        private const string UPDATEUSERSETTINGSBYUSERIDANDSETTINGNAME = "UpdateUserSettingsByUserIDAndSettingName";
        #endregion
        
        #region Private Variables
        private string _connectionString = string.Empty;
        #endregion

        #region The Constructor
        //public UserSettingsManager()
        //{
        //    _connectionString = ConfigurationBlock.ConnectionString;
        //}
        public UserSettingsManager(string connectionString)
        {
            _connectionString = connectionString;
        }
        #endregion

        //added by tsrdev2 - 04 Nov 2010
        /// <summary>
        /// gets all resource include: language name, key and value
        /// </summary>
        /// <returns></returns>
        public Dictionary<Int64, String> GetAllUserSettingsForSettingKey(SettingKeysEnum settingKey)
        {
            Dictionary<Int64, String> dicResult = new Dictionary<long, string>();
            //NameValueCollection settingValuesList = new NameValueCollection(); 
            SqlConnection connection = new SqlConnection(_connectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                //Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = GETALLUSERSETTINGSBYSETTINGKEY;
            command.CommandType = CommandType.StoredProcedure;
            SqlParameter par = new SqlParameter("@SettingName", SqlDbType.NText);
            par.Value = settingKey.ToString();
            command.Parameters.Add(par);                                  
            try
            {
                SqlDataReader reader = command.ExecuteReader();                
                using (reader)
                {                    
                    while (reader.Read())
                    {
                        Int64 userID = -1;
                        string settingValue = string.Empty;
                        //settingValuesList.Add(reader.GetValue(0).ToString(), reader.GetValue(1).ToString());
                        //index = 0 is column UserID
                        if (reader.IsDBNull(0))
                            userID = -1;
                        else userID = reader.GetInt64(0);
                        //index = 1 is column SettingValue
                        if (reader.IsDBNull(1))
                            settingValue = "";
                        else settingValue = reader.GetString(1);

                        dicResult.Add(userID, settingValue);                        
                    }

                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                //Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return dicResult;
        }
        // added by tsrdev2
        /// <summary>
        /// update language resource        
        /// </summary>
        /// <param name="twoLetterISOLanguageName"></param>
        /// <param name="languageName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public bool UpdateSettingValue(string settingName, string settingValue,Int64? userID)
        {
            bool success = false;
            SqlConnection connection = new SqlConnection(_connectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                //Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = UPDATEUSERSETTINGSBYUSERIDANDSETTINGNAME;
            command.CommandType = CommandType.StoredProcedure;            
            ///set parameters
            SqlParameter parameter = new SqlParameter("@UserID", SqlDbType.BigInt);
            parameter.Value = userID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@SettingName", SqlDbType.NText);
            parameter.Value = settingName;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@SettingValue", SqlDbType.NText);
            parameter.Value = settingValue;
            command.Parameters.Add(parameter);            
            try
            {
                if(command.ExecuteNonQuery() > 0)                
                    success = true;
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                //Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
                success = false;
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return success;
        }      
    }
}
