﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices;
using System.Security.Principal;
using System.Web;
using System.Collections.Specialized;

namespace TSR.Framework
{
    /// <summary>
    /// Class
    /// Name: ADHelper
    /// Description: This class is a helper class which handles Active Directory 
    /// related properties & methods.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class ADHelper
    {
        public const String ADUser_LoginName = "SAMAccountName";
        public const String ADUser_FirstName = "givenName";
        public const String ADUser_MiddleInitials = "initials";
        public const String ADUser_LastName = "sn";
        public const String ADUser_Company = "company";
        public const String ADUser_Department = "department";
        public const String ADUser_Email = "mail";
        public const String ADUser_UserAccountControl = "useraccountcontrol";
        public const String ADUser_MemberOf = "memberOf";
        //added by tsrdev2
        public const String ADUser_PrimaryGroupID = "primaryGroupID";
        public const String ADUser_ObjectSid = "objectSid";
        public const String ADUser_PrimaryGroupName = "distinguishedName";
        
        
        /// <summary>
        /// Find the UserName by passing a path of AD login user
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static string ExtractUserName(string path)
        {
            string[] userPath = path.Split(new char[] { '\\' });
            return userPath[userPath.Length - 1];
        }

        /// <summary>
        /// Checking a user in active directory user list by passing login name
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="loginName"></param>
        /// <returns></returns>
        public static bool IsExistInAD(string loginName)
        {
            string userName = ExtractUserName(loginName);
            DirectorySearcher search = new DirectorySearcher();
            search.Filter = String.Format("(SAMAccountName={0})", userName);
            search.PropertiesToLoad.Add("cn");
            SearchResult result = search.FindOne();

            if (result == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Getting an active directory user by passing user login name
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="loginName"></param>
        /// <returns></returns>
        public static DirectoryEntry GetADUserByUserName(string userName)
        {
            string _userName = ExtractUserName(userName);
            DirectorySearcher search = new DirectorySearcher();
            search.Filter = String.Format("(SAMAccountName={0})", _userName);
            search.PropertiesToLoad.Add("cn");
            SearchResult result = search.FindOne();
            if (result != null)
                return result.GetDirectoryEntry();
            return null;
        }

        /// <summary>
        ///Getting list of Group of an Active Directiry entry 
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static StringCollection GetADGroupsByADUser(DirectoryEntry obj)
        {
            StringCollection groupList = new StringCollection();

            string memberOf = GetMemberOfsPropertyValue(obj); // get the value of the property 'memberof'
            //memberOf prop not contains primary group of the user
            //gets primary group by objectSid
            string primaryGroups = GetPrimaryGroupName(obj, null);

            //all groups:
            memberOf += primaryGroups;
            if (!String.IsNullOrEmpty(memberOf))//if the property is not empty
            {
                String[] members = memberOf.Split(','); // split the comma seperated list 

                foreach (String member in members)
                {
                    String[] memstrs = member.Split('='); //split the '=' seperated list
                    if (memstrs.Length > 0)
                    {
                        if (memstrs[0].Equals("cn", StringComparison.CurrentCultureIgnoreCase))
                        {
                            bool isExist = false;
                            foreach (String grName in groupList)
                            {
                                if (grName.ToLower().Equals(memstrs[1].ToLower()))
                                {
                                    isExist = true;
                                    break;
                                }
                            }
                            if (!isExist)
                            {
                                groupList.Add(memstrs[1].ToLower()); // add to the group list
                            }
                        }
                    }
                }
            }

            return groupList;
        }

        /// <summary>
        ///Getting List of AD Group
        /// 
        /// Last updated on:
        /// October 05, 2009
        /// Change description: 
        /// </summary>
        /// <returns></returns>
        public static NameValueCollection GetADGroups()
        {
            DirectoryEntry searchRoot = new DirectoryEntry();
            NameValueCollection groupList = new NameValueCollection();

            searchRoot.Path = string.Empty;
            //searchRoot.Path = "LDAP://TSRSERVER/DC=TSR,DC=IFI,DC=local";
            searchRoot.AuthenticationType = AuthenticationTypes.Secure; //is default            

            //create instance fo the direcory searcher
            DirectorySearcher deSearch = new DirectorySearcher();

            //set the search filter
            deSearch.SearchRoot = searchRoot;
            deSearch.PropertiesToLoad.Add("cn");
            deSearch.Filter = "(&(objectClass=group)(cn=*))";

            //find the first instance
            SearchResultCollection results = deSearch.FindAll();

            foreach (SearchResult result in results)
            {
                if (result.Properties["cn"][0] != null)
                {   
                    if (groupList.Get(result.Properties["cn"][0].ToString()) == null)
                    {
                        groupList.Add(result.Properties["cn"][0].ToString(), result.Properties["cn"][0].ToString());
                    }
                }
            }            
            return groupList;
        }

        /// <summary>
        /// Getting List of Active DirectoryEntries of a Group
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public static List<DirectoryEntry> GetADUsersByADGroup(string groupName)
        {
            DirectoryEntry searchRoot = new DirectoryEntry();
            searchRoot.Path = string.Empty;
            searchRoot.AuthenticationType = AuthenticationTypes.Secure;
            DirectorySearcher search = new DirectorySearcher(searchRoot, "(&(objectClass=user)(objectCategory=person))");
            //search.Filter = String.Format("(CN={0})", groupName);

            //setup the search properties to be loaded
            search.PropertiesToLoad.Add(ADUser_LoginName);
            search.PropertiesToLoad.Add(ADUser_FirstName);
            search.PropertiesToLoad.Add(ADUser_MiddleInitials);
            search.PropertiesToLoad.Add(ADUser_LastName);
            search.PropertiesToLoad.Add(ADUser_UserAccountControl);
            search.PropertiesToLoad.Add(ADUser_Email);
            search.PropertiesToLoad.Add(ADUser_Company);
            search.PropertiesToLoad.Add(ADUser_MemberOf);
            search.PropertiesToLoad.Add(ADUser_Department); //
           
            SearchResultCollection result;
            result = search.FindAll(); // get the search result
            List<DirectoryEntry> userList = new List<DirectoryEntry>();

            foreach (SearchResult sr in result)
            {
                DirectoryEntry de = sr.GetDirectoryEntry();
                string memberOf = GetMemberOfsPropertyValue(de);
                if (!String.IsNullOrEmpty(memberOf))
                {
                    if (memberOf.Contains("CN=" + groupName)) // if the group name is in the list memberof
                    {
                        userList.Add(de); // add the dictionary entry to the user list
                    }
                }

            }

            return userList;
        }

        //public static DirectoryEntry GetDirectoryEntry()
        //{
        //    DirectoryEntry de = new DirectoryEntry();
        //    de.Path = "";
        //    de.AuthenticationType = AuthenticationTypes.Secure;

        //    return de;
        //}

        //public static DirectoryEntry UserExists(string username)
        //{
        //    DirectoryEntry root = GetDirectoryEntry();
        //    DirectoryEntry userDE = null;
        //    DirectorySearcher deSearch = new DirectorySearcher();

        //    deSearch.SearchRoot = root;
        //    deSearch.Filter = "(&(objectCategory=person)(objectClass=user))";
        //    deSearch.PropertiesToLoad.Add("cn");
        //    SearchResultCollection results = deSearch.FindAll();

        //    foreach (SearchResult sr in results)
        //    {
        //        if (sr.GetDirectoryEntry().Properties["SAMAccountName"].Value.Equals(username))
        //        {
        //            userDE = sr.GetDirectoryEntry();
        //            break;
        //        }
        //    }

        //    return userDE;
        //}

        /// <summary>
        /// Getting All active directory entries of a domain
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="domainpath"></param>
        /// <returns></returns>
        public static List<DirectoryEntry> GetAllADDomainUsers(string domainpath)
        {
            DirectoryEntry searchRoot = new DirectoryEntry(domainpath);


            //DirectoryEntry searchRoot = new DirectoryEntry("LDAP://DC=TSR,DC=IFI,DC=local", "TSR.IFI.local\tsrdev2", "Demo321");            
            //System.IO.StreamWriter sw = new System.IO.StreamWriter(@"C:\TSR\WebServers\8085\ADUser_log.txt", true);
            //StringBuilder sb = new StringBuilder();            
            //foreach (DirectoryEntry de in searchRoot.Children)
            //{
            //    //HttpContext.Current.Response.Write(de.Name + ", " + de.Path + "<br />");                
            //    sb.Append("AppType: " + de.AuthenticationType.ToString()).Append("\n");
            //    sb.Append("Name: " + de.Name).Append("\n");
            //    sb.Append("ParentName: " + de.Parent.Name).Append("\n");
            //    sb.Append("Path: " + de.Path).Append("\n");
            //    sb.Append("UserName: " + de.Username).Append("\n");
            //    sb.Append("++++++++++++++++++").Append("\n");                
            //}
            //sw.WriteLine(sb.ToString());
            //sw.Close();
            //List<DirectoryEntry> userList = new List<DirectoryEntry>();
            //return userList;

            //setup the search filter

            //searchRoot.Username = "tsradmin@tsr.ifi.local";
            //searchRoot.Password = "Demo123";           
 
            DirectorySearcher search = new DirectorySearcher(searchRoot);
            search.Filter = "(&(objectClass=user)(objectCategory=person))";             

            //setup the properties to load for search
            search.PropertiesToLoad.Add(ADUser_LoginName);
            search.PropertiesToLoad.Add(ADUser_FirstName);
            search.PropertiesToLoad.Add(ADUser_MiddleInitials);
            search.PropertiesToLoad.Add(ADUser_LastName);
            search.PropertiesToLoad.Add(ADUser_UserAccountControl);
            search.PropertiesToLoad.Add(ADUser_Email);
            search.PropertiesToLoad.Add(ADUser_Company);
            search.PropertiesToLoad.Add(ADUser_MemberOf);
            search.PropertiesToLoad.Add(ADUser_Department);
            //added by tsrdev2
            //get ID of user's primary group
            search.PropertiesToLoad.Add(ADUser_PrimaryGroupID);
            search.PropertiesToLoad.Add(ADUser_ObjectSid);

            SearchResultCollection result;
            result = search.FindAll();
            List<DirectoryEntry> userList = new List<DirectoryEntry>();
            foreach (SearchResult sr in result)
            {
                userList.Add(sr.GetDirectoryEntry());
            }
            return userList;
        }

        //public static List<DirectoryEntry> GetAllUsers()
        //{
        //    DirectoryEntry root = GetDirectoryEntry();
        //    List<DirectoryEntry> userList = new List<DirectoryEntry>();
        //    DirectorySearcher deSearch = new DirectorySearcher();

        //    deSearch.SearchRoot = root;
        //    deSearch.Filter = "(&(objectCategory=person)(objectClass=user))";
        //    deSearch.PropertiesToLoad.Add("cn");
        //    SearchResultCollection results = deSearch.FindAll();

        //    foreach (SearchResult sr in results)
        //    {
        //        userList.Add(sr.GetDirectoryEntry());
        //    }

        //    return userList;
        //}

        /// <summary>
        /// Getting a property value of an active directory entry
        /// </summary>
        /// <param name="entry"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static String GetPropertiesValue(DirectoryEntry entry, String propertyName)
        {
            if (entry.Properties.Contains(propertyName))
            {
                return entry.Properties[propertyName][0].ToString();
            }
            else
            {
                return String.Empty;
            }

        }
        // added by tsrdev2
        /// <summary>
        /// Getting the list members of MemberOf property value of an active directory entry       
        /// </summary>
        /// <param name="entry"></param>
        /// <returns></returns>
        public static String GetMemberOfsPropertyValue(DirectoryEntry entry)
        {
            String result = string.Empty;
            if (entry.Properties.Contains(ADUser_MemberOf)) 
            {
                for (int i = 0; i < entry.Properties[ADUser_MemberOf].Count; i++)
                {
                    result += entry.Properties[ADUser_MemberOf][i].ToString();
                    result += ",";                    
                }                
            }
            return result;
        }

        //private String FindName(String userAccount)
        //{
        //    DirectoryEntry entry = GetDirectoryEntry();
        //    String account = userAccount.Replace(@"Periscope\", "");

        //    try
        //    {
        //        DirectorySearcher search = new DirectorySearcher(entry);
        //        search.Filter = "(SAMAccountName=" + account + ")";
        //        search.PropertiesToLoad.Add("displayName");

        //        SearchResult result = search.FindOne();

        //        if (result != null)
        //        {
        //            return result.Properties["displayname"][0].ToString();
        //        }
        //        else
        //        {
        //            return "Unknown User";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        string debug = ex.Message;

        //        return "";
        //    }
        //}

        /// <summary>
        /// Getting active directory objectSid of an active directory entry
        /// </summary>
        /// <param name="obDirEntry"></param>
        /// <returns></returns>
        public static string GetSid(DirectoryEntry obDirEntry)
        {
            string str = string.Empty;
            try
            {
                Int64 iBigVal = 5;
                Byte[] bigArr = BitConverter.GetBytes(iBigVal);
                System.DirectoryServices.PropertyCollection
                                   coll = obDirEntry.Properties;
                object obVal = coll["objectSid"].Value;
                if (null != obVal)
                {
                    str = ConvertByteToStringSid((Byte[])obVal);
                }

            }
            catch (Exception ex)
            {
                str = string.Empty;
            }
            return str;
        }

        /// <summary>
        /// Converting byte array objectSid to String object Sid
        /// </summary>
        /// <param name="sidBytes"></param>
        /// <returns></returns>
        private static string ConvertByteToStringSid(Byte[] sidBytes)
        {
            StringBuilder strSid = new StringBuilder();
            strSid.Append("S-");
            try
            {
                // Add SID revision.

                strSid.Append(sidBytes[0].ToString());
                // Next six bytes are SID authority value.

                if (sidBytes[6] != 0 || sidBytes[5] != 0)
                {
                    string strAuth = String.Format
                        ("0x{0:2x}{1:2x}{2:2x}{3:2x}{4:2x}{5:2x}",
                        (Int16)sidBytes[1],
                        (Int16)sidBytes[2],
                        (Int16)sidBytes[3],
                        (Int16)sidBytes[4],
                        (Int16)sidBytes[5],
                        (Int16)sidBytes[6]);
                    strSid.Append("-");
                    strSid.Append(strAuth);
                }
                else
                {
                    Int64 iVal = (Int32)(sidBytes[1]) +
                        (Int32)(sidBytes[2] << 8) +
                        (Int32)(sidBytes[3] << 16) +
                        (Int32)(sidBytes[4] << 24);
                    strSid.Append("-");
                    strSid.Append(iVal.ToString());
                }

                // Get sub authority count...

                int iSubCount = Convert.ToInt32(sidBytes[7]);
                int idxAuth = 0;
                for (int i = 0; i < iSubCount; i++)
                {
                    idxAuth = 8 + i * 4;
                    UInt32 iSubAuth = BitConverter.ToUInt32(sidBytes, idxAuth);
                    strSid.Append("-");
                    strSid.Append(iSubAuth.ToString());
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
            return strSid.ToString();
        }
        /// <summary>
        /// Getting Windows Indentity of a System.HttpContext.Current
        /// </summary>
        /// <returns></returns>
        public static WindowsIdentity GetWindowsIdentity()
        {
            IServiceProvider service = (IServiceProvider)HttpContext.Current;
            HttpWorkerRequest request = null;
            if (service != null)
            {
                request = (HttpWorkerRequest)service.GetService(typeof(HttpWorkerRequest));
            }
            IntPtr userToken = IntPtr.Zero;
            if (request != null)
            {
                userToken = new IntPtr(int.Parse(request.GetUserToken().ToString()));
            }
            WindowsIdentity identity = null;
            if (userToken != IntPtr.Zero)
            {
                identity = new WindowsIdentity(userToken,
                    "Kerberos", WindowsAccountType.Normal, true);
                //identity = new WindowsIdentity(userToken,
                //    "WindowsAuthentication", WindowsAccountType.Normal, true);            
            }

            return identity;
        }

        // added by tsrdev2
        /// <summary>
        /// Gets the user's primary group
        /// using two values primaryGroupID and objectSId of the DirectoryEntry
        /// convert byte and return the objectSID value
        /// search Primary Group via objectSID value
        /// </summary>
        /// <param name="aEntry">the entry need to get primary group</param>
        /// <param name="aDomainEntry">Domain entry</param>
        /// <returns></returns>
        public static String GetPrimaryGroupName(DirectoryEntry aEntry, DirectoryEntry aDomainEntry)
        {
            String primaryGroups = string.Empty;
            int primaryGroupID = (int)aEntry.Properties[ADUser_PrimaryGroupID].Value;
            byte[] objectSid = (byte[])aEntry.Properties[ADUser_ObjectSid].Value;

            StringBuilder escapedGroupSid = new StringBuilder();

            // Copy over everything but the last four bytes(sub-authority)
            // Doing so gives us the RID of the domain
            for (uint i = 0; i < objectSid.Length - 4; i++)
            {
                escapedGroupSid.AppendFormat("\\{0:x2}", objectSid[i]);
            }

            //Add the primaryGroupID to the escape string to build the SID of the primaryGroup
            for (uint i = 0; i < 4; i++)
            {
                escapedGroupSid.AppendFormat("\\{0:x2}", (primaryGroupID & 0xFF));
                primaryGroupID >>= 8;
            }

            //Search the directory for a group with this SID
            DirectorySearcher searcher = new DirectorySearcher();
            if (aDomainEntry == null)
            {
                aDomainEntry = new DirectoryEntry(string.Empty);                
            }
            searcher.SearchRoot = aDomainEntry;
            searcher.Filter = "(&(objectCategory=Group)(objectSID=" + escapedGroupSid.ToString() + "))";
            searcher.PropertiesToLoad.Add(ADUser_PrimaryGroupName);

            SearchResult sr = searcher.FindOne();            
            if (sr.Properties.Contains(ADUser_PrimaryGroupName))
            {
                for (int i = 0; i < sr.Properties[ADUser_PrimaryGroupName].Count; i++)
                {
                    primaryGroups += sr.Properties[ADUser_PrimaryGroupName][i].ToString();
                    primaryGroups += ",";
                }
            }
            return primaryGroups;
        }            
    }
}
