﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework.Exceptions
{
    /// <summary>
    /// Class name: DataIntegrityFailedException, extended class DALException
    /// Description: This class performs as a Custom Data Integrity failed Exception 
    /// for managing data integrity when insert, update or delete to database
    /// </summary>
    public class DataIntegrityFailedException : DALException
    {
        public DataIntegrityFailedException() : base() { }
        public DataIntegrityFailedException(BaseBusinessEntity obj, Exception ex) : base(ex) { }
        public DataIntegrityFailedException(object type, object id, Exception ex) : base(ex) { }
    }
}
