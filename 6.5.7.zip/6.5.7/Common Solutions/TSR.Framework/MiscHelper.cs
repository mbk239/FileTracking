using System;
using System.Text;
using System.Data.SqlTypes;
using System.Collections.Specialized;
using System.Configuration;
using System.Text.RegularExpressions;

namespace TSR.Framework
{
    /// <summary>
    /// DataTypeHelper
    /// this is a utility class that helps in convertion of one type of object to another 
    /// </summary>
    public class DataTypeHelper
    {
        /// <summary>
        /// method GetDateTimeValue
        /// return a date time value equivalent to the parameter object
        /// on filure it returns the DateTime.MinValue
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static DateTime GetDateTimeValue(object value)
        {
            try
            {
                DateTime dtValue = Convert.ToDateTime(value);
                int year = dtValue.Year;
                //min year of .netframework: 01/01/0001
                //using value of min yeart in web.config
                if (year == 1)
                {
                    int minYear;
                    if (Int32.TryParse(ConfigurationManager.AppSettings["MinYear"].ToString(), out minYear))
                        if (minYear > year)
                        {
                            dtValue = dtValue.AddYears(minYear - year);
                        }
                }
                //max year of .netframework: 12/30/9999
                //using value of max yeart in web.config
                if (year == 9999)
                {
                    int maxYear;
                    if (Int32.TryParse(ConfigurationManager.AppSettings["MaxYear"].ToString(), out maxYear))
                        if (maxYear < year)
                        {
                            dtValue = dtValue.AddYears(maxYear - year);
                        }
                }                

                return dtValue;
                
            }
            catch
            {
                int minYear;
                if (Int32.TryParse(ConfigurationManager.AppSettings["MinYear"].ToString(), out minYear))
                    return DateTime.MinValue.AddYears(minYear - 1);
                return DateTime.MinValue;
            }
        }

        /// <summary>
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public static DateTime GetMinDate()
        {
            int minYear;
            if (Int32.TryParse(ConfigurationManager.AppSettings["MinYear"].ToString(), out minYear))
                return DateTime.MinValue.AddYears(minYear - 1);
            return DateTime.MinValue;
        }

        /// <summary>
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public static DateTime GetMaxDate()
        {
            int maxYear;
            if (Int32.TryParse(ConfigurationManager.AppSettings["MaxYear"].ToString(), out maxYear))
                return DateTime.MinValue.AddYears(maxYear - 1);
            return DateTime.MaxValue;
        }

        /// <summary>
        /// Mehtod GetBooleanValue
        /// returns the boolean value equivalent to the parameter object
        /// on failure returns false
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool GetBooleanValue(object value)
        {
            try
            {
                return Convert.ToBoolean(value);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// method GetShortValue
        /// returns an Int16 value equivalent to the parameter object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static short GetShortValue(object value)
        {
            try
            {
                return Convert.ToInt16(value);
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// method GetLongValue
        /// returns an Int64 value equivalent to parameter object
        /// returns -1 on failure
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Int64 GetLongValue(object value)
        {
            try
            {
                return Convert.ToInt64(value);
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// method GetDoubleValue
        /// returns a Double value equivalent to parameter object
        /// returns 0.0 on failure
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Double GetDoubleValue(object value)
        {
            try
            {
                return Convert.ToDouble(value);
            }
            catch
            {
                return 0.0;
            }
        }

        /// <summary>
        /// method GetNameValueCollection
        /// returns a NameValueCollection equivalent to parameter object
        /// returns null on failure to cast
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static NameValueCollection GetNameValueCollection(object value)
        {
            try
            {
                return (NameValueCollection)value;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// method : GetStringValue
        /// returns a string equivalent to the parameter object
        /// returns null on failure
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetStringValue(object value)
        {
            try
            {
                return Convert.ToString(value);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// method GetGuidValue
        /// returns a Guid extracted from the parameter object
        /// returns Guid.Empty on failure
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static Guid GetGuidValue(object value)
        {
            try
            {
                if (!String.IsNullOrEmpty(value.ToString()))
                {
                    return SqlGuid.Parse(value.ToString()).Value;
                }
                else
                    return Guid.Empty;
            }
            catch
            {
                return Guid.Empty;
            }
        }

        public static string ConvertToString(DateTime dateTime)
        {
            return dateTime.ToString(ConstantCollection.FORMAT_DATETIME_STRING);
        }

    }

    /// <summary>
    /// Enumeration helper class
    /// </summary>
    public class EnumHelper
    {
        //public static ListItemCollection EnumToList<T>()
        //{
        //    ListItemCollection lists = new ListItemCollection();
        //    foreach (string item in Enum.GetNames(typeof(T)))
        //    {
        //        int value = (int)Enum.Parse(typeof(T), item);
        //        item.Replace('_', ' ');
        //        ListItem listItem = new ListItem(item, value.ToString());

        //        lists.Add(listItem);
        //    }
        //    return lists;
        //}

        //public static string EnumToString<T>(int value)
        //{
        //    ListItemCollection lists = EnumToList<T>();
        //    return lists.FindByValue(value.ToString()).Text;
        //}

        //public static string EnumToString<T>(T value)
        //{
        //    ListItemCollection lists = EnumToList<T>();
        //    return lists.FindByValue(value.ToString()).Text;
        //}
    }

    /// <summary>
    /// Collection of regular expressions
    /// </summary>
    public class RegExpHelper
    {
        public static readonly string Url = "[a-zA-Z0-9-_\\$]+(\\.[a-zA-Z0-9-_\\$]+)?\\??[a-zA-Z0-9-_\\$]+=?[a-zA-Z0-9-_\\$]+(&[a-zA-Z0-9-_\\$]+=[a-zA-Z0-9-_\\$]+)*";
        public static readonly string Date = "(0[1-9]|[12][0-9]|3[01])[-](0[1-9]|1[012])[-]((175[7-9])|(17[6-9][0-9])|(1[8-9][0-9][0-9])|([2-9][0-9][0-9][0-9]))"; // supports dates from 1-1-1757 to 31-12-9999 for SQL Server 2000 Date Range 
        public static readonly string Time = "(0[1-9]|[1][0-2])[:](0[0-9]|[1-5][0-9])[:](0[0-9]|[1-5][0-9])[ ][A|a|P|p][M|m]";
        public static readonly string Number = "[-+]?[0-9]*\\.?[0-9]*";
        public static readonly string Digit = "[0-9]*";
        public static readonly string DurationTime = "[0-9]{0-7}";
        public static readonly string DigitRanged = "\\d";
        public static readonly string NonNegative = "[+]?[0-9]*\\.?[0-9]*";
        public static readonly string Email = @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,8}$"; //"^\\w+[\\w-\\.]*\\@\\w+((-\\w+)|(\\w*))\\.[a-z]{2,3}$";
        public static readonly string Website = @"^(((h|H?)(t|T?)(t|T?)(p|P?)(s|S?))\://)?(w{3}\.)?[a-zA-Z0-9\-]+\.([a-zA-Z]+\.)*[a-zA-Z/]+$";
        public static readonly string Phone = @"^([\+0-9\(][+]{0,1}[0-9\s]*[0-9\)][0-9\s\-]*)";

        public static readonly string PasswordValidation = @"^(?=.{6,50}$).*";
        //public static readonly string UserNameValidation = @"^[a-zA-Z]{1}[a-zA-Z0-9]{5,19}$";
        public static readonly string UserNameValidation = @"^[a-zA-Z0-9.]{2,20}$";
        public static string StringRange(int min, int max)
        {
            return "[\\s\\S]{" + min.ToString() + "," + max.ToString() + "}";
        }

        public static bool IsRegexPatternValid(String value, String pattern, bool ignoreEmpty)
        {
            if (ignoreEmpty && string.IsNullOrEmpty(value))
                return true;
            else if (string.IsNullOrEmpty(value))
                return false;
            try
            {
                Regex rgx = new Regex(pattern);
                return rgx.IsMatch(value);
            }
            catch { }
            return false;
        }

        public static bool IsUserNameValid(String username)
        {
            return IsRegexPatternValid(username, UserNameValidation, false);
        }

        public static bool IsPasswordValid(String password)
        {
            return IsRegexPatternValid(password, PasswordValidation, false);
        }

        public static bool IsEmailValid(String email)
        {
            return IsRegexPatternValid(email, Email, true);
        }
    }
}
