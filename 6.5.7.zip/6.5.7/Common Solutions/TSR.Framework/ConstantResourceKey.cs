using System;
using TSR.Framework.Resource;


namespace TSR.Framework
{
    /// <summary>
    /// Class ConstantResourceKey
    /// holds all language resource keys  
    /// </summary>
    public partial class ConstantResourceKey
    {
        /**Begin Version 6.2.1 Step 2 **/
        public const string ImprortUser_LocationInvalid = "ImprortUser_LocationInvalid"; //Location does not exist. Import failed.

        public static string btnBackMatrixView
        {
            get
            {
                return ResourceManager.GetResourceString("btnBackMatrixView", "Back to Matrix View");
            }
        }

        public static string MatrixConfirmCopyMessage
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmCopyMessage", "You are about to copy all appointmanets in the scope {0} {1} to and including {2} {3}\r\n to the scope {4} {5} to and including {6} {7}.\r\n Are you sure that you want to copy?");
            }
        }

        public static string MatrixConfirmSubmitUnsubmited
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmSubmitUnsubmited", "Are you sure that you want to submit?");
            }
        }

        public static string MatrixConfirmCopyMessageSucess
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmCopyMessageSucess", "Copied");
            }
        }
        public static string MatrixConfirmSubmitUnsubmitedSuccess
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmSubmitUnsubmitedSuccess", "Submitted");
            }
        }
        public static string MatrixConfirmCopyMessageError
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmCopyMessageError", "Copy failed");
            }
        }
        public static string MatrixConfirmSubmitUnsubmitedError
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixConfirmSubmitUnsubmitedError", "Submission failed");
            }
        }
        public static string StartDate
        {
            get
            {
                return ResourceManager.GetResourceString("StartDate", "Start Date");
            }
        }
        public static string EndDate
        {
            get
            {
                return ResourceManager.GetResourceString("EndDate", "End Date");
            }
        }

        public static string Previous7Days
        {
            get
            {
                return ResourceManager.GetResourceString("Previous7Days", "Previous 7 Days");
            }
        }

        public static string Next7Days
        {
            get
            {
                return ResourceManager.GetResourceString("Next7Days", "Next 7 Days");
            }
        }

        public static string OK
        {
            get
            {
                return ResourceManager.GetResourceString("OK", "OK");
            }
        }

        public static string Cancel
        {
            get
            {
                return ResourceManager.GetResourceString("Cancel", "Cancel");
            }
        }

        public static string WaitLoading
        {
            get
            {
                return ResourceManager.GetResourceString("WaitLoading", "Loading, please wait......");
            }
        }
        public static string btnSubmitUnSubmitedEntries
        {
            get
            {
                return ResourceManager.GetResourceString("btnSubmitUnSubmitedEntries", "Submit unsubmited entries");
            }
        }
        public static string btnCopySelected
        {
            get
            {
                return ResourceManager.GetResourceString("btnCopySelected", "Copy selected");
            }
        }
        public static string btnSubmitPeriod
        {
            get
            {
                return ResourceManager.GetResourceString("SubmitPeriod", "Submit period");
            }
        }

        public static string btnSubmitAndLockSelectedDays
        {
            get
            {
                return ResourceManager.GetResourceString("SubmitAndLockSelectedDays", "Submit and lock selected days");
            }
        }
        public static string btnSubmitSelectedDays
        {
            get
            {
                return ResourceManager.GetResourceString("SubmitSelectedDays", "Submit selected days");
            }
        }
        public static string Copy
        {
            get
            {
                return ResourceManager.GetResourceString("Copy", "Copy");
            }
        }
        public static string WeeksFromCurrent
        {
            get
            {
                return ResourceManager.GetResourceString("WeeksFromCurrent", "week(s) from current");
            }
        }

        public static string lblTotalDurationSelectedText
        {
            get
            {
                return ResourceManager.GetResourceString("lblTotalDurationSelectedText", "Total duration of selected entries");
            }
        }
        public static string lblTotalDurationText
        {
            get
            {
                return ResourceManager.GetResourceString("lblTotalDurationText", "Total duration of list entries");
            }
        }
        public static string Favorites
        {
            get
            {
                return ResourceManager.GetResourceString("Favorites", "Favorites");
            }
        }
        public static string SelectAFavotite
        {
            get
            {
                return ResourceManager.GetResourceString("SelectAFavotite", "Select a Favorite");
            }
        }

        public static string Duration
        {
            get
            {
                return ResourceManager.GetResourceString("Duration", "Duration");
            }
        }
        public static string Search
        {
            get
            {
                return ResourceManager.GetResourceString("Search", "Search");
            }
        }

        public static string Keyword
        {
            get
            {
                return ResourceManager.GetResourceString("Keyword", "Search term");
            }
        }
        public static string ShowInactivateLocation
        {
            get
            {
                return ResourceManager.GetResourceString("ShowInactivateLocation", "Show inactive locations");
            }
        }
        public static string ForeignKey
        {
            get
            {
                return ResourceManager.GetResourceString("ForeignKey", "Foreign Key");
            }
        }
        public static string LocationName
        {
            get
            {
                return ResourceManager.GetResourceString("LocationName", "Location Name");
            }
        }

        public static string PleaseEnterLocationName
        {
            get
            {
                return ResourceManager.GetResourceString("PleaseEnterLocationName", "Please enter Name of Location");
            }
        }

        public static string LocationSavedSucessMessage
        {
            get
            {
                return ResourceManager.GetResourceString("LocationSavedSucessMessage", "Location has been saved successfully.");
            }
        }
        public static string LocationSaveFailedMessage
        {
            get
            {
                return ResourceManager.GetResourceString("LocationSaveFailedMessage", "Location update failed");
            }
        }
        public static string LocationDeletedSucessMessage
        {
            get
            {
                return ResourceManager.GetResourceString("LocationDeletedSucessMessage", "Location has been deleted successfully.");
            }
        }
        public static string LocationDeleteFailedMessage
        {
            get
            {
                return ResourceManager.GetResourceString("LocationDeleteFailedMessage", "Location delete failed");
            }
        }
        public static string TSRLocation
        {
            get
            {
                return ResourceManager.GetResourceString("TSRLocation", "Location");
            }
        }
        public static string CommonUpdateFailureMessage
        {
            get
            {
                return ResourceManager.GetResourceString("CommonUpdateFailureMessage", "has not been updated");
            }
        }
        public static string SelectALocation
        {
            get
            {
                return ResourceManager.GetResourceString("SelectALocation", "Select a Location");
            }
        }

        public static string DoNotSynTECreatedViaWeb
        {
            get
            {
                return ResourceManager.GetResourceString("DoNotSynTECreatedViaWeb", "Do not synchronize entries created via web interface");
            }
        }
        public static string OutOfOffice
        {
            get
            {
                return ResourceManager.GetResourceString("OutOfOffice", "Out of Office");
            }
        }
        public static string ShowOnlyFavoritesText
        {
            get
            {
                return ResourceManager.GetResourceString("ShowOnlyFavoritesText", "Show only favorites in dropdowns");
            }
        }

        public static string ListTimeEntriesOUA
        {
            get
            {
                return ResourceManager.GetResourceString("ListTimeEntriesOUA", "List time entries � Outlook User Agent");
            }
        }

        public static string AsWebInterface
        {
            get
            {
                return ResourceManager.GetResourceString("AsWebInterface", "As web interface");
            }
        }
        public static string CurrentWeek
        {
            get
            {
                return ResourceManager.GetResourceString("CurrentWeek", "Current week");
            }
        }
        public static string CurrentMonth
        {
            get
            {
                return ResourceManager.GetResourceString("CurrentMonth", "Current month");
            }
        }
        public static string PreviousWeek
        {
            get
            {
                return ResourceManager.GetResourceString("PreviousWeek", "Previous week");
            }
        }
        public static string PreviousMonth
        {
            get
            {
                return ResourceManager.GetResourceString("PreviousMonth", "Previous month");
            }
        }

        #region User detail type
		
        public static string UserDetailType
        {
            get {
                return ResourceManager.GetResourceString("UserDetailType", "User detail type");
            }
        }
        public static string UserDetailFormat
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailFormat", "Format");
            }
        }
        public static string UserDetailAddnew
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailAddnew", "Add user detail type");
            }
        }
        public static string UserDetailHeaderMessage
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailHeaderMessage", "Select the detail type you want to edit");
            }
        }
        public static string UserDetailShowInactive
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailShowInactive", "Show inactive detail types");
            }
        }
        public static string UserDetailTypes
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailTypes", "User detail types");
            }
        }
        public static string UserDetailTypeTemplate
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailTypeTemplate", "User detail type template");
            }
        }
        public static string Text
        {
            get
            {
                return ResourceManager.GetResourceString("Text", "Text");
            }
        }
        public static string Date
        {
            get
            {
                return ResourceManager.GetResourceString("Date", "Date");
            }
        }
        public static string Description
        {
            get
            {
                return ResourceManager.GetResourceString("Description", "Description");
            }
        }
        public static string Activate
        {
            get
            {
                return ResourceManager.GetResourceString("Activate", "Activate");
            }
        }
        public static string Inactivate
        {
            get
            {
                return ResourceManager.GetResourceString("Inactivate", "Inactivate");
            }
        }
        public static string Active
        {
            get
            {
                return ResourceManager.GetResourceString("Active", "Active");
            }
        }
        public static string InActive
        {
            get
            {
                return ResourceManager.GetResourceString("InActive", "InActive");
            }
        }
        public static string UserDetailStatusInactive
        {
            get
            {
                return ResourceManager.GetResourceString("UserInactive", "UserInactive");
            }
        }
        public static string UserDetail_ConfirmActivate
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetail_ConfirmActivate", "Are you sure that you wish to activate this user detail type");
            }
        }
        public static string UserDetail_ConfirmInActivate
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetail_ConfirmInActivate", "Are you sure that you wish to inactivate this user detail type");
            }
        }
        public static string UserDetailTypeUpdated
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailTypeUpdated", "User detail type update successful");
            }
        }
        public static string UserDetailTypeNotUpdated
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailTypeNotUpdated", "User detail type update failed");
            }
        }
        public static string UserDetailTypeUpdateError
        {
            get
            {
                return ResourceManager.GetResourceString("UserDetailTypeUpdateError", "Error updating user detail type");
            }
        }
        
        #endregion

        public static string Activity_ConfirmActivate
        {
            get
            {
                return ResourceManager.GetResourceString("Activity_ConfirmActivate", "Are you sure that you want to activate this activity ?");
            }
        }
        public static string Activity_ConfirmInActivate
        {
            get
            {
                return ResourceManager.GetResourceString("Activity_ConfirmInActivate", "Are you sure that you want to inactivate this activity ?");
            }
        }

        public static string ShowInactiveActivities
        {
            get
            {
                return ResourceManager.GetResourceString("ShowInactiveActivities", "Show inactive activities");
            }
        }
        public static string Account
        {
            get
            {
                return ResourceManager.GetResourceString("Account", "Account");
            }
        }
        public static string ButtonConfirm_TSRInfOnRecurringAppointment_Message_Feature306
        {
            get
            {
                return ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message_Feature306", "Are you sure you want to enter TSR information on a recurring appointment? If you do, all instances of the appointment up to 12 months in the past up to 12 months from now will be split into separate individual appointments and the recurring function from Outlook will be removed from the appointment.");
            }
        }
		/**End Version 6.2.1 Step 2 **/

        public static string ListView
        {
            get 
            {
                return ResourceManager.GetResourceString("ListView", "List View");
            }
        }

        public static string MatrixView
        {
            get
            {
                return ResourceManager.GetResourceString("MatrixView", "Matrix View");
            }
        }

        /* Version 6.5.4 */
        public static string WeekStartsOn
        {
            get
            {
                return ResourceManager.GetResourceString("WeekStartsOn", "Week starts on");
            }
        }

        public static string Monday
        {
            get
            {
                return ResourceManager.GetResourceString("Monday", "Monday");
            }
        }

        public static string Tuesday
        {
            get
            {
                return ResourceManager.GetResourceString("Tuesday", "Tuesday");
            }
        }

        public static string Wednesday
        {
            get
            {
                return ResourceManager.GetResourceString("Wednesday", "Wednesday");
            }
        }

        public static string Thursday
        {
            get
            {
                return ResourceManager.GetResourceString("Thursday", "Thursday");
            }
        }

        public static string Friday
        {
            get
            {
                return ResourceManager.GetResourceString("Friday", "Friday");
            }
        }

        public static string Saturday
        {
            get
            {
                return ResourceManager.GetResourceString("Saturday", "Saturday");
            }
        }

        public static string Sunday
        {
            get
            {
                return ResourceManager.GetResourceString("Sunday", "Sunday");
            }
        }

        public static string Managers
        {
            get
            {
                return ResourceManager.GetResourceString("Managers", "Managers");
            }
        }

        public static string SpecifiedUserGroup
        {
            get
            {
                return ResourceManager.GetResourceString("SpecifiedUserGroup", "Specified user group");
            }
        }
        /**End Version 6.5.4 **/

        #region Lock Period

        public static string SubmitPeriodDate
        {
            get
            {
                return ResourceManager.GetResourceString("Date", "Date");
            }
        }
        public static string SubmitPeriodTotalNonSumitted
        {
            get
            {
                return ResourceManager.GetResourceString("UnSubmitted", "UnSub");
            }
        }
        public static string SubmitPeriodTotalSubmitted
        {
            get
            {
                return ResourceManager.GetResourceString("Submitted", "Sub");
            }
        }
        public static string Total
        {
            get
            {
                return ResourceManager.GetResourceString("Total", "Total");
            }
        }

        public static string UserGroup
        {
            get { return ResourceManager.GetResourceString("UserGroup", "User Group"); }
        }

        public static string SelectUserGroup
        {
            get { return ResourceManager.GetResourceString("SelectUserGroup", "Select an User Group"); }
        }

        public static string UserGroupIsMandatory
        {
            get { return ResourceManager.GetResourceString("UserGroupIsMandatory", UserGroup + " is mandatory"); }
        }
        public static string StartDateIsMandatory
        {
            get { return ResourceManager.GetResourceString("StartDateIsMandatory", StartDate + " is mandatory"); }
        }
        public static string EndDateIsMandatory
        {
            get { return ResourceManager.GetResourceString("EndDateIsMandatory", EndDate + " is mandatory"); }
        }

        public static string StartDateMustBeLessThanEndDate
        {
            get { return ResourceManager.GetResourceString("StartDateMustBeLessThanEndDate", "Start date must be less than end date"); }
        }

        public static string User
        {
            get { return ResourceManager.GetResourceString("User", "User"); }
        }
        public static string Status
        {
            get { return ResourceManager.GetResourceString("Status", "Status"); }
        }
        public static string LockStatus
        {
            get { return ResourceManager.GetResourceString("Lock Status", "Lock Status"); }
        }
        public static string InProgress
        {
            get { return ResourceManager.GetResourceString("InProgress", "InProgress"); }
        }
        public static string ApprovedHours
        {
            get { return ResourceManager.GetResourceString("ApprovedHours", "Approved Hours"); }
        }
        public static string UnSubmittedHours
        {
            get { return ResourceManager.GetResourceString("UnSubmittedHours", "UnSubmitted Hours"); }
        }
        public static string TotalHours
        {
            get { return ResourceManager.GetResourceString("TotalHours", "Total Hours"); }
        }
        public static string Actiony
        {
            get { return ResourceManager.GetResourceString("Actiony", "Actiony"); }
        }

        public static string Lock
        {
            get { return ResourceManager.GetResourceString("Lock", "Lock"); }
        }
        public static string Unlock
        {
            get { return ResourceManager.GetResourceString("Unlock", "Unlock"); }
        }

        public static string ConfirmLockPeriod
        {
            get { return ResourceManager.GetResourceString("ConfirmLockPeriod", "Do you want to lock?"); }
        }
        public static string ConfirmUnlockPeriod
        {
            get { return ResourceManager.GetResourceString("ConfirmUnlockPeriod", "Do you want to unlock?"); }
        }
        public static string LockAndUnlockConfirmLockError
        {
            get
            {
                return ResourceManager.GetResourceString("LockAndUnlockConfirmLockError", "Lock failed.");
            }
        }
        public static string LockAndUnlockConfirmUnlockError
        {
            get
            {
                return ResourceManager.GetResourceString("LockAndUnlockConfirmUnlockError", "Unlock failed.");
            }
        }
        public static string LockAndUnlockConfirmLockSuccess
        {
            get
            {
                return ResourceManager.GetResourceString("LockAndUnlockConfirmLockSuccess", "Locked successfully.");
            }
        }
        public static string LockAndUnlockConfirmUnlockSuccess
        {
            get
            {
                return ResourceManager.GetResourceString("LockAndUnlockConfirmUnlockSuccess", "Unlocked successfully.");
            }
        }

        public static string LockAndUnLockTitle
        {
            get
            {
                string sTitle = "You are about to submit all time entries for the following dates. </br>";
                sTitle += "If there are dates that you do NOT want to submit,</br> please remove checkmark.";
                return ResourceManager.GetResourceString("LockAndUnLockTitle", sTitle);
            }
        }

        public static string Locked
        {
            get
            {
                return ResourceManager.GetResourceString("Locked", "Locked");
            }
        }
        public static string Unlocked
        {
            get
            {
                return ResourceManager.GetResourceString("Unlocked", "Unlocked");
            }
        }
        public static string Partlylocked
        {
            get
            {
                return ResourceManager.GetResourceString("Partlylocked", "Partly locked");
            }
        }

        public static string YouHaveNotSelectedColumnSubject
        {
            get
            {
                return ResourceManager.GetResourceString("YouHaveNotSelectedColumnSubject", "You have not selected column Subject");
            }
        }
        #endregion

        #region Approve Summary

        public static string ApprovalSummaryShowOnlyLocked
        {
            get
            {
                return ResourceManager.GetResourceString("ApprovalSummaryShowOnlyLocked", "Show only locked");
            }
        }
        public static string ApproveSummaryShowZeroHours
        {
            get
            {
                return ResourceManager.GetResourceString("ApproveSummaryShowZeroHours", "Show zero hours");
            }
        }
        #endregion

        public static string LockedPeriodMessage
        {
            get
            {
                return ResourceManager.GetResourceString("LockedPeriodMessage",
                    "You cannot create, edit, submit or delete time entries in lock period.");
            }
        }

        public static string SubmitMessageInMatrixView
        {
            get
            {
                return ResourceManager.GetResourceString("SubmitMessageInMatrixView", "Submit and lock completed and there are some time entries cannot submit in lock period. Please contact administrator to unlock period and submit again.");
            }
        }

        public static string CopyMessageInMatrixView
        {
            get
            {
                return ResourceManager.GetResourceString("CopyMessageInMatrixView", "Copy selected time entries completed and there are some new time entries cannot create in lock period. Please contact administrator to unlock period and copy again.");
            }
        }

        public static string DurationWarning
        {
            get
            {
                return ResourceManager.GetResourceString("DurationWarning", "Duration Warning");
            }
        }

        public static string Disable
        {
            get
            {
                return ResourceManager.GetResourceString("Deactivate", "Deactivate");
            }
        }

        public static string Enable
        {
            get
            {
                return ResourceManager.GetResourceString("Activate", "Activate");
            }
        }
    }
}
