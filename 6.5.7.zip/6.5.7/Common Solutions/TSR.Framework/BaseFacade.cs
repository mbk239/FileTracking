using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace TSR.Framework
{
    /// <summary>
    /// Class
    /// Name: BaseFacade
    /// Description: This class is a custom Facade
    /// who inherits Security.ClassSecurity,
    /// imeplements IDisposable and handles facade related properties & functions
    /// for Facade Layer
    /// </summary>
    public class BaseFacade : Security.BaseSecuredClass, IDisposable, Security.IModule
    {
        // This protected variable provides access to transaction object in the
        // derived classes if required.
        protected SqlTransaction _Transaction;

        /// <summary>
        /// the constructor for BaseFacade
        /// </summary>
        /// <param name="userContext"></param>
        public BaseFacade(UserContext userContext)
            : base(userContext)
        {
            if (!IsLicensed)
                throw new Exceptions.LicenseException();
        }

        #region IDisposable Members

        void IDisposable.Dispose()
        {
        }

        #endregion

        #region IModule Members

        /// <summary>
        /// Module Attribute of a facade
        /// </summary>
        public Security.ModuleAttribute ModuleAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(Security.ModuleAttribute));

                if (att != null)
                    return att as Security.ModuleAttribute;

                return null;
            }
        }

        /// <summary>
        /// Module keys of Module Attribute
        /// </summary>
        public StringCollection ModuleKeys
        {
            get
            {
                if (ModuleAttribute != null)
                {
                    return ModuleAttribute.ModuleKeys;
                }

                return null;
            }
        }

        /// <summary>
        /// License is requred for the module or not
        /// </summary>
        public bool LicensingRequired
        {
            get
            {
                if (ModuleAttribute != null)
                    return ModuleAttribute.LicensingRequired;

                return false;
            }
        }

        /// <summary>
        /// If the module is licensed for the organization/customer
        /// </summary>
        public bool IsLicensed
        {
            get
            {
                if (LicensingRequired)
                {
                    foreach (string moduleKey in ModuleKeys)
                    {
                        if (Security.ModuleManager.IsModuleLicensed(moduleKey))
                            return true;
                    }

                    return false;
                }

                return true;
            }
        }

        #endregion
    }
}
