using System;
using System.Collections;
using System.Text;

using System.Data.SqlClient;

namespace TSR.Framework
{
    /// <summary>
    /// UserContext class needed for User Information. User means users who are using the system by any means. Through
    /// Services or Web Admin etc. Informtation hold here is used to authenticate and authorize users.
    /// </summary>
    [Serializable]
    public class UserContext
    {
        private long _UserID;
        private string _Username;
        private string _FullName;
        private DateTime? _LastSuccessfullLogin;
        private long _FailedAttemptsSinceLastLogin;
        private AllowedPermissionList _AllowedPermissions;
        private string _CurrentSessionID;
        private bool _isInExpenseLicense;
        private bool _isRateLicense;


        public bool IsInExpenseLicense
        {
            get { return _isInExpenseLicense; }
            set { _isInExpenseLicense = value; }
        }

        public bool IsRateLicense
        {
            get
            {
                return _isRateLicense;
            }
            set { _isRateLicense = value; }
        }

        #region Properties

        public long UserID
        {
            get { return _UserID; }
        }

        public string Username
        {
            get { return _Username; }
        }

        public string FullName
        {
            get { return _FullName; }
        }

        /// <summary>
        /// Allowed permissions a user has
        /// </summary>
        public AllowedPermissionList AllowedPermissions
        {
            get { return _AllowedPermissions; }
        }

        /// <summary>
        /// Just to let the user know When was the last time he/she logged
        /// </summary>
        public DateTime? LastSuccessfullLogin
        {
            get
            {
                return _LastSuccessfullLogin;
            }
        }

        /// <summary>
        /// Failed attempt information
        /// </summary>
        public long FailedAttemptsSinceLastLogin
        {
            get
            {
                return _FailedAttemptsSinceLastLogin;
            }
        }

        /// <summary>
        /// Current Session ID cannot be set, readonly
        /// </summary>
        public string CurrentSessionID
        {
            get { return _CurrentSessionID; }
            //set { _CurrentSessionID = value; }
        }

        #endregion
        

        #region Constructors

        public UserContext(long userID, string username, string fullName)
        {
            _UserID = userID;
            _Username = username;
            _FullName = fullName;
        }

        public UserContext(long userID, string username, string fullName, AllowedPermissionList allowedPermission)
            : this(userID, username, fullName)
        {
            _AllowedPermissions = allowedPermission;
        }

        public UserContext(long userID, string username, string fullName, AllowedPermissionList allowedPermission, string sessionID)
            : this(userID, username, fullName, allowedPermission)
        {
            _CurrentSessionID = sessionID;
        }

        public UserContext(long userID, string username, string fullName,
            AllowedPermissionList allowedPermission, string sessionID,
            DateTime? lastSuccessfullLogin, long unsuccessfullAttempts)
            : this(userID, username, fullName, allowedPermission, sessionID)
        {
            _LastSuccessfullLogin = lastSuccessfullLogin;
            _FailedAttemptsSinceLastLogin = unsuccessfullAttempts;
        }

        #endregion
        

        /// <summary>
        /// Whether the user has permission for specific secured item which requires permission
        /// </summary>
        /// <param name="permissionKey"></param>
        /// <returns></returns>
        public bool HasPermission(string permissionKey)
        {
            if (AllowedPermissions != null)
            {
                return AllowedPermissions.ContainsKey(permissionKey);
            }

            return true;
        }
    }

    public class AllowedPermissionList : Hashtable
    {
        //public BaseBusinessEntity this[string permissionKey]
        //{
        //    get
        //    {
        //        return base[permissionKey] as BaseBusinessEntity;
        //    }
        //}
    }
}
