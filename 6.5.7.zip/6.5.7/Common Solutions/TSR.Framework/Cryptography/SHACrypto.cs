using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace TSR.Framework.Cryptography
{
    /// <summary>
    /// Class
    /// Name: SHACrypto
    /// Description: This class is a custom BaseCrypto 
    /// who handles SHA Cryptography related properties & methods
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class SHACrypto : BaseCrypto
    {
        private static HMACSHA1 _HashProvider = new HMACSHA1(HASH_KEY_BYTE);

        /// <summary>
        /// Method GetHashValue
        /// gets the hash value form HMACSHA1 hash provider
        /// </summary>
        /// <param name="value">An array of bytes</param>
        /// <returns>Returns the encrypted bytes as an array</returns>
        public static byte[] GetHashValue(byte[] value)
        {
            return _HashProvider.ComputeHash(value);
        }

        /// <summary>
        /// Method GetHashValue
        /// Converts a normal string inot a base 64 String
        /// </summary>
        /// <param name="value">A unicode sting</param>
        /// <returns>Returns a base 64 String</returns>
        public static string GetHashValue(string value)
        {
            return Convert.ToBase64String(GetHashValue(Encoding.Unicode.GetBytes(value)));
        }
    }//end class SHACrypto
}
