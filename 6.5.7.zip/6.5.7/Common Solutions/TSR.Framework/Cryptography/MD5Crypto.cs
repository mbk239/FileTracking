using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace TSR.Framework.Cryptography
{
    /// <summary>
    /// Class
    /// Name: MD5Crypto
    /// Description: This class is a custom BaseCrypto 
    /// who handles MD5 Cryptography related properties & functions
    /// </summary>
    public class MD5Crypto : BaseCrypto
    {
        Rijndael cryptoProvider = RijndaelManaged.Create();

        public string Encrypt(string value)
        {
            return value; // the logic is not yet implemented
        }

        //added by tsrdev1
        /// <summary>
        /// Encrypts the sourceString, returns this result as an Aes encrypted, BASE64 encoded string
        /// </summary>
        /// <param name="plainSourceStringToEncrypt">a plain, Framework string (ASCII, null terminated)</param>
        /// <param name="key"></param>
        /// <returns>
        /// returns an Aes encrypted, BASE64 encoded string
        /// </returns>
        public static string EncryptString(string plainSourceStringToEncrypt)
        {
            MD5CryptoServiceProvider mdcsp = new MD5CryptoServiceProvider();
            byte[] b = System.Text.Encoding.UTF8.GetBytes(plainSourceStringToEncrypt);
            b = mdcsp.ComputeHash(b);
            //Convert encoded bytes back to a 'readable' string
            return BitConverter.ToString(b);
        }      
    }
}
