using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace TSR.Framework.Cryptography
{
    /// <summary>
    /// Class
    /// Name: TripleDESCrypto
    /// Description: This class is a custom BaseCrypto 
    /// who handles TripleDES Cryptography related properties & methods
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class TripleDESCrypto : BaseCrypto
    {
		private static TripleDESCryptoServiceProvider clientDESCryptoServiceProvider;

        /// <summary>
        /// constructor
        /// initializes the TripleDESCryptoServiceProvider variable with appropriate values
        /// </summary>
        static TripleDESCrypto()
		{
			clientDESCryptoServiceProvider = new TripleDESCryptoServiceProvider();
			clientDESCryptoServiceProvider.Key = new byte[] {111, 222, 121, 82, 172, 21, 185, 52, 28, 12, 2, 12, 23, 13, 11, 1};
			clientDESCryptoServiceProvider.IV = new byte[] {12, 224, 213, 42, 32, 102, 181, 11};
		}

        /// <summary>
        /// Decrypt an Encrypted String and returns decrypted string
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="AString">(String type) Encrypt string</param>
        /// <returns>(String type) Decrypt string</returns>
		public static string Decrypt( string AString )
		{
			byte [] encryptedData;
			MemoryStream dataStream = null;
			CryptoStream encryptedStream = null;
			
			if( 0 == AString.Length )
				return string.Empty;
			// Get the byte data
			encryptedData = Convert.FromBase64String(AString);

			try
			{
				dataStream = new MemoryStream();
				try
				{
					// Create decryptor and stream
					ICryptoTransform decryptor;
					decryptor = clientDESCryptoServiceProvider.CreateDecryptor();
					encryptedStream = new CryptoStream(dataStream, decryptor, CryptoStreamMode.Write);

					// Write the decrypted data to the memory stream
					encryptedStream.Write(encryptedData, 0, encryptedData.Length-1);
					encryptedStream.FlushFinalBlock();

					// Position back at start
					dataStream.Position = 0;
					int size = (int)dataStream.Length;

					// Create area for data
					encryptedData = new byte[size];

					// Read decrypted data to byte()
					dataStream.Read(encryptedData, 0, size);

					return System.Text.ASCIIEncoding.UTF8.GetString( encryptedData, 0, size );
				}
				finally
				{
					encryptedStream.Close();
				}
			}
			finally
			{
				dataStream.Close();
			}

		
		}
		
        /// <summary>
        /// Encrypt a string and returns an encrypted string
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="AString">(String type)</param>
        /// <returns>(String type) Encrypt string</returns>
        public static string Encrypt( string AString )
		{
			if( AString == string.Empty )
			{
				return AString;
			}
			else
			{
        
				MemoryStream dataStream = new MemoryStream( );
				ICryptoTransform encryptor = clientDESCryptoServiceProvider.CreateEncryptor();

				try
				{
					//Create the encrypted stream
					CryptoStream encryptedStream = new CryptoStream(dataStream, encryptor, CryptoStreamMode.Write);
					
					try
					{
						//Write the string to memory via the encryption algorithm							
						StreamWriter theWriter = new StreamWriter(encryptedStream);
						try
						{
							//Write the string to the memory stream
							theWriter.Write(AString);

							//End the writing
							theWriter.Flush();
							encryptedStream.FlushFinalBlock();

							//Position back at start
							dataStream.Position = 0;

							//Create area for data
							byte [] encryptedData = new byte[dataStream.Length+1];

							//Read data from memory
							dataStream.Read(encryptedData, 0, (int)dataStream.Length);

							//Convert to String
							return Convert.ToBase64String(encryptedData);
						}
						finally
						{
							theWriter.Close();
						}
					}
					finally
					{
						encryptedStream.Close();
					}
				}
				finally
				{
					dataStream.Close();
				}
			}
		}
    }//end Class TripleDESCrypto
}
