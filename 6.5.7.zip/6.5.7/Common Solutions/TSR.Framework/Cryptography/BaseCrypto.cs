using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Cryptography
{
    /// <summary>
    /// Class
    /// Name: BaseCrypto
    /// Description: This class is a custom Cryptography 
    /// who handles Cryptography related common properties & methods
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class BaseCrypto
    {
        public static readonly string HASH_KEY_HEXSTRING = "27052009"; // hash key for HEXSTRING
        public static readonly byte[] HASH_KEY_BYTE = HexToByte(HASH_KEY_HEXSTRING); //get the bytes equivalent to the HEXSTRING

        /// <summary>
        /// Convert a Hexa-decimal string to any byte array
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="hexString">String type</param>
        /// <returns>any byte array</returns>
        public static byte[] HexToByte(string hexString)
        {
            //create the array of bytes to be returned 
            byte[] returnBytes = new byte[hexString.Length / 2];

            //convert the hex string to array of bytes
            for (int i = 0; i < returnBytes.Length; i++)
                returnBytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);

            //return the array of bytes filled with converted values
            return returnBytes;
        }
    } // End Class BaseCrypto
}

