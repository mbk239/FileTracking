using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace TSR.Framework.Cryptography
{
    /// <summary>
    /// Advanced Encryption Standard
    /// Encrypts or helps to encrypt data
    /// </summary>
    public class AESCrypto  // Advanced Encryption Standard
    {
        /// <summary>
        /// Encrypts the sourceString, returns this result as an Aes encrypted, BASE64 encoded string
        /// </summary>
        /// <param name="plainSourceStringToEncrypt">a plain, Framework string (ASCII, null terminated)</param>
        /// <param name="key"></param>
        /// <returns>
        /// returns an Aes encrypted, BASE64 encoded string
        /// </returns>
      
        public static string EncryptString(string plainSourceStringToEncrypt, byte[] key)
        {
            //Set up the encryption objects
            AesCryptoServiceProvider acsp = GetProvider(key);
            byte[] sourceBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(plainSourceStringToEncrypt);
            ICryptoTransform ictE = acsp.CreateEncryptor();

            //Set up stream to contain the encryption
            System.IO.MemoryStream msS = new System.IO.MemoryStream();

            //Perform the encrpytion, storing output into the stream
            CryptoStream csS = new CryptoStream(msS, ictE, CryptoStreamMode.Write);
            csS.Write(sourceBytes, 0, sourceBytes.Length);
            csS.FlushFinalBlock();

            //sourceBytes are now encrypted as an array of secure bytes
            byte[] encryptedBytes = msS.ToArray(); //.ToArray() is important, don't mess with the buffer

            //return the encrypted bytes as a BASE64 encoded string
            return System.Convert.ToBase64String(encryptedBytes);
        }

        /// <summary>
        /// Decrypts a BASE64 encoded string of encrypted data, returns a plain string
        /// </summary>
        /// <param name="base64StringToDecrypt">an Aes encrypted AND base64 encoded string</param>
        /// <param name="key">an Aes encrypted AND base64 encoded string</param>
        /// <returns>
        /// returns a plain string
        /// </returns>
        public static string DecryptString(string base64StringToDecrypt, byte[] key)
        {
            //Set up the encryption objects
            AesCryptoServiceProvider acsp = GetProvider(key);
            byte[] RawBytes = System.Convert.FromBase64String(base64StringToDecrypt);
            ICryptoTransform ictD = acsp.CreateDecryptor();
            //RawBytes now contains original byte array, still in Encrypted state

            //Decrypt into stream
            System.IO.MemoryStream msD = new System.IO.MemoryStream(RawBytes, 0, RawBytes.Length);
            CryptoStream csD = new CryptoStream(msD, ictD, CryptoStreamMode.Read);
            //csD now contains original byte array, fully decrypted

            //return the content of msD as a regular string
            return (new System.IO.StreamReader(csD)).ReadToEnd();
        }

        /// <summary>
        /// Get AesCryptoServiceProvider by passing key parameter
        /// </summary>
        /// <param name="key">any byte array (16 bytes long is optimal)</param>
        /// <returns>AesCryptoServiceProvider</returns>
        private static AesCryptoServiceProvider GetProvider(byte[] key)
        {
            //Set up the encryption objects
            AesCryptoServiceProvider result = new AesCryptoServiceProvider();
            byte[] RealKey = GetKey(key, result);
            result.Key = RealKey;
            result.IV = RealKey;
            return result;
        }

        /// <summary>
        /// Get Key(any byte array (16 bytes long is optimal)) 
        /// by passing suggested key(any byte array (16 bytes long is optimal))
        /// and an AesCryptoServiceProvider type provider
        /// </summary>
        /// <param name="suggestedKey">any byte array (16 bytes long is optimal)</param>
        /// <param name="p">AesCryptoServiceProvider</param>
        /// <returns></returns>
        private static byte[] GetKey(byte[] suggestedKey, AesCryptoServiceProvider p)
        {
            byte[] kRaw = suggestedKey;
            List<byte> kList = new List<byte>();
            for (int i = 0; i < p.LegalKeySizes[0].MinSize / 8; i++)
            {
                kList.Add(kRaw[i % kRaw.Length]);
            }
            byte[] k = kList.ToArray();
            return k;
        }

    }  //End class Aes
}
