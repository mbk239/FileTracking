﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.CompilerServices;
using TSR.Framework.Exceptions;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Class EmailScheduler
    /// extends IScheduler
    /// Schdules emails to be sent..
    /// </summary>
    public class EmailScheduler : IScheduler
    {
        #region IScheduler Members

        /// <summary>
        /// Method Execute
        /// Handles the execution of the scheduled email sending
        /// </summary>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Execute()
        {            
            //create a notification instance
            NotificationList _pendingNotifications = new NotificationList();
            try
            {
                using (NotificationData data = new NotificationData()) // get the data access object..
                {
                    _pendingNotifications = data.GetAllPendingNotification(); // get all the pending notifications
                }                

                Execute(_pendingNotifications);
            }
            catch (DatabaseConnectionException exp) // catch the database connection Exception
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
                throw exp; //throw it to the caller to handle

            }
            catch (Exception exp) // catch other exceptions
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
            }
        }       
        /// <summary>
        /// Method: SetTrycount
        /// sets the number of attempts made to send some email.
        /// it also sets the IsSent property to false
        /// </summary>
        /// <param name="_object"></param>
        private void SetTrycount(Notification _object)
        {
            try
            {

                using (NotificationData data = new NotificationData())
                {
                    _object.TryCount += 1;//increment try count
                    _object.IsSent = false; // set IsSent to false
                    long result = data.Update(_object); // update the database
                }
            }
            catch (DatabaseConnectionException exp) // catch the DatabaseConnectionException
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception

            }
            catch (Exception exp) // catch other exceptions
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
            }
        }
        
        public void ExecuteForWeb(NotificationList _pendingNotifications)
        {            
            try
            {                
                                    
                    System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(SendMail), _pendingNotifications);
                    //email.SendMail(_pendingObject);
                    //using (NotificationData data = new NotificationData())
                    //{
                    //    _pendingObject.IsSent = true;
                    //    _pendingObject.TryCount += 1;
                    //    long result = data.Update(_pendingObject);
                    //}
            }           
            catch (Exception exp) // catch other exceptions
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception                
            }            
        }

        public bool Execute(NotificationList _pendingNotifications)
        {
            bool success = true;
            try
            {


                if (_pendingNotifications.Count > 0) // if there are some pending notifications
                {
                    //iterate through the notifications
                    foreach (Notification _pendingObject in _pendingNotifications)
                    {
                        try
                        {
                            using (Email email = new Email())
                            {

                                //System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(SendMail), _pendingObject);
                                email.SendMail(_pendingObject);
                                //using (NotificationData data = new NotificationData())
                                //{
                                //    _pendingObject.IsSent = true;
                                //    _pendingObject.TryCount += 1;
                                //    long result = data.Update(_pendingObject);
                                //}
                            }
                        }
                        catch (Exception exp) // catch the exceptions
                        {
                            SetTrycount(_pendingObject); // set the try count
                            Logging.LoggingHandler.LogUnhandledException(exp); // log the error
                            success = false;
                        }
                    }
                }
            }
            catch (DatabaseConnectionException exp) // catch the database connection Exception
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
                throw exp; //throw it to the caller to handle                

            }
            catch (Exception exp) // catch other exceptions
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
                success = false;
            }
            return success;
        }


        private void SendMail(object obj)
        {
            try
            {
                NotificationList nof = (NotificationList)obj;
                if (nof != null)
                {
                    if (nof.Count > 0) // if there are some pending notifications
                    {
                        //iterate through the notifications
                        foreach (Notification _pendingObject in nof)
                        {    
                            try
                            {
                                //send the email            
                                using (Email email = new Email())
                                {
                                    email.SendMail(_pendingObject);
                                }
                            }
                            catch (Exception exp) // catch the exceptions
                            {
                                SetTrycount(_pendingObject); // set the try count
                                Logging.LoggingHandler.LogUnhandledException(exp); // log the error                    
                            }
                        }
                    }
                }
            }
            catch (DatabaseConnectionException exp) // catch the database connection Exception
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception
                throw exp; //throw it to the caller to handle                

            }
            catch (Exception exp) // catch other exceptions
            {
                Logging.LoggingHandler.LogUnhandledException(exp); // log the exception                
            }  
        }
        #endregion
    }//end of the class EmailScheduler
   }
