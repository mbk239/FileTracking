﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using TSR.Framework.Exceptions;
using System.Data;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Class NotificationData
    /// extends IDisposable
    /// data accessing class for the notification objects..
    /// </summary>
    public class NotificationData : IDisposable
    {
        private const String GETALLNOTIFICATIONFORSCHEDULING = "GetAllPendingNotification";
        private const string UPDATENOTIFICATION = "UpdateNotification";
        private const string ReturnValue = "@Return_Value";
        private SqlConnection connection = null;
        private SqlCommand command = null;

        /// <summary>
        /// Method: GetAllPendingNotification
        /// Returns a list of all pending notifications
        /// </summary>
        /// <returns>returns a list of all pending notifications</returns>
        public NotificationList GetAllPendingNotification()
        {
            NotificationList notificationList = new NotificationList(); // create the notification list 

            try
            {
                connection = new SqlConnection(ConfigurationBlock.ConnectionString); // open a new connection
                command = connection.CreateCommand(); // create a new command
                command.CommandText = GETALLNOTIFICATIONFORSCHEDULING; // set the command text
                command.CommandType = CommandType.StoredProcedure; // set the command type

                try
                {
                    connection.Open(); //try to open the connection
                }
                catch (SqlException ex) // catch any SqlException
                {
                    Logging.LoggingHandler.LogUnhandledException(ex); // and the log
                    throw new DatabaseConnectionException(ex); //throw the exception to the caller to handle
                }

                SqlDataReader reader = command.ExecuteReader(); // execute the command
                while (reader.Read()) // read the data
                {
                    Notification notificationObj = new Notification(); // create a Notification object
                    if (!reader.IsDBNull(0)) notificationObj.ToAddress = reader.GetString(0);
                    if (!reader.IsDBNull(1)) notificationObj.ID = reader.GetInt64(1);
                    if (!reader.IsDBNull(2)) notificationObj.Name = reader.GetString(2);
                    if (!reader.IsDBNull(3)) notificationObj.UserID = reader.GetInt64(3);
                    if (!reader.IsDBNull(4)) notificationObj.Subject = reader.GetString(4);
                    if (!reader.IsDBNull(5)) notificationObj.Body = reader.GetString(5);
                    if (!reader.IsDBNull(6)) notificationObj.StartDate = reader.GetDateTime(6);
                    if (!reader.IsDBNull(7)) notificationObj.EndDate = reader.GetDateTime(7);
                    if (!reader.IsDBNull(8))
                        notificationObj.ExecutionTimeStamp = reader.GetDateTime(8);
                    else
                        notificationObj.ExecutionTimeStamp = DateTime.Now;
                    if (!reader.IsDBNull(9)) notificationObj.TransferMedium = (TransferMediumEnum)reader.GetInt16(9);
                    if (!reader.IsDBNull(10)) notificationObj.IsSent = reader.GetBoolean(10);
                    if (!reader.IsDBNull(11)) notificationObj.TryCount = reader.GetInt16(11);
                    if (!reader.IsDBNull(12)) notificationObj.CreatorID = reader.GetInt64(12);
                    if (!reader.IsDBNull(13)) notificationObj.CreatedTimeStamp = reader.GetDateTime(13);
                    if (!reader.IsDBNull(14)) notificationObj.ModifierID = reader.GetInt64(14);
                    if (!reader.IsDBNull(15)) notificationObj.ModifiedTimeStamp = reader.GetDateTime(15);
                    if (!reader.IsDBNull(16)) notificationObj.IsDeleted = reader.GetBoolean(16);
                    notificationList.Add(notificationObj); //add the Notification object to the list
                }

                reader.Close(); // close the reader
            }
            catch (Exception exp)    // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnknownException(exp);
                throw exp; 
            }
            finally
            {
                connection.Close(); // close the DB connection in case there was some exception
            }
            return notificationList; //return the notifications
        }

        /// <summary>
        /// method: Update
        /// makes necessary changes to the database with provided information through Notification object parameter
        /// </summary>
        /// <param name="notificationObj">An object of Notification type</param>
        /// <returns>the ID of the affected row</returns>
        public long Update(Notification notificationObj)
        {
            long result = 0;
            //set up the database connection
            connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            command = connection.CreateCommand();
            command.CommandText = UPDATENOTIFICATION;
            command.CommandType = CommandType.StoredProcedure;

            ///set parameters
            SqlParameter parameter = new SqlParameter("@" + Notification.Property_ID, SqlDbType.BigInt);
            parameter.Value = notificationObj.ID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_Name, SqlDbType.VarChar, 255);
            if (!String.IsNullOrEmpty(notificationObj.Name))
            {
                parameter.Value = notificationObj.Name;
            }
            else
                parameter.Value = string.Empty;

            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_UserID, SqlDbType.BigInt);
            parameter.Value = notificationObj.UserID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_Subject, SqlDbType.Text);
            parameter.Value = notificationObj.Subject;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_Body, SqlDbType.Text);
            parameter.Value = notificationObj.Body;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_StartDate, SqlDbType.DateTime);
            parameter.Value = notificationObj.StartDate;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_EndDate, SqlDbType.DateTime);
            parameter.Value = notificationObj.EndDate;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_ExecutionTimeStamp, SqlDbType.DateTime);
            parameter.Value = notificationObj.ExecutionTimeStamp;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_TransferMedium, SqlDbType.SmallInt);
            parameter.Value = (short)notificationObj.TransferMedium;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_IsSent, SqlDbType.Bit);
            parameter.Value = notificationObj.IsSent;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_TryCount, SqlDbType.SmallInt);
            parameter.Value = notificationObj.TryCount;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_CreatorID, SqlDbType.BigInt);
            parameter.Value = notificationObj.CreatorID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_CreatedTimeStamp, SqlDbType.DateTime);
            parameter.Value = notificationObj.CreatedTimeStamp;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_ModifierID, SqlDbType.BigInt);
            parameter.Value = notificationObj.ModifierID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_ModifiedTimeStamp, SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@" + Notification.Property_IsDeleted, SqlDbType.Bit);
            parameter.Value = false;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter(ReturnValue, SqlDbType.BigInt);
            parameter.Direction = ParameterDirection.ReturnValue;
            command.Parameters.Add(parameter);

            try
            {
                //try to open connection
                connection.Open();
            }
            catch (SqlException ex) // catch any SqlException
            {
                throw new DatabaseConnectionException(ex); // throw it to the caller to handle
            }

            try
            {
                command.ExecuteNonQuery(); // execute the command
                if (command.Parameters[ReturnValue] != null) // if the return value is not null
                {
                    if (command.Parameters[ReturnValue].Value != null)
                        result = Convert.ToInt64(command.Parameters[ReturnValue].Value); // get the return value
                    else
                        result = 0;
                }
                else
                    result = 0;

            }
            catch (Exception exp)    // ignore missing columns in the database
            {
                throw exp;
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }

            return result;
        }

        #region IDisposable Members

        /// <summary>
        /// Method: Dispose
        /// member of IDisposable
        /// NotificationData class specific implementation of Dispose
        /// </summary>
        public void Dispose()
        {
            if (connection != null)
            {
                //close connection if it is open
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        #endregion
    }
}
