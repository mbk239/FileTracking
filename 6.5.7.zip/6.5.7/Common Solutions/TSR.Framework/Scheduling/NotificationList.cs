﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Class: notificationList
    /// this generic collection class holds a list of Notification objects
    /// </summary>
    [CollectionDataContract]
    public class NotificationList : List<Notification>
    {

    }
}
