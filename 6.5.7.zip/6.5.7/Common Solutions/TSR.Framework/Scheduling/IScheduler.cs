﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Public interface
    /// IScheduler provides generic methods that can be implemented to handle the scheduling events
    /// </summary>
    public interface IScheduler
    {
        /// <summary>
        /// Method Execute
        /// This is an abstract method and hence every class extending this class must implement this class.
        /// </summary>
        [MethodImpl(MethodImplOptions.Synchronized)]
        void Execute();

        bool Execute(NotificationList notificationList);
        void ExecuteForWeb(NotificationList notificationList);
    }
}
