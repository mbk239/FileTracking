﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Abstruct class Scheduler
    /// provides the means to get some specific scheduler 
    /// </summary>
    public abstract class Scheduler
    {

        public static IScheduler GetScheduler(String schedulerKey)
        {
            IScheduler _scheduler;

            switch (schedulerKey)
            { 
                default:
                    _scheduler = (IScheduler)new EmailScheduler();
                    break;
            }

            return _scheduler;
        }

    }
}
