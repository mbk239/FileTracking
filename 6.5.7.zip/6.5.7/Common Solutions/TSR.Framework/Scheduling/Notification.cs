﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace TSR.Framework.Scheduling
{
    /// <summary>
    /// Class: Notification
    /// This class is an entity class
    /// it holds the necessary data for sending notification to TSR users
    /// </summary>
    [DataContract]
    public class Notification
    {
        #region Notification fields in the database
        public const string Property_ID = "ID";
        public const string Property_Name = "Name";
        public const string Property_UserID = "UserID";
        public const string Property_Subject = "Subject";
        public const string Property_Body = "Body";
        public const string Property_StartDate = "StartDate";
        public const string Property_EndDate = "EndDate";
        public const string Property_ExecutionTimeStamp = "ExecutionTimeStamp";
        public const string Property_TransferMedium = "TransferMedium";
        public const string Property_IsSent = "IsSent";
        public const string Property_TryCount = "TryCount";
        public const string Property_CreatorID = "CreatorID";
        public const string Property_CreatedTimeStamp = "CreatedTimeStamp";
        public const string Property_ModifierID = "ModifierID";
        public const string Property_ModifiedTimeStamp = "ModifiedTimeStamp";
        public const string Property_IsDeleted = "IsDeleted";
        
        #endregion Notification fields in the database

        #region private data types

        private long _ID; // notification id 
        private String _Name; //name 
        private long _UserID; // user's ID
        private String _Subject; // subject of the notification
        private String _Body; // body of the notification
        private DateTime _StartDate; // start date of the period for which notification is sent
        private DateTime _EndDate; // end date of the period for which notification is sent
        private DateTime _ExecutionTimeStamp; // the time when the notification is sent
        private TransferMediumEnum _TransferMedium; // the medium through which notification is sent
        private bool _IsSent; // is the notification sent
        private short _TryCount; // number of attempts to send the notification
        private long _CreatorID; // ID of the person who created the notification entry..
        private DateTime _CreatedTimeStamp; // the time when the entry was created
        private long _ModifierID; // the ID of the person who modified the entry
        private DateTime _ModifiedTimeStamp; // the time when this entry was modified
        private bool _IsDeleted; // whether the entry is valid or deleted
        private String _ToAddress; // destination of the notification
        private String _FromAddress; // sender of the notification

        #endregion private data types

        #region Public properties.

        /// <summary>
        /// holds the notification entry ID 
        /// </summary>
        [DataMember]
        public long ID
        {
            get { return _ID; }
            set
            {
                _ID = value;
            }
        }

        /// <summary>
        /// Holds the name
        /// </summary>
        [DataMember]
        public String Name
        {
            get { return _Name; }
            set
            {
                _Name = value;
            }
        }

        /// <summary>
        /// Holds the User ID
        /// </summary>
        [DataMember]
        public long UserID
        {
            get { return _UserID; }
            set
            {
                _UserID = value;
            }
        }

        /// <summary>
        /// Holds the subject of the notification..
        /// </summary>
        [DataMember]
        public String Subject
        {
            get { return _Subject; }
            set
            {

                _Subject = value;

            }
        }

        /// <summary>
        /// Body of the notification
        /// </summary>
        [DataMember]
        public String Body
        {
            get { return _Body; }
            set
            {

                _Body = value;

            }
        }

        /// <summary>
        /// Start data of the notification period
        /// </summary>
        [DataMember]
        public DateTime StartDate
        {
            get { return _StartDate; }
            set
            {

                _StartDate = value;

            }
        }

        /// <summary>
        /// end date of the notification period
        /// </summary>
        [DataMember]
        public DateTime EndDate
        {
            get { return _EndDate; }
            set
            {

                _EndDate = value;

            }
        }

        /// <summary>
        /// The time when the notification sending event was executed
        /// </summary>
        [DataMember]
        public DateTime ExecutionTimeStamp
        {
            get { return _ExecutionTimeStamp; }
            set { _ExecutionTimeStamp = value; }
        }

        /// <summary>
        /// the medium through which the notification is sent
        /// </summary>
        [DataMember]
        public TransferMediumEnum TransferMedium
        {

            get { return _TransferMedium; }
            set
            {

                _TransferMedium = value;

            }
        }

        /// <summary>
        /// has the notification been sent
        /// </summary>
        [DataMember]
        public bool IsSent
        {
            get { return _IsSent; }
            set
            {

                _IsSent = value;

            }
        }

        /// <summary>
        /// number of attempts to send the notification
        /// </summary>
        [DataMember]
        public short TryCount
        {
            get { return _TryCount; }
            set
            {

                _TryCount = value;

            }
        }

        /// <summary>
        /// the person who created the notification
        /// </summary>
        [DataMember]
        public long CreatorID
        {
            get { return _CreatorID; }
            set { _CreatorID = value; }
        }

        /// <summary>
        /// the time when the notification was created
        /// </summary>
        [DataMember]
        public DateTime CreatedTimeStamp
        {
            get { return _CreatedTimeStamp; }
            set { _CreatedTimeStamp = value; }
        }
        
        /// <summary>
        /// the person who modified the notification
        /// </summary>
        [DataMember]
        public long ModifierID
        {
            get { return _ModifierID; }
            set { _ModifierID = value; }
        }
        
        /// <summary>
        /// the time when the notification was modified
        /// </summary>
        [DataMember]
        public DateTime ModifiedTimeStamp
        {
            get { return _ModifiedTimeStamp; }
            set { _ModifiedTimeStamp = value; }
        }

        /// <summary>
        /// has this entry been deleted        /// </summary>
        [DataMember]
        public bool IsDeleted
        {
            get { return _IsDeleted; }
            set { _IsDeleted = value; }
        }

        /// <summary>
        /// the address of the recipient
        /// </summary>
        [DataMember]
        public String ToAddress
        {
            get
            {
                if (String.IsNullOrEmpty(_ToAddress))                    
                    _ToAddress = "test.periscope@gmail.com";
                return _ToAddress; }
            set { _ToAddress = value; }
        }

        /// <summary>
        /// the address of the sender
        /// some predetermined address
        /// </summary>
        [DataMember]
        public String FromAddress
        {
            get
            {
                if (TransferMedium == TransferMediumEnum.Email)
                    _FromAddress = ConfigurationBlock.MailSettingsXML.From; //edit by tsrdev2 - hosted version
                else if (TransferMedium == TransferMediumEnum.SMS)
                    _FromAddress = "2847";
                else if (TransferMedium == TransferMediumEnum.Postal)
                    _FromAddress = string.Empty;
                return _FromAddress;
            }
            set
            {

            }
        }
        /// <summary>
        /// the address of the cc
        /// </summary>
        public String CCAddress;
        #endregion Public properties.

    }
}
