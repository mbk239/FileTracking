﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework.Scheduling
{
    public class MailServerSetting
    {
        /// <summary>
        /// Mail server settings
        /// added by tsrdev2
        /// </summary>
        private String _host;
        private int _port;
        private String _from;
        private String _username;
        private string _password;
        private string _localfile;
        private bool _enableSsl;
        private bool _anonymousLogin;
                
        public String Host
        {
            get { return _host; }
            set
            {
                _host = value;
            }
        }
        
        public int Port
        {
            get { return _port; }
            set
            {
                _port = value;
            }
        }
       
        public String From
        {
            get { return _from; }
            set
            {
                _from = value;
            }
        }
      
        public String UserName
        {
            get { return _username; }
            set
            {
                _username = value;
            }
        }

        public String Password
        {
            get { return _password; }
            set
            {
                _password = value;
            }
        }

        public string LocalFilePath
        {
            get
            {
                return _localfile;
            }
            set
            {
                _localfile = value;
            }
        }

        public bool EnableSsl
        {
            get
            {
                return _enableSsl;
            }
            set
            {
                _enableSsl = value;
            }
        }

        public bool AnonymousLogin
        {
            get
            {
                return _anonymousLogin;
            }
            set
            {
                _anonymousLogin = value;
            }
        }

    }
}
