﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework
{
    //Created by tsrdev1
    //Created date 02/05/2010    
    /// <summary>
    /// Support get title of person
    /// </summary>
    public class PersonHelper
    {        
        public static String GetTitleByIndex(Int32 index)
        {
            switch (index)
            {
                case 1:
                    return Resource.ResourceManager.GetResourceString("SexMr","Mr");                    
                case 2:
                    return Resource.ResourceManager.GetResourceString("SexMrs", "Mrs");                   
                case 3:
                    return Resource.ResourceManager.GetResourceString("SexMs", "Ms");                    
                default:
                    return Resource.ResourceManager.GetResourceString("SexMr", "Mr");                    
            }
        }
        public static Int32 GetIndexByTitle(string title)
        {
            string strMr = Resource.ResourceManager.GetResourceString("SexMr", "Mr");
            string strMrs = Resource.ResourceManager.GetResourceString("SexMrs", "Mrs");
            string strMs =Resource.ResourceManager.GetResourceString("SexMs", "Ms");            
            if (title.Trim() == strMr)
                    return 1;                    
            if (title.Trim() == strMrs)
                    return 2;                    
            if (title.Trim() == strMs)
                    return 3;
            return 1;                       
        }
    }
}
