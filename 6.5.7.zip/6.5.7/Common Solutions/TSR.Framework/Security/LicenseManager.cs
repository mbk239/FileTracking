using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

using TSR.Framework.Cryptography;
using TSR.Framework.Exceptions;
using System.Runtime.Serialization;

namespace TSR.Framework.Security
{
    /// <summary>
    /// Enumeration for license types
    /// </summary>
    [Serializable]
    public enum LicenseTypes
    {
        Standard,
        Demo,
        TempStandard,
        TempRenewal
    }

    /// <summary>
    /// Module License Class. It keeps data related to each module's license.
    /// </summary>
    [Serializable]
    [DataContract]
    public class ModuleLicense
    {
        [DataMember]
        public string Key { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public DateTime? FunctionalExpiryDate { get; set; } //On functional expiry date, module should stop working
        
        public override bool Equals(object obj)
        {
            return (this.Key == ((ModuleLicense)obj).Key);
        }
    }

    /// <summary>
    /// Application license holds all licensing information for the total application.
    /// It has a list collection of ModuleLicense class. So, all information can be kept in this class.
    /// This is the class which is serialized and encrypted.
    /// </summary>
    [Serializable]
    [DataContract]
    public class ApplicationLicense
    {
        [DataMember]
        public string OrgID { get; set; } //organization ID
        [DataMember]
        public string OrganizationName { get; set; } // organization name
        [DataMember]
        public string SerialNumber { get; set; } // serial number
        [DataMember]
        public string Version { get; set; } // license version
        [DataMember]
        public int NumberOfUsers { get; set; } // number of users allowed for this license
        [DataMember]
        public int NumberOfExpenseUsers { get; set; } // number of users allowed for this license
        [DataMember]
        public List<ModuleLicense> Modules { get; set; }
        [DataMember]
        public LicenseTypes LicenseType { get; set; } //License type of the module
        [DataMember]
        public DateTime MaintenanceExpiry { get; set; }
        [DataMember]
        public DateTime FoundationExpiry { get; set; }
        [DataMember]
        public DateTime ExpenseExpiry { get; set; }

        [DataMember]
        public DateTime RateExpiry { get; set; }

        /// <summary>
        /// the constructor ApplicationLicense
        /// </summary>
        public ApplicationLicense() 
        {
            Modules = new List<ModuleLicense>(); // licenses of the modules of this application
        }
    }

    /// <summary>
    /// License Manager class. Basic license functionalities are handled here. To retreive existing license, validate it,
    /// or update existing one, or insert new one, this is the class.
    /// </summary>
    public class LicenseManager : BaseManager
    {
        public LicenseManager(UserContext context) : base(context) { }
        public LicenseManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// A static method to get current license for the application
        /// </summary>
        /// <returns></returns>
        public static ApplicationLicense GetLicense()
        {
            string encryptedLicense = GetLicenseValueFromDatabase();
            if(string.IsNullOrEmpty(encryptedLicense))
                throw new Exception("License not available");
            ApplicationLicense ls = GetLicenseFromEncryptedString(encryptedLicense);
            if (ls == null)
                throw new Exception("License not in correct format");

            return ls;            
        }

        public static ApplicationLicense GetLicense(string connectionString)
        {
            string encryptedLicense = GetLicenseValueFromDatabase(connectionString);
            if (string.IsNullOrEmpty(encryptedLicense))
                throw new Exception("License not available");
            ApplicationLicense ls = GetLicenseFromEncryptedString(encryptedLicense);
            if (ls == null)
                throw new Exception("License not in correct format");

            return ls;
        }

        /// <summary>
        /// Retreives encrypted license from database
        /// </summary>
        /// <returns></returns>
        public static string GetLicenseValueFromDatabase()
        {
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);// get the connection
            try
            {
                connection.Open(); //try to open the connection
            }
            catch (Exception ex) // catch the exception
            {
                throw new DatabaseConnectionException(ex); // throw it to the caller to handle
            }

            //setup the command
            SqlCommand command = connection.CreateCommand();
            command.CommandText = "GetAppConfigValueByKey";
            command.CommandType = CommandType.StoredProcedure;

            //setup and add the parameters
            string license = string.Empty;
            SqlParameter parameterKey = new SqlParameter("@Key", SqlDbType.VarChar, 255);
            parameterKey.Value = "License";
            command.Parameters.Add(parameterKey);
            SqlParameter parameterValue = new SqlParameter("@Value", SqlDbType.VarChar, -1);
            parameterValue.Direction = System.Data.ParameterDirection.Output;
            command.Parameters.Add(parameterValue);

            try
            {
                command.ExecuteNonQuery(); // try to execute the command
                license = command.Parameters["@Value"].Value.ToString(); // get the value
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                //close the connection if it's not closed yet
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return license; // return the license

        }

        public static string GetLicenseValueFromDatabase(string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);// get the connection
            try
            {
                connection.Open(); //try to open the connection
            }
            catch (Exception ex) // catch the exception
            {
                throw new DatabaseConnectionException(ex); // throw it to the caller to handle
            }

            //setup the command
            SqlCommand command = connection.CreateCommand();
            command.CommandText = "GetAppConfigValueByKey";
            command.CommandType = CommandType.StoredProcedure;

            //setup and add the parameters
            string license = string.Empty;
            SqlParameter parameterKey = new SqlParameter("@Key", SqlDbType.VarChar, 255);
            parameterKey.Value = "License";
            command.Parameters.Add(parameterKey);
            SqlParameter parameterValue = new SqlParameter("@Value", SqlDbType.VarChar, -1);
            parameterValue.Direction = System.Data.ParameterDirection.Output;
            command.Parameters.Add(parameterValue);

            try
            {
                command.ExecuteNonQuery(); // try to execute the command
                license = command.Parameters["@Value"].Value.ToString(); // get the value
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                //close the connection if it's not closed yet
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return license; // return the license

        }

        /// <summary>
        /// Appconfiguration table stores application level values that is valid for the installed application. 
        /// This table has Key and Value column. Key column is unique. 
        /// This method modifyAppConfiguration is for modifying the appconfiguration value.
        /// Depending on the isInsert parameter, it sends the parameters to that related procedure. There are two procedures:
        /// one for insertion and another for update. As both of these have same parameters, function is written to
        /// reuse the code for both types of actions.
        /// </summary>
        /// <param name="key">Key of the AppConfiguration</param>
        /// <param name="value">Value of the Key, that needs to be inserted or updated</param>
        /// <param name="isInsert">if false, action will be update, otherwise, update procedure will be called</param>
        /// <returns></returns>
        private static bool modifyAppConfiguration(string key, string value, bool isInsert)
        {
            //set the procedure name
            string procedureName = string.Empty;
            if (isInsert)
                procedureName = "InsertAppConfiguration";
            else
                procedureName = "UpdateAppconfiguration";
            
            //create new SQL Connection
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                connection.Open(); // try to open connection
            }
            catch (SqlException ex) // catch the exception
            {
                throw new DatabaseConnectionException(ex); // throw to the caller to handle
            }

            //setup an Sql Command
            SqlCommand command = connection.CreateCommand(); 
            command.CommandText = procedureName;
            command.CommandType = CommandType.StoredProcedure;

            //set the parameters
            SqlParameter parameterKey = new SqlParameter("@Key", SqlDbType.VarChar, 255);
            parameterKey.Value = key;
            command.Parameters.Add(parameterKey);
            SqlParameter parameterValue = new SqlParameter("@Value", SqlDbType.VarChar, -1);
            parameterValue.Value = value;
            command.Parameters.Add(parameterValue);

            try
            {
                return (command.ExecuteNonQuery() > 0); // try to execute the command and return the 'Return' value
            }
            catch (Exception ex) // catch the exception and ignore it
            {
                System.Diagnostics.Debug.WriteLine(ex.Message); 
            }
            finally
            {
                //close the connection if it's not closed yet
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return false;
        }

        private static bool modifyAppConfiguration(string key, string value, bool isInsert, string connectionString)
        {
            //set the procedure name
            string procedureName = string.Empty;
            if (isInsert)
                procedureName = "InsertAppConfiguration";
            else
                procedureName = "UpdateAppconfiguration";

            //create new SQL Connection
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open(); // try to open connection
            }
            catch (SqlException ex) // catch the exception
            {
                throw new DatabaseConnectionException(ex); // throw to the caller to handle
            }

            //setup an Sql Command
            SqlCommand command = connection.CreateCommand();
            command.CommandText = procedureName;
            command.CommandType = CommandType.StoredProcedure;

            //set the parameters
            SqlParameter parameterKey = new SqlParameter("@Key", SqlDbType.VarChar, 255);
            parameterKey.Value = key;
            command.Parameters.Add(parameterKey);
            SqlParameter parameterValue = new SqlParameter("@Value", SqlDbType.VarChar, -1);
            parameterValue.Value = value;
            command.Parameters.Add(parameterValue);

            try
            {
                return (command.ExecuteNonQuery() > 0); // try to execute the command and return the 'Return' value
            }
            catch (Exception ex) // catch the exception and ignore it
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                //close the connection if it's not closed yet
                if (connection != null)
                {
                    connection.Close();
                }
            }
            return false;
        }

        /// <summary>
        /// builds ApplicationLicense object from encrypted string.
        /// It first decrypts the string then tries to deserialize it back to ApplicationLicense class
        /// If it is License Data, it should be possible to convert it back to
        /// LicenseApplication Class
        /// </summary>
        /// <param name="encryptedLicense">encrytepd license string</param>
        /// <returns>ApplicationLicense object</returns>
        public static ApplicationLicense GetLicenseFromEncryptedString(string encryptedLicense)
        {
            byte[] cipherkey = new byte[16];
            ApplicationLicense ls = new ApplicationLicense();
            cipherkey = Encoding.Unicode.GetBytes("Tha$3$A!7ebr7&Ay8-EQU!&fezasaB?4"); // get the cipher key
            try
            {
                string decryptedLicense = AESCrypto.DecryptString(encryptedLicense, cipherkey); // decrypt the licemse

                ls = UtilityHelper.DeserializeBase64(decryptedLicense) as ApplicationLicense; // get the license as Application license

                return ls;
            }
            catch (Exception ex) // catch the exception
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                throw new Exceptions.LicenseException(); // throw it to the caller to handle
            }
        }

        /// <summary>
        /// Saves license value to database
        /// </summary>
        /// <param name="license">encrypted license string that needs to be saved</param>
        /// <returns></returns>
        private static bool saveLicenseValue(string license)
        {
            string key = "License";
            bool isInsert = false;
            if (string.IsNullOrEmpty(GetLicenseValueFromDatabase()))
                isInsert = true;

            return modifyAppConfiguration(key, license, isInsert);
            
        }

        private static bool saveLicenseValue(string license, string connectionString)
        {
            string key = "License";
            bool isInsert = false;
            if (string.IsNullOrEmpty(GetLicenseValueFromDatabase(connectionString)))
                isInsert = true;

            return modifyAppConfiguration(key, license, isInsert, connectionString);

        }

        //public static ModuleLicense GetModule(string Key, DateTime? StartDateTime, DateTime? FunctionalExpiryDateTime, DateTime? SupportExpiryDate, string Version, LicenseTypes? licenseType)
        //{
        //    ModuleLicense ms = new ModuleLicense();
        //    ms.Key = Key;
        //    ms.OrganizationName = getModuleNameFromKey(Key); 
        //    if (FunctionalExpiryDateTime.HasValue)
        //        ms.FunctionalExpiryDate = FunctionalExpiryDateTime.Value;
        //    if (SupportExpiryDate.HasValue)
        //        ms.SupportExpiryDate = SupportExpiryDate.Value;
        //    if (StartDateTime.HasValue)
        //        ms.StartDate = StartDateTime.Value;
        //    //ms.StartDate = StartDate;
        //    if (licenseType.HasValue)
        //        ms.LicenseType = licenseType.Value;
        //    ms.Version = Version;
        //    return ms;
        //}

        
        /// <summary>
        /// method: getModuleNameFromKey
        /// gets the module name from key
        /// </summary>
        /// <param name="Key"></param>
        /// <returns></returns>
        private static string getModuleNameFromKey(string Key)
        {
            string MODULE_FOU_KEY = "TSR-FOU" + TSR.Framework.ConstantCollection.Version;
            string MODULE_TME_KEY = "TSR-TME" + TSR.Framework.ConstantCollection.Version;
            string MODULE_WFL_KEY = "TSR-WFL" + TSR.Framework.ConstantCollection.Version;
            string MODULE_DBR_KEY = "TSR-DBR" + TSR.Framework.ConstantCollection.Version;
            string MODULE_EXP_KEY = "TSR-EXP" + TSR.Framework.ConstantCollection.Version;

            if (Key == MODULE_FOU_KEY)
            {
                return "TSR Foundation";
            }
            else if (Key == MODULE_TME_KEY)
            {
                return "TSR Time Entry";
            }
            else if (Key == MODULE_WFL_KEY)
            {
                return "TSR Work Flow";
            }
            else if (Key == MODULE_DBR_KEY)
            {
                return "TSR Data Bridge";
            }
            else if (Key == MODULE_EXP_KEY)
            {
                return "TSR Expense";
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// geenrates license .. this code will be removed from client side code
        /// </summary>
        /// <param name="ls"></param>
        /// <returns></returns>
        public static string GenerateLicense(ApplicationLicense ls)
        {
            byte[] cipherkey = new byte[16];
            cipherkey = Encoding.Unicode.GetBytes("Tha$3$A!7ebr7&Ay8-EQU!&fezasaB?4");
            string serializedLicense = UtilityHelper.SerializeBase64(ls);
            string encryptedLicense = AESCrypto.EncryptString(serializedLicense, cipherkey);
            return encryptedLicense;
        }
        

        /// <summary>
        /// saves license to database
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool SetLicense(string value)
        {
            if (GetLicenseFromEncryptedString(value)==null)
                throw new Exception("License is not in correct format");
            return saveLicenseValue(value);
        }

        public bool SetLicense(string value,string connectionString)
        {
            if (GetLicenseFromEncryptedString(value) == null)
                throw new Exception("License is not in correct format");
            return saveLicenseValue(value, connectionString);
        }

        /// <summary>
        /// method: GetAllModules
        /// gets the list of all the modules
        /// </summary>
        /// <returns></returns>
        public static List<ModuleLicense> GetAllModules()
        {
            List<ModuleLicense> lmls = new List<ModuleLicense>();
            lmls.Add(new ModuleLicense { Key = "TSR-FOU" + TSR.Framework.ConstantCollection.Version, Name = "TSR-FOU" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });
            lmls.Add(new ModuleLicense { Key = "TSR-TME" + TSR.Framework.ConstantCollection.Version, Name = "TSR-TME" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });
            lmls.Add(new ModuleLicense { Key = "TSR-WFL" + TSR.Framework.ConstantCollection.Version, Name = "TSR-WFL" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });
            lmls.Add(new ModuleLicense { Key = "TSR-DBR" + TSR.Framework.ConstantCollection.Version, Name = "TSR-DBR" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });
            lmls.Add(new ModuleLicense { Key = "TSR-EXP" + TSR.Framework.ConstantCollection.Version, Name = "TSR-EXP" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });

            lmls.Add(new ModuleLicense { Key = "TSR-RATES" + TSR.Framework.ConstantCollection.Version, Name = "TSR-RATES" + TSR.Framework.ConstantCollection.Version, FunctionalExpiryDate = null });
            return lmls;
        }

        public static bool IsExpenseLicenseAvailable()
        {
            ApplicationLicense al = GetLicense();
            if (al.ExpenseExpiry > DateTime.Now.Date.AddDays(-1))
                return true;
            else return false;
        }

        public static bool IsRateLicenseAvailable()
        {
            ApplicationLicense al = GetLicense();
            return (al.RateExpiry > DateTime.Now.Date.AddDays(-1));
        }

        public static int GetNumberUseExpense()
        {
            int remain = 0;
            ApplicationLicense apLiccense = LicenseManager.GetLicense();
            if (apLiccense.ExpenseExpiry > DateTime.Now.Date.AddDays(-1))
            {
                remain = apLiccense.NumberOfExpenseUsers;
            }

            return remain;
        }
    }

   
}

