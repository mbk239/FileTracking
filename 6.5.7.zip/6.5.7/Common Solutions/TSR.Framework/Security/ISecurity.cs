using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Security
{
    /// <summary>
    /// Interface
    /// Name: ISecurity
    /// Description: This interface performs as a security interface
    /// </summary>
    public interface ISecurity
    {
        SecurityEnabledAttribute SecurityEnabledAttribute { get; }
        UserContext UserContext { get; }
        string PermissionKey { get; }
        bool SecurityEnabled { get; }
        bool IsAllowed { get; }
    }
}
