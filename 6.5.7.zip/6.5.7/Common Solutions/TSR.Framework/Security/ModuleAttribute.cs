using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;

namespace TSR.Framework.Security
{
    /// <summary>
    /// If this attribute is set in a Facade class, that module will become license enabled..
    /// User will need to have license for that module
    /// </summary>
    [global::System.AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
    public sealed class ModuleAttribute : Attribute
    {
        private StringCollection _ModuleKeys = new StringCollection();
        private bool _LicensingRequired = false;

        /// <summary>
        /// gets or sets the Module keys
        /// </summary>
        public StringCollection ModuleKeys
        {
            get { return _ModuleKeys; }
            set { _ModuleKeys = value; }
        }

        /// <summary>
        /// can be defined whther this module will require license or not
        /// </summary>
        public bool LicensingRequired
        {
            get { return _LicensingRequired; }
            set { _LicensingRequired = value; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="licensingRequired">bool value to indicate if license is required</param>
        /// <param name="moduleKeys">the list of module keys</param>
        public ModuleAttribute(bool licensingRequired, params string[] moduleKeys)
        {
            if (moduleKeys.Length <= 0)
                throw new InvalidOperationException("Need to have modules defined.");

            foreach (String moduleKey in moduleKeys)
            {
                _ModuleKeys.Add(moduleKey);
            }

            _LicensingRequired = licensingRequired;
        }
    }
}
