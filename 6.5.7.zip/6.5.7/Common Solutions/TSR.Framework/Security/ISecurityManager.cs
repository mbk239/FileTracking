using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Security
{
    /// <summary>
    /// Interface
    /// Name: ISecurityManager
    /// Description: This interface performs as a security manager
    /// </summary>
    public interface ISecurityManager
    {
        bool SetUserContext(UserContext context);
        UserContext GetUserContext(string username);
        UserContext GetCurrentUserContext();
        string GetCurrentUsername();
        string GetCurrentUser();
    }
}
