using System;
using System.Collections.Specialized;
using System.Text;

namespace TSR.Framework.Security
{
    /// <summary>
    /// interface IModule 
    /// provides means to access basic properties of a module
    /// </summary>
    public interface IModule
    {
        ModuleAttribute ModuleAttribute { get; }
        StringCollection ModuleKeys { get; }
        bool IsLicensed { get; }
    }
}
