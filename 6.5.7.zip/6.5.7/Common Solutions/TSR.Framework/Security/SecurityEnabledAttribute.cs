using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

namespace TSR.Framework.Security
{
    /// <summary>
    /// Not used.. Might use in future for extended security features
    /// </summary>
    [SerializableAttribute]
    [ComVisibleAttribute(true)]
    public sealed class SecurityPermission : CodeAccessPermission, IUnrestrictedPermission
    {
        public override IPermission Copy()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override void FromXml(SecurityElement elem)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override IPermission Intersect(IPermission target)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override bool IsSubsetOf(IPermission target)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override SecurityElement ToXml()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #region IUnrestrictedPermission Members

        public bool IsUnrestricted()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }


    /// <summary>
    /// SecurityEnabledAttribute, used to assign security, permission for a class, method
    /// </summary>
    [global::System.AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
    public sealed class SecurityEnabledAttribute : Attribute
    {
        private bool _SecurityEnabled = false;
        //private bool _IsControlOrPage = false;

        public bool SecurityEnabled
        {
            get { return _SecurityEnabled; }
            set { _SecurityEnabled = value; }
        }

        //public bool IsControlOrPage
        //{
        //    get { return _IsControlOrPage; }
        //    set { _IsControlOrPage = value; }
        //}

        public SecurityEnabledAttribute(bool securityEnabled)
        {
            _SecurityEnabled = securityEnabled;
        }

        //public SecurityEnabledAttribute(bool securityEnabled, bool isControlOrPage) : this(securityEnabled)
        //{
        //    _IsControlOrPage = isControlOrPage;
        //}
    }

    [global::System.AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
    sealed class TestAttribute : Attribute
    {
        // See the attribute guidelines at 
        //  http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconusingattributeclasses.asp
        readonly string _positionalString;
        int _namedInt;

        // This is a positional argument.
        public TestAttribute(string positionalString)
        {
            this._positionalString = positionalString;

            // TODO: Implement code here.
            throw new Exception("The method or operation is not implemented.");
        }
        public string PositionalString
        {
            get
            {
                return this._positionalString;
            }
        }
        // This is a named argument.
        public int NamedInt
        {
            get
            {
                return this._namedInt;
            }
            set
            {
                this._namedInt = value;
            }
        }
    }
}
