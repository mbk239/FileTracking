using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Framework.Security
{
    /// <summary>
    /// Class
    /// Name: ClassSecurity
    /// Description: This class is a custom Security
    /// who imeplements ISecurity and handles security related properties and functions.
    /// </summary>
    public class BaseSecuredClass : ISecurity
    {
        private UserContext _UserContext;

        /// <summary>
        /// gets the UserContext
        /// </summary>
        public UserContext UserContext
        {
            get { return _UserContext; }
        }

        /// <summary>
        /// If this attribute is enabled in a class, permission will be needed to use that class
        /// </summary>
        public SecurityEnabledAttribute SecurityEnabledAttribute
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                    return att as SecurityEnabledAttribute;

                return null;
            }
        }

        /// <summary>
        /// Permission key against which permission will be checked
        /// </summary>
        public virtual string PermissionKey
        {
            get
            {
                return this.GetType().Name.ToUpper();
            }
        }

        /// <summary>
        /// Boolean value, is retrieved by checking the attribute [SecurityEnabledAttribute]
        /// </summary>
        public bool SecurityEnabled
        {
            get
            {
                Attribute att = AttributeHelper.GetAttribute(this.GetType(), typeof(SecurityEnabledAttribute));

                if (att != null)
                {
                    SecurityEnabledAttribute secAtt = att as SecurityEnabledAttribute;
                    if (secAtt != null)
                    {
                        return secAtt.SecurityEnabled;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// whether some action is allowed or not
        /// </summary>
        public bool IsAllowed
        {
            get { return true; }
        }

        /// <summary>
        /// The constructor BaseSecuredClass
        /// </summary>
        /// <param name="userContext">an instance of UserContext class</param>
        public BaseSecuredClass(UserContext userContext)
        {
            _UserContext = userContext;

            if (SecurityEnabled) // security is enabled
            {
                if (!UserContext.HasPermission(PermissionKey)) // dose the user have permission
                    throw new Exceptions.SecurityException(); //throw security exception
            }
        }

        /// <summary>
        /// Checks whether SecurityEnabledAttribute is set true, if so, checks user's list of permission,
        /// if the user has the permission for that class
        /// </summary>
        /// <param name="keyPrefix"></param>
        /// <param name="keySuffix"></param>
        public void CheckSecurity(string keyPrefix, string keySuffix)
        {
            string key = (String.IsNullOrEmpty(keyPrefix) ? String.Empty : keyPrefix);
            key += PermissionKey;
            key += (String.IsNullOrEmpty(keySuffix) ? String.Empty : keySuffix);

            if (SecurityEnabled)
                if (!UserContext.HasPermission(key))
                    throw new Exceptions.SecurityException();
        }

        /// <summary>
        /// Method IsInstantiateAllowed
        /// checks if instantiation of some class is allowed
        /// </summary>
        /// <returns></returns>
        public bool IsInstantiateAllowed()
        {
            return true;
        }

        /// <summary>
        /// Method: IsInvokeAllowed
        /// checks if invoking some class is allowed
        /// </summary>
        /// <param name="permissionKey"></param>
        /// <returns></returns>
        public bool IsInvokeAllowed(string permissionKey)
        {
            return true;
        }
        public static object ReplaceHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("<", "&lt;").Replace(">", "&gt;").Replace("/", "&#47;");
            }
            return value;
        }
        public static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }
    } // end of class BaseSecuredClass
}
