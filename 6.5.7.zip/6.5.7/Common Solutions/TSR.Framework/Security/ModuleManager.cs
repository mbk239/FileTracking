using System;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.Win32;
namespace TSR.Framework.Security
{
    
    public class ModuleManager
    {
        /// <summary>
        /// checks whether a module is licensed or not
        /// </summary>
        /// <param name="moduleKey"></param>
        /// <returns></returns>
        public static bool IsModuleLicensed(string moduleKey)
        {
            ApplicationLicense license = LicenseManager.GetLicense();
            if (license != null)
            {
                string strVersion = license.Version;
                string[] arrSubVersion = strVersion.Split('.');
                if (arrSubVersion.Length == 1)
                {
                    strVersion = strVersion + ".0";
                }
                else if (arrSubVersion.Length == 2)
                {

                }
                else if (arrSubVersion.Length > 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                }

                //if (strVersion == TSR.Framework.ConstantCollection.Version)
                //{

                //}
                //else
                //{
                //    return false;
                //}

                if (license.Modules != null)
                {
                    foreach (ModuleLicense module in license.Modules)
                    {
                        //if ((module.Key == moduleKey) && (module.FunctionalExpiryDate >= DateTime.Today))
                        if (module.Key.ToLower().StartsWith(moduleKey.ToLower()) && (module.FunctionalExpiryDate >= DateTime.Today))
                            return true;
                    }
                }                
                else return true;
                
            }
            return false;

            //string moduleNames = ConfigurationManager.AppSettings["EnabledModules"];

            //if (!String.IsNullOrEmpty(moduleNames))
            //{
            //    string []modules = moduleNames.Split('#');

            //    foreach (string module in modules)
            //        if (module == moduleKey)
            //            return true;

            //    return false;
            //}

            //return true;
        }
       
    }

    
}
