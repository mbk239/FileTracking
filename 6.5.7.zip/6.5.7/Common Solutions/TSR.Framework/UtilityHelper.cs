using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Globalization;

namespace TSR.Framework
{
	/// <summary>
	/// Summary description for UtilityHelper.
	/// </summary>
	public class UtilityHelper
	{        
		public UtilityHelper()
		{
            //
			// TODO: Add constructor logic here
			//
		}
        //#region Javascript Functions

        //public static string QuoteUniqeId ( string[] _parameters ) 
        //{
        //    StringBuilder sbParam = new StringBuilder();
			
        //    sbParam.Append("'");

        //    for (int i = 0; i < _parameters.Length-1; i++) 
        //    {
        //        sbParam.Append( _parameters[i] );
        //        sbParam.Append( "','" );				
        //    }
			
        //    sbParam.Append( _parameters[_parameters.Length-1] );
        //    sbParam.Append("'");					
			
        //    return sbParam.ToString();
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="_parameter"></param>
        ///// <returns></returns>
        //public static string QuoteUniqeId ( string _parameter ) 
        //{
        //    StringBuilder sbParam = new StringBuilder();
			
        //    sbParam.Append("'");			
        //    sbParam.Append( _parameter );			
        //    sbParam.Append("'");					
			
        //    return sbParam.ToString();
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="page"></param>
        ///// <param name="_key"></param>
        ///// <param name="_filePathAndName"></param>
        //public static void IncludeJSFile( System.Web.UI.Page page, string _key, string _filePathAndName ) 
        //{			
        //    if (!page.ClientScript.IsClientScriptBlockRegistered(_key)) 
        //    {
        //        page.ClientScript.RegisterClientScriptBlock(typeof(System.Web.UI.Page), _key, 
        //            "<script type=\"text/javascript\" src=\""  + _filePathAndName + "\"></script>" );
        //    }
        //}		


        //#endregion

		#region "BitString Functions"
        
        /// <summary>
        /// method IntToBits
        /// converts an integer value to an array of boolean
        /// </summary>
        /// <param name="intvalue"></param>
        /// <returns></returns>
		public static bool[] IntToBits ( int intvalue )
		{
			int i= 0;
			bool[] tempvalues =  new bool[10];
			int modvalue = 1; // the remainder
			while ( intvalue != 0 )
			{
				Math.DivRem( intvalue, 2, out modvalue ); // perform intval%2 operation
				intvalue /= 2;

				if(modvalue == 1)//the bit was one
				{
					tempvalues[i] = true;
				}
				else // the bit was zero
				{
					tempvalues[i] = false;
				}
				i++;
			}
			bool[] mainValues =  new bool[i];
			int t = i-1;

            //copy the bits to mainValues array from tempvalues in revarse order
			for( int j = 0; j<i; j++,t-- )
			{
				mainValues[j] = tempvalues[t];
			}
			return mainValues;				

		}
		
        /// <summary>
        /// method IntToBits
        /// converts an integer value to an array of boolean with size equal to length
        /// </summary>
        /// <param name="intvalue"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static bool[] IntToBits ( int intvalue, int length )
		{
			int i= 0;
			bool[] tempvalues =  new bool[length];
			int modvalue = 1; // the remainder
			while ( intvalue != 0 )
			{
                Math.DivRem(intvalue, 2, out modvalue); // perform intvalue mod 2 operation
				intvalue /= 2;

				if(modvalue == 1) // the bit was 1
				{
					tempvalues[i] = true;
				}
				else // the bit was 0
				{
					tempvalues[i] = false;
				}
				i++;
			}
			bool[] mainValues =  new bool[length];
			int t = length-1;

            //copy the bits to mainValues array from tempvalues in revarse order
			for( int j = 0; j<length; j++,t-- )
			{
				mainValues[j] = tempvalues[t];
			}
			return mainValues;				

		}

        /// <summary>
        /// method LongToBits
        /// converts a Long integer value to an array of boolean with size equal to length
        /// </summary>
        /// <param name="intvalue"></param>
        /// <param name="length"></param>
        /// <returns></returns>
		public  bool[] LongToBits ( long longvalue, int length )
		{
			int i= 0;
			bool[] tempvalues =  new bool[length];
			long modvalue = 1;
			while ( longvalue != 0 )
			{
				Math.DivRem( longvalue, 2, out modvalue );
				longvalue /= 2;

				if(modvalue == 1)
				{
					tempvalues[i] = true;
				}
				else
				{
					tempvalues[i] = false;
				}
				i++;
			}
			bool[] mainValues =  new bool[length];
			int t = length-1;
			for( int j = 0; j<length; j++,t-- )
			{
				mainValues[j] = tempvalues[t];
			}
			return mainValues;				

		}
		
        /// <summary>
        /// Method BitsToInt
        /// converts an array of bits to Integer
        /// </summary>
        /// <param name="binaryarray"></param>
        /// <returns></returns>
        public int BitsToInt ( BitArray binaryarray )
		{
			System.Collections.IEnumerator myEnumerator = binaryarray.GetEnumerator();
			bool[] b= new bool[binaryarray.Count] ;
			int i  = 0;
            double result = 0; // get a double variable as Math.Pow only returns double
			while ( myEnumerator.MoveNext() ) //iterate through the array of bits 
			{
				
				b[i] = (bool)myEnumerator.Current;
				if( b[i] ==  true ) // if the current bit is 1
				{
					result+= Math.Pow(2,binaryarray.Count-(i+1)); // add 2^(positional value) to result
				}

				if( i <= binaryarray.Count ) // not finished
				{
					i++;
				}

			}
			return (int)result; // cast the double to integer and return
		}


		public  long BitsToLong ( BitArray binaryarray )
		{
			System.Collections.IEnumerator myEnumerator = binaryarray.GetEnumerator();
			bool[] b= new bool[binaryarray.Count] ;
			long i  = 0;
			double result =0;
			while ( myEnumerator.MoveNext() )  
			{
				
				b[i] = (bool)myEnumerator.Current;
				if( b[i] ==  true )
				{
					result+= Math.Pow(2,binaryarray.Count-(i+1));
				}

				if( i <= binaryarray.Count )
				{
					i++;
				}

			}
			return (long)result;
		}

		#endregion

		#region "Utlity functions()"

		/// <summary>
		/// returns ValueIfNull if Expression is DBNull or null,
		/// returns zero if Expression is null or nothing and ValueIfNull is nothing
		/// else returns Expression		
		///	example:
		/// Dim Category As String = Nz(CStr(Request.Params("cat")), "")		
		/// </summary>
		/// <param name="Expression"></param>
		/// <param name="ValueIfNull"></param>
		/// <returns></returns>
		public static object NotZero ( object Expression, object ValueIfNull ) 
		{ 
			object result= null;

			if ( !( IsNothing ( ValueIfNull ) ) ) 
			{ 
				if ( IsNothing ( Expression ) ) 
				{ 
					result = ValueIfNull; 
				} 
				else if ( IsDBNull( Expression )) 
				{ 
					result = ValueIfNull; 
				} 
				else 
				{ 
					result = Expression; 
				} 
			} 
			else 
			{ 
				if ( IsNothing( Expression ) ) 
				{ 
					result = 0; 
				} 
				else if ( IsDBNull ( Expression ) ) 
				{ 
					result = 0; 
				} 
				else 
				{ 
					result = Expression; 
				} 
			} 
			return result; 
		} 
		/// <summary>
		///  returns "" if inVal is DBNull ,
		///  else inVal
		/// </summary>
		/// <param name="inVal"></param>
		/// <returns></returns>
		public static object StrignEmpty ( object inVal ) 
		{ 
			if ( IsDBNull ( inVal ) ) 
			{ 
				return ""; 
			} 
			else 
			{ 
				return inVal; 
			} 
		} 
		/// <summary>
		///  returns "" if inVal is DBNull or DateTime.MinValue ,
		///  else inVal	
		/// </summary>
		/// <param name="inVal"></param>
		/// <returns></returns>
		public static object DateEmpty( object inVal ) 
		{ 
			if ( IsDBNull( inVal )  || DateTime.Compare ( DateTime.MinValue, ( DateTime ) inVal ) == 0 ) 
			{
                return string.Empty; 
			} 
			else 
			{ 
				return ( ( DateTime )inVal ).ToShortDateString();
			} 
		} 
		
		/// <summary>
		///  returns DateTime.MinValue if inVal is DBNull ,
		///  else inVal
		/// </summary>
		/// <param name="inVal"></param>
		/// <returns></returns>
		public static object DateMin( object inVal ) 
		{ 
			if ( IsDBNull( inVal ) ) 
			{ 
				return System.DateTime.MinValue; 
			} 
			else 
			{ 
				return inVal; 
			} 
		} 
		/// <summary>
		///  returns DBNull if inVal is null or null ,
		///  else inVal
		/// </summary>
		/// <param name="inVal"></param>
		/// <returns></returns>
		public static object DBNull( object inVal ) 
		{ 
			if ( IsNothing( inVal ) ||( ( string )( inVal ) ) == "" ) 
			{ 
				return System.DBNull.Value; 
			}			
			else 
			{ 
				return inVal; 
			} 
		}
        /// <summary>
        ///  returns last day of year,        
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public static DateTime LastDayOfYear(int year)
        {         
            // Get first of next year
            DateTime n = new DateTime(year + 1, 1, 1);         
            // Subtract 1 from it
            return n.AddDays(-1);
        }
        /// <summary>
        ///  returns first day of year,        
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public static DateTime FirstDayOfYear(int year)
        {

            if (year == 0)
            {
                year = 1;
            }
            // Get first of next year
            DateTime n = new DateTime(year, 1, 1);            
            return n;
        }

        /// <summary>
        ///  returns short  datetime with all Culture
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public static DateTime ConvertToShortDateTime(DateTime srcDt)
        {
            string crrShortDateFomat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            //string crrLongTimeFomat = CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern;

            int yFIndex = crrShortDateFomat.IndexOf("y");
            int yLIndex = crrShortDateFomat.LastIndexOf("y");
            int yLength = yLIndex - yFIndex + 1;          
            
            //four digits years
            if (yLength == 4)
            {
                return srcDt;
            }
            //two digits year
            string srcYear = srcDt.Year.ToString();
            string srcYear2 = srcYear.Substring(srcYear.Length - 2, 2);
            int dstYear = ConvertYear2DigitsTo4Digits(int.Parse(srcYear2));                        
            string newDt = crrShortDateFomat;
            newDt = newDt.Replace("dd", srcDt.Day.ToString());
            newDt = newDt.Replace("MM", srcDt.Month.ToString());
            newDt = newDt.Replace("yy", srcDt.Year.ToString());

            newDt = newDt + " " + srcDt.ToLongTimeString();
            int era = Calendar.CurrentEra;
            DateTime dstDt = new DateTime(31,4,16);
            
            
            return DateTime.Parse(newDt,CultureInfo.CurrentCulture);
        }

        private static int ConvertYear2DigitsTo4Digits(int year2)
        {
            int dstYear = 0;
            int firstDstYear = 0;
            int firstCurrentYear2 = Int32.Parse(DateTime.Now.Year.ToString().Substring(0, 2));
            int lastCurrentYear2 = Int32.Parse(DateTime.Now.Year.ToString().Substring(2, 2));
            if ((lastCurrentYear2 + 35) > year2)
                firstDstYear = firstCurrentYear2;
            else
                firstDstYear = firstCurrentYear2 - 1;
            dstYear = int.Parse(firstDstYear.ToString() + year2.ToString());

            return dstYear;
        }

		#endregion

		#region "IsDBNull(), IsNothing()"
		/// <summary>
		/// check DBNull Value
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public static bool IsDBNull( object obj )
		{
			if ( obj == System.DBNull.Value )
			{
				return true;
			}
			return false;
		}
		
		/// <summary>
		/// check Null Value
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public static  bool IsNothing( object obj )
		{
			if ( obj == null )
			{
				return true;
			}
			return false;
		}

		#endregion

        #region Base64 Serialization of Objects

        public static string SerializeBase64(object o)
        {// Serialize to a base 64 string
            byte[] bytes;
            long length = 0;
            MemoryStream ws = new MemoryStream();
            BinaryFormatter sf = new BinaryFormatter();
            sf.Serialize(ws, o);
            length = ws.Length;
            bytes = ws.GetBuffer();
            string encodedData = bytes.Length + ":" + Convert.ToBase64String(bytes, 0, bytes.Length, Base64FormattingOptions.None);
            return encodedData;
        }

        public static object DeserializeBase64(string s)
        {
            // We need to know the exact length of the string - Base64 can sometimes pad us by a byte or two
            int p = s.IndexOf(':');
            int length = Convert.ToInt32(s.Substring(0, p));
            // Extract data from the base 64 string!
            byte[] memorydata = Convert.FromBase64String(s.Substring(p + 1));
            MemoryStream rs = new MemoryStream(memorydata, 0, length);
            BinaryFormatter sf = new BinaryFormatter();
            object o = sf.Deserialize(rs);
            return o;
        }

        #endregion

        #region Date Time Formating
        public static double GetHours(DateTime startDate, DateTime endDate)
        {   
            TimeSpan timeSpan = endDate.Subtract(startDate);
            return timeSpan.TotalHours;
        }
        #endregion        

        public static String ConvertFromUTF8ToUTF16(String uft8String)
        {
            byte[] utf8Bytes = Encoding.UTF8.GetBytes(uft8String); ;
            byte[] utf16ByteAfterConvert = Encoding.Convert(Encoding.UTF8, Encoding.Unicode, utf8Bytes);
            byte byteFF = Convert.ToByte(255);
            byte byteFE = Convert.ToByte(254);
            byte[] utf16Bytes = new byte[utf16ByteAfterConvert.Length + 2];
            utf16Bytes[0] = byteFF;
            utf16Bytes[1] = byteFE;
            for (int i = 2; i < utf16Bytes.Length; i++)
            {
                utf16Bytes[i] = utf16ByteAfterConvert[i - 2];
            }
            char[] utf16Chars = new char[Encoding.Unicode.GetCharCount(utf16Bytes, 0, utf16Bytes.Length)];

            Encoding.Unicode.GetChars(utf16Bytes, 0, utf16Bytes.Length, utf16Chars, 0);
            String utf16String = new String(utf16Chars);
            return utf16String;
        }       
        public static String ConvertFromUTF8ToASCII(String uft8String)
        {
            ASCIIEncoding ascii = new ASCIIEncoding();
            byte[] byteArray = Encoding.UTF8.GetBytes(uft8String);
            byte[] asciiArray = Encoding.Convert(Encoding.UTF8, Encoding.ASCII, byteArray);
            string finalString = ascii.GetString(asciiArray);
            return finalString;
        }
        //public static String ConvertFromUTF8ToASCII(String uft8String,bool checkConvert)
        //{
        //    byte[] asciiString = Encoding.ASCII.GetBytes(uft8String);
        //    BitConverter.ToString(asciiString);
        //    string finalString=Encoding.ASCII.GetString(asciiString);
        //    return finalString;
        //}

    }
}
