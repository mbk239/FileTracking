﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Framework.Logging
{
    #region Log Entity
    /// <summary>
    /// Class
    /// Name: Log
    /// Description: Log entity class which has multiple 
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class Log
    {
        #region Variables
        private long _ID;
        private long _UserID;
        private String _SessionID = String.Empty;
        private String _ClientHost = String.Empty;
        private String _ServerIP = String.Empty;
        private String _Service = String.Empty;
        private String _Category = String.Empty;
        private int _Priority = 0;
        private DateTime _LoggingTime = DateTime.Now;
        private String _MessageSummary = String.Empty;
        private String _MessageDetail = String.Empty;
        private String _StackTrace = String.Empty;
        private long _CreatorID;
        private DateTime _CreatedTimeStamp;
        private long _ModifierID;
        private DateTime _ModifiedTimeStamp = DateTime.Now;
        #endregion

        #region Properties
        public long ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public long UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }

        public String SessionID
        {
            get { return _SessionID; }
            set { _SessionID = value; }
        }

        public String ClientHost
        {
            get { return _ClientHost; }
            set { _ClientHost = value; }
        }

        public String ServerIP
        {
            get { return _ServerIP; }
            set { _ServerIP = value; }
        }

        public String Service
        {
            get { return _Service; }
            set { _Service = value; }
        }

        public String Category
        {
            get { return _Category; }
            set { _Category = value; }
        }

        public int Priority
        {
            get { return _Priority; }
            set { _Priority = value; }
        }

        public DateTime LoggingTime
        {
            get { return _LoggingTime; }
            set { _LoggingTime = value; }
        }

        public String MessageSummary
        {
            get { return _MessageSummary; }
            set { _MessageSummary = value; }
        }

        public String MessageDetail
        {
            get { return _MessageDetail; }
            set { _MessageDetail = value; }
        }

        public String StackTrace
        {
            get { return _StackTrace; }
            set { _StackTrace = value; }
        }

        public Exception InnerException { get; set; }

        public long CreatorID
        {
            get { return _CreatorID; }
            set { _CreatorID = value; }
        }

        public DateTime CreatedTimeStamp
        {
            get { return _CreatedTimeStamp; }
            set { _CreatedTimeStamp = value; }
        }

        public long ModifierID
        {
            get { return _ModifierID; }
            set { _ModifierID = value; }
        }


        public DateTime ModifiedTimeStamp
        {
            get { return _ModifiedTimeStamp; }
            set { _ModifiedTimeStamp = value; }
        }

        #endregion

        public override string ToString()
        {
            string msg = "UserID" + ": " + UserID + "\n" +
                "SessionID" + ": " + SessionID + "\n" +
                "ClientHost" + ": " + ClientHost + "\n" +
                "ServerIP" + ": " + ServerIP + "\n" +
                "Service" + ": " + Service + "\n" +
                "Category" + ": " + Category + "\n" +
                "Priority" + ": " + Priority + "\n" +
                "LoggingTime" + ": " + LoggingTime + "\n" +
                "MessageSummary" + ": " + MessageSummary + "\n" +
                "MessageDetail" + ": " + MessageDetail + "\n" +
                "StackTrace" + ": " + StackTrace + "\n" +
                "CreatorID" + ": " + CreatorID + "\n" +
                "CreatedTimeStamp" + ": " + CreatedTimeStamp + "\n" +
                "ModifierID" + ": " + ModifierID + "\n" +
                "ModifiedTimeStamp" + ": " + ModifiedTimeStamp + "\n";

            if (InnerException != null)
            {
                if (!string.IsNullOrEmpty(InnerException.Message))
                    msg += "InnerException message: " + InnerException.Message + "\n";
                if (!string.IsNullOrEmpty(InnerException.Source))
                    msg += "InnerException source: " + InnerException.Source + "\n";
                if (!string.IsNullOrEmpty(InnerException.StackTrace))
                    msg += "InnerException stacktrace: " + InnerException.StackTrace + "\n";
            }
            return msg;
        }

    }
    #endregion
}
