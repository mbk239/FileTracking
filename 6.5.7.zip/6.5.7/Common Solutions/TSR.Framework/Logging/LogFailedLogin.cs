﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace TSR.Framework.Logging
{
    #region Log Entity    
    /// <summary>
    /// Class
    /// Name: LogFailedLogin    
    /// Description: Login failed entity class
    /// Added by tsrdev2 - hosted version
    /// </summary>
    [Serializable]
    [DataContract]
    public class LogFailedLogin
    {
        #region Variables
        private long _ID;
        private Int64 _UserID;
        private string _UserName;
        private DateTime _LoggingTime = DateTime.Now;
        private SourceType1 _Source ;
        private TypeOfEventEnum1 _TypeOfEvent;
        private String _ClientIP = String.Empty;
        private String _CustomerNo = String.Empty;
        private long _CreatorID;
        private DateTime _CreatedTimeStamp;
        private long _ModifierID;
        private DateTime _ModifiedTimeStamp = DateTime.Now;
        #endregion

        #region Properties
        [DataMember]
        public long ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember]
        public Int64 UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        [DataMember]
        public string UserName
        {
            get { return _UserName; }
            set { _UserName = value; }
        }
        [DataMember]
        public DateTime LoggingTime
        {
            get { return _LoggingTime; }
            set { _LoggingTime = value; }
        }
        [DataMember]
        public SourceType1 Source
        {
            get { return _Source; }
            set { _Source = value; }
        }
        [DataMember]
        public TypeOfEventEnum1 TyOfEvent
        {
            get { return _TypeOfEvent; }
            set { _TypeOfEvent = value; }
        }
        [DataMember]
        public String ClientIP
        {
            get { return _ClientIP; }
            set { _ClientIP = value; }
        }
        [DataMember]
        public String CustomerNo
        {
            get { return _CustomerNo; }
            set { _CustomerNo = value; }
        }
        [DataMember]
        public long CreatorID
        {
            get { return _CreatorID; }
            set { _CreatorID = value; }
        }
        [DataMember]
        public DateTime CreatedTimeStamp
        {
            get { return _CreatedTimeStamp; }
            set { _CreatedTimeStamp = value; }
        }
        [DataMember]
        public long ModifierID
        {
            get { return _ModifierID; }
            set { _ModifierID = value; }
        }
        [DataMember]
        public DateTime ModifiedTimeStamp
        {
            get { return _ModifiedTimeStamp; }
            set { _ModifiedTimeStamp = value; }
        }
        #endregion

        //----------------------------Method override string ToString--------------------------
        public override string ToString()
        {
            string msg = "UserID" + ": " + UserID + "\n" +
            "UserName" + ": " + UserName + "\n" +
            "LoggingTime" + ": " + LoggingTime + "\n" +
            "Source" + ": " + Source.ToString() + "\n" +
            "TypeOfEvent" + ": " + TyOfEvent.ToString() + "\n" +
            "ClientIP" + ": " + ClientIP + "\n" +
            "CustomerNo" + ": " + CustomerNo + "\n" +
            "CreatorID" + ": " + CreatorID + "\n" +
            "CreatedTimeStamp" + ": " + CreatedTimeStamp + "\n" +
            "ModifierID" + ": " + ModifierID + "\n" +
            "ModifiedTimeStamp" + ": " + ModifiedTimeStamp + "\n";
            return msg;
        }
        //------------------------------------END----------------------------------------------
    }
    #endregion
}

