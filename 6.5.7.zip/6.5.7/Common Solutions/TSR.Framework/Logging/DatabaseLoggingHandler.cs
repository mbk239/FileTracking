﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Specialized;
using TSR.Framework.Exceptions;

namespace TSR.Framework.Logging
{
    /// Class
    /// Name: DatabaseLoggingHandler
    /// Description: This is a custom Database Tracer which inherits from Trace Listener.
    /// The class store Log entity into Database.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    #region DatabaseLoggingHandler
    public class DatabaseLoggingHandler : TraceListener
    {
        #region Variables
        private const string COLUMN_SEPARATOR = "|";
        private string m_strConnectionString;
        //private int m_iMaximumRequests;
        private StringCollection m_objCollection;

        #endregion

        #region Constructors
        public DatabaseLoggingHandler()
        {
            InitializeHandler();
        }

        public DatabaseLoggingHandler(string _listenerName)
            : base(_listenerName)
        {
            InitializeHandler();
        }
        #endregion

        #region InitializeHandler
        /// <summary>
        /// Initialize Database handler
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        private void InitializeHandler()
        {
            //set connection string
            m_strConnectionString = ConfigurationBlock.ConnectionString;
            //m_iMaximumRequests = ConstantCollection.MAXIMUMREQUESTS;
            m_objCollection = new StringCollection();
        }
        #endregion

        #region Save Errors
        /// <summary>
        /// 
        /// </summary>
        private void SaveErrors()
        {

        }
        /// <summary>
        /// This methors is used to store Log entity into Data
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="_logObject">Log entity type object</param>
        private void SaveErrors(Log _logObject)
        {            
            SqlConnection connection = new SqlConnection(m_strConnectionString);
            try
            {
                //open database connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                throw new DatabaseConnectionException(ex);
            }
            
            SqlCommand command = connection.CreateCommand();
            command.CommandText = "InsertLog";
            command.CommandType = CommandType.StoredProcedure;
            long ID = -1;
            //Set parameters
            SqlParameter parameter = new SqlParameter("@ID", SqlDbType.BigInt);
            parameter.Value = ID;
            parameter.Direction = ParameterDirection.Output;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@UserID", SqlDbType.BigInt);
            parameter.Value = (_logObject.UserID==0)?1:_logObject.UserID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@SessionID", SqlDbType.Text);
            parameter.Value = _logObject.SessionID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ClientHost", SqlDbType.Text);
            parameter.Value = _logObject.ClientHost;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ServerIP", SqlDbType.Text);
            parameter.Value = _logObject.ServerIP;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@Service", SqlDbType.Text);
            parameter.Value = _logObject.Service;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@Category", SqlDbType.Text);
            parameter.Value = _logObject.Category;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@Priority", SqlDbType.Int);
            parameter.Value = _logObject.Priority;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@LoggingTime", SqlDbType.DateTime);
            parameter.Value = _logObject.LoggingTime;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@MessageSummary", SqlDbType.Text);
            parameter.Value = _logObject.MessageSummary;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@MessageDetail", SqlDbType.Text);
            parameter.Value = _logObject.MessageDetail;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@StackTrace", SqlDbType.Text);
            parameter.Value = _logObject.StackTrace;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatorID", SqlDbType.BigInt);
            parameter.Value = (_logObject.CreatorID == 0) ? 1 : _logObject.CreatorID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifierID", SqlDbType.BigInt);
            parameter.Value = (_logObject.ModifierID == 0) ? 1 : _logObject.ModifierID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifiedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@IsDeleted", SqlDbType.Bit);
            parameter.Value = false;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@MaxRecord", SqlDbType.BigInt);
            parameter.Value = TSR.Framework.ConfigurationBlock.MaxRecordLoggingDataBase;
            command.Parameters.Add(parameter);
            try
            {
                //execute to store Log entity object
                command.ExecuteNonQuery();
                if (command.Parameters["@ID"].Value != null)
                {
                    ID = Convert.ToInt64(command.Parameters["@ID"].Value);
                }

            }
            catch (Exception ex)   // ignore missing columns in the database
            {

            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
        }

        /// <summary>
        /// Store Log data into database by passing basic parameters
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="category"></param>
        /// <param name="description"></param>
        /// <param name="stackTrace"></param>
        /// <param name="errorDescription"></param>
        private void SaveErrors(string category,
            string description,
            string stackTrace,
            string errorDescription)
        {
            Log obj = new Log()
            {
                UserID = 1,
                CreatorID = 1,
                CreatedTimeStamp = DateTime.Now,
                Category = category,
                LoggingTime = DateTime.Now,
                MessageSummary = description,
                MessageDetail = errorDescription,
                StackTrace = stackTrace
            };

            SaveErrors(obj);
        }
        #endregion

        #region Override Methods
        public override void Write(string message)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors(string.Empty, message, objTrace.ToString(), string.Empty);
        }

        public override void Write(object o)
        {
            SaveErrors(o as Log);
        }

        public override void Write(string message, string category)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors(category, message, objTrace.ToString(), string.Empty);
        }

        public override void Write(object o, string category)
        {
            Log obj = o as Log;
            obj.Category = category;
            SaveErrors(obj);
        }


        public override void WriteLine(string message)
        {
            Write(message + "\n");
        }

        public override void WriteLine(object o)
        {
            Write(o);
        }

        public override void WriteLine(string message, string category)
        {
            Write((message + "\n"), category);
        }

        public override void WriteLine(object o, string category)
        {
            Write(o, category);
        }


        public override void Fail(string message)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors("Fail", message, objTrace.ToString(), string.Empty);
        }

        public override void Fail(string message, string detailMessage)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors("Fail", message, objTrace.ToString(), detailMessage);
        }

        public override void Close()
        {
            SaveErrors();
        }

        public override void Flush()
        {
            SaveErrors();
        }
        #endregion
    }
    #endregion

    /// Class
    /// Name: DatabaseLoggingHandler
    /// Description: This is a custom Database Tracer which inherits from Trace Listener.
    /// The class store Log entity into Database.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    #region DatabaseLoggingHandlerFailedLogin
    public class DatabaseLoggingHandlerFailedLogin : TraceListener
    {
        #region Variables        
        private string m_strConnectionString;
        //private int m_iMaximumRequests;
        private StringCollection m_objCollection;

        #endregion

        #region Constructors
        public DatabaseLoggingHandlerFailedLogin()
        {
            InitializeHandler();
        }

        public DatabaseLoggingHandlerFailedLogin(string _listenerName)
            : base(_listenerName)
        {
            InitializeHandler();
        }
        #endregion

        #region InitializeHandler
        /// <summary>
        /// Initialize Database handler
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        private void InitializeHandler()
        {
            //set connection string
            m_strConnectionString = ConfigurationBlock.ConnectionString;
            //m_iMaximumRequests = ConstantCollection.MAXIMUMREQUESTS;
            m_objCollection = new StringCollection();
        }
        #endregion

        #region Save Errors
        /// <summary>
        /// 
        /// </summary>
        private void SaveErrors()
        {

        }
        /// <summary>
        /// This methors is used to store Log entity into Data
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="_logObject">Log entity type object</param>
        private void SaveErrors(LogFailedLogin _logObject)
        {
            SqlConnection connection = new SqlConnection(m_strConnectionString);
            try
            {
                //open database connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = "InsertLogFailedLogin";
            command.CommandType = CommandType.StoredProcedure;
            long ID = -1;

            //Set Parameter:
            SqlParameter parameter = new SqlParameter("@ID", SqlDbType.BigInt);
            parameter.Value = ID;
            parameter.Direction = ParameterDirection.Output;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@UserID", SqlDbType.BigInt);
            parameter.Value = _logObject.UserID; 
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@Username", SqlDbType.Text);
            parameter.Value = _logObject.UserName;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@LoggingTime", SqlDbType.DateTime);
            parameter.Value = _logObject.LoggingTime;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@Source", SqlDbType.Int);
            parameter.Value = (int)_logObject.Source;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@TypeOfEvent", SqlDbType.Int);
            parameter.Value = (int)_logObject.TyOfEvent;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ClientIP", SqlDbType.Text);
            parameter.Value = _logObject.ClientIP;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CustomerNo", SqlDbType.Text);
            parameter.Value = string.IsNullOrEmpty(_logObject.CustomerNo) ? ConfigurationBlock.CustomerNo : _logObject.CustomerNo;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatorID", SqlDbType.BigInt);
            parameter.Value = (_logObject.CreatorID == 0) ? 1 : _logObject.CreatorID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifierID", SqlDbType.BigInt);
            parameter.Value = (_logObject.ModifierID == 0) ? 1 : _logObject.ModifierID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifiedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@IsDeleted", SqlDbType.Bit);
            parameter.Value = false;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@MaxEntryAge", SqlDbType.DateTime);
            parameter.Value = DateTime.Now.AddDays(Double.Parse("-" + TSR.Framework.ConfigurationBlock.MaxAgeLoggingEntryForFailedLogin.ToString()));
            command.Parameters.Add(parameter);
            try
            {
                //execute to store Log entity object
                command.ExecuteNonQuery();
                if (command.Parameters["@ID"].Value != null)
                {
                    ID = Convert.ToInt64(command.Parameters["@ID"].Value);
                }

            }
            catch (Exception ex)   // ignore missing columns in the database
            {

            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
        }              
        #endregion

        #region Override Methods
        public override void Write(string message)
        {
            //StackTrace objTrace = new StackTrace(true);
            //SaveErrors(string.Empty, message, objTrace.ToString(), string.Empty);
        }

        public override void Write(object o)
        {
            SaveErrors(o as LogFailedLogin);
        }

        public override void Write(string message, string category)
        {
            //StackTrace objTrace = new StackTrace(true);
            //SaveErrors(category, message, objTrace.ToString(), string.Empty);
        }

        public override void Write(object o, string category)
        {
            LogFailedLogin obj = o as LogFailedLogin;
            //obj.Category = category;
            SaveErrors(obj);
        }


        public override void WriteLine(string message)
        {
            Write(message + "\n");
        }

        public override void WriteLine(object o)
        {
            Write(o);
        }

        public override void WriteLine(string message, string category)
        {
            Write((message + "\n"), category);
        }

        public override void WriteLine(object o, string category)
        {
            Write(o, category);
        }


        public override void Fail(string message)
        {
            StackTrace objTrace = new StackTrace(true);
            //SaveErrors("Fail", message, objTrace.ToString(), string.Empty);
        } 

        public override void Fail(string message, string detailMessage)
        {
            StackTrace objTrace = new StackTrace(true);
            //SaveErrors("Fail", message, objTrace.ToString(), detailMessage);
        }

        public override void Close()
        {
            SaveErrors();
        }

        public override void Flush()
        {
            SaveErrors();
        }
        #endregion
    }
    #endregion
}
