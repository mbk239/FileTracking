using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;

namespace TSR.Framework.Logging
{
    /// Class
    /// Name: LoggingHandler
    /// Description: This is a custom Base Log Hangler
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class LoggingHandler
    {
        public static int m_nextFileIndex = 0;

        #region Methods

        public static void LogInfo(Log logObject)
        {
            logObject.Category = "Information";
            HandleException(logObject);
        }
        public static void LogWarning(Log logObject)
        {
            logObject.Category = "Warning";
            HandleException(logObject);
        }

        public static void LogError(Log logObject)
        {
            
            logObject.Category = "Error";
            logObject.MessageDetail = "Url: " + getCurrentRequestedUrl() + ";" + logObject.MessageDetail;
            HandleException(logObject);
        }
        public static void LogUnknownException(Exception e)
        {
            HandleException(e, "Unknown Exception");
        }
        public static void LogUnhandledException(Exception e)
        {
            HandleException(e, "Unhandled Exception");
        }

        /// <summary>
        /// This method logs unknown exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        public static void LogUnknownException(Log logObject)
        {
            
            logObject.MessageDetail = "Url: " + getCurrentRequestedUrl() + ";" + logObject.MessageDetail;
            logObject.Category = "Unknown Exception";
            HandleException(logObject);
        }

        /// <summary>
        /// This method logs unhandled exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        public static void LogUnhandledException(Log logObject)
        {
            
            logObject.Category = "Unhandled Exception";
            logObject.MessageDetail = "Url: " + getCurrentRequestedUrl() + ";" + logObject.MessageDetail;
            HandleException(logObject);
        }

        //added by tsrdev2
        /// <summary>
        /// logs failed login info.
        /// </summary>
        /// <param name="logObject"></param>
        public static void LogFailedLoginInfo(LogFailedLogin logObject)
        {
            //logObject.Category = "Unhandled Exception";
            //logObject.MessageDetail = "Url: " + getCurrentRequestedUrl() + ";" + logObject.MessageDetail;
            logObject.LoggingTime = DateTime.Now;      
           
            HandleExceptionFailedLogin(logObject);
        }


        /// <summary>
        /// The method logs handled exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        private static void HandleException(Log logObject)
        {
            if (TSR.Framework.ConfigurationBlock.EnabledLoggingFile)
            {
                ///Check AD authentication
                ///
                //System.Security.Principal.WindowsIdentity _identity= ADHelper.GetWindowsIdentity();
                //if (_identity != null)
                //{
                //    if (_identity.IsAuthenticated)
                //    {
                try
                {
                    string path = ConstantCollection.RollingFileName + "\\" + ConfigurationBlock.LoggingRollingFile;
                    string fullPath = Path.GetFullPath(path);
                    //string m_fileDir = Path.GetDirectoryName(fullPath);
                    string m_fileBase = Path.GetFileNameWithoutExtension(fullPath);
                    string m_fileExt = Path.GetExtension(fullPath);
                    ///Store Log entity object by RollingFileLoggingHandler
                    //using (RollingFileStream _rollingFileStream = new RollingFileStream("TSRLog\\" + ConfigurationBlock.LoggingRollingFile, Int32.MaxValue, 10, FileMode.Append))
                    RollingFileStream _rollingFileStream = new RollingFileStream(ConstantCollection.RollingFileName + "\\" + m_fileBase + m_nextFileIndex.ToString() + m_fileExt, TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024, 10, FileMode.Append);

                    if (_rollingFileStream.Length >= (TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024))
                    {
                        m_nextFileIndex++;
                        if (m_nextFileIndex > 9)
                        {
                            m_nextFileIndex = 0;
                            TSR.Framework.Logging.RollingFileStream.Storage.DeleteFile(ConstantCollection.RollingFileName + "\\" + m_fileBase + m_nextFileIndex.ToString() + m_fileExt);                            
                        }
                        else
                        {
                            TSR.Framework.Logging.RollingFileStream.Storage.DeleteFile(ConstantCollection.RollingFileName + "\\" + m_fileBase + m_nextFileIndex.ToString() + m_fileExt);
                        }
                        _rollingFileStream = new RollingFileStream(ConstantCollection.RollingFileName + "\\" + m_fileBase + m_nextFileIndex.ToString() + m_fileExt, TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024, 10, FileMode.Append);
                    }
                    _rollingFileStream.CanSplitData = true;
                    using (RollingFileLoggingHandler handler = new RollingFileLoggingHandler(_rollingFileStream))
                    {
                        Trace.AutoFlush = true;
                        Trace.Listeners.Add(handler);
                        Trace.WriteLine(logObject);
                        Trace.Listeners.Clear();
                    }
                    //if (handler != null)
                    //{
                    //    handler.Close();
                    //}
                    //if (_rollingFileStream != null)
                    //{
                    //    _rollingFileStream.Close();
                    //}

                }
                catch (Exception exp)
                {

                }
            }

            if (TSR.Framework.ConfigurationBlock.EnabledLoggingDataBase)
            {
                try
                {
                    ///Store Log entity object by DatabaseLoggingHandler
                    using (DatabaseLoggingHandler databaseHandler = new DatabaseLoggingHandler())
                    {
                        Trace.AutoFlush = true;
                        Trace.Listeners.Add(databaseHandler);
                        Trace.WriteLine(logObject);
                        Trace.Listeners.Clear();
                    }
                }
                catch (Exception exp)
                {

                }
            }
        }

        /// <summary>
        /// The method handles an exception with a policy
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="e">Exception type</param>
        /// <param name="policy">String type</param>
        private static void HandleException(Exception e, string policy)
        {
            
            Log logObject = new Log()
            {
                MessageSummary = e.Message,
                StackTrace = e.StackTrace,
                MessageDetail = "Url: " + getCurrentRequestedUrl() + ";"+  e.ToString(),
                Category = policy,
                UserID = 1,
                CreatedTimeStamp = DateTime.Now,
                CreatorID = 1,
                LoggingTime = DateTime.Now,
                Service = e.Source,
                Priority = 1,
                InnerException = ((e.InnerException != null) ? e.InnerException : null)
            };
            HandleException(logObject);
        }

        private static string getCurrentRequestedUrl()
        {
            if ((System.Web.HttpContext.Current != null)
                && (System.Web.HttpContext.Current.Request != null)
                && (System.Web.HttpContext.Current.Request.Url != null))
            {
                return System.Web.HttpContext.Current.Request.Url.ToString();
            }
            else
                return string.Empty;
        }

        //added by tsrdev2
        /// <summary>
        /// The method logs handled exception for failed login      
        /// </summary>
        /// <param name="logObject">LogFailedLogin entity type</param>
        private static void HandleExceptionFailedLogin(LogFailedLogin logObject)
        {
            if (TSR.Framework.ConfigurationBlock.EnabledLoggingFile && (logObject.TyOfEvent != TypeOfEventEnum1.Success))
            {                
                try
                {
                    string parentFolder = TSR.Framework.ConstantCollection.RollingFailedLoginFileName + "\\";
                    string path = parentFolder + ConfigurationBlock.LoggingFailedLoginFile;
                    string fullPath = Path.GetFullPath(path);
                    //string m_fileDir = Path.GetDirectoryName(fullPath);
                    string m_fileBase = Path.GetFileNameWithoutExtension(fullPath);
                    string m_fileExt = Path.GetExtension(fullPath);
                    ///Store Log entity object by RollingFileLoggingHandler
                    //using (RollingFileStream _rollingFileStream = new RollingFileStream("TSRLog\\" + ConfigurationBlock.LoggingRollingFile, Int32.MaxValue, 10, FileMode.Append))
                    RollingFileStream _rollingFileStream = new RollingFileStream(parentFolder + m_fileBase + m_fileExt, TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024, 10, FileMode.Append);

                    //if (_rollingFileStream.Length >= (TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024))
                    //{
                    //    m_nextFileIndex++;
                    //    if (m_nextFileIndex > 9)
                    //    {
                    //        m_nextFileIndex = 0;
                    //        TSR.Framework.Logging.RollingFileStream.Storage.DeleteFile(parentFolder + m_fileBase + m_nextFileIndex.ToString() + m_fileExt);
                    //    }
                    //    else
                    //    {
                    //        TSR.Framework.Logging.RollingFileStream.Storage.DeleteFile(parentFolder + m_fileBase + m_nextFileIndex.ToString() + m_fileExt);
                    //    }
                    //    _rollingFileStream = new RollingFileStream(parentFolder + m_fileBase + m_nextFileIndex.ToString() + m_fileExt, TSR.Framework.ConfigurationBlock.MaxSizeLoggingFile * 1024 * 1024, 10, FileMode.Append);
                    //}                    
                    _rollingFileStream.CanSplitData = true;
                    using (RollingFileLoggingHandler handler = new RollingFileLoggingHandler(_rollingFileStream))
                    {
                        Trace.AutoFlush = true;
                        Trace.Listeners.Add(handler);
                        Trace.WriteLine(logObject);
                        Trace.Listeners.Clear();
                    }    
                }
                catch (Exception exp)
                {

                }
            }

            if (true)//TSR.Framework.ConfigurationBlock.EnabledLoggingDataBase)
            {
                try
                {
                    ///Store Log entity object by DatabaseLoggingHandler
                    using (DatabaseLoggingHandlerFailedLogin databaseHandler = new DatabaseLoggingHandlerFailedLogin())
                    {
                        Trace.AutoFlush = true;
                        Trace.Listeners.Add(databaseHandler);
                        Trace.WriteLine(logObject);
                        Trace.Listeners.Clear();
                    }
                }
                catch (Exception exp)
                {

                }
            }
        }

        #endregion

    }
}
