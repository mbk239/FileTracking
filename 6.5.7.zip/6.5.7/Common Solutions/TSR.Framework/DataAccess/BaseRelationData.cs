using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;

namespace TSR.Framework
{
    /// <summary>
    /// Basic Relation Data access block for Relational objects.
    /// This abstract class exposes basic method to store and remove data.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public abstract class BaseRelationData : BaseDataAccess
    {
        public BaseRelationData(SqlTransaction transaction, UserContext context)
            : base(transaction, context) { }
        /// <summary>
        /// Add method which is common for sql insert for a data access of relational table.
        /// This abstract method may implement by child class. The method returns (Int64 type) ID
        /// by passing (Int64 type) parentID and childID parameters
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="parentID">(Int64 type) parentID of the object</param>
        /// <param name="childID">(Int64 type) parentID of the object</param>
        /// <returns>(Int64 type) ID of the object</returns>
        public abstract long Add(long parentID, long childID);
        /// <summary>
        /// Remove operation which is common for sql delete for a data access of relational table.
        /// This abstract method may implement by child class. The method returns an Int64 
        /// type no of affected rows by passing Int64 type parentID and childID parameters
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="parentID">(Int64 type) parentID of the object</param>
        /// <param name="childID">(Int64 type) parentID of the object</param>
        /// <returns>(Int64 type) no of affected rows</returns>
        public abstract long Remove(long parentID, long childID);
    }//End of abstract class BaseRelationData
}
