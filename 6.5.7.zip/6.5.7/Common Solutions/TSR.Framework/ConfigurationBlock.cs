using System;
using System.Collections;
using System.Web;
using System.Net.Configuration;
using System.Xml;
using TSR.Framework.Scheduling;


namespace TSR.Framework
{
    /// <summary>
    /// Summary description for ConfigurationBlock.
    /// Get or set values in the file web.config and xml file
    /// </summary>
    public sealed class ConfigurationBlock
    {
        private static Hashtable _hashtable = (Hashtable)AppDomain.CurrentDomain.GetData("Configuration");

        private static string _ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["TSRConnectionString"].ConnectionString;
        private static string _LoggingRollingFile = "TSRRollingFile.log"; //for the time being//System.Configuration.ConfigurationManager.AppSettings["LoggingRollingFile"];
        private static MailSettingsSectionGroup _MailSettings = null;
        //added by tsrdev2 - hosted version
        private static string _TSREntitiesConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["TSREntities"].ConnectionString;
        //AppDomain.CurrentDomain.BaseDirectory + System.Configuration.ConfigurationManager.AppSettings["LoggingRollingFile"];

        /// <summary>
        /// default constructor for class ConfigurationBlock
        /// </summary>
        public ConfigurationBlock()
        {
           
        }
        /// <summary>
        /// getting Connection string
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                if(System.Configuration.ConfigurationManager.ConnectionStrings["TSRConnectionString"]==null)
                {
                    throw new Exception("Connection string not configured");
                }
                return TSR.Framework.Cryptography.TripleDESCrypto.Decrypt(System.Configuration.ConfigurationManager.ConnectionStrings["TSRConnectionString"].ConnectionString);
                //return _ConnectionString;                 
            }
        }

        //added by tsrdev2 - hosted version
        /// <summary>
        /// getting Connection string
        /// </summary>
        public static string TSREntitiesConnectionString
        {
            get
            {
                if (System.Configuration.ConfigurationManager.ConnectionStrings["TSREntities"] == null)
                {
                    throw new Exception("Connection string not configured");
                }
                string connection = TSR.Framework.Cryptography.TripleDESCrypto.Decrypt(System.Configuration.ConfigurationManager.ConnectionStrings["TSREntities"].ConnectionString);                
                return connection.Replace("&quot;", "\"");
            }
        }

        /// <summary>
        /// getting Rolling LogFile
        /// </summary>
        public static string LoggingRollingFile
        {
            get
            {
                return _LoggingRollingFile;
            }
        }

        /// <summary>
        /// getting Mail Settings
        /// </summary>
        public static MailSettingsSectionGroup MailSettings
        {
            get
            {
                if (System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~\\Web.config") != null)
                    return System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("~\\Web.config").GetSectionGroup("system.net/Entities/Entity[@Name='MailServerSetting']") as MailSettingsSectionGroup;
                else
                    return null;
            }
        }

        //added by tsrdev2
        /// <summary>
        /// getting Mail Settings
        /// </summary>
        public static MailServerSetting MailSettingsXML
        {
            get
            {               
                string mailSettingFilePath = ConstantCollection.MailServerSettingFileName;                
                MailServerSetting mailSettingXML = new MailServerSetting(); 
                try
                {
                    XmlDocument _doc = new XmlDocument();
                    _doc.Load(mailSettingFilePath);
                    //gets from address
                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/from");
                    if (node != null)
                        mailSettingXML.From = node.InnerText.Trim();
                    else
                        mailSettingXML.From = "";
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/host");
                    if (node != null)
                        mailSettingXML.Host = node.InnerText.Trim();
                    else
                        mailSettingXML.Host = "";
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/port");
                    if (node != null)
                    {
                        int port;
                        int.TryParse(node.InnerText.Trim(), out port);
                        mailSettingXML.Port = port;
                    }
                    else
                        mailSettingXML.Port = 0;
                    //gets from address                    
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/username");
                    if (node != null)
                        mailSettingXML.UserName = Cryptography.TripleDESCrypto.Decrypt(node.InnerText.Trim());
                    else
                        mailSettingXML.UserName = "";
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/password");
                    if (node != null)
                        mailSettingXML.Password = Cryptography.TripleDESCrypto.Decrypt(node.InnerText.Trim());
                    else
                        mailSettingXML.Password = "";
                    //gets enableSsl
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/enableSsl");
                    if (node != null)
                        mailSettingXML.EnableSsl = node.InnerText.Trim().ToLower() == "true" ? true : false;
                    else
                        mailSettingXML.EnableSsl = false;
                    //gets anonymousLogin
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/anonymousLogin");
                    if (node != null)
                        mailSettingXML.AnonymousLogin = node.InnerText.Trim().ToLower() == "true" ? true : false;
                    else
                        mailSettingXML.AnonymousLogin = false;
                }
                catch (Exception xe)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(xe);
                    return null;
                }                
                return mailSettingXML;
            }
            set 
            {                
                MailServerSetting mailSettingXML = (MailServerSetting)value;

                string mailSettingFilePath = ConstantCollection.MailServerSettingFileName;
                XmlDocument _doc = new XmlDocument();
                try
                {
                    _doc.Load(mailSettingFilePath);
                    //string settingRoot = @"/Entities/Entity[@Name='MailServerSetting']";
                    XmlNode rootnode = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']");
                    if (rootnode == null)
                    {
                        XmlNode _nodeEntities = _doc.SelectSingleNode(@"/Entities");
                        rootnode = _doc.CreateNode(XmlNodeType.Element, "Entity", null);
                        XmlAttribute _nameAttb = _doc.CreateAttribute("Name");
                        _nameAttb.Value = "MailServerSetting";
                        rootnode.Attributes.Append(_nameAttb);
                        _nodeEntities.AppendChild(rootnode);
                        //_doc.AppendChild(rootnode);
                    }
                    //gets from address
                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/from");
                    if (node != null)
                        node.InnerText = mailSettingXML.From.Trim();
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "from", null);
                        fromNode.InnerText = mailSettingXML.From.Trim();
                        rootnode.AppendChild(fromNode);
                    }
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/host");
                    if (node != null)
                        node.InnerText = mailSettingXML.Host.Trim();
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "host", null);
                        fromNode.InnerText = mailSettingXML.Host.Trim();
                        rootnode.AppendChild(fromNode);
                    }
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/port");
                    if (node != null)
                        node.InnerText = mailSettingXML.Port.ToString().Trim();
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "port", null);
                        fromNode.InnerText = mailSettingXML.Port.ToString().Trim();
                        rootnode.AppendChild(fromNode);
                    }
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/username");
                    if (node != null)
                        node.InnerText = Cryptography.TripleDESCrypto.Encrypt(mailSettingXML.UserName.Trim());
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "username", null);
                        fromNode.InnerText = Cryptography.TripleDESCrypto.Encrypt(mailSettingXML.UserName.Trim());
                        rootnode.AppendChild(fromNode);
                    }
                    //gets from address
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/password");
                    if (node != null)
                        node.InnerText = Cryptography.TripleDESCrypto.Encrypt(mailSettingXML.Password.Trim());
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "password", null);
                        fromNode.InnerText = Cryptography.TripleDESCrypto.Encrypt(mailSettingXML.Password.Trim());
                        rootnode.AppendChild(fromNode);
                    }
                    //gets EnableSsl
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/enableSsl");
                    if (node != null)
                        node.InnerText = mailSettingXML.EnableSsl ? "true" : "false";
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "enableSsl", null);
                        fromNode.InnerText = mailSettingXML.EnableSsl ? "true" : "false";
                        rootnode.AppendChild(fromNode);
                    }

                    //gets anonymousLogin
                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='MailServerSetting']/anonymousLogin");
                    if (node != null)
                        node.InnerText = mailSettingXML.AnonymousLogin ? "true" : "false";
                    else
                    {
                        XmlNode fromNode = _doc.CreateNode(XmlNodeType.Element, "anonymousLogin", null);
                        fromNode.InnerText = mailSettingXML.AnonymousLogin ? "true" : "false";
                        rootnode.AppendChild(fromNode);
                    }

                    _doc.Save(mailSettingFilePath);
                }
                catch (Exception ex)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }
        }

        //added by tsrdev2
        /// <summary>
        /// gets license demo properties.
        /// </summary>
        public static DateTime LicenseDemoStartDate
        {
            get
            {
                bool isValid = false;
                string filePath = ConstantCollection.LicenseDemoFileName;
                DateTime startDate = DataTypeHelper.GetDateTimeValue(DateTime.MinValue);
                try
                {
                    XmlDocument _doc = new XmlDocument();
                    _doc.Load(filePath);
                    //gets start date
                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='LicenseDemo']/StartDate");
                    if (node != null && !string.IsNullOrEmpty(node.InnerText.Trim()))
                    {
                        string strDate = node.InnerText.Trim();
                        startDate = DataTypeHelper.GetDateTimeValue(strDate);                                   
                    }                    
                }
                catch (Exception xe)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(xe);
                    return startDate;
                }                
                return startDate;
            }
            set
            {
                DateTime startDate = DataTypeHelper.GetDateTimeValue(value);                
                string filePath = ConstantCollection.LicenseDemoFileName;                
                XmlDocument _doc = new XmlDocument();
                try
                {
                    _doc.Load(filePath);
                    XmlNode rootnode = _doc.SelectSingleNode(@"/Entities/Entity[@Name='LicenseDemo']");
                    if (rootnode == null)
                    {
                        XmlNode _nodeEntities = _doc.SelectSingleNode(@"/Entities");
                        rootnode = _doc.CreateNode(XmlNodeType.Element, "Entity", null);
                        XmlAttribute _nameAttb = _doc.CreateAttribute("Name");
                        _nameAttb.Value = "LicenseDemo";
                        rootnode.Attributes.Append(_nameAttb);
                        _nodeEntities.AppendChild(rootnode);
                    }
                    //gets start date
                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='LicenseDemo']/StartDate");
                    if (node != null)
                        node.InnerText = startDate.ToString("yyyy-MM-dd");
                    else
                    {
                        XmlNode startDateNode = _doc.CreateNode(XmlNodeType.Element, "StartDate", null);
                        startDateNode.InnerText = startDate.ToString("yyyy-MM-dd");
                        rootnode.AppendChild(startDateNode);
                    }

                    XmlNode endDateNode = _doc.SelectSingleNode(@"/Entities/Entity[@Name='LicenseDemo']/EndDate");
                    if (endDateNode == null)
                    {
                        endDateNode = _doc.CreateNode(XmlNodeType.Element, "EndDate", null);
                        endDateNode.InnerText = "";
                        rootnode.AppendChild(endDateNode);
                    }
                    _doc.Save(filePath);
                }
                catch (Exception ex)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }
        }

        /// <summary>
        /// Whether to display trace information or not, from configuration file
        /// </summary>
        public static bool DisplayTraceInformation
        {
            get
            {
                try
                {
                    bool value;
                    string config = "false";

                    if (System.Configuration.ConfigurationManager.AppSettings["DisplayTraceInformation"] != null)
                    {
                        config = System.Configuration.ConfigurationManager.AppSettings["DisplayTraceInformation"].ToString();
                    }

                    if (Boolean.TryParse(config, out value))
                    {
                        return value;
                    }
                    else
                    {
                        return false;
                    }
                }
                catch
                {
                    return false;
                }
            }
        }

        public static bool EnabledLoggingFile
        {
            get
            {
                bool b = true;
                if (System.Configuration.ConfigurationManager.AppSettings["EnabledLoggingFile"] == null)
                {
                    b = true;
                }
                else
                {
                    string s = System.Configuration.ConfigurationManager.AppSettings["EnabledLoggingFile"];
                    try
                    {
                        b = bool.Parse(s);
                    }
                    catch { }
                }
                return b;
            }
        }

        public static bool EnabledLoggingDataBase
        {
            get
            {
                bool b = true;
                if (System.Configuration.ConfigurationManager.AppSettings["EnabledLoggingDataBase"] == null)
                {
                    b = true;
                }
                else
                {
                    string s = System.Configuration.ConfigurationManager.AppSettings["EnabledLoggingDataBase"];
                    try
                    {
                        b = bool.Parse(s);
                    }
                    catch { }
                }
                return b;
            }
        }

        public static Int64 MaxSizeLoggingFile
        {
            get 
            {
                Int64 maxSize = 100;
                if (System.Configuration.ConfigurationManager.AppSettings["MaxSizeLoggingFile"] == null)
                {
                    
                }
                else
                {
                    maxSize = Int64.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxSizeLoggingFile"]);
                }
                return maxSize;
            }
        }

        public static Int64 MaxRecordLoggingDataBase
        {
            get
            {
                Int64 maxRecord = 1000;
                if (System.Configuration.ConfigurationManager.AppSettings["MaxRecordLoggingDataBase"] == null)
                {
                    
                }
                else
                {
                    maxRecord = Int64.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxRecordLoggingDataBase"]);
                }
                return maxRecord;
            }
        }

        /// <summary>
        /// Return CustomerNo
        /// </summary>
        //Added by tsrdev2 - hosted version
        public static String CustomerNo
        {
            get
            {
                string customerNo = string.Empty;
                if (System.Configuration.ConfigurationManager.AppSettings["CustomerNo"] != null)                
                {
                    customerNo = System.Configuration.ConfigurationManager.AppSettings["CustomerNo"].ToString();
                }
                return customerNo;
            }
        }
        
        //added by tsrdev2 - hosted version
        /// <summary>
        /// Gets value of max age of failed login.
        /// </summary>
        public static Double MaxAgeLoggingEntryForFailedLogin
        {
            get
            {
                Double maxAge = 180; //defaule value
                if (System.Configuration.ConfigurationManager.AppSettings["MaxAgeLoggingEntryForFailedLogin"] == null)
                {
                    maxAge = 180;
                }
                else
                {
                    maxAge = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxAgeLoggingEntryForFailedLogin"]);
                }
                return maxAge;
            }
        }
         /// <summary>
        /// Return file name of log for failedlogin
        /// </summary>
        //Added by tsrdev2 - hosted version
        public static String LoggingFailedLoginFile
        {
            get
            {
                string loggingFailedLoginFile = string.Empty;
                if (System.Configuration.ConfigurationManager.AppSettings["LoggingFailedLoginFile"] != null)                
                {
                    loggingFailedLoginFile = System.Configuration.ConfigurationManager.AppSettings["LoggingFailedLoginFile"].ToString();
                }
                return loggingFailedLoginFile;
            }
        }

        /// <summary>
        /// The value that is number of previous days from current day to specify which the timesheets that will be displayed in the List timesheet page
        /// Apply to Mobile version
        /// </summary>
        public static int NumberOfPreviousDaysOnMobile
        {
            get
            {
                int preDays = 14;
                if (System.Configuration.ConfigurationManager.AppSettings["NumberOfPreviousDaysOnMobile"] != null)
                {
                    if (int.TryParse(System.Configuration.ConfigurationManager.AppSettings["NumberOfPreviousDaysOnMobile"].ToString(), out preDays))
                        return preDays;
                }
                return 14;
            }
        }

        /// <summary>
        /// The value is time-out value of the sql command, system default is 30 seconds        
        /// </summary>
        public static int SQLCommandTimeout
        {
            get
            {
                int df = 45;
                if (System.Configuration.ConfigurationManager.AppSettings["SQLCommandTimeout"] != null)
                {
                    if (int.TryParse(System.Configuration.ConfigurationManager.AppSettings["SQLCommandTimeout"].ToString(), out df))
                        return df;
                }
                return df;
            }
        }

        public static DownloadOUAProperties DownloadOUAXml
        {
            get
            {
                string xmlSettingFilePath = ConstantCollection.MailServerSettingFileName;
                DownloadOUAProperties downloadOUA = new DownloadOUAProperties();

                try
                {
                    XmlDocument _doc = new XmlDocument();
                    _doc.Load(xmlSettingFilePath);

                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urlroot");
                    if (node != null)
                        downloadOUA.UrlRoot = node.InnerText.Trim();
                    else
                        downloadOUA.UrlRoot = "";

                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urlinstallationguide");
                    if (node != null)
                        downloadOUA.UrlInstallationGuide = node.InnerText.Trim();
                    else
                        downloadOUA.UrlInstallationGuide = "";

                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urldownload");
                    if (node != null)
                        downloadOUA.UrlDownload = node.InnerText.Trim();
                    else
                        downloadOUA.UrlDownload = "";
                }
                catch (Exception ex)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
                    return null;
                }

                return downloadOUA;
            }
            set
            {
                string xmlSettingFilePath = ConstantCollection.MailServerSettingFileName;
                DownloadOUAProperties downloadOUA = (DownloadOUAProperties)value;

                try
                {
                    XmlDocument _doc = new XmlDocument();
                    _doc.Load(xmlSettingFilePath);

                    XmlNode rootnode = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']");
                    if (rootnode == null)
                    {
                        XmlNode _nodeEntities = _doc.SelectSingleNode(@"/Entities");
                        rootnode = _doc.CreateNode(XmlNodeType.Element, "Entity", null);
                        XmlAttribute _nameAttb = _doc.CreateAttribute("Name");
                        _nameAttb.Value = "ConstantDownloadOUA";
                        rootnode.Attributes.Append(_nameAttb);
                        _nodeEntities.AppendChild(rootnode);
                    }

                    XmlNode node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urlroot");
                    if (node != null)
                        node.InnerText = downloadOUA.UrlRoot.Trim();
                    else
                    {
                        XmlNode urlRootNode = _doc.CreateNode(XmlNodeType.Element, "urlroot", null);
                        urlRootNode.InnerText = downloadOUA.UrlRoot.Trim();
                        rootnode.AppendChild(urlRootNode);
                    }

                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urlinstallationguide");
                    if (node != null)
                        node.InnerText = downloadOUA.UrlInstallationGuide.Trim();
                    else
                    {
                        XmlNode urlInstallNode = _doc.CreateNode(XmlNodeType.Element, "urlinstallationguide", null);
                        urlInstallNode.InnerText = downloadOUA.UrlInstallationGuide.Trim();
                        rootnode.AppendChild(urlInstallNode);
                    }

                    node = _doc.SelectSingleNode(@"/Entities/Entity[@Name='ConstantDownloadOUA']/urldownload");
                    if (node != null)
                        node.InnerText = downloadOUA.UrlDownload.Trim();
                    else
                    {
                        XmlNode urlDownloadNode = _doc.CreateNode(XmlNodeType.Element, "urldownload", null);
                        urlDownloadNode.InnerText = downloadOUA.UrlDownload.Trim();
                        rootnode.AppendChild(urlDownloadNode);
                    }
                }
                catch (Exception ex)
                {
                    TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }
        }
    }
}
