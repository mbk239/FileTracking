using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;


namespace TSR.Framework
{
    /// <summary>
    /// Class
    /// Name: BaseManager
    /// Description: This class is a custom Business Manager
    /// who inherits Security.ClassSecurity,
    /// imeplements IDisposable and handles Business Manager 
    /// related properties & functions for Business Logic Layer
    /// </summary>
    public abstract class BaseManager : Security.BaseSecuredClass, IDisposable
    {
        private SqlTransaction _Transaction;

        /// <summary>
        /// Transaction for the whole class
        /// </summary>
        public SqlTransaction Transaction
        {
            get { return _Transaction; }
        }

        #region Constructors
        
        public BaseManager(UserContext context)
            : base(context) { }

        public BaseManager(SqlTransaction transaction, UserContext context)
            : this(context)
        {
            _Transaction = transaction;
        }

        #endregion
        

        #region IDisposable Members

        void IDisposable.Dispose()
        {
        }

        #endregion
    }
}
