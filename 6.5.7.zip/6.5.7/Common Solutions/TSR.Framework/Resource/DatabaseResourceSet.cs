using System;
using System.Collections;
using System.Text;
using System.Resources;
using System.Globalization;
using System.Data.SqlClient;

namespace TSR.Framework.Resource
{
    /// <summary>
    /// Class
    /// Name: DatabaseResourceSet
    /// Description: This class is a custom Database ResourceSet 
    /// which inherites ResourceSet & handles 
    /// ResourceSet related properties & methods.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class DatabaseResourceSet : ResourceSet
    {
        internal DatabaseResourceSet
           (string connectionString, CultureInfo culture)
            : base(new DatabaseResourceReader(connectionString, culture))
        {
        }

        public override Type GetDefaultReader()
        {
            return typeof(DatabaseResourceReader);
        }
    }
}
