using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Globalization;

namespace TSR.Framework.Resource
{
    /// <summary>
    /// Class
    /// Name: ResourcePool
    /// Description: This class is a custom ResourceContainer List 
    /// who handles ResourceContainer related properties & functions.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    [Serializable]
    public class ResourcePool : List<ResourceContainer>
    {
        /// <summary>
        /// this Property gets the resource container based on name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ResourceContainer this[string name]
        {
            get
            {
                ResourceContainer rc = FindByName(name);
                if (rc == null)
                {
                    rc = new ResourceContainer(new CultureInfo(name));
                    Add(rc);
                }
                return rc;
            }
        }

        /// <summary>
        /// this property gets the resource container by culture info
        /// </summary>
        /// <param name="ci"></param>
        /// <returns></returns>
        public ResourceContainer this[CultureInfo ci]
        {
            get
            {
                ResourceContainer rc = FindByName(ci.Name);
                if (rc == null)
                {
                    rc = new ResourceContainer(ci);
                    Add(rc);
                }
                return rc;
            }
        }

        /// <summary>
        /// Method: FindByName finds resource container based on the name supplied as parameter
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public ResourceContainer FindByName(string name)
        {
            return Find(delegate(ResourceContainer rc) { return rc.Name == name; });
        }
    }//end od class ResourcePool

    /// <summary>
    /// Class
    /// Name: ResourceContainer
    /// Description: This class is a custom NameValueCollection.
    /// It is a Container for store a resource information.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    [Serializable]
    public class ResourceContainer : NameValueCollection
    {
        private CultureInfo _CultureInfo;

        /// <summary>
        /// Gets the Culture info
        /// </summary>
        public CultureInfo CultureInfo
        {
            get { return _CultureInfo; }
        }

        /// <summary>
        /// Gets the display name of the Culture
        /// </summary>
        public string DisplayName
        {
            get { return _CultureInfo.DisplayName; }
        }

        /// <summary>
        /// Gets the name of the current cunture
        /// </summary>
        public string Name
        {
            get { return _CultureInfo.Name; }
        }

        /// <summary>
        /// The constructor
        /// </summary>
        /// <param name="info"> an object of CultureInfo type</param>
        public ResourceContainer(CultureInfo info)
        {
            if (info == null)
                throw new NullReferenceException();

            _CultureInfo = info;
        }
    } // end of the class ResourceContainer
}
