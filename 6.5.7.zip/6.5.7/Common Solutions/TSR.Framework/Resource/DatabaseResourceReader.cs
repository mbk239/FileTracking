using System;
using System.Collections;
using System.Text;
using System.Resources;
using System.Globalization;
using System.Data.SqlClient;
using System.Data;
using TSR.Framework.Exceptions;

namespace TSR.Framework.Resource
{
    /// <summary>
    /// Class
    /// Name: DatabaseResourceReader
    /// Description: This class is a custom ResourceReader 
    /// who implements IResourceReader & handles 
    /// ResourceReader related properties & methods.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class DatabaseResourceReader : IResourceReader
    {
        private string _ConnectionString;
        private string _Language;

        public DatabaseResourceReader
           (string connectionString, CultureInfo culture)
        {
            this._ConnectionString = connectionString;
            this._Language = culture.Name;
        }

        /// <summary>
        /// Get Resource Collection
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <returns>IDictionaryEnumerator type</returns>
        public System.Collections.IDictionaryEnumerator GetEnumerator()
        {
            Hashtable dict = new Hashtable();
            if (String.IsNullOrEmpty(_Language))
                _Language = "Default";

            SqlConnection connection = new SqlConnection(_ConnectionString);//create new SqlConnection
            SqlCommand command = connection.CreateCommand();//create new command

            command.CommandText = "GetAllLanguageResourcesByLanguageId";//Set the command text
            command.CommandType = CommandType.StoredProcedure; //set command type
            SqlParameter parameter = new SqlParameter("@LanguageID", SqlDbType.VarChar, 50); //create parameter
            parameter.Value = _Language; //add the parameter value
            command.Parameters.Add(parameter); //add the parameter to the command
            int outer = 0, inner = 0;
            try
            {
                try
                {
                    connection.Open();//open connection
                }
                catch (SqlException ex)
                {
                    Logging.LoggingHandler.LogUnhandledException(ex);
                    throw new DatabaseConnectionException(ex);
                }
              
                SqlDataReader reader = command.ExecuteReader(); // execute the stored-procedure
                while (reader.Read())
                {
                    if (reader["ResourceKey"] != System.DBNull.Value) // if resource key is not null
                    {
                        if (!dict.ContainsKey(reader["ResourceKey"].ToString())) // if the resource is not in the current collection
                        {
                            dict.Add(reader["ResourceKey"].ToString(), reader["ResourceValue"].ToString()); // add the resource to collection
                            inner++;
                        }
                        
                    }
                    outer++;
                }

                reader.Close(); // 
            }
            catch(Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                connection.Close(); // close the connection to the database.
            }
            return dict.GetEnumerator(); // return the resource collection
        }

        public void Close()
        {
        }

        /// <summary>
        /// Method: IEnumerable.GetEnumerator
        /// Gets the IEnumerators of the current context
        /// </summary>
        /// <returns></returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        void IDisposable.Dispose()
        {
        }
    }
}
