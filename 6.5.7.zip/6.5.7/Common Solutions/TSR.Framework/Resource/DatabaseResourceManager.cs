using System;
using System.Collections;
using System.Text;
using System.Resources;
using System.Globalization;
using System.Data.SqlClient;

namespace TSR.Framework.Resource
{
    /// <summary>
    /// Class
    /// Name: DatabaseResourceManager
    /// Description: This class is a custom ResourceManager which inherites from ResourceManager
    /// who handles ResourceManager related properties & methods.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>/// </summary>
    public class DatabaseResourceManager
          : System.Resources.ResourceManager
    {
        private string _ConnectionString;

        public DatabaseResourceManager()
        {
            this._ConnectionString = ConfigurationBlock.ConnectionString;
            ResourceSets = new Hashtable();
        }
        /// <summary>
        /// overrite InternalGetResourceSet method
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="createIfNotExists"></param>
        /// <param name="tryParents"></param>
        /// <returns></returns>
        protected override ResourceSet InternalGetResourceSet(
              CultureInfo culture, bool createIfNotExists, bool tryParents)
        {
            DatabaseResourceSet rs = null;

            if (ResourceSets.Contains(culture.Name))
            {
                rs = ResourceSets[culture.Name] as DatabaseResourceSet;
            }
            else
            {
                rs = new DatabaseResourceSet(_ConnectionString, culture);
                ResourceSets.Add(culture.Name, rs);
            }
            return rs;
        }
        /// <summary>
        /// override GetResourceSet method
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="createIfNotExists"></param>
        /// <param name="tryParents"></param>
        /// <returns></returns>
        public override ResourceSet GetResourceSet(CultureInfo culture, bool createIfNotExists, bool tryParents)
        {
            return base.GetResourceSet(culture, createIfNotExists, tryParents);
        }
    }
}
