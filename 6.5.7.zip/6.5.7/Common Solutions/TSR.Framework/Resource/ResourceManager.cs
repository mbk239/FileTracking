using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using System.Threading;
using TSR.Framework.Exceptions;
using System.Collections.Specialized;

namespace TSR.Framework.Resource
{
    /// <summary>
    /// Class
    /// Name: ResourceManager
    /// Description: This class is a static Class 
    /// handles some static properties & functions to manage resources.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public static class ResourceManager
    {
        //private static ResourcePool _ResourceStateBag
        //{
        //    get
        //    {
        //        ResourcePool rp = HttpContext.Current.Application[ConstantCollection.RESOURCEPOOLKEY] as ResourcePool;
        //        if (rp == null)
        //        {
        //            rp = new ResourcePool();
        //            HttpContext.Current.Application.Add(ConstantCollection.RESOURCEPOOLKEY, rp);
        //        }
        //        return rp;
        //    }
        //}
        const string GETALLLANGUAGERESOURCES = "GetAllLanguageResources";
        const string UPDATELANGUAGENAMEFORNULL = "UpdateLanguageNameForNull";
        const string GETALLLANGUAGEIDS = "GetAllLanguageIDsForLanguageNameIsNull";
        const string DEFAULT_LANGUAGE = ConstantCollection.LANGUAGENAME_DEFAULT;
        const string DEFAULT_LANGUAGEID = ConstantCollection.LANGUAGEID_DEFAULT;

        const string COLUMN_LANGUAGEID = "LanguageID";
        const string COLUMN_LANGUAGENAME = "LanguageName";
        const string COLUMN_RESOURCEKEY = "ResourceKey";
        const string COLUMN_RESOURCEVALUE = "ResourceValue";

        /// <summary>
        /// Get Resource String by passing key, defaultvalue and culture.
        /// Default value is used as fallback resource value.
        /// </summary>
        /// <param name="key"></param>
        /// <param name="defaultValue"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public static string GetResourceString(string key, string defaultValue, string languageName, string languageID)
        {
            //DatabaseResourceManager dbrm = new DatabaseResourceManager();
            //dbrm.IgnoreCase = true;
            if (String.IsNullOrEmpty(languageName) || String.IsNullOrEmpty(languageID))
            {
                languageName = DEFAULT_LANGUAGE;
                languageID = DEFAULT_LANGUAGEID;
            }            
            //List<string> existedKeys = GetAllResourceKeyByName(languageName);
            //foreach (string existedKey in existedKeys)
            //{
            //    if (existedKey.ToLower(new CultureInfo("en")).Equals(key.ToLower(new CultureInfo("en"))))
            //    {
            //        key = existedKey;
            //        break;
            //    }
            //}
            //string value = dbrm.GetString(key, culture);
            int rowCount = 0;
            string value = GetResourceValue(key, languageName, out rowCount); //key: ignore case
            if (rowCount == 0)//(string.IsNullOrEmpty(value))
            {                 
                //if languageName is not 'English'                
                if (languageName != DEFAULT_LANGUAGE)
                {
                    //get resValue of English
                    rowCount = 0;
                    value = GetResourceValue(key, DEFAULT_LANGUAGE, out rowCount);
                }
                if (rowCount == 0)//(string.IsNullOrEmpty(value))
                {
                    value = defaultValue;
                    //add to US English
                    AddLanguageResource(DEFAULT_LANGUAGEID, DEFAULT_LANGUAGE, key, value);
                    if (languageName != DEFAULT_LANGUAGE)
                    {
                        //add to current language
                        AddLanguageResource(languageID, languageName, key, value);
                    }
                }               
            }
            return value;
        }

        /// <summary>
        /// gets resource value by key and language name
        /// added by tsrdev2
        /// </summary>
        /// <param name="key"></param>
        /// <param name="langName"></param>
        /// <returns></returns>
        private static string GetResourceValue(string key, string langName, out int rowCount)
        {
            rowCount = 0;
            string values = string.Empty;
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = "GetLanguageResourcesByKeyAndLanguageName";
            command.CommandType = CommandType.StoredProcedure;
            ///set parameters                        
            SqlParameter parameter = new SqlParameter("@LanguageName", SqlDbType.NVarChar, 200);
            parameter.Value = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(langName);
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ResourceKey", SqlDbType.NVarChar);
            parameter.Value = key;
            command.Parameters.Add(parameter);
            try
            {
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            if (reader.GetName(i) == COLUMN_RESOURCEVALUE)
                            {
                                values = reader.GetValue(i).ToString();
                                rowCount++;
                                break;
                            }                            
                        }                        
                    }

                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return values;
        }

        //added by tsrdev 03 Nov 2010
        /// <summary>
        /// 
        /// </summary>
        /// <param name="langID"></param>
        /// <param name="langName"></param>
        /// <returns></returns>
        public static NameValueCollection GetAllResourcesByLanguage(string langName)
        {
            return new NameValueCollection();
        }

        //added by tsrdev2 - 04 Nov 2010
        /// <summary>
        /// gets all resource include: language name, key and value
        /// </summary>
        /// <returns></returns>
        public static NameValueCollection GetAllResources()
        {
            NameValueCollection resources = new NameValueCollection();
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = GETALLLANGUAGERESOURCES;
            command.CommandType = CommandType.StoredProcedure;
            ///no parameters                                    
            try
            {
                SqlDataReader reader = command.ExecuteReader();                
                using (reader)
                {                    
                    while (reader.Read())
                    {
                        string languageID = string.Empty;
                        string languageName = string.Empty;
                        string resKey = string.Empty;
                        string resValue = string.Empty;

                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            switch (reader.GetName(i))
                            {
                                case COLUMN_LANGUAGEID:
                                    languageID = reader.GetValue(i).ToString();
                                    break;
                                case COLUMN_LANGUAGENAME:
                                    languageName = TSR.Framework.BaseBusinessEntity.ReverseToHTMLCode(reader.GetValue(i).ToString());
                                    break;
                                case COLUMN_RESOURCEKEY:
                                    resKey = reader.GetValue(i).ToString();
                                    break;
                                case COLUMN_RESOURCEVALUE:
                                    resValue = reader.GetValue(i).ToString();
                                    break;
                                default:
                                    break;
                            }                         
                        }
                        string languageNameAndKey = "[" + languageName + "]" + resKey;
                        
                        resources.Add(languageNameAndKey, resValue);
                    }

                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return resources;
        }

        /// <summary>
        /// gets language id by language name
        /// added by tsrdev2
        /// </summary>        
        /// <param name="langName"></param>
        /// <returns></returns>
        public static string GetLanguageIDByLanguageName(string langName)
        {
            string languageID = string.Empty; // is default
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = "GetLanguageIDByLanguageName";
            command.CommandType = CommandType.StoredProcedure;
            ///set parameters                        
            SqlParameter parameter = new SqlParameter("@LanguageName", SqlDbType.NVarChar, 200);
            parameter.Value = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(langName);
            command.Parameters.Add(parameter);           
            try
            {
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    while (reader.Read())
                    {
                        languageID = reader.GetString(0);
                        break;
                        //for (int i = 0; i < reader.FieldCount; i++)
                        //{
                        //    if (reader.GetName(i) == COLUMN_LANGUAGEID)
                        //    {
                        //        languageID = reader.GetValue(i).ToString();
                        //        break;
                        //    }
                        //}
                        //if (!string.IsNullOrEmpty(languageID))
                        //    break;                        
                    }

                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return languageID;
        }

        /// <summary>
        /// gets all resources key of the language
        /// added by tsrdev2
        /// </summary>
        /// <param name="languageName">current language name</param>
        /// <returns>all keys</returns>
        //private static List<string> GetAllResourceKeyByName(string languageName)
        //{
        //    List<string> keys = new List<string>();
        //    SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
        //    try
        //    {
        //        ///open connection
        //        connection.Open();
        //    }
        //    catch (SqlException ex)
        //    {
        //        Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
        //        throw new DatabaseConnectionException(ex);
        //    }

        //    SqlCommand command = connection.CreateCommand();
        //    command.CommandText = "GetAllLanguageResourcesByLanguageName";
        //    command.CommandType = CommandType.StoredProcedure;            
        //    ///set parameters                        
        //    SqlParameter parameter = new SqlParameter("@LanguageName", SqlDbType.NVarChar, 200);
        //    parameter.Value = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(languageName);
        //    command.Parameters.Add(parameter);
        //    try
        //    {
        //        SqlDataReader reader = command.ExecuteReader();
        //        using (reader)
        //        {
        //            while (reader.Read())
        //            {
        //                keys.Add(reader.GetString(3));
        //            }

        //            // Close the reader in order to receive output parameters
        //            // Output parameters are not available until reader is closed.
        //            reader.Close();
        //        }
        //    }
        //    catch (Exception ex)   // ignore missing columns in the database
        //    {
        //        Logging.LoggingHandler.LogUnhandledException(ex); // log the error
        //        System.Diagnostics.Debug.WriteLine(ex.Message);
        //    }
        //    finally
        //    {
        //        if (connection != null)
        //        {
        //            //close connection
        //            connection.Close();
        //        }
        //    }
        //    return keys;
        //}
        /// <summary>
        /// Get Resource value by passing key and defaultvalue of current culture 
        /// </summary>
        /// <param name="key">resource key</param>
        /// <param name="defaultValue"></param>
        /// <returns>resource value</returns>
        public static string GetResourceString(string key, string defaultValue)
        {
            //TSR.Framework.Logging.Log log = new TSR.Framework.Logging.Log();
            //log.MessageSummary = key + ":: Get Resource, Begin: " + DateTime.Now.ToString("hh:mm:ss") + ":" + DateTime.Now.Millisecond.ToString();            
          try
            {
                if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(defaultValue))
                {
                    return string.Empty;
                }
                string value = string.Empty;

                //gets resource value by service
                value = GetResourceValueByApplication(key);

                if (string.IsNullOrEmpty(value))
                {
                    string langName = GetLanguageName();
                    value = GetResourceString(key, defaultValue, langName, GetLanguageIDByLanguageName(langName));
                }
                return value;
            }
            catch
            {
                return defaultValue;
            }
            //log.MessageSummary += ", End: " + DateTime.Now.ToString("hh:mm:ss") + ":" + DateTime.Now.Millisecond.ToString();
            //TSR.Framework.Logging.LoggingHandler.LogInfo(log);
            //return value;
            
            #region Previous Code Blocks
            //DatabaseResourceManager dbrm = new DatabaseResourceManager();
            //string value = dbrm.GetString(key, GetPrefferedCI());
            //if (String.IsNullOrEmpty(value))
            //{   
            //    SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            //    SqlCommand command = connection.CreateCommand();

            //    command.CommandText = "InsertLanguageResources";
            //    command.CommandType = CommandType.StoredProcedure;
            //    long ID = -1;
            //    SqlParameter parameter = new SqlParameter("@ID", SqlDbType.BigInt);
            //    parameter.Value = ID;
            //    parameter.Direction = ParameterDirection.Output;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@LanguageID", SqlDbType.VarChar, 50);
            //    parameter.Value = GetPrefferedCI().TwoLetterISOLanguageName;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@ResourceKey", SqlDbType.Text);
            //    parameter.Value = key;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@ResourceValue", SqlDbType.Text);
            //    parameter.Value = defaultValue;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@CreatorID", SqlDbType.BigInt);
            //    parameter.Value = 1;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@CreatedTimeStamp", SqlDbType.DateTime);
            //    parameter.Value = DateTime.Now;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@ModifierID", SqlDbType.BigInt);
            //    parameter.Value = 1;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@ModifiedTimeStamp", SqlDbType.DateTime);
            //    parameter.Value = DateTime.Now;
            //    command.Parameters.Add(parameter);
            //    parameter = new SqlParameter("@IsDeleted", SqlDbType.Bit);
            //    parameter.Value = false;
            //    command.Parameters.Add(parameter);
            //    try
            //    {
            //        connection.Open();

            //        command.ExecuteNonQuery();
            //        if (command.Parameters["@ID"].Value!=null)
            //        {
            //            ID = Convert.ToInt64(command.Parameters["@ID"].Value);
            //        }
            //        if (ID > -1)
            //        {
            //            return defaultValue;
            //        }
            //    }
            //    catch   // ignore missing columns in the database
            //    {

            //    }
            //    finally
            //    {
            //        connection.Close();
            //    }
            //    return "Missing Resource Value";
            //}
            //return value; 
            #endregion
        }

        //added by tsrdev2
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static string GetResourceValueByApplication(string key)
        {
            NameValueCollection resources = new NameValueCollection();
            if (HttpContext.Current != null && HttpContext.Current.Application != null) // if the current session is not null
            {
                if (HttpContext.Current.Application[ConstantCollection.APPLICATION_ALLRESOURCES] == null) //if CULTUREINFOSESSIONKEY is not null
                {                    
                    //string languageID = GetLanguageIDByLanguageName(languageName);
                    NameValueCollection AllResources = GetAllResources();

                    HttpContext.Current.Application.Lock();
                    HttpContext.Current.Application[ConstantCollection.APPLICATION_ALLRESOURCES] = AllResources;
                    HttpContext.Current.Application.UnLock();
                }
                resources = (NameValueCollection)HttpContext.Current.Application[ConstantCollection.APPLICATION_ALLRESOURCES];
            }
            string languageName = GetLanguageName();
            string fullKey = "[" + languageName + "]" + key;
            string[] value = resources.GetValues(fullKey);
            if (value != null && value.Length > 0)
            {
                return value[0];
            }
            else return string.Empty;
        }


        /// <summary>
        /// Get Preffered Culture
        /// </summary>
        private static CultureInfo GetPrefferedCI()
        {
            CultureInfo culture = new CultureInfo("en-US"); //send en-US as the Default value 
            if (Thread.CurrentThread.CurrentUICulture != null) // if the current culture is not null
            {
                //if (HttpContext.Current.Session != null) // if the current session is not null
                //{
                //    if (HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY] != null) //if CULTUREINFOSESSIONKEY is not null
                //    {
                //        if (!String.IsNullOrEmpty(HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY].ToString()))
                //        {
                //            // if CULTUREINFOSESSIONKEY and CurrentUICulture.Name are equal
                //            //if (!HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY].ToString().Equals(Thread.CurrentThread.CurrentUICulture.Name))
                //            //{
                //            //    //set values to CurrentUICulture and CurrentCulture
                //            //    Thread.CurrentThread.CurrentUICulture = new CultureInfo(HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY].ToString());
                //            //    Thread.CurrentThread.CurrentCulture = new CultureInfo(HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY].ToString());
                //            //}
                //            culture = new CultureInfo(HttpContext.Current.Session[Framework.ConstantCollection.CULTUREINFOSESSIONKEY].ToString());
                //        }
                //    }
                //}
                //return Thread.CurrentThread.CurrentUICulture; // return the current uiCulture
                return Thread.CurrentThread.CurrentUICulture;
            }
            return culture;//new CultureInfo("en-US"); // send en-US as the Default value 
        }

        /// <summary>
        /// gets current language name, default value is 'English'
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public static string GetLanguageName()
        {
            string languageName = DEFAULT_LANGUAGE;

            if (HttpContext.Current !=null && HttpContext.Current.Session != null) // if the current session is not null
            {
                if (HttpContext.Current.Session[HttpContext.Current.Session.SessionID.ToString() + Framework.ConstantCollection.SESSION_CURRENTLANGUAGENAME] != null) //if CULTUREINFOSESSIONKEY is not null
                {
                      languageName = HttpContext.Current.Session[HttpContext.Current.Session.SessionID.ToString() + Framework.ConstantCollection.SESSION_CURRENTLANGUAGENAME].ToString();                    
                }                
            }
            return languageName;
        }

        /// <summary>
        /// Insert language resource
        /// added by tsrdev2
        /// </summary>
        /// <param name="twoLetterISOLanguageName"></param>
        /// <param name="languageName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        private static bool AddLanguageResource(string twoLetterISOLanguageName, string languageName,string key, string defaultValue)
        {
            bool success = false;
            SqlConnection connection = new SqlConnection(ConfigurationBlock.ConnectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = "InsertLanguageResources";
            command.CommandType = CommandType.StoredProcedure;
            long ID = -1;
            ///set parameters
            SqlParameter parameter = new SqlParameter("@ID", SqlDbType.BigInt);
            parameter.Value = ID;
            parameter.Direction = ParameterDirection.Output;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@LanguageID", SqlDbType.VarChar, 50);
            parameter.Value = twoLetterISOLanguageName;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@LanguageName", SqlDbType.NVarChar, 200);
            parameter.Value = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(languageName);
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ResourceKey", SqlDbType.Text);
            parameter.Value = key;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ResourceValue", SqlDbType.Text);
            parameter.Value = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(defaultValue);
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatorID", SqlDbType.BigInt);
            parameter.Value = 1;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@CreatedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifierID", SqlDbType.BigInt);
            parameter.Value = 1;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@ModifiedTimeStamp", SqlDbType.DateTime);
            parameter.Value = DateTime.Now;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@IsDeleted", SqlDbType.Bit);
            parameter.Value = false;
            command.Parameters.Add(parameter);
            try
            {
                command.ExecuteNonQuery();
                if (command.Parameters["@ID"].Value != null)
                {
                    ID = Convert.ToInt64(command.Parameters["@ID"].Value);
                    success = true;
                }
                if (ID > -1)
                {
                    //value = defaultValue;
                    success = false;
                }

            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return success;
        }
        // added by tsrdev2
        /// <summary>
        /// update language resource name when it is NULL      
        /// </summary>
        /// <param name="twoLetterISOLanguageName"></param>
        /// <param name="languageName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static bool UpdateLanguageName(string connectionString, string languageID, string languageName)
        {
            bool success = false;
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                //Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = UPDATELANGUAGENAMEFORNULL;
            command.CommandType = CommandType.StoredProcedure;
            ///set parameters
            SqlParameter parameter = new SqlParameter("@LanguageID", SqlDbType.NVarChar, 50);
            parameter.Value = languageID;
            command.Parameters.Add(parameter);
            parameter = new SqlParameter("@LanguageName", SqlDbType.NVarChar, 200);
            parameter.Value = languageName;
            command.Parameters.Add(parameter);            
            try
            {
                if (command.ExecuteNonQuery() > 0)
                    success = true;
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                //Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
                success = false;
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return success;
        }
          // added by tsrdev2
        /// <summary>
        /// update language resource        
        /// </summary>
        /// <param name="twoLetterISOLanguageName"></param>
        /// <param name="languageName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static List<string> GetAllLanguageIDsForLanguageNameIsNull(string connectionString)
        {
            List<string> list = new List<string>();           
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                ///open connection
                connection.Open();
            }
            catch (SqlException ex)
            {
                //Logging.LoggingHandler.LogUnhandledException(new DatabaseConnectionException(ex));
                throw new DatabaseConnectionException(ex);
            }

            SqlCommand command = connection.CreateCommand();
            command.CommandText = GETALLLANGUAGEIDS;
            command.CommandType = CommandType.StoredProcedure;
            ///NO parameters            
            try
            {
                SqlDataReader reader = command.ExecuteReader();
                using (reader)
                {
                    while (reader.Read())
                    {
                        if(!reader.IsDBNull(0))
                            list.Add(reader.GetString(0));
                    }
                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                //Logging.LoggingHandler.LogUnhandledException(ex); // log the error
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (connection != null)
                {
                    //close connection
                    connection.Close();
                }
            }
            return list;
        }
    }
}
