﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Web;
using System.Web.UI;

namespace TSR.Framework
{
    /// <summary>
    /// Class ReflectionHelper, 
    /// Working with reflection of the page
    /// This class has methods to load assembly from server, create instance and invoke method from the page
    /// </summary>
    public class ReflectionHelper : IDisposable
    {
        private Page _CurrentPage;
        public ReflectionHelper(Page currentPage)
        {
            _CurrentPage = currentPage;
        }
        /// <summary>
        /// retrieve Assembly instance
        /// </summary>
        /// <param name="_assemblyName"></param>
        /// <returns></returns>
        private Assembly LoadAssemblyInstanceFromServer(String assemblyPath)
        {

            Assembly assembly = null;
            try
            {
                assembly = Assembly.LoadFrom(_CurrentPage.Server.MapPath(assemblyPath));
            }
            catch (Exception exp)
            {
                Logging.LoggingHandler.LogUnhandledException(exp);
            }
            return assembly;
        }

        /// <summary>
        /// create the instance of required class
        /// </summary>
        /// <param name="_assembly"></param>
        /// <param name="_nameSpace"></param>
        /// <param name="_className"></param>
        /// <returns></returns>
        private object CreateClassInstance(Assembly assembly, String nameSpace, String className)
        {

            object instance = null;
            UserContext userContext = _CurrentPage.Session[ConstantCollection.USERCONTEXTKEY] as UserContext;
            try
            {
                if (!String.IsNullOrEmpty(nameSpace))
                    instance = assembly.CreateInstance(
                        nameSpace + "." + className, false,
                        BindingFlags.CreateInstance | BindingFlags.Instance | BindingFlags.Public,
                        null, new object[] { userContext }, null, null);

                else
                    instance = assembly.CreateInstance(className, false,
                        BindingFlags.CreateInstance | BindingFlags.Instance | BindingFlags.Public,
                        null, new object[] { userContext }, null, null);
            }
            catch (Exception exp)
            {
                Logging.LoggingHandler.LogUnhandledException(exp);
            }
            return instance;
        }

        /// <summary>
        /// method 
        /// InvokeMethod
        /// 
        /// </summary>
        /// <param name="assemblyPath"></param>
        /// <param name="nameSpace"></param>
        /// <param name="className"></param>
        /// <param name="functionName"></param>
        /// <returns></returns>
        public object InvokeMethod(String assemblyPath, String nameSpace, String className, String functionName)
        {
            Assembly assembly = LoadAssemblyInstanceFromServer(assemblyPath);
            return InvokeMethod(assembly, nameSpace, className, functionName);
        }

        /// <summary>
        /// retrieve the data collection by passing Facade and Function name
        /// </summary>
        /// <param name="_facadeName"></param>
        /// <param name="functionName"></param>
        /// <returns></returns>
        private object InvokeMethod(Assembly assembly, String nameSpace, String className, String functionName)
        {
            if (assembly != null)
            {
                object _object = CreateClassInstance(assembly, nameSpace, className);
                if (_object != null)
                {
                    return InvokeMethod(_object, functionName);
                }
                return null;
            }

            return null;
        }

        /// <summary>
        /// method
        /// InvokeMethod
        /// invoke by classInstance
        /// </summary>
        /// <param name="classInstance"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        public object InvokeMethod(object classInstance, String methodName)
        {
            if (classInstance != null)
            {
                Type _objectType = classInstance.GetType();

                MethodInfo _method = _objectType.GetMethod(methodName);

                if (_method != null)
                {
                    return (object)_method.Invoke(classInstance, null);
                }
                return null;
            }
            return null;
        }

        /// <summary>
        /// method 
        /// GetDataList
        /// retrieve Ilist object using reflection on an object
        /// </summary>
        /// <param name="_datalist"></param>
        /// <param name="_textFieldName"></param>
        /// <param name="_valueFieldName"></param>
        /// <returns></returns>
        public IList RetrieveDataList(object _datalist, String _textFieldName, String _valueFieldName)
        {
            IEnumerable enumeration = (IEnumerable)_datalist;
            IEnumerator enumerator;
            CustomProperties _cumtomProperties = new CustomProperties();

            enumerator = enumeration.GetEnumerator();
            while (enumerator.MoveNext())
            {
                object selectedItem = enumerator.Current;
                if (selectedItem != null)
                {
                    object _textFieldValue = FindPropertyValue(selectedItem, _textFieldName);
                    object _valueFieldValue = FindPropertyValue(selectedItem, _valueFieldName);
                    _cumtomProperties.Add(new CustomProperty(_valueFieldValue, _textFieldValue));

                }
            }
            return (IList)_cumtomProperties;
        }

        public object FindValueByKey(object list, String keyPropertyName, object keyValue, String valuePerpertyName)
        {

            IEnumerator enumerator;
            object _textFieldValue = null;
            if (list != null)
            {
                IEnumerable enumeration = (IEnumerable)list;
                enumerator = enumeration.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    object selectedItem = enumerator.Current;
                    if (selectedItem != null)
                    {
                        object _valueFieldValue = FindPropertyValue(selectedItem, keyPropertyName);
                        if (_valueFieldValue != null)
                        {
                            if (_valueFieldValue.Equals(keyValue))
                            {
                                _textFieldValue = FindPropertyValue(selectedItem, valuePerpertyName);
                                break;
                            }
                        }
                    }
                }
            }

            return _textFieldValue;
        }

        public object FindPropertyValue(object selectedObject, String selectedPropertyName)
        {
            object propertyValue = null;
            Type objType = selectedObject.GetType();
            PropertyInfo selectedProp = null;
            selectedProp = objType.GetProperty(selectedPropertyName);
            if (selectedProp != null)
            {
                propertyValue = selectedProp.GetValue(selectedObject, null);
            }
            return propertyValue;
        }


        #region IDisposable Members

        public void Dispose()
        {
            _CurrentPage = null;
        }

        #endregion
    }
}
