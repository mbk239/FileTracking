using System;
using System.Collections;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class
    /// Name: Calendar
    /// Description: This class performs an important function for Custom Calendar Control
    /// </summary>
    public class Calendar : System.Web.UI.WebControls.Calendar
    {
        [Category("Appearance")]
        public bool RenderOtherMonthDates
        {
            get
            {
                if (ViewState["RenderOtherMonthDates"] == null)
                    ViewState["RenderOtherMonthDates"] = true;

                return (bool)ViewState["RenderOtherMonthDates"];
            }
            set
            {
                ViewState["RenderOtherMonthDates"] = value;
            }
        }

        protected override void OnDayRender(TableCell cell, CalendarDay day)
        {
            base.OnDayRender(cell, day);

            if (day.IsOtherMonth && RenderOtherMonthDates == false)
            {
                cell.Text = String.Empty;
            }
        }
    }
}
