using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using TSR.Framework;
using TSR.Framework.Resource;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class
    /// Name: GridControl
    /// Description: This class performs as Custom GridView Control which inherites
    /// from System.Web.UI.WebControls.GridView.
    /// The control has all basic properties to bind and view IList type data.
    /// The control has properties and methods to update, cancel, delete rows with custom
    /// RosStatus. The control has methods for sorting, paging and so on.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:GridControl runat=server></{0}:GridControl>")]
    public class GridControl : GridView
    {

        #region Constants

        private const string VIEWSTATENAME_DATALIST = "DataList";
        private const string VIEWSTATENAME_CHECKEDDATALIST = "CheckedDataList";
        private const string VIEWSTATENAME_UNSAVEDDATA = "UnsavedData";
        private const string VIEWSTATENAME_CUSTOMSORTEXPRESSION = "CustomSortExpression";
        private const string VIEWSTATENAME_CUSTOMSORTDIRECTION = "CustomSortDirection";
        private const string VIEWSTATENAME_AUTOGETRESOURCESTRING = "AutoGetResourceString";

        public const string CHECKBOX_ITEMNAME_IN_GRID = "chkSelected";
        public const string CHECKALL_ITEMNAME_IN_GRID = "chkSelectAll";
        private const string STATUSOFUSER_ACTIVE = "Active";
        private const string STATUSOFUSER_INACTIVE = "Inactive";

        #endregion

        private DropDownList ddlNumberOfPages;
        //public delegate void PageSizeChangeHandler(object s, PageSizeChangeEventArgs e);
        //public event PageSizeChangeHandler OnPageSizeChanged;

        private labelControl lblStatus = new labelControl();

        #region Properties

        /// <summary>
        /// Property to Store and Retrieve binding Data list variable
        /// </summary>
        public IList DataList
        {
            get
            {
                if (ViewState[VIEWSTATENAME_DATALIST] == null)
                    return null;

                return (IList)(ViewState[VIEWSTATENAME_DATALIST]);
            }
            set
            {
                ViewState[VIEWSTATENAME_DATALIST] = value;
            }
        }

        /// <summary>
        /// Property to Store and Retrieve binding Checked Data list variable
        /// </summary>
        public IList CheckedDataList
        {
            get
            {
                if (ViewState[VIEWSTATENAME_CHECKEDDATALIST] == null)
                    return null;

                return (IList)(ViewState[VIEWSTATENAME_CHECKEDDATALIST]);
            }
            set
            {
                ViewState[VIEWSTATENAME_CHECKEDDATALIST] = value;

                SelectEntities();

            }
        }
        /// <summary>
        /// Property to Store and Retrieve Page Increment variable
        /// </summary>
        public int PageIncrement
        {
            get
            {
                int j = 0;
                if (this.AllowPaging)
                {
                    j = this.PageIndex * this.PageSize;
                }
                return j;
            }
        }

        /// <summary>
        /// Property to Store and Retrieve status of unsaved rows
        /// </summary>
        public bool UnsavedDataExists
        {
            get
            {
                if (ViewState[VIEWSTATENAME_UNSAVEDDATA] != null)
                {
                    return (bool)ViewState[VIEWSTATENAME_UNSAVEDDATA];
                }
                return false;
            }
            set
            {
                ViewState[VIEWSTATENAME_UNSAVEDDATA] = value;
            }
        }

        /// <summary>
        /// Property to Store and Retrieve Sort Expression variable
        /// </summary>
        public string CustomSortExpression
        {
            get
            {
                if (ViewState[VIEWSTATENAME_CUSTOMSORTEXPRESSION] != null)
                {
                    return (string)ViewState[VIEWSTATENAME_CUSTOMSORTEXPRESSION];
                }
                return String.Empty;
            }
            set
            {
                ViewState[VIEWSTATENAME_CUSTOMSORTEXPRESSION] = value;
            }
        }

        /// <summary>
        /// Property to Store and Retrieve Sort Direction variable
        /// </summary>
        public SortDirection CustomSortDirection
        {
            get
            {
                if (ViewState[VIEWSTATENAME_CUSTOMSORTDIRECTION] != null)
                {
                    return (SortDirection)ViewState[VIEWSTATENAME_CUSTOMSORTDIRECTION];
                }
                return SortDirection.Ascending;
            }
            set
            {
                ViewState[VIEWSTATENAME_CUSTOMSORTDIRECTION] = value;
            }
        }

        /// <summary>
        /// Property to automatically generate header column text
        /// </summary>
        ///Add by tsrdev1
        ///May 19th, 2010
        [DefaultValue(false)]
        public bool AutoGenerateHeaderText
        {
            get;set;            
        }
        //added by tsrdev2 - 19 Nov 2010
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>        
        ///May 19th, 2010
        [DefaultValue(false)]
        public bool DisableSortInit
        {
            get;
            set;
        }
        //added by tsrdev2 - 11 May 2011
        /// <summary>
        /// Property to disable auto sort when OnSotting event is called.
        /// </summary>        
        ///May 19th, 2010
        [DefaultValue(false)]
        public bool DisableAutoSort
        {
            get;
            set;
        }
        /// <summary>
        /// Property to auto generate resource by header text
        /// </summary>
        /// add by tsrdev2
        [DefaultValue(true)]
        public bool AutoGetResourceString
        {
            get
            {
                if (ViewState[VIEWSTATENAME_AUTOGETRESOURCESTRING] != null)
                {
                    return (bool)ViewState[VIEWSTATENAME_AUTOGETRESOURCESTRING];
                }
                return true;
            }
            set
            {
                ViewState[VIEWSTATENAME_AUTOGETRESOURCESTRING] = value;
            }
        }

        public new string EmptyDataText
        {
            get { return base.EmptyDataText; }
            set { base.EmptyDataText = ReplaceHTMLCode(value); }
        }

        //added by tsrdev2 - 13 Mar 2012
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool BaseOnRowCancelingEdit
        {
            get;
            set;
        }
        
        //added by tsrdev2 - 13 Mar 2012
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool BaseOnRowEditing
        {
            get;
            set;
        }

        //added by tsrdev2 - 13 Mar 2012
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool BaseOnRowDeleting
        {
            get;
            set;
        }

        //added by tsrdev2 - 01 Aug 2012
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool BaseOnRowCommand
        {
            get;
            set;
        }

        //added by tsrdev2 - 01 Aug 2012
        /// <summary>
        /// Property to disable sort when bind data to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool BaseOnRowUpdating
        {
            get;
            set;
        }
	    //Added by tsrdev2 - 26 Sep 2012
        /// <summary>
        /// Property to allow display deleted record (as normal) to gridview
        /// </summary>                
        [DefaultValue(false)]
        public bool AllowDisplayDeletedItem
        {
            get;
            set;
        }

        [DefaultValue(false)]
        public bool DisableEditCommand
        {
            get;
            set;
        }

        int _iTotalRec;
        public int TotalRecord
        {
            get
            {
                int iTotalRec;
                if (DataList is IListSource)
                {
                    IListSource itotal = (IListSource)DataList;
                    iTotalRec = itotal.GetList().Count;
                }
                else if (DataList is ICollection)
                {
                    ICollection itotal = (ICollection)DataList;
                    iTotalRec = itotal.Count;
                }
                else
                    iTotalRec = _iTotalRec;

                return iTotalRec;
            }
            set
            {
                _iTotalRec = value;
            }
        }

        #endregion

        public delegate void BindGridDelegate();
        public delegate void UpdateListData();
        public BindGridDelegate BindGrid;
        //added by tsrdev2
        public delegate void ManualSortDelegate(string customExpression, string customDirection);       
        public ManualSortDelegate ManualSort;
        //add by tdthinh
        public delegate void ChangePagesizeDelegate(int pagesize);
        public ChangePagesizeDelegate ChangePagesize;
        //public UpdateListData UpdateList;

        /// <summary>
        /// override OnInit method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin OnInit [GridControl]");
                if (AllowPaging)
                {
                    base.PagerSettings.Position = PagerPosition.TopAndBottom;
                    base.PagerSettings.Mode = PagerButtons.NumericFirstLast;
                    base.PagerSettings.FirstPageText = ReplaceHTMLCode(ResourceManager.GetResourceString("First", "First"));
                    base.PagerSettings.LastPageText = ReplaceHTMLCode(ResourceManager.GetResourceString("Last", "Last"));
                    base.PagerSettings.NextPageText = ReplaceHTMLCode(ResourceManager.GetResourceString("WizardButtonNext", "Next"));
                    base.PagerSettings.PreviousPageText = ReplaceHTMLCode(ResourceManager.GetResourceString("WizardButtonPrevious", "Previous"));

                    this.PagerSettings.Visible = true;
                    ddlNumberOfPages = new DropDownList();
                    ddlNumberOfPages.ID = "ddlNumberOfPages";
                    ddlNumberOfPages.AutoPostBack = true;
                    ddlNumberOfPages.SkinID = "WrapDropDownList";
                    ddlNumberOfPages.EnableViewState = true;
                    ddlNumberOfPages.SelectedIndexChanged += new EventHandler(ddlNumberOfPages_SelectedIndexChanged);
                    //if (!Page.IsPostBack)
                    {
                        ddlNumberOfPages.Items.Clear();                        
                        for (int i = 10; i <= 100; i += 10)
                            ddlNumberOfPages.Items.Add(i.ToString());
                    }
                    PageSize = Convert.ToInt32(ddlNumberOfPages.SelectedItem.Value);
                }
                base.OnInit(e);
                //Page.Trace.Write("End OnInit [GridControl]");
            }

        }

        /// <summary>
        /// override OnPagePreLoad method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected override void OnPagePreLoad(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin OnPagePreLoad [GridControl]");
                base.OnPagePreLoad(sender, e);
                if (Page.IsPostBack)
                {

                    UpdateCheckedListData(true, false);
                }

                //Page.Trace.Write("End OnPagePreLoad [GridControl]");
            }
        }

        /// <summary>
        /// override Render method
        /// </summary>
        /// <param name="writer"></param>
        protected override void Render(HtmlTextWriter writer)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin Render [GridControl]");
                if (AllowPaging && TopPagerRow != null)
                {
                    TopPagerRow.Visible = true;
                }
                base.Render(writer);
                //Page.Trace.Write("End Render [GridControl]");
            }
        }

        /// <summary>
        /// override OnRowCreated method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowCreated(GridViewRowEventArgs e)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin OnRowCreated [GridControl]");

                base.OnRowCreated(e);
                // If header tries to localize the resources of the header
                if (e.Row.RowType == DataControlRowType.Header)
                {
                    if (AutoGetResourceString) //auto generate resource by header text
                    {
                        foreach (TableCell tc in e.Row.Cells)
                        {
                            if (!(AutoGenerateHeaderText))
                            {
                                // Checks to see if the header text is plain or embedded in a link button
                                if (tc.Controls.Count == 0)
                                    tc.Text = ReplaceHTMLCode(ResourceManager.GetResourceString(tc.Text, tc.Text));
                                else
                                {
                                    LinkButton btn = tc.Controls[0] as LinkButton;
                                    if (btn != null)
                                    {
                                        btn.Text = ReplaceHTMLCode(ResourceManager.GetResourceString(btn.Text, btn.Text));
                                    }
                                }
                            }
                        }
                    }
                }
                else if (e.Row.RowType == DataControlRowType.Pager)
                {
                    GridViewRow bottomPagerRow = this.BottomPagerRow;

                    GridViewRow topPagerRow = this.TopPagerRow;
                    if (topPagerRow != null)
                    {
                        topPagerRow.Cells[0].Controls.Clear();
                        Table oTab = new Table();

                        Table oOutertab = new Table();
                        oOutertab.Width = Unit.Percentage(100);

                        TableRow oOuterRow = new TableRow();
                        oOutertab.Rows.Add(oOuterRow);

                        int iTotalRec = this.TotalRecord;
                        int iUpto = 0;
                        int iStart = PageIndex * PageSize + 1;                        

                        if ((PageIndex + 1) == PageCount)
                            iUpto = iTotalRec;
                        else
                            iUpto = iStart + PageSize - 1;
                        lblStatus.Text = iStart + " - " + iUpto + " " + ResourceManager.GetResourceString("OF", "of") + " " + iTotalRec
                        +" " + ResourceManager.GetResourceString("Display", "Display");
                        TableCell oCell = new TableCell();
                        oCell.HorizontalAlign = HorizontalAlign.Right;
                        oCell.Controls.Add(lblStatus);
                        oCell.Controls.Add(ddlNumberOfPages);
                        oCell.Width = Unit.Percentage(100);
                        oOuterRow.Cells.Add(oCell);

                        //oCell = new TableCell();
                        //oCell.HorizontalAlign = HorizontalAlign.Right;
                        //lblStatus = new Label();
                        //lblStatus.Text = ResourceManager.GetResourceString("Display", "Display") + "  ";
                        //oCell.Controls.Add(lblStatus);                        
                        //oCell.Controls.Add(ddlNumberOfPages);
                        //oCell.Width = Unit.Percentage(50);
                        //oOuterRow.Cells.Add(oCell);
                        topPagerRow.Cells[0].HorizontalAlign = HorizontalAlign.Right;
                        topPagerRow.Cells[0].Controls.Add(oOutertab);
                    }                    
                   
                }
                //Page.Trace.Write("End OnRowCreated [GridControl]");
            }

        }

        protected override void OnRowCommand(GridViewCommandEventArgs e)
        {
            if(BaseOnRowCommand)
                base.OnRowCommand(e);
        }
        /// <summary>
        /// implement data bind method
        /// </summary>
        public new void DataBind()
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin DataBind [GridControl]");
                
                //TSR.Framework.Logging.Log log = new TSR.Framework.Logging.Log();                
                //log.MessageDetail += "[ListLanguage].DataBind: " + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString();
                
                if(!DisableSortInit)
                    SortData();                
                base.DataBind();

                //log.MessageDetail += "--->" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString();
                //TSR.Framework.Logging.LoggingHandler.LogInfo(log);

                //Page.Trace.Write("End DataBind [GridControl]");
            }
        }

        public int SetPageSize
        {            
            set
            {
                this.PageSize = value;
                //ddlNumberOfPages.SelectedIndex = ddlNumberOfPages.Items.IndexOf(ddlNumberOfPages.Items.FindByValue(value.ToString());

                if(ddlNumberOfPages != null)
                    ddlNumberOfPages.SelectedIndex = ddlNumberOfPages.Items.IndexOf(new ListItem(value.ToString()));
            }
        }

        /// <summary>
        /// override OnDataBound method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnDataBound(EventArgs e)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin OnDataBound [GridControl]");
                base.OnDataBound(e);
                SelectEntities();
                //Page.Trace.Write("End OnDataBound [GridControl]");
            }
        }

        /// <summary>
        /// override OnSorting method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnSorting(GridViewSortEventArgs e)
        {
            if (!DesignMode)
            {                
                if (e.SortExpression == CustomSortExpression)
                    this.CustomSortDirection = (CustomSortDirection == SortDirection.Ascending ? SortDirection.Descending : SortDirection.Ascending);
                else
                    this.CustomSortDirection = SortDirection.Ascending;
                CustomSortExpression = e.SortExpression;
                
                if (!this.DisableAutoSort)
                {                 
                    this.DataSource = DataList;
                    SortData();                    
                }
                else
                {                    
                    string[] expresss = CustomSortExpression.Split('.');
                    ManualSort(expresss[expresss.Length-1], this.CustomSortDirection == SortDirection.Ascending ? "ASC" : "DESC");
                    //this.DataSource = DataList;
                }                
                base.DataBind();                
            }
        }

        /// <summary>
        /// This method sorts Grid control Data
        /// </summary>
        private void SortData()
        {
            if (!DesignMode)
            {
                //TSR.Framework.Logging.Log log = new TSR.Framework.Logging.Log();
                //log.MessageDetail += "[ListLanguage].SortData: " + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString();

                //Page.Trace.Write("Begin SortData [GridControl]");
                if (!String.IsNullOrEmpty(CustomSortExpression.Trim()))
                {
                    // Creates a temporary list to hold the sorted data
                    // A temporary list is needed cause we cannot modify
                    // a container data object during enumerating it.
                    ArrayList list = new ArrayList();

                    // Retrieves the enumerator of the data source
                    IEnumerable enumeration = (IEnumerable)this.DataSource;
                    IEnumerator enumerator;

                    // Counts the number of elements in the datasource
                    int eleCount = 0;
                    if (this.DataSource is IListSource)
                    {
                        IListSource itotal = (IListSource)this.DataSource;
                        eleCount = itotal.GetList().Count;
                    }
                    else if (this.DataSource is ICollection)
                    {
                        ICollection itotal = (ICollection)this.DataSource;
                        eleCount = itotal.Count;
                    }
                    else
                    {
                        enumerator = enumeration.GetEnumerator();
                        while (enumerator.MoveNext())
                        {
                            eleCount++;
                        }
                    }

                    // Starts the sorting algorithm using selection sort
                    for (int i = 0; i < eleCount; i++)
                    {
                        enumerator = enumeration.GetEnumerator();
                        object selected = null;
                        string selectedValue = String.Empty;

                        // This inner iteration finds the suitable candidate for the i'th position
                        while (enumerator.MoveNext())
                        {
                            // As we iterate the same collection over and over and do not
                            // remove items from it, we need to check if the item has already
                            // been selected
                            if (list.Contains(enumerator.Current))
                                continue;

                            // Holds a reference to the current item
                            // This item changes if the sorting criteria refers to a sub object
                            object selectedItem = enumerator.Current;

                            #region Retrieves the value using reflection

                            
                            
                            Type objType = enumerator.Current.GetType();  
                            
                            System.Reflection.PropertyInfo valueProp = null;
                            if (CustomSortExpression.Contains("."))
                            {
                                string[] innerprops = CustomSortExpression.Split('.');
                                Type tempType = objType;
                                for (int j = 0; j < innerprops.Length; j++)
                                {
                                    valueProp = tempType.GetProperty(innerprops[j]);
                                    tempType = valueProp.PropertyType;

                                    if (j < innerprops.Length - 1)
                                        selectedItem = valueProp.GetValue(selectedItem, null);
                                }
                            }
                            else
                            {
                                valueProp = objType.GetProperty(CustomSortExpression);
                            }

                            //if (valueProp == null)
                            //    return;

                            object currentValueObj = null;
                            if (selectedItem != null && valueProp != null)
                            {
                                currentValueObj = valueProp.GetValue(selectedItem, null);
                            }
                            string currentValue = (currentValueObj == null ? String.Empty : currentValueObj.ToString());
                            if (selected == null)
                            {
                                selected = enumerator.Current;
                                selectedValue = currentValue;
                                continue;
                            }

                            #endregion

                            if (valueProp != null)
                            {
                                // Checks if the value is of type integer
                                if (valueProp.PropertyType == typeof(Int16) ||
                                    valueProp.PropertyType == typeof(Int32) ||
                                    valueProp.PropertyType == typeof(Int64))
                                {
                                    long currentIntValue;
                                    long selectedIntValue;

                                    if (long.TryParse(currentValue, out currentIntValue) && long.TryParse(selectedValue, out selectedIntValue))
                                    {
                                        // Decides based upon the SortDirection
                                        if ((CustomSortDirection == SortDirection.Ascending && currentIntValue < selectedIntValue) ||
                                            (CustomSortDirection == SortDirection.Descending && currentIntValue > selectedIntValue))
                                        {
                                            selected = enumerator.Current;
                                            selectedValue = currentValue;
                                        }
                                    }

                                }
                                // Checks if the value is of type datatime
                                else if (valueProp.PropertyType == typeof(DateTime))
                                {
                                    DateTime currentDateTimeValue;
                                    DateTime selectedDateTimeValue;

                                    if (DateTime.TryParse(currentValue, out currentDateTimeValue) && DateTime.TryParse(selectedValue, out selectedDateTimeValue))
                                    {
                                        // Decides based upon the SortDirection
                                        if ((CustomSortDirection == SortDirection.Ascending && currentDateTimeValue < selectedDateTimeValue) ||
                                            (CustomSortDirection == SortDirection.Descending && currentDateTimeValue > selectedDateTimeValue))
                                        {
                                            selected = enumerator.Current;
                                            selectedValue = currentValue;
                                        }
                                    }

                                }
                                // If none of the above then determines by using its ToString value
                                // Decides based upon the SortDirection
                                else if ((CustomSortDirection == SortDirection.Ascending && currentValue.CompareTo(selectedValue) < 0) ||
                                    (CustomSortDirection == SortDirection.Descending && currentValue.CompareTo(selectedValue) > 0))
                                {
                                    selected = enumerator.Current;
                                    selectedValue = currentValue;
                                }
                            }
                        }

                        list.Add(selected);
                    }


                    // Clears the datalist and uses the temporary list created
                    // earlier to fill it using the new sorted values.
                    DataList.Clear();
                    foreach (object item in list)
                    {
                        DataList.Add(item);
                    }

                    this.DataSource = DataList;
                }
                //log.MessageDetail += "--->" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString() + ":" + DateTime.Now.Millisecond.ToString();
                //TSR.Framework.Logging.LoggingHandler.LogInfo(log);
                //Page.Trace.Write("End SortData [GridControl]");
            }
        }

        /// <summary>
        /// override OnRowDataBound method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowDataBound(GridViewRowEventArgs e)
        {
            if (!DesignMode)
            {
                //Page.Trace.Write("Begin OnRowDataBound [GridControl]");
            
                base.OnRowDataBound(e);
                int _RowIndex = e.Row.RowIndex + this.PageIncrement;

                if (_RowIndex >= 0 && DataList != null)
                {
                    BaseBusinessEntity entity = DataList[_RowIndex] as BaseBusinessEntity;
                    if (entity != null)
                    {
                        if (entity.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                        {
                            if (!AllowDisplayDeletedItem)
                            {
                                e.Row.Enabled = false;
                                e.Row.CssClass = "DefaultGridViewDeletedRow";
                                foreach (Control control in e.Row.Controls)
                                {
                                    WebControl webControl = control as WebControl;
                                    if (webControl != null)
                                    {
                                        webControl.Enabled = false;
                                    }
                                }
                            }
                        }
                    }

                    //Html Encoding to block dangerous code
                    foreach (TableCell tc in e.Row.Cells)
                    {
                        foreach (Control ctl in tc.Controls)
                        {
                            LinkButton btn = ctl as LinkButton;                            
                            if (btn != null)
                            {
                                if (btn.Text == "Edit" || btn.Text == "Update" || btn.Text == "Cancel" || btn.Text == "Delete")
                                {
                                    btn.Text = ResourceManager.GetResourceString(btn.Text, btn.Text);
                                }
                                //btn.Text = HttpUtility.HtmlEncode(btn.Text);
                                btn.Text = ReplaceHTMLCode(btn.Text);
                            }

                            HyperLink hlk = ctl as HyperLink;
                            if (hlk != null)
                            {
                                if (hlk.Text == "Edit" || hlk.Text == "Update" || hlk.Text == "Cancel" || hlk.Text == "Delete")
                                {
                                    hlk.Text = ResourceManager.GetResourceString(hlk.Text, hlk.Text);
                                }
                                //hlk.Text = HttpUtility.HtmlEncode(hlk.Text);
                                hlk.Text = ReplaceHTMLCode(hlk.Text);
                            }
                        }
                    }
                }
                //Page.Trace.Write("End OnRowDataBound [GridControl]");
            }

        }


        /// <summary>
        /// oevrride OnRowCancelingEdit method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowCancelingEdit(GridViewCancelEditEventArgs e)
        {
            if (!DesignMode)
            {
                if (this.BaseOnRowCancelingEdit)
                    base.OnRowCancelingEdit(e);
                else
                {
                    int _RowIndex = e.RowIndex + PageIncrement;
                    BaseBusinessEntity entity = DataList[_RowIndex] as BaseBusinessEntity;

                    if (entity.RowState == BaseBusinessEntity.RowStateEnum.NewRow)
                        DataList.RemoveAt(_RowIndex);
                }
                this.EditIndex = -1;

                InvokeBindGrid();
                UnsavedDataExists = false;
            }
        }

        /// <summary>
        /// override OnRowDeleting method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowDeleting(GridViewDeleteEventArgs e)
        {
            if (!DesignMode)
            {
                if (this.BaseOnRowDeleting)
                    base.OnRowDeleting(e);
                else
                {
                    int _RowIndex = e.RowIndex + PageIncrement;
                    BaseBusinessEntity entity = DataList[_RowIndex] as BaseBusinessEntity;

                    if (entity.RowState == BaseBusinessEntity.RowStateEnum.NewRow)
                        DataList.RemoveAt(_RowIndex);
                    else
                    {
                        entity.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                        DataList[_RowIndex] = entity;
                    }
                }
                InvokeBindGrid();
            }
        }

        /// <summary>
        /// oevrride OnRowEditing method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnRowEditing(GridViewEditEventArgs e)
        {
            if (!DesignMode)
            {
                if (!DisableEditCommand)
                {
                    this.EditIndex = e.NewEditIndex;
                    if (this.BaseOnRowEditing)
                        base.OnRowEditing(e);

                    InvokeBindGrid();
                    UnsavedDataExists = true;
                }
                else
                {
                    this.EditIndex = -1;
                    UnsavedDataExists = false;
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// override OnPageIndexChanging method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPageIndexChanging(GridViewPageEventArgs e)
        {
            if (!DesignMode)
            {
                //InvokeUpdateListData();
                this.PageIndex = e.NewPageIndex;
                InvokeBindGrid();

                //base.OnPageIndexChanging(e);
            }
        }

        protected override void OnPageIndexChanged(EventArgs e)
        {
            //base.OnPageIndexChanged(e);
            if (!DesignMode)
            {                
                this.EditIndex = -1;
                InvokeBindGrid();
                UnsavedDataExists = false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void InvokeBindGrid()
        {
            if (!DesignMode)
            {
                if (BindGrid != null)
                    BindGrid();
            }
        }

        //private void InvokeUpdateListData()
        //{
        //    if (!DesignMode)
        //    {
        //        if (UpdateList != null)
        //            UpdateList();
        //    }
        //}

        /// <summary>
        /// 
        /// </summary>
        public void UpdateCheckedListData()
        {
            UpdateCheckedListData(true, false);
        }

        /// <summary>
        /// Checks updated items, whether they are checked or not, and updates checked item list accordingly
        /// </summary>
        /// <param name="considerGrid"></param>
        /// <param name="selectAll"></param>
        /// 
        public void UpdateCheckedListData(bool considerGrid, bool selectAll)
        {
            BaseBusinessEntity bbEntity;
            List<BaseBusinessEntity> bbEntitiesToBeRemoved = new List<BaseBusinessEntity>();


            if (CheckedDataList != null)
            {
                int pi = (considerGrid) ? PageIncrement : 0;
                int countTotal = (considerGrid) ? Rows.Count + pi : DataList.Count;
                bool check = selectAll;
                bool doNothing = false;

                int index;
                for (int i = pi; i < countTotal; i++)
                {
                    bbEntity = DataList[i] as BaseBusinessEntity;
                    if (bbEntity != null)
                    {
                        if (considerGrid)
                        {
                            CheckBox chk = Rows[i - pi].FindControl(CHECKBOX_ITEMNAME_IN_GRID) as CheckBox;
                            doNothing = (chk == null);
                            if (!doNothing)
                                check = chk.Checked;
                        }

                        if (!doNothing)
                        {
                            if (check)
                            {
                                BaseBusinessEntity bbEntityToChange;
                                if (CheckedDataList.Contains(bbEntity))
                                {
                                    index = CheckedDataList.IndexOf(bbEntity);
                                    bbEntityToChange = CheckedDataList[index] as BaseBusinessEntity;

                                    if (bbEntityToChange.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                                    {
                                        bbEntityToChange.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                                    }
                                }
                                else
                                {
                                    bbEntity.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                                    CheckedDataList.Add(bbEntity);
                                }
                            }
                            else
                            {
                                if (CheckedDataList.Contains(bbEntity))
                                {
                                    index = CheckedDataList.IndexOf(bbEntity);
                                    BaseBusinessEntity bbEntityTemp = CheckedDataList[index] as BaseBusinessEntity;
                                    if (bbEntityTemp.RowState == BaseBusinessEntity.RowStateEnum.NewRow)
                                    {
                                        bbEntitiesToBeRemoved.Add(bbEntityTemp);
                                    }
                                    else
                                    {
                                        bbEntityTemp.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                                    }
                                }
                            }
                        }
                    }

                }

                foreach (BaseBusinessEntity entityToRemove in bbEntitiesToBeRemoved)
                {
                    CheckedDataList.Remove(entityToRemove);
                }
                if (!considerGrid)
                    SelectEntities();
            }

        }

        /// <summary>
        /// 
        /// </summary>
        private void SelectEntities()
        {
            SelectEntities(false);
        }
        public delegate void BindingComplatedARow(object rowSender);
        /// <summary>
        /// handler when apter SelectEntities : check or not  checkbox
        /// </summary>
        public event BindingComplatedARow BindingComplated_ARowHandler;
        /// <summary>
        /// Selects [checked] items from the checked list items collection
        /// </summary>
        /// <param name="considerGrid"></param>
        private void SelectEntities(bool considerGrid)
        {
            if (CheckedDataList != null)
            {
                int pi = PageIncrement;
                bool check = false;
                int index;

                for (int i = pi; i < Rows.Count + pi; i++)
                {
                    CheckBox chk = Rows[i - pi].FindControl(CHECKBOX_ITEMNAME_IN_GRID) as CheckBox;
                    //bool InUse = false;
                    if (chk != null)
                    {
                        if (considerGrid)
                        {
                            check = considerGrid;
                        }
                        else
                        {
                            check = (DataList.Count > 0) ? (CheckedDataList.Contains(DataList[i])) : false;
                            if (check)
                            {
                                index = CheckedDataList.IndexOf(DataList[i]);
                                
                                BaseBusinessEntity bbEntity = CheckedDataList[index] as BaseBusinessEntity;
                                if (bbEntity != null)
                                {
                                    check = (bbEntity.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow);
                                    //if (index >= 0 && DataList[i].GetType().ToString().Equals("TSR.Entities.User"))
                                    //{
                                    //    InUse = (DataList[i] as BaseBusinessEntity).inUse.Equals(STATUSOFUSER_ACTIVE);
                                    //}
                                }
                            }
                        }

                        chk.Checked = check;
                        //if (InUse)
                        //    chk.Checked = true;
                        //if (!check && chk.Checked == false && !InUse)
                        //    chk.Enabled = true;
                        if (BindingComplated_ARowHandler != null)
                        {
                            if (!DesignMode)
                            {
                                BindingComplated_ARowHandler(this.Rows[i - pi]);
                            }
                        }
                    }
                }
            }
            //added by tsrdev2
            //set chkCheckAll is checked if the all checkbox is checked.
            //bool isCheckAll = true;
            //foreach (GridViewRow row in Rows)
            //{
            //    CheckBox chk = Rows[i - pi].FindControl(CHECKBOX_ITEMNAME_IN_GRID) as CheckBox;
            //    if (chk != null && !chk.Checked)
            //    {
            //        isCheckAll = false;
            //        break;
            //    }
            //}
            
            //CheckBox chkAll = HeaderRow.FindControl(CHECKALL_ITEMNAME_IN_GRID) as CheckBox;
            //if (chkAll != null)
            //{
            //    chkAll.Checked = isCheckAll;
            //}  
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ddlNumberOfPages_SelectedIndexChanged(object sender, System.EventArgs e)
        {

            if (!DesignMode)
            {
                int iPageSize = Convert.ToInt32(ddlNumberOfPages.SelectedItem.Value);
                base.PageSize = iPageSize;
                base.PageIndex = 0;
                InvokeBindGrid();

                if (ChangePagesize != null)
                    ChangePagesize(iPageSize);
            }
            
            //OnPageSizeChanged(this, new PageSizeChangeEventArgs(iPageSize));
        }
        private string ReplaceHTMLCode(Object objVlaue)
        {
            return TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(objVlaue);
        }
    }
    ///End Grid Control

    
    //{
    //    public int NewPageSize;
    //    public PageSizeChangeEventArgs(int pNewPageSize)
    //    {
    //        NewPageSize = pNewPageSize;
    //    }
    //}
}
