﻿using System.ComponentModel;
using System.Web.UI;
using Obout.Grid;
using System;
using TSR.Framework.Resource;
using System.Web;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class
    /// Name: GridControl
    /// Description: This class performs as Custom GridView Control which inherites
    /// from System.Web.UI.WebControls.GridView.
    /// The control has all basic properties to bind and view IList type data.
    /// The control has properties and methods to update, cancel, delete rows with custom
    /// RosStatus. The control has methods for sorting, paging and so on.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class oboutGrid : Grid
    {
        #region Properties
        /// <summary>
        /// Property to auto generate resource by header text
        /// </summary>
        /// add by tsrdev2
        [DefaultValue(true)]
        public bool AutoGetResourceString
        {
            get;
            set;
        } 
        #endregion

        #region Events handling

        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
        }

        protected override void OnInit(System.EventArgs e)
        {
            if (base.AllowPaging)
            {
                base.LocalizationSettings.Paging_PageSizeText = ResourceManager.GetResourceString("Display", "Display");
                base.NumberOfPagesShownInFooter = 10;

                if (base.AllowPageSizeSelection)
                {
                    base.PageSizeOptions = genPageSizeOption();
                    base.PageSize = getPageSize();
                }
            }

            base.LocalizationSettings.LoadingText = ResourceManager.GetResourceString("WaitLoading", "Loading, please wait...");
            base.LocalizationSettings.NoRecordsText = ResourceManager.GetResourceString("EmptyDataText", "Related data not available.");
            base.LocalizationSettings.Paging_RecordsText = ResourceManager.GetResourceString("Records", "Records") + ":";
            base.LocalizationSettings.Paging_OfText = ResourceManager.GetResourceString("OF", "of");
            base.LocalizationSettings.Paging_PagesText = ResourceManager.GetResourceString("Pages", "Pages") + ":";
            base.LocalizationSettings.EditLink = ResourceManager.GetResourceString("Edit", "Edit");
            base.LocalizationSettings.DeleteLink = ResourceManager.GetResourceString("Delete", "Delete");
            base.LocalizationSettings.UpdateLink = ResourceManager.GetResourceString("Update", "Update");
            base.LocalizationSettings.CancelLink = ResourceManager.GetResourceString("Cancel", "Cancel");

            base.AutoGenerateColumns = false;
            //base.AllowAddingRecords = false;
            //base.Serialize = false;
            base.AllowFiltering = false;
            //base.AllowGrouping = false;
            base.FolderStyle = getFolderStyle();
            
            //base.AllowMultiRecordSelection = false;
            base.AllowMultiRecordEditing = false;
            base.AllowColumnResizing = false;

            base.OnInit(e);
        }

        protected override void OnPageSizeChange(int iPageSize)
        {
            base.OnPageSizeChange(iPageSize);

            HttpCookie cookie = new HttpCookie("pagesize");
            cookie.Value = Convert.ToString(iPageSize);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        protected override void OnColumnsCreated()
        {
            base.OnColumnsCreated();

            if (AutoGetResourceString)
            {
                foreach (Column col in base.Columns)
                {
                    col.HeaderText = ReplaceHTMLCode(ResourceManager.GetResourceString(col.HeaderText, col.HeaderText));
                }
            }
        }

        #endregion

        #region Mics

        private string ReplaceHTMLCode(Object objVlaue)
        {
            return TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(objVlaue);
        }

        private string genPageSizeOption()
        {
            string s = "10";
            for (int i = 20; i <= 100; i+=10)
            {
                s += "," + i.ToString();
            }
            return s;
        }

        private string getFolderStyle()
        {
            string mapPath = HttpContext.Current.Server.MapPath("~");
            string tsrwebadmin = mapPath.Substring(mapPath.LastIndexOf("\\") + 1, mapPath.Length - mapPath.LastIndexOf("\\") - 1);
            string rootFolderName = !string.IsNullOrEmpty(TSR.Framework.ConfigurationBlock.CustomerNo) ? (TSR.Framework.ConfigurationBlock.CustomerNo + "/" + tsrwebadmin) : tsrwebadmin;
            rootFolderName = string.IsNullOrEmpty(rootFolderName) ? "" : "/" + rootFolderName;
            if (rootFolderName.EndsWith("/"))
                return rootFolderName + "App_Themes/Default/GridStyle/default";
            else
                return rootFolderName + "/App_Themes/Default/GridStyle/default";
        }

        private int getPageSize()
        {
            int pageSize = 10;
            if (HttpContext.Current.Request.Cookies["pagesize"] != null)
            {
                if (!int.TryParse(HttpContext.Current.Request.Cookies["pagesize"].Value, out pageSize))
                {
                    pageSize = 10;
                }
            }
            return pageSize;
        }

        #endregion
    }
}

