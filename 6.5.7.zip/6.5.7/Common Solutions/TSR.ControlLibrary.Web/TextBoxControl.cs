
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class name: TextBoxControl
    /// Description: This class performs as Custom TextBox Control which inherites
    /// from System.Web.UI.WebControls.TextBox.
    /// The control has all basic properties of TextBox control.
    /// The control is asigned to RegularExpressionValidator with validation expression is "^[a-zA-Z]{1}[a-zA-Z0-9]{5,14}$" 
    /// </summary>
    public class TextBoxControl : TextBox
    {
        private RegularExpressionValidator req;
        public string InvalidMessage;
        public string ClientScript = "true";

        protected override void OnInit(EventArgs e)
        {
            req = new RegularExpressionValidator();
            req.ControlToValidate = this.ID;
            req.ErrorMessage = this.InvalidMessage;
            req.ValidationExpression = "^[a-zA-Z]{1}[a-zA-Z0-9]{5,14}$";

            req.EnableClientScript = (this.ClientScript.ToLower() != "false");
            Controls.Add(req);
        }

        protected override void Render(HtmlTextWriter w)
        {
            base.Render(w);
            req.RenderControl(w);
        }
    }
}
