﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class name: hyperLinkControl
    /// Description: This class performs as Custom HyperLink Control which inherites
    /// from System.Web.UI.WebControls.HyperLink.
    /// The control has all basic properties of HyperLink control.
    /// The control has properties to set or get value of text that has been replaced HMLT code    
    /// </summary>
    public class hyperLinkControl:HyperLink
    {
        public new string Text
        {
            get { return base.Text; }
            set { base.Text = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(value); }
        }
    }
}
