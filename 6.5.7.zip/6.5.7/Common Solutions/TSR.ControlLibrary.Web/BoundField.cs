using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class
    /// Name: BoundField
    /// Description: This class performs as Custom BoundField which inherites
    /// from System.Web.UI.WebControls.BoundField
    /// The control to set default value of property NullDisplayText
    /// </summary>
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:BoundField runat=server></{0}:BoundField>")]
    public class BoundField : System.Web.UI.WebControls.BoundField
    {
        [Bindable(true)]
        [Category("Behavior")]
        [DefaultValue("Not Set")]
        [Localizable(true)]
        public override string NullDisplayText
        {
            get
            {
                return base.NullDisplayText;
            }
            set
            {
                base.NullDisplayText = value;
            }
        }
    }
}
