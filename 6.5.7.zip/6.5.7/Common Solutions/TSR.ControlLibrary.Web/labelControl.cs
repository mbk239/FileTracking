﻿
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class name: labelControl
    /// Description: This class performs as Custom Label Control which inherites
    /// from System.Web.UI.WebControls.Label.
    /// The control has all basic properties of Label control.
    /// The control has properties to set or get value of text that has been replaced HMLT code    
    /// </summary>
    public class labelControl :Label
    {
        public new string Text
        {
            get { return  base.Text;  }
            set { base.Text = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(value); }
        }
        
    }

}
