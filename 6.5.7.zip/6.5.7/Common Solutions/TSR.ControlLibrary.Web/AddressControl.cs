using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// Class
    /// Name: AddressControl
    /// Description: This class performs as Custom WebControl
    /// </summary>
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:AddressControl runat=server></{0}:AddressControl>")]
    public class AddressControl : WebControl
    {
        GridView AddressGrid;

        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        public string Text
        {
            get
            {
                String s = (String)ViewState["Text"];
                return ((s == null) ? String.Empty : s);
            }

            set
            {
                ViewState["Text"] = value;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            AddressGrid = new GridView();
            this.Controls.Add(AddressGrid);
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(Text);
        }
    }
}
