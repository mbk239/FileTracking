﻿
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace ControlLibrary.Web
{
    /// <summary>
    /// Class name: TemplateFieldControl
    /// Description: This class performs as Custom TemplateField Control which inherites
    /// from System.Web.UI.WebControls.TemplateField.
    /// The control has all basic properties of TemplateField control.
    /// The control has properties to set or get value of HeaderText that has been replaced HMLT code    
    /// </summary>
    public class TemplateFieldControl:TemplateField
    {
        public new string HeaderText
        {
            get { return base.HeaderText; }
            set { base.HeaderText = TSR.Framework.BaseBusinessEntity.ReplaceHTMLCode(value); }
        }
    }
}
