using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ControlLibrary.Web
{
    /// <summary>
    /// ListPageControl
    /// </summary>
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:ListPageControl runat=server></{0}:ListPageControl>")]
    public class ListPageControl : PlaceHolder
    {
        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        public string Text
        {
            get
            {
                String s = (String)ViewState["Text"];
                return ((s == null) ? String.Empty : s);
            }

            set
            {
                ViewState["Text"] = value;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
        }
    }
}
