﻿using System;
using System.Linq;
using TSR.CommandLine.Core;
using TSR.CommandLine.Core.DataBridgeService;

namespace TSR.CommandLineForDataBridge
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Debug starting");
            //System.Diagnostics.Debugger.Launch();            
            String profileName = string.Empty;
            String filePath = string.Empty;
            DataBridgeSettings profile = null;

            bool isSuccessLogin = false;
            bool isHasPermission = false;
            bool isSeviceUp = false;          

            try
            {
                //Accept invalid certificate
                ImportAndExportDBR.SetPolicy();

                //Check first run
                ImportAndExportDBR.CheckFirstRun();

                try
                {
                    Console.WriteLine("\nChecking server address...");
                    isSeviceUp = ImportAndExportDBR.IsServiceUp();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nError connecting to server");
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                    return;
                }
                if (isSeviceUp)
                {
                    try
                    {
                        Console.WriteLine("\nStarting to login to server...");
                        isSuccessLogin = ImportAndExportDBR.LoginUserToServer(out isHasPermission);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("\nError login user to server");
                        TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        return;
                    }
                    if (isSuccessLogin)
                    {

                        if (isHasPermission)
                        {
                            Console.WriteLine("\nRetrieving license from server...");

                            if (!ImportAndExportDBR.CheckLicense())
                                return;
                            if (args.Length > 0)
                            {
                                switch (args[0])
                                {
                                    case ImportAndExportDBR.IMPORT:
                                        #region Import
                                        if (args.Length > 1)
                                        {
                                            profileName = args[1];

                                            try
                                            {
                                                Console.WriteLine("\nGetting profile from server...");

                                                profile = ImportAndExportDBR.GetDBRSettingForCurrentUser(profileName, false);
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine(string.Format("\nError getting profile \"{0}\"", profileName));
                                                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                                            }

                                            if (profile != null)
                                            {
                                                try
                                                {
                                                    //-i <file_name> -f <file_path> -a
                                                    switch (args.Length)
                                                    {
                                                        case 2: //-i <file_name>
                                                            //Console.WriteLine("\nStarting importing from delimited file to server...");
                                                            ImportAndExportDBR.Import(profile);
                                                            break;
                                                        case 3://-i <file_name> -a
                                                            if (args[2] == ImportAndExportDBR.UPDATEALL)
                                                            {
                                                                ImportAndExportDBR.UpdateAll = true;
                                                            }
                                                            //Console.WriteLine("\nStarting importing from delimited file to server...");
                                                            ImportAndExportDBR.Import(profile);
                                                            break;
                                                        case 4://-i <file_name> -f <file_path>
                                                            filePath = args[3];
                                                            //Console.WriteLine("\nStarting importing from delimited file to server...");
                                                            ImportAndExportDBR.Import(profile, filePath);
                                                            break;
                                                        case 5://-i <file_name> -f <file_path> -a
                                                            filePath = args[3];
                                                            if (args[4] == ImportAndExportDBR.UPDATEALL)
                                                            {
                                                                ImportAndExportDBR.UpdateAll = true;
                                                            }
                                                            else
                                                            {
                                                                ImportAndExportDBR.UpdateAll = false;
                                                            }
                                                            //Console.WriteLine("\nStarting importing from delimited file to server...");
                                                            ImportAndExportDBR.Import(profile, filePath);
                                                            break;
                                                        default:
                                                            break;
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    string message = "Error importing from delimited file";
                                                    Console.WriteLine("\n" + message);
                                                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnknownException(ex);
                                                }
                                                //if (args.Length > 2 && args[2] == UtilityHelper.UPDATEALL)
                                                //{
                                                //    UtilityHelper.UpdateAll = true;
                                                //}
                                                //UtilityHelper.Import(profile);
                                            }
                                            else
                                            {
                                                Console.WriteLine("\nThe profile '" + args[1] + "' does not exist");
                                                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                                {
                                                    LoggingTime = DateTime.Now,
                                                    CreatedTimeStamp = DateTime.Now,
                                                    SessionID = string.Empty,
                                                    MessageSummary = "The profile '" + args[1] + "' does not exist",
                                                    Priority = 0
                                                });
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("\nYou must input profile name");
                                            TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                            {
                                                LoggingTime = DateTime.Now,
                                                CreatedTimeStamp = DateTime.Now,
                                                SessionID = string.Empty,
                                                MessageSummary = "You must input profile name",
                                                Priority = 0
                                            });
                                            Console.WriteLine(ImportAndExportDBR.MESSAGE_HELP);
                                        }
                                        break; 
                                        #endregion

                                    case ImportAndExportDBR.EXPORT:
                                        #region Exprot
                                        if (args.Length > 1)
                                        {
                                            profileName = args[1];
                                            try
                                            {
                                                Console.WriteLine("\nGetting profile from server...");
                                                profile = ImportAndExportDBR.GetDBRSettingForCurrentUser(profileName, true);
                                            }
                                            catch (Exception ex)
                                            {
                                                Console.WriteLine("\n" + string.Format("Error getting profile \"{0}\"", profileName));
                                                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                                            }
                                            if (profile != null)
                                            {
                                                bool success = false;
                                                string fileExportName = string.Empty;
                                                try
                                                {
                                                    //System.Diagnostics.Debugger.Launch();
                                                    if (args.Length > 3 && args[2] == ImportAndExportDBR.FILE_PATH)
                                                    {
                                                        filePath = args[3];
                                                        Console.WriteLine("\nStarting exporting from server to delimited file...");
                                                        success = ImportAndExportDBR.Export(profile, out fileExportName, filePath);
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine("\nStarting exporting from server to delimited file...");
                                                        success = ImportAndExportDBR.Export(profile, out fileExportName);
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    Console.WriteLine("\n" + "Error exporting databridge to delimited file");
                                                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                                                }
                                                if (success)
                                                {
                                                    Console.WriteLine("\n" + "Export to file '" + fileExportName + "' successfully");
                                                }
                                                else
                                                {
                                                    Console.WriteLine("\n" + "Export to file unsuccessfully");
                                                    TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                                    {
                                                        LoggingTime = DateTime.Now,
                                                        CreatedTimeStamp = DateTime.Now,
                                                        SessionID = string.Empty,
                                                        MessageSummary = "Export to file unsuccessfully",
                                                        Priority = 0
                                                    });
                                                }
                                            }
                                            else
                                            {
                                                Console.WriteLine("\n" + "The profile '" + args[1] + "' does not exist");
                                                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                                {
                                                    LoggingTime = DateTime.Now,
                                                    CreatedTimeStamp = DateTime.Now,
                                                    SessionID = string.Empty,
                                                    MessageSummary = "The profile '" + args[1] + "' does not exist",
                                                    Priority = 0
                                                });
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("\n" + "You must input profile name");
                                            TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                            {
                                                LoggingTime = DateTime.Now,
                                                CreatedTimeStamp = DateTime.Now,
                                                SessionID = string.Empty,
                                                MessageSummary = "You must input profile name",
                                                Priority = 0
                                            });
                                            Console.WriteLine("\n" + ImportAndExportDBR.MESSAGE_HELP);
                                        }
                                        break;
                                    case ImportAndExportDBR.HELPER:
                                        Console.WriteLine("\n" + ImportAndExportDBR.MESSAGE_HELP);
                                        //Console.WriteLine(UtilityHelper.MESSAGE_HELP_IMPORT);
                                        break;
                                    default:
                                        Console.WriteLine("'" + args[0] + "' " + ImportAndExportDBR.MESSAGE_COMMAND_FAILURE);
                                        TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                        {
                                            LoggingTime = DateTime.Now,
                                            CreatedTimeStamp = DateTime.Now,
                                            SessionID = string.Empty,
                                            MessageSummary = "'" + args[0] + "' " + ImportAndExportDBR.MESSAGE_COMMAND_FAILURE,
                                            Priority = 0
                                        });
                                        Console.WriteLine("\n" + ImportAndExportDBR.MESSAGE_HELP);
                                        //Console.WriteLine(UtilityHelper.MESSAGE_HELP_IMPORT);
                                        break; 
                                        #endregion
                                }
                            }
                            else
                            {
                                //Console.WriteLine("Input command line");
                                Console.WriteLine(ImportAndExportDBR.MESSAGE_HELP);
                                //Console.WriteLine(UtilityHelper.MESSAGE_HELP_IMPORT);
                            }
                        }
                        else
                        {
                            Console.WriteLine("\n" + "Access to module databridge denied");
                            TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                MessageSummary = "Access to module databridge denied",
                                Priority = 0
                            });
                        }
                    }
                    else
                    {
                        Console.WriteLine("\n" + "This user account does not exist in TSR");
                        TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = "This user account does not exist in TSR",
                            Priority = 0
                        });
                    }
                }
                else
                {
                    Console.WriteLine("\n" + "Connect to server was failed");
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = "Connect to server was failed",
                        Priority = 0
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n" + "Error Message: " + ex.Message);
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);

            }         
        }
    }
}
