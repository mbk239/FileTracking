﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Security.Principal;
using System.IO;

namespace TSR.CommandLine.Core.Logging
{
    /// Class
    /// Name: LoggingHandler
    /// Description: This is a custom Base Log Hangler
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class LoggingHandler
    {
        private const string CONST_XMLLOGFILEPATH = "TSRDBRRollingLogFile.log";

        #region Methods

        public static void LogInfo(Log logObject)
        {
            logObject.Category = "Information";
            HandleException(logObject);
        }
        public static void LogWarning(Log logObject)
        {
            logObject.Category = "Warning";
            HandleException(logObject);
        }

        public static void LogError(Log logObject)
        {
            logObject.Category = "Error";
            HandleException(logObject);
        }
        public static void LogError(Exception exceptionObject)
        {

            Log logObject = new Log()
            {
                Category = "Error",
                ClientHost = exceptionObject.Source,
                CreatedTimeStamp = DateTime.Now,
                CreatorID = -1,
                LoggingTime = DateTime.Now,
                MessageDetail = exceptionObject.Message,
                MessageSummary = exceptionObject.Message,
                ModifiedTimeStamp = DateTime.Now,
                ModifierID = -1,
                Priority = 1,
                StackTrace = exceptionObject.StackTrace,
                InnerException = ((exceptionObject.InnerException != null) ? exceptionObject.InnerException : null)
            };
            logObject.Category = "Error";
            HandleException(logObject);
        }
        public static void LogUnknownException(Exception e)
        {
            HandleException(e, "Unknown Exception");
        }
        public static void LogUnhandledException(Exception e)
        {
            HandleException(e, "Unhandled Exception");
        }

        /// <summary>
        /// This method logs unknown exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        public static void LogUnknownException(Log logObject)
        {
            logObject.Category = "Unknown Exception";
            HandleException(logObject);
        }

        /// <summary>
        /// This method logs unhandled exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        public static void LogUnhandledException(Log logObject)
        {
            logObject.Category = "Unhandled Exception";
            HandleException(logObject);
        }

        /// <summary>
        /// The method logs handled exception
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="logObject">Log entity type</param>
        private static void HandleException(Log logObject)
        {
            ///Check AD authentication
            if (WindowsIdentity.GetCurrent().IsAuthenticated)
            {
                try
                {
                    ///Store Log entity object by RollingFileLoggingHandler
                    using (RollingFileStream _rollingFileStream = new RollingFileStream("TSRLog\\" + CONST_XMLLOGFILEPATH, Int32.MaxValue, 10, FileMode.Append))
                    {
                        _rollingFileStream.CanSplitData = true;
                        using (RollingFileLoggingHandler handler = new RollingFileLoggingHandler(_rollingFileStream))
                        {
                            Trace.AutoFlush = true;
                            Trace.Listeners.Add(handler);
                            Trace.WriteLine(logObject);
                        }
                        //if (handler != null)
                        //{
                        //    handler.Close();
                        //}
                        //if (_rollingFileStream != null)
                        //{
                        //    _rollingFileStream.Close();
                        //}
                    }
                }
                catch (Exception exp)
                {
                    System.Diagnostics.Debug.WriteLine(exp.Message);
                }
                //try
                //{
                //    ///Store Log entity object by DatabaseLoggingHandler
                //    using (DatabaseLoggingHandler databaseHandler = new DatabaseLoggingHandler())
                //    {
                //        Trace.AutoFlush = true;
                //        Trace.Listeners.Add(databaseHandler);
                //        Trace.WriteLine(logObject);
                //    }

                //}
                //catch (Exception exp)
                //{

                //}
            }
        }

        /// <summary>
        /// The method handles an exception with a policy
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="e">Exception type</param>
        /// <param name="policy">String type</param>
        private static void HandleException(Exception e, string policy)
        {

            Log logObject = new Log()
            {
                MessageSummary = e.Message,
                StackTrace = e.StackTrace,
                MessageDetail = e.ToString(),
                Category = policy,
                UserID = 1,
                CreatedTimeStamp = DateTime.Now,
                CreatorID = 1,
                LoggingTime = DateTime.Now,
                Service = e.Source,
                Priority = 1
            };
            HandleException(logObject);
        }

        #endregion


        internal static void LogInfo(string p)
        {
            throw new NotImplementedException();
        }
    }
}
