﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Collections.Specialized;

namespace TSR.CommandLine.Core.Logging
{
    #region Log Entity
    /// <summary>
    /// Class
    /// Name: Log
    /// Description: Log entity class which has multiple 
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class Log
    {
        #region Variables
        private long _ID;
        private long _UserID;
        private String _SessionID = String.Empty;
        private String _ClientHost = String.Empty;
        private String _ServerIP = String.Empty;
        private String _Service = String.Empty;
        private String _Category = String.Empty;
        private int _Priority = 0;
        private DateTime _LoggingTime = DateTime.Now;
        private String _MessageSummary = String.Empty;
        private String _MessageDetail = String.Empty;
        private String _StackTrace = String.Empty;
        private long _CreatorID;
        private DateTime _CreatedTimeStamp;
        private long _ModifierID;
        private DateTime _ModifiedTimeStamp = DateTime.Now;
        #endregion

        #region Properties
        public long ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public long UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }

        public String SessionID
        {
            get { return _SessionID; }
            set { _SessionID = value; }
        }

        public String ClientHost
        {
            get { return _ClientHost; }
            set { _ClientHost = value; }
        }

        public String ServerIP
        {
            get { return _ServerIP; }
            set { _ServerIP = value; }
        }

        public String Service
        {
            get { return _Service; }
            set { _Service = value; }
        }

        public String Category
        {
            get { return _Category; }
            set { _Category = value; }
        }

        public int Priority
        {
            get { return _Priority; }
            set { _Priority = value; }
        }

        public DateTime LoggingTime
        {
            get { return _LoggingTime; }
            set { _LoggingTime = value; }
        }

        public String MessageSummary
        {
            get { return _MessageSummary; }
            set { _MessageSummary = value; }
        }

        public String MessageDetail
        {
            get { return _MessageDetail; }
            set { _MessageDetail = value; }
        }

        public String StackTrace
        {
            get { return _StackTrace; }
            set { _StackTrace = value; }
        }

        public Exception InnerException { get; set; }

        public long CreatorID
        {
            get { return _CreatorID; }
            set { _CreatorID = value; }
        }

        public DateTime CreatedTimeStamp
        {
            get { return _CreatedTimeStamp; }
            set { _CreatedTimeStamp = value; }
        }

        public long ModifierID
        {
            get { return _ModifierID; }
            set { _ModifierID = value; }
        }


        public DateTime ModifiedTimeStamp
        {
            get { return _ModifiedTimeStamp; }
            set { _ModifiedTimeStamp = value; }
        }
        #endregion

        /// <summary>
        /// to string method overriden to facilitate with formatted error message
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string msg = "UserID" + ": " + UserID + "\n" +
                "SessionID" + ": " + SessionID + "\n" +
                "ClientHost" + ": " + ClientHost + "\n" +
                "ServerIP" + ": " + ServerIP + "\n" +
                "Service" + ": " + Service + "\n" +
                "Category" + ": " + Category + "\n" +
                "Priority" + ": " + Priority + "\n" +
                "LoggingTime" + ": " + LoggingTime + "\n" +
                "MessageSummary" + ": " + MessageSummary + "\n" +
                "MessageDetail" + ": " + MessageDetail + "\n" +
                "StackTrace" + ": " + StackTrace + "\n" +
                "CreatorID" + ": " + CreatorID + "\n" +
                "CreatedTimeStamp" + ": " + CreatedTimeStamp + "\n" +
                "ModifierID" + ": " + ModifierID + "\n" +
                "ModifiedTimeStamp" + ": " + ModifiedTimeStamp + "\n";
            if (InnerException != null)
            {
                if(!string.IsNullOrEmpty(InnerException.Message))
                    msg += "InnerException message: " + InnerException.Message + "\n";
                if (!string.IsNullOrEmpty(InnerException.Source))
                    msg += "InnerException source: " + InnerException.Source + "\n";
                if (!string.IsNullOrEmpty(InnerException.StackTrace))
                    msg += "InnerException stacktrace: " + InnerException.StackTrace + "\n";
            }
            return msg;
        }

    }
    #endregion

    #region DatabaseLoggingHandler
    /// Class
    /// Name: DatabaseLoggingHandler
    /// Description: This is a custom Database Tracer which inherits from Trace Listener.
    /// The class store Log entity into Database.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class DatabaseLoggingHandler : TraceListener
    {
        #region Variables
        private const string COLUMN_SEPARATOR = "|";
        //private string m_strConnectionString;
        //private int m_iMaximumRequests;
        private StringCollection m_objCollection;

        #endregion

        #region Constructors
        public DatabaseLoggingHandler()
        {
            InitializeHandler();
        }

        public DatabaseLoggingHandler(string _listenerName)
            : base(_listenerName)
        {
            InitializeHandler();
        }
        #endregion

        #region InitializeHandler
        /// <summary>
        /// Initialize Database handler
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        private void InitializeHandler()
        {
            //set connection string            
            //m_iMaximumRequests = ConstantCollection.MAXIMUMREQUESTS;
            m_objCollection = new StringCollection();
        }
        #endregion

        #region Save Errors
        /// <summary>
        /// 
        /// </summary>
        private void SaveErrors()
        {

        }
        /// <summary>
        /// This methors is used to store Log entity into Data
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="_logObject">Log entity type object</param>
        private void SaveErrors(Log _logObject)
        {   
            try
            {
                //execute to store Log entity object
                

            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                
            }
        }

        /// <summary>
        /// Store Log data into database by passing basic parameters
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="category"></param>
        /// <param name="description"></param>
        /// <param name="stackTrace"></param>
        /// <param name="errorDescription"></param>
        private void SaveErrors(string category,
            string description,
            string stackTrace,
            string errorDescription)
        {
            Log obj = new Log()
            {
                UserID = 1,
                CreatorID = 1,
                CreatedTimeStamp = DateTime.Now,
                Category = category,
                LoggingTime = DateTime.Now,
                MessageSummary = description,
                MessageDetail = errorDescription,
                StackTrace = stackTrace
            };

            SaveErrors(obj);
        }
        #endregion

        #region Override Methods


        public override void Write(string message)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors("", message, objTrace.ToString(), "");
        }

        public override void Write(object o)
        {
            SaveErrors(o as Log);
        }

        public override void Write(string message, string category)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors(category, message, objTrace.ToString(), "");
        }

        public override void Write(object o, string category)
        {
            Log obj = o as Log;
            obj.Category = category;
            SaveErrors(obj);
        }


        public override void WriteLine(string message)
        {
            Write(message + "\n");
        }

        public override void WriteLine(object o)
        {
            Write(o);
        }

        public override void WriteLine(string message, string category)
        {
            Write((message + "\n"), category);
        }

        public override void WriteLine(object o, string category)
        {
            Write(o, category);
        }


        public override void Fail(string message)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors("Fail", message, objTrace.ToString(), "");
        }

        public override void Fail(string message, string detailMessage)
        {
            StackTrace objTrace = new StackTrace(true);
            SaveErrors("Fail", message, objTrace.ToString(), detailMessage);
        }

        public override void Close()
        {
            SaveErrors();
        }

        public override void Flush()
        {
            SaveErrors();
        }
        #endregion
    }
    #endregion
}
