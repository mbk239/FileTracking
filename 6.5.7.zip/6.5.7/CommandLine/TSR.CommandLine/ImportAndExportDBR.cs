﻿using System;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using Microsoft.Win32;


using TSR.CommandLine.Core.DataBridgeService;

namespace TSR.CommandLine.Core
{  
    public class ImportAndExportDBR
    {
        #region Constants
        public const long MAX_FILE_LENGTH = 5000000; //No over 10MB        

        public const string IMPORT = "-i";
        public const string UPDATEALL = "-a";
        public const string EXPORT = "-e";
        public const string FILE_PATH = "-f";
        public const string HELPER = "-help";
        public const string MESSAGE_COMMAND_FAILURE = "is not recognized as an internal or external command,\n operable program or batch file.";
        public const string MESSAGE_HELP_IMPORT = "-i ProfileName -f <file_path> [-a]\t Import data from CSV file to TSR database by using an available profile \n -a: Update all TSR records when importing data \n -f <file path>: full path of file";
        public const string MESSAGE_HELP_EXPORT = "-e ProfileName -f <file_path>\t Export data from TSR database to CSV file by using an available profile \n -f <file_path>: full path of file";
        public const string PERMISSION_DATABRIDGE_KEY = "SECURED_DATABRIDGE_DATABRIDGE_ASPX";
        public const string MESSAGE_HELP = "USAGE:\n\t-i|-e \"ProfileName\" [–f <file_path>] [-a]"
                                            + "\nOptions:\n\t-e\tExport data to TSR database to CSV file by an available profile"
                                            + "\n\t-i\tImport data from CSV file to TSR database by using an available profile\n\t-a\tUpdate all TSR records when importing data\n\t-f <file_path>\tFull path of file";
      

        #endregion

        #region Constructor input data
        public static void CheckFirstRun()
        {
            System.Security.Principal.WindowsIdentity winID = System.Security.Principal.WindowsIdentity.GetCurrent();
            string userName = winID.Name;

            userName = userName.Replace("\\", "_");

            string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\" + Constants.CONST_APPDATA_FOLDER;
            string filePath = folderPath + "\\" + userName + ".ini";

            string commandFilePath = folderPath + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;

            if (!File.Exists(filePath))
            {
                try
                {
                    string appDataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                                        + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
                    string dataFilePath = appDataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
                    //Modified by tsrdev1
                    //Check whether directory appDataFolder is existed
                    if (Directory.Exists(appDataFolder))
                        Directory.Delete(appDataFolder, true);

                    Directory.CreateDirectory(appDataFolder);

                    StreamWriter w = File.CreateText(dataFilePath);
                    w.Write(string.Format("[{0}]",Constants.ROOTCATERGORY));
                    w.Flush();
                    w.Close();
                    w.Dispose();

                    //Set DBR options
                    UtilitiHelper.SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE, 
                        UtilitiHelper.GetValue(commandFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE));

                    UtilitiHelper.SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO,
                        UtilitiHelper.GetValue(commandFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO));

                    UtilitiHelper.SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES,
                        UtilitiHelper.GetValue(commandFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES));
                    
                     RegistryKey dbrKey = null;
                     try
                     {
                         dbrKey = Registry.CurrentUser.OpenSubKey(Constants.DBROptionsLocation, false);
                         if (dbrKey != null)
                         {
                             UtilitiHelper.SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRUSERNAME,
                                 (string)dbrKey.GetValue(Constants.CONST_REGISTRYKEY_USERNAME, string.Empty));

                             UtilitiHelper.SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRPASSWORD,
                                 (string)dbrKey.GetValue(Constants.CONST_REGISTRYKEY_PASSWORD, string.Empty));
                         }
                     }
                     catch (Exception ex)
                     {
                         Logging.LoggingHandler.LogError(ex);
                     }
                     finally
                     {
                         if (dbrKey != null)
                         {
                             dbrKey.Close();
                             Registry.CurrentUser.DeleteSubKey(Constants.DBROptionsLocation);
                         }
                     }

                }
                catch (Exception ex)
                {
                    Logging.LoggingHandler.LogError(ex);
                }

                //Modified by tsrdev1
                //Check whether directory folderPath is existed
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                StreamWriter temp = File.CreateText(filePath);
                temp.Close();
                temp.Dispose();

            }

        }



        public static bool IsSSLMode
        {
            get
            {
                return UtilitiHelper.GetSSLMode();
                //return false;
            }
        }
        public static string serviceAddr
        {
            get
            {
                return UtilitiHelper.GetTSRServices();
                //return "https://tsrvw2k8:444/Services";
                //return "http://localhost:2920/TSR.AdvancedServices";
                //return "https://tsrserver123:4433/Services";
                //return "http://tsrserver123:8085/Services";
            }
        }
        public static string UserName
        {
            get
            {
                return UtilitiHelper.GetUserName();
                //return "tsrdev1";
            }
        }
        public static string Password
        {
            get
            {
                //return "22-78-A0-F7-43-D9-0E-23-B2-FB-4D-00-9E-6A-F1-0A";
                return UtilitiHelper.GetPassword();
            }
        }        
        #endregion
        #region Extra Methods
        public static bool LoginUserToServer(out bool isHasPermission)
        {
            try
            {
                DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);
                RequestMessageOfstring reqUserName = new RequestMessageOfstring();
                RequestMessageOfstring reqPass = new RequestMessageOfstring();

                reqUserName.Data = UserName;
                reqPass.Data = Password;


                ResponseMessageOfboolean result = new ResponseMessageOfboolean();
                ResponseMessageOfboolean resIsHasPermission = new ResponseMessageOfboolean();

                result = service.LogInUser(out resIsHasPermission, reqUserName, reqPass);

                isHasPermission = resIsHasPermission.Data;
                if (!result.Data && !result.IsException && !string.IsNullOrEmpty(result.ErrorMessage))
                {
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = result.ErrorMessage,
                        Priority = 0
                    });
                    Console.Write("\n" + result.ErrorMessage);
                }
                if (result.IsException && !string.IsNullOrEmpty(result.ErrorMessage))
                    throw new Exception(result.ErrorMessage);
                return result.Data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataBridgeSettings GetDBRSettingForCurrentUser(string profileName, bool isExport)
        {
            try
            {
                DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);

                RequestMessageOfstring reqProfileName = new RequestMessageOfstring();
                RequestMessageOfstring reqUserName = new RequestMessageOfstring();
                RequestMessageOfstring reqPass = new RequestMessageOfstring();
                RequestMessageOfboolean reqIsExport = new RequestMessageOfboolean();

                reqProfileName.Data = profileName;
                reqUserName.Data = UserName;
                reqPass.Data = Password;
                reqIsExport.Data = isExport;

                ResponseMessageOfDataBridgeSettings4akJsoFH result = new ResponseMessageOfDataBridgeSettings4akJsoFH();

                result = service.GetDBRSettingsForCurrentUser(reqUserName, reqPass, reqProfileName, reqIsExport);

                return result.Data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool IsServiceUp()
        {
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(serverAddress);
            DataBridgeService.DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);
            int count = 0;
            while (true)
            {
                if (count == Constants.TryConnectToServerCount - 1)
                {
                    try
                    {
                        success = service.IsServiceUp();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    break;
                }
                try
                {
                    success = service.IsServiceUp();
                    break;
                }
                catch
                {
                }
                count++;
            }

            return success;
        }

        public static bool IsServiceUp(string serverAddr, bool isSSLMode)
        {
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(serverAddress);
            DataBridgeService.DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serverAddr, isSSLMode);
            int count = 0;
            while (true)
            {
                if (count == Constants.TryConnectToServerCount - 1)
                {
                    try
                    {
                        success = service.IsServiceUp();
                    }                    
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    break;
                }
                try
                {
                    success = service.IsServiceUp();
                    break;
                }
                catch
                {
                }
                count++;
            }

            return success;
        }
        private static Encoding DetectEncodingOfSourceFile(string filePath)
        {
            System.Text.Encoding enc = null;
            System.IO.FileStream file = new System.IO.FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
            if (file.CanSeek)
            {
                byte[] bom = new byte[4]; // Get the byte-order mark, if there is one
                file.Read(bom, 0, 4);
                if ((bom[0] == 0xef && bom[1] == 0xbb && bom[2] == 0xbf) || // utf-8
                    (bom[0] == 0xff && bom[1] == 0xfe) || // ucs-2le, ucs-4le, and ucs-16le
                    (bom[0] == 0xfe && bom[1] == 0xff) || // utf-16 and ucs-2
                    (bom[0] == 0 && bom[1] == 0 && bom[2] == 0xfe && bom[3] == 0xff)) // ucs-4
                {
                    if (bom[0] == 0xef && bom[1] == 0xbb && bom[2] == 0xbf)
                    {
                        enc = Encoding.UTF8;
                    }
                    else if ((bom[0] == 0xff && bom[1] == 0xfe) || // ucs-2le, ucs-4le, and ucs-16le
                                (bom[0] == 0xfe && bom[1] == 0xff)) // utf-16 and ucs-2
                        enc = System.Text.Encoding.Unicode;
                    else
                        enc = Encoding.UTF7;
                }
                else
                {
                    enc = System.Text.Encoding.ASCII;
                }

                // Now reposition the file cursor back to the start of the file
                file.Seek(0, System.IO.SeekOrigin.Begin);
            }
            else
            {
                enc = System.Text.Encoding.ASCII;
            }
            file.Close();

            return enc;
        }

        private static string GetContentFile(string filePath)
        {
            string content = string.Empty;
            StreamReader file = null;
            if (File.Exists(filePath))
            {
                try
                {
                    file = new StreamReader(filePath, true);                    
                    content = file.ReadToEnd();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (file != null)
                        file.Close();
                }
            }
            else
            {
                throw new Exception(string.Format("Specified file does not exist, unable to load file - {0}", filePath));
            }
            return content;
        }

        //private static byte[] GetContentFile(string filePath)
        //{
        //    FileStream fs = File.OpenRead(filePath);
        //    try
        //    {
        //        byte[] bytes = new byte[fs.Length];
        //        fs.Read(bytes, 0, Convert.ToInt32(fs.Length));
        //        fs.Close();

        //        return bytes;
        //    }
        //    finally
        //    {
        //        fs.Close();
        //    }

        //}

        public static bool UploadFileToServer(string filePath, string fileName)
        {
            try
            {
                System.Net.WebClient client = new System.Net.WebClient();

                System.Net.NetworkCredential nc = System.Net.CredentialCache.DefaultNetworkCredentials;

                Uri addy = new Uri(serviceAddr + "\\App_Data\\" + fileName);

                client.Credentials = nc;

                client.UploadFile(addy, fileName);

                byte[] arrReturn = client.UploadFile(addy, filePath);

                Console.WriteLine(arrReturn.ToString());

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }

        }


        #endregion

        #region Export Utilities
        public static bool Export(DataBridgeSettings profile, out string fileExportName)
        {
            if (!profile.IsExport)
            {
                Console.WriteLine("Invalid profile\n");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Invalid profile",
                    Priority = 0
                });
                fileExportName = string.Empty;
                return false;
            }
            bool success = false;
            fileExportName = string.Empty;
            try
            {
                if (profile.IsDelimited)
                {
                    try
                    {
                        success = ExportToDelimitedFile(profile, out fileExportName);
                    }
                    catch (Exception ex)
                    {
                        Logging.LoggingHandler.LogUnknownException(ex);
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            finally
            {

            }
            return success;
        }

        public static bool Export(DataBridgeSettings profile, out string fileExportName, string filePath)
        {
            if (!profile.IsExport)
            {
                Console.WriteLine("Invalid profile\n");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Invalid profile",
                    Priority = 0
                });
                fileExportName = string.Empty;
                return false;
            }
            bool success = false;
            fileExportName = string.Empty;
            if (profile.IsDelimited)
            {
                try
                {
                    success = ExportToDelimitedFile(profile, out fileExportName, filePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error exporting databridge to delimited file");
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnknownException(ex);
                }
            }
            return success;
        }

        public static bool ExportToDelimitedFile(DataBridgeSettings settings, out string fileExportName)
        {
            string fileContent = string.Empty;
            string tsrTypeName = settings.TSREntityTypeName;

            if (!string.IsNullOrEmpty(settings.DelimiterFilePath))
            {
                tsrTypeName = settings.DelimiterFilePath;
            }

            fileExportName = System.AppDomain.CurrentDomain.BaseDirectory + "\\" + tsrTypeName + DateTime.Now.ToString("dd.MM.yy.hh.mm.ss") + ".csv";
            try
            {
                DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);
                RequestMessageOfstring reqProfile = new RequestMessageOfstring();
                RequestMessageOfstring reqUserName = new RequestMessageOfstring();
                RequestMessageOfstring reqPass = new RequestMessageOfstring();

                reqProfile.Data = settings.Name;
                reqUserName.Data = UserName;
                reqPass.Data = Password;

                ResponseMessageOfstring result = new ResponseMessageOfstring();

                result = service.ExportToTextDelimitedContent(reqUserName, reqPass, reqProfile);

                if ((!result.IsSuccessful) && (result.IsException))
                    throw new Exception(result.ErrorMessage);
                else if ((!result.IsSuccessful) && (!result.IsException))
                {
                    Console.WriteLine("\n" + result.ErrorMessage);
                    return false;
                }

                fileContent = result.Data;

                FileStream fileExport = File.Create(fileExportName);
                using (StreamWriter writer = new StreamWriter(fileExport))
                {
                    writer.Write(fileContent);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public static bool ExportToDelimitedFile(DataBridgeSettings settings, out string fileExportName, string filePath)
        {
            string fileContent = string.Empty;
            fileExportName = filePath;// +"\\" + tsrType.Name + DateTime.Now.ToString("dd.MM.yy.hh.mm.ss") + ".csv";
            try
            {
                DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);
                RequestMessageOfstring reqProfile = new RequestMessageOfstring();
                RequestMessageOfstring reqUserName = new RequestMessageOfstring();
                RequestMessageOfstring reqPass = new RequestMessageOfstring();

                reqProfile.Data = settings.Name;
                reqUserName.Data = UserName;
                reqPass.Data = Password;

                ResponseMessageOfstring result = new ResponseMessageOfstring();

                result = service.ExportToTextDelimitedContent(reqUserName, reqPass, reqProfile);

                if ((!result.IsSuccessful) && (result.IsException))
                    throw new Exception(result.ErrorMessage);
                else if ((!result.IsSuccessful) && (!result.IsException))
                {
                    Console.WriteLine("\n" + result.ErrorMessage);
                    return false;
                }

                fileContent = result.Data;

                FileStream fileExport = File.Create(fileExportName);
                using (StreamWriter writer = new StreamWriter(fileExport))
                {
                    writer.Write(fileContent);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
        #endregion

        #region Properties
        public static long PauseIndex;
        public static bool UpdateAll;
        public static bool IsStopImport;
        #endregion

        #region Import Utilities
        public static void Import(DataBridgeSettings profile)
        {
            if (profile.IsExport)
            {
                Console.WriteLine("Invalid profile");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Invalid profile",
                    Priority = 0
                });
                Console.WriteLine("\nImport unsuccessfully");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Import unsucessfully",
                    Priority = 0
                });
                return;
            }
            string serverPathFile = GetServerFullPath(profile.DelimiterFilePath);

            if (!File.Exists(serverPathFile))
            {
                Console.Write(string.Format("\nSpecified file does not exist, unable to load file - {0}", serverPathFile));
                return;
            }

            System.IO.FileInfo fileInfo = new System.IO.FileInfo(serverPathFile);

            //Checking valid of size of file
            long fileLength = fileInfo.Length;
            if (fileLength > MAX_FILE_LENGTH)
            {
                Console.Write("\nMaximum delimited file length exceeded");
                return;
            }

            string fileName = "importDBR_" + Guid.NewGuid() + fileInfo.Extension;

            Console.Write("\nUploading delimited file for importing databridge...");
            try
            {
                UploadFile(serverPathFile, fileName);
            }
            catch (Exception ex)
            {
                Console.Write("\nUploading delimited file was unsuccessful");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return;
            }

            //Encoding encoding = DetectEncodingOfSourceFile(serverPathFile);
            //string fileContent = GetContentFile(serverPathFile);
            Console.Write("\nStarting importing from delimited file to server...");

            if (profile.IsDelimited)
            {
                try
                {
                    ImportFromTextFile(fileName,profile.Name);
                }
                catch (Exception ex)
                {
                    string message = "\nError importing from delimited file";
                    Console.Write(message);
                    Logging.LoggingHandler.LogUnknownException(ex);
                }
            }
        }

        public static void Import(DataBridgeSettings profile, string filePath)
        {
            if (profile.IsExport)
            {
                Console.WriteLine("Invalid profile");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Invalid profile",
                    Priority = 0
                });
                Console.WriteLine("\nImport unsuccessfully");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = "Import unsucessfully",
                    Priority = 0
                });
                return;
            }
            string serverPathFile = filePath;

            if (!File.Exists(serverPathFile))
            {
                Console.Write(string.Format("\nSpecified file does not exist, unable to load file - {0}", serverPathFile));
                return;
            }
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(serverPathFile);

            //Checking valid of size of file
            long fileLength = fileInfo.Length;
            if (fileLength > MAX_FILE_LENGTH)
            {
                Console.Write("\nMaximum delimited file length exceeded");
                return;
            }

            string fileName = "importDBR_" + Guid.NewGuid() + fileInfo.Extension;


            Console.Write("\nUploading delimited file for importing databridge...");
            try
            {
                UploadFile(serverPathFile, fileName);
            }
            catch (Exception ex)
            {
                Console.Write("\nUploading delimited file was unsuccessful");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return;
            }

            //Encoding encoding = DetectEncodingOfSourceFile(serverPathFile);
            //string fileContent = GetContentFile(serverPathFile);
            Console.Write("\nStarting importing from delimited file to server...");

            if (profile.IsDelimited)
            {
                try
                {
                    ImportFromTextFile(fileName, profile.Name);
                }
                catch (Exception ex)
                {
                    string message = "\nError importing from delimited file";
                    Console.Write(message);
                    Logging.LoggingHandler.LogUnknownException(ex);
                }
            }
        }

        private static void ImportFromTextFile(string fileName,string profileName)
        {
            string message = string.Empty;
            try
            {
                DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);

                while (true)
                {
                    //DataBridgeFacade.IsUpdateAll = UpdateAll;
                    service.GetOrSetIsUpdateAll(UpdateAll, true);

                    try
                    {
                        //using (DataBridgeFacade facade = new DataBridgeFacade(GetCurrentUserContext()))
                        //{
                        //    PauseIndex = facade.importFromDelimitedFile(serverPathFile, entityMappingInfo, delimiter, applicationID, PauseIndex);
                        //}

                        RequestMessageOfstring reqFileContent = new RequestMessageOfstring();
                        //RequestMessageOfint reqCodePage = new RequestMessageOfint();
                        RequestMessageOfstring reqProfileName = new RequestMessageOfstring();
                        RequestMessageOflong reqPauseIndex = new RequestMessageOflong();
                        RequestMessageOfstring reqUserName = new RequestMessageOfstring();
                        RequestMessageOfstring reqPass = new RequestMessageOfstring();

                        reqFileContent.Data = fileName;
                        //reqFileContent.Data = "OrgID\tOrgName\r\n\"3\tImp_Organization_03\"\r\n\"4\tImp_Organization_04\"\r\n";
                        //reqCodePage.Data = encoding.CodePage;
                        reqProfileName.Data = profileName;
                        reqPauseIndex.Data = PauseIndex;
                        reqUserName.Data = UserName;
                        reqPass.Data = Password;

                        ResponseMessageOflong resPauseIndex = new ResponseMessageOflong();

                        //resPauseIndex = service.ImportFromDelimitedFile(reqUserName, reqPass, reqFileContent, reqCodePage, reqProfileName, reqPauseIndex);
                        resPauseIndex = service.ImportFromDelimitedFile(reqUserName, reqPass, reqFileContent, reqProfileName, reqPauseIndex);

                        if ((!resPauseIndex.IsSuccessful) && (resPauseIndex.IsException))
                            throw new Exception(resPauseIndex.ErrorMessage);
                        else if ((!resPauseIndex.IsSuccessful) && (!resPauseIndex.IsException))
                        {
                            Console.WriteLine("\n" + resPauseIndex.ErrorMessage);
                            return;
                        }

                        PauseIndex = resPauseIndex.Data;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    if (service.GetOrSetIsPausedImportProcess(false, false))
                    {
                        message = service.GetOrSetExternalKeyIsPaused(string.Empty, false) + "already existing in database. Do you want to update this record? (Y/N/A)";                        
                        Console.WriteLine();
                        Console.WriteLine(message);
                        short isUpdate = 0;
                        while (true)
                        {
                            Console.Write("Please press 'y': update,'n': stop importing,'a': update for all records: ");
                            ConsoleKeyInfo keyInfo = Console.ReadKey();
                            switch (keyInfo.KeyChar.ToString().ToLower())
                            {
                                case "y":
                                    isUpdate = 1;
                                    break;
                                case "n":
                                    isUpdate = 2;
                                    break;
                                case "a":
                                    isUpdate = 3;
                                    break;
                                default:
                                    continue;
                            }
                            if (isUpdate != 0)
                                break;
                        }
                        if (isUpdate == 1)
                        {
                            continue;
                        }
                        else if (isUpdate == 3)
                        {
                            UpdateAll = true;
                            continue;
                        }
                        else if (isUpdate == 2)
                        {
                            IsStopImport = true;
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                if (true)
                {
                    message = string.Empty;
                    string strFailedLog = service.GetOrSetStrFailedLog(string.Empty, false);
                    string strInsertedLog = service.GetOrSetStrInsertedLog(string.Empty, false);
                    string strUpdatedLog = service.GetOrSetStrUpdatedLog(string.Empty, false);
                    if (IsStopImport)
                    {
                        service.GetOrSetTotalRecords(PauseIndex, true);
                        //DataBridgeFacade.totalRecords = PauseIndex;
                    }
                    //long countFailed = DataBridgeFacade.totalRecords - DataBridgeFacade.countInserted - DataBridgeFacade.countUpdated;
                    long countInserted = service.GetOrSetCountInserted(-1, false);
                    long countUpdated = service.GetOrSetCountUpdated(-1, false);
                    long totalRecords = service.GetOrSetTotalRecords(-1, false);
                    long countFailed = totalRecords - countInserted - countUpdated;
                    if (countInserted > 0)
                        message += "\nINSERTED SUCCESS (" + countInserted + "):"
                                          + strInsertedLog;
                    else
                        message += "\nNo item is inserted";

                    if (countUpdated > 0)
                        message += "\nUPDATED SUCCESS (" + countUpdated + "):"
                                          + strUpdatedLog;
                    else
                        message += "\nNo item is updated";

                    if (!string.IsNullOrEmpty(strFailedLog))
                    {
                        message += "\nFAILED! (" + countFailed + "): "
                                          + strFailedLog;

                        TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = message,
                            Priority = 0
                        });
                    }
                    Console.WriteLine();
                    Console.WriteLine(message);
                    if (IsStopImport)
                    {
                        Console.WriteLine("IMPORT IS CANCELED");
                        TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = "IMPORT IS CANCELED",
                            Priority = 0
                        });
                    }

                    //DataBridgeFacade.totalRecords = 0;
                    //DataBridgeFacade.countInserted = 0;
                    //DataBridgeFacade.countUpdated = 0;
                    //DataBridgeFacade.strFailedLog = string.Empty;
                    //DataBridgeFacade.strUpdatedLog = string.Empty;
                    //DataBridgeFacade.strInsertedLog = string.Empty;
                    //DataBridgeFacade.IsUpdateAll = false;
                    //DataBridgeFacade.IsPausedImportProcess = false;
                    //DataBridgeFacade.externalKeyIsPaused = string.Empty;
                    service.ResetAllImportKey();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private static string GetServerFullPath(string fileName)
        {
            return System.AppDomain.CurrentDomain.BaseDirectory + "\\" + fileName;
        }

        #endregion       
         /// <summary>
        /// Method for retrieving license information for server
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        internal static ApplicationLicense FetchAndProcessLicenseInformation(out string error)
        {
            ApplicationLicense license = null;
            error = string.Empty;
            RequestMessageOfstring reqUserName = new RequestMessageOfstring();
            RequestMessageOfstring reqPass = new RequestMessageOfstring();
            ResponseMessageOfApplicationLicenseIOX2hSuW resLicense = new ResponseMessageOfApplicationLicenseIOX2hSuW();

            reqUserName.Data = UserName;
            reqPass.Data = Password;
            
            DataBridgeServiceClient service = ServiceProvider.GetDataBridgeService(serviceAddr, IsSSLMode);

            resLicense = service.GetLicense63(reqUserName,reqPass);
            if (resLicense.IsSuccessful)
            {

                license =  resLicense.Data;
            }
            else
            {                
                if (resLicense.IsException)
                    throw new Exception(resLicense.ErrorMessage);
                else
                {
                    error = resLicense.ErrorMessage;                    
                }                
            }
            return license;
            
        }
        #region Check valid license
        /// <summary>
        /// Check license demo
        /// </summary>
        /// <returns></returns>
        protected static bool CheckLicenseDemo(ApplicationLicense license)
        {
            string error = string.Empty;                                          
            if (license.LicenseType == LicenseTypes.Demo)
            {
                string val = string.Empty;

                val = license.MaintenanceExpiry.Date.ToString();
                if (val != "")
                {
                    DateTime dateEnd = license.MaintenanceExpiry.Date;
                    if (dateEnd > DateTime.Today)
                        return true;
                }

            }
                
            return false;
        }


        // end edit

        private static bool CheckLicenseVersion(ApplicationLicense aLicense)
        {
            //string strVersion = aLicense.Version;
            //string[] arrSubVersion = strVersion.Split('.');
            //if (arrSubVersion.Length == 1)
            //{
            //    strVersion = strVersion + ".0";
            //}
            //else if (arrSubVersion.Length == 2)
            //{

            //}
            //else if (arrSubVersion.Length > 2)
            //{
            //    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
            //}

            //if (strVersion != Version)
            //{
            //    MessageContainer msgContainer;
            //    string message = string.Empty;

            //    message = ResourceManager.GetResourceString("InvalidLicense", "Invalid license");
            //    msgContainer = new MessageContainer(MessageTypeEnum.Failure, message, null);
            //    CustomMaster.Parameters.Add(msgContainer);
            //    return false;
            //}
            return true;
        }

        public static bool CheckLicense()
        {
            try
            {
                bool success = false;
                string error = string.Empty;
                bool isDemo = false;
                ApplicationLicense license = null;
                try
                {
                    license = FetchAndProcessLicenseInformation(out error);                 
                    if (license == null && !string.IsNullOrEmpty(error))
                    {
                        Console.WriteLine("\n" + error);
                        TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            Priority = 0,
                            MessageSummary = error
                        });
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nError getting license from server");
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                    return false;
                }

                if (license != null)
                {
                    if (!CheckLicenseVersion(license))
                    {
                        //success = false;
                    }
                    else
                    {
                        success = true;
                        if (license.LicenseType == LicenseTypes.Demo)
                        {
                            isDemo = true;
                            success = CheckLicenseDemo(license);

                        }
                    }
                }

                if (success)
                {

                    Console.WriteLine("Retrieving license information from server successful.");                    
                    if (!isDemo)
                    {
                        foreach (ModuleLicense item in license.Modules)
                        {
                            if (item.Key.Contains("TSR-EXP"))
                                continue;

                            if (item.FunctionalExpiryDate < DateTime.Today)
                            {
                                success = false;
                                string strSynchroinzation = "Synchronization will stop now..";
                                Console.WriteLine("\n" + "License has been expired" + Environment.NewLine + strSynchroinzation);                                
                                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    Priority = 0,
                                    MessageSummary = "License has been expired"
                                });
                                break;
                            }
                        }
                    }
                }
                else
                {                    
                    Console.WriteLine("Retrieval license  in CommandLine failed" + Environment.NewLine + "Please contact to your administrator");
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogError(new TSR.CommandLine.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = "Retrieval license  in CommandLine failed"
                    });
                }               
                return success;
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nError getting license from server");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return false;                
            }
        }

        private static string Version
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;
                string strVersion = v.ToString();
                string[] arrSubVersion = strVersion.Split('.');
                if (arrSubVersion.Length == 1)
                {
                    strVersion = strVersion + ".0";
                }
                else if (arrSubVersion.Length == 2)
                {

                }
                else if (arrSubVersion.Length > 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                }
                return strVersion;
            }
        }
        #endregion
        #region Accecpt invalid certificate
        public static void SetPolicy()
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback += new System.Net.Security.RemoteCertificateValidationCallback(ValidateRemoteCertificate);
            
        }

        // callback used to validate the certificate in an SSL conversation
        private static bool ValidateRemoteCertificate(
        object sender,
            X509Certificate certificate,
            X509Chain chain,
            System.Net.Security.SslPolicyErrors policyErrors
        )
        {
            return true;
            //if (Convert.ToBoolean(ConfigurationManager.AppSettings["IgnoreSslErrors"]))
            //{
            //    // allow any old dodgy certificate...
            //    return true;
            //}
            //else
            //{
            //    return policyErrors == SslPolicyErrors.None;
            //}
        }


        #endregion

        #region Upload File to Server
        public static void UploadFile(string filePath, string fileName)
        {
            //TSR.CommandLine.Core.FileTransferService.RequestMessageOfRemoteFileInfoMTRdQN6P reqFileInfo = new TSR.CommandLine.Core.FileTransferService.RequestMessageOfRemoteFileInfoMTRdQN6P();
            //TSR.CommandLine.Core.FileTransferService.ResponseMessageOfstring res = new TSR.CommandLine.Core.FileTransferService.ResponseMessageOfstring();

            //TSR.CommandLine.Core.FileTransferService.RemoteFileInfo info = new TSR.CommandLine.Core.FileTransferService.RemoteFileInfo();
           // get some info about the input file
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(filePath);
            
            System.IO.FileStream stream = new System.IO.FileStream(filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read);

            //info.FileName = fileName;
            //info.Length = fileInfo.Length;
            //info.FileByteStream = stream;

            //reqFileInfo.Data = info;

            TSR.CommandLine.Core.FileTransferService.FileTransferServiceClient service = ServiceProvider.GetFileTransferService(serviceAddr, IsSSLMode);

            service.Open();
            service.UploadFile(fileName,fileInfo.Length,stream);
            service.Close();

            stream.Close();
            stream.Dispose();                                               
        }
        #endregion
    }
}
