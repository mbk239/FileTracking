﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using DBRS = TSR.CommandLine.Core.DataBridgeService;

namespace TSR.CommandLine.Core
{
    public class ServiceProvider
    {
        //private static AUS.AuthenticationService _AUService;
        private static DBRS.DataBridgeServiceClient _DBRService;
        private static System.Net.CookieContainer _Container;
        //private static System.Net.ICredentials _Credentials;

        private static System.Net.CookieContainer Container
        {
            get
            {
                if (_Container == null)
                    _Container = new System.Net.CookieContainer();
                return _Container;
            }
        }

        public static DBRS.DataBridgeServiceClient GetDataBridgeService(bool isSSLMode)
        {
            return GetDataBridgeService(string.Empty, isSSLMode);
        }

        /// <summary>
        /// retrieves databridge service
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        public static DBRS.DataBridgeServiceClient GetDataBridgeService(string address, bool isSSLMode)
        {

            //string serverAdd = (string.IsNullOrEmpty(address) ? SettingsHelper.TSRServerAddress + "/UserAgentService.svc" : address + "/UserAgentService.svc");
            address += "/DataBridgeService.svc";
            BasicHttpBinding CurrentBasicHttpBinding;
            CurrentBasicHttpBinding = new BasicHttpBinding();
            CurrentBasicHttpBinding.MaxReceivedMessageSize = 204003200; // Int32.MaxValue;
            CurrentBasicHttpBinding.MaxBufferSize = 204003200;
            CurrentBasicHttpBinding.TransferMode = TransferMode.Buffered;
            //CurrentBasicHttpBinding.MessageEncoding = WSMessageEncoding.Mtom;
            CurrentBasicHttpBinding.ReaderQuotas.MaxStringContentLength = 2147483647;

            if (isSSLMode)
            {
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.Transport;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            }
            else
            {
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.None;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            }
            CurrentBasicHttpBinding.SendTimeout = new System.TimeSpan(0, 10, 0);


            EndpointAddress endpoint = new EndpointAddress(address); //"http://localhost:49585/Contest.TSR.AdvancedServices/UserAgentService.svc");
            _DBRService = new TSR.CommandLine.Core.DataBridgeService.DataBridgeServiceClient(CurrentBasicHttpBinding, endpoint);
            _DBRService.ChannelFactory.Credentials.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;
            //if (!isSSLMode)
            //    _DBRService.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;


            return _DBRService;
        }

        /// <summary>
        /// retrieves databridge service
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        public static TSR.CommandLine.Core.FileTransferService.FileTransferServiceClient GetFileTransferService(string address, bool isSSLMode)
        {

            //string serverAdd = (string.IsNullOrEmpty(address) ? SettingsHelper.TSRServerAddress + "/UserAgentService.svc" : address + "/UserAgentService.svc");
            address += "/FileTransferService.svc";
            BasicHttpBinding CurrentBasicHttpBinding;
            CurrentBasicHttpBinding = new BasicHttpBinding();
            CurrentBasicHttpBinding.MaxReceivedMessageSize = 10067108864; // Int32.MaxValue;
            //CurrentBasicHttpBinding.MaxBufferSize = 204003200;
            CurrentBasicHttpBinding.TransferMode = TransferMode.Streamed;
            CurrentBasicHttpBinding.MessageEncoding = WSMessageEncoding.Mtom;
            //CurrentBasicHttpBinding.ReaderQuotas.MaxStringContentLength = 2147483647;

            if (isSSLMode)
            {
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.Transport;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            }
            else
            {
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.None;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            }
            CurrentBasicHttpBinding.SendTimeout = new System.TimeSpan(0, 10, 0);


            EndpointAddress endpoint = new EndpointAddress(address); //"http://localhost:49585/Contest.TSR.AdvancedServices/UserAgentService.svc");
            TSR.CommandLine.Core.FileTransferService.FileTransferServiceClient _fileTransferService = new TSR.CommandLine.Core.FileTransferService.FileTransferServiceClient(CurrentBasicHttpBinding, endpoint);
            _fileTransferService.ChannelFactory.Credentials.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;
            //if (!isSSLMode)
            //    _fileTransferService.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;

            return _fileTransferService;
        }
    }
}
