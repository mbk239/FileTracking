﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Security.Principal;
namespace TSR.CommandLine.Core
{
    public class Constants
    {
        public const int ENTITY_TYPE_ORGANIZATION = 1;
        public const int ENTITY_TYPE_PROJECT = 2;
        public const int ENTITY_TYPE_ACTIVITY = 3;
        public const int ENTITY_TYPE_CONTACT = 4;
        public const int ENTITY_TYPE_TIMEENTRY = 5;
        public const int TryConnectToServerCount = 2;

        public const string CONST_REGISTRYKEY_SERVERADDRESS = "ServerAddr";
        public const string CONST_REGISTRYKEY_INSTALLATIONMODE = "InstallationMode";
        public const string CONST_REGISTRYKEY_CUSTOMERNO = "CustomerNo";
        public const string CONST_REGISTRYKEY_USERNAME = "UserName";
        public const string CONST_REGISTRYKEY_PASSWORD = "Password";
        public const string CONST_REGISTRYKEY_SSLMODE = "SSLMode";

        public const string CONST_APPDATA_FOLDER = "TSRDataBridge_Data";
        public const string CONST_INIFILEPATH = "TSRDBROption.ini";
        public const string CONST_FOLDER_SEPERATOR = "\\";

        public const string CONST_OPTION_VERBOSE = "Verbose";
        public const string CONST_OPTION_INSTALLATIONMODE = "InstallationMode";
        public const string CONST_OPTION_CUSTOMERNO = "CustomerNo";
        public const string CONST_OPTION_TSRSERVICES = "TSRServices";
        public const string CONST_OPTION_TSRUSERNAME = "TSRUsername";
        public const string CONST_OPTION_TSRPASSWORD = "TSRPassword";
        public const string CONST_OPTION_TSRSSLMODE = "TSRSSLMode";        

        public const string ROOTCATERGORY = "DBRRUNTIMEOPTION";

        public const string DBROptionsLocation = @"Software\CommandLine";
    }
    public enum ValidationMode
    {
        AD,
        NONAD
    }
    public enum ExchangeMode
    {
        No = 0,
        Yes = 1

    }
    public class UtilitiHelper
    {
        public const string DBROptionsLocation = @"Software\CommandLine";

        private const string addinLocation = "CommandLine";
        private const string LocationRoot = "Software";
        private const string TSRINIFilePathKey_Name = "TSRINIFilePath";
        private const string USER_SID = "USERSID";

        public static readonly string Y_IN_LOWER_CHARS = "y";
        public static readonly string YES_IN_LOWER_CHARS = "yes";
        public static readonly string ROOTCATERGORY = "DBRRUNTIMEOPTION";
        public static readonly string VERBOSE = "Verbose";
        public static readonly string INSTALLATIONMODE = "NONAD";
        public static readonly string CUSTOMERNO = "";
        public static readonly string TSRSERVICES = "https://tsrserver.net/%OrgId%/Service";

        //public static readonly string CUSTOMERNO_VARIABLENAME = "%OrgId%";
        #region DBR Installation Constant
        public static readonly string BLANK_IN_LOWER_CHARS = "blank";
        public static readonly string CONST_OPTION_VERBOSE = "Verbose";
        public static readonly string CONST_OPTION_INSTALLATIONMODE = "InstallationMode";
        public static readonly string CONST_OPTION_CUSTOMERNO = "CustomerNo";
        public static readonly string CONST_OPTION_TSRSERVICES = "TSRServices";
        public static readonly string CONST_OPTION_TSRWEBADMIN = "TSRWebAdmin";
        public static readonly string CONST_OPTION_EXCHANGEMODE = "ExchangeMode";
        public static readonly string CUSTOMERNO_VARIABLENAME = "%OrgId%";
        #endregion

        #region Variable
        [DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int GetPrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpDefault,
            string lpReturnString,
            int nSize,
            string lpFilename);

        [DllImport("KERNEL32.DLL", EntryPoint = "WritePrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int WritePrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpString,
            string lpFilename);
        #endregion Variable

        #region Read ini file
        /// <summary>
        /// Get value from ini file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="cate"></param>
        /// <param name="strKey"></param>
        /// <returns></returns>
        public static string GetValue(string path, string cate, string strKey)
        {
            string defaultValue = "???";
            string iniFile = path;
            string value = "";
            try
            {
                List<string> categories = GetCategories(iniFile);
                foreach (string category in categories)
                {
                    if (category == cate)
                    {
                        List<string> keys = GetKeys(iniFile, category);
                        foreach (string key in keys)
                        {
                            if (key == strKey)
                            {
                                value = GetIniFileString(iniFile, category, key, defaultValue);
                            }
                        }
                    }
                }                
            }
            catch
            {
            }
            if (!string.IsNullOrEmpty(value) && value.ToLower() == BLANK_IN_LOWER_CHARS)
                value = string.Empty;
            return value;
        }
        /// <summary>
        /// Set value to ini file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="cate"></param>
        /// <param name="strKey"></param>
        /// <param name="strValue"></param>
        /// <returns></returns>
        public static bool SetValue(string path, string cate, string strKey, string strValue)
        {
            string iniFile = path;
            string value = string.Empty;
            try
            {
                List<string> categories = GetCategories(iniFile);
                if (categories.Contains(cate))
                    return SetIniFileString(iniFile, cate, strKey, strValue) > 0;
            }
            catch
            {
            }
            return false;
        }

        /// <summary>
        /// Gets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static string GetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            string returnString = new string(' ', 1024);
            GetPrivateProfileString(category, key, defaultValue, returnString, 1024, iniFile);
            return returnString.Split('\0')[0];
        }

        /// <summary>
        /// Sets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static int SetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            return WritePrivateProfileString(category, key, defaultValue, iniFile);
        }

        /// <summary>
        /// Gets the keys.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        private static List<string> GetKeys(string iniFile, string category)
        {
            string returnString = new string(' ', 32768);
            GetPrivateProfileString(category, null, null, returnString, 32768, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <returns></returns>
        private static List<string> GetCategories(string iniFile)
        {
            string returnString = new string(' ', 65536);
            GetPrivateProfileString(null, null, null, returnString, 65536, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }
        #endregion

        #region Methods
        public static bool CheckValidConfigurationFile(string filePath)
        {
            string strValidationMode = GetValue(filePath, ROOTCATERGORY, CONST_OPTION_INSTALLATIONMODE);

            ValidationMode mode;
            if ((!string.IsNullOrEmpty(strValidationMode)) && ((strValidationMode.ToUpper() == ValidationMode.AD.ToString()) ||
                (strValidationMode.ToUpper() == ValidationMode.NONAD.ToString())))
                mode = (strValidationMode.ToUpper() == ValidationMode.AD.ToString()) ? ValidationMode.AD : ValidationMode.NONAD;
            else
                return false;

            if (mode == ValidationMode.NONAD)
                if (string.IsNullOrEmpty(GetValue(filePath, ROOTCATERGORY, CONST_OPTION_CUSTOMERNO)))
                    return false;

            if (string.IsNullOrEmpty(GetValue(filePath, ROOTCATERGORY, CONST_OPTION_TSRSERVICES)))
                return false;

            return true;
        }

        public static bool StorteINIFilePath(string filePath)
        {
            RegistryKey currentRootKey = null;            
            RegistryKey TSRINIFilePathKey = null;            
            try
            {
                currentRootKey = Registry.LocalMachine.OpenSubKey(LocationRoot, true);
                if (currentRootKey != null)
                {
                    TSRINIFilePathKey = currentRootKey.OpenSubKey(addinLocation, true);
                    if (TSRINIFilePathKey == null)
                        TSRINIFilePathKey = currentRootKey.CreateSubKey(addinLocation);

                    TSRINIFilePathKey.SetValue(TSRINIFilePathKey_Name, filePath);
                    TSRINIFilePathKey.SetValue(USER_SID, GetCurrentUserSID());
                }
            }
            catch(Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
                return false;
            }
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (currentRootKey != null)
                    currentRootKey.Close();
            }
            return true;
        }
        public static bool DeleteINIFilePath()
        {
            //MessageBox.Show("Utilyti - addinLocation :" + addinLocation);
            RegistryKey currentRootKey = null;            
            try
            {
                currentRootKey = Registry.LocalMachine.OpenSubKey(LocationRoot,true);
                if (currentRootKey != null)
                    currentRootKey.DeleteSubKey(addinLocation);
            }
            catch
            {
                return false;
            }
            finally
            {
                if (currentRootKey != null)
                    currentRootKey.Close();
            }
            return true;
        }
        /// <summary>
        /// Read ini file path from registry
        /// </summary>
        /// <returns></returns>
        public static string GetINIFilePath()
        {
            string path = string.Empty;                        
            RegistryKey currentRootKey = null;
            RegistryKey TSRINIFilePathKey = null;
            try
            {
                currentRootKey = Registry.LocalMachine.OpenSubKey(LocationRoot,true);
                if (currentRootKey != null)
                {
                    TSRINIFilePathKey = currentRootKey.OpenSubKey(addinLocation, true);
                    if (TSRINIFilePathKey != null)
                    {
                        path = TSRINIFilePathKey.GetValue(TSRINIFilePathKey_Name, string.Empty).ToString();
                    }
                }
            }            
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (currentRootKey != null)
                    currentRootKey.Close();
            }
            return path;
        }

        public static string GetCurrentUserSIDFromRegistry()
        {
            string sid = string.Empty;
            RegistryKey currentRootKey = null;
            RegistryKey TSRINIFilePathKey = null;
            try
            {
                currentRootKey = Registry.LocalMachine.OpenSubKey(LocationRoot, false);
                if (currentRootKey != null)
                {
                    TSRINIFilePathKey = currentRootKey.OpenSubKey(addinLocation, false);
                    if (TSRINIFilePathKey != null)
                    {
                        sid = TSRINIFilePathKey.GetValue(USER_SID, string.Empty).ToString();
                    }
                }
            }
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (currentRootKey != null)
                    currentRootKey.Close();
            }
            return sid;
        }

        public static string EncryptString(string plainSourceStringToEncrypt)
        {
            MD5CryptoServiceProvider mdcsp = new MD5CryptoServiceProvider();
            byte[] b = System.Text.Encoding.UTF8.GetBytes(plainSourceStringToEncrypt);
            b = mdcsp.ComputeHash(b);
            //Convert encoded bytes back to a 'readable' string
            return BitConverter.ToString(b);
        }

        public static ValidationMode GetValidationMode()
        {
            //ValidationMode mode = ValidationMode.NONAD;    
            //RegistryKey tsrOptionKey = null;
            //try
            //{
            //    tsrOptionKey = Registry.LocalMachine.OpenSubKey(DBROptionsLocation, true);
            //    if (tsrOptionKey != null)
            //    {
            //        //Set registry key installation mode
            //        mode = ((tsrOptionKey.GetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_INSTALLATIONMODE,
            //            ValidationMode.NONAD.ToString())).ToString().ToUpper() == ValidationMode.AD.ToString()) ? ValidationMode.AD : ValidationMode.NONAD;
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Logging.LoggingHandler.LogUnhandledException(ex);
            //}
            //finally
            //{             
            //    if (tsrOptionKey != null)
            //        tsrOptionKey.Close();             
            //}
            //return mode;
            return ValidationMode.NONAD;
        }                

        public static bool SetValidationMode(ValidationMode mode)
        {
            //RegistryKey tsrOptionKey = null;
            //try
            //{
            //    tsrOptionKey = Registry.LocalMachine.OpenSubKey(DBROptionsLocation, true);
            //    if (tsrOptionKey != null)
            //    {
            //        //Set registry key installation mode
            //        tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_INSTALLATIONMODE, mode.ToString());                    
            //    }

            //}
            //catch (Exception ex)
            //{
            //    Logging.LoggingHandler.LogUnhandledException(ex);
            //    return false;
            //}    
            //finally
            //{
            //    if (tsrOptionKey != null)
            //        tsrOptionKey.Close();
            //}
            //return true;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]",Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE, mode.ToString());
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        public static string GetCustomerNo()
        {
            string customerNo = string.Empty;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {            
                customerNo = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO);                
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return customerNo;
        }
        public static bool SetCustomerNo(string customerNo)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO, customerNo);
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        public static string GetTSRServices()
        {
            string tsrServices = string.Empty;            
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                tsrServices = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES);
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }            
            return tsrServices;
        }
        public static bool SetTSRServices(string serverAddr)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES, serverAddr);
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        public static string GetUserName()
        {
            string userName = string.Empty;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                userName = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRUSERNAME);
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }       
            return userName;
        }
        public static bool SetUserName(string userName)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRUSERNAME, userName);
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        public static string GetPassword()
        {
            string pass = string.Empty;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                pass = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRPASSWORD);
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }       
            return pass;
        }
        public static bool SetPassword(string pass)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRPASSWORD, pass);
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        public static bool GetSSLMode()
        {
            bool isSSLMode = true;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!bool.TryParse(GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSSLMODE), out isSSLMode))
                    isSSLMode = true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }       
            return isSSLMode;
        }
        public static bool SetSSLMode(bool sslMode)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSSLMODE, sslMode.ToString());
                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }
        
        public static void GetAllDBROptions(out ValidationMode validationMode, out string customerNo, out string serAddr, out string userName,out string pass,out bool sslMode)
        {
            validationMode = ValidationMode.NONAD;
            customerNo = string.Empty;
            serAddr = string.Empty;
            userName = string.Empty;
            pass = string.Empty;
            sslMode = true;
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                customerNo = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO);
                serAddr = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES);
                userName = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRUSERNAME);
                pass = GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRPASSWORD);
                if (!bool.TryParse(GetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSSLMODE), out sslMode))
                    sslMode = true;

            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }       
        }
        public static bool SetAllDBROptions(ValidationMode validationMode, string customerNo,string serAddr,string userName, string pass, bool sslMode)
        {
            string dataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string dataFilePath = dataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
            try
            {
                if (!System.IO.Directory.Exists(dataFolder))
                {
                    System.IO.Directory.CreateDirectory(dataFolder);
                }
                if (!System.IO.File.Exists(dataFilePath))
                {
                    System.IO.StreamWriter wr = System.IO.File.CreateText(dataFilePath);
                    wr.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    wr.Flush();
                    wr.Close();
                    wr.Dispose();
                }

                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE, validationMode.ToString());
                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO, customerNo);
                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES, serAddr);
                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRUSERNAME, userName);
                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRPASSWORD, pass);
                SetValue(dataFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSSLMODE, sslMode.ToString());

                return true;
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return false;
        }

        private static string GetCurrentUserSID()
        {
            string sid = string.Empty;
            string loginUserName = GetLoginUserName();
            if (!string.IsNullOrEmpty(loginUserName))
            {
                try
                {
                    NTAccount f = new NTAccount(loginUserName);
                    SecurityIdentifier s = (SecurityIdentifier)f.Translate(typeof(SecurityIdentifier));

                    sid = s.ToString();
                }
                catch (Exception ex)
                {
                    // get SID from System.Security.Principal
                    System.Security.Principal.WindowsIdentity wi = System.Security.Principal.WindowsIdentity.GetCurrent();
                    if (wi != null && wi.User != null)
                        sid = wi.User.Value;
                }
            }
            else
            {
                System.Security.Principal.WindowsIdentity wi = System.Security.Principal.WindowsIdentity.GetCurrent();
                if (wi != null && wi.User != null)
                    sid = wi.User.Value;
            }

            return sid;
        }

        private static string GetLoginUserName()
        {
            string procName = "explorer.exe";
            string result = string.Empty;

            string sessionId = string.Empty;
            sessionId += System.Diagnostics.Process.GetCurrentProcess().SessionId;

            string query = "SELECT * FROM Win32_Process WHERE Name = \'" + procName + "\' AND SessionId=\'" + sessionId + "\'";
            var procs = new System.Management.ManagementObjectSearcher(query);
            foreach (System.Management.ManagementObject p in procs.Get())
            {
                var path = p["ExecutablePath"];
                if (path != null)
                {
                    string executablePath = path.ToString();
                    string[] ownerInfo = new string[2];
                    p.InvokeMethod("GetOwner", (object[])ownerInfo);
                    result += ownerInfo[0];
                    if (string.IsNullOrEmpty(result)) //return first user in loop
                        break;
                }
            }
            return result;
        }
        #endregion
    }
}
