﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using Microsoft.Win32;
using TSR.CommandLine.Core;
using System.Reflection;
using System.Diagnostics;

namespace TSR.CommandLineSetupSetting
{
    public class SetupCommandLine
    {
        #region private contants        
        private static string OptionsLocationRoot = @"Software";
        private const string OptionsLocationCommandLine = "CommandLine";

        # endregion

        public void Register()
        {         
            StoreOptions();
        }
        
        public void UnRegister()
        {
            //MessageBox.Show("unrig");
            RemoveOptions();
        }
        public void StoreOptions()
        {
            string CURRENTUSER_SID = UtilitiHelper.GetCurrentUserSIDFromRegistry();
            if (CURRENTUSER_SID.Length > 0)
            {
                OptionsLocationRoot = CURRENTUSER_SID + @"\" + OptionsLocationRoot;
                //OUAOptionsLocation = CURRENTUSER_SID + @"\Timesheet Reporter";
                //OUAOptionsLocationRoot = CURRENTUSER_SID + @"\Software";
            }

            string customerNo = string.Empty;
            string serverAddr = string.Empty;
            string verbose = string.Empty;
            ValidationMode validationMode = ValidationMode.NONAD;
            string userName = string.Empty;
            string pass = string.Empty;           

            //Read tsr option values from ini file
            string iniFilePath = UtilitiHelper.GetINIFilePath();
            if (!string.IsNullOrEmpty(iniFilePath))
            {
                customerNo = UtilitiHelper.GetValue(iniFilePath, UtilitiHelper.ROOTCATERGORY, UtilitiHelper.CONST_OPTION_CUSTOMERNO);
                serverAddr = UtilitiHelper.GetValue(iniFilePath, UtilitiHelper.ROOTCATERGORY, UtilitiHelper.CONST_OPTION_TSRSERVICES);
                verbose = UtilitiHelper.GetValue(iniFilePath, UtilitiHelper.ROOTCATERGORY, UtilitiHelper.CONST_OPTION_VERBOSE);
            }
            string title = "TSR CommandLine";
            WindowWrapper wrapper = WindowWrapper.GetInstance(title);

            if (!(!string.IsNullOrEmpty(verbose) && (verbose.ToLower() == UtilitiHelper.Y_IN_LOWER_CHARS.ToLower() || verbose.ToLower() == UtilitiHelper.YES_IN_LOWER_CHARS.ToLower())))
            {
                try
                {
                    //Show server information form
                    ServerInformation serverFrm = new ServerInformation(customerNo, serverAddr);
                    if (wrapper != null)
                        serverFrm.ShowDialog(wrapper);
                    else
                        serverFrm.ShowDialog();
                    customerNo = serverFrm.CustomerNo;
                    serverAddr = serverFrm.TSRServices;

                    //Show user information
                    UserInformation userInfo = new UserInformation();
                    if (wrapper != null)
                        userInfo.ShowDialog(wrapper);
                    else
                        userInfo.ShowDialog();
                    userName = userInfo.UserName;
                    pass = userInfo.Password;
                    if (!string.IsNullOrEmpty(pass))
                        pass = UtilitiHelper.EncryptString(pass);
                    //MessageBox.Show("xong form");
                }
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message);
                    TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }
            else
            {
                //Show user information
                UserInformation userInfo = new UserInformation();
                if (wrapper != null)
                    userInfo.ShowDialog(wrapper);
                else
                    userInfo.ShowDialog();
                userName = userInfo.UserName;
                pass = userInfo.Password;
                if (!string.IsNullOrEmpty(pass))
                    pass = UtilitiHelper.EncryptString(pass);

                if (!string.IsNullOrEmpty(serverAddr) && serverAddr.Contains(UtilitiHelper.CUSTOMERNO_VARIABLENAME))
                    serverAddr = serverAddr.Replace(UtilitiHelper.CUSTOMERNO_VARIABLENAME, customerNo);
            }

            // registry
            RegistryKey tsrOptionKey = null;
            RegistryKey softwareKey = null;
            //MessageBox.Show("regis 1");
            try
            {

                //Store common options
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

                string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
                if (Directory.Exists(folderPath))
                {
                    string commonIniFilePath = folderPath + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
                    if (File.Exists(commonIniFilePath))
                    {
                        TSR.CommandLine.Core.UtilitiHelper.SetValue(commonIniFilePath, TSR.CommandLine.Core.UtilitiHelper.ROOTCATERGORY, TSR.CommandLine.Core.UtilitiHelper.CONST_OPTION_CUSTOMERNO, customerNo);
                        TSR.CommandLine.Core.UtilitiHelper.SetValue(commonIniFilePath, TSR.CommandLine.Core.UtilitiHelper.ROOTCATERGORY, TSR.CommandLine.Core.UtilitiHelper.CONST_OPTION_INSTALLATIONMODE, validationMode.ToString());
                        TSR.CommandLine.Core.UtilitiHelper.SetValue(commonIniFilePath, TSR.CommandLine.Core.UtilitiHelper.ROOTCATERGORY, TSR.CommandLine.Core.UtilitiHelper.CONST_OPTION_TSRSERVICES, serverAddr);                        
                        
                    }
                }

                softwareKey = Registry.Users.OpenSubKey(OptionsLocationRoot, true);
                //MessageBox.Show("regis 2");
                if (softwareKey != null)
                {
                    //MessageBox.Show(softwareKey.Name);
                    tsrOptionKey = softwareKey.OpenSubKey(OptionsLocationCommandLine,true);
                    if (tsrOptionKey != null)
                    {
                        //MessageBox.Show("regis 2.1");
                        tsrOptionKey.Close();
                        //MessageBox.Show("regis 2.2");
                        softwareKey.DeleteSubKey(OptionsLocationCommandLine);
                    }
                    //MessageBox.Show("regis 2.3");
                    tsrOptionKey = softwareKey.CreateSubKey(OptionsLocationCommandLine);
                    //MessageBox.Show("regis 3");
                    //MessageBox.Show(validationMode + "  " + customerNo + "  " + serverAddr + "  " + userName + "    " + pass);                    
                    if (tsrOptionKey != null)
                    {
                        //Set registry key installation mode
                        //tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_INSTALLATIONMODE, validationMode);
                        //tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_CUSTOMERNO, customerNo);
                        //tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_SERVERADDRESS, serverAddr);
                        tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_USERNAME, userName);
                        tsrOptionKey.SetValue(TSR.CommandLine.Core.Constants.CONST_REGISTRYKEY_PASSWORD, pass);
                    }
                    //MessageBox.Show("xong regis");
                }
                //check folderPath:
                if(!string.IsNullOrEmpty(folderPath))
                {
                    if (folderPath.EndsWith("\\"))
                    {
                        folderPath = folderPath.Remove(folderPath.Length - 1);
                    }
                    //get Environment variable:
                    string installFolderPath = System.IO.Directory.GetParent(Assembly.GetExecutingAssembly().Location).ToString();
                    string strCurrentPathValue = Environment.GetEnvironmentVariable("Path");
                    strCurrentPathValue += strCurrentPathValue.EndsWith(";") ? "" : ";";
                    if (!strCurrentPathValue.ToLower().Contains(installFolderPath.ToLower()))
                    {
                        strCurrentPathValue += installFolderPath;
                    }
                    else
                    {
                        strCurrentPathValue = strCurrentPathValue.Remove(strCurrentPathValue.Length - 1);
                    }                   
                    //set path Environment
                    System.Environment.SetEnvironmentVariable("Path", strCurrentPathValue, EnvironmentVariableTarget.Machine);        
                }                                
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Error storing databridge installation options");
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                //MessageBox.Show("regis 4");
                if (tsrOptionKey != null)                    
                    tsrOptionKey.Close();
                //MessageBox.Show("regis 5");
                if (softwareKey != null)                    
                    softwareKey.Close();
                //MessageBox.Show("regis 6");
            }
            //MessageBox.Show("regis 7");
        }

        public void RemoveOptions()
        {
            RegistryKey softwareKey = null;
            try
            {
                softwareKey = Registry.Users.OpenSubKey(OptionsLocationRoot, true);
                if (softwareKey != null)
                {
                    //MessageBox.Show("vao ham nay");
                    softwareKey.DeleteSubKey(OptionsLocationCommandLine);
                    //MessageBox.Show("Xoa xong " + OptionsLocationCommandLine);
                }
            }
            catch (Exception ex)
            {
                TSR.CommandLine.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                //MessageBox.Show("Error removing databridge installation options");
            }
            finally
            {
                if (softwareKey != null)
                    softwareKey.Close();
            }
        }
    }

    class WindowWrapper : System.Windows.Forms.IWin32Window
    {
        public WindowWrapper(IntPtr handle)
        {
            _hwnd = handle;
        }

        public static WindowWrapper GetInstance(string windowTitle)
        {
            IntPtr handle = IntPtr.Zero;
            Process[] procs = Process.GetProcessesByName("msiexec");

            if (null != procs && procs.Length > 0)
            {
                foreach (Process p in procs)
                {
                    if (p.MainWindowTitle.Equals(windowTitle))
                    {
                        handle = p.MainWindowHandle;
                    }
                }
            }
            if (handle != IntPtr.Zero)
                return new WindowWrapper(handle);
            else
                return null;
        }

        public IntPtr Handle
        {
            get { return _hwnd; }
        }

        private IntPtr _hwnd;
    }
}