﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.CommandLine.Core;

namespace TSR.CommandLineSetupSetting
{
    public partial class DBRRuntimeSetting : Form
    {
        #region Private variables
        private ValidationMode mode = ValidationMode.NONAD;
        private string custmerNo;
        private string serverAddr;
        private string userName;
        private string pass;
        private bool isSSL = true;

        private bool isChangePass = false;
        #endregion
        public string CustomerNo
        {
            get;
            set;
        }
        public string TSRServices
        {
            get;
            set;
        }
        public string UserName
        {
            get;
            set;
        }
        public string Password
        {
            get;
            set;
        }

        public DBRRuntimeSetting()
        {
            InitializeComponent();

            this.TopMost = false;
            this.Icon = TSR.CommandLineSetupSetting.Properties.Resources.gear;
        }
        #region Events      

        private void DBRRuntimeSetting_Load(object sender, EventArgs e)
        {
            InitData();
        }

        private void btnTestServerAddress_Click(object sender, EventArgs e)
        {
            try
            {
                //Accept invalid certificate
                ImportAndExportDBR.SetPolicy();

                if (TSR.CommandLine.Core.ImportAndExportDBR.IsServiceUp(txtServerAddress.Text.Trim(), chkSSLMode.Checked))
                {
                    MessageBox.Show("Server Address is valid", "Test Server Address");
                }
                else
                    MessageBox.Show("Server Address is invalid", "Test Server Address");

            }
            catch
            {
                MessageBox.Show("Server Address is invalid", "Test Server Address");
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(txtPassword.Text.Trim())) && string.IsNullOrEmpty(txtUser.Text.Trim()))
            {
                MessageBox.Show("User Account is invalid","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                txtUser.Focus();
            }
            else
            {
                SaveData();                   
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
        #region Methods
        private void InitData()
        {
            //Check fist run
            ImportAndExportDBR.CheckFirstRun();

            UtilitiHelper.GetAllDBROptions(out mode, out custmerNo, out serverAddr, out userName, out pass, out isSSL);
            txtCustomerID.Text = custmerNo;
            txtServerAddress.Text = serverAddr;
            txtUser.Text = userName;
            //txtPassword.Text = pass;
            chkSSLMode.Checked = isSSL;
        }
        private void SaveData()
        {
            custmerNo = txtCustomerID.Text.Trim();
            serverAddr = txtServerAddress.Text.Trim();
            userName = txtUser.Text.Trim();
            if (isChangePass)
                pass = TSR.CommandLine.Core.UtilitiHelper.EncryptString(txtPassword.Text.Trim());

            isSSL = chkSSLMode.Checked;

            if (!UtilitiHelper.SetAllDBROptions(mode, custmerNo, serverAddr, userName, pass, isSSL))
                MessageBox.Show("Error saving databridge settings", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            isChangePass = true;
        }

      
    }
}
