﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.CommandLine.Core;
using System.Reflection;

namespace TSR.CommandLineSetupSetting
{
    public partial class ServerInformation : Form
    {
        public string CustomerNo
        {
            get;
            set;
        }
        public string TSRServices
        {
            get;
            set;
        }
        private bool isChangedServer = false;

        public ServerInformation(string customerNo, string serverAddr)
        {
            InitializeComponent();
            //Init properties
            CustomerNo = customerNo;
            TSRServices = serverAddr;

            this.TopMost = true;            
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerNo.Text.Trim()))
            {
                MessageBox.Show("Customer Number field is mandatory", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCustomerNo.Focus();
                e.Cancel = true;
            }
            else
            {
                CustomerNo = txtCustomerNo.Text.Trim();
                TSRServices = txtServerAddress.Text.Trim();
                //TSRWebAdmin = txtWebInterface.Text.Trim();
                base.OnClosing(e);
            }                      
        }
        private void ServerInformation_Load(object sender, EventArgs e)
        {
            txtCustomerNo.Text = CustomerNo;
            txtServerAddress.Text = TSRServices.Replace(UtilitiHelper.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);            
        }

        private void txtServerAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!isChangedServer && TSRServices.Contains(UtilitiHelper.CUSTOMERNO_VARIABLENAME))
            {
                if (MessageBox.Show("Do you want to change server names?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.OK)
                    isChangedServer = true;
                else
                {
                    e.Handled = true;
                    isChangedServer = false;
                }
            }
        }

        private void txtCustomerID_TextChanged(object sender, EventArgs e)
        {
            if ((!isChangedServer) && (TSRServices.Contains(UtilitiHelper.CUSTOMERNO_VARIABLENAME)))
            {
                txtServerAddress.Text = TSRServices.Replace(UtilitiHelper.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);
            }         
        }

        private void btnOK_Click(object sender, EventArgs e)
        {            
             this.Close();        
        }        
    }
}
