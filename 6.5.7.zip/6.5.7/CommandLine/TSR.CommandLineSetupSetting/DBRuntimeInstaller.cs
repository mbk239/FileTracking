﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Windows.Forms;
using TSR.CommandLine;
using System.IO;

namespace TSR.CommandLineSetupSetting
{
    [RunInstaller(true)]
    public partial class DBRuntimeInstaller : System.Configuration.Install.Installer
    {
        private const string COMMANDLINE = "CommandLine";
        public DBRuntimeInstaller()
        {
            InitializeComponent();
        }
        public override void Install(IDictionary stateSaver)
        {
            SetupCommandLine commandLine = new SetupCommandLine();
            //string addInName = COMMANDLINE;
            try
            {
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + TSR.CommandLine.Core.Constants.CONST_FOLDER_SEPERATOR + TSR.CommandLine.Core.Constants.CONST_APPDATA_FOLDER;
                if (Directory.Exists(s))
                    Directory.Delete(s, true);

                Directory.CreateDirectory(s);

                if (Directory.Exists(s))
                {
                    string iniFilePath = TSR.CommandLine.Core.UtilitiHelper.GetINIFilePath();
                    string commomIniFilePath = s + TSR.CommandLine.Core.Constants.CONST_FOLDER_SEPERATOR + TSR.CommandLine.Core.Constants.CONST_INIFILEPATH;
                    if (File.Exists(iniFilePath))
                    {
                        File.Copy(iniFilePath, commomIniFilePath, true);
                    }
                    else
                    {
                        StreamWriter w = File.CreateText(commomIniFilePath);
                        w.Write(string.Format("[{0}]", TSR.CommandLine.Core.UtilitiHelper.ROOTCATERGORY));
                        w.Flush();
                        w.Close();
                        w.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(ex);
            }

            //commandLine.Register(addInName);
            commandLine.Register();
            //MessageBox.Show("regis 7");
            base.Install(stateSaver);
            //MessageBox.Show("regis 8");
        }
        public override void Uninstall(IDictionary savedState)
        {
            SetupCommandLine commandLine = new SetupCommandLine();
            try
            {
                string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + TSR.CommandLine.Core.Constants.CONST_FOLDER_SEPERATOR + TSR.CommandLine.Core.Constants.CONST_APPDATA_FOLDER;                
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);
            }
            catch (Exception ex)
            {
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(ex);
            }

            commandLine.UnRegister(); 

            base.Uninstall(savedState);
            
        }
        public override void Rollback(IDictionary savedState)
        {
            SetupCommandLine commandLine = new SetupCommandLine();
            try
            {
                string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + TSR.CommandLine.Core.Constants.CONST_FOLDER_SEPERATOR + TSR.CommandLine.Core.Constants.CONST_APPDATA_FOLDER;
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);
            }
            catch (Exception ex)
            {
                TSR.CommandLine.Core.Logging.LoggingHandler.LogError(ex);
            }

            commandLine.UnRegister();
                        
            base.Rollback(savedState);
        }
    }
}
