﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Configuration;

namespace TSR.CommandLineSetupSetting
{
    public partial class Setting : Form
    {
        private const string FILE_NAME_CONFIG = "TSRDBRUN.exe.config";
        private const string CONNECTION_STRING_NAME = "TSRConnectionString";
        private const string CONNECTION_STRING_NAME2 = "TSREntities";
        private const string FILE_NAME_EXE = "TSRDBRUN.exe";
        private const string MESSAGE_TEST_CONNECTION_SUCCESS = "Test the connection successfully";
        //private const string MESSAGE_TEST_CONNECTION_FAILURE = "FAILURE";

        public Setting()
        {
            InitializeComponent();
        }

        private void Setting_Load(object sender, EventArgs e)
        {
            if (File.Exists(Application.StartupPath + "\\" + FILE_NAME_CONFIG))
            {
                //Server=TSRSERVER;Initial Catalog=Contest_TSR_Test;
                //Persist Security Info=true;User ID=sa;pwd=Admin123
                //string connectionString = string.Format("Server={0};Initial Catalog={1};Persist Security Info=true;User ID={2};pwd={3}",
                //    txtServer.Text, txtDatabase.Text, txtUser.Text, txtPassword.Text);
                Configuration config = ConfigurationManager.OpenExeConfiguration(Application.StartupPath + "\\" + FILE_NAME_EXE);
                if (config != null)
                {
                    string connectionString = config.ConnectionStrings.ConnectionStrings[CONNECTION_STRING_NAME].ConnectionString;
                    string[] arrString = connectionString.Split(';');
                    foreach (string s in arrString)
                    {
                        //MessageBox.Show(s);
                        switch (s.Substring(0, s.IndexOf('=')).ToLower())
                        {
                            case "server":
                                txtServer.Text = s.Substring(s.IndexOf('=') + 1);
                                break;
                            case "initial catalog":
                                txtDatabase.Text = s.Substring(s.IndexOf('=') + 1);
                                break;
                            case "user id":
                            case "uid":
                                txtUser.Text = s.Substring(s.IndexOf('=') + 1);
                                break;
                            case "pwd":
                                txtPassword.Text = s.Substring(s.IndexOf('=') + 1);
                                break;
                            default:
                                break;
                        }
                        
                    }
                }
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (File.Exists(Application.StartupPath + "\\" + FILE_NAME_CONFIG))
            {
                if (txtServer.Text.Trim().Length > 0 && txtDatabase.Text.Trim().Length > 0
                    && txtUser.Text.Trim().Length > 0 && txtPassword.Text.Length > 0)
                {
                    //Server=TSRSERVER;Initial Catalog=Contest_TSR_Test;
                    //Persist Security Info=true;User ID=sa;pwd=Admin123
                    string connectionString = string.Format("Server={0};Initial Catalog={1};Persist Security Info=true;User ID={2};pwd={3}",
                        txtServer.Text, txtDatabase.Text, txtUser.Text, txtPassword.Text);
                    string connectionString2 = string.Format("metadata=res://*/UserSettings.csdl|res://*/UserSettings.ssdl|res://*/UserSettings.msl;provider=System.Data.SqlClient;provider connection string=\"Server={0};Initial Catalog={1};Persist Security Info=True;User ID={2};Password={3};MultipleActiveResultSets=True\"",
                        txtServer.Text, txtDatabase.Text, txtUser.Text, txtPassword.Text);
                    Configuration config = ConfigurationManager.OpenExeConfiguration(Application.StartupPath + "\\" + FILE_NAME_EXE);
                    if (config == null)
                    {
                        //MessageBox.Show("null");
                    }
                    else
                    {
                        //MessageBox.Show("not null");
                        //MessageBox.Show(config.ConnectionStrings.ConnectionStrings[CONNECTION_STRING_NAME].ConnectionString);
                        config.ConnectionStrings.ConnectionStrings[CONNECTION_STRING_NAME].ConnectionString = connectionString;
                        //config.Save(ConfigurationSaveMode.Modified);
                        config.ConnectionStrings.ConnectionStrings[CONNECTION_STRING_NAME2].ConnectionString = connectionString2;
                        config.Save(ConfigurationSaveMode.Modified);
                        
                        MessageBox.Show("Connection information is saved successfully");

                        //tsrdev4
                        this.Close();
                    }
                }
                
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            string connectionString = string.Empty;
            //if (txtServer.Text.Trim().Length > 0 && txtDatabase.Text.Trim().Length > 0
            //        && txtUser.Text.Trim().Length > 0 && txtPassword.Text.Length > 0)
            //{
                //Server=TSRSERVER;Initial Catalog=Contest_TSR_Test;
                //Persist Security Info=true;User ID=sa;pwd=Admin123
                connectionString = string.Format("Server={0};Initial Catalog={1};Persist Security Info=true;User ID={2};pwd={3}",
                    txtServer.Text, txtDatabase.Text, txtUser.Text, txtPassword.Text);
                
            //}
            using (System.Data.SqlClient.SqlConnection cnn = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    cnn.Open();
                    cnn.Close();
                    this.Cursor = Cursors.Default;
                    MessageBox.Show(MESSAGE_TEST_CONNECTION_SUCCESS);
                }
                catch (Exception ex)
                {
                    this.Cursor = Cursors.Default;
                    MessageBox.Show(ex.Message);
                }
                
            }
        }

        private bool IsValid()
        {
            if (txtServer.Text.Trim().Length == 0)
            {
                MessageBox.Show(TSR.CommandLineSetupSetting.Properties.Resources.strMsgTxtServerNameEmpty);
                txtServer.Focus();
                return false;
            }

            if (txtDatabase.Text.Trim().Length == 0)
            {
                MessageBox.Show(TSR.CommandLineSetupSetting.Properties.Resources.strMsgTxtDatabaseNameEmpty);
                txtDatabase.Focus();
                return false;
            }

            if (txtUser.Text.Trim().Length == 0)
            {
                MessageBox.Show(TSR.CommandLineSetupSetting.Properties.Resources.strMsgTxtUsernameEmpty);
                txtUser.Focus();
                return false;
            }

            if (txtPassword.Text.Trim().Length == 0)
            {
                MessageBox.Show(TSR.CommandLineSetupSetting.Properties.Resources.strMsgTxtPasswordEmpty);
                txtPassword.Focus();
                return false;
            }
            return true;
        }
    }
}
