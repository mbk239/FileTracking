﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TSR.CommandLineSetupSetting
{
    public partial class UserInformation : Form
    {
        public string UserName
        {
            get;
            set;
        }
        public string Password
        {
            get;
            set;
        }
        public UserInformation()
        {
            InitializeComponent();
            this.TopMost = true;            
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UserInformation_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text) && !string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                MessageBox.Show("User Name must be required", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUserName.Focus();
                e.Cancel = true;
            }
            else
            {
                UserName = txtUserName.Text.Trim();
                Password = txtPassword.Text.Trim();
                base.OnClosing(e);
            }            
        }

        private void UserInformation_Load(object sender, EventArgs e)
        {
           
        }
    }
}
