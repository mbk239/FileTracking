﻿namespace TSR.CommandLineSetupSetting
{
    partial class ServerInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServerInformation));
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnButton = new System.Windows.Forms.Panel();
            this.btnOK = new System.Windows.Forms.Button();
            this.pnContent = new System.Windows.Forms.Panel();
            this.lblCustomerNo = new System.Windows.Forms.Label();
            this.txtCustomerNo = new System.Windows.Forms.TextBox();
            this.lblServerAddress = new System.Windows.Forms.Label();
            this.txtServerAddress = new System.Windows.Forms.TextBox();
            this.lblContent = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnTitle = new System.Windows.Forms.Panel();
            this.pnButton.SuspendLayout();
            this.pnContent.SuspendLayout();
            this.pnTitle.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(9, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(389, 56);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Server Information";
            // 
            // pnButton
            // 
            this.pnButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnButton.Controls.Add(this.btnOK);
            this.pnButton.Location = new System.Drawing.Point(-1, 294);
            this.pnButton.Name = "pnButton";
            this.pnButton.Size = new System.Drawing.Size(410, 40);
            this.pnButton.TabIndex = 5;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(326, 8);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "&OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // pnContent
            // 
            this.pnContent.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnContent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnContent.Controls.Add(this.lblCustomerNo);
            this.pnContent.Controls.Add(this.txtCustomerNo);
            this.pnContent.Controls.Add(this.lblServerAddress);
            this.pnContent.Controls.Add(this.txtServerAddress);
            this.pnContent.Controls.Add(this.lblContent);
            this.pnContent.Location = new System.Drawing.Point(-4, 70);
            this.pnContent.Name = "pnContent";
            this.pnContent.Size = new System.Drawing.Size(413, 224);
            this.pnContent.TabIndex = 4;
            // 
            // lblCustomerNo
            // 
            this.lblCustomerNo.AutoSize = true;
            this.lblCustomerNo.Location = new System.Drawing.Point(7, 56);
            this.lblCustomerNo.Name = "lblCustomerNo";
            this.lblCustomerNo.Size = new System.Drawing.Size(91, 13);
            this.lblCustomerNo.TabIndex = 9;
            this.lblCustomerNo.Text = "Customer Number";
            // 
            // txtCustomerNo
            // 
            this.txtCustomerNo.Location = new System.Drawing.Point(9, 73);
            this.txtCustomerNo.Name = "txtCustomerNo";
            this.txtCustomerNo.Size = new System.Drawing.Size(392, 20);
            this.txtCustomerNo.TabIndex = 0;
            this.txtCustomerNo.TextChanged += new System.EventHandler(this.txtCustomerID_TextChanged);
            // 
            // lblServerAddress
            // 
            this.lblServerAddress.AutoSize = true;
            this.lblServerAddress.Location = new System.Drawing.Point(7, 104);
            this.lblServerAddress.Name = "lblServerAddress";
            this.lblServerAddress.Size = new System.Drawing.Size(79, 13);
            this.lblServerAddress.TabIndex = 7;
            this.lblServerAddress.Text = "Server Address";
            // 
            // txtServerAddress
            // 
            this.txtServerAddress.Location = new System.Drawing.Point(9, 121);
            this.txtServerAddress.Name = "txtServerAddress";
            this.txtServerAddress.Size = new System.Drawing.Size(392, 20);
            this.txtServerAddress.TabIndex = 1;
            this.txtServerAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtServerAddress_KeyPress);
            // 
            // lblContent
            // 
            this.lblContent.Location = new System.Drawing.Point(9, 10);
            this.lblContent.Name = "lblContent";
            this.lblContent.Size = new System.Drawing.Size(390, 37);
            this.lblContent.TabIndex = 0;
            this.lblContent.Text = "Please enter server information";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 80);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(368, 80);
            this.panel2.TabIndex = 1;
            // 
            // pnTitle
            // 
            this.pnTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnTitle.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnTitle.Controls.Add(this.lblTitle);
            this.pnTitle.Controls.Add(this.panel2);
            this.pnTitle.Location = new System.Drawing.Point(-1, -2);
            this.pnTitle.Name = "pnTitle";
            this.pnTitle.Size = new System.Drawing.Size(410, 72);
            this.pnTitle.TabIndex = 3;
            // 
            // ServerInformation
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 333);
            this.Controls.Add(this.pnButton);
            this.Controls.Add(this.pnContent);
            this.Controls.Add(this.pnTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ServerInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TSR CommandLine";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.ServerInformation_Load);
            this.pnButton.ResumeLayout(false);
            this.pnContent.ResumeLayout(false);
            this.pnContent.PerformLayout();
            this.pnTitle.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        protected System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnButton;
        protected System.Windows.Forms.Button btnOK;
        protected System.Windows.Forms.Panel pnContent;
        private System.Windows.Forms.Label lblCustomerNo;
        private System.Windows.Forms.TextBox txtCustomerNo;
        private System.Windows.Forms.Label lblServerAddress;
        private System.Windows.Forms.TextBox txtServerAddress;
        protected System.Windows.Forms.Label lblContent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnTitle;

    }
}