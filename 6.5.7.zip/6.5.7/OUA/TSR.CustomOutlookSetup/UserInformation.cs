﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    public partial class UserInformation : CustomOutlookSetup.TemplateForm
    {
        public string UserName
        {
            get;
            set;
        }
        public string Password
        {
            get;
            set;
        }
        public UserInformation()
        {
            InitializeComponent();
        }

        public UserInformation(string userName, string pass)
        {
            InitializeComponent();
            // TODO: Complete member initialization
            //check input parameters in order to avoid NUll exception
            if (!string.IsNullOrEmpty(userName))
                this.UserName = userName;
            else
                this.UserName = string.Empty;

            if (!string.IsNullOrEmpty(pass))
                this.Password = pass;
            else
                this.Password = pass;
        }

        private void UserInformation_Load(object sender, EventArgs e)
        {
            txtUserName.Text = this.UserName;
            txtPassword.Text = this.Password;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UserInformation_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text) && !string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                MessageBox.Show("User Name must be required","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                txtUserName.Focus();
                e.Cancel = true;
            }
            else
            {
                UserName = txtUserName.Text.Trim();
                Password = txtPassword.Text.Trim();
            }
        }
    }
}