﻿namespace TSR.CustomOutlookSetup
{
    partial class ServerInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblServerAddress = new System.Windows.Forms.Label();
            this.txtServerAddress = new System.Windows.Forms.TextBox();
            this.lblWebInterface = new System.Windows.Forms.Label();
            this.txtWebInterface = new System.Windows.Forms.TextBox();
            this.lblCustomerNo = new System.Windows.Forms.Label();
            this.txtCustomerNo = new System.Windows.Forms.TextBox();
            this.pnContent.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnContent
            // 
            this.pnContent.Controls.Add(this.lblCustomerNo);
            this.pnContent.Controls.Add(this.txtCustomerNo);
            this.pnContent.Controls.Add(this.lblWebInterface);
            this.pnContent.Controls.Add(this.txtWebInterface);
            this.pnContent.Controls.Add(this.lblServerAddress);
            this.pnContent.Controls.Add(this.txtServerAddress);
            this.pnContent.Controls.SetChildIndex(this.txtServerAddress, 0);
            this.pnContent.Controls.SetChildIndex(this.lblServerAddress, 0);
            this.pnContent.Controls.SetChildIndex(this.lblContent, 0);
            this.pnContent.Controls.SetChildIndex(this.txtWebInterface, 0);
            this.pnContent.Controls.SetChildIndex(this.lblWebInterface, 0);
            this.pnContent.Controls.SetChildIndex(this.txtCustomerNo, 0);
            this.pnContent.Controls.SetChildIndex(this.lblCustomerNo, 0);
            // 
            // lblTitle
            // 
            this.lblTitle.Text = "Server Information";
            // 
            // lblContent
            // 
            this.lblContent.Text = "Please enter a valid server address and a valid web interface";
            // 
            // btnOK
            // 
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lblServerAddress
            // 
            this.lblServerAddress.AutoSize = true;
            this.lblServerAddress.Location = new System.Drawing.Point(6, 100);
            this.lblServerAddress.Name = "lblServerAddress";
            this.lblServerAddress.Size = new System.Drawing.Size(79, 13);
            this.lblServerAddress.TabIndex = 1;
            this.lblServerAddress.Text = "Server Address";
            // 
            // txtServerAddress
            // 
            this.txtServerAddress.Location = new System.Drawing.Point(8, 117);
            this.txtServerAddress.Name = "txtServerAddress";
            this.txtServerAddress.Size = new System.Drawing.Size(392, 20);
            this.txtServerAddress.TabIndex = 1;
            this.txtServerAddress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtServerAddress_KeyPress);
            // 
            // lblWebInterface
            // 
            this.lblWebInterface.AutoSize = true;
            this.lblWebInterface.Location = new System.Drawing.Point(6, 148);
            this.lblWebInterface.Name = "lblWebInterface";
            this.lblWebInterface.Size = new System.Drawing.Size(75, 13);
            this.lblWebInterface.TabIndex = 3;
            this.lblWebInterface.Text = "Web Interface";
            // 
            // txtWebInterface
            // 
            this.txtWebInterface.Location = new System.Drawing.Point(8, 165);
            this.txtWebInterface.Name = "txtWebInterface";
            this.txtWebInterface.Size = new System.Drawing.Size(392, 20);
            this.txtWebInterface.TabIndex = 2;
            this.txtWebInterface.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtWebInterface_KeyPress);
            // 
            // lblCustomerNo
            // 
            this.lblCustomerNo.AutoSize = true;
            this.lblCustomerNo.Location = new System.Drawing.Point(6, 52);
            this.lblCustomerNo.Name = "lblCustomerNo";
            this.lblCustomerNo.Size = new System.Drawing.Size(91, 13);
            this.lblCustomerNo.TabIndex = 5;
            this.lblCustomerNo.Text = "Customer Number";
            // 
            // txtCustomerNo
            // 
            this.txtCustomerNo.Location = new System.Drawing.Point(8, 69);
            this.txtCustomerNo.Name = "txtCustomerNo";
            this.txtCustomerNo.Size = new System.Drawing.Size(392, 20);
            this.txtCustomerNo.TabIndex = 0;
            this.txtCustomerNo.TextChanged += new System.EventHandler(this.txtCustomerNo_TextChanged);
            // 
            // ServerInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(407, 335);
            this.Name = "ServerInformation";
            this.Text = "TSR User Agent";
            this.Load += new System.EventHandler(this.ServerInformation_Load);
            this.pnContent.ResumeLayout(false);
            this.pnContent.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblServerAddress;
        private System.Windows.Forms.TextBox txtServerAddress;
        private System.Windows.Forms.Label lblWebInterface;
        private System.Windows.Forms.TextBox txtWebInterface;
        private System.Windows.Forms.Label lblCustomerNo;
        private System.Windows.Forms.TextBox txtCustomerNo;
    }
}
