﻿namespace TSR.CustomOutlookSetup
{
    partial class ExchangeOption
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkExchangMode = new System.Windows.Forms.CheckBox();
            this.lblEx = new System.Windows.Forms.Label();
            this.pnContent.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnContent
            // 
            this.pnContent.Controls.Add(this.lblEx);
            this.pnContent.Controls.Add(this.chkExchangMode);
            this.pnContent.Controls.SetChildIndex(this.lblContent, 0);
            this.pnContent.Controls.SetChildIndex(this.chkExchangMode, 0);
            this.pnContent.Controls.SetChildIndex(this.lblEx, 0);
            // 
            // lblTitle
            // 
            this.lblTitle.Text = "Exchange Mode Option";
            // 
            // lblContent
            // 
            this.lblContent.Text = "Please choose OUA runtime environment";
            // 
            // btnOK
            // 
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chkExchangMode
            // 
            this.chkExchangMode.AutoSize = true;
            this.chkExchangMode.Location = new System.Drawing.Point(8, 56);
            this.chkExchangMode.Name = "chkExchangMode";
            this.chkExchangMode.Size = new System.Drawing.Size(104, 17);
            this.chkExchangMode.TabIndex = 0;
            this.chkExchangMode.Text = "Exchange Mode";
            this.chkExchangMode.UseVisualStyleBackColor = true;
            // 
            // lblEx
            // 
            this.lblEx.Location = new System.Drawing.Point(8, 90);
            this.lblEx.Margin = new System.Windows.Forms.Padding(0);
            this.lblEx.Name = "lblEx";
            this.lblEx.Size = new System.Drawing.Size(403, 80);
            this.lblEx.TabIndex = 1;
            // 
            // ExchangeOption
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(407, 335);
            this.Name = "ExchangeOption";
            this.Text = "TSR User Agent";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ExchangeOption_FormClosing);
            this.Load += new System.EventHandler(this.ExchangeOption_Load);
            this.pnContent.ResumeLayout(false);
            this.pnContent.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkExchangMode;
        private System.Windows.Forms.Label lblEx;
    }
}
