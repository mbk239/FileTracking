﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    public partial class ExchangeOption : CustomOutlookSetup.TemplateForm
    {
        public TSR.Core.ExchangeMode EXMode
        {
            get;
            set;
        }
        public ExchangeOption(TSR.Core.ExchangeMode exMode)
        {
            InitializeComponent();
            EXMode = TSR.Core.ExchangeMode.Yes;
        }

        private void ExchangeOption_Load(object sender, EventArgs e)
        {
            if (EXMode == TSR.Core.ExchangeMode.Yes)
                chkExchangMode.Checked = true;
            else
                chkExchangMode.Checked = false;
            string msg = "Choose whether to run exchange mode. If your Microsoft Outlook is connected to a Microsoft Exchange Server 2003® or higher, select Exchange mode.  This also applies if you are running on hosted Exchange such as Microsoft Office 365, etc.\nIf you do not use Microsoft Exchange do not check the box. If in doubt, consult your system administrator. Click the OK button to continue.";
            lblEx.Text = msg;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ExchangeOption_FormClosing(object sender, FormClosingEventArgs e)
        {
            //EXMode = chkExchangMode.Checked ? TSR.Core.ExchangeMode.Yes : TSR.Core.ExchangeMode.No;
            EXMode = TSR.Core.ExchangeMode.Yes;
        }
    }
}
