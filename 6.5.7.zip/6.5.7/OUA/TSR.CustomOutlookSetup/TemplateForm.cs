﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    public partial class TemplateForm : Form
    {
        public void SetTitle(string title)
        {
            this.Text = title;
        }

        public TemplateForm()
        {
            InitializeComponent();
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
        }
    }
}
