﻿namespace TSR.CustomOutlookSetup
{
    partial class InstallationMode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkInstallationMode = new System.Windows.Forms.CheckBox();
            this.pnContent.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnContent
            // 
            this.pnContent.Controls.Add(this.chkInstallationMode);
            this.pnContent.Controls.SetChildIndex(this.lblContent, 0);
            this.pnContent.Controls.SetChildIndex(this.chkInstallationMode, 0);
            // 
            // lblTitle
            // 
            this.lblTitle.Text = "Installation Mode";
            // 
            // lblContent
            // 
            this.lblContent.Text = "Please choose installation mode (AD Default and NON-AD else)";
            // 
            // btnOK
            // 
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // chkInstallationMode
            // 
            this.chkInstallationMode.AutoSize = true;
            this.chkInstallationMode.Checked = true;
            this.chkInstallationMode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkInstallationMode.Location = new System.Drawing.Point(8, 56);
            this.chkInstallationMode.Name = "chkInstallationMode";
            this.chkInstallationMode.Size = new System.Drawing.Size(125, 17);
            this.chkInstallationMode.TabIndex = 0;
            this.chkInstallationMode.Text = "Active Diretory Mode";
            this.chkInstallationMode.UseVisualStyleBackColor = true;
            this.chkInstallationMode.CheckedChanged += new System.EventHandler(this.chkInstallationMode_CheckedChanged);
            // 
            // InstallationMode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.ClientSize = new System.Drawing.Size(407, 335);
            this.Name = "InstallationMode";
            this.Text = "TSR User Agent";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InstallationMode_FormClosing);
            this.Load += new System.EventHandler(this.InstallationMode_Load);
            this.pnContent.ResumeLayout(false);
            this.pnContent.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkInstallationMode;
    }
}
