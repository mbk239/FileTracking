﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    public partial class InstallationMode : CustomOutlookSetup.TemplateForm
    {
        public TSR.Core.ValidationMode InsMode;

        public InstallationMode(TSR.Core.ValidationMode initMode)
        {
            InitializeComponent();

            InsMode = initMode;
            
        }

        private void chkInstallationMode_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Are you sure that you want to choose NON-AD validation?", "Installation warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
        }

        private void InstallationMode_Load(object sender, EventArgs e)
        {          
            chkInstallationMode.Text = "Active Directory Mode";
            if (InsMode == TSR.Core.ValidationMode.AD)
                chkInstallationMode.Checked = true;
            else
                chkInstallationMode.Checked = false;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {            
            this.Close();
        }

        private void InstallationMode_FormClosing(object sender, FormClosingEventArgs e)
        {
            InsMode = chkInstallationMode.Checked ? TSR.Core.ValidationMode.AD : TSR.Core.ValidationMode.NONAD;
        }

    }
}
