﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new UserInformation());
            //MessageBox.Show("TSR is not available because UserName/Password is not provided", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
