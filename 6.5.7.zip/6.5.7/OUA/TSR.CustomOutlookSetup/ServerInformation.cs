﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TSR.CustomOutlookSetup
{
    public partial class ServerInformation : CustomOutlookSetup.TemplateForm
    {        
        public string CustomerNo
        {
            get;
            set;
        }
        public string TSRServices
        {
            get;
            set;
        }
        public string TSRWebAdmin
        {
            get;
            set;
        }
        private bool isChangedServer = false;
        public ServerInformation(string customerNo,string serverAddr, string webInterface)
        {
            InitializeComponent();

            //Init properties
            //check input parameters in order to avoid NUll exception
            if (!string.IsNullOrEmpty(customerNo))
                CustomerNo = customerNo;
            else
                customerNo = string.Empty;

            if (!string.IsNullOrEmpty(serverAddr))
                TSRServices = serverAddr;
            else
                TSRServices = string.Empty;

            if (!string.IsNullOrEmpty(webInterface))
                TSRWebAdmin = webInterface;
            else
                TSRWebAdmin = string.Empty;
            //CustomerNo = "Customer123";
            //TSRServices = "https://tsrserver.net/%OrgId%/WebServices";
            //TSRWebAdmin = "https://tsrserver.net/%OrgId%/WebServices";
        }
        private void ServerInformation_Load(object sender, EventArgs e)
        {
            txtCustomerNo.Text = CustomerNo;            

            txtServerAddress.Text = TSRServices.Replace(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);
            txtWebInterface.Text = TSRWebAdmin.Replace(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);

            //MessageBox.Show("CustomerID field is mandatory", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //MessageBox.Show("The TSR User Agent Intallation ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnOK_Click(object sender, EventArgs e)
        {            
             this.Close();         
        }

        
        protected override void OnClosing(CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtCustomerNo.Text.Trim()))

            {
                MessageBox.Show("Customer Number field is mandatory", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCustomerNo.Focus();
                e.Cancel = true;
            }
            else
            {
                CustomerNo = txtCustomerNo.Text.Trim();
                TSRServices = txtServerAddress.Text.Trim();
                TSRWebAdmin = txtWebInterface.Text.Trim();

                base.OnClosing(e);   
            }            
        }

        private void txtServerAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!isChangedServer && TSRServices.Contains(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME))
            {
                if (MessageBox.Show("Do you want to change server names?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.OK)
                    isChangedServer = true;
                else
                {
                    e.Handled = true;
                    isChangedServer = false;
                }
            }
        }

        private void txtWebInterface_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!isChangedServer && TSRWebAdmin.Contains(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME))
            {
                if (MessageBox.Show("Do you want to change server names?", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.OK)
                    isChangedServer = true;
                else
                {
                    e.Handled = true;
                    isChangedServer = false;
                }
            }
        }

        private void txtCustomerNo_TextChanged(object sender, EventArgs e)
        {
            if (!isChangedServer)
            {
                txtServerAddress.Text = TSRServices.Replace(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);
                txtWebInterface.Text = TSRWebAdmin.Replace(TSR.Core.Constants.CUSTOMERNO_VARIABLENAME, txtCustomerNo.Text);
            }
        }        
    }
}
