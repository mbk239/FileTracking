﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using TSR.Core;
using System.IO;
using Microsoft.Win32;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Windows.Forms;
using System.Diagnostics;
//using System.Security;
//using System.Security.Permissions;
//using Microsoft.VisualStudio.Tools.Applications;
//using Microsoft.VisualStudio.Tools.Office.Runtime.Security;


namespace TSR.Outlook2013.RegistryAddin
{
    [RunInstaller(true)]
    public partial class RegisterAddIns : Installer
    {      
        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);

            RegisterOffice reg = new RegisterOffice();
            string addInName = Context.Parameters["addinName"];                            
            try
            {
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                string folderPath = s + "\\" + Constants.CONST_APPDATA_FOLDER;
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);                

                Directory.CreateDirectory(folderPath);                    
               
                string iniFilePath = TSR.Core.UtilityHelper.GetINIFilePath();                    
                if (TSR.Core.UtilityHelper.IsExistedFile(iniFilePath))
                {
                    File.Copy(iniFilePath, folderPath + "\\" + TSR.Core.Constants.CONST_INIFILEPATH, true);
                }
                else
                {                        
                    StreamWriter w = File.CreateText(folderPath + "\\" + TSR.Core.Constants.CONST_INIFILEPATH);
                    w.Write(string.Format("[{0}]", Constants.ROOTCATERGORY));
                    w.Flush();
                    w.Close();
                    w.Dispose();
                }
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
            }

            //if(GetOfficeVersion() == 16) //check if it is running under outlook 2016
            //    addInName = "TSR_OL2016";

            reg.RegisterAddIn(addInName);

            // Remove temporary ini file
            TSR.Core.UtilityHelper.DeleteINIFilePath();
            string tempFile = Path.GetTempPath() + "\\" + Constants.CONST_INIFILEPATH;
            try
            {
                if (File.Exists(tempFile)) File.Delete(tempFile);
            }
            catch (Exception)
            {

            }
        }

        public override void Uninstall(IDictionary savedState)
        {
            RegisterOffice reg = new RegisterOffice();
            string addinName = Context.Parameters["addinName"];
            string appName = Context.Parameters["application"];
            try
            {
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                //Modified by tsrdev1
                //Modified date: 07/09/2010
                string folderPath = s + "\\" + Constants.CONST_APPDATA_FOLDER;          
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
            }  
         
            reg.UnRegisterAddIn(appName, addinName);            
            base.Uninstall(savedState);
        }

        public override void Rollback(IDictionary savedState)
        {
            RegisterOffice reg = new RegisterOffice();
            string addinName = Context.Parameters["addinName"];
            string appName = Context.Parameters["application"];
            try
            {
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
                string folderPath = s + "\\" + Constants.CONST_APPDATA_FOLDER; 
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
            }
            reg.UnRegisterAddIn(appName, addinName); 

            base.Rollback(savedState);
        }

        private int GetOfficeVersion()
        {
            RegistryKey key = null;
            try
            {
                key = Registry.ClassesRoot.OpenSubKey("Outlook.Application\\CurVer", false);
                if (key != null)
                {
                    string version = key.GetValue("", "Outlook.Application.9").ToString();
                    int pos = version.LastIndexOf(".");
                    if (pos >= 0)
                    {
                        version = version.Remove(0, pos + 1);
                        int iVer = 0;
                        int.TryParse(version, out iVer);
                        return iVer;
                    }
                }
            }
            finally
            {
                if (key != null) key.Close();
            }
            return 0;
        }
    }    
}
