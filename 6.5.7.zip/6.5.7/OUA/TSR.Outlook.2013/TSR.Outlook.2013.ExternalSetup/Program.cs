﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Microsoft.Win32;
using System.IO;
using System.Runtime.InteropServices;

namespace TSR.Outlook2013.UserAgentSetup
{
    static class Program
    {        
        //private const int SW_HIDE = 0;
        //[DllImport("User32")]
        //private static extern int ShowWindow(int hwnd, int nCmdShow);

        private enum PlatformType
        {
            x64 = 0,
            x86 = 1,
            none = 99
        }

        [STAThread]
        static void Main()
        {   
            StartSetup();
        }

        private static void StartSetup()
        {
            string path = Directory.GetParent(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)).Parent.FullName
                + "\\" + Constants.CONST_INIFILEPATH;

            string tempFile = Path.GetTempPath() + "\\" + Constants.CONST_INIFILEPATH;
            if (File.Exists(path))
            {
                File.Copy(path, tempFile, true);
                path = tempFile;
            }

            bool silentMode = false;

            if (UtilityHelper.IsExistedFile(path))
            {                
                string strSilentInstall = UtilityHelper.GetValue(path, Constants.ROOTCATERGORY, Constants.CONST_OPTION_SILENTINSTALL);
                if (!string.IsNullOrEmpty(strSilentInstall) &&
                   (strSilentInstall.Trim().ToLower() == Constants.Y_IN_LOWER_CHARS || strSilentInstall.Trim().ToLower() == Constants.YES_IN_LOWER_CHARS))
                {
                    silentMode = true;
                }

                bool isKeepExistingValue = false;
                string strKeepExistingValue  = UtilityHelper.GetValue(path, Constants.ROOTCATERGORY, Constants.CONST_OPTION_KEEPEXISTINGVALUE);
                if (!string.IsNullOrEmpty(strKeepExistingValue) &&
                   (strKeepExistingValue.Trim().ToLower() == Constants.Y_IN_LOWER_CHARS || strKeepExistingValue.Trim().ToLower() == Constants.YES_IN_LOWER_CHARS))
                {
                    isKeepExistingValue = true;
                }

                string strCustomerNo = UtilityHelper.GetValue(path, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO);
                if (silentMode && !isKeepExistingValue && string.IsNullOrEmpty(strCustomerNo))
                {
                    MessageBox.Show("Insufficient parameters in the INI-file. Installation aborted", "TSR User Agent", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string verbose = UtilityHelper.GetValue(path, Constants.ROOTCATERGORY, Constants.CONST_OPTION_VERBOSE);
                if (!string.IsNullOrEmpty(verbose) &&
                    (verbose.Trim().ToLower() == Constants.Y_IN_LOWER_CHARS || verbose.Trim().ToLower() == Constants.YES_IN_LOWER_CHARS)
                    && !silentMode && !isKeepExistingValue)
                {
                    if (!(UtilityHelper.CheckValidConfigurationFile(path)))
                    {
                        MessageBox.Show("Verbose mode has been specified but one or more default values have not been set in the TSROUAOptions.ini file", "TSR User Agent", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                if (!(UtilityHelper.StorteINIFilePath(path)))
                {
                    MessageBox.Show("TSR User Agent Installation interrupted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            PlatformType platform = DetectOutlookPlatformOnLocal();

            string rootLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            string strLinkOUA2010 = string.Empty;

            if (platform == PlatformType.x64)
            {
                if(!silentMode) strLinkOUA2010 = "\\Data\\x64\\setup.exe";
                else strLinkOUA2010 = "\\Data\\x64\\silent\\setup.exe";
            }
            else //if (platform == PlatformType.x86)
            {
                if (!silentMode) strLinkOUA2010 = "\\Data\\x86\\setup.exe";
                else strLinkOUA2010 = "\\Data\\x86\\silent\\setup.exe";
            }

            Process processOUA = new Process();
            processOUA.StartInfo.FileName = rootLocation + strLinkOUA2010;

            //Process[] procs = Process.GetProcessesByName("msiexec");
            //if (null != procs && procs.Length > 0)
            //{
            //    int hWnd;
            //    foreach (Process p in procs)
            //    {
            //        if (p.StartInfo.FileName == strLinkOUA2010)
            //        {
            //            hWnd = p.MainWindowHandle.ToInt32();
            //            ShowWindow(hWnd, SW_HIDE);
            //            return;
            //        }
            //    }
            //}

            try
            {
                processOUA.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            processOUA.WaitForExit();
        }

        private static PlatformType DetectOutlookPlatformOnLocal()
        {
            PlatformType ptype = PlatformType.none;
            RegistryKey rk = null;
            try
            {
                rk = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Office\15.0\Outlook", false);
                if (rk != null)
                {
                    Object bitnessValue = rk.GetValue("Bitness");
                    if (bitnessValue != null)
                    {
                        string platform = bitnessValue.ToString();

                        if (platform.Equals("x64", StringComparison.OrdinalIgnoreCase))
                            ptype = PlatformType.x64;
                        else if (platform.Equals("x86", StringComparison.OrdinalIgnoreCase))
                            ptype = PlatformType.x86;
                        else
                            ptype = PlatformType.none;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Detect outlook platform: " + ex.Message);
                return ptype;
            }
            finally
            {
                if (rk != null)
                {
                    rk.Close();
                }
            }
            return ptype;
        }
    }
}
