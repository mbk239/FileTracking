namespace TSR.Shell
{
    partial class About
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLegalWarning = new System.Windows.Forms.Label();
            this.lblCompanyName = new System.Windows.Forms.LinkLabel();
            this.lblVersionNumber = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblExchangeFlag = new System.Windows.Forms.Label();
            this.lblCreateSupportLog = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtOrgantionName = new System.Windows.Forms.Label();
            this.txtLicense = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLegalWarning
            // 
            this.lblLegalWarning.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.lblLegalWarning.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblLegalWarning.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegalWarning.Location = new System.Drawing.Point(3, 263);
            this.lblLegalWarning.Name = "lblLegalWarning";
            this.lblLegalWarning.Size = new System.Drawing.Size(430, 16);
            this.lblLegalWarning.TabIndex = 3;
            this.lblLegalWarning.Text = "Copyright TimeSheet Reporter. All rights reserved.";
            this.lblLegalWarning.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblCompanyName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCompanyName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblCompanyName.Location = new System.Drawing.Point(0, 0);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(430, 25);
            this.lblCompanyName.TabIndex = 1;
            this.lblCompanyName.TabStop = true;
            this.lblCompanyName.Text = "www.TimeSheetReporter.com";
            this.lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCompanyName.Click += new System.EventHandler(this.lblCompanyName_Click);
            // 
            // lblVersionNumber
            // 
            this.lblVersionNumber.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblVersionNumber.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersionNumber.Location = new System.Drawing.Point(3, 59);
            this.lblVersionNumber.Name = "lblVersionNumber";
            this.lblVersionNumber.Size = new System.Drawing.Size(430, 21);
            this.lblVersionNumber.TabIndex = 2;
            this.lblVersionNumber.Text = "Version 5.1";
            this.lblVersionNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoEllipsis = true;
            this.lblProductName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblProductName.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.Location = new System.Drawing.Point(3, 0);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(430, 35);
            this.lblProductName.TabIndex = 0;
            this.lblProductName.Text = "TimeSheet Reporter";
            this.lblProductName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(430, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Outlook User Agent";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblExchangeFlag
            // 
            this.lblExchangeFlag.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExchangeFlag.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExchangeFlag.Location = new System.Drawing.Point(3, 80);
            this.lblExchangeFlag.Name = "lblExchangeFlag";
            this.lblExchangeFlag.Size = new System.Drawing.Size(430, 20);
            this.lblExchangeFlag.TabIndex = 8;
            this.lblExchangeFlag.Text = "Exchangeflag";
            this.lblExchangeFlag.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblExchangeFlag.Visible = false;
            // 
            // lblCreateSupportLog
            // 
            this.lblCreateSupportLog.AutoSize = true;
            this.lblCreateSupportLog.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblCreateSupportLog.Location = new System.Drawing.Point(307, 0);
            this.lblCreateSupportLog.Name = "lblCreateSupportLog";
            this.lblCreateSupportLog.Size = new System.Drawing.Size(123, 13);
            this.lblCreateSupportLog.TabIndex = 9;
            this.lblCreateSupportLog.TabStop = true;
            this.lblCreateSupportLog.Text = "Create Support Log Files";
            this.lblCreateSupportLog.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lblCreateSupportLog.Click += new System.EventHandler(this.lblCreateSupportLog_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.lblLegalWarning, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblExchangeFlag, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblVersionNumber, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblProductName, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtOrgantionName, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.txtLicense, 0, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.83082F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.706633F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.790144F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.257572F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.225806F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.11111F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.739779F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.632723F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.69914F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.510138F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.269803F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(436, 279);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblCreateSupportLog);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 240);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(430, 17);
            this.panel1.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblCompanyName);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 112);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(430, 25);
            this.panel2.TabIndex = 10;
            // 
            // txtOrgantionName
            // 
            this.txtOrgantionName.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtOrgantionName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrgantionName.Location = new System.Drawing.Point(3, 191);
            this.txtOrgantionName.Name = "txtOrgantionName";
            this.txtOrgantionName.Size = new System.Drawing.Size(430, 23);
            this.txtOrgantionName.TabIndex = 11;
            this.txtOrgantionName.Text = "TSR Company";
            this.txtOrgantionName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtLicense
            // 
            this.txtLicense.AutoSize = true;
            this.txtLicense.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtLicense.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLicense.Location = new System.Drawing.Point(3, 172);
            this.txtLicense.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.txtLicense.Name = "txtLicense";
            this.txtLicense.Size = new System.Drawing.Size(430, 16);
            this.txtLicense.TabIndex = 12;
            this.txtLicense.Text = "This product is licensed to";
            this.txtLicense.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // About
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(436, 279);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "About";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About TSR";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.About_FormClosed);
            this.Load += new System.EventHandler(this.About_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblLegalWarning;
        private System.Windows.Forms.LinkLabel lblCompanyName;
        private System.Windows.Forms.Label lblVersionNumber;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblExchangeFlag;
        private System.Windows.Forms.LinkLabel lblCreateSupportLog;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label txtOrgantionName;
        private System.Windows.Forms.Label txtLicense;

    }
}