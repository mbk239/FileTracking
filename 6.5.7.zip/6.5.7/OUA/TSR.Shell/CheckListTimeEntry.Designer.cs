﻿namespace TSR.Shell
{
    partial class CheckListTimeEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.gvTimeEntry = new TSR.Shell.Controls.DataGridViewTSR();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.gvTimeEntry)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnOK.Location = new System.Drawing.Point(863, 286);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // gvTimeEntry
            // 
            this.gvTimeEntry.AllowUserToAddRows = false;
            this.gvTimeEntry.AllowUserToDeleteRows = false;
            this.gvTimeEntry.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.gvTimeEntry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvTimeEntry.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvTimeEntry.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gvTimeEntry.Location = new System.Drawing.Point(3, 3);
            this.gvTimeEntry.MultiSelect = false;
            this.gvTimeEntry.Name = "gvTimeEntry";
            this.gvTimeEntry.ReadOnly = true;
            this.gvTimeEntry.Size = new System.Drawing.Size(935, 276);
            this.gvTimeEntry.TabIndex = 2;
            this.gvTimeEntry.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvTimeEntry_CellContentClick);
            this.gvTimeEntry.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvTimeEntry_CellContentDoubleClick);
            this.gvTimeEntry.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gvTimeEntry_ColumnHeaderMouseClick);
            this.gvTimeEntry.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.gvTimeEntry_DataError);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.gvTimeEntry, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOK, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.12739F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.872611F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(941, 314);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // CheckListTimeEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 314);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CheckListTimeEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CheckListTimeEntry";
            this.Load += new System.EventHandler(this.CheckListTimeEntry_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvTimeEntry)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private TSR.Shell.Controls.DataGridViewTSR gvTimeEntry;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}