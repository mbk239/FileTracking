using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Collections.Specialized;
using System.Globalization;
using System.Net;
using System.IO;
using Microsoft.Win32;
using System.Diagnostics;
using TSR.Core;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Timers;
using System.Data;
using System.Reflection;
//using SHDocVw;

namespace TSR.Shell
{
    public static class UIHelper
    {
        private const string DEFAULT_VALUE_MEMBERNAME = "Key";
        private const string DEFAULT_DISPLAY_MEMBERNAME = "Value";
        public const string BACK_COLOR_DEFAULT = "#E3EFFF";
        public const string BACK_COLOR_CONTENT_DEFAULT = "#BFDBFF";
        public const string BACK_COLOR_MISSINGDATA_ROW = "#D2D2D2";
        public const string BACK_COLOR_OLDDBDATA_ROW = "#BBBBBB";
        public const string BACK_COLOR_VALIDDATA_ROW  = "#FFFFFF";
        public const string BACK_COLOR_ISCREATEDVIAWEB_ROW = "#4682B4";
        public const string COLOR_LABAL_ADV_FORM = "#3f68d3";
        public static Color GetColor(String strColor)
        {
            string hc = ExtractHexDigits(strColor);
            if (hc.Length != 6)
            {
                // you can choose whether to throw an exception
                //throw new ArgumentException("hexColor is not exactly 6 digits.");
                return Color.Empty;
            }
            string r = hc.Substring(0, 2);
            string g = hc.Substring(2, 2);
            string b = hc.Substring(4, 2);
            Color color = Color.Empty;
            try
            {
                int ri
                   = Int32.Parse(r, System.Globalization.NumberStyles.HexNumber);
                int gi
                   = Int32.Parse(g, System.Globalization.NumberStyles.HexNumber);
                int bi
                   = Int32.Parse(b, System.Globalization.NumberStyles.HexNumber);
                color = Color.FromArgb(ri, gi, bi);
            }
            catch
            {
                // you can choose whether to throw an exception
                //throw new ArgumentException("Conversion failed.");
                return Color.Empty;
            }
            return color;

        }

        public static object COMCreateObject(string sProgID)
        {            
            Type oType = Type.GetTypeFromProgID(sProgID);
            if (oType != null)
            {
                return Activator.CreateInstance(oType);
            }
            return null;
        } 
       
        public static CultureInfo GetCultureByLanguageId(String languageId)
        {
            CultureInfo culture = new CultureInfo(languageId);
            if (!culture.IsNeutralCulture)
            {
                culture = CultureInfo.CreateSpecificCulture(languageId);
            }
            return culture;
        }
        public static CultureInfo[] GetCultureByLanguageIds(StringCollection languageIds)
        {
            CultureInfo[] cultures = new CultureInfo[languageIds.Count];
            int index = 0;
            foreach (string languageId in languageIds)
            {
                cultures[index++] = GetCultureByLanguageId(languageId);
            }
            return cultures;

        }

        public static void FillCheckedListBox(CheckedListBox clb, object lst, string displayMember, string valueMember, object selectedItemID, bool sortEnabled)
        {
            try
            {
                if (lst != null)
                {
                    //if (selectedItemID == null)
                    //{
                    //    selectedItemID = lst[0];
                    //}
                    IList alData;
                    if (sortEnabled)
                        alData = SortData((IList)lst, displayMember);
                    else
                        alData = (IList)lst;

                    if (alData.Count > 0)
                    {
                        lst = alData;
                    }
                    clb.DataSource = lst;
                    clb.DisplayMember = displayMember;
                    clb.ValueMember = valueMember;

                    if (selectedItemID != null)
                    {
                        clb.SelectedValue = selectedItemID;
                    }

                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                throw ex;
            }
        }

        //public static void FillComboBox(ComboBox cmb, CultureInfo[] cultures)
        //{
        //    FillComboBox(cmb, cultures, "EnglishName", "Name", null);
        //    cmb.SelectedItem = System.Threading.Thread.CurrentThread.CurrentUICulture;          
        //}
        public static void FillComboBox(ComboBox cmb, object lst, string displayMember, string valueMember, bool sortEnabled)
        {
            FillComboBox(cmb, lst, displayMember, valueMember, null, sortEnabled);
        }
        //public static void FillComboBox(ComboBox cmb, object lst, string displayMember, string valueMember, object selectedItemID, bool sortEnabled)
        //{
        //    FillComboBox(cmb, lst, displayMember, valueMember, selectedItemID, sortEnabled);
        //}

        public static void FillComboBox(ComboBox cmb, object lst, string displayMember, string valueMember, object selectedItemID, bool sortEnabled)
        {
            try
            {
                if (lst != null)
                {
                    //if (selectedItemID == null)
                    //{
                    //    selectedItemID = lst[0];
                    //}
                    IList alData;
                    if (sortEnabled)
                        alData = SortData((IList)lst, displayMember);
                    else
                        alData = (IList)lst;

                    if (alData.Count > 0)
                    {
                        lst = alData;
                    }
                    cmb.DataSource = lst;
                    cmb.DisplayMember = displayMember;
                    cmb.ValueMember = valueMember;

                    if (selectedItemID != null)
                    {
                        cmb.SelectedValue = selectedItemID;
                    }
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                throw ex;
            }
        }
        public static void FillComboWithEnum(ComboBox cmb, Type enumType, string defaultSelectionText)
        {
            FillComboBox(cmb, Core.EnumHelper.GetListFromEnum(enumType, defaultSelectionText),
                Core.EnumListItem.COL_NAME, Core.EnumListItem.COL_ID, true);
        }
        public static void FillCheckedListBoxWithEnum(CheckedListBox clb, Type enumType)
        {
            FillCheckedListBox(clb, Core.EnumHelper.GetListFromEnum(enumType, null),
                Core.EnumListItem.COL_NAME, Core.EnumListItem.COL_ID, null, true);
        }
        public static IList SortData(IList listToBeSorted, string CustomSortExpression)
        {
            ArrayList list = new ArrayList();

            //IEnumerable enumeration1 = listToBeSorted;
            //IEnumerator enumerator1 = enumeration1.GetEnumerator();
            //enumerator1.MoveNext();
            //Type objType1 = enumerator1.Current.GetType();
            //objType1.
            //List<objType1> lst1 = new List<objType1>();
            //List<o

            if (!String.IsNullOrEmpty(CustomSortExpression))
            {
                IEnumerable enumeration = listToBeSorted;
                IEnumerator enumerator = enumeration.GetEnumerator();

                int eleCount = 0;
                while (enumerator.MoveNext())
                {
                    eleCount++;
                }
                for (int i = 0; i < eleCount; i++)
                {
                    enumerator = enumeration.GetEnumerator();
                    object selected = null;
                    string selectedValue = String.Empty;
                    while (enumerator.MoveNext())
                    {
                        if (i == 0) //if it is first item, no need to compare, keep it there, cause it is something like 'Select an Organization'
                        {
                            selected = enumerator.Current;
                            break;
                        }

                        if (list.Contains(enumerator.Current))
                            continue;

                        Type objType = enumerator.Current.GetType();
                        System.Reflection.PropertyInfo valueProp = objType.GetProperty(CustomSortExpression);
                        object currentValueObj = valueProp.GetValue(enumerator.Current, null);
                        string currentValue = (currentValueObj == null ? String.Empty : currentValueObj.ToString());
                        if (selected == null)
                        {
                            selected = enumerator.Current;
                            selectedValue = currentValue;
                            continue;
                        }

                        if (currentValue.CompareTo(selectedValue) < 0)
                        {
                            selected = enumerator.Current;
                            selectedValue = currentValue;
                        }
                    }
                    if (selected != null)
                        list.Add(selected);
                }
            }
            return list;
        }

        /// <summary>
        /// Filll Combo Box using NameValueCollection List
        /// </summary>
        /// <param name="cmb"></param>
        /// <param name="collection"></param>
        public static void FillComboBoxWithNameValueCollection(ComboBox cmb, NameValueCollection collection)
        {

            ArrayList list = new ArrayList();
            foreach (String key in collection.Keys)
            {
                KeyValuePair<String, String> pair = new KeyValuePair<string, string>(key, collection[key]);
                list.Add(pair);
            }            
            cmb.DataSource = list;
            cmb.ValueMember = DEFAULT_VALUE_MEMBERNAME;
            cmb.DisplayMember = DEFAULT_DISPLAY_MEMBERNAME;
        }

        #region Private methods
        /// <summary>
        /// Extract only the hex digits from a string.
        /// </summary>
        public static string ExtractHexDigits(string input)
        {
            // remove any characters that are not digits (like #)
            Regex isHexDigit
               = new Regex("[abcdefABCDEF\\d]+", RegexOptions.Compiled);
            string newnum = "";
            foreach (char c in input)
            {
                if (isHexDigit.IsMatch(c.ToString()))
                    newnum += c.ToString();
            }
            return newnum;
        }

        #endregion
    }

    public abstract class Synchronizer : IDisposable
    {
        private static Core.SyncEngine syncEngine;
        public static System.Windows.Forms.Timer timer;
        private static IMemoryBox _memBox;

        public static ISyncEngineCheckListTimeEntry checkListTiemEntry;
        public static ISyncEngineOverwriteTimeEntry overwriteTimeEntry;

        /// <summary>
        /// Synchronize process for backgroundworker
        /// </summary>
        public static void Synchronize(IMemoryBox membox)
        {
            Synchronize(true, membox);
        }

        static void GetTimerInstance()
        {
            if (timer == null)
                timer = new System.Windows.Forms.Timer();
            //return timer;
        }

        /// <summary>
        /// Synchronize process
        /// </summary>
        /// <param name="inBackground"></param>
        public static void Synchronize(bool inBackground, IMemoryBox memBox)
        {
            syncEngine = Core.SyncEngine.GetInstance();
            if (syncEngine == null) // it must be already in another synchronization process
            {
                return;
            }
            syncEngine.DoAsBackGroundWorker = inBackground;

            syncEngine._checkListTimeEntry = new TSR.Shell.CheckListTimeEntry();
            syncEngine._overwriteTimeEntries = new TSR.Shell.OverwriteTimeEntries();

            if (TSRFacade.IsServiceUp(Core.SettingsHelper.TSRServerAddress))
            {
                bool isWrongUserPass = !TSRFacade.LogInToServer();
                {
                    if (isWrongUserPass && !TSRFacade.TSRLoginDismiss)
                    {
                        frmTSRLoginRequired frmLogin = frmTSRLoginRequired.GetInstance(true);
                        frmLogin.ShowDialog();
                    }
                }
            }
            syncEngine.StartSynchornization(memBox);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (TSR.Core.SettingsHelper.TSRAutoSyncOption)
                {
                    if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
                    {
                        Synchronize(false, _memBox);
                    }
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        /// <summary>
        /// synchonization with timer
        /// </summary>
        public static void SynchronizeByTimer(IMemoryBox MemoryBox)
        {
            if (TSR.Core.SettingsHelper.TSRAutoSyncOption == false)
            {
                if (timer != null)
                {
                    timer.Stop();
                    timer = null;
                }
            }
            else
            {
                _memBox = MemoryBox;
                if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
                {
                    int numberOfintervals = (Core.SettingsHelper.TSRAutoSyncIndex > -1 ? Core.SettingsHelper.TSRAutoSyncIndex : 1);
                    if (numberOfintervals > 0)
                    {
                        int intervalInMillSec = 0;

                        //assumption - if the interval is not in hours, it must be in minutes
                        int intervalInSeconds = 60;
                        if (Core.SettingsHelper.TSRAutoSyncPeriod == (int)TSR.Core.SettingsHelper.PeriodType.Hour)
                            intervalInSeconds = 3600;

                        intervalInMillSec = numberOfintervals * intervalInSeconds * 1000;
                        
                        GetTimerInstance();
                        
                        timer.Interval = intervalInMillSec;
                        if (TSRFacade.bCheckTimer)
                        {
                            timer.Tick += new EventHandler(timer_Tick);
                        }
                        timer.Start();
                    }
                }
                else
                {
                    if (timer != null)
                    {
                        timer.Stop();
                        timer = null;
                    }
                }
            }

        }

        #region IDisposable Members

        public void Dispose()
        {
            if (syncEngine != null)
                syncEngine = null;
            if (timer != null)
                timer = null;
        }

        #endregion
    }    

    public class ComboBoxTip : ComboBox
    {
        private DropdownWindow mDropdown;
        public delegate void DropdownItemSelectedEventHandler(object sender, DropdownItemSelectedEventArgs e);
        public event DropdownItemSelectedEventHandler DropdownItemSelected;

        protected override void OnDropDown(EventArgs e)
        {
            // Install wrapper
            base.OnDropDown(e);
            // Retrieve handle to dropdown list
            COMBOBOXINFO info = new COMBOBOXINFO();
            info.cbSize = Marshal.SizeOf(info);
            SendMessageCb(this.Handle, 0x164, IntPtr.Zero, out info);
            mDropdown = new DropdownWindow(this);
            mDropdown.AssignHandle(info.hwndList);
        }
        protected override void OnDropDownClosed(EventArgs e)
        {
            // Remove wrapper
            mDropdown.ReleaseHandle();
            mDropdown = null;
            base.OnDropDownClosed(e);
            OnSelect(-1, Rectangle.Empty, true);
        }
        internal void OnSelect(int item, Rectangle pos, bool scroll)
        {
            if (this.DropdownItemSelected != null)
            {
                pos = this.RectangleToClient(pos);
                DropdownItemSelected(this, new DropdownItemSelectedEventArgs(item, pos, scroll));
            }
        }
        // Event handler arguments
        public class DropdownItemSelectedEventArgs : EventArgs
        {
            private int mItem;
            private Rectangle mPos;
            private bool mScroll;
            public DropdownItemSelectedEventArgs(int item, Rectangle pos, bool scroll) { mItem = item; mPos = pos; mScroll = scroll; }
            public int SelectedItem { get { return mItem; } }
            public Rectangle Bounds { get { return mPos; } }
            public bool Scrolled { get { return mScroll; } }
        }

        // Wrapper for combobox dropdown list
        private class DropdownWindow : NativeWindow
        {
            private ComboBoxTip mParent;
            private int mItem;
            public DropdownWindow(ComboBoxTip parent)
            {
                mParent = parent;
                mItem = -1;
            }
            protected override void WndProc(ref Message m)
            {
                // All we're getting here is WM_MOUSEMOVE, ask list for current selection for LB_GETCURSEL
                Console.WriteLine(m.ToString());
                base.WndProc(ref m);
                if (m.Msg == 0x200)
                {
                    int item = (int)SendMessage(this.Handle, 0x188, IntPtr.Zero, IntPtr.Zero);
                    if (item != mItem)
                    {
                        mItem = item;
                        OnSelect(false);
                    }
                }
                if (m.Msg == 0x115)
                {
                    // List scrolled, item position would change
                    OnSelect(true);
                }
            }
            private void OnSelect(bool scroll)
            {
                RECT rc = new RECT();
                SendMessageRc(this.Handle, 0x198, (IntPtr)mItem, out rc);
                MapWindowPoints(this.Handle, IntPtr.Zero, ref rc, 2);
                mParent.OnSelect(mItem, Rectangle.FromLTRB(rc.Left, rc.Top, rc.Right, rc.Bottom), scroll);
            }
        }
        // P/Invoke declarations
        private struct COMBOBOXINFO
        {
            public Int32 cbSize;
            public RECT rcItem;
            public RECT rcButton;
            public int buttonState;
            public IntPtr hwndCombo;
            public IntPtr hwndEdit;
            public IntPtr hwndList;
        }
        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }
        [DllImport("user32.dll", EntryPoint = "SendMessageW", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessageCb(IntPtr hWnd, int msg, IntPtr wp, out COMBOBOXINFO lp);
        [DllImport("user32.dll", EntryPoint = "SendMessageW", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessageRc(IntPtr hWnd, int msg, IntPtr wp, out RECT lp);
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);
        [DllImport("user32.dll")]
        private static extern int MapWindowPoints(IntPtr hWndFrom, IntPtr hWndTo, [In, Out] ref RECT rc, int points);
    }

}
