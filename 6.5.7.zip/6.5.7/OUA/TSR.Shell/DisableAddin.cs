﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.Core;

namespace TSR.Shell
{
    public partial class DisableAddin : Controls.OUAForm
    {
        private const int waitTimeDisable = 10;
        private Timer tm = null;

        public DisableAddin()
        {
            InitializeComponent();
            this.Text = ResourceManager.GetResourceString("DisableTSRAddin","Disable TSR Addin");
        }

        private void DisableAddin_Load(object sender, EventArgs e)
        {
            //this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);            
            //lblMessegaBox.Text = ResourceManager.GetResourceString("DoNotProvidedUserAccount", "TSR Addin will be disabled because login account to server is invalid");
            lblMessegaBox.Text = ResourceManager.GetResourceString("DoNotProvidedUserAccount", "Username and/or password missing. TSR is not available.");
            tm = new Timer();
            tm.Interval = waitTimeDisable * 1000;
            tm.Tick += new EventHandler(tm_Tick);
            tm.Start();            
        }
        
        private void tm_Tick(object sender, EventArgs e)
        {            
            this.Close();
            tm.Stop();
        }
        protected override void OnClosing(CancelEventArgs e)
        {
            if (tm != null)
                tm.Stop();
            base.OnClosing(e);
        }
    }
}
