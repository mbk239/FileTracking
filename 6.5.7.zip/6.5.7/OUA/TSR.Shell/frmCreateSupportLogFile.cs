﻿using System;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using TSR.Core;
using TSR.Core.Logging;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace TSR.Shell
{
    public partial class frmCreateSupportLogFile : Controls.OUAForm
    {
        private SyncEngine.SyncStatus _syncStatus = SyncEngine.SyncStatus.Undefined;
        private StringBuilder _message = new StringBuilder();
        private string _yesValue = "Yes";
        private string _noValue = "No";

        private string _selectedLanguageName = String.Empty;
        private string _selectedLanguageId = String.Empty;

        public static int Instances { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public frmCreateSupportLogFile()
        {
            InitializeComponent();
            this.lblCreateSupportLogWaiting.Text = Core.ResourceManager.GetResourceString("CreateSupportLogWaiting", "Creating support log files. Please wait, this may take a few minutes…");
            this.Text = Core.ResourceManager.GetResourceString("CreateSupportLog", "Create Support Log Files");
            SetLocationForLabels();
        }

        private void SetLocationForLabels()
        {
            int windowWidth = this.Width;
            int windowHeight = this.Height;
            int labelWidth = this.lblCreateSupportLogWaiting.Width;
            int labelHeight = this.lblCreateSupportLogWaiting.Height;
            if (windowWidth < labelWidth + 10)
            {
                windowWidth += labelWidth - windowWidth + 10;
                this.Width = windowWidth;
            }
            int x = (windowWidth - labelWidth) / 2;
            int y = (windowHeight - labelHeight * 3) / 2;
            this.lblCreateSupportLogWaiting.Location = new System.Drawing.Point(x, y);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string GetAbsolutePathFile()
        {
            string path = String.Empty;
            IsolatedStorageFile isoStore = RollingFileStream.Storage;
            using (IsolatedStorageFileStream oStream = new IsolatedStorageFileStream("TSRLog\\temp.txt", FileMode.OpenOrCreate, isoStore))
            {
                path = oStream.GetType().GetField("m_FullPath", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(oStream).ToString();
                oStream.Dispose();
                oStream.Close();
            }
            File.Delete(path);
            path = path.Substring(0, path.LastIndexOf('\\')) + "\\";

            return path;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmCreateSupportLogFile_Load(object sender, EventArgs e)
        {
            //Store data language
            _selectedLanguageName = TSR.Core.SettingsHelper.TSRLanguageName;
            _selectedLanguageId = TSR.Core.SettingsHelper.TSRLanguageId;
            //Set language
            TSR.Core.SettingsHelper.TSRLanguageName = Constants.DEFAULT_LANGUAGE_NAME;
            TSR.Core.SettingsHelper.TSRLanguageId = Constants.DEFAULT_CULTURE_LCID;
            //Synchronization
            Synchronize(true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inBackground"></param>
        private void Synchronize(bool inBackground)
        {
            try
            {
                Core.SyncEngine syncEngineCheck = Core.SyncEngine.GetSingleton();
                if (syncEngineCheck != null)
                {
                    syncEngineCheck.Completed += new SyncEngine.SynchronizationCompleted(syncEngineCheck_Completed);
                    syncEngineCheck.ProgressChanged += new SyncEngine.SynchronizationProgressChanged(syncEngineCheck_ProgressChanged);
                }
                else
                {
                    syncEngineCheck = null;
                    SynchronizationData(inBackground);
                }
            }
            catch (System.Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        private void syncEngineCheck_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            this.Activate();
        }

        private void SynchronizationData(bool inBackground)
        {
            Core.SyncEngine syncEngine = Core.SyncEngine.GetInstance(null);
            if (syncEngine == null)
            {
                return;
            }
            syncEngine.DoAsBackGroundWorker = inBackground;
            syncEngine.ProgressChanged += new SyncEngine.SynchronizationProgressChanged(syncEngine_ProgressChanged);
            syncEngine.Completed += new SyncEngine.SynchronizationCompleted(syncEngine_Completed);
            IMemoryBox memBox = new MemoryBox();
            ISyncEngineCheckListTimeEntry checkListTiemEntry = new CheckListTimeEntry();
            syncEngine._checkListTimeEntry = checkListTiemEntry;
            syncEngine._overwriteTimeEntries = new OverwriteTimeEntries();
            syncEngine.StartSynchornization(memBox);
        }

        private void syncEngineCheck_Completed(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            Core.SyncEngine syncEngine = Core.SyncEngine.GetSingleton();
            if (syncEngine != null)
            {
                syncEngine.Dispose();
                syncEngine = null;
            }
            SynchronizationData(true);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void syncEngine_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            this.Activate();
            if (e.UserState != null)
            {
                SyncEngine.SyncMessage progressMessage = (SyncEngine.SyncMessage)e.UserState;
                _syncStatus = progressMessage.Status;

                if (!string.IsNullOrEmpty(progressMessage.Message))
                {
                    LogAppend(progressMessage.Message, progressMessage.Status);
                }
                switch (progressMessage.Status)
                {
                    case SyncEngine.SyncStatus.Completed:
                        LogAppend(string.Empty, SyncEngine.SyncStatus.Completed);
                        break;
                    case SyncEngine.SyncStatus.CompletedWithErrors:
                        LogAppend(string.Empty, SyncEngine.SyncStatus.CompletedWithErrors);
                        break;
                }
            }
        }

        private void syncEngine_Completed(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (_syncStatus != SyncEngine.SyncStatus.CompletedWithErrors)
                    _syncStatus = SyncEngine.SyncStatus.Completed;

                this.Activate();
                this.Close();

                this.ProcessGetSyncData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                TSR.Core.SettingsHelper.TSRLanguageName = _selectedLanguageName;
                TSR.Core.SettingsHelper.TSRLanguageId = _selectedLanguageId;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void ProcessGetSyncData()
        {
            try
            {
                string path = this.GetAbsolutePathFile();
                //Return result automatic sync

                StringBuilder syncResult = new StringBuilder("***SYNCHRONIZATION RESULTS***" + Environment.NewLine);
                syncResult.Append(_message);

                //Get Settings
                StringBuilder settings = this.GetDataSettings();
                settings.Append(syncResult.ToString());

                string settingsFile = path + "settings.txt";
                string logFile = path + LoggingHandler.GetLogFileName();

                //Write settings
                System.IO.File.WriteAllText(settingsFile, settings.ToString());

                if (File.Exists(settingsFile) && File.Exists(logFile))
                {
                    //Create new mail
                    Outlook.MailItem _mailItem = TSR.Core.OutlookHelper.CreateNewEmail(settingsFile, logFile);
                    _mailItem.Display(false);
                }
            }
            catch (System.IO.FileNotFoundException ex)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            catch (System.Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="status"></param>
        private void LogAppend(string message, TSR.Core.SyncEngine.SyncStatus status)
        {
            _message.Append(message);
            if (status == SyncEngine.SyncStatus.Completed)
            {
                this.Cursor = Cursors.Default;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private StringBuilder GetDataSettings()
        {
            StringBuilder sbResult = new StringBuilder();
            //VERSION INFOMATION
            StringBuilder sbVersion = new StringBuilder("***VERSION INFORMATIONS***" + Environment.NewLine);
            sbVersion.AppendLine("Operation System: " + this.GetFriendlyOSName());
            sbVersion.AppendLine("Outlook Version: " + this.GetOutLookVersion());
            //USER ACCOUNT
            StringBuilder sbTabUserAccount = new StringBuilder("***SETTINGS – USER ACCOUNT***" + Environment.NewLine);
            sbTabUserAccount.AppendLine("Customer number: " + TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_CUSTOMERNO_KEY));
            sbTabUserAccount.AppendLine("Username: " + SettingsHelper.TSRUserName);
            sbTabUserAccount.AppendLine("Server address: " + SettingsHelper.TSRServerAddress);
            sbTabUserAccount.AppendLine("Secure mode: " + (TSR.Core.TSRFacade.GetTSRSSLMode() ? "SSL Mode" : _noValue));
            sbTabUserAccount.AppendLine("Web interface: " + (String.IsNullOrEmpty(SettingsHelper.TSRWebinterface) ? "[Empty]" : SettingsHelper.TSRWebinterface));
            sbTabUserAccount.AppendLine("Warning submit entry: " + (SettingsHelper.TSRDontShowAgain ? _yesValue : _noValue));
            sbTabUserAccount.AppendLine("Retrieve settings server: " + (SettingsHelper.TSRDoNotRetrieveSettingsServer ? _yesValue : _noValue));
            //WHAT TO SYNC
            StringBuilder sbTabWhatToSync = new StringBuilder("***SETTINGS – WHAT TO SYNCHRONIZE***" + Environment.NewLine);
            sbTabWhatToSync.AppendLine("Setup data: " + (SettingsHelper.SynchronizeTSRSetupData ? _yesValue : _noValue));
            sbTabWhatToSync.AppendLine("TSR items: " + (SettingsHelper.SynchronizeTSREntries ? _yesValue : _noValue));
            sbTabWhatToSync.AppendLine("Outlook folder to sync: " + SettingsHelper.GetTSROutlookFolderToSync().Split('#')[3].ToString());
            sbTabWhatToSync.AppendLine("Synchronize range index in the past: " + SettingsHelper.TSRSyncRangeIndex + " " + this.GetMiscPeriod(SettingsHelper.TSRSyncRangePeriod));
            sbTabWhatToSync.AppendLine("Synchronize range index in the future: " + SettingsHelper.TSRSyncRangeIndexFuture + " " + this.GetMiscPeriod(SettingsHelper.TSRSyncRangePeriodFuture));
            //AUTOMATIC SYNC
            StringBuilder sbTabAutomaticSync = new StringBuilder("***SETTINGS – AUTOMATIC SYNC***" + Environment.NewLine);
            sbTabAutomaticSync.AppendLine("Don't sync automatically: " + (SettingsHelper.TSRAutoSyncOption ? _noValue : _yesValue));
            sbTabAutomaticSync.AppendLine("Automatically synchronize: " + (SettingsHelper.TSRAutoSyncOption ? _yesValue : _noValue));
            sbTabAutomaticSync.AppendLine("Synchronize every time I connect to MS Outlook : " + (SettingsHelper.TSRAutoSyncWhenOutlookOpen ? _yesValue : _noValue));
            sbTabAutomaticSync.AppendLine("Synchronize on MS Outlook shutdown: " + (SettingsHelper.TSRAutoSyncWhenOutlookClose ? _yesValue : _noValue));
            sbTabAutomaticSync.AppendLine("Synchronize in intervals while MS Outlook is connected : " + (SettingsHelper.TSRAutoSyncPeriodOption ? _yesValue : _noValue));
            sbTabAutomaticSync.AppendLine("Interval value: " + SettingsHelper.TSRAutoSyncIndex + (SettingsHelper.TSRAutoSyncPeriod == 0 ? " Minutes" : " Hour"));

            //MISCELLANEOUS
            StringBuilder sbTabMiscellaneous = new StringBuilder("***SETTINGS – MISCELLANEOUS***" + Environment.NewLine);
            sbTabMiscellaneous.AppendLine("Launch TSR Outlook Sync. on Outlook startup: " + (SettingsHelper.TSRMiscLaunch ? _yesValue : _noValue));
            sbTabMiscellaneous.AppendLine("Do not synchronize completed TSR Items from Server: " + (SettingsHelper.TSRMiscNotSyncCompletedData ? _yesValue : _noValue));
            sbTabMiscellaneous.AppendLine("Do not synchronize entries created via web interface: " + (SettingsHelper.TSRMiscNotSyncTECreatedViaWeb ? _yesValue : _noValue));
            sbTabMiscellaneous.AppendLine("Recreate deleted TSR Appointments of Outlook during synchronization: " + (SettingsHelper.TSRMiscSyncRemovedData ? _yesValue : _noValue));
            sbTabMiscellaneous.AppendLine("Misc Past Index: " + SettingsHelper.TSRMiscPastIndex + " " + this.GetMiscPeriod(TSR.Core.SettingsHelper.TSRMiscPastPeriod));
            sbTabMiscellaneous.AppendLine("Misc Future Index: " + SettingsHelper.TSRMiscFutureIndex + " " + this.GetMiscPeriod(TSR.Core.SettingsHelper.TSRMiscFuturePeriod));
            sbTabMiscellaneous.AppendLine("Preferred Language: " + _selectedLanguageName);
            sbTabMiscellaneous.AppendLine("Activate tooltip: " + (SettingsHelper.TSRDisplayTooltip ? _yesValue : _noValue));
            sbTabMiscellaneous.AppendLine("Date format: " + (SettingsHelper.TSRDateFormat.Equals("NA") ? "[Not selected]" : SettingsHelper.TSRDateFormat));
            sbTabMiscellaneous.AppendLine("Time format: " + (SettingsHelper.TSRTimeFormat.Equals("NA") ? "[Not selected]" : SettingsHelper.TSRTimeFormat));
            //CONNECTION SETTINGS
            StringBuilder sbTabConnectionSettings = new StringBuilder("***SETTINGS – CONNECTION SETTINGS***" + Environment.NewLine);
            sbTabConnectionSettings.AppendLine("Proxy Type: " + SettingsHelper.ProxyType);
            sbTabConnectionSettings.AppendLine("Proxy Host: " + (String.IsNullOrEmpty(SettingsHelper.ProxyHost) ? "[empty]" : SettingsHelper.ProxyHost));
            sbTabConnectionSettings.AppendLine("Proxy Port: " + (String.IsNullOrEmpty(SettingsHelper.ProxyPort) ? "[empty]" : SettingsHelper.ProxyHost));
            sbTabConnectionSettings.AppendLine("Enable proxy authentication: " + (SettingsHelper.ProxyAuthenticationEnable ? _yesValue : _noValue));
            sbTabConnectionSettings.AppendLine("User name: " + (String.IsNullOrEmpty(SettingsHelper.ProxyUsername) ? "[empty]" : SettingsHelper.ProxyUsername));
            //sbTabConnectionSettings.AppendLine("Password: " + SettingsHelper.ProxyPassword);

            sbTabConnectionSettings.AppendLine("SOCKS4: " + _noValue);
            if (SettingsHelper.ProxyType == SettingsHelper.ProxyTypeEnum.Socks4)
            {
                sbTabConnectionSettings.AppendLine("SOCKS4: " + _yesValue);
            }
            sbTabConnectionSettings.AppendLine("SOCKS5: " + _noValue);
            if (SettingsHelper.ProxyType == SettingsHelper.ProxyTypeEnum.Socks5)
            {
                sbTabConnectionSettings.AppendLine("SOCKS5: " + _yesValue);
            }
            sbTabConnectionSettings.AppendLine("Connection time out value (seconds): " + SettingsHelper.ConnectionTimeOut);
            sbTabConnectionSettings.AppendLine("Proxy Auto Switch: " + (SettingsHelper.ProxyAutoSwitch ? _yesValue : _noValue));

            //ABOUT
            StringBuilder sbAbout = new StringBuilder("***ABOUT***" + Environment.NewLine);
            string strVersion = String.Empty;
            strVersion = ResourceManager.GetResourceString("OutlookAgentVersion", "Version") + " ";
            if (TSR.Core.Constants.Version3 != "0")
            {
                strVersion = strVersion + TSR.Core.Constants.Version3;
            }
            else
            {
                strVersion = strVersion + TSR.Core.Constants.Version;
            }

            if (TSR.Core.Constants.VersionRevision != "0")
            {
                strVersion = strVersion + " Build # " + TSR.Core.Constants.VersionRevision;
            }
            sbAbout.AppendLine("Version number: " + strVersion);
            sbAbout.AppendLine("Exchange Flag: " + (TSRFacade.GetExchangeMode() ? _yesValue : _noValue));
            return sbResult.AppendLine(sbVersion.ToString() + Environment.NewLine +
                sbTabUserAccount.ToString() + Environment.NewLine +
                sbTabWhatToSync.ToString() + Environment.NewLine +
                sbTabAutomaticSync.ToString() + Environment.NewLine +
                sbTabMiscellaneous.ToString() + Environment.NewLine +
                sbTabConnectionSettings.ToString() + Environment.NewLine +
                sbAbout.ToString());
        }

        private string GetOutLookVersion()
        {
            string result = String.Empty;
            string version = OutlookHelper.CurrentApplication.Version;
            string currentApp = OutlookHelper.CurrentApplication.ProductCode;
            int index = version.IndexOf('.');
            try
            {
                int numberOfVersion = Convert.ToInt32(version.Substring(0, index));
                string keyName32 = String.Empty;
                string keyName64 = String.Empty;
                string formatKey64 = String.Empty;
                string formatKey32 = @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Office\{0}.0\Outlook";
                if (this.Is64BitOperatingSystem())
                {
                    formatKey64 = @"HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Office\{0}.0\Outlook";
                }
                switch (numberOfVersion)
                {
                    case 15:
                        keyName32 = String.Format(formatKey32, 15);
                        keyName64 = String.Format(formatKey64, 15);
                        result = "Microsoft Outlook 2013 (" + version + ")";
                        break;
                    case 14:
                        keyName32 = String.Format(formatKey32, 14);
                        keyName64 = String.Format(formatKey64, 14);
                        result = "Microsoft Outlook 2010 (" + version + ")";
                        break;
                    case 12:
                        keyName32 = String.Format(formatKey32, 12);
                        keyName64 = String.Format(formatKey64, 12);
                        result = "Microsoft Outlook 2007 (" + version + ")";
                        break;
                    case 11:
                        keyName32 = String.Format(formatKey32, 11);
                        keyName64 = String.Format(formatKey64, 11);
                        result = "Microsoft Outlook 2003 (" + version + ")";
                        break;

                    case 10:
                        keyName32 = String.Format(formatKey32, 10);
                        keyName64 = String.Format(formatKey64, 10);
                        result = "Microsoft Outlook 2002 (" + version + ")";
                        break;
                    default:
                        return version;
                }
                string bits = String.Empty;
                if (!String.IsNullOrEmpty(keyName64) && Registry.GetValue(keyName64, "Bitness", null) != null)
                {
                    bits = Registry.GetValue(keyName64, "Bitness", String.Empty).ToString();
                }
                else if (!String.IsNullOrEmpty(keyName32) && Registry.GetValue(keyName32, "Bitness", null) != null)
                {
                    bits = Registry.GetValue(keyName32, "Bitness", String.Empty).ToString();
                }
                else { }
                switch (bits)
                {
                    case "x86":
                        result += " 32bit";
                        break;
                    case "x64":
                        result += " 64bit";
                        break;
                    default:
                        break;
                }
                return result;
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnknownException(ex);
                return version;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private string GetMiscPeriod(string index)
        {
            switch (index)
            {
                case "0":
                    return "Hour";
                case "1":
                    return "Day";
                case "2":
                    return "Week";
                case "3":
                    return "Month";
                case "4":
                    return "Year";
            }
            return String.Empty;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private string GetFriendlyOSName()
        {
            try
            {
                var name = (from x in new ManagementObjectSearcher("SELECT Caption, OSArchitecture FROM Win32_OperatingSystem").Get().OfType<ManagementObject>()
                            select x).FirstOrDefault();
                if (name == null) return "Unknown";
                string servicePack = Environment.OSVersion.ServicePack;
                if (String.IsNullOrEmpty(servicePack))
                {
                    return String.Format("{0}{1}", name["Caption"], name["OSArchitecture"]);
                }
                else
                {
                    return String.Format("{0}{1} {2}", name["Caption"], servicePack, name["OSArchitecture"]);
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnknownException(ex);
                return "Unknown";
            }
        }

        private bool Is64BitOperatingSystem()
        {
            try
            {
                var name = (from x in new ManagementObjectSearcher("SELECT OSArchitecture FROM Win32_OperatingSystem").Get().OfType<ManagementObject>()
                            select x).FirstOrDefault();
                if (name == null) return false;
                return name["OSArchitecture"].ToString().Contains("64");
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnknownException(ex);
                return false;
            }
        }
    }
}
