﻿using System;
using System.Windows.Forms;
using TSR.Core;

namespace TSR.Shell
{
    /// <summary>
    /// Deprecated class, form
    /// </summary>
    public partial class frmTSRLoginRequired : Controls.OUAForm
    {
        #region Get Single Instance

        private static frmTSRLoginRequired instance = null;

        /// <summary>
        /// method ( Property Like)
        /// Gets an Instance of the class
        /// </summary>
        /// <returns></returns>
        public static frmTSRLoginRequired GetInstance(bool isShowInTaskbar)
        {
            if (instance == null)
                instance = new frmTSRLoginRequired(isShowInTaskbar);
            return instance;
        }

        #endregion

        public frmTSRLoginRequired(bool isShowInTaskbar)
        {
            InitializeComponent();
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            if (TSRFacade.TSRLoginDismiss)
                CloseThis();

            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);

            this.Text = Core.ResourceManager.GetResourceString("TimeSheetReporterLogin", "TimeSheet Reporter Login");
            this.ShowInTaskbar = isShowInTaskbar;
        }       

        private void btnOK_Click(object sender, EventArgs e)
        {
            bool authenticated = false;
            string errorMessage = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(txtUsername.Text.Trim()) && !String.IsNullOrEmpty(txtPassword.Text.Trim()))
                {
                    if (txtUsername.Text.Trim() != TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY)
                        || txtPassword.Text.Trim() != TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY))
                    {
                        TSRFacade.SetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY, txtUsername.Text.Trim());
                        TSRFacade.SetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY, Core.UtilityHelper.EncryptString(txtPassword.Text.Trim()));

                        authenticated = TSRFacade.LogInToServer();
                    }
                }
            }
            catch (Exception ex)
            {
                string strMessegaError = Core.ResourceManager.GetResourceString("ErrorConnectingToTSRServer", "Error connecting to TSR Server");
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message, strMessegaError, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (authenticated)
            {
                DialogResult = DialogResult.OK;
                this.Close();
                this.Dispose();
            }
            else
            {
                ResetControl();
            }
        }
        
        private void btnDismiss_Click(object sender, EventArgs e)
        {
            TSRFacade.TSRLoginDismiss = true;
            CloseThis();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            lblLoginWarning.Text = Core.ResourceManager.GetResourceString("TSRServerLoginRejected", 
                "Login to the TSR Server was rejected due to incorrect username/password. Please type the correct username/password below.").Replace("&#47;", "/");
            lblPassword.Text = Core.ResourceManager.GetResourceString("Passwd_LebelText", "Password");
            lblUsername.Text = TSR.Core.ResourceHelper.UserNameLebelText;
            lblAccount.Text = Core.ResourceManager.GetResourceString("Account", "Account");

            btnDismiss.Text = Core.ResourceManager.GetResourceString("Dismiss", "Dismiss");
            btnOK.Text = Core.ResourceHelper.OK;

            txtAccount.Text = TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_CUSTOMERNO_KEY);

            txtUsername.Location = new System.Drawing.Point(lblUsername.Width + 55, txtUsername.Location.Y);
            txtPassword.Location = new System.Drawing.Point(lblUsername.Width + 55, txtPassword.Location.Y);
            txtAccount.Location = new System.Drawing.Point(lblUsername.Width + 55, txtPassword.Location.Y);
        }

        private void ResetControl()
        {
            txtUsername.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtUsername.Focus();
        }

        private void CloseThis()
        {
            //dispose the instance
            if (instance != null)
            {
                instance.Dispose();
                instance = null;
            }

            //free resources related to this class
            if (this != null)
            {
                try
                {
                    this.Close();
                    this.Dispose();
                }
                catch (System.Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }
        }

        private void frmTSRLoginRequired_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (!TSRFacade.TSRLoginDismiss && DialogResult != System.Windows.Forms.DialogResult.OK)
            //{
            //    e.Cancel = true;
            //}
            CloseThis();
        }
    }
}