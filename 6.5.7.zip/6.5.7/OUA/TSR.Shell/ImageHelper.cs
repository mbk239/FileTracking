using System;
using System.Drawing;
using System.Windows.Forms;
using stdole;

namespace TSR.Shell
{
    public class ImageHelper : AxHost
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public ImageHelper()
            : base(null)
        {
        }
        /// <summary>
        /// This method returns the IPictureDisp from an Image passed as argument
        /// </summary>
        /// <param name="image">The image to convert to a IPictureDisp</param>
        /// <returns>The IPictureDisp of the image</returns>
        public static IPictureDisp Convert(Bitmap bmp)
        {
            return (IPictureDisp)AxHost.GetIPictureDispFromPicture(bmp);
        }
    }
}
