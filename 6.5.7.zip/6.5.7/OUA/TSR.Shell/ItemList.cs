using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;

using Office = Microsoft.Office.Core;
using Outlook = Microsoft.Office.Interop.Outlook;

using Core = TSR.Core;
using Entity = TSR.Core.Entity;
using TSR.Core.Entity;
using TSR.Core;
using System.Globalization;


namespace TSR.Shell
{
    /// <summary>
    /// Partial Class
    /// ItemList
    /// which extends Form and 
    /// Core.IAppointmentObserver
    /// classes
    /// </summary>
    public partial class ItemList : Controls.OUAForm, Core.IAppointmentObserver
    {
        #region Instance Variables

        private Core.AppointmentInformer appInformer;
        private static ItemList instance;
        //private bool _chkAllOrg = true;
        //private bool _chkAllProj = true;
        //private bool _chkAllActs = true;
        //private bool _chkAllStatus = true;
        Timer timer = new Timer();
        private Cursor _DefaultCursor;
        Core.AppointmentRetriever appRetriever;
        private TimeEntryList teFromLocalStorage;

        #endregion

        #region Constructor

        /// <summary>
        /// The constructor
        /// </summary>
        private ItemList()
        {
            InitializeComponent();
        }

        #endregion

        #region singleton

        /// <summary>
        /// This priperty checks 
        /// whether the class is instanciated 
        /// </summary>
        public static bool HasInstance
        {
            get { return (instance != null); }
        }

        /// <summary>
        /// Method
        /// GetInstance
        /// Gets the instnce of this class
        /// </summary>
        /// <returns>
        /// ItemList
        /// </returns>
        public static ItemList GetInstance()
        {
            if (instance == null)
            {
                instance = new ItemList();
            }
            return instance;
        }

        #endregion


        #region Events Handlers

        /// <summary>
        /// Method (Event Handler)
        /// ItemList_FormLoad
        /// Handles the Form Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemList_FormLoad(object sender, EventArgs e)
        {
            CultureInfo userCulture = Core.TSRFacade.GetCurrentCulture();
            CultureInfo sysCulture = (CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            sysCulture.NumberFormat = userCulture.NumberFormat;

            System.Threading.Thread.CurrentThread.CurrentCulture = sysCulture;

            Load_Date();
            btnDelete.Text = TSR.Core.ResourceHelper.DeleteButtonText.ToString();
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            grpSearch.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            panel1.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_MISSINGDATA_ROW);
            panel2.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_OLDDBDATA_ROW);
            panel3.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT); //recurring time entries
            panel4.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_ISCREATEDVIAWEB_ROW);
            lblIsCreatedViaWeb.ForeColor = UIHelper.GetColor(UIHelper.BACK_COLOR_ISCREATEDVIAWEB_ROW);

            _DefaultCursor = this.DefaultCursor;

            appInformer = Core.AppointmentInformer.GetInstance();//get the handler
            appInformer.Register(this); //register it with the controls            
            PopulateAllControls();            
        }
        private void Load_Date()
        {         
            DateTime dateNows = new DateTime();
            dateNows = DateTime.Now;

            switch (SettingsHelper.TSRListTimeEntriesOutlookUserAgent)
            {
                case (int)SettingsHelper.OutlookUserAgentEnum.AsWebInterface:
                    {
                        int pastDays = SettingsHelper.TimeIntervalTimeSheetWebFrom;
                        int futureDays = SettingsHelper.TimeIntervalTimeSheetWebTo;

                        TimeSpan tSpan = new TimeSpan(pastDays, 0, 0, 0);
                        DateTime dTineStart = dateNows - tSpan;

                        dtpStartTime.Value = dTineStart;
                        dtpStartTime.Format = DateTimePickerFormat.Custom;
                        dtpStartTime.CustomFormat = Utilities.Helper.GetDateFormat();

                        dtpEndTime.Value = dateNows.AddDays(futureDays);
                        dtpEndTime.Format = DateTimePickerFormat.Custom;
                        dtpEndTime.CustomFormat = Utilities.Helper.GetDateFormat();

                        break;
                    }

                case (int)SettingsHelper.OutlookUserAgentEnum.PreviousMonth:
                {
                    DateTime firstDayOfTheMonth = new DateTime(dateNows.Year, dateNows.Month, 1);
                    firstDayOfTheMonth = firstDayOfTheMonth.AddMonths(-1);
                    DateTime lastDayOfTheMonth = firstDayOfTheMonth.AddMonths(1).AddDays(-1);
                    dtpStartTime.Value = firstDayOfTheMonth;
                    dtpEndTime.Value = lastDayOfTheMonth;

                    break;
                }

                case (int)SettingsHelper.OutlookUserAgentEnum.PreviousWeek:
                {
                    var firstDay = FirstDayOfWeek(DateTime.Today.AddDays(-6));
                    var lastDay = firstDay.AddDays(6);
                    dtpStartTime.Value = firstDay;
                    dtpEndTime.Value = lastDay;

                    break;
                }

                case (int)SettingsHelper.OutlookUserAgentEnum.CurrentWeek:
                {
                    var firstDay = FirstDayOfWeek(DateTime.Today);
                    var lastDay = firstDay.AddDays(6);
                    dtpStartTime.Value = firstDay;
                    dtpEndTime.Value = lastDay;

                    break;
                }

                case (int)SettingsHelper.OutlookUserAgentEnum.CurrentMonth:
                {
                    DateTime firstDayOfTheMonth = new DateTime(dateNows.Year, dateNows.Month, 1);
                    DateTime lastDayOfTheMonth = firstDayOfTheMonth.AddMonths(1).AddDays(-1);
                    dtpStartTime.Value = firstDayOfTheMonth;
                    dtpEndTime.Value = lastDayOfTheMonth;

                    break;
                }

                default:
                {
                    break;
                }
            }
        }

        public DateTime FirstDayOfWeek(DateTime date)
        {
            var candidateDate = date;
            while (candidateDate.DayOfWeek != DayOfWeek.Monday)
            {
                candidateDate = candidateDate.AddDays(-1);
            }
            return candidateDate;
        }

        /// <summary>
        /// Method (Event Handler)
        /// ItemList_FormClosed
        /// Handles the form closed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ItemList_FormClosed(object sender, FormClosedEventArgs e)
        {
            appInformer.UnRegister(this); //Unregister the control
            instance.Dispose(); //Free the resources
            instance = null;
        }

        /// <summary>
        /// Method (Event Handler)
        /// btnSearch_Click
        /// handles the search button clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //prepare the search parameters
            //Int64 organizationID = Convert.ToInt64(cmbOrganizations.SelectedValue);
            //Int64 projectID = Convert.ToInt64(cmbProjects.SelectedValue);
            //Int64 activityID = Convert.ToInt64(cmbActivities.SelectedValue);
            //Int64 taskID = Convert.ToInt64(cmbTasks.SelectedValue);
            //Int64 contactID = -1;
            //Int32 status = Convert.ToInt32(cmbStatus.SelectedValue);                        
            if (timer != null)
                timer.Stop();

            if (dtpStartTime.Value.Date > dtpEndTime.Value.Date)
            {
                string startDateMustBeLessThanEndDateMsg = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsg", "Start date must be less than end date");
                string startDateMustBeLessThanEndDateMsgCaption = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsgCaption", "Search Criteria");
                MessageBox.Show(startDateMustBeLessThanEndDateMsg, startDateMustBeLessThanEndDateMsgCaption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            DateTime startTime = dtpStartTime.Value.Date;
            DateTime endTime = dtpEndTime.Value.Date.AddDays(1);
            string subject = txtSubject.Text.Trim(); //.Replace(" ", "%");
            bool addPendingSubmissions = false;
            //bool pending = true;

            List<Int64> lstOrg = new List<Int64>(); // GetIDList(clbOrganizations);            
            foreach (var item in clbOrganizations.CheckedItems)
            {
                Organization org = item as Organization;
                if (org != null)
                    lstOrg.Add(org.ID);
            }

            List<Int64> lstProj = new List<Int64>(); // GetIDList(clbProjects); 
            foreach (var item in clbProjects.CheckedItems)
            {
                Project proj = item as Project;
                if (proj != null)
                    lstProj.Add(proj.ID);
            }

            List<Int64> lstAct = new List<Int64>();  //GetIDList(clbActivities);
            foreach (var item in clbActivities.CheckedItems)
            {
                Activity act = item as Activity;
                if (act != null)
                    lstAct.Add(act.ID);
            }

            List<Int64> lstTask = new List<Int64>(); //GetIDList(clbTasks);
            foreach (var item in clbTasks.CheckedItems)
            {
                Task tsk = item as Task;
                if (tsk != null)
                    lstTask.Add(tsk.ID);
            }


            List<Int64> lstContacts = new List<Int64>();

            List<Int32> lstStatus = new List<Int32>();
            Int32 stat;

            foreach (var item in clbStatus.CheckedItems)
            {
                TSR.Core.EnumListItem stata = item as TSR.Core.EnumListItem;
                if (stata != null)
                {
                    if (Int32.TryParse(stata.ID, out stat))
                    {
                        lstStatus.Add(stat);
                        if (((TSR.Core.UserAgentService.StatusEnum)stat) == TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                            addPendingSubmissions = true;

                    }
                }
                //TSR.Core.UserAgentService.StatusEnum org = item;
                //if (org != null)

            }

            Search(lstOrg, lstProj, lstAct, lstTask, lstContacts, lstStatus, subject, startTime, endTime,
                addPendingSubmissions);
            //Get the data with the search parameter
            //ucTSRItemList1.DataSource = Core.TSRFacade.GetTimeEntriesByAllParams(organizationID, projectID,
            //  activityID, taskID, contactID, status, subject, startTime, endTime, true);
            //ucTSRItemList1.DataSource = Core.TSRFacade.GetTimeEntriesByAllParams(organizationID, projectID,
            //    activityID, taskID, contactID, status, subject, true);
        }
       
        private void StartSynchronization(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID, DateTime start, DateTime end)
        {
            string message = string.Empty;

            try
            {
                appRetriever = Core.AppointmentRetriever.NewInstance();

                if (appRetriever == null)//Only one instance of syncEngine can run at a time.. singleton.. 
                //so, it must be automatic synchronization that is already using the class
                {
                    return;
                }
                appRetriever.ProgressChanged += new AppointmentRetriever.SynchronizationProgressChanged(syncEngine_ProgressChanged);
                appRetriever.Completed += new AppointmentRetriever.SynchronizationCompleted(syncEngine_Completed);
                //tmAppRetriever.Enabled = true;
                //tmAppRetriever.Start();

                timer.Interval = 1000;
                timer.Tick += new EventHandler(timer_Tick);
                timer.Start();

                appRetriever.StartSynchornization(subject,lstOrganizationID,lstProjectID,lstActivityID, start, end);                
                //LogAppend(SyncEngine.SyncStatus.Normal);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorSynchronizingWithTSRServer","Error synchronizing with TSR Server");
                MessageBox.Show(ex.Message,caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private TimeEntryList _teListForRetrievedApps = new TimeEntryList();

        void syncEngine_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.UserState != null)
            {
                AppointmentRetriever.SyncMessage progressMessage = (AppointmentRetriever.SyncMessage)e.UserState;
                //_syncStatus = progressMessage.Status;


                switch (progressMessage.Status)
                {
                    case AppointmentRetriever.SyncStatus.Normal:
                        _teListForRetrievedApps = progressMessage.UpdatedTimeEntries;                        
                        //timer_Tick(null, null);
                        //ucTSRItemList1.
                        break;
                }

            }
        }

        /// <summary>
        /// Event raised when time entry retrieval is complete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void syncEngine_Completed(object sender, RunWorkerCompletedEventArgs e)
        {
            //IsWorkInProgress = false;
            //_syncStatus = SyncEngine.SyncStatus.Completed;
            //if ((ucTSRItemList1.DataSource != null) && (ucTSRItemList1.DataSource.Count > 0))
            //    showTimeEntriesInGrid();
            //if (_teListForRetrievedApps.Count != 0)
            //    timer_Tick(null, null);
            //timer.Stop();
            //tmAppRetriever.Enabled = false;
            appRetriever = null;
            //LogAppend(SyncEngine.SyncStatus.Completed);
        }


        private void timer_Tick(object sender, EventArgs e)
        {
            if (_teListForRetrievedApps != null && _teListForRetrievedApps.QueueHasData())
            {
                TimeEntryList resultTEList = new TimeEntryList();
                if (!ckShowInvalidTE.Checked)
                    resultTEList = GetTimeEntryListWithoutInvalid(_teListForRetrievedApps.PopAllTimeEntry());
                else
                    resultTEList = _teListForRetrievedApps.PopAllTimeEntry();
                ucTSRItemList1.SetDataSource(resultTEList, true);
                ucTSRItemList1.ToggleAllSelect(chkSelectAll.Checked);
                Application.DoEvents();
            }

            if ((appRetriever == null) && (!_teListForRetrievedApps.QueueHasData()))
            {
                //LogAppend(SyncEngine.SyncStatus.Completed);
                //ucTSRItemList1.UseWaitCursor = false;
                timer.Stop();
                //Application.DoEvents();
            }
        }

        //Created by tsrdev1
        //Created date 05/08/2010
        /// <summary>
        /// This method is called when searching time entry is passed from background thread
        /// </summary>        
        /// <param name="status"></param>
        private void LogAppend(TSR.Core.SyncEngine.SyncStatus status)
        {            
            switch (status)
            {
                case SyncEngine.SyncStatus.Undefined:                    
                    this.Cursor = _DefaultCursor;                    
                    break;
                case SyncEngine.SyncStatus.Normal:                    
                    this.Cursor = Cursors.WaitCursor;
                    break;
                case SyncEngine.SyncStatus.Error:
                    this.Cursor = _DefaultCursor;
                    break;
                case SyncEngine.SyncStatus.Completed:
                    this.Cursor = _DefaultCursor;
                    break;
                case SyncEngine.SyncStatus.CompletedWithErrors:
                    this.Cursor = _DefaultCursor;
                    break;                    
            }            
        }
        /// <summary>
        /// Method to retrieve tsr entries which were not actually inserted in data store, these will be generated on the fly for
        /// view. but, if saved or changed from here, these will be saved
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        //private TimeEntryList getUnchangedRecurringOccurrences(DateTime startTime, DateTime endTime)
        //{
        //    TimeEntryList teList = new TimeEntryList();

        //    //List<Outlook.AppointmentItem> appList = getRecurringAppointmentsWithInaTimeRange(startTime, endTime);
        //    addTimeEntriesOnTheFlyForUnsavedRecurringEntries(teList, startTime, endTime);//method call to retrieve time entries on the fly

        //    return teList;
        //}

        //private List<Outlook.AppointmentItem> getRecurringAppointmentsWithInaTimeRange(DateTime startTime, DateTime endTime)
        //{
        //    List<RecurringMaster> recurringMasters = Core.TSRFacade.GetRecurringMastersWithInTimeRange(startTime, endTime);

        //    List<Outlook.AppointmentItem> appList = new List<Outlook.AppointmentItem>();

        //    foreach (RecurringMaster rm in recurringMasters)
        //    {
        //        Outlook.AppointmentItem recurApp = OutlookHelper.GetAppointmentItemByEntryID(rm.ID);
        //        if (recurApp != null)
        //            appList.Add(recurApp);
        //    }
        //    return appList;

        //    /*
        //     * NO NEED TO USE THESE, THIS CODE ONLY RETURNS MAIN SERIES APPOINTMENT ANYWAY..
            
        //    Outlook.MAPIFolder oCalendar = OutlookHelper.CurrentApplication.Session.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderCalendar);

        //    Outlook.Items oItems = (Outlook.Items)oCalendar.Items;

        //    oItems.Sort("[Start]", false);

        //    oItems.IncludeRecurrences = true;

        //    //string sCriteria = (@"[End] >= " + Quote("May 16, 2009 12:00 AM") + " AND [Start] < " + Quote("May 30, 2009 12:00 AM"));
        //    string sCriteria = "[End] >= '" + startTime + "' AND [Start] < '" + endTime + "'";
        //    //Outlook specific syntax
        //    //string sCriteria = "[Start] <= '" + endTime + "' " + "And [End] > '" + startTime + "'";

        //    Outlook.Items oRestrictedItems = oItems.Restrict(sCriteria);

        //    oRestrictedItems.Sort("[Start]", true);

        //    oRestrictedItems.IncludeRecurrences = true;



        //    Outlook.AppointmentItem oAppt;

        //    oAppt = (Outlook.AppointmentItem)oRestrictedItems.GetFirst();
        //    //for each appointment if it is recurring.. add it to list
        //    while (oAppt != null)
        //    {
        //        if (oAppt.IsRecurring)
        //            appList.Add(oAppt);                    

        //        oAppt = (Outlook.AppointmentItem)oRestrictedItems.FindNext();
        //    }
        //    return appList; 
             
        //    */

        //}


        /// <summary>
        /// this method generated time entries on the fly, which were never stored locally, and user did not
        /// create these entries one by one, these were created as part of recurring appointment, but
        /// as these were not changed specifically, all of these will be generated on the fly for viewing, and will
        /// be saved only if user individually opens an appointment and saves it
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="AppList"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        //private void addTimeEntriesOnTheFlyForUnsavedRecurringEntries(TimeEntryList teList, DateTime start, DateTime end)
        //{
        //    //foreach (Outlook.AppointmentItem oAppt in AppList)
        //    //{
        //    List<RecurringMaster> recurringMasters = Core.TSRFacade.GetRecurringMastersWithInTimeRange(start, end);


        //    foreach (RecurringMaster rm in recurringMasters)
        //    {
        //        Outlook.AppointmentItem oAppt = OutlookHelper.GetAppointmentItemByEntryID(rm.ID);
        //        if (oAppt != null)
        //        {
        //            //RecurringMaster rm = Core.TSRFacade.GetRecurringMasterByOutlookEntryID(oAppt.EntryID);
        //            //if (rm != null)
        //            //{
        //            if (oAppt.GetRecurrencePattern().PatternStartDate > start)
        //                start = oAppt.GetRecurrencePattern().PatternStartDate;
        //            if (oAppt.GetRecurrencePattern().PatternEndDate < end)
        //                end = oAppt.GetRecurrencePattern().PatternEndDate.AddDays(1);
        //            //oAppt.GetRecurrencePattern().
        //            DateTime date = start;
        //            while (date <= end) // this huge loop can be changed by retrieving information from recurrence pattern
        //            {
        //                date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);
        //                try
        //                {

        //                    Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence = oAppt.GetRecurrencePattern().GetOccurrence(date);

        //                    if (appointmentOccurrence != null)
        //                    {
        //                        //get list of recurring entries including deleted ones, if even a deleted one exists, we dont want to list it
        //                        TimeEntry te = Core.TSRFacade.GetTimeEntryForRecurringAppointment(oAppt.EntryID, appointmentOccurrence.Start, appointmentOccurrence.End, false, true);
        //                        if (te == null)
        //                        {
        //                            te = new TimeEntry(Guid.NewGuid(), appointmentOccurrence);
        //                            te.Subject = rm.Subject;
        //                            te.Body = rm.Body;
        //                            te.OrganizationID = rm.OrganizationID;
        //                            te.ProjectID = rm.ProjectID;
        //                            te.ActivityID = rm.ActivityID;
        //                            //date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);
        //                            te.StartTimeStamp = appointmentOccurrence.Start;
        //                            te.EndTimeStamp = appointmentOccurrence.End;//new DateTime(date.Year, date.Month, date.Day, oAppt.End.Hour, oAppt.End.Minute, oAppt.End.Second);//oAppt.End;

        //                            te.Organization = Core.TSRFacade.GetOrganizationByID(rm.OrganizationID);
        //                            te.Project = Core.TSRFacade.GetProjectByID(rm.ProjectID);
        //                            te.Activity = Core.TSRFacade.GetActivityByID(rm.ActivityID);
        //                            te.IsRecurring = true;
        //                            teList.Add(te);
        //                        }
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    TSR.Core.Logging.LoggingHandler.LogError(ex);
        //                }
        //                date = date.AddDays(1);
        //            }
        //            //}
        //        }
        //    }


        //    //}

        //}

        private List<Int64> GetIDList(CheckedListBox clb)
        {
            List<Int64> lstIds = new List<Int64>();
            foreach (var item in clb.CheckedItems)
            {
                BaseEntity entity = item as BaseEntity;
                if (entity != null)
                    lstIds.Add(entity.ID);
            }
            return lstIds;
        }

        /// <summary>
        /// Method (Event Handler)
        /// btnReset_Click
        /// handles the reset button clicked event
        /// Takes the input controls for search at initial state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSubject.Text = "";            
            Load_Date();
            //dtpEndTime.Value = DateTime.Now;
            PopulateActivityCombo(new List<long>());
            PopulateProjectCombo(new List<long>());
            chkAllOrg.Checked = chkAllProj.Checked = chkAllActs.Checked = chkAllStatus.Checked = false;
            toggleCheckBoxes(clbOrganizations, false);
            toggleCheckBoxes(clbProjects, false);
            toggleCheckBoxes(clbActivities, false);
            toggleCheckBoxes(clbStatus, false);
            InitializeComboBoxes();
            //ucTSRItemList1.DataSource = Core.TSRFacade.GetAllTimeEntries(true);
        }

        /// <summary>
        /// Method (Event Handler)
        /// btnCancel_Click
        /// handles the cancle button clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            CloseWindow();
        }

        /// <summary>
        /// Method (Event Handler)
        /// btnSubmit_Click
        /// handles submit button clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var countLockPeriod = 0;
            var countIsDurationWarning = 0;
            try
            {
                //Feature 370
                foreach (Entity.TimeEntry obj in ucTSRItemList1.CheckedTimeEntries)
                {
                    var duration = (obj.EndTimeStamp - obj.StartTimeStamp).TotalMinutes;
                    if (Core.TSRFacade.IsDurationWarning(duration))
                        countIsDurationWarning += 1;
                }

                if (countIsDurationWarning > 0)
                {
                    var setting = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_DURATION_WARNING);
                    var message = String.Format(Core.ResourceManager.GetResourceString("DurationWarningMessage", "This appointment is longer than {0}. Do you want to continue?"), setting);
                    if (MessageBox.Show(message, "", MessageBoxButtons.YesNo) != DialogResult.Yes)
                    {
                        return;
                    }
                }

                foreach (Entity.TimeEntry obj in ucTSRItemList1.CheckedTimeEntries)
                {
                    //Feature 340
                    if (Core.TSRFacade.IsLockPeriod(obj.StartTimeStamp))
                    {
                        countLockPeriod += 1;

                        continue;
                    }

                    obj.Status = TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue;
                    //obj.SubmitterName = Core.MiscHelper.GetCurrentUsername();
                    obj.SubmitterName = Core.TSRFacade.GetNONADUserName();
                    Core.TSRFacade.UpdateTimeEntry(obj);
                    Microsoft.Office.Interop.Outlook.AppointmentItem appointItem = null;
                    try
                    {
                        appointItem = obj.OLAppointmentItem;
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogError(ex);
                    }
                    if (appointItem != null && !appointItem.IsRecurring)
                    {
                        OutlookHelper.CreateCategoriesForTSREntry();
                        appointItem.Categories = OutlookHelper.SetTSRCategory(appointItem.Categories, obj.Status);
                        appointItem.Save();
                    }
                    //listTemp.Add(obj);
                }

                if (countLockPeriod > 0)
                {
                    MessageBox.Show(ResourceManager.GetResourceString("SubmitMessageInMatrixView", "Submit and lock completed and there are some time entries cannot submit in lock period. Please contact administrator to unlock period and submit again."));
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorUpdatingTimeEntry","Error updating time entry");
                MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //DataGridViewCheckBoxCell cell;
            //foreach (DataGridViewRow dgvRow in dgvItems.Rows)
            //{
            //    cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
            //    if (cell != null && Convert.ToBoolean(cell.Value))
            //    {
            //        Entity.TimeEntry obj = dgvRow.DataBoundItem as Entity.TimeEntry;
            //        obj.Status = TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue;
            //        Core.TSRFacade.UpdateTimeEntry(obj);
            //    }
            //}

            btnSearch_Click(null, null);
            //ucTSRItemList1.UpdateRows(listTemp);

        }

        /// <summary>
        /// Method (Event Handler)
        /// chkSelectAll_CheckedChanged
        /// check the selected event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            ucTSRItemList1.ToggleAllSelect(chkSelectAll.Checked);
        }

        #endregion

        #region UI Actions

        /// <summary>
        /// Method
        /// PopulateAllControls
        /// populates the controls in the form
        /// </summary>
        private void PopulateAllControls()
        {
            PopulateLocalizedTextFromResource();
            InitializeComboBoxes();
            PopulateItemsInGrid();
        }

        #region UI Actions - Update Combos

        private void UpdateOrganizationsLowerCombos()
        {
            //if (cmbOrganizations.SelectedIndex != 0)
            //{
            //    long OrgID = 0;
            //    bool isValidValue = long.TryParse(cmbOrganizations.SelectedValue.ToString(), out OrgID);
            //    if (isValidValue)
            //    {
            //        PopulateProjectCombo(OrgID);
            //    }
            //}

            //UpdateActivitysLowerComboes();
        }



        #endregion

        #region UI Actions - Populate Combos

        /// <summary>
        /// Method
        /// PopulateComboBoxes
        /// populates the combo boxe
        /// </summary>
        private void InitializeComboBoxes()
        {
            PopulateOrganizationCombo();
            //PopulateProjectCombo(-1);
            //PopulateActivityCombo(-1);
            //PopulateTaskCombo(-1);
            PopulateStatusCombo();
        }

        /// <summary>
        /// method 
        /// PopulateOrganizationCombo
        /// populates the organization combo box
        /// </summary>
        private void PopulateOrganizationCombo()
        {
            try
            {
                Entity.OrganizationList organizationList = Core.TSRFacade.GetAllOrganizations();
                //organizationList.InsertSelectionDefaultItem();

                UIHelper.FillCheckedListBox(clbOrganizations, organizationList, Entity.Organization.Property_Name, Entity.Organization.Property_ID, null, true);
                //UIHelper.FillComboBox(cmbOrganizations, organizationList, Entity.Organization.COL_NAME, Entity.Organization.COL_ID);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorGettingOrganizations", "Error getting organizations");
                MessageBox.Show(ex.Message,caption , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// method
        /// PopulateProjectCombo
        /// populates project combo box
        /// </summary>
        /// <param name="organizationID"></param>
        private void PopulateProjectCombo(long organizationID)
        {
            Entity.ProjectList projectList;
            if (organizationID == -1)
                projectList = Core.TSRFacade.GetAllProjects();
            else
            {
                try
                {
                    projectList = Core.TSRFacade.GetProjectsForOrganization(organizationID);
                }
                catch (Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                    string caption = ResourceManager.GetResourceString("ErrorGettingProjectsForOrganization", "Error getting projects for organization");
                    MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);                    
                    return;
                }
            }
            //projectList.InsertSelectionDefaultItem();
            UIHelper.FillCheckedListBox(clbProjects, projectList, Entity.Project.Property_Name, Entity.Project.Property_ID, null, true);
            //UIHelper.FillComboBox(cmbProjects, projectList, Entity.Project.COL_NAME, Entity.Project.COL_ID);
        }

        /// <summary>
        /// populates project list, if organization ids are passed, 
        /// projects will be populated depending on the list of organizations
        /// </summary>
        /// <param name="organizationIDs"></param>
        private void PopulateProjectCombo(List<long> organizationIDs)
        {
            Entity.ProjectList projectList;
            try
            {
                projectList = Core.TSRFacade.GetProjectsForMultipleOrganizations(organizationIDs);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorGettingProjectsForMultiOrganization", "Error getting projects for multi-organization");
                MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //projectList.InsertSelectionDefaultItem();
            UIHelper.FillCheckedListBox(clbProjects, projectList, Entity.Project.Property_Name, Entity.Project.Property_ID, null, true);
            //UIHelper.FillComboBox(cmbProjects, projectList, Entity.Project.COL_NAME, Entity.Project.COL_ID);
        }

        /// <summary>
        /// Method 
        /// PopulateActivityCombo
        /// Populates Activity combo box
        /// </summary>
        /// <param name="projectID"></param>
        private void PopulateActivityCombo(long projectID)
        {
            Entity.ActivityList activityList;

            if (projectID == -1)
                activityList = Core.TSRFacade.GetAllActivities();
            else
            {
                try
                {
                    activityList = Core.TSRFacade.GetActivitiesForProject(projectID);
                }
                catch (Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                    string caption = ResourceManager.GetResourceString("ErrorGettingActivitiesForProject",
                       "Error getting activities for project" );
                    MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            //activityList.InsertSelectionDefaultItem();

            UIHelper.FillCheckedListBox(clbActivities, activityList, Entity.Activity.Property_Name, Entity.Activity.Property_ID, null, true);
            //UIHelper.FillComboBox(cmbActivities, activityList, Entity.Activity.COL_NAME, Entity.Activity.COL_ID);
        }


        /// <summary>
        /// populates activity list.
        /// </summary>
        /// <param name="projectIDs"></param>
        private void PopulateActivityCombo(List<long> projectIDs)
        {
            Entity.ActivityList activityList;
            try
            {
                activityList = Core.TSRFacade.GetActivitiesForMultipleProjects(projectIDs);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorGettingActivitiesForMultiProject"
                    ,"Error getting activities for multi-project");
                MessageBox.Show(ex.Message,caption , MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //activityList.InsertSelectionDefaultItem();

            UIHelper.FillCheckedListBox(clbActivities, activityList, Entity.Activity.Property_Name, Entity.Activity.Property_ID, null, true);
            //UIHelper.FillComboBox(cmbActivities, activityList, Entity.Activity.COL_NAME, Entity.Activity.COL_ID);
        }


        /// <summary>
        /// Method
        /// PopulateTaskCombo
        /// Populates Task Combo Box
        /// </summary>
        /// <param name="activityID"></param>
        private void PopulateTaskCombo(long activityID)
        {
            Entity.TaskList taskList;

            taskList = Core.TSRFacade.GetAllTasks();
            taskList.InsertSelectionDefaultItem();

            //UIHelper.FillComboBox(cmbTasks, taskList, Entity.Task.COL_NAME, Entity.Task.COL_ID);
        }

        /// <summary>
        /// Method 
        /// PopulateStatusCombo
        /// populate Status ComboBox
        /// </summary>
        private void PopulateStatusCombo()
        {
            List<EnumListItem> list = new List<EnumListItem>();

            list.Add(new EnumListItem 
            { 
                ID = ((int)TSR.Core.UserAgentService.StatusEnum.PendingSubmission).ToString(), 
                Name = EnumHelper.ProcessEnumString(TSR.Core.UserAgentService.StatusEnum.PendingSubmission.ToString()) 
            });
            list.Add(new EnumListItem
            {
                ID = ((int)TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue).ToString(),
                Name = EnumHelper.ProcessEnumString(TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue.ToString())
            });
            list.Add(new EnumListItem 
            { 
                ID = ((int)TSR.Core.UserAgentService.StatusEnum.InProgress).ToString(), 
                Name = EnumHelper.ProcessEnumString(TSR.Core.UserAgentService.StatusEnum.InProgress.ToString()) 
            });
            list.Add(new EnumListItem 
            { 
                ID = ((int)TSR.Core.UserAgentService.StatusEnum.Approved).ToString(), 
                Name = EnumHelper.ProcessEnumString(TSR.Core.UserAgentService.StatusEnum.Approved.ToString()) 
            });
            list.Add(new EnumListItem 
            { 
                ID = ((int)TSR.Core.UserAgentService.StatusEnum.Rejected).ToString(), 
                Name = EnumHelper.ProcessEnumString(TSR.Core.UserAgentService.StatusEnum.Rejected.ToString()) 
            });

            UIHelper.FillCheckedListBox(clbStatus, list, Core.EnumListItem.COL_NAME, Core.EnumListItem.COL_ID, null, true);
            //UIHelper.FillCheckedListBoxWithEnum(clbStatus, typeof(TSR.Core.UserAgentService.StatusEnum));
            //UIHelper.FillComboWithEnum(cmbStatus, typeof(TSR.Core.UserAgentService.StatusEnum), Core.ResourceHelper.StatusSelectionText);
        }

        #endregion

        #region UI Actions - GridView - Prepare Grid

        /// <summary>
        /// Method
        /// PopulateItemsInGrid
        /// Populates the grid view with data
        /// </summary>
        private void PopulateItemsInGrid()
        {
            //ucTSRItemList1.DataSource = Core.TSRFacade.GetAllTimeEntries(true);
            btnSearch_Click(this, EventArgs.Empty);
        }

        #endregion


        /// <summary>
        /// Method
        /// OLAppointmentItem_Unload
        /// Unloads the OL Appointment
        /// </summary>
        void OLAppointmentItem_Unload()
        {
            btnSearch_Click(this, EventArgs.Empty);
        }

        /// <summary>
        /// Method
        /// OLAppointmentItem_Write
        /// OL Appointment Writer
        /// </summary>
        /// <param name="Cancel"></param>
        void OLAppointmentItem_Write(ref bool Cancel)
        {
            btnSearch_Click(this, EventArgs.Empty);
            //obj.OLAppointmentItem.Write -= new Outlook.ItemEvents_10_WriteEventHandler(OLAppointmentItem_Write);
        }

        /// <summary>
        /// Method
        /// PopulateLocalizedTextFromResource
        /// Gets the localized text from resource to populate
        /// </summary>
        private void PopulateLocalizedTextFromResource()
        {
            this.Text = Core.ResourceHelper.ItemsFormHeadingText;
            lblSubject.Text = Core.ResourceHelper.Subject;
            lblProject.Text = Core.ResourceHelper.Project;
            lblOrganization.Text = Core.ResourceHelper.Organization;
            lblActivity.Text = Core.ResourceHelper.Activity;
            lblTask.Text = Core.ResourceHelper.Task;
            lblStartTime.Text = Core.ResourceHelper.StartTime;
            lblEndTime.Text = Core.ResourceHelper.EndTime;
            lblStatus.Text = Core.ResourceHelper.Status;
            lblTotalDurationSelectedText.Text = Core.ResourceHelper.lblTotalDurationSelectedText +":";
            lblTotalDurationText.Text = Core.ResourceHelper.lblTotalDurationText + ":";
            btnPrevious7Days.Text = Core.ResourceHelper.Previous7Days;
            btnNext7Days.Text = Core.ResourceHelper.Next7Days;

            lblTemplateMissing.Text = ResourceManager.GetResourceString("InvalidTimeEntries", "Time entries are invalid");
            //lblOldDBData.Text = ResourceManager.GetResourceString("OldDataTemplate","Items do not exist in current database");
            //lblRecurringTE.Text = ResourceManager.GetResourceString("RecurringAppointmentTemplate", "Items is recurring appointments");

            btnDelete.Text = Core.ResourceHelper.DeleteButtonText;
            btnSearch.Text = Core.ResourceHelper.Search;
            btnReset.Text = Core.ResourceHelper.Reset;
            btnSubmit.Text = Core.ResourceHelper.Submit;
            btnCancel.Text = Core.ResourceHelper.Cancel;
            chkSelectAll.Text = Core.ResourceHelper.SelectAll;
            chkAllOrg.Text = Core.ResourceHelper.SelectAll;
            chkAllProj.Text = Core.ResourceHelper.SelectAll;
            chkAllActs.Text = Core.ResourceHelper.SelectAll;
            chkAllStatus.Text = Core.ResourceHelper.SelectAll;
            grpSearch.Text = Core.ResourceHelper.SearchItems;
            ckShowInvalidTE.Text = ResourceManager.GetResourceString("ShowInvalidTimeEntryText", "Show invalid time entry");
            lblIsCreatedViaWeb.Text = ResourceHelper.IsCreatedViaWeb;
        }

        /// <summary>
        /// Method
        /// CloseWindow
        /// Closes Window
        /// </summary>
        private void CloseWindow()
        {
            this.Close();
            this.Dispose();
        }
        #endregion

        #region IAppointmentObserver Members

        public void Notify(object anObject)
        {
            btnSearch_Click(this, null);
        }

        #endregion

        #region Filter Data
        private TimeEntryList GetTimeEntryListWithoutInvalid(TimeEntryList list)
        {
            TimeEntryList listResult = new TimeEntryList();
            foreach (TimeEntry te in list)
            {
                if (Core.TimeEntryHelper.GetTimeEntryType(te) == TimeEntryType.Valid)
                    listResult.Add(te);
            }
            return listResult;
        }
        #endregion
        /// <summary>
        /// Method (Event Handler)
        /// cmbOrganizations_SelectedIndexChanged
        /// takes necessary steps when the combo box
        /// Organization's selectd index changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void cmbOrganizations_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    long orgId;
        //    if (long.TryParse(cmbOrganizations.SelectedValue.ToString(), out orgId))
        //    {
        //        PopulateProjectCombo(orgId);
        //    }
        //}

        /// <summary>
        /// Method
        /// cmbProjects_SelectedIndexChanged
        /// akes necessary steps when the combo box
        /// Project's selectd index changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void cmbProjects_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    long projId;
        //    if (long.TryParse(cmbOrganizations.SelectedValue.ToString(), out projId))
        //    {
        //        PopulateActivityCombo(projId);
        //    }
        //}

        /// <summary>
        /// Method (Event Handler)
        /// btnDelete_Click
        /// handles the event when delete button is pressed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {            
            //foreach (Entity.TimeEntry obj in ucTSRItemList1.CheckedTimeEntries)
            //{
            //    if (TSRExpenseFacade.GetExpenseSheetByTimeEntryID(obj.ID) != null)
            //    {
            //        string caption = ResourceManager.GetResourceString("TimeSheetDeleteFailureMessageBecauseExpenses", "Time entries  with expenses cannot be deleted");
            //        MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        return;
            //    }
            //}
            //TimeEntryList listTemp = new TimeEntryList();
            //Perform the delete
            bool isExistingTimesHasExpenses = false;

            foreach (Entity.TimeEntry obj in ucTSRItemList1.CheckedTimeEntries)
            {
                if (obj.IsChangeAllowed())
                {
                    //checking if the time entry has expenses.
                    if (TSRExpenseFacade.GetExpenseSheetByTimeEntryID(obj.ID) != null)
                    {
                        isExistingTimesHasExpenses = true;
                        continue;
                    }

                    try
                    {
                        Core.TSRFacade.DeleteTimeEntry(obj);
                        //listTemp.Add(obj);
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogError(ex);
                        string caption = ResourceManager.GetResourceString("ErrorDeletingTimeEntry",
                            "Error deleting time entry");
                        MessageBox.Show(ex.Message,caption , MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }
                    //if ((deleteAppointments) && (obj.OLAppointmentItem != null))
                    //    obj.OLAppointmentItem.Delete(); //delete the appointments if selected
                }
            }
            if (isExistingTimesHasExpenses)
            {                
                MessageBox.Show(ResourceManager.GetResourceString("TimeSheetDeleteFailureMessageBecauseExpenses", "Time entries  with expenses cannot be deleted"), "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //ucTSRItemList1.DeleteRows(listTemp);
            btnSearch_Click(null, null);
        }

        private void clbOrganizations_SelectedIndexChanged(object sender, EventArgs e)
        {
            //AdjustProjectList();
            
            
            
            //DeselectSelectAllCheckBox(clbOrganizations, chkAllOrg);
            
            
            //return;


            //long orgId;
            //if (long.TryParse(clbOrganizations.SelectedValue.ToString(), out orgId))
            //{
            //    PopulateProjectCombo(orgId);
            //}
        }

        private void AdjustProjectList()
        {
            List<Int64> lstOrgs = new List<Int64>();  //GetIDList(clbActivities);
            foreach (var item in clbOrganizations.CheckedItems)
            {
                Organization org = item as Organization;
                if (org != null)
                    lstOrgs.Add(org.ID);
            }

            PopulateProjectCombo(lstOrgs);
        }

        private void clbProjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            //long projId;

            //DeselectSelectAllCheckBox(clbProjects, chkAllProj);
            //AdjustActivityList();
            //return;


            //if (long.TryParse(clbProjects.SelectedValue.ToString(), out projId))
            //{
            //    PopulateActivityCombo(projId);
            //}

        }

        private void AdjustActivityList()
        {
            List<Int64> lstProj = new List<Int64>();  //GetIDList(clbActivities);
            foreach (var item in clbProjects.CheckedItems)
            {
                Project proj = item as Project;
                if (proj != null)
                    lstProj.Add(proj.ID);
            }

            PopulateActivityCombo(lstProj);
        }

        private void clbProjects_DoubleClick(object sender, EventArgs e)
        {
            AdjustActivityList();
        }

        private void clbOrganizations_DoubleClick(object sender, EventArgs e)
        {
            AdjustProjectList();
        }
        
        /// <summary>
        /// select all checkbox for organization was checked, so adjust all the appropriate selections for organization and projects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkAllOrg_CheckedChanged(object sender, EventArgs e)
        {
            //if (enforceChkallOrg)
            //{
            //    enforceChkallOrg = false;
            //    return;
            //}

            //toggleCheckBoxes(clbOrganizations, chkAllOrg.Checked);

            ////_chkAllOrg = !_chkAllOrg;
            //if (chkAllOrg.Checked == false)
            //{
            //    chkAllProj.Checked = false;
            //}
            //AdjustProjectList();
           
        }

        private void toggleCheckBoxes(CheckedListBox clb, bool check)
        {
            for (int i = 0; i < clb.Items.Count; i++)
            {
                clb.SetItemChecked(i, check);
            }
        }

        private void DeselectSelectAllCheckBox(CheckedListBox clb, CheckBox cb)
        {
            if ((clb.CheckedItems.Count != clb.Items.Count)||
                ((clb.CheckedItems.Count == clb.Items.Count) && (clb.CheckedItems.Count == 0)))
                cb.Checked = false;
        }

        /// <summary>
        /// select all check box was clicked, so adjust all checkboxes in project list and activity list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkAllProj_CheckedChanged(object sender, EventArgs e)
        {
            //toggleCheckBoxes(clbProjects, chkAllProj.Checked);
            ////for (int i = 0; i < clbProjects.Items.Count; i++)
            ////{
            ////    clbProjects.SetItemChecked(i, _chkAllProj);
            ////}
            ////_chkAllProj = !_chkAllProj;
            //if (chkAllProj.Checked == false)
            //{
            //    chkAllActs.Checked = false;
            //}
            //AdjustActivityList();
        }

        /// <summary>
        /// select all check box was clicked, so adjust all checkboxes in activity list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkAllActs_CheckedChanged(object sender, EventArgs e)
        {
            //toggleCheckBoxes(clbActivities, chkAllActs.Checked);
            
        }

        private void chkAllStatus_CheckedChanged(object sender, EventArgs e)
        {
            //for (int i = 0; i < clbStatus.Items.Count; i++)
            //{
            //    clbStatus.SetItemChecked(i, chkAllStatus.Checked);
            //}
            //_chkAllStatus = !_chkAllStatus;
        }

        private void clbOrganizations_MouseUp(object sender, MouseEventArgs e)
        {
            DeselectSelectAllCheckBox(clbOrganizations, chkAllOrg);
            AdjustProjectList();

            DeselectSelectAllCheckBox(clbProjects, chkAllProj);
            AdjustActivityList();

            DeselectSelectAllCheckBox(clbActivities, chkAllActs);
        }

        private void chkAllOrg_MouseUp(object sender, MouseEventArgs e)
        {
            toggleCheckBoxes(clbOrganizations, chkAllOrg.Checked);
            if (chkAllOrg.Checked == false)
            {
                chkAllProj.Checked = false;
                chkAllActs.Checked = false;
            }
            AdjustProjectList();
            AdjustActivityList();
        }

        private void chkAllProj_MouseUp(object sender, MouseEventArgs e)
        {
            toggleCheckBoxes(clbProjects, chkAllProj.Checked);
            //for (int i = 0; i < clbProjects.Items.Count; i++)
            //{
            //    clbProjects.SetItemChecked(i, _chkAllProj);
            //}
            //_chkAllProj = !_chkAllProj;
            if (chkAllProj.Checked == false)
            {
                chkAllActs.Checked = false;
            }
            AdjustActivityList();
        }

        private void clbProjects_MouseUp(object sender, MouseEventArgs e)
        {
            DeselectSelectAllCheckBox(clbProjects, chkAllProj);
            AdjustActivityList();

            DeselectSelectAllCheckBox(clbActivities, chkAllActs);
            //DeselectSelectAllCheckBox(clbProjects, chkAllProj);
            //AdjustActivityList();
        }

        private void chkAllActs_MouseUp(object sender, MouseEventArgs e)
        {
            toggleCheckBoxes(clbActivities, chkAllActs.Checked);
        }

        private void clbActivities_MouseUp(object sender, MouseEventArgs e)
        {
            DeselectSelectAllCheckBox(clbActivities, chkAllActs);
        }

        private void clbActivities_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DeselectSelectAllCheckBox(clbActivities, chkAllActs);
        }

        private void clbStatus_MouseUp(object sender, MouseEventArgs e)
        {
            DeselectSelectAllCheckBox(clbStatus, chkAllStatus);
        }

        private void chkAllStatus_MouseUp(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < clbStatus.Items.Count; i++)
            {
                clbStatus.SetItemChecked(i, chkAllStatus.Checked);
            }
        }

        private void ckShowInvalidTE_CheckedChanged(object sender, EventArgs e)
        {
            btnSearch_Click(null, null);
        }

        private void btnPrevious7Days_Click(object sender, EventArgs e)
        {
            if (timer != null)
                timer.Stop();

            if (dtpStartTime.Value.Date > dtpEndTime.Value.Date)
            {
                string startDateMustBeLessThanEndDateMsg = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsg", "Start date must be less than end date");
                string startDateMustBeLessThanEndDateMsgCaption = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsgCaption", "Search Criteria");
                MessageBox.Show(startDateMustBeLessThanEndDateMsg, startDateMustBeLessThanEndDateMsgCaption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            DateTime startTime = dtpStartTime.Value.Date;
            DateTime endTime = dtpEndTime.Value.Date.AddDays(1);
            string subject = txtSubject.Text.Trim(); //.Replace(" ", "%");
            bool addPendingSubmissions = false;
            //bool pending = true;

            List<Int64> lstOrg = new List<Int64>(); // GetIDList(clbOrganizations);            
            foreach (var item in clbOrganizations.CheckedItems)
            {
                Organization org = item as Organization;
                if (org != null)
                    lstOrg.Add(org.ID);
            }

            List<Int64> lstProj = new List<Int64>(); // GetIDList(clbProjects); 
            foreach (var item in clbProjects.CheckedItems)
            {
                Project proj = item as Project;
                if (proj != null)
                    lstProj.Add(proj.ID);
            }

            List<Int64> lstAct = new List<Int64>();  //GetIDList(clbActivities);
            foreach (var item in clbActivities.CheckedItems)
            {
                Activity act = item as Activity;
                if (act != null)
                    lstAct.Add(act.ID);
            }

            List<Int64> lstTask = new List<Int64>(); //GetIDList(clbTasks);
            foreach (var item in clbTasks.CheckedItems)
            {
                Task tsk = item as Task;
                if (tsk != null)
                    lstTask.Add(tsk.ID);
            }


            List<Int64> lstContacts = new List<Int64>();

            List<Int32> lstStatus = new List<Int32>();
            Int32 stat;

            foreach (var item in clbStatus.CheckedItems)
            {
                TSR.Core.EnumListItem stata = item as TSR.Core.EnumListItem;
                if (stata != null)
                {
                    if (Int32.TryParse(stata.ID, out stat))
                    {
                        lstStatus.Add(stat);
                        if (((TSR.Core.UserAgentService.StatusEnum)stat) == TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                            addPendingSubmissions = true;

                    }
                }
                //TSR.Core.UserAgentService.StatusEnum org = item;
                //if (org != null)

            }
            dtpStartTime.Value = startTime.AddDays(-7);
            dtpEndTime.Value = startTime.AddDays(-1);

            Search(lstProj, lstProj, lstAct, lstTask, lstContacts, lstStatus, subject, startTime.AddDays(-7), startTime, addPendingSubmissions);
        }

        private void btnNext7Days_Click(object sender, EventArgs e)
        {
            if (timer != null)
                timer.Stop();

            if (dtpStartTime.Value.Date > dtpEndTime.Value.Date)
            {
                string startDateMustBeLessThanEndDateMsg = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsg", "Start date must be less than end date");
                string startDateMustBeLessThanEndDateMsgCaption = Core.ResourceManager.GetResourceString("StartDateMustBeLessThanEndDateMsgCaption", "Search Criteria");
                MessageBox.Show(startDateMustBeLessThanEndDateMsg, startDateMustBeLessThanEndDateMsgCaption, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            DateTime startTime = dtpStartTime.Value.Date;
            DateTime endTime = dtpEndTime.Value.Date.AddDays(1);
            string subject = txtSubject.Text.Trim(); //.Replace(" ", "%");
            bool addPendingSubmissions = false;
            //bool pending = true;

            List<Int64> lstOrg = new List<Int64>(); // GetIDList(clbOrganizations);            
            foreach (var item in clbOrganizations.CheckedItems)
            {
                Organization org = item as Organization;
                if (org != null)
                    lstOrg.Add(org.ID);
            }

            List<Int64> lstProj = new List<Int64>(); // GetIDList(clbProjects); 
            foreach (var item in clbProjects.CheckedItems)
            {
                Project proj = item as Project;
                if (proj != null)
                    lstProj.Add(proj.ID);
            }

            List<Int64> lstAct = new List<Int64>();  //GetIDList(clbActivities);
            foreach (var item in clbActivities.CheckedItems)
            {
                Activity act = item as Activity;
                if (act != null)
                    lstAct.Add(act.ID);
            }

            List<Int64> lstTask = new List<Int64>(); //GetIDList(clbTasks);
            foreach (var item in clbTasks.CheckedItems)
            {
                Task tsk = item as Task;
                if (tsk != null)
                    lstTask.Add(tsk.ID);
            }


            List<Int64> lstContacts = new List<Int64>();

            List<Int32> lstStatus = new List<Int32>();
            Int32 stat;

            foreach (var item in clbStatus.CheckedItems)
            {
                TSR.Core.EnumListItem stata = item as TSR.Core.EnumListItem;
                if (stata != null)
                {
                    if (Int32.TryParse(stata.ID, out stat))
                    {
                        lstStatus.Add(stat);
                        if (((TSR.Core.UserAgentService.StatusEnum)stat) == TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                            addPendingSubmissions = true;

                    }
                }
                //TSR.Core.UserAgentService.StatusEnum org = item;
                //if (org != null)

            }
            dtpStartTime.Value = endTime;
            dtpEndTime.Value = endTime.AddDays(6);

            Search(lstProj, lstProj, lstAct, lstTask, lstContacts, lstStatus, subject, endTime, endTime.AddDays(7), addPendingSubmissions);
        }

        private void Search(List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
            List<Int64> lstTaskID, List<Int64> lstContactID, List<Int32> lstStatus, string subject, DateTime startTime, DateTime endTime, bool addPendingSubmissions)
        {
        
            TimeEntryList teFilter = null;
            try
            {
                //Get the data with the search parameter
                if (TSR.Core.TSRFacade.GetExchangeMode())
                {
                    teFromLocalStorage = Core.TSRFacade.GetTimeEntriesByAllParamsForCurrentCalendarFolder(lstOrganizationID, lstProjectID,
                        lstActivityID, lstTaskID, lstContactID, lstStatus, subject, startTime, endTime, true);
                }
                else
                {
                    teFromLocalStorage = Core.TSRFacade.GetTimeEntriesByAllParams(lstOrganizationID, lstProjectID,
                        lstActivityID, lstTaskID, lstContactID, lstStatus, subject, startTime, endTime, true);
                }
                if (teFromLocalStorage != null)
                {
                    if (!(ckShowInvalidTE.Checked))
                        teFilter = GetTimeEntryListWithoutInvalid(teFromLocalStorage);
                    else
                        teFilter = teFromLocalStorage;
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string caption = ResourceManager.GetResourceString("ErrorGettingTimeEntry", "Error getting time entries");
                MessageBox.Show(ex.Message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //populate list with recurring appointment's tsr items where nothing was actively changed by user
            TimeEntryList teList = new TimeEntryList();
            if ((lstStatus.Count == 0) || addPendingSubmissions)
            {
                StartSynchronization(subject, lstOrganizationID, lstProjectID,
                lstActivityID, startTime, endTime);
                //teList = getUnchangedRecurringOccurrences(startTime, endTime);
            }
            if (teFilter != null)
                teList.AddRange(teFilter);

            if (teList.Any())
            {
                foreach (var timeEntry in teList)
                {
                    double duration = (timeEntry.EndTimeStamp - timeEntry.StartTimeStamp).TotalHours;
                    timeEntry.Duration = Math.Round(duration, 2).ToString("F2");
                }
            }
            lblTotalDurationValue.Text = teList.Sum(x => double.Parse(x.Duration)).ToString("F2");

            ucTSRItemList1.DataSource = teList;
            ucTSRItemList1.ToggleAllSelect(chkSelectAll.Checked);
        }
    }
}