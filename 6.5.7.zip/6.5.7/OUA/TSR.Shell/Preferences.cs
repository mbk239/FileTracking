using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using TSR.Shell;
using Entity = TSR.Core.Entity;
using Core = TSR.Core;

using TSRDataSet = TSR.Core.TSRDataSet;
using System.Diagnostics;

namespace TSR.Shell
{
    /// <summary>
    /// Partial Class
    /// Preferences
    /// Screen for setting preferred paths
    /// </summary>
    public partial class Preferences : Controls.OUAForm
    {

        #region Variables
        private Entity.PreferredPathsList preferredPathsList = null;
        private Entity.PreferredPathsList prePreferredPathsList = null;
        private static Preferences instance = null;

        #endregion

        #region Properties

        /// <summary>
        /// Property
        /// Organization
        /// this property gets the value of 
        /// TSR.Core.ResourceHelper.Organization
        /// </summary>
        private string Organization
        {
            get
            {
                return TSR.Core.ResourceHelper.Organization;
            }
        }

        /// <summary>
        /// Property 
        /// Project
        /// gets the value of TSR.Core.ResourceHelper.Project
        /// </summary>
        private string Project
        {
            get
            {
                return TSR.Core.ResourceHelper.Project;
            }
        }

        /// <summary>
        /// Property 
        /// Default
        /// gets the value of 
        /// TSR.Core.ResourceHelper.Default
        /// </summary>
        private string Default
        {
            get
            {
                return TSR.Core.ResourceHelper.DefaultGridColumnHeaderText;
            }
        }

        /// <summary>
        /// property
        /// Activity
        /// gets the value of
        /// TSR.Core.ResourceHelper.Avtivity
        /// </summary>
        private string Activity
        {
            get
            {
                return TSR.Core.ResourceHelper.Activity;
            }
        }

        /// <summary>
        /// property 
        /// HasInstance
        /// checks if instance is null
        /// </summary>
        public static bool HasInstance
        {
            get { return (instance != null); }
        }


        #endregion

        #region Messages

        /// <summary>
        /// Property 
        /// OrgNotAvailableMsg
        /// gets the message for Organization not Available dialogue
        /// </summary>
        private string OrgNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.OrgNotAvailableMsg;
            }
        }

        /// <summary>
        /// property 
        /// ProjectNotAvailableMsg
        /// gets the message for 
        /// project not available dialogue 
        /// </summary>
        private string ProjectNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.ProjectNotAvailableMsg;
            }
        }

        /// <summary>
        /// property 
        /// ActivityNotAvailableMsg
        /// gets the message for
        /// Activity not available dialogue
        /// </summary>
        private string ActivityNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.ActivityNotAvailableMsg;
            }
        }

        /// <summary>
        /// property
        /// InfomationAlreadyExistInGridMsg
        /// gets the message for 
        /// information already exist in grid dialogue
        /// </summary>
        private string InfomationAlreadyExistInGridMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.InfomationAlreadyExistInGridMsg;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Method (Singletone pattern)
        /// GetInstance
        /// gets the instance of this class
        /// </summary>
        /// <returns>
        /// Preferences
        /// an instance
        /// </returns>
        public static Preferences GetInstance()
        {
            if (instance == null)
            {
                instance = new Preferences();

            }

            return instance;
        }

        /// <summary>
        /// The constructor
        /// </summary>
        public Preferences()
        {
            InitializeComponent();
        }
        #endregion

        #region Form Loading


        /// <summary>
        /// Method
        /// TSRPreferences_Load
        /// the method is invoked when 
        /// the form is loaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TSRPreferences_Load(object sender, EventArgs e)
        {
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            Init();
            //FormClosing += new FormClosingEventHandler(TSRPreferences_FormClosing);
            FormClosed += new FormClosedEventHandler(Preferences_FormClosed);
        }

        /// <summary>
        /// Method 
        /// Preferences_FormClosed
        /// this method is called when the form is closed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Preferences_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseWindow();
        }

        #endregion

        #region Initialization
        
        /// <summary>
        /// Method
        /// Init
        /// initializes the controls and buttons
        /// </summary>
        private void Init()
        {
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            InitButtons();

            InitPreferences();
        }


        #region Initialize Preferences Tab

        /// <summary>
        /// Method
        /// InitPreferences
        /// initializes the preferences controls
        /// </summary>
        private void InitPreferences()
        {
            this.Text = TSR.Core.ResourceHelper.PreferencesText;
            lblOrganization.Text = TSR.Core.ResourceHelper.OrganizationSelectionText;
            lblProject.Text = TSR.Core.ResourceHelper.ProjectSelectionText;
            lblActivity.Text = TSR.Core.ResourceHelper.ActivitySelectionText;
            cbShowOnlyFavorites.Text = TSR.Core.ResourceHelper.ShowOnlyFavoritesText;

            FillListBox();
            PrepareGridView(dgvPreferredPathList);
            preferredPathsList = RetrievePreferredPaths();
            prePreferredPathsList = RetrievePreferredPaths();
            FillDataGridView(dgvPreferredPathList, preferredPathsList);

            GetShowOnlyFavorites();
        }

        #region Initialize Buttons

        /// <summary>
        /// Method
        /// InitButtons
        /// initializes the buttons
        /// </summary>
        private void InitButtons()
        {
            btnOk.Text = TSR.Core.ResourceHelper.OK;
            btnCancel.Text = TSR.Core.ResourceHelper.Cancel;
            btnAdd.Text = TSR.Core.ResourceHelper.Add;
            btnRemove.Text = TSR.Core.ResourceHelper.Remove;
        }

        #endregion

        #endregion

        #endregion

        #region Form Closing

        /// <summary>
        /// Method (event handler)
        /// TSRPreferences_FormClosing
        /// the method is invoked to handle 
        /// form closing events
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TSRPreferences_FormClosing(Object sender, FormClosingEventArgs e)
        {
            CloseWindow();
        }
        #endregion

        #region Events - Actions

        /// <summary>
        /// method (Event handler)
        /// btnAdd_Click
        /// handles the Add button clicked event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //declare the flags and variables
                bool _isError = false;
                string _msg = string.Empty;
                string orgName = GetSelectedItemName(lstOrganization);
                string projectName = GetSelectedItemName(lstProject);
                string activityName = GetSelectedItemName(lstActivity);

                var data = new[] {orgName, projectName, activityName};

                if (!IsDataExistInGrid(data, dgvPreferredPathList)) // the data is not in the grid
                {
                    //create a new PreferredPaths objects
                    Entity.PreferredPaths pp = new TSR.Core.Entity.PreferredPaths();

                    //add the necessary data
                    pp.Organization = new TSR.Core.Entity.Organization();
                    pp.OrganizationID = GetSelectedItemID(lstOrganization);
                    pp.Organization.Name = GetSelectedItemName(lstOrganization);
                    pp.Project = new TSR.Core.Entity.Project();
                    pp.ProjectID = GetSelectedItemID(lstProject);
                    pp.Project.Name = GetSelectedItemName(lstProject);
                    pp.Activity = new TSR.Core.Entity.Activity();
                    pp.ActivityID = GetSelectedItemID(lstActivity);
                    pp.Activity.Name = GetSelectedItemName(lstActivity);

                    // add the object to the collection
                    preferredPathsList.Add(pp);

                    //add the object to the grid view
                    dgvPreferredPathList.Rows.Add(new object[] { false, pp.OrganizationName, pp.ProjectName, pp.ActivityName });


                }
                else //the data is in the gridview
                {
                    _isError = true;
                    _msg = this.InfomationAlreadyExistInGridMsg;

                }

                // if some error occers let the user know
                if (_isError)
                {
                    string TSRSettings = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " " + Core.ResourceManager.GetResourceString("Settings", "Settings");
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = _msg,
                        Priority = 0
                    });
                    MessageBox.Show(this, _msg, TSRSettings, MessageBoxButtons.OK, MessageBoxIcon.Error);                 
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                System.Console.WriteLine(ex.StackTrace);
            }
        }

        /// <summary>
        /// method (event handler)
        /// btnRemove_Click
        /// this method is invoked 
        /// when remove button is selected
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Entity.PreferredPathsList ppList=new TSR.Core.Entity.PreferredPathsList(preferredPathsList);
            DataGridViewRow rowToRemove = new DataGridViewRow();

            foreach (DataGridViewRow row in dgvPreferredPathList.Rows)
            {
                if (row != null)
                {
                    if (row.Selected)
                    {
                        //preferredPathsList.Remove(ppList[row.Index]);
                        preferredPathsList.RemoveAt(row.Index);
                        rowToRemove = row;
                    }


                }
            }
            
            //preferredPathsList.Remove(preferredPathsList.FindByID(GetSelectedItemID(dgvPreferredPathList.)));
            //dgvPreferredPathList.SelectedRow
            
            if ((rowToRemove != null) && (rowToRemove.Index != -1))
            {
                dgvPreferredPathList.Rows.Remove(rowToRemove);
            }
            
            //FillDataGridView(dgvPreferredPathList, preferredPathsList);

        }

        /// <summary>
        /// Method
        /// btnCancel_Click
        /// the cancel button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //nothing to do, so close the window
            CloseWindow();

        }


        private void lstOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillListBox(this.Organization);
        }

        private void lstProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillListBox(this.Project);
        }


        /// <summary>
        /// method 
        /// btnOk_Click
        /// ok button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            FillPreferences();

            SetShowOnlyFavorites();

            CloseWindow();
        }

        /// <summary>
        /// Method
        /// CloseWindow
        /// </summary>
        private void CloseWindow()
        {
            //free the instance
            if (instance != null)
            {
                instance.Dispose();
                instance = null;
            }

            //free the resources
            if (this != null)
            {
                try
                {
                    this.Close();
                    this.Dispose();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.StackTrace);
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }
        }
        #endregion

        #region Method Private Prepare DataGridView
        
        /// <summary>
        /// method
        /// GetCheckColumn
        /// gets the data grid view columns
        /// </summary>
        /// <param name="_name"></param>
        /// <returns>
        /// DataGridViewCheckBoxColumn
        /// </returns>
        private DataGridViewCheckBoxColumn GetCheckColumn(string _name)
        {
            DataGridViewCheckBoxColumn checkColumn = new DataGridViewCheckBoxColumn();
            checkColumn.Name = _name;
            return checkColumn;
        }


        /// <summary>
        /// method
        /// GetTextBoxColumn
        /// gets the columns for text box
        /// </summary>
        /// <param name="name"></param>
        /// <param name="dataPropertyName"></param>
        /// <returns>
        /// DataGridViewCheckBoxColumn
        /// </returns>
        private static DataGridViewTextBoxColumn GetTextBoxColumn(string name, string dataPropertyName)
        {
            DataGridViewTextBoxColumn textColumn = new DataGridViewTextBoxColumn();
            textColumn.Name = name;
            textColumn.DataPropertyName = dataPropertyName;
            textColumn.ReadOnly = true;
            return textColumn;
        }

        /// <summary>
        /// method 
        /// PrepareGridView
        /// prepares the grid view
        /// </summary>
        /// <param name="dgv"></param>
        private void PrepareGridView(DataGridView dgv)
        {
            dgv.AutoGenerateColumns = false;

            DataGridViewCheckBoxColumn dgvCheckColumn = GetCheckColumn(this.Default);
            DataGridViewColumn dgvOrganizationColumn = GetTextBoxColumn(this.Organization, TSR.Core.Entity.TimeEntry.Property_OrganizationName);
            DataGridViewColumn dgvProjectColumn = GetTextBoxColumn(this.Project, TSR.Core.Entity.TimeEntry.Property_ProjectName);
            DataGridViewColumn dgvActivityColumn = GetTextBoxColumn(this.Activity, TSR.Core.Entity.TimeEntry.Property_ActivityName);

            dgv.Columns.Add(dgvCheckColumn);
            dgv.Columns.Add(dgvOrganizationColumn);
            dgv.Columns.Add(dgvProjectColumn);
            dgv.Columns.Add(dgvActivityColumn);
        }
        #endregion

        #region Methods Data Filling in UI Controls

        /// <summary>
        /// Method
        /// FillListBox
        /// fills the listbox specified by the parameter
        /// </summary>
        /// <param name="_listBoxName"></param>
        private void FillListBox(string _listBoxName)
        {

            //fill organization list box
            if (_listBoxName.Equals(this.Organization))
            {
                if (GetSelectedItemID(lstOrganization) != -1)
                {
                    FillListBox(this.Project, lstProject, (Int64)lstOrganization.SelectedValue);
                }
                else
                {
                    FillListBox(this.Project, lstProject, -1);

                }
            }
            else if (_listBoxName.Equals(this.Project)) //the projects
            {
                if (GetSelectedItemID(lstProject) != -1)
                {

                    FillListBox(this.Activity, lstActivity, (Int64)lstProject.SelectedValue);
                }
                else
                {
                    FillListBox(this.Activity, lstActivity, -1);
                }
            }
        }

        /// <summary>
        /// Method 
        /// FillListBox
        /// fills a list box specified by the parameter
        /// and organization
        /// </summary>
        /// <param name="_listBox"></param>
        /// <param name="_orgList"></param>
        /// <param name="displayName"></param>
        /// <param name="valueMember"></param>
        private void FillListBox(ListBox _listBox, IList _orgList, string displayName, string valueMember)
        {
            _listBox.DataSource = _orgList;
            _listBox.ValueMember = valueMember;
            _listBox.DisplayMember = displayName;
        }

        /// <summary>
        /// Method
        /// FillListBox
        /// fills a listbox given it's name
        /// </summary>
        /// <param name="_listBoxName"></param>
        /// <param name="_listBox"></param>
        /// <param name="_id"></param>
        private void FillListBox(string _listBoxName, ListBox _listBox, Int64 _id)
        {
            try
            {
                //organization listbox
                if (_listBoxName.Equals(this.Organization))
                {
                    TSR.Core.Entity.OrganizationList _orgList = TSR.Core.TSRFacade.GetAllOrganizations();
                    FillListBox(_listBox, _orgList, TSR.Core.Entity.Organization.Property_Name, TSR.Core.Entity.Organization.Property_ID);
                }
                else if (_listBoxName.Equals(this.Project)) // project listbox
                {
                    TSR.Core.Entity.ProjectList _projectList;

                    switch (_id)
                    {
                        case -1:
                            {                                
                                //_projectList = TSR.Core.TSRFacade.GetAllProjects();
                                long organizationID;
                                if (!long.TryParse(lstOrganization.SelectedValue.ToString(), out organizationID))
                                    organizationID = -1;
                                //Entity.ProjectList projectList;

                                if (organizationID == -1)
                                    _projectList = Core.TSRFacade.GetAllProjects();
                                else
                                    _projectList = Core.TSRFacade.GetProjectsForOrganization(organizationID);

                                FillListBox(_listBox, _projectList, TSR.Core.Entity.Project.Property_Name, TSR.Core.Entity.Project.Property_ID);


                            }
                            break;

                        default:
                            {
                                _projectList = TSR.Core.TSRFacade.GetProjectsForOrganization(_id);
                                FillListBox(_listBox, _projectList, TSR.Core.Entity.Project.Property_Name, TSR.Core.Entity.Project.Property_ID);

                            }
                            break;

                    }
                }
                else if (_listBoxName.Equals(this.Activity))
                {
                    TSR.Core.Entity.ActivityList _activityList = null;
                    switch (_id)
                    {
                        case -1:
                            {
                                //_activityList = TSR.Core.TSRFacade.GetAllActivities();
                                long projectID;
                                if (!long.TryParse(lstProject.SelectedValue.ToString(), out projectID))
                                    projectID = -1;

                                if (projectID == -1)
                                    _activityList = Core.TSRFacade.GetAllActivities();
                                else
                                    _activityList = Core.TSRFacade.GetActivitiesForProject(projectID);

                                FillListBox(_listBox, _activityList, TSR.Core.Entity.Activity.Property_Name, TSR.Core.Entity.Activity.Property_ID);

                            }
                            break;

                        default:
                            {
                                _activityList = TSR.Core.TSRFacade.GetActivitiesForProject(_id);
                                FillListBox(_listBox, _activityList, TSR.Core.Entity.Activity.Property_Name, TSR.Core.Entity.Activity.Property_ID);

                            }
                            break;


                    }

                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.StackTrace);
                Core.Logging.LoggingHandler.LogError(ex);
            }

        }


        private void AddDataInList(ArrayList _arrayList, object data)
        {
            _arrayList.Add(data);
        }

        private Entity.PreferredPathsList RetrievePreferredPaths()
        {
            return TSR.Core.TSRFacade.GetAllPreferredPathsList();
        }

        /// <summary>
        /// Method
        /// FillDataGridView
        /// fills a data grid view
        /// </summary>
        /// <param name="_dgv"></param>
        /// <param name="ppList"></param>
        private void FillDataGridView(DataGridView _dgv, Entity.PreferredPathsList ppList)
        {

            if (ppList != null)
            {
                if (_dgv.RowCount > 0)
                {
                    _dgv.Rows.Clear();

                } _dgv.DataSource = null;                
                foreach (Entity.PreferredPaths pp in ppList)
                {
                    try
                    {
                        _dgv.Rows.Add(new object[] { pp.IsDefault, pp.OrganizationName, pp.ProjectName, pp.ActivityName });
                    }
                    catch (Exception exp)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(exp);
                    }
                }

            }


        }
        
        /// <summary>
        /// Method
        /// FillListBox
        /// fills all the listboxes
        /// </summary>
        private void FillListBox()
        {
            FillListBox(this.Organization, lstOrganization, -1);
            FillListBox(this.Project,lstProject,-1);
            FillListBox(this.Activity,lstActivity,-1);

        }

        /// <summary>
        /// Method
        /// FillPreferences
        /// fills the preferances
        /// </summary>
        private void FillPreferences()
        {
            try
            {
                //Entity.PreferredPathsList ppList = new TSR.Core.Entity.PreferredPathsList(preferredPathsList);
                TSR.Core.TSRFacade.DeleteAllPreferredPaths();
                TSR.Core.TSRFacade.UpdatePreferredPaths(preferredPathsList);

                //foreach (Entity.PreferredPaths pp in ppList)
                //{
                //    //if (prePreferredPathsList.Find(pp))
                //    //{

                //    Entity.PreferredPaths prePP = prePreferredPathsList.FindByID(pp.ID);

                //    if (prePP != null && prePP.ID != -1)
                //    {
                //        preferredPathsList.Remove(pp);
                //        prePreferredPathsList.Remove(prePP);
                //    }
                //}



                //TSR.Core.TSRFacade.InsDelPreferredPaths(preferredPathsList,prePreferredPathsList);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.StackTrace);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }
        #endregion

        #region Selection Methods

        /// <summary>
        /// Method
        /// GetSelectedItemID
        /// gets the selected item index given the listbox
        /// </summary>
        /// <param name="_listBox"></param>
        /// <returns>
        /// Int64
        /// (the selected item's ID)
        /// </returns>
        private Int64 GetSelectedItemID(ListBox _listBox)
        {
            Int64 _id = 0;
            bool _isValid = false;
            if (_listBox.SelectedIndex >= 0)
            {


                _isValid = Int64.TryParse(_listBox.SelectedValue.ToString(), out _id);

                if (_isValid)
                {
                    return _id;

                }
            }
            return -1;
        }

        //private bool IsItemDefault(ListBox _listBox, int rowIndex)
        //{

        //    bool isChecked = false;

        //    DataGridViewRow dgvRow = _listBox.Rows[rowIndex];
        //    DataGridViewCheckBoxCell cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
        //    if (cell != null)
        //    {
        //        isChecked = Convert.ToBoolean(cell.Value);
        //    }

        //    return isChecked;
        //}

        /// <summary>
        /// Method
        /// GetSelectedItemName
        /// gets the name of the selected item
        /// given the list box
        /// </summary>
        /// <param name="_listBox"></param>
        /// <returns>
        /// String
        /// (name of the selectes item)
        /// </returns>
        private String GetSelectedItemName(ListBox _listBox)
        {

            String _name = null;
            if (_listBox.SelectedIndex > -1)
            {
                _name = _listBox.Text.ToString();

            }
            return _name;

        }

        /// <summary>
        /// Method
        /// IsDataExistInGrid
        /// checks whether the data set exist in the gridview
        /// </summary>
        /// <param name="_data">string[]</param>
        /// <param name="_dataGridView"></param>
        /// <returns>
        /// bool
        /// </returns>
        private bool IsDataExistInGrid(string[] _data, DataGridView _dataGridView)
        {
            bool isExist = false;
            foreach (DataGridViewRow dgvRow in _dataGridView.Rows)
            {
                DataGridViewCellCollection cells = dgvRow.Cells;

                if (cells[1].Value != null && cells[2].Value != null && cells[3].Value != null)
                {
                    if ((cells[1].Value.Equals(_data[0])) &&
                        (cells[2].Value.Equals(_data[1])) &&
                    (cells[3].Value.Equals(_data[2])))
                    {
                        isExist = true;
                        break;
                    }
                }
            }

            return isExist;
        }

        /// <summary>
        /// Method
        /// IsDataExistInGrid
        /// checks whether the data exists 
        /// in the data gridview in th especified collumn
        /// </summary>
        /// <param name="_data"></param>
        /// <param name="colIndex"></param>
        /// <param name="_dataGridView"></param>
        /// <returns>
        /// bool
        /// </returns>
        private bool IsDataExistInGrid(string _data, int colIndex,  DataGridView _dataGridView)
        {
            bool isExist = false;
            foreach (DataGridViewRow dgvRow in _dataGridView.Rows)
            {
                DataGridViewCellCollection cells = dgvRow.Cells;

                if (colIndex > 0)
                {
                    if (cells[colIndex].Value != null)
                    {
                        if (cells[colIndex].Value.Equals(_data))
                        {
                            isExist = true;
                            break;
                        }
                    }
                }


            }

            return isExist;
        }

        #endregion

        /// <summary>
        /// Method (Event handler)
        /// dgvPreferredPathList_CellContentClick
        /// the method is invoked when any content of a cell 
        /// in the data grid view is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvPreferredPathList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if ((e.ColumnIndex == 0) &&(e.RowIndex > -1))
            {
                DataGridViewRow dgvRow = dgvPreferredPathList.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
                if (cell != null)
                {
                    bool isChecked = Convert.ToBoolean(cell.Value);
                    cell.Value = preferredPathsList[e.RowIndex].IsDefault = !isChecked;

                    if ((bool)cell.Value)
                    {
                        for (int index = 0; index < dgvPreferredPathList.Rows.Count; index++)
                        {
                            if (index != e.RowIndex)
                            {
                                DataGridViewCheckBoxCell checkCell = dgvPreferredPathList.Rows[index].Cells[0] as DataGridViewCheckBoxCell;
                                if (checkCell != null)
                                {
                                    checkCell.Value = preferredPathsList[index].IsDefault = false;
                                }
                            }
                        }
                    }
                    
                }
            }
        }

        #region Save Setting
        /// <summary>
        /// Method 
        /// SetShowOnlyFavorites
        /// sets the show only favorites of the server
        /// </summary>
        private void SetShowOnlyFavorites()
        {
            TSR.Core.SettingsHelper.ShowOnlyFavorites = cbShowOnlyFavorites.Checked;
        }

        /// <summary>
        /// method
        /// GetShowOnlyFavorites
        /// gets show only favorites of the server
        /// </summary>
        private void GetShowOnlyFavorites()
        {
            cbShowOnlyFavorites.Checked = TSR.Core.SettingsHelper.ShowOnlyFavorites;
        }
        #endregion
    }
}