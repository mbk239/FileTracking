﻿namespace TSR.Shell
{
    partial class OverwriteTimeEntries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.chkSelectAllOrNo = new System.Windows.Forms.CheckBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.ucOverwriteTimeEntries = new TSR.Shell.Controls.ucTSRItemList();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnOk.Location = new System.Drawing.Point(707, 396);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(81, 26);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // chkSelectAllOrNo
            // 
            this.chkSelectAllOrNo.AutoSize = true;
            this.chkSelectAllOrNo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.chkSelectAllOrNo.Location = new System.Drawing.Point(3, 400);
            this.chkSelectAllOrNo.Name = "chkSelectAllOrNo";
            this.chkSelectAllOrNo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 5);
            this.chkSelectAllOrNo.Size = new System.Drawing.Size(389, 22);
            this.chkSelectAllOrNo.TabIndex = 4;
            this.chkSelectAllOrNo.Text = "Select All/Deselect All";
            this.chkSelectAllOrNo.UseVisualStyleBackColor = true;
            this.chkSelectAllOrNo.CheckedChanged += new System.EventHandler(this.chkSelectAllOrNo_CheckedChanged);
            this.chkSelectAllOrNo.CheckStateChanged += new System.EventHandler(this.chkSelectAllOrNo_CheckStateChanged);
            // 
            // lblMessage
            // 
            this.lblMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.lblMessage, 2);
            this.lblMessage.Location = new System.Drawing.Point(3, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Padding = new System.Windows.Forms.Padding(5, 0, 0, 0);
            this.lblMessage.Size = new System.Drawing.Size(785, 32);
            this.lblMessage.TabIndex = 5;
            this.lblMessage.Text = "label1";
            // 
            // ucOverwriteTimeEntries
            // 
            this.ucOverwriteTimeEntries.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.ucOverwriteTimeEntries, 2);
            this.ucOverwriteTimeEntries.EnableSelection = false;
            this.ucOverwriteTimeEntries.Location = new System.Drawing.Point(3, 35);
            this.ucOverwriteTimeEntries.Name = "ucOverwriteTimeEntries";
            this.ucOverwriteTimeEntries.Size = new System.Drawing.Size(785, 355);
            this.ucOverwriteTimeEntries.TabIndex = 3;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lblMessage, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOk, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.chkSelectAllOrNo, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ucOverwriteTimeEntries, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.764706F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85.17647F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.294117F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(791, 425);
            this.tableLayoutPanel1.TabIndex = 6;
            // 
            // OverwriteTimeEntries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 425);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(799, 457);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(799, 457);
            this.Name = "OverwriteTimeEntries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Overwrite time entries";
            this.Load += new System.EventHandler(this.frmOverwriteTimeEntries_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private Controls.ucTSRItemList ucOverwriteTimeEntries;
        private System.Windows.Forms.CheckBox chkSelectAllOrNo;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}