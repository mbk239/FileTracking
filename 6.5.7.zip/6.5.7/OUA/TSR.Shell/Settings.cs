using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.Collections;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Globalization;
using Microsoft.Office.Interop.Outlook;
using TSR.Core.Entity.List;
using TSR.Core;
using TSR.Core.Entity;
using TSR.Core.DAL;
using Microsoft.Win32;	// For RegKey

namespace TSR.Shell
{
    /// <summary>
    /// Partial Class
    /// Settings
    /// Extends Form and IDisposable
    /// </summary>
    public partial class Settings : Controls.OUAForm, IDisposable
    {
        private static UserSettingsList userSettingListData = new UserSettingsList();
        private bool isDisableAddin = false;
        private bool isChangePassword = false;

        private ToolTip toolTip1;

        #region Get Single Instance
        /// <summary>
        /// method ( Property Like)
        /// Gets an Instance of the class
        /// </summary>
        /// <returns></returns>
        public static Settings GetInstance()
        {
            if (instance == null)
            {
                instance = new Settings();

            }
            return instance;
        }

        public static Settings GetInstance(bool isDisableAddin)
        {
            if (instance == null)
            {
                instance = new Settings(isDisableAddin);

            }
            return instance;
        }

        #endregion

        #region Constructor

        /// <summary>
        /// The constructor
        /// </summary>
        public Settings()
        {
            m_Application = null;
            InitializeComponent();
            if (TSR.Core.SettingsHelper.TSRDontShowAgain)
            {
                chbDontshowagain.Checked = true;
            }
            else
            {
                chbDontshowagain.Checked = false;
            }
        }
        public Settings(bool isDisable)
        {
            m_Application = null;
            InitializeComponent();
            if (!isDisable)
            {
                if (TSR.Core.SettingsHelper.TSRDontShowAgain)
                {
                    chbDontshowagain.Checked = true;
                }
                else
                {
                    chbDontshowagain.Checked = false;
                }
            }
            else
                DisableAllTabsExceptUserAccountTab();
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="_m_Application"></param>
        public Settings(Outlook.Application _m_Application)
        {
            this.m_Application = _m_Application;
            InitializeComponent();
        }

        #endregion

        #region Form Loading

        /// <summary>
        /// Method
        /// Settings_Load
        /// Loads the settings form and 
        /// performs some initializing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Settings_Load(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            Init();
            //FormClosing += new FormClosingEventHandler(Settings_FormClosing);
            FormClosed += new FormClosedEventHandler(Settings_FormClosed);

            //  RegistryKey regKey = Registry.CurrentUser.CreateSubKey("Areyousuretosubmit");
            // bool chk = Convert.ToBoolean(regKey.GetValue("DontShowAgain"));     
            this.chkDisplayTooltip.CheckedChanged += new System.EventHandler(this.chkDisplayTooltip_CheckedChanged);

            this.Cursor = Cursors.Default;

        }
        /// <summary>
        /// Get User Settings List Data
        /// </summary>
        //private void GetUserSettingsListData()
        //{
        //    try
        //    {
        //        if (userSettingListData.Count == 0)
        //        {
        //            foreach (UserSettings obj in TSR.Core.TSRFacade.GetUserSettingsList())
        //            {
        //                userSettingListData.Add(obj);
        //            }
        //        }
        //        if (userSettingListData.Count > 0)
        //        {
        //            foreach (UserSettings objUser in userSettingListData)
        //            {

        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRAUTO_SYNC_INDEX)
        //                {
        //                    txtAutoSyncIndex.Text = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNCHRONIZE_TSRSETUP_DATA)
        //                {
        //                    chkSetupData.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNCHRONIZE_TSRENTRIES)
        //                {
        //                    chkTSRItems.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNC_RANGE_INDEX)
        //                {
        //                    txtSyncRangeIndex.Text = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNC_RANGE_INDEX_FUTURE)
        //                {
        //                    txtSyncRangeIndexFuture.Text = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRBTN_AUTO_SYNC_EVERYTIIME)
        //                {
        //                    rbtnAutoSyncEveryTiime.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRMISC_LAUNCH)
        //                {
        //                    chkMiscLaunch.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRMISC_NOT_SYNC_COMPLETED_DATA)
        //                {
        //                    chkMiscNotSyncCompletedData.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRMISC_SYNC_REMOVED_DATA)
        //                {
        //                    chkMiscRecreateDeletedTSRAppointment.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNC_RANGE_PERIOD)
        //                {
        //                    cmbSyncRangePeriod.SelectedValue = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRSYNC_RANGE_PERIOD_FUTURE)
        //                {
        //                    cmbSyncRangePeriodFuture.SelectedValue = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRAUTO_SYNC_PERIOD)
        //                {
        //                    cmbAutoSyncPeriod.SelectedValue = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRMISC_PAST_INDEX)
        //                {
        //                    txtMiscPastIndex.Text = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRMISC_FUTURE_INDEX)
        //                {
        //                    txtMiscFutureIndex.Text = objUser.Value.ToString();
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRAUTO_SYNC_WHEN_OUTLOOK_CLOSE)
        //                {
        //                    rbtnAutoSuncClosingTIme.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRAUTO_SYNC_PERIOD_OPTION)
        //                {
        //                    rbtnAutoSyncPeriod.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRAUTO_SYNC_OPTION)
        //                {
        //                    rbtnAutoSunc.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //                if (objUser.Key.ToString() == Core.SettingsHelper.TSRDISPLAY_TOOLTIP)
        //                {
        //                    chkDisplayTooltip.Checked = Convert.ToBoolean(objUser.Value.ToString());
        //                }
        //            }
        //        }
        //    }
        //    catch (System.Exception ex)
        //    {
        //        Core.Logging.LoggingHandler.LogError(ex);
        //    }
        //}

        /// <summary>
        /// method
        /// Settings_FormClosed
        /// Handles the FormClosed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Settings_FormClosed(object sender, FormClosedEventArgs e)
        {
            CloseWindow();
            //throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region Initialize Form Controls
        /// <summary>
        /// Method 
        /// Init
        /// initializes the controls of the form
        /// </summary>
        private void Init()
        {
            //BaseDAL.MyDataSet.AcceptChanges();
            BaseDAL.MyDataSet.LanguageResources.AcceptChanges();
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            foreach (TabPage tbpage in tbcntSettings.TabPages)
            {
                tbpage.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            }
            rbtnAutoSuncClosingTIme.Text = Core.ResourceHelper.AutoSyncOnCloseRadioButtonText.ToString();
            lblPreferredLanguage.Text = Core.ResourceHelper.PreferredLanguageLabelText.ToString();
            rbtnAutoSunc.Text = Core.ResourceHelper.AutomaticallySyncRadioButtonText.ToString();
            gbAutoSync.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            txtUserAccInfoMsg.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);
            txtWhatToSyncInfoMsg.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);
            txtSyncRangeInfoMsg.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);

            chkNeverAskAgain.Text = Core.ResourceManager.GetResourceString("NeverAskMeAgain", "Never ask me again");
            rdBtnShowAllFolder.Text = Core.ResourceManager.GetResourceString("DislayAllOutlookFolder", "Show all Outlook calendar");

            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            this.Text = TSR.Core.ResourceHelper.Settings;
            
            //isSettingChanged = false;
            InitUserAccount();
            InitComboboxTooltip();
            if (!isDisableAddin)
            {
                chkNeverAskAgain.Visible = false;

                InitWhatToSync();
                InitSyncRange();
                InitAutoSync();
                InitMiscellaneous();
                InitComboBoxes();


                SetEnabledControl();
            }

            InitConnectionSettings();

            InitButtons();
            RetriveData();
        }

        private void SetEnabledControl()
        {
            bool isLocked = TSR.Core.Constants.ISLOCKEDUSERSETTING;
            bool isServerFound = TSR.Core.Constants.ISSERVERFOUND;

            if (isLocked)
            {
                //Set enabled to all text boxes
                txtAutoSyncIndex.Enabled = !isLocked;
                txtMiscFutureIndex.Enabled = !isLocked;
                //txtWebinterface.Enabled = !isLocked;
                txtMiscPastIndex.Enabled = !isLocked;
                txtSyncRangeIndex.Enabled = !isLocked;
                txtSyncRangeIndexFuture.Enabled = !isLocked;

                //Set enable to all combo boxes
                cmbAutoSyncPeriod.Enabled = !isLocked;
                cmbMiscFuturePeriod.Enabled = !isLocked;
                cmbMiscPastPeriod.Enabled = !isLocked;
                //cmbOutlookFloder.Enabled = !isLocked;
                cmbPreferredLanguage.Enabled = !isLocked;
                cmbSyncRangePeriod.Enabled = !isLocked;
                cmbSyncRangePeriodFuture.Enabled = !isLocked;

                //Set enabled to all check boxes or radio buttons
                chkMiscLaunch.Enabled = !isLocked;
                //chbDontshowagain.Enabled = !isLocked;
                chkMiscNotSyncCompletedData.Enabled = !isLocked;
                chkMiscNotSyncTECreatedViaWeb.Enabled = !isLocked;
                chkMiscRecreateDeletedTSRAppointment.Enabled = !isLocked;
                chkSetupData.Enabled = !isLocked;
                chkTSRItems.Enabled = !isLocked;
                rbtnAutoSunc.Enabled = !isLocked;
                rbtnAutoSuncClosingTIme.Enabled = !isLocked;
                rbtnAutoSyncEveryTiime.Enabled = !isLocked;
                rbtnAutoSyncPeriod.Enabled = !isLocked;
                rbtnNotAutoSync.Enabled = !isLocked;

                chkDisplayTooltip.Enabled = !isLocked;

                cbbDateFormat.Enabled = !isLocked;
                cbbTimeFormat.Enabled = !isLocked;

                cbxOutUserAgent.Enabled = !isLocked;

                //Feature 316 � Settings lock
                if(isServerFound) //really locked in web Admin
                {
                    //Tab account
                    txtCustomerNo.Enabled = !isLocked;
                    txtUserName.Enabled = !isLocked;
                    txtPassword.Enabled = !isLocked;
                    txtServerAddress.Enabled = !isLocked;
                    chkSSLMode.Enabled = !isLocked;
                    btnTestServerUp.Enabled = !isLocked;
                    txtWebinterface.Enabled = !isLocked;
                    chbDoNotRetrieveSettings.Enabled = !isLocked;
                    chbDontshowagain.Enabled = !isLocked;
                    chkNeverAskAgain.Enabled = !isLocked;
                    //tab What to sync
                    rdBtnShowAllFolder.Enabled = !isLocked;
                    cmbOutlookFloder.Enabled = !isLocked;

                    cbbProxyType.Enabled = !isLocked;
                    txtConnectionTimeOutValue.Enabled = !isLocked;
                    txtMiscPastIndex.Enabled = !isLocked;
                    txtMiscFutureIndex.Enabled = !isLocked;
                    cmbMiscPastPeriod.Enabled = !isLocked;
                    cmbMiscFuturePeriod.Enabled = !isLocked;
                }
            }
        }
        /// <summary>
        /// Method
        /// InitComboBoxes
        /// initializes the controls of combo box
        /// </summary>
        private void InitComboBoxes()
        {
            //cmbAutoSyncIndex.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAutoSyncPeriod.DropDownStyle = ComboBoxStyle.DropDownList;
            //cmbMiscIndex.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMiscPastPeriod.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMiscFuturePeriod.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbOutlookFloder.DropDownStyle = ComboBoxStyle.DropDownList;
            //cmbSyncRangeIndex.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSyncRangePeriod.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSyncRangePeriodFuture.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPreferredLanguage.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxOutUserAgent.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        /// <summary>
        /// method 
        /// RetriveData
        /// retrives data from the form
        /// </summary>
        private void RetriveData()
        {
            GetNONADUserName();
            GetPassword();
            GetCustomerNo();
            GetServerAddres();
            GetNeverAskMeAgainSetting();
            chkSSLMode.Checked = TSR.Core.TSRFacade.GetTSRSSLMode();

            if (!isDisableAddin)
            {
                GetTSRItemsToBeSynchronized();
                GetSyncRange();
                GetOutlookFolder();
                GetMisc();
                GetAutoSync();
            }

            GetConnectionSettings();
        }

        #region Initialize User Account Tab

        /// <summary>
        /// Method 
        /// InitUserAccount
        /// initializes the user account tab
        /// </summary>
        private void InitUserAccount()
        {
            lblWebinterface.Text = Core.ResourceManager.GetResourceString("_webInterface", "Web Interface");

            lblCustomerNo.Text = Core.ResourceManager.GetResourceString("CustomerNo", "Customer Number");
            lblPassword.Text = Core.ResourceManager.GetResourceString("Passwd_LebelText", "Password");

            //txtCustomerNo.Enabled = false;

            tpUserAccount.Text = TSR.Core.ResourceHelper.UserAccountText;
            txtUserAccInfoMsg.Text = TSR.Core.ResourceHelper.UserAccountInfoMsgLebelText;
            lblUserName.Text = TSR.Core.ResourceHelper.UserNameLebelText;
            //lblPasswd.Text = TSR.Core.ResourceHelper.PasswordLebelText;
            lblServerAddress.Text = TSR.Core.ResourceHelper.ServerAddressLebelText;
            lblChooseSecureMode.Text = TSR.Core.ResourceManager.GetResourceString("ChooseSecureMode", "Secure Mode");
            chkSSLMode.Text = TSR.Core.ResourceManager.GetResourceString("SSLMode", "SSL Mode");
            //lblTestUserCredential.Text = TSR.Core.ResourceHelper.TestUserCredentialLebelText;
            if (!isDisableAddin)
            {
                chbDontshowagain.Text = TSR.Core.ResourceHelper.DonnotShowAgainMsgLabelText;
                chbDoNotRetrieveSettings.Text = TSR.Core.ResourceHelper.DoNotRetrieveSettingsText;
            }
        }
        #endregion
        #region Initialize What To Sync Tab
        /// <summary>
        /// methid
        /// InitWhatToSync
        /// initializes what to say tab
        /// </summary>
        private void InitWhatToSync()
        {
            tpWhatToSynchronize.Text = TSR.Core.ResourceHelper.WhatToSyncText;
            lblOutlookFloder.Text = TSR.Core.ResourceHelper.OutlookFolderLebelText + ":";
            chkSetupData.Text = TSR.Core.ResourceHelper.SetupDataCheckBoxText;
            chkTSRItems.Text = TSR.Core.ResourceHelper.TSRItemsCheckBoxText;
            txtWhatToSyncInfoMsg.Text = TSR.Core.ResourceHelper.WhatToSyncInfoMsgLebelText;
            BindDefaultFolders();
            cmbOutlookFloder.Enabled = false;
            rdBtnShowAllFolder.Enabled = false;
        }

        private void BindDefaultFolders()
        {
            MAPIFolder mapiFolder = null;
            if (!String.IsNullOrEmpty(Core.SettingsHelper.GetTSROutlookFolderToSync()))
            {
                ///Get Folder by Entry ID and set the folder as Appointment Folder
                mapiFolder = Core.OutlookHelper.GetUserSelectedAppointmentFolderForSynchronization_NotCheckedSameName();
            }
            if(mapiFolder == null) mapiFolder = TSR.Core.OutlookHelper.DefaultAppointmentFolder;           

            TSR.Core.OutlookMAPIFolderList _outlookFolderList = new OutlookMAPIFolderList();
            _outlookFolderList.Add(Core.OutlookHelper.FillOutlookMAPIFolder(mapiFolder));

            FillComboBox(cmbOutlookFloder, _outlookFolderList);
        }

        private void BindFolders()
        {
            TSR.Core.OutlookMAPIFolderList _outlookFolderList = TSR.Core.OutlookHelper.GetAllAppointmentItemFolders();
            FillComboBox(cmbOutlookFloder, _outlookFolderList);
        }

        #endregion

        #region Initialize Sync. Range Tab

        /// <summary>
        /// Method 
        /// InitSyncRange
        /// initializes sync. Range
        /// </summary>
        private void InitSyncRange()
        {
            txtSyncRangeInfoMsg.Text = TSR.Core.ResourceHelper.SyncRangeInfoMsgLebelText;
            lblSyncRangeInThePast.Text = TSR.Core.ResourceHelper.InThePastLebelText;
            label1.Text = TSR.Core.ResourceHelper.InTheFutureLabelText;
            //FillIndex(cmbSyncRangeIndex);
            FillPeriod(cmbSyncRangePeriod, false);
            FillPeriod(cmbSyncRangePeriodFuture, false);
        }
        #endregion

        #region Initialize Auto. Sync. Tab

        /// <summary>
        /// Method 
        /// InitAutoSync
        /// initializes the Auto Sync. tab
        /// </summary>
        private void InitAutoSync()
        {
            tpAutomaticSync.Text = TSR.Core.ResourceHelper.AutoSyncText;
            lblAutoSuncInfoMsg.Text = TSR.Core.ResourceHelper.AutoSyncInfoMsgLebelText;
            rbtnNotAutoSync.Text = TSR.Core.ResourceHelper.DotNotAutoSyncRadioButtonText;
            rbtnAutoSunc.Text = TSR.Core.ResourceHelper.AutomaticallySyncRadioButtonText;
            rbtnAutoSyncEveryTiime.Text = TSR.Core.ResourceHelper.AutoSyncEveryTimeRadioButtonText;
            rbtnAutoSuncClosingTIme.Text = TSR.Core.ResourceHelper.AutoSyncOnCloseRadioButtonText;
            rbtnAutoSyncPeriod.Text = TSR.Core.ResourceHelper.AutoSyncPeriodRadioButtonText;
            lblAutoSyncPeriod.Text = TSR.Core.ResourceHelper.PeriodLebelText;

            //FillIndex(cmbAutoSyncIndex);
            FillPeriod(cmbAutoSyncPeriod, true);
            //cmbAutoSyncIndex.Enabled = false;
            txtAutoSyncIndex.Enabled = false;
            cmbAutoSyncPeriod.Enabled = false;
            cmbAutoSyncPeriod.SelectedIndex = TSR.Core.SettingsHelper.TSRAutoSyncPeriod;
        }
        #endregion

        #region Initialize Miscellaneous Tab

        /// <summary>
        /// Method 
        /// InitMiscellaneous
        /// initializes the Miscellaneous tab
        /// </summary>
        private void InitMiscellaneous()
        {
            tpMisc.Text = TSR.Core.ResourceHelper.MiscText;
            chkMiscLaunch.Text = TSR.Core.ResourceHelper.LaunchTSRCheckBoxText;
            chkMiscNotSyncCompletedData.Text = TSR.Core.ResourceHelper.DoNotSyncCompletedDataCheckBoxText;
            chkMiscNotSyncTECreatedViaWeb.Text = TSR.Core.ResourceHelper.DoNotSyncTECreatedViaWebCheckBoxText;
            chkMiscRecreateDeletedTSRAppointment.Text = TSR.Core.ResourceHelper.RecreateRemovedTSRAppointmentCheckBoxText;
            lblMiscFrom.Text = TSR.Core.ResourceHelper.FromLebelText;
            lblMiscTo.Text = TSR.Core.ResourceHelper.ToLebelText;
            lblMiscInThePast.Text = TSR.Core.ResourceHelper.InThePastLebelText;
            label2.Text = TSR.Core.ResourceHelper.InTheFutureLabelText;
            lblPreferredLanguage.Text = TSR.Core.ResourceHelper.PreferredLanguageLabelText;

            //FillIndex(cmbMiscIndex);
            FillPeriod(cmbMiscPastPeriod, false);
            cmbMiscPastPeriod.SelectedIndex = 0;
            FillPeriod(cmbMiscFuturePeriod, false);
            cmbMiscFuturePeriod.SelectedItem = 0;
            FillPreferredOLanguages();
            //cmbMiscIndex.Enabled = false;
            txtMiscPastIndex.Enabled = false;
            cmbMiscPastPeriod.Enabled = false;
            txtMiscFutureIndex.Enabled = false;
            cmbMiscFuturePeriod.Enabled = false;

            chkDisplayTooltip.Text = Core.ResourceManager.GetResourceString("TooltipOptionText", "Activate tooltip");
            lblDefaultDateTimeFormat.Text = Core.ResourceManager.GetResourceString("UserSetting_DefaultDateTimeFormat", "Default date and time format");

            lblOutlookUserAgent.Text = TSR.Core.ResourceHelper.ListTimeEntriesOUA;

            //cbbDateFormat.Enabled = false;
            FillDateFormat();
            cbbDateFormat.SelectedIndex = 0;

            //cbbTimeFormat.Enabled = false;
            FillTimeFormat();
            cbbTimeFormat.SelectedIndex = 0;

            InitOutlookUserAgent();
        }

        private void InitOutlookUserAgent()
        {
            var collection = new NameValueCollection();
            collection.Add(((int)SettingsHelper.OutlookUserAgentEnum.AsWebInterface).ToString(), ResourceManager.GetResourceString("AsWebInterface", "As web interface"));
            collection.Add(((int)SettingsHelper.OutlookUserAgentEnum.PreviousMonth).ToString(), ResourceManager.GetResourceString("PreviousMonth", "Previous month"));
            collection.Add(((int)SettingsHelper.OutlookUserAgentEnum.PreviousWeek).ToString(), ResourceManager.GetResourceString("PreviousWeek", "Previous week"));
            collection.Add(((int)SettingsHelper.OutlookUserAgentEnum.CurrentWeek).ToString(), ResourceManager.GetResourceString("CurrentWeek", "Current week"));
            collection.Add(((int)SettingsHelper.OutlookUserAgentEnum.CurrentMonth).ToString(), ResourceManager.GetResourceString("CurrentMonth", "Current month"));

            UIHelper.FillComboBoxWithNameValueCollection(cbxOutUserAgent, collection);
        }

        private void InitConnectionSettings()
        {
            tpConnectionSettings.Text = Core.ResourceManager.GetResourceString("ConnectionSettings", "Connection Settings");
            grpProxyConfiguration.Text = Core.ResourceManager.GetResourceString("ProxyConfiguration", "Configure Proxy");
            lblProxyHost.Text = Core.ResourceManager.GetResourceString("Host", "Host");
            lblProxyPort.Text = Core.ResourceManager.GetResourceString("Port", "Port");
            lblProxyUsername.Text = Core.ResourceManager.GetResourceString("Username", "Username");
            lblProxyPassword.Text = Core.ResourceManager.GetResourceString("Password", "Password");
            chkProxyAuthentication.Text = Core.ResourceManager.GetResourceString("ProxyAuthenticationEnable", "Enable proxy authentication");

            //fill Proxy type combobox
            cbbProxyType.Items.Clear();
            cbbProxyType.Items.Add(Core.ResourceManager.GetResourceString("NoProxy", "No Proxy"));
            cbbProxyType.Items.Add(Core.ResourceManager.GetResourceString("ProxyAutoDetection", "Automatic proxy detection"));
            cbbProxyType.Items.Add("HTTPS");
            cbbProxyType.Items.Add("SOCKS");
            cbbProxyType.SelectedIndex = 0;

            chkProxyAutoSwitch.Text = Core.ResourceManager.GetResourceString("ProxyAutoSwitch", "Automatic proxy. If this value is set, the agent will try to connect to the server without the proxy settings if the proxy server is not reachable.");
            lblConnectionTimeOutValue.Text = Core.ResourceManager.GetResourceString("ConnectionTimeOutLabel", "Connection time out value (seconds)");
        }

        #endregion

        #region Initialize Buttons

        /// <summary>
        /// Method
        /// InitButtons
        /// initializes the buttons
        /// </summary>
        private void InitButtons()
        {
            btnOk.Text = TSR.Core.ResourceHelper.OK;
            //btnHelp.Text = TSR.Core.ResourceHelper.Help;
            btnCancel.Text = TSR.Core.ResourceHelper.Cancel;
            btnOk.Enabled = false;
            btnTestServerUp.Text = TSR.Core.ResourceHelper.TestServerAddressUpButtonText;
            btnTestServerUp.Enabled = false;

        }

        private void InitComboboxTooltip()
        {
            toolTip1 = new ToolTip();
            toolTip1.AutoPopDelay = 0;
            toolTip1.InitialDelay = 0;
            toolTip1.ReshowDelay = 0;
            toolTip1.ShowAlways = true;
        }

        #endregion

        #endregion

        #region Selecting Methods

        /// <summary>
        /// Method
        /// GetSelectedItemName
        /// gets the selected Item Name
        /// </summary>
        /// <param name="_listBox"></param>
        /// <returns>
        /// string 
        /// </returns>
        private string GetSelectedItemName(ListBox _listBox)
        {

            String _name = null;
            if (_listBox.SelectedIndex != -1)
            {
                _name = _listBox.Text.ToString();

            }
            return _name;

        }

        /// <summary>
        /// Method
        /// GetSelectedItemValue
        /// gets the value of the selected item
        /// </summary>
        /// <param name="_listBox"></param>
        /// <returns>
        /// Int64
        /// </returns>
        private Int64 GetSelectedItemValue(ListBox _listBox)
        {
            Int64 _id = 0;
            bool _isValid = false;
            if (_listBox.SelectedIndex != 0)
            {
                _isValid = Int64.TryParse(_listBox.SelectedValue.ToString(), out _id);

                if (_isValid)
                {
                    return _id;

                }
            }
            return -1;
        }


        #endregion

        #region Private Method ChangedSettings

        /// <summary>
        /// Method
        /// ChangedSettings
        /// </summary>
        private void ChangedSettings()
        {
            if (!string.IsNullOrEmpty(txtServerAddress.Text.Trim()))
            {
                bool isLocked = TSR.Core.Constants.ISLOCKEDUSERSETTING;
                bool isServerFound = TSR.Core.Constants.ISSERVERFOUND;
                if (isLocked && isServerFound)
                    btnTestServerUp.Enabled = false;
                else
                    btnTestServerUp.Enabled = true;
                if (!String.IsNullOrEmpty(txtUserName.Text.Trim()))
                {
                    btnOk.Enabled = true;
                }
                else
                    btnOk.Enabled = false;

            }
            else
            {
                btnTestServerUp.Enabled = false;
                btnOk.Enabled = false;
            }

            if (chkNeverAskAgain.Visible)
            {
                //Get do not ask setting again user setting
                bool isNeverAskMeAgain = false;
                if (!string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY)))
                {
                    bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY), out isNeverAskMeAgain);
                }
                if (chkNeverAskAgain.Checked != isNeverAskMeAgain)
                    btnOk.Enabled = true;
            }
        }
        #endregion

        #region Setter-Getter for Core Settings Properties

        /// <summary>
        /// method
        /// SetUserAccount
        /// sets the user account up
        /// </summary>
        private void SetUserAccount()
        {
            SetCustomerNo();
            SetUserName();
            SetPassword();
            SetServerAddres();
            TSR.Core.TSRFacade.SetTSRSSLMode(chkSSLMode.Checked.ToString());
        }
        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// Set user name in case of NONAD mode
        /// </summary>
        private void SetUserName()
        {
            string userName = txtUserName.Text.Trim();
            if (!String.IsNullOrEmpty(userName))
            {
                if (!TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY).Equals(userName, StringComparison.OrdinalIgnoreCase))
                {
                    SyncEngine._IsAccountHasBeenChanged = true;
                    TSR.Core.TSRFacade.SetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY, userName);
                }
            }
        }

        ///// <summary>
        ///// Method 
        ///// GetUserName
        ///// gets the user name
        ///// </summary>
        //private void GetUserName()
        //{
        //    try
        //    {
        //        txtUserName.Text = TSR.Core.TSRFacade.GetCurrentUsername();//TSR.Core.SettingsHelper.TSRUserName;
        //    }
        //    catch (System.Exception ex)
        //    {
        //        Core.Logging.LoggingHandler.LogError(ex);
        //        string message = ResourceManager.GetResourceString("ErrorGettingCurrentUsername", "Error getting current username");
        //        string caption = ResourceManager.GetResourceString("Error", "Error");
        //        MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //}

        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// Method 
        /// GetNONADUserName
        /// gets the user name in case of NONAD mode
        /// </summary>
        private void GetNONADUserName()
        {
            txtUserName.Text = TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY);

        }

        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// SetPassword
        /// Set password in case of NONAD mode
        /// </summary>
        private void SetPassword()
        {
            if (!String.IsNullOrEmpty(txtPassword.Text.Trim()) && isChangePassword)
            {
                if (txtPassword.Text.Trim() != TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY))
                {
                    TSR.Core.TSRFacade.SetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY, Core.UtilityHelper.EncryptString(txtPassword.Text.Trim()));
                }
            }
        }

        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// GetPassword
        /// Get password in case of NONAD mode
        /// </summary>
        private void GetPassword()
        {
            //txtPassword.Text = TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY);
        }

        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// SetCustomerNo
        /// Set customer number in case of NONAD mode
        /// </summary>
        private void SetCustomerNo()
        {
            string value = txtCustomerNo.Text.Trim().Replace("/", "");
            if (!String.IsNullOrEmpty(value))
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(Constants.CONST_CUSTOMERNO_KEY, value);
            }
        }

        //Added by tsrdev1
        //Added datetime 25/02/2011
        /// <summary>
        /// GetCustomerNo
        /// Get customer number in case of NONAD mode
        /// </summary>
        private void GetCustomerNo()
        {
            txtCustomerNo.Text = TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_CUSTOMERNO_KEY);
        }

        /// <summary>
        /// Method 
        /// SetServerAddress
        /// sets the address of the server
        /// </summary>
        private void SetServerAddres()
        {
            if (!String.IsNullOrEmpty(txtServerAddress.Text))
            {
                TSR.Core.SettingsHelper.TSRServerAddress = txtServerAddress.Text;
            }
            if (!String.IsNullOrEmpty(txtWebinterface.Text))
            {
                TSR.Core.SettingsHelper.TSRWebinterface = txtWebinterface.Text;
            }
            //TSR.Core.SettingsHelper.TSRCompanyName = "TSR Company";
        }

        /// <summary>
        /// method
        /// GetServerAddres
        /// gets the address of the server
        /// </summary>
        private void GetServerAddres()
        {
            txtServerAddress.Text = TSR.Core.SettingsHelper.TSRServerAddress;
            txtWebinterface.Text = TSR.Core.SettingsHelper.TSRWebinterface;
        }

        /// <summary>
        /// GetNeverAskMeAgainSetting
        /// </summary>
        private void GetNeverAskMeAgainSetting()
        {
            //Get do not ask setting again user setting
            bool isNeverAskMeAgain = false;
            if (!string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY)))
            {
                bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY), out isNeverAskMeAgain);
            }

            chkNeverAskAgain.Checked = isNeverAskMeAgain;
        }
        /// <summary>
        /// SetNeverAskMeAgainSetting
        /// </summary>
        private void SetNeverAskMeAgainSetting()
        {
            //Save do not ask setting again
            TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSR.Core.Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY, chkNeverAskAgain.Checked.ToString());
        }

        /// <summary>
        /// Method
        /// SetTSRItemsToBeSynchronized
        /// sets the value of the items to be synchronized
        /// </summary>
        private void SetTSRItemsToBeSynchronized()
        {
            //if (chkTSRItems.Checked)
            //{
            TSR.Core.SettingsHelper.SynchronizeTSREntries = chkTSRItems.Checked;
            TSR.Core.SettingsHelper.SynchronizeTSRSetupData = chkSetupData.Checked;
            //}
        }

        /// <summary>
        /// Method
        /// GetTSRItemsToBeSynchronized
        /// Gets the TSR Items to be synchronized
        /// </summary>
        private void GetTSRItemsToBeSynchronized()
        {

            chkTSRItems.Checked = TSR.Core.SettingsHelper.SynchronizeTSREntries;
            chkSetupData.Checked = TSR.Core.SettingsHelper.SynchronizeTSRSetupData;

        }


        /// <summary>
        /// Method 
        /// SetOutlookFolder
        /// stes the forlder for Outlook
        /// </summary>
        private void SetOutlookFolder()
        {
            if (cmbOutlookFloder.SelectedIndex > -1)
            {
                if (cmbOutlookFloder.SelectedItem != null)
                {
                    Core.OutlookMAPIFolder _folder = cmbOutlookFloder.SelectedItem as Core.OutlookMAPIFolder;
                    if (_folder != null)
                    {
                        TSR.Core.SettingsHelper.SetTSROutlookFolderToSync(_folder.EntryID + Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR + _folder.FolderName);
                    }
                }
            }
        }

        /// <summary>
        /// Method
        /// GetOutlookFolder
        /// gets the outlook folder
        /// and updates it in the form's combo box
        /// </summary>
        private void GetOutlookFolder()
        {
            //if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync()))
            //{
            MAPIFolder _appointmentFolder = Core.OutlookHelper.UserSelectedAppointmentFolderForSync;

            if (_appointmentFolder != null)
            {
                cmbOutlookFloder.SelectedValue = _appointmentFolder.EntryID;
                //Core.OutlookHelper.AppointmentFolder = _appointmentFolder;
            }

            //String _folderEntityID = String.Empty;
            //String _folderName = String.Empty;
            //String[] _list = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.TSROutlookFolderToSync, Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);

            //if (_list != null && _list.Length > 0)
            //{
            //    _folderEntityID = _list[0];
            //    if (_list.Length > 1)
            //    {
            //        _folderName = _list[1];
            //    }
            //}

            //bool objectInList = false;
            //foreach (Core.OutlookMAPIFolder folder in cmbOutlookFloder.Items)
            //{
            //    if (folder.EntryID == _folderEntityID)
            //    {
            //        objectInList = true;
            //        break;
            //    }
            //}

            //MAPIFolder _appointmentFolder = null;
            //if (!String.IsNullOrEmpty(_folderEntityID) && objectInList)
            //{

            //    _appointmentFolder = Core.OutlookHelper.GetFolderByEntryID(_folderEntityID.ToString());
            //    if (_appointmentFolder == null)
            //        objectInList = false;

            //}
            //else if (_appointmentFolder == null && !String.IsNullOrEmpty(_folderName) && !objectInList)
            //{
            //    try
            //    {
            //        _appointmentFolder = Core.OutlookHelper.AddFolder(_folderName);
            //        if (_appointmentFolder != null)
            //        {
            //            BindFolders();
            //        }
            //    }
            //    catch (System.Exception exp)
            //    {
            //        Core.Logging.LoggingHandler.LogError(exp);
            //    }
            //}

            //if (_appointmentFolder != null)
            //{
            //    cmbOutlookFloder.SelectedValue = _appointmentFolder.EntryID;
            //    Core.OutlookHelper.AppointmentFolder = _appointmentFolder;
            //}
            //}
        }

        /// <summary>
        /// Method
        /// SetSyncRange
        /// sets the Sync. Range
        /// </summary>
        private void SetSyncRange()
        {

            //if (cmbSyncRangeIndex.SelectedIndex >= 0)
            //{
            Int32 index = -1;

            if (Int32.TryParse(txtSyncRangeIndex.Text, out  index))
            {
                TSR.Core.SettingsHelper.TSRSyncRangeIndex = index;
            }
            if (Int32.TryParse(txtSyncRangeIndexFuture.Text, out  index))
            {
                TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture = index;
            }

            if (cmbSyncRangePeriod.SelectedIndex >= 0)
            {
                TSR.Core.SettingsHelper.TSRSyncRangePeriod = cmbSyncRangePeriod.SelectedValue.ToString();
            }

            if (cmbSyncRangePeriodFuture.SelectedIndex >= 0)
            {
                TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture = cmbSyncRangePeriodFuture.SelectedValue.ToString();
            }
            Core.IMemoryBox memBox = new MemoryBox();
            //ISyncEngineCheckListTimeEntry checkListTiemEntry = new CheckListTimeEntry();
            //Core.Synchronization.Synchronizer.checkListTiemEntry = checkListTiemEntry;
            //Core.Synchronization.Synchronizer.SynchronizeByTimer(memBox);
            TSR.Shell.Synchronizer.checkListTiemEntry = new TSR.Shell.CheckListTimeEntry();
            TSR.Shell.Synchronizer.SynchronizeByTimer(memBox);

            //}
        }

        /// <summary>
        /// Method
        /// GetSyncRange
        /// gets the sync range 
        /// and if the range is not null 
        /// then it is set in the combo box
        /// </summary>
        private void GetSyncRange()
        {


            if (TSR.Core.SettingsHelper.TSRSyncRangeIndex != -1)
            {
                txtSyncRangeIndex.Text = TSR.Core.SettingsHelper.TSRSyncRangeIndex.ToString();
            }

            if (TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture != -1)
            {
                txtSyncRangeIndexFuture.Text = TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture.ToString();
            }
            if (TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture != -1)
            {
                txtWebinterface.Text = TSR.Core.SettingsHelper.TSRWebinterface.ToString();
            }


            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRSyncRangePeriod))
            {
                cmbSyncRangePeriod.SelectedValue = TSR.Core.SettingsHelper.TSRSyncRangePeriod;
            }

            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture))
            {
                cmbSyncRangePeriodFuture.SelectedValue = TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture;
            }
        }


        /// <summary>
        /// Method 
        /// SetWhatToSync
        /// sets up things to be set up
        /// </summary>
        private void SetWhatToSync()
        {
            SetTSRItemsToBeSynchronized();
            SetOutlookFolder();
        }

        /// <summary>
        /// Method
        /// SetAutoSync
        /// sets the AutoSync function
        /// </summary>
        /// <returns></returns>
        private bool SetAutoSync()
        {
            string pleaseSelectASpecificAutomaticSyncOptionMsgCaption = Core.ResourceManager.GetResourceString("PleaseSelectASpecificAutomaticSyncOptionMsgCaption", "Automatic Synchronization Setting");
            if (rbtnNotAutoSync.Checked)
            {
                TSR.Core.SettingsHelper.TSRAutoSyncOption = false;
            }
            else if (rbtnAutoSunc.Checked)
            {
                TSR.Core.SettingsHelper.TSRAutoSyncOption = true;
                if ((!rbtnAutoSyncEveryTiime.Checked) && (!rbtnAutoSuncClosingTIme.Checked) && (!rbtnAutoSyncPeriod.Checked))
                {
                    string pleaseSelectASpecificAutomaticSyncOptionMsg = Core.ResourceManager.GetResourceString("PleaseSelectASpecificAutomaticSyncOptionMsg", "Please select a specific automatic synchronization option");
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = pleaseSelectASpecificAutomaticSyncOptionMsgCaption,
                        MessageDetail = pleaseSelectASpecificAutomaticSyncOptionMsg,
                        Priority = 0
                    });
                    MessageBox.Show(pleaseSelectASpecificAutomaticSyncOptionMsg, pleaseSelectASpecificAutomaticSyncOptionMsgCaption, MessageBoxButtons.OK);
                    tbcntSettings.SelectedTab = tpAutomaticSync;
                    txtAutoSyncIndex.Focus();
                    return false;
                }
            }
            TSR.Core.SettingsHelper.TSRAutoSyncWhenOutlookOpen = rbtnAutoSunc.Checked && rbtnAutoSyncEveryTiime.Checked;
            TSR.Core.SettingsHelper.TSRAutoSyncWhenOutlookClose = rbtnAutoSunc.Checked && rbtnAutoSuncClosingTIme.Checked;
            TSR.Core.SettingsHelper.TSRAutoSyncPeriodOption = rbtnAutoSunc.Checked && rbtnAutoSyncPeriod.Checked;
            Int32 index = -1;
            if (TSR.Core.SettingsHelper.TSRAutoSyncPeriodOption)
            {
                //string message = Core.ResourceManager.GetResourceString("PleaseInputValidAutoSyncIndex", "Please input a integer between 10 and 99 into field Interval");
                string message = Core.ResourceManager.GetResourceString("InputValidTimeInterval", "Synchronization value must be minimum 5 minutes");
                if (!string.IsNullOrEmpty(txtAutoSyncIndex.Text))//(cmbAutoSyncIndex.SelectedIndex >= 0)
                {
                    if (!Int32.TryParse(txtAutoSyncIndex.Text, out index))//cmbAutoSyncIndex.Text, out index))
                    {
                        //TO DO: throw an exception..                 
                    }
                    //tsrdev
                    if ((index < TSR.Core.SettingsHelper.TSRAUTO_SYNC_INDEX_MINIMUM && Convert.ToInt32(cmbAutoSyncPeriod.SelectedValue) == 0) || (index < 1 && Convert.ToInt32(cmbAutoSyncPeriod.SelectedValue) == 1))
                    {
                        Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = pleaseSelectASpecificAutomaticSyncOptionMsgCaption,
                            MessageDetail = message,
                            Priority = 0
                        });
                        MessageBox.Show(message, pleaseSelectASpecificAutomaticSyncOptionMsgCaption, MessageBoxButtons.OK);
                        tbcntSettings.SelectedTab = tpAutomaticSync;
                        txtAutoSyncIndex.Focus();
                        return false;
                    }

                    TSR.Core.SettingsHelper.TSRAutoSyncIndex = index;
                    if (cmbAutoSyncPeriod.SelectedIndex >= 0)
                    {
                        TSR.Core.SettingsHelper.TSRAutoSyncPeriod = Convert.ToInt32(cmbAutoSyncPeriod.SelectedValue);//cmbAutoSyncPeriod.SelectedItem.ToString();
                    }
                }
                else
                {
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = pleaseSelectASpecificAutomaticSyncOptionMsgCaption,
                        MessageDetail = message,
                        Priority = 0
                    });
                    MessageBox.Show(message, pleaseSelectASpecificAutomaticSyncOptionMsgCaption, MessageBoxButtons.OK);
                    tbcntSettings.SelectedTab = tpAutomaticSync;
                    txtAutoSyncIndex.Focus();
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Method
        /// GetAutoSync
        /// gets the Auto Sync. Data
        /// </summary>
        private void GetAutoSync()
        {
            bool _options = TSR.Core.SettingsHelper.TSRAutoSyncOption;

            if (!_options) // auto sync. is not selected
            {
                rbtnNotAutoSync.Checked = true;
                gbAutoSync.Enabled = false;
                gbAutoSync.Visible = false;
            }
            else // auto sync. is on
            {
                rbtnAutoSunc.Checked = true;
                gbAutoSync.Enabled = true;
                gbAutoSync.Visible = true;
                if (TSR.Core.SettingsHelper.TSRAutoSyncWhenOutlookOpen)
                {
                    rbtnAutoSyncEveryTiime.Checked = true;
                }
                if (TSR.Core.SettingsHelper.TSRAutoSyncWhenOutlookClose)
                {
                    rbtnAutoSuncClosingTIme.Checked = true;
                }
                if (TSR.Core.SettingsHelper.TSRAutoSyncPeriodOption) //auto sync. period is selected
                {
                    rbtnAutoSyncPeriod.Checked = true;
                    if (TSR.Core.SettingsHelper.TSRAutoSyncIndex != -1)
                    {
                        txtAutoSyncIndex.Text = TSR.Core.SettingsHelper.TSRAutoSyncIndex.ToString();
                        //cmbAutoSyncIndex.SelectedValue = TSR.Core.SettingsHelper.TSRAutoSyncIndex.ToString();
                        //if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRAutoSyncPeriod))
                        //{
                        cmbAutoSyncPeriod.SelectedValue = TSR.Core.SettingsHelper.TSRAutoSyncPeriod.ToString();
                        //}
                    }
                }
            }
        }
        /// <summary>
        /// Method
        /// SetMisc
        /// Sets up the Miscellanious data
        /// </summary>
        private bool SetMisc()
        {
            TSR.Core.SettingsHelper.TSRMiscLaunch = chkMiscLaunch.Checked;
            TSR.Core.SettingsHelper.TSRDontShowAgain = chbDontshowagain.Checked;
            TSR.Core.SettingsHelper.TSRDoNotRetrieveSettingsServer = chbDoNotRetrieveSettings.Checked;
            TSR.Core.SettingsHelper.TSRMiscNotSyncCompletedData = chkMiscNotSyncCompletedData.Checked;
            TSR.Core.SettingsHelper.TSRMiscNotSyncTECreatedViaWeb = chkMiscNotSyncTECreatedViaWeb.Checked;
            TSR.Core.SettingsHelper.TSRMiscSyncRemovedData = chkMiscRecreateDeletedTSRAppointment.Checked;

            TSR.Core.SettingsHelper.TSRDisplayTooltip = chkDisplayTooltip.Checked;

            if(cbbDateFormat.SelectedIndex > -1)
                TSR.Core.SettingsHelper.TSRDateFormat = cbbDateFormat.SelectedValue.ToString();
            if (cbbTimeFormat.SelectedIndex > -1)
                TSR.Core.SettingsHelper.TSRTimeFormat = cbbTimeFormat.SelectedValue.ToString();

            TSR.Core.SettingsHelper.TSRListTimeEntriesOutlookUserAgent = int.Parse(cbxOutUserAgent.SelectedValue.ToString());

            Int32 index = -1;

            if (chkMiscRecreateDeletedTSRAppointment.Checked)
            {
                string pleaseSelectAValidNumberMsg = Core.ResourceManager.GetResourceString("PleaseInputAValidNumberMsg", "Please input a valid number");

                if ((Int32.TryParse(txtMiscPastIndex.Text, out index)) && (index >= 0))
                    TSR.Core.SettingsHelper.TSRMiscPastIndex = index;
                else
                {
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = pleaseSelectAValidNumberMsg,
                        Priority = 0
                    });
                    MessageBox.Show(pleaseSelectAValidNumberMsg);
                    tbcntSettings.SelectedTab = tpMisc;
                    txtMiscPastIndex.Focus();
                    return false;
                }
                index = -1;
                if ((Int32.TryParse(txtMiscFutureIndex.Text, out index)) && (index >= 0))
                    TSR.Core.SettingsHelper.TSRMiscFutureIndex = index;
                else
                {
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = pleaseSelectAValidNumberMsg,
                        Priority = 0
                    });
                    MessageBox.Show(pleaseSelectAValidNumberMsg);
                    tbcntSettings.SelectedTab = tpMisc;
                    txtMiscFutureIndex.Focus();
                    return false;
                }
                if (cmbMiscPastPeriod.SelectedIndex >= 0)
                    TSR.Core.SettingsHelper.TSRMiscPastPeriod = cmbMiscPastPeriod.SelectedValue.ToString();

                if (cmbMiscFuturePeriod.SelectedIndex >= 0)
                    TSR.Core.SettingsHelper.TSRMiscFuturePeriod = cmbMiscFuturePeriod.SelectedValue.ToString();
            }
            if (cmbPreferredLanguage.SelectedIndex > -1)
            {
                Language lang = cmbPreferredLanguage.SelectedItem as Language;
                if (lang != null)
                {
                    TSR.Core.SettingsHelper.TSRLanguageId = TSRFacade.GetLanguageIDByLanguageName(lang.LanguageName);
                    TSR.Core.SettingsHelper.TSRLanguageName = lang.LanguageName;
                }
                else if (cmbPreferredLanguage.SelectedIndex >= 0)
                {
                    TSR.Core.SettingsHelper.TSRLanguageId = TSRFacade.GetLanguageIDByLanguageName(cmbPreferredLanguage.SelectedValue.ToString());
                    TSR.Core.SettingsHelper.TSRLanguageName = cmbPreferredLanguage.SelectedValue.ToString();
                }
                    
                LanguageResourcesList list = new LanguageResourcesList();
                list = TSR.Core.TSRFacade.GetLanguageResourcesByLanguageName(TSR.Core.SettingsHelper.TSRLanguageName);
                if (list != null && list.Count <= 0)
                {
                    string languageResourceMissingWarningMsg = Core.ResourceManager.GetResourceString("OUALanguageResourceMissingWarningMsg", "No resources available locally for the selected language. Please synchronize language resources.");
                    string languageResourceMissingWarningMsgCaption = Core.ResourceManager.GetResourceString("OUALanguageResourceMissingWarningMsgCaption", "Language Resource Missing");
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = languageResourceMissingWarningMsgCaption,
                        MessageDetail = languageResourceMissingWarningMsg,
                        Priority = 0
                    });
                    MessageBox.Show(languageResourceMissingWarningMsg, languageResourceMissingWarningMsgCaption);
                }

                //TSR.Core.TSRFacade.FetchAndProcessResourceData();
            }
            return true;
            //TSR.Core.SettingsHelper.TSRPluginDBConnectionString = txtConnectionString.Text;
        }

        /// <summary>
        /// Method
        /// GetMisc
        /// Gets the miscellanious data
        /// </summary>
        private void GetMisc()
        {
            chkMiscLaunch.Checked = TSR.Core.SettingsHelper.TSRMiscLaunch;
            chbDontshowagain.Checked = TSR.Core.SettingsHelper.TSRDontShowAgain;
            chkMiscNotSyncCompletedData.Checked = TSR.Core.SettingsHelper.TSRMiscNotSyncCompletedData;
            chkMiscNotSyncTECreatedViaWeb.Checked = TSR.Core.SettingsHelper.TSRMiscNotSyncTECreatedViaWeb;
            chbDoNotRetrieveSettings.Checked = TSR.Core.SettingsHelper.TSRDoNotRetrieveSettingsServer;
            chkMiscRecreateDeletedTSRAppointment.Checked = TSR.Core.SettingsHelper.TSRMiscSyncRemovedData;
            chkDisplayTooltip.Checked = TSR.Core.SettingsHelper.TSRDisplayTooltip;

            cbbDateFormat.SelectedValue = ReverseToHTMLCode(TSR.Core.SettingsHelper.TSRDateFormat);

            cbxOutUserAgent.SelectedValue = TSR.Core.SettingsHelper.TSRListTimeEntriesOutlookUserAgent.ToString();

            string tempTimeFormat = TSR.Core.SettingsHelper.TSRTimeFormat;
            if (tempTimeFormat == "hh:mm:ss tt")
            {
                tempTimeFormat = "h:mm:ss tt";
            }

            cbbTimeFormat.SelectedValue = TSR.Core.SettingsHelper.TSRTimeFormat;

            if (TSR.Core.SettingsHelper.TSRMiscPastIndex != -1)
            {
                txtMiscPastIndex.Text = TSR.Core.SettingsHelper.TSRMiscPastIndex.ToString();
            }

            if (TSR.Core.SettingsHelper.TSRMiscFutureIndex != -1)
            {
                txtMiscFutureIndex.Text = TSR.Core.SettingsHelper.TSRMiscFutureIndex.ToString();
            }

            if (TSR.Core.SettingsHelper.TSRMiscFutureIndex != -1)
            {
                txtWebinterface.Text = TSR.Core.SettingsHelper.TSRWebinterface.ToString();
            }


            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRMiscPastPeriod))
            {
                cmbMiscPastPeriod.SelectedValue = TSR.Core.SettingsHelper.TSRMiscPastPeriod;
            }

            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRMiscFuturePeriod))
            {
                cmbMiscFuturePeriod.SelectedValue = TSR.Core.SettingsHelper.TSRMiscFuturePeriod;
            }

            //txtConnectionString.Text = TSR.Core.SettingsHelper.TSRPluginDBConnectionString;
            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRLanguageName))
            {
                Language lang = new Language();
                lang.LanguageID = TSR.Core.SettingsHelper.TSRLanguageId;
                lang.LanguageName = TSR.Core.SettingsHelper.TSRLanguageName;
                cmbPreferredLanguage.SelectedItem = lang;
                //cmbPreferredLanguage.SelectedValue = TSR.Core.SettingsHelper.TSRLanguageId;
            }
        }

        private void GetConnectionSettings()
        {
            SettingsHelper.ProxyTypeEnum type = SettingsHelper.ProxyType;

            switch (type)
            {
                case SettingsHelper.ProxyTypeEnum.NoProxy:
                    txtProxyHost.Enabled = false;
                    txtProxyPort.Enabled = false;
                    chkProxyAuthentication.Enabled = false;
                    txtProxyUsername.Enabled = false;
                    txtProxyPassword.Enabled = false;

                    cbbProxyType.SelectedIndex = (int)type;

                    break;
                case SettingsHelper.ProxyTypeEnum.SystemProxy:
                    txtProxyHost.Enabled = false;
                    txtProxyPort.Enabled = false;
                    cbbProxyType.SelectedIndex = (int)type;
                    break;

                case SettingsHelper.ProxyTypeEnum.Https:
                    txtProxyHost.Enabled = true;
                    txtProxyPort.Enabled = true;
                    txtProxyHost.Text = SettingsHelper.ProxyHost;
                    txtProxyPort.Text = SettingsHelper.ProxyPort;
                    cbbProxyType.SelectedIndex = (int)type;
                    break;

                case SettingsHelper.ProxyTypeEnum.Socks4:
                case SettingsHelper.ProxyTypeEnum.Socks5:
                    txtProxyHost.Enabled = true;
                    txtProxyPort.Enabled = true;
                    txtProxyHost.Text = SettingsHelper.ProxyHost;
                    txtProxyPort.Text = SettingsHelper.ProxyPort;
                    radProxySocks4.Enabled = true;
                    radProxySocks5.Enabled = true;

                    cbbProxyType.SelectedIndex = 3; //SOCKS
                    break;
            }

            string username = SettingsHelper.ProxyUsername;
            string pass = SettingsHelper.ProxyPassword;

            txtProxyUsername.Enabled = false;
            txtProxyPassword.Enabled = false;

            if (type != SettingsHelper.ProxyTypeEnum.NoProxy)
            {
                if (string.IsNullOrEmpty(username) && string.IsNullOrEmpty(pass))
                {
                    chkProxyAuthentication.Checked = false;
                }
                else
                {
                    chkProxyAuthentication.Checked = SettingsHelper.ProxyAuthenticationEnable;
                    if (chkProxyAuthentication.Checked)
                    {
                        txtProxyUsername.Text = SettingsHelper.ProxyUsername;
                        txtProxyPassword.Text = SettingsHelper.ProxyPassword;
                        txtProxyUsername.Enabled = chkProxyAuthentication.Enabled;
                        txtProxyPassword.Enabled = chkProxyAuthentication.Enabled;
                    }
                }
            }
            if (type == SettingsHelper.ProxyTypeEnum.Socks4)
                radProxySocks4.Checked = true;
            else if (type == SettingsHelper.ProxyTypeEnum.Socks5)
                radProxySocks5.Checked = true;

            chkProxyAutoSwitch.Checked = SettingsHelper.ProxyAutoSwitch;
            txtConnectionTimeOutValue.Text = SettingsHelper.ConnectionTimeOut.ToString();
        }

        private bool SetConnectionSettings()
        {
            SettingsHelper.ProxyType = (SettingsHelper.ProxyTypeEnum)cbbProxyType.SelectedIndex;

            int timeOutValue = 0;
            if (int.TryParse(txtConnectionTimeOutValue.Text.Trim(), out timeOutValue))
                SettingsHelper.ConnectionTimeOut = timeOutValue;

            if (radProxySocks4.Enabled && radProxySocks5.Enabled)
            {
                if (radProxySocks4.Checked) SettingsHelper.ProxyType = SettingsHelper.ProxyTypeEnum.Socks4;
                else if (radProxySocks5.Checked) SettingsHelper.ProxyType = SettingsHelper.ProxyTypeEnum.Socks5;
            }
            if (SettingsHelper.ProxyType == SettingsHelper.ProxyTypeEnum.NoProxy)
            {
                SettingsHelper.ProxyHost = string.Empty;
                SettingsHelper.ProxyPort = string.Empty;
                SettingsHelper.ProxyUsername = string.Empty;
                SettingsHelper.ProxyPassword = string.Empty;
                SettingsHelper.ProxyAuthenticationEnable = false;
                SettingsHelper.ProxyAutoSwitch = false;

                return true;
            }
            if (SettingsHelper.ProxyType == SettingsHelper.ProxyTypeEnum.SystemProxy)
            {
                SettingsHelper.ProxyHost = string.Empty;
                SettingsHelper.ProxyPort = string.Empty;
            }
            else
            {
                SettingsHelper.ProxyHost = txtProxyHost.Text.Trim();
                SettingsHelper.ProxyPort = txtProxyPort.Text.Trim();
            }
            string username = txtProxyUsername.Text.Trim();
            string password = txtProxyPassword.Text;
            if (chkProxyAuthentication.Checked && (!string.IsNullOrEmpty(username) || !string.IsNullOrEmpty(password)))
            {
                SettingsHelper.ProxyUsername = username;
                SettingsHelper.ProxyPassword = password;
                SettingsHelper.ProxyAuthenticationEnable = true;
            }
            else
            {
                SettingsHelper.ProxyUsername = string.Empty;
                SettingsHelper.ProxyPassword = string.Empty;
                SettingsHelper.ProxyAuthenticationEnable = false;
            }

            SettingsHelper.ProxyAutoSwitch = chkProxyAutoSwitch.Checked;

            return true;
        }

        #endregion

        #region Populate Methods

        /// <summary>
        /// Method
        /// AddDataInList
        /// Adds data in the list
        /// </summary>
        /// <param name="_arrayList"></param>
        /// <param name="data"></param>
        private void AddDataInList(ArrayList _arrayList, object data)
        {
            _arrayList.Add(data);
        }


        /// <summary>
        /// Methods 
        /// FillComboBox
        /// Fills the comboboxes with data
        /// </summary>
        /// <param name="_comboBox"></param>
        /// <param name="_arrayList"></param>
        private void FillComboBox(ComboBox _comboBox, ArrayList _arrayList)
        {
            BindingManagerBase _bindMB = _comboBox.BindingContext[_arrayList];
            _bindMB.SuspendBinding();
            _bindMB.ResumeBinding();
            _comboBox.DataSource = _arrayList;
        }

        /// <summary>
        /// Method
        /// FillComboBox
        /// fills the combo box 
        /// depending on the out look folder list
        /// </summary>
        /// <param name="_comboBox"></param>
        /// <param name="_outlookFolderList"></param>
        private void FillComboBox(ComboBox _comboBox, TSR.Core.OutlookMAPIFolderList _outlookFolderList)
        {

            //bool _selected = false;

            ///Change the filling options of Appointment Folder
            _comboBox.DataSource = _outlookFolderList;
            _comboBox.DisplayMember = "FolderName";
            _comboBox.ValueMember = "EntryID";

            //foreach (TSR.Core.OutlookMAPIFolder _outlookMAPIFolder in _outlookFolderList)
            //{

            //    _comboBox.Items.Add(_outlookMAPIFolder.FolderName);

            //    //if (!_selected)
            //    //{
            //    //    _comboBox.SelectedValue = _outlookMAPIFolder.FolderName;
            //    //    _selected = true;
            //    //}

            //}
        }

        /// <summary>
        /// Method
        /// FillIndex
        /// fills the index list for a combo box
        /// </summary>
        /// <param name="_comboBox"></param>
        //private void FillIndex(ComboBox _comboBox)
        //{
        //    NameValueCollection collection = Core.SettingsHelper.GetAutoSyncIndexes();
        //    UIHelper.FillComboBoxWithNameValueCollection(_comboBox, collection);
        //    //ArrayList _indexOptionsList = new ArrayList();
        //    //AddDataInList(_indexOptionsList, "1");
        //    //AddDataInList(_indexOptionsList, "2");
        //    //AddDataInList(_indexOptionsList, "3");
        //    //AddDataInList(_indexOptionsList, "4");
        //    //AddDataInList(_indexOptionsList, "5");
        //    //AddDataInList(_indexOptionsList, "10");
        //    //AddDataInList(_indexOptionsList, "15");
        //    //AddDataInList(_indexOptionsList, "20");
        //    //AddDataInList(_indexOptionsList, "25");
        //    //FillComboBox(_comboBox, _indexOptionsList);
        //}

        /// <summary>
        /// Method
        /// FillPreferredOLanguages
        /// binds the data to preferred languages field
        /// </summary>
        private void FillPreferredOLanguages()
        {
            List<Language> preferredlanguages = TSRFacade.GetPreferredLanguages();
            string currentLanguageName = TSR.Core.SettingsHelper.TSRLanguageName;
            currentLanguageName = currentLanguageName.Replace("&#47;", "/");
            //string currentLanguageID = TSR.Core.SettingsHelper.TSRLanguageId;
            UIHelper.FillComboBox(cmbPreferredLanguage, preferredlanguages, "LanguageName", "LanguageName", null, false);
            //cmbPreferredLanguage.SelectedText = currentLanguageName;
            if (cmbPreferredLanguage.Items.Count > 0)
            {
                for (int i = 0; i < cmbPreferredLanguage.Items.Count; i++)
                {
                    Language lang = cmbPreferredLanguage.Items[i] as Language;
                    if (lang.LanguageName.Equals(currentLanguageName))
                    //if (lang.LanguageID.Equals(currentLanguageID))
                    {
                        cmbPreferredLanguage.SelectedIndex = i;
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Method 
        /// FillPeriod
        /// fills the interval choice list
        /// </summary>
        /// <param name="_comboBox"></param>
        /// <param name="_isAutoSync"></param>
        private void FillPeriod(ComboBox _comboBox, bool _isAutoSync)
        {
            ArrayList _periodOptionsList = new ArrayList();
            NameValueCollection collection = new NameValueCollection();
            if (_isAutoSync)
            {
                collection = Core.SettingsHelper.GetAutoSyncPeriods();
                //UIHelper.FillComboWithEnum(_comboBox, typeof(TSR.Core.SettingsHelper.PeriodType), string.Empty);
                //return;
                //AddDataInList(_periodOptionsList, "minute(s)");
                //AddDataInList(_periodOptionsList, "hour(s)");
                //AddDataInList(_periodOptionsList, "day(s)");
            }
            else
            {
                collection = Core.SettingsHelper.GetPeriods();
                //_periodOptionsList.Clear();
                //AddDataInList(_periodOptionsList, "hour(s)");
                //AddDataInList(_periodOptionsList, "day(s)");
                //AddDataInList(_periodOptionsList, "week(s)");
                //AddDataInList(_periodOptionsList, "month(s)");
                //AddDataInList(_periodOptionsList, "year(s)");
                //FillComboBox(_comboBox, _periodOptionsList);
            }
            UIHelper.FillComboBoxWithNameValueCollection(_comboBox, collection);
        }

        private void FillTimeFormat()
        {
            NameValueCollection collection = new NameValueCollection();

            collection.Add("NA", ResourceManager.GetResourceString("SelectTimeFormat", "Select Time Format")); //importance: the value must equal "NA"
            collection.Add("HH:mm:ss", ResourceManager.GetResourceString("24hClock", "24h clock"));
            collection.Add("h:mm:ss tt", ResourceManager.GetResourceString("12hClock", "12h clock"));

            UIHelper.FillComboBoxWithNameValueCollection(cbbTimeFormat, collection);
        }

        private void FillDateFormat()
        {
            NameValueCollection collection = new NameValueCollection();

            collection.Add("NA", ResourceManager.GetResourceString("SelectDateFormat", "Select Date Format")); //importance: the value must equal "NA"
            collection.Add("dd-mm-yyyy", "dd-mm-yyyy");
            collection.Add("yyyy-mm-dd", "yyyy-mm-dd");
            collection.Add("MM/dd/yyyy", "mm/dd/yyyy");
            collection.Add("dd.mm.yyyy", "dd.mm.yyyy");
            collection.Add("MM.dd.yyyy", "mm.dd.yyyy");
            collection.Add("yyyy.mm.dd", "yyyy.mm.dd");

            UIHelper.FillComboBoxWithNameValueCollection(cbbDateFormat, collection);
        }

        private static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }
        #endregion

        #region Events - Actions

        /// <summary>
        /// Method (Event Handler)
        /// Settings_FormClosing
        /// handles the Settings form closed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Settings_FormClosing(Object sender, FormClosingEventArgs e)
        {
            CloseWindow();

        }

        /// <summary>
        /// Method
        /// CloseWindow
        /// handles details while closing the window
        /// </summary>
        private void CloseWindow()
        {
            //dispose the instance
            if (instance != null)
            {
                instance.Dispose();
                instance = null;
            }

            //free resources related to this class
            if (this != null)
            {
                try
                {
                    this.Close();
                    this.Dispose();
                }
                catch (System.Exception ex)
                {
                    Debug.WriteLine(ex.StackTrace);
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }
        }

        /// <summary>
        /// Method
        /// btnCancel_Click
        /// handles cancell button click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(Screen.PrimaryScreen.WorkingArea.Width.ToString() + ", " + Screen.PrimaryScreen.WorkingArea.Height.ToString());
            CloseWindow();
        }
        /// <summary>
        /// Method        
        /// Check change data in form setting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public bool CheckChangeDataInSetting()
        {
            try
            {
                if (userSettingListData.Count == 0)
                {
                    foreach (UserSettings obj in TSR.Core.TSRFacade.GetUserSettingsList())
                    {
                        userSettingListData.Add(obj);
                    }
                }
                Core.OutlookMAPIFolder _folder = cmbOutlookFloder.SelectedItem as Core.OutlookMAPIFolder;
                string currentCalendarSetting = string.Empty;
                string calendarSettingOnServer = TSR.Core.TSRFacade.GetCalendarSettingFromServer();
                if (_folder != null)
                {
                    currentCalendarSetting = _folder.EntryID + Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR + _folder.FolderName;
                }
                if (!((string.IsNullOrEmpty(currentCalendarSetting) && string.IsNullOrEmpty(calendarSettingOnServer)) || (!string.IsNullOrEmpty(currentCalendarSetting) && !string.IsNullOrEmpty(calendarSettingOnServer) && (currentCalendarSetting == calendarSettingOnServer))))
                    return true;
                if (userSettingListData.Count > 0)
                {
                    foreach (UserSettings objUser in userSettingListData)
                    {
                        switch (objUser.Key.ToString())
                        {
                            case (Core.SettingsHelper.TSRAUTO_SYNC_INDEX):
                                {
                                    if (txtAutoSyncIndex.Text != "")
                                    {
                                        if (objUser.Value.ToString() != txtAutoSyncIndex.Text.ToString().Trim() && Convert.ToInt32(txtAutoSyncIndex.Text.ToString()) > 0)
                                        {
                                            return true;
                                            //break;
                                        }
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNCHRONIZE_TSRSETUP_DATA:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkSetupData.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNCHRONIZE_TSRENTRIES:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkTSRItems.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNC_RANGE_INDEX:
                                {
                                    if (txtSyncRangeIndex.Text != "")
                                    {
                                        if (objUser.Value.ToString() != txtSyncRangeIndex.Text.Trim())
                                        {
                                            return true;
                                            //break;
                                        }
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNC_RANGE_INDEX_FUTURE:
                                {
                                    if (txtSyncRangeIndexFuture.Text != "")
                                    {
                                        if (objUser.Value.ToString() != txtSyncRangeIndexFuture.Text.Trim())
                                        {
                                            return true;
                                            //break;
                                        }
                                    }
                                } break;
                            case Core.SettingsHelper.TSRBTN_AUTO_SYNC_EVERYTIIME:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != rbtnAutoSyncEveryTiime.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_LAUNCH:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkMiscLaunch.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_NOT_SYNC_COMPLETED_DATA:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkMiscNotSyncCompletedData.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_NOT_SYNC_TECREATED_VIA_WEB:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkMiscNotSyncTECreatedViaWeb.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_SYNC_REMOVED_DATA:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != chkMiscRecreateDeletedTSRAppointment.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNC_RANGE_PERIOD:
                                {
                                    if (objUser.Value.ToString() != cmbSyncRangePeriod.SelectedValue.ToString())
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRSYNC_RANGE_PERIOD_FUTURE:
                                {
                                    if (objUser.Value.ToString() != cmbSyncRangePeriodFuture.SelectedValue.ToString())
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRAUTO_SYNC_PERIOD:
                                {
                                    if (objUser.Value.ToString() != cmbAutoSyncPeriod.SelectedValue.ToString())
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_PAST_INDEX:
                                {
                                    if (txtMiscPastIndex.Text != "")
                                    {
                                        if (objUser.Value.ToString() != txtMiscPastIndex.Text.ToString())
                                        {
                                            return true;
                                            //break;
                                        }
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_FUTURE_INDEX:
                                {
                                    if (txtMiscFutureIndex.Text != "")
                                    {
                                        if (objUser.Value.ToString() != txtMiscFutureIndex.Text.ToString())
                                        {
                                            return true;
                                            //break;
                                        }
                                    }
                                } break;
                            case Core.SettingsHelper.TSRAUTO_SYNC_WHEN_OUTLOOK_CLOSE:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != rbtnAutoSuncClosingTIme.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRAUTO_SYNC_PERIOD_OPTION:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != rbtnAutoSyncPeriod.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRAUTO_SYNC_OPTION:
                                {
                                    if (Convert.ToBoolean(objUser.Value.ToString()) != rbtnAutoSunc.Checked)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRLANGUAGE_ID:
                                {
                                    if (objUser.Value.ToString() != TSR.Core.SettingsHelper.TSR_LANGUAGE_ID)
                                    {
                                        return true;
                                        //break;
                                    }
                                } break;
                            case Core.SettingsHelper.TSRMISC_PAST_PERIOD:
                                if (objUser.Value.ToString() != cmbMiscPastPeriod.SelectedValue.ToString())
                                    return true;
                                break;

                            case Core.SettingsHelper.TSRMISC_FUTURE_PERIOD:
                                if (objUser.Value.ToString() != cmbMiscFuturePeriod.SelectedValue.ToString())
                                    return true;
                                break;

                            case Core.SettingsHelper.TSRDISPLAY_TOOLTIP:
                                if (Convert.ToBoolean(objUser.Value.ToString()) != chkDisplayTooltip.Checked)
                                    return true;
                                break;

                            case Core.SettingsHelper.TSRMISC_DATEFORMAT:
                                if (string.IsNullOrEmpty(objUser.Value) || !ReverseToHTMLCode(objUser.Value).Equals(cbbDateFormat.SelectedValue))
                                    return true;
                                break;

                            case Core.SettingsHelper.TSRMISC_TIMEFORMAT:
                                if (string.IsNullOrEmpty(objUser.Value) || !objUser.Value.Equals(cbbTimeFormat.SelectedValue))
                                    return true;
                                break;

                            case SettingsHelper.PROXY_TYPE:
                                if (string.IsNullOrEmpty(objUser.Value) || int.Parse(objUser.Value) != cbbProxyType.SelectedIndex)
                                    return true;
                                break;
                            case SettingsHelper.PROXY_HOST:
                                if (!objUser.Value.Equals(txtProxyHost.Text.Trim()))
                                    return true;
                                break;
                            case SettingsHelper.PROXY_PORT:
                                if (!objUser.Value.Equals(txtProxyPort.Text.Trim()))
                                    return true;
                                break;
                            case SettingsHelper.PROXY_ENABLE_AUTHENTICATION:
                                if (string.IsNullOrEmpty(objUser.Value) || bool.Parse(objUser.Value) != chkProxyAuthentication.Checked)
                                    return true;
                                break;
                            case SettingsHelper.PROXY_USERNAME:
                                if (!objUser.Value.Equals(txtProxyUsername.Text.Trim()))
                                    return true;
                                break;
                            case SettingsHelper.PROXY_PASSWORD:
                                if (!objUser.Value.Equals(txtProxyPassword.Text))
                                    return true;
                                break;
                            case SettingsHelper.PROXY_AUTOSWITCH:
                                if (string.IsNullOrEmpty(objUser.Value) || bool.Parse(objUser.Value) != chkProxyAutoSwitch.Checked)
                                    return true;
                                break;
                            case SettingsHelper.PROXY_CONNECTION_TIMEOUT:
                                if (string.IsNullOrEmpty(objUser.Value) || !objUser.Value.Equals(txtConnectionTimeOutValue.Text.Trim()))
                                    return true;
                                break;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
            return false;
        }
        /// <summary>
        /// Method
        /// btnOk_Click
        /// invoked when the ok button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (!isDisableAddin)
            {
                TSRFacade.bCheckTimer = true;
                bool bCheckSetting = CheckChangeDataInSetting();
                if (bCheckSetting)
                {
                    TSRFacade.bCheckSetting = true;
                }
                if (chbDontshowagain.Checked == true)
                {
                    TSR.Core.SettingsHelper.TSRDontShowAgain = true;
                }
                else
                {
                    TSR.Core.SettingsHelper.TSRDontShowAgain = false;
                }
                bool configurationCorrect = true; // IsServerUp() && IsConnectionStringCorrect();
                bool success = false;
                if (configurationCorrect)
                {
                    success = SetAutoSync();
                    success = success && SetMisc();
                    if (success)
                    {
                        SetUserAccount();
                        SetNeverAskMeAgainSetting();
                        SetWhatToSync();
                        SetSyncRange();
                        SetConnectionSettings();

                        CloseWindow();
                    }
                }
            }
            else
            {
                SetUserAccount();
                SetNeverAskMeAgainSetting();
                SetConnectionSettings();

                CloseWindow();
            }
        }

        /// <summary>
        /// Method
        /// txtPasswd_TextChanged
        /// Text of password field is changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPasswd_TextChanged(object sender, EventArgs e)
        {
            ChangedSettings();
        }

        /// <summary>
        /// Method 
        /// txtServerAddress_TextChanged
        /// text of the server address field is changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtServerAddress_TextChanged(object sender, EventArgs e)
        {
            ChangedSettings();
        }

        /// <summary>
        /// Method
        /// btnTestServerUp_Click
        /// tests whether the server is up
        /// when the button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTestServerUp_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            string error = string.Empty;
            bool serverUp = IsServerUp(ref error);

            this.Cursor = Cursors.Default;

            if (serverUp)
            {
                MessageBox.Show(this, ServerUpSuccessMsg, string.Empty, MessageBoxButtons.OK);
            }
            else
            {
                if (string.IsNullOrEmpty(error))
                {
                    error = ResourceManager.GetResourceString("ServerUpFailureOrProxyWrongMsg", "Server address or proxy configuration is incorrect");

                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = error,
                        Priority = 0
                    });
                    MessageBox.Show(this, error, string.Empty, MessageBoxButtons.OK);
                }
                else
                {
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = error,
                        Priority = 0
                    });
                    MessageBox.Show(this, error, string.Empty, MessageBoxButtons.OK);
                }

            }
        }

        /// <summary>
        /// Method
        /// chkTSRItems_CheckedChanged
        /// state of the check box changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkTSRItems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTSRItems.Checked)
            {
                bool isLocked = TSR.Core.Constants.ISLOCKEDUSERSETTING;
                if (isLocked)
                {
                    rdBtnShowAllFolder.Enabled = false;
                    cmbOutlookFloder.Enabled = false;
                }
                else
                {
                    rdBtnShowAllFolder.Enabled = true;
                    cmbOutlookFloder.Enabled = true;
                }
            }
            else
            {
                rdBtnShowAllFolder.Enabled = false;
                cmbOutlookFloder.Enabled = false;
            }
        }


        /// <summary>
        /// Method
        /// comboBox_KeyPress
        /// gets the key pressed 
        /// when the focus is on 
        /// combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        /// <summary>
        /// Method 
        /// btnHelp_Click
        /// invoked when the Help button is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnHelp_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Method
        /// chkMiscReloadRemovedData_CheckedChanged
        /// this method is invoked when the check box
        /// MiscReloadRemovedData changes state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chkMiscReloadRemovedData_CheckedChanged(object sender, EventArgs e)
        {
            bool isChecked = (chkMiscRecreateDeletedTSRAppointment.Checked);

            bool isLocked = TSR.Core.Constants.ISLOCKEDUSERSETTING;
            if (isLocked)
            {
                txtMiscPastIndex.Enabled = false;
                cmbMiscPastPeriod.Enabled = false;
                txtMiscFutureIndex.Enabled = false;
                //txtWebinterface.Enabled = isChecked;
                cmbMiscFuturePeriod.Enabled = false;
            }
            else
            {
                txtMiscPastIndex.Enabled = isChecked;
                cmbMiscPastPeriod.Enabled = isChecked;
                txtMiscFutureIndex.Enabled = isChecked;
                //txtWebinterface.Enabled = isChecked;
                cmbMiscFuturePeriod.Enabled = isChecked;
            }
        }

        /// <summary>
        /// Method 
        /// rbtnAutoSunc_CheckedChanged
        /// the method is invopked when 
        /// the radio button auto sync changes state
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbtnAutoSunc_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnAutoSunc.Checked)
            {
                gbAutoSync.Enabled = true;
                gbAutoSync.Visible = true;

            }
            else
            {
                gbAutoSync.Enabled = false;
                gbAutoSync.Visible = false;
            }
        }

        /// <summary>
        /// method 
        /// rbtnAutoSyncPeriod_CheckedChanged
        /// when the auto sync period radio button
        /// changes state, this method is invoked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rbtnAutoSyncPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnAutoSyncPeriod.Checked)
            {
                //cmbAutoSyncIndex.Enabled = true;
                txtAutoSyncIndex.Enabled = true;
                cmbAutoSyncPeriod.Enabled = true;
            }
            else
            {
                txtAutoSyncIndex.Enabled = false;
                //cmbAutoSyncIndex.Enabled = false;
                cmbAutoSyncPeriod.Enabled = false;
            }

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            isChangePassword = true;
        }


        #endregion

        #region IDisposable Members

        /// <summary>
        /// Method
        /// IDisposable.Dispose
        /// </summary>
        void IDisposable.Dispose()
        {

            //throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region Variables
        internal Outlook.Application m_Application;
        //private static bool isSettingChanged = false;
        private static Settings instance = null;

        #endregion

        #region Properties

        /// <summary>
        /// property 
        /// Organization
        /// gets the value of TSR.Core.ResourceHelper.Organization
        /// </summary>
        private string Organization
        {
            get
            {
                return TSR.Core.ResourceHelper.Organization;
            }
        }

        /// <summary>
        /// property
        /// Project
        /// gets the value of 
        /// TSR.Core.ResourceHelper.Project
        /// </summary>
        private string Project
        {
            get
            {
                return TSR.Core.ResourceHelper.Project;
            }
        }

        /// <summary>
        /// property
        /// Activity
        /// gets the value of
        /// TSR.Core.ResourceHelper.Activity
        /// </summary>
        private string Activity
        {
            get
            {
                return TSR.Core.ResourceHelper.Activity;
            }
        }

        /// <summary>
        /// Property
        /// HasInctance
        /// checks if the class is instanciated
        /// </summary>
        public static bool HasInstance
        {
            get { return (instance != null); }
        }

        #endregion

        #region Messages

        /// <summary>
        /// property
        /// OrgNotAvailableMsg
        /// gets the message for organization not available dialogue
        /// </summary>
        private string OrgNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.OrgNotAvailableMsg;
            }
        }

        /// <summary>
        /// property
        /// ProjectNotAvailableMsg
        /// gets the  message for 
        /// project not available dialogue
        /// </summary>
        private string ProjectNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.ProjectNotAvailableMsg;
            }
        }

        /// <summary>
        /// Property
        /// ActivityNotAvailableMsg
        /// Activity not available message
        /// </summary>
        private string ActivityNotAvailableMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.ActivityNotAvailableMsg;
            }
        }

        /// <summary>
        /// property
        /// InfomationAlreadyExistInGridMsg
        /// gets the message for duplicate entry in the grid view
        /// </summary>
        private string InfomationAlreadyExistInGridMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.InfomationAlreadyExistInGridMsg;
            }
        }

        /// <summary>
        /// property
        /// ServerUpFailureMsg
        /// message for server up failure dialogue
        /// </summary>
        //private string ServerUpFailureMsg
        //{
        //    get
        //    {
        //        return TSR.Core.ResourceHelper.ServerUpFailureMsg;
        //    }
        //}

        /// <summary>
        /// property 
        /// ServerUpSuccessMsg
        /// server up success dialogue message
        /// </summary>
        private string ServerUpSuccessMsg
        {
            get
            {
                return TSR.Core.ResourceHelper.ServerUpSuccessMsg;
            }
        }


        //private string UsernameOrPassword_FiledEmplyMessage
        //{
        //    get
        //    {
        //        return "Username or password cannot be blank.";
        //    }
        //}

        #endregion

        #region Misc

        /// <summary>
        /// Method
        /// IsServerUp
        /// checks if the server is up
        /// </summary>
        /// <returns>
        /// bool
        /// </returns>
        private bool IsServerUp(ref string error)
        {
            bool serverUp = true;

            try
            {
                SettingsHelper.ProxyTypeEnum proxyType = (SettingsHelper.ProxyTypeEnum)cbbProxyType.SelectedIndex;
                if (radProxySocks4.Enabled && radProxySocks5.Enabled)
                {
                    if (radProxySocks4.Checked) SettingsHelper.ProxyType = SettingsHelper.ProxyTypeEnum.Socks4;
                    else if (radProxySocks5.Checked) SettingsHelper.ProxyType = SettingsHelper.ProxyTypeEnum.Socks5;
                }

                int connectionTimeout = 0;
                if (!int.TryParse(txtConnectionTimeOutValue.Text.Trim(), out connectionTimeout))
                    connectionTimeout = SettingsHelper.ConnectionTimeOut;

                serverUp = TSR.Core.TSRFacade.IsServiceUp(txtServerAddress.Text, ref error, chkSSLMode.Checked,
                    proxyType, txtProxyHost.Text.Trim(), txtProxyPort.Text.Trim(), chkProxyAuthentication.Checked, txtProxyUsername.Text.Trim(), txtProxyPassword.Text,
                    chkProxyAutoSwitch.Checked, connectionTimeout);
            }
            //catch (System.UriFormatException ex)
            //{
            //    serverUp = false;
            //    //error = ResourceManager.GetResourceString("UriFormatExceptionMsg", "Server uri address format is not correct");
            //    error = ResourceManager.GetResourceString("ServerUriOrProxyFormatExceptionMsg", "Server URL or proxy address has format is incorrect");
            //    Core.Logging.LoggingHandler.LogError(ex);
            //}
            catch (System.Exception ex)
            {
                serverUp = false;
                Core.Logging.LoggingHandler.LogError(ex);
            }

            return serverUp;
        }

        private void cmbOutlookFloder_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (toolTip1 == null)
            {
                return;
            }
            if (this.cmbOutlookFloder.SelectedIndex > -1)
            {
                TSR.Core.OutlookMAPIFolder selectedItem = this.cmbOutlookFloder.SelectedItem as TSR.Core.OutlookMAPIFolder;
                if (selectedItem != null)
                {
                    toolTip1.SetToolTip(this.cmbOutlookFloder, selectedItem.FolderName);
                }
            }
        }

        private void txtAutoSyncIndex_TextChanged(object sender, EventArgs e)
        {
            int val;
            if (!int.TryParse(txtAutoSyncIndex.Text, out val))
                txtAutoSyncIndex.Text = string.Empty;
        }

        private void cmbPreferredLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbPreferredLanguage.SelectedItem != null)
            {
                Language lang = cmbPreferredLanguage.SelectedItem as Language;
                TSR.Core.SettingsHelper.TSR_LANGUAGE_ID = lang.LanguageID;
            }
        }
        /// <summary>
        /// Method
        /// IsConnectionStringCorrect
        /// checks if the connectionString is correct
        /// </summary>
        /// <returns></returns>
        //private bool IsConnectionStringCorrect()
        //{
        //    bool connectionStringRight = true;

        //    try
        //    {
        //        //try to open a connection
        //        System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(txtConnectionString.Text);
        //        conn.Open();
        //    }
        //    catch
        //    {
        //        connectionStringRight = false;
        //    }
        //    if (connectionStringRight == false)
        //    {
        //        //on failure let the user know
        //        MessageBox.Show(this, "Connection string invalid.  Could not connect to database.", "", MessageBoxButtons.OK);
        //    }

        //    return connectionStringRight;
        //}

        public void DisableAllTabsExceptUserAccountTab()
        {
            tbcntSettings.TabPages.Remove(tpWhatToSynchronize);
            tbcntSettings.TabPages.Remove(tpAutomaticSync);
            tbcntSettings.TabPages.Remove(tpMisc);
            chbDoNotRetrieveSettings.Visible = false;
            chbDontshowagain.Visible = false;
            isDisableAddin = true;
        }

        #endregion

        private void chkNeverAskAgain_CheckedChanged(object sender, EventArgs e)
        {
            ChangedSettings();
        }

        private void chkDisplayTooltip_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDisplayTooltip.Checked)
                MessageBox.Show(Core.ResourceManager.GetResourceString("TurnOnTooltipWarning", "Warning: Activating tooltips can reduce performance"),
                    Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning"));
        }

        private void cbbProxyType_SelectedIndexChanged(object sender, EventArgs e)
        {
            radProxySocks5.Enabled = false;
            radProxySocks4.Enabled = false;
            //No proxy
            if (cbbProxyType.SelectedIndex == 0)
            {
                txtProxyHost.Enabled = false;
                txtProxyPort.Enabled = false;
                chkProxyAuthentication.Enabled = false;
                chkProxyAuthentication.Checked = false;
                txtProxyUsername.Enabled = false;
                txtProxyPassword.Enabled = false;
                chkProxyAutoSwitch.Enabled = false;
                return;
            }
            chkProxyAutoSwitch.Enabled = true;
            chkProxyAuthentication.Enabled = true;

            //Proxy automatic detection
            if (cbbProxyType.SelectedIndex == 1)
            {
                txtProxyHost.Enabled = false;
                txtProxyPort.Enabled = false;
                return;
            }

            if (cbbProxyType.SelectedIndex == 3) //SOCKS
            {
                radProxySocks5.Enabled = true;
                radProxySocks4.Enabled = true;
                if (!radProxySocks5.Checked && !radProxySocks4.Checked)
                    radProxySocks5.Checked = true;
            }

            txtProxyHost.Enabled = true;
            txtProxyPort.Enabled = true;

            if (chkProxyAuthentication.Checked)
            {
                txtProxyUsername.Enabled = true;
                txtProxyPassword.Enabled = true;
            }
        }

        private void chkProxyAuthentication_CheckedChanged(object sender, EventArgs e)
        {
            txtProxyUsername.Enabled = chkProxyAuthentication.Checked;
            txtProxyPassword.Enabled = chkProxyAuthentication.Checked;
        }

        private void txtCustomerNo_TextChanged(object sender, EventArgs e)
        {
            SetEffectTo(txtServerAddress);
            SetEffectTo(txtWebinterface);
        }

        private void SetEffectTo(TextBox txt)
        {
            string serverAddress = txt.Text.Trim();
            if (serverAddress.EndsWith("/"))
                serverAddress = serverAddress.Remove(serverAddress.Length - 1);

            if (serverAddress.Length > 0)
            {
                string[] pars = serverAddress.Split(new string[] { "/" }, StringSplitOptions.None);
                if (pars.Length >= 2)
                {
                    string host = string.Empty;
                    string service = pars[pars.Length - 1];
                    string oldCustomerNo = pars[pars.Length - 2];

                    for (int i = 0; i < pars.Length; i++)
                    {
                        if (i < pars.Length - 2)
                            host += pars[i] + "/";
                    }

                    string newCustomerNo = txtCustomerNo.Text.Trim().Replace("/", "");

                    txt.Text = host + newCustomerNo + "/" + service;
                }
            }
        }

        private void txtCustomerNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '/')
            {
                e.Handled = true;
            }
        }

        private void rdBtnShowAllFolder_CheckedChanged(object sender, EventArgs e)
        {
            if (rdBtnShowAllFolder.Checked)
            {
                this.Cursor = Cursors.WaitCursor;
                try
                {
                    BindFolders();
                }
                catch
                {
                }
                finally
                {
                    this.Cursor = Cursors.Default;
                }
            }
        }
    }
}