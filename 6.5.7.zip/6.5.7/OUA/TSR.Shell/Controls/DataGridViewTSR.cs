﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Shell.Controls
{
    public class DataGridViewTSR:System.Windows.Forms.DataGridView
    {
        protected override bool ProcessCmdKey(ref System.Windows.Forms.Message msg, System.Windows.Forms.Keys keyData)
        {
            if (keyData == (System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C))
            {
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
