﻿using System;
using System.Windows.Forms;
using TSR.Core;

namespace TSR.Shell.Controls
{
    public class OUAForm : Form
    {
        protected override void OnResizeEnd(EventArgs e)
        {
            base.OnResizeEnd(e);

            string[] newSize = new string[2] { this.ClientSize.Width.ToString(), this.ClientSize.Height.ToString() };
            SettingsHelper.SaveScreenSize(this.Name, newSize);
        }

        protected override void OnLoad(EventArgs e)
        {            
            int[] newSize = SettingsHelper.GetScreenSize(this.Name);
            if(newSize.Length > 0)
                this.ClientSize = new System.Drawing.Size(newSize[0], newSize[1]);

            base.OnLoad(e);
        }
    }
}