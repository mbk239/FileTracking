using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using Core = TSR.Core;
using Entity = TSR.Core.Entity;
using TSR.Core.Entity;
using TSR.Core;
namespace TSR.Shell.Controls
{
    public partial class ucTSRItemList : UserControl
    {        
        private int _selectedColumnIndex;
        private TimeEntryList _sourceTeList = new TimeEntryList();
        private TimeEntryList _checkedTimeEntries = new TimeEntryList();

        private Dictionary<int, bool> order = new Dictionary<int, bool>();

        //Added by tsrdev1
        //Added datetime 21/10/2010
        public delegate void chkSelectCheckedEventHandler();
        public event chkSelectCheckedEventHandler chkSelectChecked;

        public ucTSRItemList()
        {
            InitializeComponent();
        }

        //public void DataSource(Object DataSource)
        //{
        //    PopulateItemsInGrid(DataSource);
        //}
        public bool EnableSelection { get; set; }

        [DefaultValue(false)]
        public bool IsOverwriteTimeEntries { get; set; }        

        public void ToggleAllSelect(bool isSelected)
        {
            double totalDuration = 0;
            if (EnableSelection)
            {
                DataGridViewCheckBoxCell cell;
                int i = 0;
                foreach (DataGridViewRow dgvRow in dgvItems.Rows)
                {
                    cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
                    if (cell != null)
                    {
                        Entity.TimeEntry obj = DataSource[i];//dgvRow.DataBoundItem as Entity.TimeEntry;
                        if (obj != null)
                        {
                            if ((obj.IsChangeAllowed() && !IsOverwriteTimeEntries) || IsOverwriteTimeEntries)
                            {
                                cell.Value = isSelected;
                                if (isSelected)
                                {
                                    totalDuration += double.Parse(obj.Duration);
                                }
                            }
                        }   
                        
                    }
                    i++;
                }
            }
            var tableTotalDuration = this.Parent.Controls["tableTotalDuration"] as TableLayoutPanel;
            if (tableTotalDuration != null)
            {
                var lblTotalDurationSelectedValue = tableTotalDuration.Controls["lblTotalDurationSelectedValue"] as Label;
                if (lblTotalDurationSelectedValue != null)
                {
                    lblTotalDurationSelectedValue.Text = totalDuration.ToString("F2");
                }
            }
            
        }

        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="inCreamental"></param>
        public void SetDataSource(TimeEntryList teList, bool inCremental)
        {
            if (teList == null)
                return;

            dgvItems.AutoGenerateColumns = false;
            PrepareGridView(dgvItems);

            if (!inCremental)
            {
                _sourceTeList.Clear();
            }

            _checkedTimeEntries = new TimeEntryList();            
            //else
            //{
            //    if (CheckedTimeEntries != null && CheckedTimeEntries.Count > 0)
            //    {
            //        foreach (TimeEntry te in CheckedTimeEntries)
            //            _checkedTimeEntries.Add(te);
            //    }
            //}
            foreach (TimeEntry te in teList)
            {
                _sourceTeList.Add(te);
            }
            _sourceTeList.Sort(CompareTimeEntriesWithDefault);
            order[EnableSelection?5:4] = true;

            SetDataSourceWithoutSorting(_sourceTeList);
        }

        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="inCreamental"></param>
        public void SortDataSource(TimeEntryList teList, bool inCremental)
        {
            if (teList == null)
                return;

            _checkedTimeEntries = new TimeEntryList();

            if (CheckedTimeEntries != null && CheckedTimeEntries.Count > 0)
            {
                foreach (TimeEntry te in CheckedTimeEntries)
                    _checkedTimeEntries.Add(te);
            }

            if (!inCremental)
            {
                _sourceTeList.Clear();
            }

            foreach (TimeEntry te in teList)
            {
                _sourceTeList.Add(te);
            }            

            SetDataSourceWithoutSorting(teList);
        }

        //Added by tsrdev1
        //Added datetime 10/11/2010
        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>        
        public void SetDataSourceWithoutSorting(TimeEntryList teList)
        {
            if (teList == null)
                return;            
            if (dgvItems.Rows != null)
            {
                //DataGridViewRowCollection rows = dgvItems.Rows;
                int totalRows = dgvItems.Rows.Count;
                //foreach (DataGridViewRow row in rows)
                //{
                //    dgvItems.Rows.Remove(row);
                //}
                for (int i = totalRows - 1; i > -1; i--)
                {
                    dgvItems.Rows.RemoveAt(i);
                }
            }

            dgvItems.Refresh();

            string dateFormat = string.Empty, timeFormat = string.Empty;
            OutlookHelper.GetDateTimeFormat(out dateFormat, out timeFormat, false);

            foreach (TimeEntry te in teList)
            {
                int index = -1;
                index = dgvItems.Rows.Add(getDataGridRowFromTimeEntry(te, dateFormat, timeFormat));
                if (EnableSelection)
                {
                    bool IsSelected = false;
                    if (_checkedTimeEntries != null && _checkedTimeEntries.Count > 0)
                    {
                        if ((_checkedTimeEntries.Exists(delegate(TimeEntry temp){return te.ID == temp.ID;})) && (IsOverwriteTimeEntries || (!IsOverwriteTimeEntries && te.IsChangeAllowed())))
                            IsSelected = true;
                    }
                    dgvItems.Rows[index].Cells[0].Value = IsSelected;
                }
                if (!IsOverwriteTimeEntries)
                {
                    if (te != null && te.IsDeleted)
                    {
                        DataGridViewLinkCell cell = dgvItems.Rows[index].Cells[TimeEntry.Property_Subject] as DataGridViewLinkCell;
                        if (cell != null)
                        {
                            cell.LinkBehavior = LinkBehavior.NeverUnderline;
                            cell.LinkVisited = false;
                            cell.LinkColor = System.Drawing.Color.Black;
                        }
                    }

                    if (Core.TimeEntryHelper.GetTimeEntryType(te) == TSR.Core.TimeEntryType.MissingCurrentDB)
                        dgvItems.Rows[index].DefaultCellStyle.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_MISSINGDATA_ROW);
                    else if (Core.TimeEntryHelper.GetTimeEntryType(te) == TSR.Core.TimeEntryType.OldDB)
                        dgvItems.Rows[index].DefaultCellStyle.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_OLDDBDATA_ROW);

                    if (te != null && te.IsCreatedViaWeb)
                        dgvItems.Rows[index].DefaultCellStyle.ForeColor = UIHelper.GetColor(UIHelper.BACK_COLOR_ISCREATEDVIAWEB_ROW);

                    if (te.IsRecurring)
                    {
                        TimeEntry teRec = Core.TSRFacade.GetTimeEntryByTSRItemID(te.ID, false, true);
                        if (teRec == null)
                        {
                            dgvItems.Rows[index].DefaultCellStyle.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
                        }
                    }                   
                }                
            }

            _checkedTimeEntries = new TimeEntryList();
        }

        public TimeEntryList DataSource
        {
            get
            {
                //TimeEntryList tel = new TimeEntryList();
                //if (dgvItems.DataSource != null)
                //{
                //   tel = dgvItems.DataSource as TimeEntryList;
                //}
                return _sourceTeList;
            }
            set
            {
                SetDataSource(value, false);
                //dgvItems.AutoGenerateColumns = false;
                //PrepareGridView(dgvItems);
                //if(dgvItems.Rows!=null)
                //    dgvItems.Rows.Clear();
                //foreach (TimeEntry te in value)
                //{
                //    dgvItems.Rows.Add(getDataGridRowFromTimeEntry(te));
                //}
                //_sourceTeList = value;
                //dgvItems.DataSource = value;
            }
        }

        private string[] getDataGridRowFromTimeEntry(TimeEntry te, string dateFormat, string timeFormat)
        {
            //string shortDateFormat = OutlookHelper.shortDate;
            DataGridViewRow dgvRow = dgvItems.RowTemplate;
            string[] row6;
            if (EnableSelection)
            {

                row6 = new string[]
                {
                    Core.Constants.FALSE_IN_LOWER_CHARS,
                    te.Subject,
                    te.OrganizationName, te.ProjectName, te.ActivityName,
                    te.StartTimeStamp.ToString(dateFormat, CultureInfo.InvariantCulture) + " : " + te.StartTimeStamp.ToString(timeFormat),
                    te.EndTimeStamp.ToString(dateFormat, CultureInfo.InvariantCulture) + " : " + te.EndTimeStamp.ToString(timeFormat),
                    te.Duration,
                    te.Status.ToString(), te.SubmitterName
                };
            }
            else
            {

                row6 = new string[]{
                    te.Subject, 
                    te.OrganizationName,                                            
                    te.ProjectName, te.ActivityName, 
                    te.StartTimeStamp.ToString(dateFormat, CultureInfo.InvariantCulture) + " : " + te.StartTimeStamp.ToString(timeFormat),
                    te.EndTimeStamp.ToString(dateFormat, CultureInfo.InvariantCulture) + " : " + te.EndTimeStamp.ToString(timeFormat),
                    te.Duration,
                    te.Status.ToString(),te.SubmitterName};
            }
            return row6;
        }

        public TimeEntryList CheckedTimeEntries
        {
            get
            {
                TimeEntryList tel = new TimeEntryList();
                DataGridViewCheckBoxCell cell;
               
                if (dgvItems.Rows != null)
                {
                    for (int i = 0; i < dgvItems.Rows.Count; i++)
                    {
                        DataGridViewRow dgvRow = dgvItems.Rows[i];
                        cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
                        if (cell != null && Convert.ToBoolean(cell.Value))
                        {
                            Entity.TimeEntry obj = DataSource[i];//dgvRow.DataBoundItem as Entity.TimeEntry;
                            if (obj != null)
                            {
                                tel.Add(obj);
                            }
                        }
                    }
                }
                return tel;
            }
        }

        private void PopulateItemsInGrid(Object DataSource)
        {
            dgvItems.AutoGenerateColumns = false;
            PrepareGridView(dgvItems);
            dgvItems.DataSource = DataSource; // Core.TSRFacade.GetAllTimeEntries(true);
        }

        private void PrepareGridView(DataGridView dgv)
        {
            if (dgv.Columns.Count == 0)
            {
                if (EnableSelection)
                {
                    DataGridViewCheckBoxColumn dgvCheckColumn = GetCheckColumn();
                    dgv.Columns.Add(dgvCheckColumn);
                }

                DataGridViewColumn dgvSubjectColumn;
                if (!IsOverwriteTimeEntries)
                    dgvSubjectColumn = GetSubjectColumn() as DataGridViewLinkColumn;
                else
                    dgvSubjectColumn = GetTextBoxColumn(Core.ResourceHelper.Subject, Entity.TimeEntry.Property_Subject);

                DataGridViewColumn dgvOrganizationColumn = GetTextBoxColumn(Core.ResourceHelper.Organization, Entity.TimeEntry.Property_OrganizationName);
                DataGridViewColumn dgvProjectColumn = GetTextBoxColumn(Core.ResourceHelper.Project, Entity.TimeEntry.Property_ProjectName);
                DataGridViewColumn dgvActivityColumn = GetTextBoxColumn(Core.ResourceHelper.Activity, Entity.TimeEntry.Property_ActivityName);
                //DataGridViewColumn dgvTaskColumn = GetTextBoxColumn(Core.ResourceHelper.Task, Entity.TimeEntry.COL_TASKNAME);
                           
                DataGridViewColumn dgvStartTimeColumn = GetTextBoxColumn(Core.ResourceHelper.StartTime, Entity.TimeEntry.Property_StartTime);                
                DataGridViewColumn dgvEndTimeColumn = GetTextBoxColumn(Core.ResourceHelper.EndTime, Entity.TimeEntry.Property_EndTime);

                DataGridViewColumn dgvDurationColumn = GetTextBoxColumn(Core.ResourceHelper.Duration, Entity.TimeEntry.Property_EndTime);
                
                DataGridViewColumn dgvStatusColumn = GetTextBoxColumn(Core.ResourceHelper.Status, Entity.TimeEntry.Property_Status);
                DataGridViewColumn dgvSubmittedByColumn = GetTextBoxColumn(Core.ResourceHelper.SubmittedBy, Entity.TimeEntry.Property_SubmitterName);

                dgv.Columns.Add(dgvSubjectColumn);
                dgv.Columns.Add(dgvOrganizationColumn);
                dgv.Columns.Add(dgvProjectColumn);
                dgv.Columns.Add(dgvActivityColumn);
                //dgv.Columns.Add(dgvTaskColumn);
                dgv.Columns.Add(dgvStartTimeColumn);
                dgv.Columns.Add(dgvEndTimeColumn);
                dgv.Columns.Add(dgvDurationColumn);
                dgv.Columns.Add(dgvStatusColumn);
                dgv.Columns.Add(dgvSubmittedByColumn);
                
            }            
        }

        private DataGridViewCheckBoxColumn GetCheckColumn()
        {
            DataGridViewCheckBoxColumn checkColumn = new DataGridViewCheckBoxColumn();
            checkColumn.Width = 40;
            checkColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;            
            return checkColumn;
        }
       
        private DataGridViewLinkColumn GetSubjectColumn()
        {
            DataGridViewLinkColumn subjectColumn = new DataGridViewLinkColumn();

            subjectColumn.Name = Entity.TimeEntry.Property_Subject;
            subjectColumn.HeaderText = Core.ResourceHelper.Subject;
            subjectColumn.DataPropertyName = Entity.TimeEntry.Property_Subject;

            subjectColumn.SortMode = DataGridViewColumnSortMode.Programmatic;

            subjectColumn.ActiveLinkColor = Color.White;
            subjectColumn.LinkBehavior = LinkBehavior.SystemDefault;
            subjectColumn.LinkColor = Color.Blue;
            subjectColumn.TrackVisitedState = true;
            subjectColumn.VisitedLinkColor = Color.Black;
            subjectColumn.DefaultCellStyle.NullValue = "[" + Core.ResourceHelper.Untitled + "]";

            return subjectColumn;
        }

        private static DataGridViewTextBoxColumn GetTextBoxColumn(string name, string dataPropertyName)
        {
            DataGridViewTextBoxColumn statusColumn = new DataGridViewTextBoxColumn();
            statusColumn.Name = dataPropertyName;
            statusColumn.HeaderText = name;
            statusColumn.DataPropertyName = dataPropertyName;

            statusColumn.SortMode = DataGridViewColumnSortMode.Programmatic;

            return statusColumn;
        }

        private void dgvItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                if (dgvItems.Columns[e.ColumnIndex].HeaderText == Core.ResourceHelper.Subject)
                {
                    if ((!IsOverwriteTimeEntries) && (DataSource[e.RowIndex] != null && !DataSource[e.RowIndex].IsDeleted))
                        ShowSelectedAppointment(e.RowIndex);
                }
                if (e.ColumnIndex == 0)
                {
                    DataGridViewRow dgvRow = dgvItems.Rows[e.RowIndex];
                    DataGridViewCheckBoxCell cell = dgvRow.Cells[0] as DataGridViewCheckBoxCell;
                    if (cell != null)
                    {
                        Entity.TimeEntry obj = DataSource[e.RowIndex];//dgvRow.DataBoundItem as Entity.TimeEntry;
                        if (obj != null)
                        {
                            if ((obj.IsChangeAllowed() && !IsOverwriteTimeEntries) || IsOverwriteTimeEntries)
                            {
                                bool isChecked = Convert.ToBoolean(cell.Value);
                                cell.Value = !isChecked;
                                if (chkSelectChecked != null)
                                    chkSelectChecked();

                                var tableTotalDuration = this.Parent.Controls["tableTotalDuration"] as TableLayoutPanel;
                                if (tableTotalDuration != null)
                                {
                                    var lblTotalDurationSelectedValue = tableTotalDuration.Controls["lblTotalDurationSelectedValue"] as Label;

                                    if (lblTotalDurationSelectedValue != null)
                                    {
                                        var totalCurrent = double.Parse(lblTotalDurationSelectedValue.Text);
                                        var durationSelected = !string.IsNullOrEmpty(obj.Duration)
                                                                ? double.Parse(obj.Duration)
                                                                : 0;
                                        if (!isChecked)
                                        {
                                            lblTotalDurationSelectedValue.Text = (totalCurrent + durationSelected).ToString("F2");
                                        }
                                        else
                                        {
                                            lblTotalDurationSelectedValue.Text = (totalCurrent - durationSelected).ToString("F2");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }            
        }

        private void ShowSelectedAppointment(int rowIndex)
        {
            Entity.TimeEntry obj = DataSource[rowIndex];//dgvItems.Rows[rowIndex].DataBoundItem as Entity.TimeEntry;
            string outlookAppointmentNotFoundRecreationQuestionMsg = Core.ResourceManager.GetResourceString("OutlookAppointmentNotFoundRecreationQuestionMsg", "Appointment not found. Do you want to recreate it?");
            string outlookAppointmentNotFoundRecreationQuestionMsgCaption = Core.ResourceManager.GetResourceString("OutlookAppointmentNotFoundRecreationQuestionMsgCaption", "Missing Appointment");

            //Modified by tsrdev1
            //Modified datetime 18/10/2010


            if (obj.OLAppointmentItem != null)
            {
                obj.OLAppointmentItem.Display(false);
            }
            else
            {
                if ((TSR.Core.TSRFacade.GetExchangeMode()) && (obj.Revision.HasValue && obj.Revision.Value > 0))
                {
                    if (TSR.Core.TSRFacade.IsServiceUp(Core.SettingsHelper.TSRServerAddress))
                    {
                        TimeEntry_OutlookAppointment te_app = TSRFacade.GetTimeEntry_OutlookAppointmentLinkFromServer(obj.ID);
                        Microsoft.Office.Interop.Outlook.AppointmentItem app = (te_app != null)?Core.OutlookHelper.GetAppointmentItemInCurrentFolderByEntryIDAndDatetime(te_app.OutlookItemID, obj.StartTimeStamp):null;
                        if (te_app == null)
                        {
                            if (MessageBox.Show(outlookAppointmentNotFoundRecreationQuestionMsg, outlookAppointmentNotFoundRecreationQuestionMsgCaption,
                               MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                ///create appointment in selected folder(appointment folder not default folder)
                                Microsoft.Office.Interop.Outlook.AppointmentItem tmp = Core.OutlookHelper.CreateNewTimeEntryAppointmentWithoutUpdatingTimeEntry(obj);

                                //Save new link to server
                                TimeEntry_OutlookAppointment updatedTe_App = new TimeEntry_OutlookAppointment();
                                updatedTe_App.TimeEntryID = obj.ID;
                                updatedTe_App.OutlookItemID = tmp.EntryID;
                                updatedTe_App.CalendarID = TSR.Core.OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID;

                                if (TSRFacade.UpdateTimeEntry_OutlookAppointmentLinkToServer(updatedTe_App))
                                {

                                    obj.OLAppointmentItem = tmp;
                                    updatedTe_App.Revision += 1;
                                    TSRFacade.UpdateTimeEntry(obj, updatedTe_App);

                                    string message = Core.ResourceManager.GetResourceString("SuccessCreateNewAppointmentAndLinkMsg", "The new appointment was created successfully and the link was updated to server");
                                    string messageCaption = Core.ResourceManager.GetResourceString("SuccessCreateNewAppointmentAndLinkMsgCaption", "Created appointment");
                                    MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    obj.OLAppointmentItem.Display(false);
                                }
                                else
                                {
                                    try
                                    {
                                        if (tmp != null)
                                            tmp.Delete();
                                    }
                                    catch //(Exception ex)
                                    {
                                        //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                                    }

                                    string message = Core.ResourceManager.GetResourceString("FailureCreateNewAppointmentAndLinkMsg", "The new appointment was created unsuccessfully because the link was not updated to server");
                                    string messageCaption = Core.ResourceManager.GetResourceString("FailureCreateNewAppointmentAndLinkMsgCaption", "No created appointment");
                                    MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            if (app == null)
                            {
                                if ((te_app.OutlookItemID == obj.OutlookItemID) || 
                                    (string.IsNullOrEmpty(te_app.OutlookItemID) ||
                                    (!string.IsNullOrEmpty(te_app.OutlookItemID) && (te_app.OutlookItemID == Core.Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID))))
                                {
                                    if (MessageBox.Show(outlookAppointmentNotFoundRecreationQuestionMsg, outlookAppointmentNotFoundRecreationQuestionMsgCaption,
                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                                    {
                                        ///create appointment in selected folder(appointment folder not default folder)
                                        Microsoft.Office.Interop.Outlook.AppointmentItem tmp = Core.OutlookHelper.CreateNewTimeEntryAppointmentWithoutUpdatingTimeEntry(obj);

                                        //Save new link to server
                                        TimeEntry_OutlookAppointment updatedTe_App = new TimeEntry_OutlookAppointment();
                                        updatedTe_App.TimeEntryID = obj.ID;
                                        updatedTe_App.OutlookItemID = tmp.EntryID;
                                        updatedTe_App.Revision = te_app.Revision;
                                        updatedTe_App.CalendarID = TSR.Core.OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID;

                                        if (TSRFacade.UpdateTimeEntry_OutlookAppointmentLinkToServer(updatedTe_App))
                                        {

                                            obj.OLAppointmentItem = tmp;
                                            updatedTe_App.Revision += 1;
                                            TSRFacade.UpdateTimeEntry(obj, updatedTe_App);

                                            string message = Core.ResourceManager.GetResourceString("SuccessCreateNewAppointmentAndLinkMsg", "The new appointment was created successfully and the link was updated to server");
                                            string messageCaption = Core.ResourceManager.GetResourceString("SuccessCreateNewAppointmentAndLinkMsgCaption", "Created appointment");
                                            MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);

                                            obj.OLAppointmentItem.Display(false);
                                        }
                                        else
                                        {
                                            try
                                            {
                                                if (tmp != null)
                                                    tmp.Delete();
                                            }
                                            catch //(Exception ex)
                                            {
                                                //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                                            }

                                            string message = Core.ResourceManager.GetResourceString("FailureCreateNewAppointmentAndLinkMsg", "The new appointment was created unsuccessfully because the link was not updated to server");
                                            string messageCaption = Core.ResourceManager.GetResourceString("FailureCreateNewAppointmentAndLinkMsgCaption", "No created appointment");
                                            MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                                else
                                {
                                    string message = Core.ResourceManager.GetResourceString("TimeEntryLinkedButNoSyncedFromEX", "This time entry was linked to an appoinment but the appointment has been not synchronized from exchange yet");
                                    string messageCaption = Core.ResourceManager.GetResourceString("TimeEntryLinkedButNoSyncedFromEXMsgCaption", "No synchronize appointment");
                                    MessageBox.Show(message,messageCaption,MessageBoxButtons.OK,MessageBoxIcon.Information);
                                }
                            }
                            else
                            {
                                string message = Core.ResourceManager.GetResourceString("TimeEntryLinkedButNoSyncedFromTSRServer", "This time entry was linked to an appoinment but the link has been not synchronized from TSR Server yet");
                                string messageCaption = Core.ResourceManager.GetResourceString("TimeEntryLinkedButNoSyncedFromTSRServerMsgCaption", "No synchronize link");
                                MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    else
                    {                        
                        string message = Core.ResourceManager.GetResourceString("NeedSetValidAddressForEX", "You need setting a valid server address for exchange mode");
                        string messageCaption = Core.ResourceManager.GetResourceString("NeedSetValidAddressForEXMsgCaption", "Invalid Server Address");
                        MessageBox.Show(message, messageCaption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                    if (MessageBox.Show(outlookAppointmentNotFoundRecreationQuestionMsg, outlookAppointmentNotFoundRecreationQuestionMsgCaption,
                              MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        ///create appointment in selected folder(appointment folder not default folder)
                        Core.OutlookHelper.CreateNewTimeEntryAppointment(obj);
                        obj.OLAppointmentItem.Display(false);
                    }
                }
        }
                
        private void dgvItems_ColumnHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int increamentForSelection = (EnableSelection) ? 0 : 1;
            if ((e.Clicks == 1) && (e.ColumnIndex + increamentForSelection > 0))
            {
                _selectedColumnIndex = e.ColumnIndex;
                if (order.ContainsKey(e.ColumnIndex))
                {
                    order[e.ColumnIndex] = !order[e.ColumnIndex];
                }
                else
                {
                    order[e.ColumnIndex] = true;
                }

                dgvItems.Columns[e.ColumnIndex].HeaderCell.SortGlyphDirection = (order[e.ColumnIndex]) ? SortOrder.Ascending : SortOrder.Descending;
                foreach (DataGridViewColumn col in dgvItems.Columns)
                {
                    if (col.Index != e.ColumnIndex)
                        col.HeaderCell.SortGlyphDirection = SortOrder.None;
                }                

                //TimeEntry[] teList = new TimeEntry[] { };
                
                //DataSource.CopyTo(teList);

                TimeEntryList newTeList = new TimeEntryList();
                foreach (TimeEntry item in DataSource)
                {
                    newTeList.Add(item);
                }

                newTeList.Sort(CompareTimeEntries);

                SortDataSource(newTeList, false);
                //dgvItems.DataSource = DataSource;
                dgvItems.Refresh();                
            }
        }

        private int CompareTimeEntries(TimeEntry x, TimeEntry y)
        {
            TimeEntry tempXEntry;
            TimeEntry tempYEntry;
            int increamentForSelection = (EnableSelection) ? 0 : 1;

            if (order[_selectedColumnIndex])
            {
                tempXEntry = x;
                tempYEntry = y;
            }
            else
            {
                tempXEntry = y;
                tempYEntry = x;
            }

            switch (_selectedColumnIndex + increamentForSelection - 1)
            {
                case 0:
                {
                    if(tempXEntry.Subject != null)
                        return System.String.Compare(tempXEntry.Subject, tempYEntry.Subject, System.StringComparison.Ordinal);

                    return System.String.Compare(string.Empty, tempYEntry.Subject, System.StringComparison.Ordinal);
                }
                case 1:
                    return tempXEntry.OrganizationName.CompareTo(tempYEntry.OrganizationName);
                case 2:
                    return tempXEntry.ProjectName.CompareTo(tempYEntry.ProjectName);
                case 3:
                    return tempXEntry.ActivityName.CompareTo(tempYEntry.ActivityName);
                case 4:
                    return tempXEntry.StartTimeStamp.CompareTo(tempYEntry.StartTimeStamp);
                case 5:
                    return tempXEntry.EndTimeStamp.CompareTo(tempYEntry.EndTimeStamp);
                case 6:
                    return tempXEntry.Status.ToString().CompareTo(tempYEntry.Status.ToString());
                case 7:                                       
                    return tempXEntry.SubmitterName.CompareTo(tempYEntry.SubmitterName);                    
            }
            return 0;            
        }

        //Added by tsrdev1
        //Added datetime 
        private int CompareTimeEntriesWithDefault(TimeEntry x, TimeEntry y)
        {           
            return x.StartTimeStamp.CompareTo(y.StartTimeStamp);           
        }

        //Added by tsrdev1
        //Added datetime 11/11/2010
        /// <summary>
        /// Update data for rows
        /// </summary>
        /// <param name="teList"></param>
        public void UpdateRows(TimeEntryList teList)
        {
            if (teList == null)
                return;
            foreach (TimeEntry te in teList)
            {
                TimeEntry temp = null;
                temp = _sourceTeList.FindByID(te.ID);
                int rowIndex = -1;
                if (temp != null)
                {
                    rowIndex = _sourceTeList.IndexOf(temp);

                    temp.Status = te.Status;
                    temp.SubmitterName = te.SubmitterName;

                    if (rowIndex > -1)
                    {
                        dgvItems.Rows[rowIndex].Cells[TimeEntry.Property_Status].Value = te.Status.ToString();
                        dgvItems.Rows[rowIndex].Cells[TimeEntry.Property_SubmitterName].Value = te.SubmitterName;
                        if (EnableSelection) dgvItems.Rows[rowIndex].Cells[0].Value = false;

                        dgvItems.Rows[rowIndex].DefaultCellStyle.BackColor = Color.White;
                    }
                }

            }
        }

        //Added by tsrdev1
        //Added datetime 11/11/2010
        /// <summary>
        /// Delete data for rows
        /// </summary>
        /// <param name="teList"></param>
        public void DeleteRows(TimeEntryList teList)
        {
            if (teList == null)
                return;            

            foreach (TimeEntry te in teList)
            {
                TimeEntry temp = null;
                temp = _sourceTeList.FindByID(te.ID);
                int rowIndex = -1;
                if (temp != null)
                {
                    rowIndex = _sourceTeList.IndexOf(temp);

                    if (rowIndex > -1)
                    {                        
                        dgvItems.Rows.RemoveAt(rowIndex);                     
                    }

                    _sourceTeList.Remove(te);
                }
            }            
        }
    }
}
