using System.Windows.Forms;
using System.Drawing;
namespace TSR.Shell
{
    partial class Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tbcntSettings = new System.Windows.Forms.TabControl();
            this.tpUserAccount = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.txtUserAccInfoMsg = new System.Windows.Forms.TextBox();
            this.chbDoNotRetrieveSettings = new System.Windows.Forms.CheckBox();
            this.chkSSLMode = new System.Windows.Forms.CheckBox();
            this.chbDontshowagain = new System.Windows.Forms.CheckBox();
            this.lblChooseSecureMode = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblCustomerNo = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.txtWebinterface = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtServerAddress = new System.Windows.Forms.TextBox();
            this.lblServerAddress = new System.Windows.Forms.Label();
            this.lblWebinterface = new System.Windows.Forms.Label();
            this.txtCustomerNo = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.btnTestServerUp = new System.Windows.Forms.Button();
            this.tpWhatToSynchronize = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtWhatToSyncInfoMsg = new System.Windows.Forms.TextBox();
            this.cmbSyncRangePeriodFuture = new System.Windows.Forms.ComboBox();
            this.txtSyncRangeIndexFuture = new System.Windows.Forms.TextBox();
            this.rdBtnShowAllFolder = new System.Windows.Forms.RadioButton();
            this.cmbSyncRangePeriod = new System.Windows.Forms.ComboBox();
            this.txtSyncRangeIndex = new System.Windows.Forms.TextBox();
            this.chkSetupData = new System.Windows.Forms.CheckBox();
            this.chkTSRItems = new System.Windows.Forms.CheckBox();
            this.lblOutlookFloder = new System.Windows.Forms.Label();
            this.txtSyncRangeInfoMsg = new System.Windows.Forms.TextBox();
            this.cmbOutlookFloder = new System.Windows.Forms.ComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lblSyncRangeInThePast = new System.Windows.Forms.Label();
            this.tpAutomaticSync = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblAutoSuncInfoMsg = new System.Windows.Forms.Label();
            this.rbtnNotAutoSync = new System.Windows.Forms.RadioButton();
            this.rbtnAutoSunc = new System.Windows.Forms.RadioButton();
            this.gbAutoSync = new System.Windows.Forms.GroupBox();
            this.txtAutoSyncIndex = new System.Windows.Forms.TextBox();
            this.rbtnAutoSyncPeriod = new System.Windows.Forms.CheckBox();
            this.rbtnAutoSuncClosingTIme = new System.Windows.Forms.CheckBox();
            this.rbtnAutoSyncEveryTiime = new System.Windows.Forms.CheckBox();
            this.lblAutoSyncPeriod = new System.Windows.Forms.Label();
            this.cmbAutoSyncPeriod = new System.Windows.Forms.ComboBox();
            this.tpMisc = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.chkMiscNotSyncCompletedData = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblPreferredLanguage = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblMiscTo = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblMiscInThePast = new System.Windows.Forms.Label();
            this.cbbTimeFormat = new System.Windows.Forms.ComboBox();
            this.cbbDateFormat = new System.Windows.Forms.ComboBox();
            this.chkMiscRecreateDeletedTSRAppointment = new System.Windows.Forms.CheckBox();
            this.lblDefaultDateTimeFormat = new System.Windows.Forms.Label();
            this.chkDisplayTooltip = new System.Windows.Forms.CheckBox();
            this.cmbMiscFuturePeriod = new System.Windows.Forms.ComboBox();
            this.cmbMiscPastPeriod = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMiscFrom = new System.Windows.Forms.Label();
            this.txtMiscPastIndex = new System.Windows.Forms.TextBox();
            this.txtMiscFutureIndex = new System.Windows.Forms.TextBox();
            this.cmbPreferredLanguage = new System.Windows.Forms.ComboBox();
            this.chkMiscNotSyncTECreatedViaWeb = new System.Windows.Forms.CheckBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblOutlookUserAgent = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.cbxOutUserAgent = new System.Windows.Forms.ComboBox();
            this.chkMiscLaunch = new System.Windows.Forms.CheckBox();
            this.tpConnectionSettings = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.grpProxyConfiguration = new System.Windows.Forms.GroupBox();
            this.radProxySocks5 = new System.Windows.Forms.RadioButton();
            this.radProxySocks4 = new System.Windows.Forms.RadioButton();
            this.txtProxyPassword = new System.Windows.Forms.TextBox();
            this.lblProxyPassword = new System.Windows.Forms.Label();
            this.txtProxyUsername = new System.Windows.Forms.TextBox();
            this.lblProxyUsername = new System.Windows.Forms.Label();
            this.chkProxyAuthentication = new System.Windows.Forms.CheckBox();
            this.txtProxyPort = new System.Windows.Forms.TextBox();
            this.lblProxyPort = new System.Windows.Forms.Label();
            this.txtProxyHost = new System.Windows.Forms.TextBox();
            this.lblProxyHost = new System.Windows.Forms.Label();
            this.cbbProxyType = new System.Windows.Forms.ComboBox();
            this.chkProxyAutoSwitch = new System.Windows.Forms.CheckBox();
            this.txtConnectionTimeOutValue = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblConnectionTimeOutValue = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.chkNeverAskAgain = new System.Windows.Forms.CheckBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tbcntSettings.SuspendLayout();
            this.tpUserAccount.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tpWhatToSynchronize.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tpAutomaticSync.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.gbAutoSync.SuspendLayout();
            this.tpMisc.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tpConnectionSettings.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.grpProxyConfiguration.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tbcntSettings, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 91.13924F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.86076F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(488, 401);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // tbcntSettings
            // 
            this.tbcntSettings.Controls.Add(this.tpUserAccount);
            this.tbcntSettings.Controls.Add(this.tpWhatToSynchronize);
            this.tbcntSettings.Controls.Add(this.tpAutomaticSync);
            this.tbcntSettings.Controls.Add(this.tpMisc);
            this.tbcntSettings.Controls.Add(this.tpConnectionSettings);
            this.tbcntSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcntSettings.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.tbcntSettings.Location = new System.Drawing.Point(3, 3);
            this.tbcntSettings.Multiline = true;
            this.tbcntSettings.Name = "tbcntSettings";
            this.tbcntSettings.SelectedIndex = 0;
            this.tbcntSettings.Size = new System.Drawing.Size(482, 359);
            this.tbcntSettings.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tbcntSettings.TabIndex = 0;
            // 
            // tpUserAccount
            // 
            this.tpUserAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tpUserAccount.Controls.Add(this.tableLayoutPanel2);
            this.tpUserAccount.Location = new System.Drawing.Point(4, 40);
            this.tpUserAccount.Name = "tpUserAccount";
            this.tpUserAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tpUserAccount.Size = new System.Drawing.Size(474, 315);
            this.tpUserAccount.TabIndex = 0;
            this.tpUserAccount.Text = "User Account";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.47322F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.35564F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.47863F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.03419F));
            this.tableLayoutPanel2.Controls.Add(this.txtUserAccInfoMsg, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.chbDoNotRetrieveSettings, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.chkSSLMode, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.chbDontshowagain, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.lblChooseSecureMode, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.txtPassword, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblCustomerNo, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblUserName, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtWebinterface, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.lblPassword, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtServerAddress, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblServerAddress, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.lblWebinterface, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.txtCustomerNo, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtUserName, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.btnTestServerUp, 2, 5);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.32686F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.090615F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(468, 309);
            this.tableLayoutPanel2.TabIndex = 40;
            // 
            // txtUserAccInfoMsg
            // 
            this.txtUserAccInfoMsg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUserAccInfoMsg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.tableLayoutPanel2.SetColumnSpan(this.txtUserAccInfoMsg, 4);
            this.txtUserAccInfoMsg.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtUserAccInfoMsg.Location = new System.Drawing.Point(3, 3);
            this.txtUserAccInfoMsg.Multiline = true;
            this.txtUserAccInfoMsg.Name = "txtUserAccInfoMsg";
            this.txtUserAccInfoMsg.ReadOnly = true;
            this.txtUserAccInfoMsg.Size = new System.Drawing.Size(462, 42);
            this.txtUserAccInfoMsg.TabIndex = 0;
            this.txtUserAccInfoMsg.Text = "Make sure your Username is displayed below and correct server address has been en" +
                "tered";
            // 
            // chbDoNotRetrieveSettings
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.chbDoNotRetrieveSettings, 4);
            this.chbDoNotRetrieveSettings.Location = new System.Drawing.Point(3, 280);
            this.chbDoNotRetrieveSettings.Name = "chbDoNotRetrieveSettings";
            this.chbDoNotRetrieveSettings.Size = new System.Drawing.Size(363, 17);
            this.chbDoNotRetrieveSettings.TabIndex = 8;
            this.chbDoNotRetrieveSettings.Text = "Do not retrieve settings from server automatically";
            this.chbDoNotRetrieveSettings.UseVisualStyleBackColor = true;
            // 
            // chkSSLMode
            // 
            this.chkSSLMode.AutoSize = true;
            this.chkSSLMode.Location = new System.Drawing.Point(140, 189);
            this.chkSSLMode.Name = "chkSSLMode";
            this.chkSSLMode.Size = new System.Drawing.Size(82, 17);
            this.chkSSLMode.TabIndex = 4;
            this.chkSSLMode.Text = "SSL Mode";
            this.chkSSLMode.UseVisualStyleBackColor = true;
            // 
            // chbDontshowagain
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.chbDontshowagain, 4);
            this.chbDontshowagain.Location = new System.Drawing.Point(3, 255);
            this.chbDontshowagain.Name = "chbDontshowagain";
            this.chbDontshowagain.Size = new System.Drawing.Size(363, 17);
            this.chbDontshowagain.TabIndex = 7;
            this.chbDontshowagain.Text = "Don�t show warning when submitting an entry";
            this.chbDontshowagain.UseVisualStyleBackColor = true;
            // 
            // lblChooseSecureMode
            // 
            this.lblChooseSecureMode.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblChooseSecureMode.Location = new System.Drawing.Point(3, 186);
            this.lblChooseSecureMode.Name = "lblChooseSecureMode";
            this.lblChooseSecureMode.Size = new System.Drawing.Size(125, 16);
            this.lblChooseSecureMode.TabIndex = 39;
            this.lblChooseSecureMode.Text = "Secure Mode";
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLayoutPanel2.SetColumnSpan(this.txtPassword, 2);
            this.txtPassword.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtPassword.Location = new System.Drawing.Point(140, 127);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(263, 21);
            this.txtPassword.TabIndex = 2;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // lblCustomerNo
            // 
            this.lblCustomerNo.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblCustomerNo.Location = new System.Drawing.Point(3, 62);
            this.lblCustomerNo.Name = "lblCustomerNo";
            this.lblCustomerNo.Size = new System.Drawing.Size(125, 16);
            this.lblCustomerNo.TabIndex = 1;
            this.lblCustomerNo.Text = "Customer Number:";
            // 
            // lblUserName
            // 
            this.lblUserName.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblUserName.Location = new System.Drawing.Point(3, 93);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(125, 16);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User Name:";
            // 
            // txtWebinterface
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.txtWebinterface, 2);
            this.txtWebinterface.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtWebinterface.Location = new System.Drawing.Point(140, 220);
            this.txtWebinterface.Name = "txtWebinterface";
            this.txtWebinterface.Size = new System.Drawing.Size(263, 21);
            this.txtWebinterface.TabIndex = 6;
            // 
            // lblPassword
            // 
            this.lblPassword.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblPassword.Location = new System.Drawing.Point(3, 124);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(125, 16);
            this.lblPassword.TabIndex = 38;
            this.lblPassword.Text = "Password:";
            // 
            // txtServerAddress
            // 
            this.tableLayoutPanel2.SetColumnSpan(this.txtServerAddress, 2);
            this.txtServerAddress.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtServerAddress.Location = new System.Drawing.Point(140, 158);
            this.txtServerAddress.Name = "txtServerAddress";
            this.txtServerAddress.Size = new System.Drawing.Size(263, 21);
            this.txtServerAddress.TabIndex = 3;
            this.txtServerAddress.TextChanged += new System.EventHandler(this.txtServerAddress_TextChanged);
            // 
            // lblServerAddress
            // 
            this.lblServerAddress.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblServerAddress.Location = new System.Drawing.Point(3, 155);
            this.lblServerAddress.Name = "lblServerAddress";
            this.lblServerAddress.Size = new System.Drawing.Size(130, 16);
            this.lblServerAddress.TabIndex = 3;
            this.lblServerAddress.Text = "Server Address";
            // 
            // lblWebinterface
            // 
            this.lblWebinterface.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.lblWebinterface.Location = new System.Drawing.Point(3, 217);
            this.lblWebinterface.Name = "lblWebinterface";
            this.lblWebinterface.Size = new System.Drawing.Size(130, 19);
            this.lblWebinterface.TabIndex = 4;
            this.lblWebinterface.Text = "Web Interface";
            // 
            // txtCustomerNo
            // 
            this.txtCustomerNo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLayoutPanel2.SetColumnSpan(this.txtCustomerNo, 2);
            this.txtCustomerNo.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtCustomerNo.Location = new System.Drawing.Point(140, 65);
            this.txtCustomerNo.Name = "txtCustomerNo";
            this.txtCustomerNo.Size = new System.Drawing.Size(263, 21);
            this.txtCustomerNo.TabIndex = 0;
            this.txtCustomerNo.TextChanged += new System.EventHandler(this.txtCustomerNo_TextChanged);
            this.txtCustomerNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCustomerNo_KeyPress);
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLayoutPanel2.SetColumnSpan(this.txtUserName, 2);
            this.txtUserName.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.txtUserName.Location = new System.Drawing.Point(140, 96);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(263, 21);
            this.txtUserName.TabIndex = 1;
            this.txtUserName.TextChanged += new System.EventHandler(this.txtServerAddress_TextChanged);
            // 
            // btnTestServerUp
            // 
            this.btnTestServerUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTestServerUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnTestServerUp.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnTestServerUp.Location = new System.Drawing.Point(270, 189);
            this.btnTestServerUp.Name = "btnTestServerUp";
            this.btnTestServerUp.Size = new System.Drawing.Size(133, 23);
            this.btnTestServerUp.TabIndex = 5;
            this.btnTestServerUp.Text = "Test Server Address";
            this.btnTestServerUp.UseVisualStyleBackColor = false;
            this.btnTestServerUp.Click += new System.EventHandler(this.btnTestServerUp_Click);
            // 
            // tpWhatToSynchronize
            // 
            this.tpWhatToSynchronize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tpWhatToSynchronize.Controls.Add(this.tableLayoutPanel3);
            this.tpWhatToSynchronize.Location = new System.Drawing.Point(4, 40);
            this.tpWhatToSynchronize.Name = "tpWhatToSynchronize";
            this.tpWhatToSynchronize.Padding = new System.Windows.Forms.Padding(3);
            this.tpWhatToSynchronize.Size = new System.Drawing.Size(474, 315);
            this.tpWhatToSynchronize.TabIndex = 1;
            this.tpWhatToSynchronize.Text = "What To Sync.";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.20833F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.375F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.41667F));
            this.tableLayoutPanel3.Controls.Add(this.panel9, 2, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtWhatToSyncInfoMsg, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.cmbSyncRangePeriodFuture, 1, 8);
            this.tableLayoutPanel3.Controls.Add(this.txtSyncRangeIndexFuture, 0, 8);
            this.tableLayoutPanel3.Controls.Add(this.rdBtnShowAllFolder, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.cmbSyncRangePeriod, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.txtSyncRangeIndex, 0, 7);
            this.tableLayoutPanel3.Controls.Add(this.chkSetupData, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.chkTSRItems, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblOutlookFloder, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.txtSyncRangeInfoMsg, 0, 6);
            this.tableLayoutPanel3.Controls.Add(this.cmbOutlookFloder, 0, 5);
            this.tableLayoutPanel3.Controls.Add(this.panel8, 2, 7);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.47522F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.443149F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.03207F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.825073F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.766763F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.94461F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.28205F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.03207F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.199F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(468, 309);
            this.tableLayoutPanel3.TabIndex = 24;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(281, 267);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(184, 39);
            this.panel9.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "in the future.";
            // 
            // txtWhatToSyncInfoMsg
            // 
            this.txtWhatToSyncInfoMsg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.tableLayoutPanel3.SetColumnSpan(this.txtWhatToSyncInfoMsg, 3);
            this.txtWhatToSyncInfoMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtWhatToSyncInfoMsg.Location = new System.Drawing.Point(3, 3);
            this.txtWhatToSyncInfoMsg.Multiline = true;
            this.txtWhatToSyncInfoMsg.Name = "txtWhatToSyncInfoMsg";
            this.txtWhatToSyncInfoMsg.ReadOnly = true;
            this.txtWhatToSyncInfoMsg.Size = new System.Drawing.Size(462, 47);
            this.txtWhatToSyncInfoMsg.TabIndex = 11;
            this.txtWhatToSyncInfoMsg.Text = "Note: You can only select information types that your organization and PIM applic" +
                "ation support.";
            // 
            // cmbSyncRangePeriodFuture
            // 
            this.cmbSyncRangePeriodFuture.FormattingEnabled = true;
            this.cmbSyncRangePeriodFuture.Location = new System.Drawing.Point(144, 267);
            this.cmbSyncRangePeriodFuture.Name = "cmbSyncRangePeriodFuture";
            this.cmbSyncRangePeriodFuture.Size = new System.Drawing.Size(121, 21);
            this.cmbSyncRangePeriodFuture.TabIndex = 7;
            // 
            // txtSyncRangeIndexFuture
            // 
            this.txtSyncRangeIndexFuture.Location = new System.Drawing.Point(3, 267);
            this.txtSyncRangeIndexFuture.Name = "txtSyncRangeIndexFuture";
            this.txtSyncRangeIndexFuture.Size = new System.Drawing.Size(124, 21);
            this.txtSyncRangeIndexFuture.TabIndex = 6;
            // 
            // rdBtnShowAllFolder
            // 
            this.rdBtnShowAllFolder.AutoSize = true;
            this.tableLayoutPanel3.SetColumnSpan(this.rdBtnShowAllFolder, 3);
            this.rdBtnShowAllFolder.Location = new System.Drawing.Point(3, 125);
            this.rdBtnShowAllFolder.Name = "rdBtnShowAllFolder";
            this.rdBtnShowAllFolder.Size = new System.Drawing.Size(164, 17);
            this.rdBtnShowAllFolder.TabIndex = 23;
            this.rdBtnShowAllFolder.TabStop = true;
            this.rdBtnShowAllFolder.Text = "Show all Outlook folders";
            this.rdBtnShowAllFolder.UseVisualStyleBackColor = true;
            this.rdBtnShowAllFolder.CheckedChanged += new System.EventHandler(this.rdBtnShowAllFolder_CheckedChanged);
            // 
            // cmbSyncRangePeriod
            // 
            this.cmbSyncRangePeriod.FormattingEnabled = true;
            this.cmbSyncRangePeriod.Location = new System.Drawing.Point(144, 237);
            this.cmbSyncRangePeriod.Name = "cmbSyncRangePeriod";
            this.cmbSyncRangePeriod.Size = new System.Drawing.Size(121, 21);
            this.cmbSyncRangePeriod.TabIndex = 5;
            // 
            // txtSyncRangeIndex
            // 
            this.txtSyncRangeIndex.Location = new System.Drawing.Point(3, 237);
            this.txtSyncRangeIndex.Name = "txtSyncRangeIndex";
            this.txtSyncRangeIndex.Size = new System.Drawing.Size(124, 21);
            this.txtSyncRangeIndex.TabIndex = 4;
            // 
            // chkSetupData
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.chkSetupData, 3);
            this.chkSetupData.Location = new System.Drawing.Point(3, 56);
            this.chkSetupData.Name = "chkSetupData";
            this.chkSetupData.Size = new System.Drawing.Size(363, 16);
            this.chkSetupData.TabIndex = 1;
            this.chkSetupData.Text = "Setup Data (Organization, Project, Activity. Etc)";
            this.chkSetupData.UseVisualStyleBackColor = true;
            // 
            // chkTSRItems
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.chkTSRItems, 3);
            this.chkTSRItems.Location = new System.Drawing.Point(3, 78);
            this.chkTSRItems.Name = "chkTSRItems";
            this.chkTSRItems.Size = new System.Drawing.Size(363, 16);
            this.chkTSRItems.TabIndex = 2;
            this.chkTSRItems.Text = "TSR Items";
            this.chkTSRItems.UseVisualStyleBackColor = true;
            this.chkTSRItems.CheckedChanged += new System.EventHandler(this.chkTSRItems_CheckedChanged);
            // 
            // lblOutlookFloder
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.lblOutlookFloder, 3);
            this.lblOutlookFloder.Location = new System.Drawing.Point(3, 105);
            this.lblOutlookFloder.Name = "lblOutlookFloder";
            this.lblOutlookFloder.Size = new System.Drawing.Size(363, 13);
            this.lblOutlookFloder.TabIndex = 10;
            this.lblOutlookFloder.Text = "Select Outlook folder to sync.";
            // 
            // txtSyncRangeInfoMsg
            // 
            this.txtSyncRangeInfoMsg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.tableLayoutPanel3.SetColumnSpan(this.txtSyncRangeInfoMsg, 3);
            this.txtSyncRangeInfoMsg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSyncRangeInfoMsg.Location = new System.Drawing.Point(3, 187);
            this.txtSyncRangeInfoMsg.Multiline = true;
            this.txtSyncRangeInfoMsg.Name = "txtSyncRangeInfoMsg";
            this.txtSyncRangeInfoMsg.ReadOnly = true;
            this.txtSyncRangeInfoMsg.Size = new System.Drawing.Size(462, 44);
            this.txtSyncRangeInfoMsg.TabIndex = 20;
            this.txtSyncRangeInfoMsg.Text = "Select the time range for the TSR Items you want to include in the synchronizatio" +
                "n.";
            // 
            // cmbOutlookFloder
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.cmbOutlookFloder, 3);
            this.cmbOutlookFloder.FormattingEnabled = true;
            this.cmbOutlookFloder.Location = new System.Drawing.Point(3, 148);
            this.cmbOutlookFloder.Name = "cmbOutlookFloder";
            this.cmbOutlookFloder.Size = new System.Drawing.Size(364, 21);
            this.cmbOutlookFloder.TabIndex = 3;
            this.cmbOutlookFloder.SelectedIndexChanged += new System.EventHandler(this.cmbOutlookFloder_SelectedIndexChanged);
            this.cmbOutlookFloder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_KeyPress);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.lblSyncRangeInThePast);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(281, 237);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(184, 24);
            this.panel8.TabIndex = 24;
            // 
            // lblSyncRangeInThePast
            // 
            this.lblSyncRangeInThePast.AutoSize = true;
            this.lblSyncRangeInThePast.Location = new System.Drawing.Point(3, 5);
            this.lblSyncRangeInThePast.Name = "lblSyncRangeInThePast";
            this.lblSyncRangeInThePast.Size = new System.Drawing.Size(71, 13);
            this.lblSyncRangeInThePast.TabIndex = 17;
            this.lblSyncRangeInThePast.Text = "in the past.";
            // 
            // tpAutomaticSync
            // 
            this.tpAutomaticSync.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tpAutomaticSync.Controls.Add(this.tableLayoutPanel4);
            this.tpAutomaticSync.Location = new System.Drawing.Point(4, 40);
            this.tpAutomaticSync.Name = "tpAutomaticSync";
            this.tpAutomaticSync.Padding = new System.Windows.Forms.Padding(3);
            this.tpAutomaticSync.Size = new System.Drawing.Size(474, 315);
            this.tpAutomaticSync.TabIndex = 3;
            this.tpAutomaticSync.Text = "Automatic Sync.";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel4.Controls.Add(this.lblAutoSuncInfoMsg, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.rbtnNotAutoSync, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.rbtnAutoSunc, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.gbAutoSync, 0, 3);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.tableLayoutPanel4.RowCount = 4;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.096774F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.709678F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.709678F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 76.12904F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(468, 309);
            this.tableLayoutPanel4.TabIndex = 25;
            // 
            // lblAutoSuncInfoMsg
            // 
            this.lblAutoSuncInfoMsg.AutoSize = true;
            this.lblAutoSuncInfoMsg.Location = new System.Drawing.Point(3, 5);
            this.lblAutoSuncInfoMsg.Name = "lblAutoSuncInfoMsg";
            this.lblAutoSuncInfoMsg.Size = new System.Drawing.Size(349, 13);
            this.lblAutoSuncInfoMsg.TabIndex = 17;
            this.lblAutoSuncInfoMsg.Text = "Select how automatic synchronization should be performed.";
            // 
            // rbtnNotAutoSync
            // 
            this.rbtnNotAutoSync.AutoSize = true;
            this.rbtnNotAutoSync.Location = new System.Drawing.Point(3, 29);
            this.rbtnNotAutoSync.Name = "rbtnNotAutoSync";
            this.rbtnNotAutoSync.Size = new System.Drawing.Size(219, 17);
            this.rbtnNotAutoSync.TabIndex = 0;
            this.rbtnNotAutoSync.Text = "Do not synchronize automatically.";
            this.rbtnNotAutoSync.UseVisualStyleBackColor = true;
            // 
            // rbtnAutoSunc
            // 
            this.rbtnAutoSunc.AutoSize = true;
            this.rbtnAutoSunc.Checked = true;
            this.rbtnAutoSunc.Location = new System.Drawing.Point(3, 55);
            this.rbtnAutoSunc.Name = "rbtnAutoSunc";
            this.rbtnAutoSunc.Size = new System.Drawing.Size(176, 17);
            this.rbtnAutoSunc.TabIndex = 1;
            this.rbtnAutoSunc.TabStop = true;
            this.rbtnAutoSunc.Text = "Automatically Synchronize";
            this.rbtnAutoSunc.UseVisualStyleBackColor = true;
            this.rbtnAutoSunc.CheckedChanged += new System.EventHandler(this.rbtnAutoSunc_CheckedChanged);
            // 
            // gbAutoSync
            // 
            this.gbAutoSync.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gbAutoSync.Controls.Add(this.txtAutoSyncIndex);
            this.gbAutoSync.Controls.Add(this.rbtnAutoSyncPeriod);
            this.gbAutoSync.Controls.Add(this.rbtnAutoSuncClosingTIme);
            this.gbAutoSync.Controls.Add(this.rbtnAutoSyncEveryTiime);
            this.gbAutoSync.Controls.Add(this.lblAutoSyncPeriod);
            this.gbAutoSync.Controls.Add(this.cmbAutoSyncPeriod);
            this.gbAutoSync.Location = new System.Drawing.Point(3, 81);
            this.gbAutoSync.Name = "gbAutoSync";
            this.gbAutoSync.Size = new System.Drawing.Size(462, 200);
            this.gbAutoSync.TabIndex = 23;
            this.gbAutoSync.TabStop = false;
            // 
            // txtAutoSyncIndex
            // 
            this.txtAutoSyncIndex.Location = new System.Drawing.Point(111, 96);
            this.txtAutoSyncIndex.MaxLength = 9;
            this.txtAutoSyncIndex.Name = "txtAutoSyncIndex";
            this.txtAutoSyncIndex.Size = new System.Drawing.Size(136, 21);
            this.txtAutoSyncIndex.TabIndex = 3;
            this.txtAutoSyncIndex.TextChanged += new System.EventHandler(this.txtAutoSyncIndex_TextChanged);
            // 
            // rbtnAutoSyncPeriod
            // 
            this.rbtnAutoSyncPeriod.AutoSize = true;
            this.rbtnAutoSyncPeriod.Location = new System.Drawing.Point(15, 64);
            this.rbtnAutoSyncPeriod.Name = "rbtnAutoSyncPeriod";
            this.rbtnAutoSyncPeriod.Size = new System.Drawing.Size(347, 17);
            this.rbtnAutoSyncPeriod.TabIndex = 2;
            this.rbtnAutoSyncPeriod.Text = "Synchronize periodically while the Outlook is connected.";
            this.rbtnAutoSyncPeriod.UseVisualStyleBackColor = true;
            this.rbtnAutoSyncPeriod.CheckedChanged += new System.EventHandler(this.rbtnAutoSyncPeriod_CheckedChanged);
            // 
            // rbtnAutoSuncClosingTIme
            // 
            this.rbtnAutoSuncClosingTIme.AutoSize = true;
            this.rbtnAutoSuncClosingTIme.Location = new System.Drawing.Point(15, 40);
            this.rbtnAutoSuncClosingTIme.Name = "rbtnAutoSuncClosingTIme";
            this.rbtnAutoSuncClosingTIme.Size = new System.Drawing.Size(176, 17);
            this.rbtnAutoSuncClosingTIme.TabIndex = 1;
            this.rbtnAutoSuncClosingTIme.Text = "Sync on outlook shutdown";
            this.rbtnAutoSuncClosingTIme.UseVisualStyleBackColor = true;
            // 
            // rbtnAutoSyncEveryTiime
            // 
            this.rbtnAutoSyncEveryTiime.AutoSize = true;
            this.rbtnAutoSyncEveryTiime.Location = new System.Drawing.Point(15, 16);
            this.rbtnAutoSyncEveryTiime.Name = "rbtnAutoSyncEveryTiime";
            this.rbtnAutoSyncEveryTiime.Size = new System.Drawing.Size(162, 17);
            this.rbtnAutoSyncEveryTiime.TabIndex = 0;
            this.rbtnAutoSyncEveryTiime.Text = "Sync on outlook startup";
            this.rbtnAutoSyncEveryTiime.UseVisualStyleBackColor = true;
            // 
            // lblAutoSyncPeriod
            // 
            this.lblAutoSyncPeriod.Location = new System.Drawing.Point(14, 97);
            this.lblAutoSyncPeriod.Name = "lblAutoSyncPeriod";
            this.lblAutoSyncPeriod.Size = new System.Drawing.Size(89, 18);
            this.lblAutoSyncPeriod.TabIndex = 25;
            this.lblAutoSyncPeriod.Text = "Period:";
            // 
            // cmbAutoSyncPeriod
            // 
            this.cmbAutoSyncPeriod.FormattingEnabled = true;
            this.cmbAutoSyncPeriod.Location = new System.Drawing.Point(254, 96);
            this.cmbAutoSyncPeriod.Name = "cmbAutoSyncPeriod";
            this.cmbAutoSyncPeriod.Size = new System.Drawing.Size(100, 21);
            this.cmbAutoSyncPeriod.TabIndex = 4;
            // 
            // tpMisc
            // 
            this.tpMisc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tpMisc.Controls.Add(this.tableLayoutPanel5);
            this.tpMisc.Location = new System.Drawing.Point(4, 40);
            this.tpMisc.Name = "tpMisc";
            this.tpMisc.Padding = new System.Windows.Forms.Padding(3);
            this.tpMisc.Size = new System.Drawing.Size(474, 315);
            this.tpMisc.TabIndex = 4;
            this.tpMisc.Text = "Miscellaneous";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 5;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.94669F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.978678F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.96802F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.73348F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.37313F));
            this.tableLayoutPanel5.Controls.Add(this.chkMiscNotSyncCompletedData, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.panel6, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.panel5, 4, 5);
            this.tableLayoutPanel5.Controls.Add(this.panel4, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.panel3, 4, 4);
            this.tableLayoutPanel5.Controls.Add(this.cbbTimeFormat, 2, 9);
            this.tableLayoutPanel5.Controls.Add(this.cbbDateFormat, 0, 9);
            this.tableLayoutPanel5.Controls.Add(this.chkMiscRecreateDeletedTSRAppointment, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.lblDefaultDateTimeFormat, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.chkDisplayTooltip, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.cmbMiscFuturePeriod, 3, 5);
            this.tableLayoutPanel5.Controls.Add(this.cmbMiscPastPeriod, 3, 4);
            this.tableLayoutPanel5.Controls.Add(this.panel2, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.txtMiscPastIndex, 1, 4);
            this.tableLayoutPanel5.Controls.Add(this.txtMiscFutureIndex, 1, 5);
            this.tableLayoutPanel5.Controls.Add(this.cmbPreferredLanguage, 2, 6);
            this.tableLayoutPanel5.Controls.Add(this.chkMiscNotSyncTECreatedViaWeb, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.panel10, 0, 10);
            this.tableLayoutPanel5.Controls.Add(this.panel11, 0, 11);
            this.tableLayoutPanel5.Controls.Add(this.chkMiscLaunch, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.tableLayoutPanel5.RowCount = 12;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.980411F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.487459F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.479012F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.539848F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.409833F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.699829F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.771545F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.864144F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.956744F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.237138F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.289F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.28504F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(468, 309);
            this.tableLayoutPanel5.TabIndex = 37;
            // 
            // chkMiscNotSyncCompletedData
            // 
            this.chkMiscNotSyncCompletedData.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.chkMiscNotSyncCompletedData, 5);
            this.chkMiscNotSyncCompletedData.Location = new System.Drawing.Point(3, 29);
            this.chkMiscNotSyncCompletedData.Name = "chkMiscNotSyncCompletedData";
            this.chkMiscNotSyncCompletedData.Size = new System.Drawing.Size(345, 16);
            this.chkMiscNotSyncCompletedData.TabIndex = 1;
            this.chkMiscNotSyncCompletedData.Text = "Do not synchronize completed TSR Items from Server. ";
            this.chkMiscNotSyncCompletedData.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.panel6, 2);
            this.panel6.Controls.Add(this.lblPreferredLanguage);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 146);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(156, 20);
            this.panel6.TabIndex = 41;
            // 
            // lblPreferredLanguage
            // 
            this.lblPreferredLanguage.AutoSize = true;
            this.lblPreferredLanguage.Location = new System.Drawing.Point(1, 5);
            this.lblPreferredLanguage.Name = "lblPreferredLanguage";
            this.lblPreferredLanguage.Size = new System.Drawing.Size(120, 13);
            this.lblPreferredLanguage.TabIndex = 19;
            this.lblPreferredLanguage.Text = "Preferred Language";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label2);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(350, 120);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(115, 20);
            this.panel5.TabIndex = 40;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "in the future.";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblMiscTo);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 120);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(110, 20);
            this.panel4.TabIndex = 39;
            // 
            // lblMiscTo
            // 
            this.lblMiscTo.Location = new System.Drawing.Point(30, 3);
            this.lblMiscTo.Name = "lblMiscTo";
            this.lblMiscTo.Size = new System.Drawing.Size(43, 13);
            this.lblMiscTo.TabIndex = 32;
            this.lblMiscTo.Text = "To";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lblMiscInThePast);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(350, 95);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(115, 19);
            this.panel3.TabIndex = 38;
            // 
            // lblMiscInThePast
            // 
            this.lblMiscInThePast.Location = new System.Drawing.Point(3, 4);
            this.lblMiscInThePast.Name = "lblMiscInThePast";
            this.lblMiscInThePast.Size = new System.Drawing.Size(78, 13);
            this.lblMiscInThePast.TabIndex = 15;
            this.lblMiscInThePast.Text = "in the past.";
            // 
            // cbbTimeFormat
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.cbbTimeFormat, 2);
            this.cbbTimeFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbTimeFormat.FormattingEnabled = true;
            this.cbbTimeFormat.Location = new System.Drawing.Point(165, 216);
            this.cbbTimeFormat.Name = "cbbTimeFormat";
            this.cbbTimeFormat.Size = new System.Drawing.Size(157, 21);
            this.cbbTimeFormat.TabIndex = 36;
            // 
            // cbbDateFormat
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.cbbDateFormat, 2);
            this.cbbDateFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbDateFormat.FormattingEnabled = true;
            this.cbbDateFormat.Location = new System.Drawing.Point(3, 216);
            this.cbbDateFormat.Name = "cbbDateFormat";
            this.cbbDateFormat.Size = new System.Drawing.Size(156, 21);
            this.cbbDateFormat.TabIndex = 35;
            // 
            // chkMiscRecreateDeletedTSRAppointment
            // 
            this.chkMiscRecreateDeletedTSRAppointment.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.chkMiscRecreateDeletedTSRAppointment, 5);
            this.chkMiscRecreateDeletedTSRAppointment.Location = new System.Drawing.Point(3, 73);
            this.chkMiscRecreateDeletedTSRAppointment.Name = "chkMiscRecreateDeletedTSRAppointment";
            this.chkMiscRecreateDeletedTSRAppointment.Size = new System.Drawing.Size(428, 16);
            this.chkMiscRecreateDeletedTSRAppointment.TabIndex = 2;
            this.chkMiscRecreateDeletedTSRAppointment.Text = "Recreate deleted TSR Appointments of Outlook during synchronization";
            this.chkMiscRecreateDeletedTSRAppointment.UseVisualStyleBackColor = true;
            this.chkMiscRecreateDeletedTSRAppointment.CheckedChanged += new System.EventHandler(this.chkMiscReloadRemovedData_CheckedChanged);
            // 
            // lblDefaultDateTimeFormat
            // 
            this.lblDefaultDateTimeFormat.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.lblDefaultDateTimeFormat, 5);
            this.lblDefaultDateTimeFormat.Location = new System.Drawing.Point(3, 192);
            this.lblDefaultDateTimeFormat.Name = "lblDefaultDateTimeFormat";
            this.lblDefaultDateTimeFormat.Size = new System.Drawing.Size(178, 13);
            this.lblDefaultDateTimeFormat.TabIndex = 34;
            this.lblDefaultDateTimeFormat.Text = "Default date and time format:";
            // 
            // chkDisplayTooltip
            // 
            this.chkDisplayTooltip.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.chkDisplayTooltip, 5);
            this.chkDisplayTooltip.Location = new System.Drawing.Point(3, 172);
            this.chkDisplayTooltip.Name = "chkDisplayTooltip";
            this.chkDisplayTooltip.Size = new System.Drawing.Size(111, 17);
            this.chkDisplayTooltip.TabIndex = 33;
            this.chkDisplayTooltip.Text = "Activate tooltip";
            this.chkDisplayTooltip.UseVisualStyleBackColor = true;
            // 
            // cmbMiscFuturePeriod
            // 
            this.cmbMiscFuturePeriod.FormattingEnabled = true;
            this.cmbMiscFuturePeriod.Location = new System.Drawing.Point(235, 120);
            this.cmbMiscFuturePeriod.Name = "cmbMiscFuturePeriod";
            this.cmbMiscFuturePeriod.Size = new System.Drawing.Size(97, 21);
            this.cmbMiscFuturePeriod.TabIndex = 6;
            // 
            // cmbMiscPastPeriod
            // 
            this.cmbMiscPastPeriod.FormattingEnabled = true;
            this.cmbMiscPastPeriod.Location = new System.Drawing.Point(235, 95);
            this.cmbMiscPastPeriod.Name = "cmbMiscPastPeriod";
            this.cmbMiscPastPeriod.Size = new System.Drawing.Size(97, 21);
            this.cmbMiscPastPeriod.TabIndex = 4;
            this.cmbMiscPastPeriod.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox_KeyPress);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblMiscFrom);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(110, 19);
            this.panel2.TabIndex = 37;
            // 
            // lblMiscFrom
            // 
            this.lblMiscFrom.Location = new System.Drawing.Point(30, 4);
            this.lblMiscFrom.Name = "lblMiscFrom";
            this.lblMiscFrom.Size = new System.Drawing.Size(43, 13);
            this.lblMiscFrom.TabIndex = 16;
            this.lblMiscFrom.Text = "From";
            // 
            // txtMiscPastIndex
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.txtMiscPastIndex, 2);
            this.txtMiscPastIndex.Location = new System.Drawing.Point(119, 95);
            this.txtMiscPastIndex.Name = "txtMiscPastIndex";
            this.txtMiscPastIndex.Size = new System.Drawing.Size(97, 21);
            this.txtMiscPastIndex.TabIndex = 3;
            // 
            // txtMiscFutureIndex
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.txtMiscFutureIndex, 2);
            this.txtMiscFutureIndex.Location = new System.Drawing.Point(119, 120);
            this.txtMiscFutureIndex.Name = "txtMiscFutureIndex";
            this.txtMiscFutureIndex.Size = new System.Drawing.Size(97, 21);
            this.txtMiscFutureIndex.TabIndex = 5;
            // 
            // cmbPreferredLanguage
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.cmbPreferredLanguage, 2);
            this.cmbPreferredLanguage.FormattingEnabled = true;
            this.cmbPreferredLanguage.Location = new System.Drawing.Point(165, 146);
            this.cmbPreferredLanguage.Name = "cmbPreferredLanguage";
            this.cmbPreferredLanguage.Size = new System.Drawing.Size(179, 21);
            this.cmbPreferredLanguage.Sorted = true;
            this.cmbPreferredLanguage.TabIndex = 7;
            this.cmbPreferredLanguage.SelectedIndexChanged += new System.EventHandler(this.cmbPreferredLanguage_SelectedIndexChanged);
            // 
            // chkMiscNotSyncTECreatedViaWeb
            // 
            this.chkMiscNotSyncTECreatedViaWeb.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.chkMiscNotSyncTECreatedViaWeb, 5);
            this.chkMiscNotSyncTECreatedViaWeb.Location = new System.Drawing.Point(3, 51);
            this.chkMiscNotSyncTECreatedViaWeb.Name = "chkMiscNotSyncTECreatedViaWeb";
            this.chkMiscNotSyncTECreatedViaWeb.Size = new System.Drawing.Size(332, 16);
            this.chkMiscNotSyncTECreatedViaWeb.TabIndex = 42;
            this.chkMiscNotSyncTECreatedViaWeb.Text = "Do not synchronize entries created via web interface.";
            this.chkMiscNotSyncTECreatedViaWeb.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.panel10, 5);
            this.panel10.Controls.Add(this.lblOutlookUserAgent);
            this.panel10.Location = new System.Drawing.Point(3, 244);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(225, 25);
            this.panel10.TabIndex = 46;
            // 
            // lblOutlookUserAgent
            // 
            this.lblOutlookUserAgent.AutoSize = true;
            this.lblOutlookUserAgent.Location = new System.Drawing.Point(1, 6);
            this.lblOutlookUserAgent.Name = "lblOutlookUserAgent";
            this.lblOutlookUserAgent.Size = new System.Drawing.Size(222, 13);
            this.lblOutlookUserAgent.TabIndex = 0;
            this.lblOutlookUserAgent.Text = "List time entries - Outlook User Agent";
            // 
            // panel11
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.panel11, 5);
            this.panel11.Controls.Add(this.cbxOutUserAgent);
            this.panel11.Location = new System.Drawing.Point(3, 275);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(276, 28);
            this.panel11.TabIndex = 47;
            // 
            // cbxOutUserAgent
            // 
            this.cbxOutUserAgent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxOutUserAgent.FormattingEnabled = true;
            this.cbxOutUserAgent.Location = new System.Drawing.Point(2, 0);
            this.cbxOutUserAgent.Name = "cbxOutUserAgent";
            this.cbxOutUserAgent.Size = new System.Drawing.Size(245, 21);
            this.cbxOutUserAgent.TabIndex = 0;
            // 
            // chkMiscLaunch
            // 
            this.chkMiscLaunch.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.chkMiscLaunch, 5);
            this.chkMiscLaunch.Location = new System.Drawing.Point(3, 8);
            this.chkMiscLaunch.Name = "chkMiscLaunch";
            this.chkMiscLaunch.Size = new System.Drawing.Size(291, 15);
            this.chkMiscLaunch.TabIndex = 0;
            this.chkMiscLaunch.Text = "Launch TSR Outlook Sync. on Outlook startup.";
            this.chkMiscLaunch.UseVisualStyleBackColor = true;
            // 
            // tpConnectionSettings
            // 
            this.tpConnectionSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tpConnectionSettings.Controls.Add(this.tableLayoutPanel6);
            this.tpConnectionSettings.Location = new System.Drawing.Point(4, 40);
            this.tpConnectionSettings.Name = "tpConnectionSettings";
            this.tpConnectionSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tpConnectionSettings.Size = new System.Drawing.Size(474, 315);
            this.tpConnectionSettings.TabIndex = 5;
            this.tpConnectionSettings.Text = "Connection Settings";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.20833F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.79167F));
            this.tableLayoutPanel6.Controls.Add(this.grpProxyConfiguration, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.chkProxyAutoSwitch, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.txtConnectionTimeOutValue, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.panel7, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.22581F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.58065F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.51613F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(468, 309);
            this.tableLayoutPanel6.TabIndex = 26;
            // 
            // grpProxyConfiguration
            // 
            this.tableLayoutPanel6.SetColumnSpan(this.grpProxyConfiguration, 2);
            this.grpProxyConfiguration.Controls.Add(this.radProxySocks5);
            this.grpProxyConfiguration.Controls.Add(this.radProxySocks4);
            this.grpProxyConfiguration.Controls.Add(this.txtProxyPassword);
            this.grpProxyConfiguration.Controls.Add(this.lblProxyPassword);
            this.grpProxyConfiguration.Controls.Add(this.txtProxyUsername);
            this.grpProxyConfiguration.Controls.Add(this.lblProxyUsername);
            this.grpProxyConfiguration.Controls.Add(this.chkProxyAuthentication);
            this.grpProxyConfiguration.Controls.Add(this.txtProxyPort);
            this.grpProxyConfiguration.Controls.Add(this.lblProxyPort);
            this.grpProxyConfiguration.Controls.Add(this.txtProxyHost);
            this.grpProxyConfiguration.Controls.Add(this.lblProxyHost);
            this.grpProxyConfiguration.Controls.Add(this.cbbProxyType);
            this.grpProxyConfiguration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpProxyConfiguration.Location = new System.Drawing.Point(3, 3);
            this.grpProxyConfiguration.Name = "grpProxyConfiguration";
            this.grpProxyConfiguration.Size = new System.Drawing.Size(462, 188);
            this.grpProxyConfiguration.TabIndex = 0;
            this.grpProxyConfiguration.TabStop = false;
            this.grpProxyConfiguration.Text = "Configure Proxy";
            // 
            // radProxySocks5
            // 
            this.radProxySocks5.AutoSize = true;
            this.radProxySocks5.Location = new System.Drawing.Point(103, 160);
            this.radProxySocks5.Name = "radProxySocks5";
            this.radProxySocks5.Size = new System.Drawing.Size(74, 17);
            this.radProxySocks5.TabIndex = 27;
            this.radProxySocks5.Text = "SOCKS5";
            this.radProxySocks5.UseVisualStyleBackColor = true;
            // 
            // radProxySocks4
            // 
            this.radProxySocks4.AutoSize = true;
            this.radProxySocks4.Location = new System.Drawing.Point(15, 160);
            this.radProxySocks4.Name = "radProxySocks4";
            this.radProxySocks4.Size = new System.Drawing.Size(74, 17);
            this.radProxySocks4.TabIndex = 26;
            this.radProxySocks4.Text = "SOCKS4";
            this.radProxySocks4.UseVisualStyleBackColor = true;
            // 
            // txtProxyPassword
            // 
            this.txtProxyPassword.Location = new System.Drawing.Point(187, 132);
            this.txtProxyPassword.Name = "txtProxyPassword";
            this.txtProxyPassword.Size = new System.Drawing.Size(114, 21);
            this.txtProxyPassword.TabIndex = 23;
            this.txtProxyPassword.UseSystemPasswordChar = true;
            // 
            // lblProxyPassword
            // 
            this.lblProxyPassword.Location = new System.Drawing.Point(184, 116);
            this.lblProxyPassword.Name = "lblProxyPassword";
            this.lblProxyPassword.Size = new System.Drawing.Size(116, 16);
            this.lblProxyPassword.TabIndex = 24;
            this.lblProxyPassword.Text = "Password";
            // 
            // txtProxyUsername
            // 
            this.txtProxyUsername.Location = new System.Drawing.Point(33, 132);
            this.txtProxyUsername.Name = "txtProxyUsername";
            this.txtProxyUsername.Size = new System.Drawing.Size(147, 21);
            this.txtProxyUsername.TabIndex = 21;
            // 
            // lblProxyUsername
            // 
            this.lblProxyUsername.Location = new System.Drawing.Point(30, 116);
            this.lblProxyUsername.Name = "lblProxyUsername";
            this.lblProxyUsername.Size = new System.Drawing.Size(131, 13);
            this.lblProxyUsername.TabIndex = 22;
            this.lblProxyUsername.Text = "User name";
            // 
            // chkProxyAuthentication
            // 
            this.chkProxyAuthentication.Location = new System.Drawing.Point(15, 93);
            this.chkProxyAuthentication.Name = "chkProxyAuthentication";
            this.chkProxyAuthentication.Size = new System.Drawing.Size(261, 17);
            this.chkProxyAuthentication.TabIndex = 20;
            this.chkProxyAuthentication.Text = "Enable proxy authentication";
            this.chkProxyAuthentication.UseVisualStyleBackColor = true;
            this.chkProxyAuthentication.CheckedChanged += new System.EventHandler(this.chkProxyAuthentication_CheckedChanged);
            // 
            // txtProxyPort
            // 
            this.txtProxyPort.Location = new System.Drawing.Point(236, 56);
            this.txtProxyPort.Name = "txtProxyPort";
            this.txtProxyPort.Size = new System.Drawing.Size(65, 21);
            this.txtProxyPort.TabIndex = 18;
            // 
            // lblProxyPort
            // 
            this.lblProxyPort.AutoSize = true;
            this.lblProxyPort.Location = new System.Drawing.Point(206, 58);
            this.lblProxyPort.Name = "lblProxyPort";
            this.lblProxyPort.Size = new System.Drawing.Size(30, 13);
            this.lblProxyPort.TabIndex = 19;
            this.lblProxyPort.Text = "Port";
            // 
            // txtProxyHost
            // 
            this.txtProxyHost.Location = new System.Drawing.Point(44, 56);
            this.txtProxyHost.Name = "txtProxyHost";
            this.txtProxyHost.Size = new System.Drawing.Size(145, 21);
            this.txtProxyHost.TabIndex = 16;
            // 
            // lblProxyHost
            // 
            this.lblProxyHost.AutoSize = true;
            this.lblProxyHost.Location = new System.Drawing.Point(12, 58);
            this.lblProxyHost.Name = "lblProxyHost";
            this.lblProxyHost.Size = new System.Drawing.Size(32, 13);
            this.lblProxyHost.TabIndex = 17;
            this.lblProxyHost.Text = "Host";
            // 
            // cbbProxyType
            // 
            this.cbbProxyType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbProxyType.FormattingEnabled = true;
            this.cbbProxyType.Location = new System.Drawing.Point(15, 23);
            this.cbbProxyType.Name = "cbbProxyType";
            this.cbbProxyType.Size = new System.Drawing.Size(286, 21);
            this.cbbProxyType.TabIndex = 5;
            this.cbbProxyType.SelectedIndexChanged += new System.EventHandler(this.cbbProxyType_SelectedIndexChanged);
            // 
            // chkProxyAutoSwitch
            // 
            this.chkProxyAutoSwitch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.chkProxyAutoSwitch.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.tableLayoutPanel6.SetColumnSpan(this.chkProxyAutoSwitch, 2);
            this.chkProxyAutoSwitch.Location = new System.Drawing.Point(3, 235);
            this.chkProxyAutoSwitch.Name = "chkProxyAutoSwitch";
            this.chkProxyAutoSwitch.Size = new System.Drawing.Size(462, 48);
            this.chkProxyAutoSwitch.TabIndex = 21;
            this.chkProxyAutoSwitch.Text = "Automatic proxy. If this value is set, the agent will try to connect to the serve" +
                "r without the proxy settings if the proxy server is not reachable.";
            this.chkProxyAutoSwitch.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkProxyAutoSwitch.UseVisualStyleBackColor = true;
            // 
            // txtConnectionTimeOutValue
            // 
            this.txtConnectionTimeOutValue.Location = new System.Drawing.Point(261, 197);
            this.txtConnectionTimeOutValue.Name = "txtConnectionTimeOutValue";
            this.txtConnectionTimeOutValue.Size = new System.Drawing.Size(55, 21);
            this.txtConnectionTimeOutValue.TabIndex = 22;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.lblConnectionTimeOutValue);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 197);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(252, 32);
            this.panel7.TabIndex = 23;
            // 
            // lblConnectionTimeOutValue
            // 
            this.lblConnectionTimeOutValue.AutoSize = true;
            this.lblConnectionTimeOutValue.Location = new System.Drawing.Point(12, 4);
            this.lblConnectionTimeOutValue.Name = "lblConnectionTimeOutValue";
            this.lblConnectionTimeOutValue.Size = new System.Drawing.Size(222, 13);
            this.lblConnectionTimeOutValue.TabIndex = 23;
            this.lblConnectionTimeOutValue.Text = "Connection time out value (seconds):";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.chkNeverAskAgain);
            this.panel1.Controls.Add(this.btnOk);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 368);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(482, 30);
            this.panel1.TabIndex = 1;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnCancel.Location = new System.Drawing.Point(400, 3);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // chkNeverAskAgain
            // 
            this.chkNeverAskAgain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkNeverAskAgain.AutoSize = true;
            this.chkNeverAskAgain.Location = new System.Drawing.Point(12, 5);
            this.chkNeverAskAgain.Name = "chkNeverAskAgain";
            this.chkNeverAskAgain.Size = new System.Drawing.Size(121, 17);
            this.chkNeverAskAgain.TabIndex = 0;
            this.chkNeverAskAgain.Text = "Never ask me again";
            this.chkNeverAskAgain.UseVisualStyleBackColor = true;
            this.chkNeverAskAgain.CheckedChanged += new System.EventHandler(this.chkNeverAskAgain_CheckedChanged);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOk.Font = new System.Drawing.Font("Verdana", 8.25F);
            this.btnOk.Location = new System.Drawing.Point(318, 3);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 1;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(488, 401);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.Settings_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tbcntSettings.ResumeLayout(false);
            this.tpUserAccount.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tpWhatToSynchronize.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tpAutomaticSync.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.gbAutoSync.ResumeLayout(false);
            this.gbAutoSync.PerformLayout();
            this.tpMisc.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.tpConnectionSettings.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.grpProxyConfiguration.ResumeLayout(false);
            this.grpProxyConfiguration.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcntSettings;
        private System.Windows.Forms.TabPage tpUserAccount;
        private System.Windows.Forms.TabPage tpWhatToSynchronize;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TabPage tpAutomaticSync;
        private System.Windows.Forms.TabPage tpMisc;
        private System.Windows.Forms.Label lblServerAddress;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Button btnTestServerUp;
        private System.Windows.Forms.TextBox txtServerAddress;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtUserAccInfoMsg;
        private System.Windows.Forms.CheckBox chkSetupData;
        private System.Windows.Forms.TextBox txtWhatToSyncInfoMsg;
        private System.Windows.Forms.Label lblOutlookFloder;
        private System.Windows.Forms.CheckBox chkTSRItems;
        private System.Windows.Forms.ComboBox cmbOutlookFloder;
        private System.Windows.Forms.RadioButton rbtnNotAutoSync;
        private System.Windows.Forms.Label lblAutoSuncInfoMsg;
        private System.Windows.Forms.ComboBox cmbMiscPastPeriod;
        private System.Windows.Forms.CheckBox chkMiscRecreateDeletedTSRAppointment;
        private System.Windows.Forms.CheckBox chkMiscNotSyncCompletedData;
        private System.Windows.Forms.CheckBox chkMiscLaunch;
        private System.Windows.Forms.TextBox txtSyncRangeInfoMsg;
        private System.Windows.Forms.ComboBox cmbSyncRangePeriod;
        private System.Windows.Forms.Label lblSyncRangeInThePast;
        private System.Windows.Forms.RadioButton rbtnAutoSunc;
        private System.Windows.Forms.GroupBox gbAutoSync;
        private System.Windows.Forms.CheckBox rbtnAutoSyncPeriod;
        private System.Windows.Forms.CheckBox rbtnAutoSuncClosingTIme;
        private System.Windows.Forms.CheckBox rbtnAutoSyncEveryTiime;
        private System.Windows.Forms.Label lblAutoSyncPeriod;
        private System.Windows.Forms.ComboBox cmbAutoSyncPeriod;
        private System.Windows.Forms.ComboBox cmbSyncRangePeriodFuture;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbPreferredLanguage;
        private System.Windows.Forms.Label lblPreferredLanguage;
        private System.Windows.Forms.TextBox txtSyncRangeIndex;
        private System.Windows.Forms.TextBox txtSyncRangeIndexFuture;
        private System.Windows.Forms.TextBox txtMiscPastIndex;
        private System.Windows.Forms.Label lblMiscTo;
        private System.Windows.Forms.TextBox txtMiscFutureIndex;
        private System.Windows.Forms.ComboBox cmbMiscFuturePeriod;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMiscInThePast;
        private System.Windows.Forms.TextBox txtAutoSyncIndex;
        private System.Windows.Forms.TextBox txtWebinterface;
        private System.Windows.Forms.Label lblWebinterface;
        private System.Windows.Forms.CheckBox chbDontshowagain;
        private System.Windows.Forms.CheckBox chbDoNotRetrieveSettings;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkNeverAskAgain;
        private System.Windows.Forms.Label lblCustomerNo;
        private System.Windows.Forms.TextBox txtCustomerNo;
        private System.Windows.Forms.CheckBox chkSSLMode;
        private System.Windows.Forms.Label lblChooseSecureMode;
        private System.Windows.Forms.CheckBox chkDisplayTooltip;
        private System.Windows.Forms.TabPage tpConnectionSettings;
        private System.Windows.Forms.GroupBox grpProxyConfiguration;
        private System.Windows.Forms.TextBox txtProxyPort;
        private System.Windows.Forms.Label lblProxyPort;
        private System.Windows.Forms.TextBox txtProxyHost;
        private System.Windows.Forms.Label lblProxyHost;
        private System.Windows.Forms.ComboBox cbbProxyType;
        private System.Windows.Forms.TextBox txtProxyPassword;
        private System.Windows.Forms.Label lblProxyPassword;
        private System.Windows.Forms.TextBox txtProxyUsername;
        private System.Windows.Forms.Label lblProxyUsername;
        private System.Windows.Forms.CheckBox chkProxyAuthentication;
        private System.Windows.Forms.RadioButton radProxySocks5;
        private System.Windows.Forms.RadioButton radProxySocks4;
        private System.Windows.Forms.CheckBox chkProxyAutoSwitch;
        private System.Windows.Forms.TextBox txtConnectionTimeOutValue;
        private System.Windows.Forms.Label lblConnectionTimeOutValue;
        private System.Windows.Forms.ComboBox cbbTimeFormat;
        private System.Windows.Forms.ComboBox cbbDateFormat;
        private System.Windows.Forms.Label lblDefaultDateTimeFormat;
        private System.Windows.Forms.RadioButton rdBtnShowAllFolder;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private TableLayoutPanel tableLayoutPanel5;
        private TableLayoutPanel tableLayoutPanel6;
        private Panel panel2;
        private Label lblMiscFrom;
        private Panel panel6;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private Panel panel7;
        private Panel panel9;
        private Panel panel8;
        private CheckBox chkMiscNotSyncTECreatedViaWeb;
        private Panel panel10;
        private Label lblOutlookUserAgent;
        private Panel panel11;
        private ComboBox cbxOutUserAgent;
    }
}