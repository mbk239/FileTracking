﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.Core;
using TSR.Core.Entity;

namespace TSR.Shell
{
    public partial class CheckListTimeEntry : Controls.OUAForm, TSR.Core.ISyncEngineCheckListTimeEntry
    {
        private int _selectedColumnIndex;
        private TimeEntryList _sourceTeList = new TimeEntryList();        

        private Dictionary<int, bool> order = new Dictionary<int, bool>();

        /// <summary>
        /// Yes
        /// </summary>
        public const string COLUMUN_NAME_QUESTIONS_STATUS_1 = "Recreation";
        /// <summary>
        /// No
        /// </summary>
        public const string COLUMUN_NAME_QUESTIONS_STATUS_2 = "Never ask again";
        /// <summary>
        /// Recreation
        /// </summary>
        public const string COLUMUN_NAME_QUESTIONS_STATUS_3 = "Ask again";

        private string ColumnHeaderText1 = "";
        private string ColumnHeaderText2 = "";
        private string ColumnHeaderText3 = "";

        public TSR.Core.ListTimeEntryQuestions listResult;
        
        private bool _checkAllColumn1 = false;
        private bool _checkAllColumn2 = false;
        private bool _checkAllColumn3 = false;

        //Added by tsrdev1
        //Added datetime 12/11/2010
        public TimeEntryList DataSource
        {
            get
            {
                //TimeEntryList tel = new TimeEntryList();
                //if (dgvItems.DataSource != null)
                //{
                //   tel = dgvItems.DataSource as TimeEntryList;
                //}
                return _sourceTeList;
            }
            set
            {
                SetDataSource(value);
                //dgvItems.AutoGenerateColumns = false;
                //PrepareGridView(dgvItems);
                //if(dgvItems.Rows!=null)
                //    dgvItems.Rows.Clear();
                //foreach (TimeEntry te in value)
                //{
                //    dgvItems.Rows.Add(getDataGridRowFromTimeEntry(te));
                //}
                //_sourceTeList = value;
                //dgvItems.DataSource = value;
            }
        }

        public TSR.Core.ListTimeEntryQuestions _TimeEntryQuestions = new ListTimeEntryQuestions();
        public TSR.Core.ListTimeEntryQuestions TimeEntryQuestions
        {
            get
            {
                TSR.Core.ListTimeEntryQuestions list = new TSR.Core.ListTimeEntryQuestions();
                foreach (DataGridViewRow row in gvTimeEntry.Rows)
                {
                    bool bYes = false;
                    bool bNo = false;
                    bool bCancel = false;
                    try
                    {
                        bYes = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value.ToString());
                    }
                    catch { }
                    try
                    {
                        bNo = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value.ToString());
                    }
                    catch { }
                    try
                    {
                        bCancel = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value.ToString());
                    }
                    catch { }

                    if (bYes || bNo || bCancel)
                    {
                        TSR.Core.TimeEntryQuestionsStatus qStatus = TSR.Core.TimeEntryQuestionsStatus.Cancel;
                        if (bYes)
                        {
                            qStatus = TSR.Core.TimeEntryQuestionsStatus.Yes;
                        }
                        else if (bNo)
                        {
                            qStatus = TSR.Core.TimeEntryQuestionsStatus.No;
                            //TSR.Core.DAL.BaseDAL._ListTimeEntryQuestionsStatus2.Add(new TSR.Core.TimeEntryQuestions() { TimeEntryID = (System.Guid)row.Cells["ID"].Value, QuestionsStatus = qStatus });
                        }
                        else if (bCancel)
                        {
                            qStatus = TSR.Core.TimeEntryQuestionsStatus.Cancel;
                        }
                        else
                        {
                            continue;
                        }
                        TimeEntry te = DataSource[row.Index];
                        if (te != null)
                            list.Add(new TSR.Core.TimeEntryQuestions() { TimeEntryID = te.ID, QuestionsStatus = qStatus });
                    }
                }
                return list;
            }
        }


        public CheckListTimeEntry()
        {
            InitializeComponent();
            this.ColumnHeaderText1 = TSR.Core.ResourceManager.GetResourceString("Recreation", "Recreation");
            this.ColumnHeaderText2 = TSR.Core.ResourceManager.GetResourceString("NeverAskAgain", "Never ask again");
            this.ColumnHeaderText3 = TSR.Core.ResourceManager.GetResourceString("AskAgain", "Ask again");
            this.Text = TSR.Core.ResourceManager.GetResourceString("DeletedAppointmentList", "TSR deleted appointment list");
            //this.Text = Core.ResourceHelper.ItemsFormHeadingText;
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);             
            this.Icon = TSR.Core.ResourceHelper.TSRIcon; // set icon                                   
            gvTimeEntry.ColumnHeadersHeight = 18;            
        }

        protected override void OnClosing(CancelEventArgs e)
        {            
            listResult = TimeEntryQuestions;
            base.OnClosing(e);
        }

        private void CheckListTimeEntry_Load(object sender, EventArgs e)
        {            
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            //gvTimeEntry.EndEdit();
            //TSR.Core.ListTimeEntryQuestions list = new TSR.Core.ListTimeEntryQuestions();
            //foreach (DataGridViewRow row in gvTimeEntry.Rows)
            //{
            //    bool bYes = false;
            //    bool bNo = false;
            //    bool bCancel = false;
            //    try
            //    {
            //        bYes = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value.ToString());
            //    }
            //    catch { }
            //    try
            //    {
            //        bNo = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value.ToString());
            //    }
            //    catch { }
            //    try
            //    {
            //        bCancel = bool.Parse(row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value.ToString());
            //    }
            //    catch { }

            //    if (bYes || bNo || bCancel)
            //    {
            //        TSR.Core.TimeEntryQuestionsStatus qStatus = TSR.Core.TimeEntryQuestionsStatus.Yes;
            //        if (bYes)
            //        {
            //            qStatus = TSR.Core.TimeEntryQuestionsStatus.Yes;
            //        }
            //        else if (bNo)
            //        {
            //            qStatus = TSR.Core.TimeEntryQuestionsStatus.No;
            //        }
            //        else if (bCancel)
            //        {
            //            qStatus = TSR.Core.TimeEntryQuestionsStatus.Cancel;
            //        }
            //        else
            //        {
            //            continue;
            //        }
            //        list.Add(new TSR.Core.TimeEntryQuestions() { TimeEntryID = (System.Guid)row.Cells["ID"].Value, QuestionsStatus = qStatus });
            //    }
            //}
            //listResult = list;
            this.Close();
        }

        private void gvTimeEntry_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                bool b = false;
                //bool b2 = false;
                string s = gvTimeEntry.Columns[e.ColumnIndex].Name;
                if (s == COLUMUN_NAME_QUESTIONS_STATUS_1 || s == COLUMUN_NAME_QUESTIONS_STATUS_2 || s == COLUMUN_NAME_QUESTIONS_STATUS_3)
                {
                    try
                    {
                        b = bool.Parse(gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
                    }
                    catch { }

                    if (!b)
                        gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !b;

                    //try
                    //{
                    //    b2 = bool.Parse(gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
                    //}
                    //catch { }
                    //if (b2)
                    //{

                    //}
                    //else
                    //{

                    //}                
                    switch (s)
                    {
                        case COLUMUN_NAME_QUESTIONS_STATUS_1:
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = false;
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = false;
                            break;
                        case COLUMUN_NAME_QUESTIONS_STATUS_2:
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = false;
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = false;
                            break;
                        case COLUMUN_NAME_QUESTIONS_STATUS_3:
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = false;
                            gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = false;
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        private void gvTimeEntry_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }              
        #region ISyncEngineCheckListTimeEntry Members

        public TSR.Core.ListTimeEntryQuestions ShowCheckListTimeEntry(TSR.Core.Entity.TimeEntryList timeEntryList)
        {
            gvTimeEntry.AutoGenerateColumns = false;            

            PrepareGridView(gvTimeEntry);

            gvTimeEntry_SetWidthColumns();

            SetDataSource(timeEntryList);
            
            //List<TSR.Core.TimeEntryQuestions> listResult = new List<TSR.Core.TimeEntryQuestions>();

            //DataTable dt = new DataTable("TimeEntryListNerverAskAgain");
            //dt.Columns.Add("TimeEntryID", typeof(Guid));
            //foreach (TSR.Core.TimeEntryQuestions item in listResult)
            //{
            //    if (item.QuestionsStatus == TSR.Core.TimeEntryQuestionsStatus.No)
            //    {
            //        DataRow row = dt.NewRow();
            //        row[0] = item.TimeEntryID;
            //        dt.Rows.Add(row);
            //    }
            //}

            //TSR.Core.DAL.BaseDAL.MyDataSet.Tables.Add(dt);
            base.ShowDialog();
            return listResult;
        }        

        #endregion        

        private void gvTimeEntry_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //_checkAllColumn = false;
            string s = gvTimeEntry.Columns[e.ColumnIndex].Name;
            switch (s)
            {
                case COLUMUN_NAME_QUESTIONS_STATUS_1:
                    //_checkAllColumn1 = !_checkAllColumn1;
                    _checkAllColumn1 = true;
                    _checkAllColumn2 = false;
                    _checkAllColumn3 = false;

                    break;
                case COLUMUN_NAME_QUESTIONS_STATUS_2:
                    //_checkAllColumn2 = !_checkAllColumn2;
                    _checkAllColumn2 = true;
                    _checkAllColumn1 = false;
                    _checkAllColumn3 = false;

                    break;
                case COLUMUN_NAME_QUESTIONS_STATUS_3:
                    //_checkAllColumn3 = !_checkAllColumn3;
                    _checkAllColumn3 = true;
                    _checkAllColumn1 = false;
                    _checkAllColumn2 = false;

                    break;
                default:
                    break;
            }
            foreach (DataGridViewRow row in gvTimeEntry.Rows)
            {
                s = gvTimeEntry.Columns[e.ColumnIndex].Name;
                switch (s)
                {
                    case COLUMUN_NAME_QUESTIONS_STATUS_1:
                        //_checkAllColumn1 = !_checkAllColumn1;
                        //_checkAllColumn2 = false;
                        //_checkAllColumn3 = false;

                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = _checkAllColumn1;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = _checkAllColumn2;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = _checkAllColumn3;

                        break;
                    case COLUMUN_NAME_QUESTIONS_STATUS_2:
                        //_checkAllColumn2 = !_checkAllColumn2;
                        //_checkAllColumn1 = false;
                        //_checkAllColumn3 = false;

                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = _checkAllColumn1;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = _checkAllColumn2;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = _checkAllColumn3;
                        
                        break;
                    case COLUMUN_NAME_QUESTIONS_STATUS_3:
                        //_checkAllColumn3 = !_checkAllColumn3;
                        //_checkAllColumn1 = false;
                        //_checkAllColumn2 = false;

                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = _checkAllColumn1;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = _checkAllColumn2;
                        row.Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = _checkAllColumn3;

                        break;
                    default:
                        break;
                }
            }
            if (e.Clicks == 1 && (s != COLUMUN_NAME_QUESTIONS_STATUS_1 && s != COLUMUN_NAME_QUESTIONS_STATUS_2 && s != COLUMUN_NAME_QUESTIONS_STATUS_3))
            {
                _selectedColumnIndex = e.ColumnIndex;
                if (order.ContainsKey(e.ColumnIndex))
                {
                    order[e.ColumnIndex] = !order[e.ColumnIndex];
                }
                else
                {
                    order[e.ColumnIndex] = true;
                }

                gvTimeEntry.Columns[e.ColumnIndex].HeaderCell.SortGlyphDirection = (order[e.ColumnIndex]) ? SortOrder.Ascending : SortOrder.Descending;
                foreach (DataGridViewColumn col in gvTimeEntry.Columns)
                {
                    if (col.Index != e.ColumnIndex)
                        col.HeaderCell.SortGlyphDirection = SortOrder.None;
                }

                //TimeEntry[] teList = new TimeEntry[] { };

                //DataSource.CopyTo(teList);

                TimeEntryList newTeList = new TimeEntryList();
                foreach (TimeEntry item in DataSource)
                {
                    newTeList.Add(item);
                }

                newTeList.Sort(CompareTimeEntries);

                SortDataSource(newTeList);
                //dgvItems.DataSource = DataSource;
                gvTimeEntry.Refresh();       
            }
        }

        private void gvTimeEntry_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                bool b = false;
                //bool b2 = false;

                try
                {
                    b = bool.Parse(gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
                }
                catch { }                

                if (b)
                {
                    gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = true;                    
                    return;
                }
                else
                {

                }

                //try
                //{
                //    b2 = bool.Parse(gvTimeEntry.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
                //}
                //catch { }
                //if (b2)
                //{

                //}
                //else
                //{

                //}
                string s = gvTimeEntry.Columns[e.ColumnIndex].Name;
                switch (s)
                {
                    case COLUMUN_NAME_QUESTIONS_STATUS_1:
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = false;
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = false;
                        break;
                    case COLUMUN_NAME_QUESTIONS_STATUS_2:
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = false;
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = false;
                        break;
                    case COLUMUN_NAME_QUESTIONS_STATUS_3:
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = false;
                        gvTimeEntry.Rows[e.RowIndex].Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = false;
                        break;
                    default:
                        break;
                }
            }
        }

        //Added by tsrdev1
        //Added datetime 
        #region Databind and sorting
        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="inCreamental"></param>
        public void SetDataSource(TimeEntryList teList)
        {
            if (teList == null)
                return;       
                 
            _sourceTeList.Clear();

            _TimeEntryQuestions = new ListTimeEntryQuestions();
            //if (TimeEntryQuestions != null && TimeEntryQuestions.Count > 0)
            //{
            //    foreach (TSR.Core.TimeEntryQuestions ques in TimeEntryQuestions)
            //        _TimeEntryQuestions.Add(ques);
            //}

            foreach (TimeEntry te in teList)
            {
                _sourceTeList.Add(te);
            }

            _sourceTeList.Sort(CompareTimeEntriesWithDefault);

            order[4] = true;

            SetDataSourceWithoutSorting(_sourceTeList);
        }

        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="inCreamental"></param>
        public void SortDataSource(TimeEntryList teList)
        {
            if (teList == null)
                return;

            _TimeEntryQuestions = new ListTimeEntryQuestions();
            if (TimeEntryQuestions != null && TimeEntryQuestions.Count > 0)
            {
                foreach (TSR.Core.TimeEntryQuestions ques in TimeEntryQuestions)
                    _TimeEntryQuestions.Add(ques);
            }           

            _sourceTeList.Clear();

            foreach (TimeEntry te in teList)
            {
                _sourceTeList.Add(te);
            }
            SetDataSourceWithoutSorting(teList);
        }

        //Added by tsrdev1
        //Added datetime 10/11/2010
        /// <summary>
        /// method for incrementally updating grid
        /// </summary>
        /// <param name="teList"></param>        
        public void SetDataSourceWithoutSorting(TimeEntryList teList)
        {
            if (teList == null)
                return;
            if (gvTimeEntry.Rows != null)
            {
                //DataGridViewRowCollection rows = dgvItems.Rows;
                int totalRows = gvTimeEntry.Rows.Count;
                //foreach (DataGridViewRow row in rows)
                //{
                //    dgvItems.Rows.Remove(row);
                //}
                for (int i = totalRows - 1; i > -1; i--)
                {
                    gvTimeEntry.Rows.RemoveAt(i);
                }
            }

            string dateFormat = string.Empty, timeFormat = string.Empty;
            OutlookHelper.GetDateTimeFormat(out dateFormat, out timeFormat, false);

            foreach (TimeEntry te in teList)
            {
                int index = -1;
                index = gvTimeEntry.Rows.Add(getDataGridRowFromTimeEntry(te, dateFormat, timeFormat));   
                             
                if (_TimeEntryQuestions != null && _TimeEntryQuestions.Count > 0)
                {
                    TimeEntryQuestions ques = _TimeEntryQuestions.FindByID(te.ID);
                    if (ques != null && index > -1)
                    {
                        gvTimeEntry.Rows[index].Cells[COLUMUN_NAME_QUESTIONS_STATUS_1].Value = (ques.QuestionsStatus == TimeEntryQuestionsStatus.Yes);
                        gvTimeEntry.Rows[index].Cells[COLUMUN_NAME_QUESTIONS_STATUS_2].Value = (ques.QuestionsStatus == TimeEntryQuestionsStatus.No);
                        gvTimeEntry.Rows[index].Cells[COLUMUN_NAME_QUESTIONS_STATUS_3].Value = (ques.QuestionsStatus == TimeEntryQuestionsStatus.Cancel);
                    }
                }                
            }

            _TimeEntryQuestions = new ListTimeEntryQuestions();
        }        
        private int CompareTimeEntries(TimeEntry x, TimeEntry y)
        {
            TimeEntry tempXEntry;
            TimeEntry tempYEntry;

            if (order[_selectedColumnIndex])
            {
                tempXEntry = x;
                tempYEntry = y;
            }
            else
            {
                tempXEntry = y;
                tempYEntry = x;
            }

            switch (_selectedColumnIndex)
            {
                case 0:                    
                    return tempXEntry.Subject.CompareTo(tempYEntry.Subject);                    
                case 1:
                    return tempXEntry.OrganizationName.CompareTo(tempYEntry.OrganizationName);
                case 2:
                    return tempXEntry.ProjectName.CompareTo(tempYEntry.ProjectName);
                case 3:
                    return tempXEntry.ActivityName.CompareTo(tempYEntry.ActivityName);
                case 4:
                    return tempXEntry.StartTimeStamp.CompareTo(tempYEntry.StartTimeStamp);
                case 5:
                    return tempXEntry.EndTimeStamp.CompareTo(tempYEntry.EndTimeStamp);
                case 6:
                    return tempXEntry.Status.ToString().CompareTo(tempYEntry.Status.ToString());
                default: break;
            }
            return 0;
        }
        private int CompareTimeEntriesWithDefault(TimeEntry x, TimeEntry y)
        {
            return x.StartTimeStamp.CompareTo(y.StartTimeStamp);
        }
        private string[] getDataGridRowFromTimeEntry(TimeEntry te, string dateFormat, string timeFormat)
        {
            //string shortDateFormat = OutlookHelper.shortDate;
            DataGridViewRow dgvRow = gvTimeEntry.RowTemplate;
            string[] row6;            
            row6 = new string[]{
                te.Subject, te.OrganizationName, te.ProjectName, te.ActivityName, 
                te.StartTimeStamp.ToString(dateFormat) + " : " + te.StartTimeStamp.ToString(timeFormat),
                te.EndTimeStamp.ToString(dateFormat) + " : " + te.StartTimeStamp.ToString(timeFormat),
                te.Status.ToString(),
                Constants.TRUE_IN_LOWER_CHARS,Constants.FALSE_IN_LOWER_CHARS,Constants.FALSE_IN_LOWER_CHARS};
            return row6;            
        }
        #endregion 
      
        #region Add columns for grid view             
        private void gvTimeEntry_SetWidthColumns()
        {
            gvTimeEntry.Columns[COLUMUN_NAME_QUESTIONS_STATUS_1].Width = 70;
            gvTimeEntry.Columns[COLUMUN_NAME_QUESTIONS_STATUS_2].Width = 70;
            gvTimeEntry.Columns[COLUMUN_NAME_QUESTIONS_STATUS_3].Width = 70;

        }        
        private void PrepareGridView(DataGridView dgv)
        {
            if (dgv.Columns.Count == 0)
            {                
                
                DataGridViewColumn dgvSubjectColumn = GetTextBoxColumn(Core.ResourceHelper.Subject, TimeEntry.Property_Subject);

                DataGridViewColumn dgvOrganizationColumn = GetTextBoxColumn(Core.ResourceHelper.Organization, TimeEntry.Property_OrganizationName);
                DataGridViewColumn dgvProjectColumn = GetTextBoxColumn(Core.ResourceHelper.Project, TimeEntry.Property_ProjectName);
                DataGridViewColumn dgvActivityColumn = GetTextBoxColumn(Core.ResourceHelper.Activity, TimeEntry.Property_ActivityName);
                //DataGridViewColumn dgvTaskColumn = GetTextBoxColumn(Core.ResourceHelper.Task, Entity.TimeEntry.COL_TASKNAME);
                DataGridViewColumn dgvStartTimeColumn = GetTextBoxColumn(Core.ResourceHelper.StartTime, TimeEntry.Property_StartTime);
                DataGridViewColumn dgvEndTimeColumn = GetTextBoxColumn(Core.ResourceHelper.EndTime, TimeEntry.Property_EndTime);
                DataGridViewColumn dgvStatusColumn = GetTextBoxColumn(Core.ResourceHelper.Status, TimeEntry.Property_Status);                

                dgv.Columns.Add(dgvSubjectColumn);
                dgv.Columns.Add(dgvOrganizationColumn);
                dgv.Columns.Add(dgvProjectColumn);
                dgv.Columns.Add(dgvActivityColumn);
                //dgv.Columns.Add(dgvTaskColumn);
                dgv.Columns.Add(dgvStartTimeColumn);
                dgv.Columns.Add(dgvEndTimeColumn);
                dgv.Columns.Add(dgvStatusColumn);

                string s = "Check all/Uncheck all";
                DataGridViewCheckBoxColumn column1 = new DataGridViewCheckBoxColumn();
                column1.Name = COLUMUN_NAME_QUESTIONS_STATUS_1;
                column1.HeaderText = this.ColumnHeaderText1;
                column1.HeaderCell.ToolTipText = s;                
                dgv.Columns.Add(column1);

                DataGridViewCheckBoxColumn column2 = new DataGridViewCheckBoxColumn();
                column2.Name = COLUMUN_NAME_QUESTIONS_STATUS_2;
                column2.HeaderText = this.ColumnHeaderText2;
                column2.HeaderCell.ToolTipText = s;
                dgv.Columns.Add(column2);

                DataGridViewCheckBoxColumn column3 = new DataGridViewCheckBoxColumn();
                column3.Name = COLUMUN_NAME_QUESTIONS_STATUS_3;
                column3.HeaderText = this.ColumnHeaderText3;
                column3.HeaderCell.ToolTipText = s;
                dgv.Columns.Add(column3);

            }
        }
       
        private static DataGridViewTextBoxColumn GetTextBoxColumn(string name, string dataPropertyName)
        {
            DataGridViewTextBoxColumn statusColumn = new DataGridViewTextBoxColumn();
            statusColumn.Name = dataPropertyName;
            statusColumn.HeaderText = name;
            statusColumn.DataPropertyName = dataPropertyName;

            statusColumn.SortMode = DataGridViewColumnSortMode.Programmatic;

            return statusColumn;
        }

        #endregion
    }
}
