﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.Core;

namespace TSR.Shell
{
    public partial class OverwriteTimeEntries : Controls.OUAForm, ISyncEngineOverwriteTimeEntry
    {
        private TSR.Core.Entity.TimeEntryList dataSource;

        private TSR.Core.Entity.TimeEntryList listCheckedTimeEtries;

        public OverwriteTimeEntries()
        {
            InitializeComponent();          
        }

        private void frmOverwriteTimeEntries_Load(object sender, EventArgs e)
        {            
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);

            lblMessage.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);
            this.Icon = TSR.Core.ResourceHelper.TSRIcon; // set icon                    
            this.StartPosition = FormStartPosition.CenterScreen;

            ucOverwriteTimeEntries.IsOverwriteTimeEntries = true;
            ucOverwriteTimeEntries.EnableSelection = true;

            ucOverwriteTimeEntries.DataSource = dataSource;

            SetText();

            ucOverwriteTimeEntries.chkSelectChecked +=new Shell.Controls.ucTSRItemList.chkSelectCheckedEventHandler(ucOverwriteTimeEntries_chkSelectChecked);         
        }

        private void SetText()
        {
            lblMessage.Text = TSR.Core.ResourceManager.GetResourceString("OverwriteTimeEntriesLabel","These time entries were linked to appointments that these appointments was linked to another time entries on server. Please choose time entries that you want to overwrite to server");
            chkSelectAllOrNo.Text = TSR.Core.ResourceManager.GetResourceString("CheckAllOrDeselectAll", "Check All/Deselect All").Replace("&#47;", "/");
        }
        private void chkSelectAllOrNo_CheckedChanged(object sender, EventArgs e)
        {            
        }

        private void ucOverwriteTimeEntries_chkSelectChecked()
        {
            if (ucOverwriteTimeEntries.CheckedTimeEntries.Count == ucOverwriteTimeEntries.DataSource.Count)
            {
                chkSelectAllOrNo.CheckState = CheckState.Checked;                
            }
            else if (ucOverwriteTimeEntries.CheckedTimeEntries.Count == 0)
            {
                chkSelectAllOrNo.CheckState = CheckState.Unchecked;                
            }
            else
            {                
                chkSelectAllOrNo.CheckState = CheckState.Indeterminate;                
            }
        }

        private void chkSelectAllOrNo_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkSelectAllOrNo.CheckState == CheckState.Checked)            
                ucOverwriteTimeEntries.ToggleAllSelect(true);
            else if (chkSelectAllOrNo.CheckState == CheckState.Unchecked)
                ucOverwriteTimeEntries.ToggleAllSelect(false);
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            listCheckedTimeEtries = ucOverwriteTimeEntries.CheckedTimeEntries;
            base.OnClosing(e);
        }

        //Interface member
        public TSR.Core.Entity.TimeEntryList ShowOverwriteTimeEntries(TSR.Core.Entity.TimeEntryList listSource)
        {
            this.dataSource = listSource;

            base.ShowDialog();

            return listCheckedTimeEtries;
        }        
    }
}
