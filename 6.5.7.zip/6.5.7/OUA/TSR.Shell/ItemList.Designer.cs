namespace TSR.Shell
{
    partial class ItemList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tableTotalDuration = new System.Windows.Forms.TableLayoutPanel();
            this.lblTotalDurationValue = new System.Windows.Forms.Label();
            this.lblTotalDurationText = new System.Windows.Forms.Label();
            this.lblTotalDurationSelectedText = new System.Windows.Forms.Label();
            this.lblTotalDurationSelectedValue = new System.Windows.Forms.Label();
            this.btnNext7Days = new System.Windows.Forms.Button();
            this.btnPrevious7Days = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblRecurringTE = new System.Windows.Forms.Label();
            this.ckShowInvalidTE = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblOldDBData = new System.Windows.Forms.Label();
            this.lblTemplateMissing = new System.Windows.Forms.Label();
            this.grpSearch = new System.Windows.Forms.GroupBox();
            this.clbStatus = new System.Windows.Forms.CheckedListBox();
            this.clbOrganizations = new System.Windows.Forms.CheckedListBox();
            this.clbActivities = new System.Windows.Forms.CheckedListBox();
            this.clbProjects = new System.Windows.Forms.CheckedListBox();
            this.chkAllStatus = new System.Windows.Forms.CheckBox();
            this.chkAllOrg = new System.Windows.Forms.CheckBox();
            this.chkAllProj = new System.Windows.Forms.CheckBox();
            this.chkAllActs = new System.Windows.Forms.CheckBox();
            this.clbTasks = new System.Windows.Forms.CheckedListBox();
            this.lblTask = new System.Windows.Forms.Label();
            this.dtpStartTime = new System.Windows.Forms.DateTimePicker();
            this.lblProject = new System.Windows.Forms.Label();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.lblOrganization = new System.Windows.Forms.Label();
            this.lblActivity = new System.Windows.Forms.Label();
            this.dtpEndTime = new System.Windows.Forms.DateTimePicker();
            this.lblEndTime = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.lblSubject = new System.Windows.Forms.Label();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblIsCreatedViaWeb = new System.Windows.Forms.Label();
            this.ucTSRItemList1 = new TSR.Shell.Controls.ucTSRItemList();
            this.tableTotalDuration.SuspendLayout();
            this.grpSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnSearch.Location = new System.Drawing.Point(734, 24);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(734, 613);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // tableTotalDuration
            // 
            this.tableTotalDuration.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableTotalDuration.ColumnCount = 4;
            this.tableTotalDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableTotalDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableTotalDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableTotalDuration.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableTotalDuration.Controls.Add(this.lblTotalDurationValue, 3, 0);
            this.tableTotalDuration.Controls.Add(this.lblTotalDurationText, 2, 0);
            this.tableTotalDuration.Controls.Add(this.lblTotalDurationSelectedText, 0, 0);
            this.tableTotalDuration.Controls.Add(this.lblTotalDurationSelectedValue, 1, 0);
            this.tableTotalDuration.Location = new System.Drawing.Point(133, 249);
            this.tableTotalDuration.Name = "tableTotalDuration";
            this.tableTotalDuration.RowCount = 1;
            this.tableTotalDuration.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableTotalDuration.Size = new System.Drawing.Size(593, 17);
            this.tableTotalDuration.TabIndex = 31;
            // 
            // lblTotalDurationValue
            // 
            this.lblTotalDurationValue.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTotalDurationValue.AutoSize = true;
            this.lblTotalDurationValue.Location = new System.Drawing.Point(475, 2);
            this.lblTotalDurationValue.Name = "lblTotalDurationValue";
            this.lblTotalDurationValue.Size = new System.Drawing.Size(35, 13);
            this.lblTotalDurationValue.TabIndex = 18;
            this.lblTotalDurationValue.Text = "label4";
            // 
            // lblTotalDurationText
            // 
            this.lblTotalDurationText.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTotalDurationText.AutoSize = true;
            this.lblTotalDurationText.Location = new System.Drawing.Point(333, 2);
            this.lblTotalDurationText.Name = "lblTotalDurationText";
            this.lblTotalDurationText.Size = new System.Drawing.Size(136, 13);
            this.lblTotalDurationText.TabIndex = 17;
            this.lblTotalDurationText.Text = "Total duration of list entries:";
            // 
            // lblTotalDurationSelectedText
            // 
            this.lblTotalDurationSelectedText.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTotalDurationSelectedText.AutoSize = true;
            this.lblTotalDurationSelectedText.Location = new System.Drawing.Point(10, 2);
            this.lblTotalDurationSelectedText.Name = "lblTotalDurationSelectedText";
            this.lblTotalDurationSelectedText.Size = new System.Drawing.Size(164, 13);
            this.lblTotalDurationSelectedText.TabIndex = 15;
            this.lblTotalDurationSelectedText.Text = "Total duration of selected entries:";
            // 
            // lblTotalDurationSelectedValue
            // 
            this.lblTotalDurationSelectedValue.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblTotalDurationSelectedValue.AutoSize = true;
            this.lblTotalDurationSelectedValue.Location = new System.Drawing.Point(180, 2);
            this.lblTotalDurationSelectedValue.Name = "lblTotalDurationSelectedValue";
            this.lblTotalDurationSelectedValue.Size = new System.Drawing.Size(13, 13);
            this.lblTotalDurationSelectedValue.TabIndex = 16;
            this.lblTotalDurationSelectedValue.Text = "0";
            // 
            // btnNext7Days
            // 
            this.btnNext7Days.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext7Days.Location = new System.Drawing.Point(697, 584);
            this.btnNext7Days.Name = "btnNext7Days";
            this.btnNext7Days.Size = new System.Drawing.Size(112, 23);
            this.btnNext7Days.TabIndex = 20;
            this.btnNext7Days.Text = "Next 7 days";
            this.btnNext7Days.UseVisualStyleBackColor = true;
            this.btnNext7Days.Click += new System.EventHandler(this.btnNext7Days_Click);
            // 
            // btnPrevious7Days
            // 
            this.btnPrevious7Days.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrevious7Days.Location = new System.Drawing.Point(574, 584);
            this.btnPrevious7Days.Name = "btnPrevious7Days";
            this.btnPrevious7Days.Size = new System.Drawing.Size(117, 23);
            this.btnPrevious7Days.TabIndex = 19;
            this.btnPrevious7Days.Text = "Previous 7 days";
            this.btnPrevious7Days.UseVisualStyleBackColor = true;
            this.btnPrevious7Days.Click += new System.EventHandler(this.btnPrevious7Days_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(426, 599);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(15, 15);
            this.panel3.TabIndex = 14;
            this.panel3.Visible = false;
            // 
            // lblRecurringTE
            // 
            this.lblRecurringTE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblRecurringTE.AutoSize = true;
            this.lblRecurringTE.Location = new System.Drawing.Point(444, 602);
            this.lblRecurringTE.Name = "lblRecurringTE";
            this.lblRecurringTE.Size = new System.Drawing.Size(35, 13);
            this.lblRecurringTE.TabIndex = 13;
            this.lblRecurringTE.Text = "label1";
            this.lblRecurringTE.Visible = false;
            // 
            // ckShowInvalidTE
            // 
            this.ckShowInvalidTE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ckShowInvalidTE.AutoSize = true;
            this.ckShowInvalidTE.Location = new System.Drawing.Point(13, 598);
            this.ckShowInvalidTE.Name = "ckShowInvalidTE";
            this.ckShowInvalidTE.Size = new System.Drawing.Size(80, 17);
            this.ckShowInvalidTE.TabIndex = 12;
            this.ckShowInvalidTE.Text = "checkBox1";
            this.ckShowInvalidTE.UseVisualStyleBackColor = true;
            this.ckShowInvalidTE.CheckedChanged += new System.EventHandler(this.ckShowInvalidTE_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(426, 622);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(15, 15);
            this.panel2.TabIndex = 11;
            this.panel2.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(13, 620);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(15, 15);
            this.panel1.TabIndex = 10;
            // 
            // lblOldDBData
            // 
            this.lblOldDBData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblOldDBData.AutoSize = true;
            this.lblOldDBData.Location = new System.Drawing.Point(444, 623);
            this.lblOldDBData.Name = "lblOldDBData";
            this.lblOldDBData.Size = new System.Drawing.Size(35, 13);
            this.lblOldDBData.TabIndex = 9;
            this.lblOldDBData.Text = "label1";
            this.lblOldDBData.Visible = false;
            // 
            // lblTemplateMissing
            // 
            this.lblTemplateMissing.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTemplateMissing.AutoSize = true;
            this.lblTemplateMissing.Location = new System.Drawing.Point(33, 622);
            this.lblTemplateMissing.Name = "lblTemplateMissing";
            this.lblTemplateMissing.Size = new System.Drawing.Size(35, 13);
            this.lblTemplateMissing.TabIndex = 9;
            this.lblTemplateMissing.Text = "label1";
            // 
            // grpSearch
            // 
            this.grpSearch.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.grpSearch.Controls.Add(this.clbStatus);
            this.grpSearch.Controls.Add(this.clbOrganizations);
            this.grpSearch.Controls.Add(this.clbActivities);
            this.grpSearch.Controls.Add(this.clbProjects);
            this.grpSearch.Controls.Add(this.chkAllStatus);
            this.grpSearch.Controls.Add(this.chkAllOrg);
            this.grpSearch.Controls.Add(this.chkAllProj);
            this.grpSearch.Controls.Add(this.chkAllActs);
            this.grpSearch.Controls.Add(this.clbTasks);
            this.grpSearch.Controls.Add(this.lblTask);
            this.grpSearch.Controls.Add(this.dtpStartTime);
            this.grpSearch.Controls.Add(this.lblProject);
            this.grpSearch.Controls.Add(this.lblStartTime);
            this.grpSearch.Controls.Add(this.lblOrganization);
            this.grpSearch.Controls.Add(this.lblActivity);
            this.grpSearch.Controls.Add(this.dtpEndTime);
            this.grpSearch.Controls.Add(this.lblEndTime);
            this.grpSearch.Controls.Add(this.lblStatus);
            this.grpSearch.Controls.Add(this.txtSubject);
            this.grpSearch.Controls.Add(this.lblSubject);
            this.grpSearch.Location = new System.Drawing.Point(8, 8);
            this.grpSearch.Name = "grpSearch";
            this.grpSearch.Size = new System.Drawing.Size(718, 235);
            this.grpSearch.TabIndex = 0;
            this.grpSearch.TabStop = false;
            this.grpSearch.Text = "Search Items";
            // 
            // clbStatus
            // 
            this.clbStatus.CheckOnClick = true;
            this.clbStatus.FormattingEnabled = true;
            this.clbStatus.Location = new System.Drawing.Point(509, 40);
            this.clbStatus.Name = "clbStatus";
            this.clbStatus.Size = new System.Drawing.Size(156, 79);
            this.clbStatus.TabIndex = 10;
            this.clbStatus.MouseUp += new System.Windows.Forms.MouseEventHandler(this.clbStatus_MouseUp);
            // 
            // clbOrganizations
            // 
            this.clbOrganizations.BackColor = System.Drawing.Color.White;
            this.clbOrganizations.CheckOnClick = true;
            this.clbOrganizations.FormattingEnabled = true;
            this.clbOrganizations.Location = new System.Drawing.Point(85, 144);
            this.clbOrganizations.Name = "clbOrganizations";
            this.clbOrganizations.Size = new System.Drawing.Size(156, 79);
            this.clbOrganizations.TabIndex = 4;
            this.clbOrganizations.SelectedIndexChanged += new System.EventHandler(this.clbOrganizations_SelectedIndexChanged);
            this.clbOrganizations.DoubleClick += new System.EventHandler(this.clbOrganizations_DoubleClick);
            this.clbOrganizations.MouseUp += new System.Windows.Forms.MouseEventHandler(this.clbOrganizations_MouseUp);
            // 
            // clbActivities
            // 
            this.clbActivities.CheckOnClick = true;
            this.clbActivities.FormattingEnabled = true;
            this.clbActivities.Location = new System.Drawing.Point(297, 143);
            this.clbActivities.Name = "clbActivities";
            this.clbActivities.Size = new System.Drawing.Size(156, 79);
            this.clbActivities.TabIndex = 8;
            this.clbActivities.SelectedIndexChanged += new System.EventHandler(this.clbActivities_SelectedIndexChanged);
            this.clbActivities.MouseUp += new System.Windows.Forms.MouseEventHandler(this.clbActivities_MouseUp);
            // 
            // clbProjects
            // 
            this.clbProjects.CheckOnClick = true;
            this.clbProjects.FormattingEnabled = true;
            this.clbProjects.Location = new System.Drawing.Point(297, 40);
            this.clbProjects.Name = "clbProjects";
            this.clbProjects.Size = new System.Drawing.Size(156, 79);
            this.clbProjects.TabIndex = 6;
            this.clbProjects.ThreeDCheckBoxes = true;
            this.clbProjects.SelectedIndexChanged += new System.EventHandler(this.clbProjects_SelectedIndexChanged);
            this.clbProjects.DoubleClick += new System.EventHandler(this.clbProjects_DoubleClick);
            this.clbProjects.MouseUp += new System.Windows.Forms.MouseEventHandler(this.clbProjects_MouseUp);
            // 
            // chkAllStatus
            // 
            this.chkAllStatus.Location = new System.Drawing.Point(511, 23);
            this.chkAllStatus.Name = "chkAllStatus";
            this.chkAllStatus.Size = new System.Drawing.Size(100, 17);
            this.chkAllStatus.TabIndex = 9;
            this.chkAllStatus.Text = "Select All";
            this.chkAllStatus.UseVisualStyleBackColor = true;
            this.chkAllStatus.CheckedChanged += new System.EventHandler(this.chkAllStatus_CheckedChanged);
            this.chkAllStatus.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkAllStatus_MouseUp);
            // 
            // chkAllOrg
            // 
            this.chkAllOrg.Location = new System.Drawing.Point(87, 127);
            this.chkAllOrg.Name = "chkAllOrg";
            this.chkAllOrg.Size = new System.Drawing.Size(100, 17);
            this.chkAllOrg.TabIndex = 3;
            this.chkAllOrg.Text = "Select All";
            this.chkAllOrg.UseVisualStyleBackColor = true;
            this.chkAllOrg.CheckedChanged += new System.EventHandler(this.chkAllOrg_CheckedChanged);
            this.chkAllOrg.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkAllOrg_MouseUp);
            // 
            // chkAllProj
            // 
            this.chkAllProj.Location = new System.Drawing.Point(299, 23);
            this.chkAllProj.Name = "chkAllProj";
            this.chkAllProj.Size = new System.Drawing.Size(100, 17);
            this.chkAllProj.TabIndex = 5;
            this.chkAllProj.Text = "Select All";
            this.chkAllProj.UseVisualStyleBackColor = true;
            this.chkAllProj.CheckedChanged += new System.EventHandler(this.chkAllProj_CheckedChanged);
            this.chkAllProj.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkAllProj_MouseUp);
            // 
            // chkAllActs
            // 
            this.chkAllActs.Location = new System.Drawing.Point(299, 126);
            this.chkAllActs.Name = "chkAllActs";
            this.chkAllActs.Size = new System.Drawing.Size(100, 17);
            this.chkAllActs.TabIndex = 7;
            this.chkAllActs.Text = "Select All";
            this.chkAllActs.UseVisualStyleBackColor = true;
            this.chkAllActs.CheckedChanged += new System.EventHandler(this.chkAllActs_CheckedChanged);
            this.chkAllActs.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkAllActs_MouseUp);
            // 
            // clbTasks
            // 
            this.clbTasks.CheckOnClick = true;
            this.clbTasks.FormattingEnabled = true;
            this.clbTasks.Location = new System.Drawing.Point(510, 144);
            this.clbTasks.Name = "clbTasks";
            this.clbTasks.Size = new System.Drawing.Size(156, 79);
            this.clbTasks.TabIndex = 11;
            this.clbTasks.Visible = false;
            // 
            // lblTask
            // 
            this.lblTask.Location = new System.Drawing.Point(456, 126);
            this.lblTask.Name = "lblTask";
            this.lblTask.Size = new System.Drawing.Size(48, 13);
            this.lblTask.TabIndex = 30;
            this.lblTask.Text = "Task";
            this.lblTask.Visible = false;
            // 
            // dtpStartTime
            // 
            this.dtpStartTime.CalendarTitleBackColor = System.Drawing.SystemColors.InactiveCaption;
            this.dtpStartTime.CalendarTitleForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpStartTime.CustomFormat = "";
            this.dtpStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartTime.Location = new System.Drawing.Point(85, 46);
            this.dtpStartTime.Name = "dtpStartTime";
            this.dtpStartTime.Size = new System.Drawing.Size(154, 20);
            this.dtpStartTime.TabIndex = 1;
            // 
            // lblProject
            // 
            this.lblProject.Location = new System.Drawing.Point(245, 24);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(48, 13);
            this.lblProject.TabIndex = 18;
            this.lblProject.Text = "Project";
            // 
            // lblStartTime
            // 
            this.lblStartTime.Location = new System.Drawing.Point(7, 50);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(69, 13);
            this.lblStartTime.TabIndex = 22;
            this.lblStartTime.Text = "Start Time";
            // 
            // lblOrganization
            // 
            this.lblOrganization.Location = new System.Drawing.Point(7, 128);
            this.lblOrganization.Name = "lblOrganization";
            this.lblOrganization.Size = new System.Drawing.Size(72, 13);
            this.lblOrganization.TabIndex = 26;
            this.lblOrganization.Text = "Organization";
            // 
            // lblActivity
            // 
            this.lblActivity.Location = new System.Drawing.Point(244, 127);
            this.lblActivity.Name = "lblActivity";
            this.lblActivity.Size = new System.Drawing.Size(48, 13);
            this.lblActivity.TabIndex = 28;
            this.lblActivity.Text = "Activity";
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.CalendarTitleBackColor = System.Drawing.SystemColors.InactiveCaption;
            this.dtpEndTime.CalendarTitleForeColor = System.Drawing.SystemColors.ControlText;
            this.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEndTime.Location = new System.Drawing.Point(85, 74);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.Size = new System.Drawing.Size(154, 20);
            this.dtpEndTime.TabIndex = 2;
            // 
            // lblEndTime
            // 
            this.lblEndTime.Location = new System.Drawing.Point(7, 78);
            this.lblEndTime.Name = "lblEndTime";
            this.lblEndTime.Size = new System.Drawing.Size(69, 13);
            this.lblEndTime.TabIndex = 23;
            this.lblEndTime.Text = "End Time";
            // 
            // lblStatus
            // 
            this.lblStatus.Location = new System.Drawing.Point(458, 24);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(48, 13);
            this.lblStatus.TabIndex = 20;
            this.lblStatus.Text = "Status";
            // 
            // txtSubject
            // 
            this.txtSubject.Location = new System.Drawing.Point(85, 21);
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(154, 20);
            this.txtSubject.TabIndex = 0;
            // 
            // lblSubject
            // 
            this.lblSubject.Location = new System.Drawing.Point(7, 24);
            this.lblSubject.Name = "lblSubject";
            this.lblSubject.Size = new System.Drawing.Size(69, 14);
            this.lblSubject.TabIndex = 16;
            this.lblSubject.Text = "Subject";
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.Location = new System.Drawing.Point(14, 249);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(100, 17);
            this.chkSelectAll.TabIndex = 3;
            this.chkSelectAll.Text = "Select All";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnSubmit.Location = new System.Drawing.Point(655, 613);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 6;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnDelete.Location = new System.Drawing.Point(574, 613);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnReset.Location = new System.Drawing.Point(734, 56);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Location = new System.Drawing.Point(244, 599);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(15, 15);
            this.panel4.TabIndex = 33;
            // 
            // lblIsCreatedViaWeb
            // 
            this.lblIsCreatedViaWeb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblIsCreatedViaWeb.AutoSize = true;
            this.lblIsCreatedViaWeb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsCreatedViaWeb.ForeColor = System.Drawing.Color.Black;
            this.lblIsCreatedViaWeb.Location = new System.Drawing.Point(264, 601);
            this.lblIsCreatedViaWeb.Name = "lblIsCreatedViaWeb";
            this.lblIsCreatedViaWeb.Size = new System.Drawing.Size(35, 13);
            this.lblIsCreatedViaWeb.TabIndex = 32;
            this.lblIsCreatedViaWeb.Text = "label1";
            // 
            // ucTSRItemList1
            // 
            this.ucTSRItemList1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ucTSRItemList1.EnableSelection = true;
            this.ucTSRItemList1.Location = new System.Drawing.Point(8, 272);
            this.ucTSRItemList1.Name = "ucTSRItemList1";
            this.ucTSRItemList1.Size = new System.Drawing.Size(801, 306);
            this.ucTSRItemList1.TabIndex = 4;
            // 
            // ItemList
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(815, 645);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.lblIsCreatedViaWeb);
            this.Controls.Add(this.tableTotalDuration);
            this.Controls.Add(this.btnNext7Days);
            this.Controls.Add(this.btnPrevious7Days);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lblRecurringTE);
            this.Controls.Add(this.ckShowInvalidTE);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblOldDBData);
            this.Controls.Add(this.lblTemplateMissing);
            this.Controls.Add(this.ucTSRItemList1);
            this.Controls.Add(this.grpSearch);
            this.Controls.Add(this.chkSelectAll);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnReset);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ItemList";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Items";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ItemList_FormClosed);
            this.Load += new System.EventHandler(this.ItemList_FormLoad);
            this.tableTotalDuration.ResumeLayout(false);
            this.tableTotalDuration.PerformLayout();
            this.grpSearch.ResumeLayout(false);
            this.grpSearch.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.GroupBox grpSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DateTimePicker dtpEndTime;
        private System.Windows.Forms.Label lblEndTime;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblProject;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label lblSubject;
        private System.Windows.Forms.Label lblTask;
        private System.Windows.Forms.Label lblActivity;
        private System.Windows.Forms.Label lblOrganization;
        private System.Windows.Forms.Button btnReset;
        private TSR.Shell.Controls.ucTSRItemList ucTSRItemList1;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.CheckedListBox clbProjects;
        private System.Windows.Forms.CheckedListBox clbActivities;
        private System.Windows.Forms.CheckedListBox clbStatus;
        private System.Windows.Forms.CheckedListBox clbTasks;
        private System.Windows.Forms.CheckBox chkAllActs;
        private System.Windows.Forms.CheckBox chkAllStatus;
        private System.Windows.Forms.CheckBox chkAllProj;
        private System.Windows.Forms.CheckedListBox clbOrganizations;
        private System.Windows.Forms.CheckBox chkAllOrg;
        private System.Windows.Forms.Label lblTemplateMissing;
        private System.Windows.Forms.Label lblOldDBData;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox ckShowInvalidTE;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblRecurringTE;
        private System.Windows.Forms.Label lblTotalDurationSelectedText;
        public System.Windows.Forms.Label lblTotalDurationSelectedValue;
        private System.Windows.Forms.Label lblTotalDurationText;
        private System.Windows.Forms.Label lblTotalDurationValue;
        private System.Windows.Forms.Button btnPrevious7Days;
        private System.Windows.Forms.Button btnNext7Days;
        private System.Windows.Forms.DateTimePicker dtpStartTime;
        private System.Windows.Forms.TableLayoutPanel tableTotalDuration;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblIsCreatedViaWeb;
    }
}