﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace TSR.Shell.Utilities
{
    public static class Helper
    {
        public static bool IsDecimal(string value, out decimal number)
        {
            Char decimalSymbol = Convert.ToChar(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
            string reg = @"^\d{1,13}\" + decimalSymbol + @"\d{1,2}$";
            string reg2 = @"^(?!0)\d{1,13}$";
            try
            {
                if (Regex.IsMatch(value, reg) || Regex.IsMatch(value, reg2))
                {
                    number = decimal.Parse(value);
                    return true;
                }
                else
                {
                    number = 0;
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }

        public static string GetDateFormat()
        {
            if (!TSR.Core.SettingsHelper.TSRDateFormat.Equals("NA"))
                return ReverseToHTMLCode(TSR.Core.SettingsHelper.TSRDateFormat);
            else
                return CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
        }

    }
}
