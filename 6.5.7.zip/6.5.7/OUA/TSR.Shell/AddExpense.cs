﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TSR.Shell.Utilities;
using Entity = TSR.Core.Entity;
using TSR.Core.Entity;
using TSR.Core;

namespace TSR.Shell
{
    public partial class AddExpense : Controls.OUAForm
    {
        private ExpenseEntry expenseEntry;
        private bool isNew;
        private decimal _zeroValue = 0;

        static char decimalSymbol = Convert.ToChar(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);

        public AddExpense(ExpenseEntry entry, bool isNew)
        {
            this.expenseEntry = entry;
            this.isNew = isNew;
            InitializeComponent();    
        }

        private void AddExpense_Load(object sender, EventArgs e)
        {
            CultureInfo userCulture = Core.TSRFacade.GetCurrentCulture();
            CultureInfo sysCulture = (CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            sysCulture.NumberFormat = userCulture.NumberFormat;
            decimalSymbol = Convert.ToChar(sysCulture.NumberFormat.NumberDecimalSeparator);

            if (isNew)
                this.Text = Core.ResourceManager.GetResourceString("AddExpense", "Add Expense");
            else
                this.Text = Core.ResourceManager.GetResourceString("EditExpense", "Edit Expense");

            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);

            //this.Text = Core.ResourceManager.GetResourceString("Expenses", "Expenses");
            lblExpenseType.Text = Core.ResourceManager.GetResourceString("ExpenseType", "Expense Type");
            lblDescription.Text = Core.ResourceManager.GetResourceString("Text", "Text");
            lblLocation.Text = Core.ResourceHelper.Location;
            lblQuantity.Text = Core.ResourceManager.GetResourceString("Quantity", "Quantity");
            lblValue.Text = Core.ResourceManager.GetResourceString("Value", "Value");
            lblTotal.Text = Core.ResourceManager.GetResourceString("Total", "Total");
            btnOK.Text = ResourceHelper.OK;
            btnCancel.Text = ResourceHelper.Cancel;

            PopulateExpenseTypeCombo();
            PopulateLocationCombo();
            PopulateExpenseInfosToControls();
        }

        private string getExpenseEntryInfoFromControls(ExpenseEntry entry)
        {
            string errorMessage = string.Empty;
            decimal value = 0;
            decimal quantity = 0;
            long expenseTypeID = 0;
            string description = txtDescription.Text;
            ExpenseType type = (ExpenseType)cbExpenseType.SelectedItem;
            
            if(type !=null)
            {
                expenseTypeID = type.ID;
            }

            Location location = (Location)cbLocation.SelectedItem;
            
            if(expenseTypeID <= 0)
            {
                errorMessage = Core.ResourceManager.GetResourceString("PleaseSelectExpenseType", "Please select expense type");
                return errorMessage;
            }
            else if (string.IsNullOrEmpty(txtDescription.Text))
            {
                errorMessage = Core.ResourceManager.GetResourceString("PleaseEnterText", "Please enter a text");
                return errorMessage;
            }
            else if(!decimal.TryParse(txtQuantity.Text, out quantity))
            {
                errorMessage = Core.ResourceManager.GetResourceString("QuantityIncorrect", "The Quantity is incorrect");
                return errorMessage;
            }
            else if(!decimal.TryParse(txtValue.Text, out value))
            {
                errorMessage = Core.ResourceManager.GetResourceString("ValueIncorrect", "The value is incorrect");
                return errorMessage;
            }

            if(string.IsNullOrEmpty(errorMessage))
            {
                quantity = Math.Round(quantity, 2);
                value = Math.Round(value, 2);

                entry.ExpenseTypeID = expenseTypeID;
                entry.Description = description;
                if (type.IsLockedValue)
                    entry.Value = type.DefaultValue.HasValue ? type.DefaultValue.Value : 0;
                else
                    entry.Value = value;
                entry.Quantity = quantity;
                entry.Total = entry.Quantity*entry.Value;
                entry.ExpenseTypeName = type.Name;
                if (location != null && location.ID > 0)
                {
                    entry.LocationID = location.ID;
                    entry.LocationName = location.Name;
                }
                else
                {
                    entry.LocationID = null;
                    entry.LocationName = string.Empty;
                }
                    
            }

            return errorMessage;
        }

        private void cbExpense_SelectedIndexChanged(object sender, EventArgs e)
        {
            ExpenseType item = (ExpenseType)cbExpenseType.SelectedItem;

            if(item != null && item.ID > 0)
            {
                decimal defaultValue = item.DefaultValue.HasValue?item.DefaultValue.Value:0;
                txtValue.Text = defaultValue.ToString("F2");
                if(item.IsLockedValue)
                {
                    txtValue.ReadOnly = true;
                }
                else
                {
                    txtValue.ReadOnly = false;
                }
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            string error = Core.ResourceManager.GetResourceString("Error", "Error");
            decimal quantity = 0, value = 0;
            if (!Helper.IsDecimal(txtQuantity.Text, out quantity) && double.Parse(txtQuantity.Text) > 0)
            {
                var message = ResourceManager.GetResourceString("QuantityIncorrect", "The Quantity is incorrect");
                MessageBox.Show(message, error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!Helper.IsDecimal(txtValue.Text, out value) && double.Parse(txtValue.Text) > 0)
            {
                var message = ResourceManager.GetResourceString("ValueIncorrect", "The Value is incorrect");
                MessageBox.Show(message, error, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string errorMess = getExpenseEntryInfoFromControls(expenseEntry);
            if (!string.IsNullOrEmpty(errorMess))
            {
                MessageBox.Show(errorMess, error,MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            CloseWindow();
        }

        private void CloseWindow()
        {
            this.Close();
            //this.Dispose();
        }

        private void PopulateExpenseTypeCombo()
        {
            Entity.ExpenseTypeList expenseTypeList = new ExpenseTypeList();
            try
            {
                List<ExpenseType> lst =
                    Core.TSRExpenseFacade.GetAllExpenseTypes()
                        .Where(x => x.IsActive == true)
                        .OrderBy(x => x.Name)
                        .ToList();

                ExpenseType empty = new ExpenseType();
                empty.Name = Core.ResourceManager.GetResourceString("SelectExpense", "Select an expense name");
                empty.ID = -1;

                lst.Insert(0, empty);

                cbExpenseType.DataSource = lst;
                cbExpenseType.DisplayMember = "Name";
                cbExpenseType.ValueMember = "ID";

            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// populates Location combo
        /// </summary>
        /// <param name="locationID"></param>
        private void PopulateLocationCombo()
        {
            Entity.LocationList locationList = Core.TSRFacade.GetAllLocations();
            if (locationList == null)
                locationList = new Entity.LocationList();
            List<Entity.Location> tempList = locationList.OrderBy(x => x.Name).ToList();

            Entity.LocationList activeLocationList = new Entity.LocationList();
            foreach (var item in tempList)
            {
                if (item.IsActivate == true)
                    activeLocationList.Add(item);
            }

            activeLocationList.InsertSelectionDefaultItem();

            UIHelper.FillComboBox(cbLocation, activeLocationList, Entity.Location.Property_Name, Entity.Location.Property_ID, false);
        }

        private void PopulateExpenseInfosToControls()
        {
            if (!isNew)
            {
                cbExpenseType.SelectedValue = expenseEntry.ExpenseTypeID;
                cbLocation.SelectedValue = expenseEntry.LocationID == null ? -1 : expenseEntry.LocationID;
                txtDescription.Text = expenseEntry.Description;
                txtQuantity.Text = expenseEntry.Quantity.ToString("F2");
                txtValue.Text = expenseEntry.Value.ToString("F2");
                txtTotal.Text = expenseEntry.Total.ToString("F2");
            }
            else
            {
                cbExpenseType.SelectedIndex = 0;                
                cbLocation.SelectedValue = expenseEntry.LocationID == null ? -1 : expenseEntry.LocationID;
                txtDescription.Text = string.Empty;
                txtQuantity.Text = _zeroValue.ToString("F2");
                txtValue.Text = _zeroValue.ToString("F2");
                txtTotal.Text = _zeroValue.ToString("F2");
            }
        }

        private void txtValue_TextChanged(object sender, EventArgs e)
        {
            recalculateTotal();
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            recalculateTotal();
        }

        private void recalculateTotal()
        {
            decimal value = 0;
            decimal quantity = 0;

            if (decimal.TryParse(txtQuantity.Text, out quantity) &&
                decimal.TryParse(txtValue.Text, out value))
            {
                quantity = Math.Round(quantity, 2);
                value = Math.Round(value, 2);
                var total = quantity * value;

                txtTotal.Text = total.ToString("F2");
            }
            else
            {
                txtTotal.Text = _zeroValue.ToString("F2");
            }
        }
        
        private void textBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != decimalSymbol))
            {
                e.Handled = true;                
            }

            // only allow one decimal point
            if ((e.KeyChar == decimalSymbol) && ((sender as TextBox).Text.IndexOf(decimalSymbol) > -1))
            {
                e.Handled = true;
            }

            if(txtQuantity.Text.Contains(decimalSymbol))
            {
                if(txtQuantity.Text.Length > 15 && e.KeyChar != 8)
                    e.Handled = true;
            }
            else if (txtQuantity.Text.Length > 12)
            {
                if (e.KeyChar != decimalSymbol && e.KeyChar != 8)
                    e.Handled = true;
            }
        }

        private void textBox_KeyPress2(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != decimalSymbol))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == decimalSymbol) && ((sender as TextBox).Text.IndexOf(decimalSymbol) > -1))
            {
                e.Handled = true;
            }

            if (txtValue.Text.Contains(decimalSymbol))
            {
                if (txtValue.Text.Length > 15 && e.KeyChar != 8)
                    e.Handled = true;
            }
            else if (txtValue.Text.Length > 12)
            {
                if (e.KeyChar != decimalSymbol && e.KeyChar != 8)
                    e.Handled = true;
            }
        }

        private void txtQuantity_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantity.Text))
            {
                txtQuantity.Text = _zeroValue.ToString("F2");
            }
            else if (string.IsNullOrEmpty(txtQuantity.Text) || txtQuantity.Text.EndsWith(decimalSymbol.ToString()))
            {
                txtQuantity.Text = txtQuantity.Text + "00";
            }
        }

        private void txtValue_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtValue.Text))
            {
                txtValue.Text = _zeroValue.ToString("F2");
            }
            else if (string.IsNullOrEmpty(txtValue.Text) || txtValue.Text.EndsWith(decimalSymbol.ToString()))
            {
                txtValue.Text = txtValue.Text + "00";
            }
        }
    }
}
