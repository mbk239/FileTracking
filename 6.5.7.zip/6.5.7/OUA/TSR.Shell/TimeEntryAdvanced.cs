using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Linq;
using TSR.Core.UserAgentService;
using Core = TSR.Core;
using Entity = TSR.Core.Entity;
using TSR.Core.Entity;
using TSR.Shell.Utilities;

//using WS = TSR.Core.UserAgentService;


namespace TSR.Shell
{
    /// <summary>
    /// Advanced screen, it is loaded when in outlook ribbon, advanced button is clicked
    /// </summary>
    public partial class TimeEntryAdvanced : Controls.OUAForm
    {
        ToolTip toolTip = null;
        ToolTip toolTip2 = null;
        bool toolTipShown;

        string tooltipOrg;
        string tooltipProj;
        string tooltipAct;

        private string tooltipResource_Org;
        private string tooltipResource_Proj;
        private string tooltipResource_Act;
        private string tooltipResource_Name;
        private string tooltipResource_Description;
        private string tooltipResource_Type;

        private static bool _favoritesComboIndexChanged = false;
        private static bool _orgComboIndexChanged = false;
        private static bool _projectComboIndexChanged = false;
        private static bool _activityComboIndexChanged = false;
        private static bool _isClickOk = false;

        private long organizationId;
        private long projectId;
        private long activityId;

        static char decimalSymbol = Convert.ToChar(System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);

        #region Properties

        private Entity.TimeEntry TSRTimeEntry;
        private Entity.ExpenseSheet TSRExpenseSheet;
        private Entity.ExpenseEntryList TSRExpenseEntryDeleted;

        //private bool Changed
        //{
        //    get
        //    {
        //        if (TSRTimeEntry.OrganizationID.ToString() != cmbOrganizations.SelectedValue.ToString() ||
        //            TSRTimeEntry.ProjectID.ToString() != cmbProjects.SelectedValue.ToString() ||
        //            TSRTimeEntry.ActivityID.ToString() != cmbActivities.SelectedValue.ToString() ||
        //            TSRTimeEntry.TaskID.ToString() != cmbTasks.SelectedValue.ToString() ||
        //            TSRTimeEntry.ContactID.ToString() != cmbContacts.SelectedValue.ToString() ||
        //            TSRTimeEntry.Message != GetCurrentMessageContent())                    
        //            return true;

        //        return false;
        //    }
        //}

        bool IsExpenseMode = false;

        #endregion

        #region Constructor

        public TimeEntryAdvanced(Entity.TimeEntry tsrTimeEntry)
        {
            TSRTimeEntry = tsrTimeEntry;
            if (TSRTimeEntry.ExpenseSheet == null)
            {
                TSRTimeEntry.ExpenseSheet = TSR.Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSRTimeEntry.ID);
            }

            TSRExpenseSheet = tsrTimeEntry.ExpenseSheet;
            DialogResult = DialogResult.Cancel;
            InitializeComponent();

            //btnEdit.Text = Core.ResourceManager.GetResourceString("Edit", "Edit");
            //btnDelete.Text = Core.ResourceManager.GetResourceString("Delete", "Delete");

            Entity.ActivityList listActivity = Core.TSRFacade.GetActivitiesForProject(10034);

            Entity.ActivityList listActivity2 = Core.TSRFacade.GetAllActivities();
        }
        #endregion

        #region Event Handlers

        /// <summary>
        /// Form load event for time entry advanced screen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TimeEntryAdvanced_Load(object sender, EventArgs e)
        {
            CultureInfo userCulture = Core.TSRFacade.GetCurrentCulture();
            CultureInfo sysCulture = (CultureInfo)System.Threading.Thread.CurrentThread.CurrentCulture.Clone();
            sysCulture.NumberFormat = userCulture.NumberFormat;
            decimalSymbol = Convert.ToChar(sysCulture.NumberFormat.NumberDecimalSeparator);

            System.Threading.Thread.CurrentThread.CurrentCulture = sysCulture;
            //userCulture.DateTimeFormat = sysCulture.DateTimeFormat;

            this.IsExpenseMode = TSR.Core.Constants.USERINEXPENSELICENSE;
            if (TSR.Core.SettingsHelper.TSRDisplayTooltip)
            {
                tooltipResource_Org = Core.ResourceManager.GetResourceString("Organization", "Organization");
                tooltipResource_Proj = Core.ResourceManager.GetResourceString("Project", "Project");
                tooltipResource_Act = Core.ResourceManager.GetResourceString("Activity", "Activity");
                tooltipResource_Description = Core.ResourceManager.GetResourceString("Description", "Description");
                tooltipResource_Type = Core.ResourceManager.GetResourceString("Type", "Type");
                tooltipResource_Name = Core.ResourceManager.GetResourceString("Name", "Name");

                cmbOrganizations.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cmbOrganizations_DropdownItemSelected);
                cmbProjects.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cmbProjects_DropdownItemSelected);
                cmbActivities.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cmbActivities_DropdownItemSelected);

                if (this.IsExpenseMode)
                {
                    cbbExpenseOrganization.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cbbExpenseOrganization_DropdownItemSelected);
                    cbbExpenseProject.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cbbExpenseProject_DropdownItemSelected);
                    cbbExpenseActivity.DropdownItemSelected += new ComboBoxTip.DropdownItemSelectedEventHandler(cbbExpenseActivity_DropdownItemSelected);
                }
            }
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            groupBox2.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            grpAdvancedAttributes.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            grpMessage.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            tbpAdvanced.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            if (TSRTimeEntry.OLAppointmentItem != null)
            {
                //if appointment is recurring, and opened as series, dont allow the user to change response
                if (TSRTimeEntry.OLAppointmentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    txtNewResponse.Enabled = false;
            }

            if (this.IsExpenseMode)
            {
                tbpExpenses.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
                gvExpensesSheet.AutoGenerateColumns = false;
                tableLayoutExpense.Enabled = true;

                if (TSRExpenseSheet == null)
                {
                    TSRExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSRTimeEntry.ID);
                }
            }
            else
            {
                tableLayoutExpense.Enabled = false;
            }            

            toolTip = new ToolTip();
            toolTip2 = new ToolTip();

            this.toolTipShown = false;

            this.tooltipOrg = this.tooltipProj = this.tooltipAct = string.Empty;

            gvExpensesSheet.Columns[2].HeaderText = Core.ResourceManager.GetResourceString("Name", "Name");
            gvExpensesSheet.Columns[3].HeaderText = Core.ResourceManager.GetResourceString("Text", "Text");
            gvExpensesSheet.Columns[4].HeaderText = Core.ResourceHelper.Location;
            gvExpensesSheet.Columns[5].HeaderText = Core.ResourceManager.GetResourceString("Quantity", "Quantity");
            gvExpensesSheet.Columns[6].HeaderText = Core.ResourceManager.GetResourceString("Value", "Value");
            gvExpensesSheet.Columns[7].HeaderText = Core.ResourceManager.GetResourceString("Total", "Total");
            gvExpensesSheet.Columns[8].HeaderText = Core.ResourceManager.GetResourceString("Edit", "Edit");
            gvExpensesSheet.Columns[9].HeaderText = Core.ResourceManager.GetResourceString("Delete", "Delete");
            TSRExpenseEntryDeleted = new Entity.ExpenseEntryList();

            PopulateAllControls();

            organizationId = TSRTimeEntry.OrganizationID;
            projectId = TSRTimeEntry.ProjectID;
            activityId = TSRTimeEntry.ActivityID;
        }

        #region For Tooltip

        private void cmbActivities_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cmbOrganizations);
            else
            {
                Entity.Activity act = cmbActivities.SelectedItem as Entity.Activity;

                if (act != null)
                {
                    string tip = tooltipResource_Act + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + act.Name + "\n";
                    tip += "    " + tooltipResource_Type + ": " + act.ActivityTypeName + "\n";
                    tip += "    " + tooltipResource_Description + ": " + act.Description;

                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cmbActivities, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        }

        private void cmbProjects_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cmbOrganizations);
            else
            {
                Entity.Project proj = cmbProjects.Items[e.SelectedItem] as Entity.Project;
                if (proj != null)
                {
                    string tip = tooltipResource_Proj + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + proj.Name + "\n";
                    tip += "    " + tooltipResource_Type + ": " + proj.ProjectTypeName + "\n";
                    tip += "    " + tooltipResource_Description + ": " + proj.Description;
                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cmbProjects, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        }

        private void cmbOrganizations_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cmbOrganizations);
            else
            {
                Entity.Organization org = cmbOrganizations.Items[e.SelectedItem] as Entity.Organization;
                if (org != null)
                {
                    string tip = tooltipResource_Org + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + org.Name + "\n";
                    tip += "    " + tooltipResource_Description + ": " + org.Description;
                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cmbOrganizations, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        }

        private void cbbExpenseActivity_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cbbExpenseOrganization);
            else
            {
                Entity.Activity act = cbbExpenseActivity.SelectedItem as Entity.Activity;

                if (act != null)
                {
                    string tip = tooltipResource_Act + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + act.Name + "\n";
                    tip += "    " + tooltipResource_Type + ": " + act.ActivityTypeName + "\n";
                    tip += "    " + tooltipResource_Description + ": " + act.Description;

                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cbbExpenseActivity, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        }

        private void cbbExpenseProject_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cbbExpenseOrganization);
            else
            {
                Entity.Project proj = cbbExpenseProject.Items[e.SelectedItem] as Entity.Project;
                if (proj != null)
                {
                    string tip = tooltipResource_Proj + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + proj.Name + "\n";
                    tip += "    " + tooltipResource_Type + ": " + proj.ProjectTypeName + "\n";
                    tip += "    " + tooltipResource_Description + ": " + proj.Description;
                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cbbExpenseProject, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        }

        private void cbbExpenseOrganization_DropdownItemSelected(object sender, ComboBoxTip.DropdownItemSelectedEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (e.SelectedItem <= 0 || e.Scrolled)
                toolTip2.Hide(cbbExpenseOrganization);
            else
            {
                Entity.Organization org = cbbExpenseOrganization.Items[e.SelectedItem] as Entity.Organization;
                if (org != null)
                {
                    string tip = tooltipResource_Org + ": \n";
                    tip += "    " + tooltipResource_Name + ": " + org.Name + "\n";
                    tip += "    " + tooltipResource_Description + ": " + org.Description;
                    if (tip.Length > 990)
                    {
                        tip = tip.Remove(989);
                        tip = tip + "...";
                    }
                    toolTip2.Show(tip, cbbExpenseOrganization, e.Bounds.Location.X + 150, e.Bounds.Location.Y + 15);
                }
            }
        } 

        #endregion

        /// <summary>
        /// cancel button event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            TSRTimeEntry.OrganizationID = organizationId;
            TSRTimeEntry.ProjectID = projectId;
            TSRTimeEntry.ActivityID = activityId;

            CloseWindow();
        }

        /// <summary>
        /// save button event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            _isClickOk = true;

            if (tableLayoutAdvanced.SelectedTab.Name == "tbpAdvanced")
            {
                SaveComboItems();
            }
            else if (tableLayoutAdvanced.SelectedTab.Name == "tbpExpenses")
            {
                SaveComboItemsExpense();
            }
            if (SaveAdvancedTimeEntryData())
                CloseWindow();
        }

        #endregion

        #region UI Actions

        #region Populate Controls

        /// <summary>
        /// populates all controls
        /// </summary>
        private void PopulateAllControls()
        {
            PopulateLocalizedTextFromResource();
            PopulateComboBoxes();

            if (this.IsExpenseMode)
            {                
                PopulateComboBoxesExpense();
                BindExpenseSheet(TSRExpenseSheet);
            }
            
            if (TSRTimeEntry.OLAppointmentItem != null)
            {//if it is recurring series, no need to populate notes
                if (TSRTimeEntry.OLAppointmentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    return;
            }
            //populate notes 
            PopulateNoteWithPreviousValue();
        }

        private void BindExpenseSheet(Entity.ExpenseSheet sheet)
        {
            if (this.IsExpenseMode)
            {                
                if (sheet != null && !sheet.IsDeleted)
                {
                    pnlExpenseStatus.Visible = true;
                    lblExpenseSheetStatus.Visible = true;
                    lblExpenseSheetStatus.Text = sheet.Status.ToString();
                    decimal total = 0;
                    if (sheet.ExpenseEntryListLocal != null && sheet.ExpenseEntryListLocal.Count > 0)
                    {
                        foreach (Entity.ExpenseEntry exp in sheet.ExpenseEntryListLocal)
                        {
                            exp.Description = Helper.ReverseToHTMLCode(exp.Description);
                            total += exp.Total;
                        }
                    }
                    lblExpenseTotalValue.Text = total.ToString("F2");

                    //clear
                    gvExpensesSheet.DataSource = null;
                    gvExpensesSheet.Rows.Clear();
                    gvExpensesSheet.DataSource = sheet.ExpenseEntryListLocal;
                }
                else
                {
                    pnlExpenseStatus.Visible = false;
                    lblExpenseSheetStatus.Visible = false;
                }

                gvExpensesSheet.Refresh();

                enableExpenseControls(TSRTimeEntry, TSRExpenseSheet);
            }
        }

        #region Populate Combos

        /// <summary>
        /// populates all combo boxes for organization, project, activity, etc
        /// </summary>
        private void PopulateComboBoxes()
        {
            PopulateOrganizationCombo(cmbOrganizations, TSRTimeEntry.OrganizationID);
            PopulateProjectCombo(cmbOrganizations, cmbProjects, TSRTimeEntry.ProjectID, TSRTimeEntry.OrganizationID);
            PopulateActivityCombo(cmbProjects, cmbActivities, TSRTimeEntry.ActivityID, TSRTimeEntry.ProjectID);
            PopulateTaskCombo(TSRTimeEntry.TaskID);
            PopulateContactCombo(cmbOrganizations, cmbContacts, TSRTimeEntry.ContactID, TSRTimeEntry.OrganizationID);

            PopulateLocationCombo(TSRTimeEntry.LocationID);

            PopulateFavoritesCombo();

            cbOutOfOffice.Checked = TSRTimeEntry.IsOutOfOffice;

            SetEnabledComboBox();

            PopulateTime();
        }

        private void PopulateTime()
        {
            dtStartDate.Format = DateTimePickerFormat.Custom;
            dtStartTime.Format = DateTimePickerFormat.Custom;
            dtStartTime.ShowUpDown = true;
            dtStartDate.CustomFormat =  TSR.Core.SettingsHelper.TSRDateFormat.ToLower().Equals("na")
                                        ? "MM/dd/yyyy"
                                        : ReverseToHTMLCode(TSR.Core.SettingsHelper.TSRDateFormat);

            dtStartTime.CustomFormat = TSR.Core.SettingsHelper.TSRTimeFormat.ToLower().Equals("na")
                                        ? "h:mm tt"
                                        : TSR.Core.SettingsHelper.TSRTimeFormat.Replace(":ss", "");

            bool isChangeAllowed = TSRTimeEntry.IsChangeAllowed();

            if (!isChangeAllowed)
            {
                var startDateTime = TSRTimeEntry.StartTimeStamp;
                var endDateTime = TSRTimeEntry.EndTimeStamp;
                dtStartDate.Value = TSRTimeEntry.StartTimeStamp;
                dtStartTime.Value = TSRTimeEntry.StartTimeStamp;

                double duration = (endDateTime - startDateTime).TotalHours;
                txtDuration.Text = Math.Round(duration, 2).ToString("F2");
            }
            else if (TSRTimeEntry.OLAppointmentItem != null)
            {
                var startDateTime = TSRTimeEntry.OLAppointmentItem.Start;
                var endDateTime = TSRTimeEntry.OLAppointmentItem.End;
                dtStartDate.Value = TSRTimeEntry.OLAppointmentItem.Start.Date;
                dtStartTime.Value = TSRTimeEntry.OLAppointmentItem.Start;

                double duration = (endDateTime - startDateTime).TotalHours;
                txtDuration.Text = Math.Round(duration, 2).ToString("F2");
            }

            if (TSRTimeEntry.OLAppointmentItem == null || 
                TSRTimeEntry.OLAppointmentItem.RecurrenceState != Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptNotRecurring)
            {
                dtStartDate.Enabled = false;
                dtStartTime.Enabled = false;
                txtDuration.Enabled = false;
            }
        }

        public static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }

        private void PopulateComboBoxesExpense()
        {
            PopulateOrganizationCombo(cbbExpenseOrganization, TSRTimeEntry.OrganizationID);
            PopulateProjectCombo(cbbExpenseOrganization, cbbExpenseProject, TSRTimeEntry.ProjectID, TSRTimeEntry.OrganizationID);
            PopulateActivityCombo(cbbExpenseProject, cbbExpenseActivity, TSRTimeEntry.ActivityID, TSRTimeEntry.ProjectID);
            PopulateContactCombo(cbbExpenseOrganization, cbbExpenseContact, TSRTimeEntry.ContactID, TSRTimeEntry.OrganizationID);
            SetEnabledComboBoxExpense();
        }

        /// <summary>
        /// populates organization combo box
        /// </summary>
        /// <param name="organizationID"></param>
        private void PopulateOrganizationCombo(ComboBox cbb, Int64 organizationID)
        {
            var organizationList = new Entity.OrganizationList();
            long orgID = -1;
            try
            {
                if (TSRTimeEntry.Status == StatusEnum.InSubmissionQueue)
                {
                    organizationList.Add(TSRTimeEntry.Organization ?? Core.TSRFacade.GetOrganizationByID(TSRTimeEntry.OrganizationID));
                    cbb.DataSource = organizationList;
                    cbb.DisplayMember = Entity.Organization.Property_Name;
                    cbb.ValueMember = Entity.Organization.Property_ID;

                    return;
                }
                else if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.Valid)
                {
                    organizationList = Core.TSRFacade.GetAllOrganizations();
                    organizationList.InsertSelectionDefaultItem();
                    orgID = organizationID;
                }
                else
                {
                    //if ((TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue)
                    //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                    //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected))
                    if (!TSRTimeEntry.IsChangeAllowedView())
                    {
                        if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.MissingCurrentDB)
                        {
                            organizationList = new Entity.OrganizationList();
                            organizationList.Add(TSRTimeEntry.Organization);
                            orgID = organizationID;
                        }
                        else
                        {
                            if (TSRTimeEntry.Organization != null)
                            {
                                organizationList = new Entity.OrganizationList();
                                organizationList.Add(TSRTimeEntry.Organization);
                                orgID = organizationID;
                            }
                            else
                            {
                                organizationList = new Entity.OrganizationList();
                                organizationList.InsertSelectionDefaultItem();
                            }                            
                        }
                    }
                    else
                    {
                        organizationList = Core.TSRFacade.GetAllOrganizations();
                        organizationList.InsertSelectionDefaultItem();
                        if (organizationList.Exists(delegate(Entity.Organization org) { return org.ID == organizationID; }))
                            orgID = organizationID;
                    }
                }

                List<Entity.Organization> favoOrgList = CheckOrganizationShowOnlyFavorites(organizationList);
                if (favoOrgList != null)
                    favoOrgList = favoOrgList.OrderByDescending(x => x == favoOrgList.FirstOrDefault()).ThenBy(x=>x.Name).ToList();

                UIHelper.FillComboBox(cbb, favoOrgList, Entity.Organization.Property_Name, Entity.Organization.Property_ID, orgID, false);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);                
                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error","Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }           
        }

        /// <summary>
        /// populates project combo
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="organizationID"></param>
        private void PopulateProjectCombo(ComboBox cbbOrg, ComboBox cbbPro, Int64 projectID, Int64 organizationID)
        {
            Entity.ProjectList projectList;
            long prjID = -1;
            try
            {
                projectList = (organizationID == -1) ? new Entity.ProjectList() : Core.TSRFacade.GetProjectsForOrganization(organizationID);
                projectList.InsertSelectionDefaultItem();

                if (TSRTimeEntry.Status == StatusEnum.InSubmissionQueue)
                {
                    projectList = new Entity.ProjectList();
                    projectList.Add(TSRTimeEntry.Project ?? Core.TSRFacade.GetProjectByID(TSRTimeEntry.ProjectID));
                    cbbPro.DataSource = projectList;
                    cbbPro.DisplayMember = Entity.Organization.Property_Name;
                    cbbPro.ValueMember = Entity.Organization.Property_ID;

                    return;
                }
                else if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.Valid)
                {
                    projectList = (organizationID == -1) ? new Entity.ProjectList() : Core.TSRFacade.GetProjectsForOrganization(organizationID);
                    projectList.InsertSelectionDefaultItem();
                    prjID = projectID;
                }
                else
                {
                    //if ((TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue)
                    //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                    //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected))
                    if (!TSRTimeEntry.IsChangeAllowedView())
                    {
                        if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.MissingCurrentDB)
                        {
                            projectList = new Entity.ProjectList();
                            projectList.Add(TSRTimeEntry.Project);
                            prjID = projectID;
                        }
                        else
                        {

                            if (TSRTimeEntry.Project == null)
                            {
                                projectList = new Entity.ProjectList();
                                projectList.InsertSelectionDefaultItem();                                    
                            }
                            else
                            {
                                projectList = new Entity.ProjectList();
                                projectList.Add(TSRTimeEntry.Project);
                                prjID = projectID;
                            }
                        }
                    }
                    else
                    {
                        projectList = (organizationID == -1) ? new Entity.ProjectList() : Core.TSRFacade.GetProjectsForOrganization(organizationID);
                        projectList.InsertSelectionDefaultItem();
                        if ((projectList.Exists(delegate(Entity.Project prj) { return prj.ID == projectID; })) &&(cbbOrg.SelectedIndex != 0))
                            prjID = projectID;
                    }
                }
                List<Entity.Project> favoProjectList = CheckProjectShowOnlyFavorites(projectList);
                if (favoProjectList != null)
                    favoProjectList = favoProjectList.OrderByDescending(x => x == favoProjectList.FirstOrDefault()).ThenBy(x => x.Name).ToList();
                UIHelper.FillComboBox(cbbPro, favoProjectList, Entity.Project.Property_Name, Entity.Project.Property_ID, prjID,false);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// populate activity combo
        /// </summary>
        /// <param name="enable"></param>
        private void SetEnabledComboBox()
        {        
            bool isChangeAllowed = TSRTimeEntry.IsChangeAllowed();

            bool isExpenseChangeAllowed = true;
            if (TSRExpenseSheet != null)
                isExpenseChangeAllowed = TSRExpenseSheet.IsChangeAllowed();

            cmbActivities.Enabled = isChangeAllowed && isExpenseChangeAllowed;
            cmbContacts.Enabled = isChangeAllowed && isExpenseChangeAllowed;
            cmbOrganizations.Enabled = isChangeAllowed && isExpenseChangeAllowed;
            cmbProjects.Enabled = isChangeAllowed && isExpenseChangeAllowed;
            cmbFavorites.Enabled = isChangeAllowed && isExpenseChangeAllowed;
            cmbTasks.Enabled = isChangeAllowed;
            txtNewResponse.Enabled = isChangeAllowed;
            btnOK.Enabled = isChangeAllowed || isExpenseChangeAllowed;
            //added by tsrdev2
            //feature: Tooltip of combobox
            grpAdvancedAttributes.Enabled = isChangeAllowed;

            //set color
            if (!isChangeAllowed || !isExpenseChangeAllowed)
            {
                lblOrganization.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblProject.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblActivity.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblContact.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblTask.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblFavorites.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblLocation.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
            }
        }

        private void SetEnabledComboBoxExpense()
        {
            bool isChangeAllowed = TSRTimeEntry.IsChangeAllowed();

            bool isExpenseChangeAllowed = true;
            if (TSRExpenseSheet != null)
                isExpenseChangeAllowed = TSRExpenseSheet.IsChangeAllowed();

            //Remove by Feature 340
            //else
            //{
            //    if (isChangeAllowed == false)
            //        isExpenseChangeAllowed = false;
            //}

            btnOK.Enabled = isChangeAllowed || isExpenseChangeAllowed;

            if (this.IsExpenseMode)
            {
                cbbExpenseActivity.Enabled = isExpenseChangeAllowed && isChangeAllowed;
                cbbExpenseContact.Enabled = isExpenseChangeAllowed && isChangeAllowed;
                cbbExpenseOrganization.Enabled = isExpenseChangeAllowed && isChangeAllowed;
                cbbExpenseProject.Enabled = isExpenseChangeAllowed && isChangeAllowed;
                //btnOK.Enabled = isExpenseChangeAllowed;
                btnAddExpense.Enabled = isExpenseChangeAllowed;
                btnSaveExpenses.Enabled = isExpenseChangeAllowed;
                //btnSubmitExpenses.Enabled = isExpenseChangeAllowed;

                btnSubmitExpenses.Enabled = (TSRExpenseSheet != null && TSRExpenseSheet.ExpenseEntryListLocal != null
                                    && TSRExpenseSheet.ExpenseEntryListLocal.Count > 0 && TSRExpenseSheet.IsChangeAllowed());

                Entity.TimeEntry teExisted = TSR.Core.TSRFacade.GetTimeEntryByTSRItemID(TSRTimeEntry.ID, false);
                if (teExisted == null)
                    btnSubmitExpenses.Enabled = false;
            }

            cbbExpenseOrganization.Enabled = false;
            cbbExpenseProject.Enabled = false;
            cbbExpenseActivity.Enabled = false;
            cbbExpenseContact.Enabled = false;
        }
        /// <summary>
        /// populate activity combo
        /// </summary>
        /// <param name="activityID"></param>
        /// <param name="projectID"></param>
        private void PopulateActivityCombo(ComboBox cbbPro, ComboBox cbbAct, Int64 activityID, Int64 projectID)
        {
            Entity.ActivityList activityList = new Entity.ActivityList();
            long actID = -1;
            try
            {
                if (TSRTimeEntry.Status == StatusEnum.InSubmissionQueue)
                {
                    activityList.Add(TSRTimeEntry.Activity ?? Core.TSRFacade.GetActivityByID(TSRTimeEntry.ActivityID));
                    cbbAct.DataSource = activityList;
                    cbbAct.DisplayMember = Entity.Activity.Property_Name;
                    cbbAct.ValueMember = Entity.Activity.Property_ID;

                    return;
                }
                else
                {
                    if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.Valid)
                    {
                        activityList = (projectID == -1) ? new Entity.ActivityList() : Core.TSRFacade.GetActivitiesForProject(projectID);
                        activityList.InsertSelectionDefaultItem();
                        actID = activityID;
                    }
                    else
                    {
                        //if ((TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue)
                        //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                        //    && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected))
                        if (!TSRTimeEntry.IsChangeAllowedView())
                        {
                            if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.MissingCurrentDB)
                            {
                                activityList = new Entity.ActivityList();
                                activityList.Add(TSRTimeEntry.Activity);
                                actID = activityID;
                            }
                            else
                            {
                                if (TSRTimeEntry.Activity == null)
                                {
                                    activityList = new Entity.ActivityList();
                                    activityList.InsertSelectionDefaultItem();
                                }
                                else
                                {
                                    activityList = new Entity.ActivityList();
                                    activityList.Add(TSRTimeEntry.Activity);
                                    actID = activityID;
                                }
                            }
                        }
                        else
                        {
                            activityList = (projectID == -1)
                                            ? new Entity.ActivityList()
                                            : Core.TSRFacade.GetActivitiesForProject(projectID);
                            activityList.InsertSelectionDefaultItem();

                            if ((activityList.Exists(delegate(Entity.Activity act) { return act.ID == activityID; })) && (cbbPro.SelectedIndex != 0)) actID = activityID;
                        }
                    }
                    List<Entity.Activity> favoActList = CheckActivityShowOnlyFavorites(activityList, projectID);
                    if(favoActList != null)
                        favoActList = favoActList.OrderByDescending(x => x == favoActList.FirstOrDefault()).ThenBy(x => x.Name).ToList();
                    UIHelper.FillComboBox(cbbAct, favoActList, Entity.Activity.Property_Name, Entity.Activity.Property_ID, actID, false);
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        /// <summary>
        /// populates task combo
        /// </summary>
        /// <param name="taskID"></param>
        private void PopulateTaskCombo(Int64? taskID)
        {
            Entity.TaskList taskList;

            taskList = Core.TSRFacade.GetAllTasks();
            taskList.InsertSelectionDefaultItem();

            List<Task> sortedTaskList = taskList.OrderByDescending(x => x == taskList.FirstOrDefault()).ThenBy(x => x.Name).ToList();

            if (!taskID.HasValue || taskList.FindByID(taskID.Value) == null)
                UIHelper.FillComboBox(cmbTasks, sortedTaskList, Entity.Task.Property_Name, Entity.Task.COL_ID, false);
            else
                UIHelper.FillComboBox(cmbTasks, sortedTaskList, Entity.Task.Property_Name, Entity.Task.COL_ID, taskID.Value, false);
        }

        /// <summary>
        /// populates contact combo
        /// </summary>
        /// <param name="contactID"></param>
        /// <param name="organizationID"></param>
        private void PopulateContactCombo(ComboBox cbbOrg, ComboBox cbbCnt, Int64? contactID, Int64 organizationID)
        {
            Entity.ContactList contactList = new Entity.ContactList();
            long cntID = -1;
            try
            {
                if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.Valid)
                {
                    contactList = (organizationID == -1) ? new Entity.ContactList() : Core.TSRFacade.GetContactsByOrganizationID(organizationID);//Core.TSRFacade.GetAllContacts();
                    contactList.InsertSelectionDefaultItem();
                    if (contactID.HasValue)
                        cntID = contactID.Value;
                }
                else
                {
                    //if ((TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue)
                    //   && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                    //   && (TSRTimeEntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected))
                    if (!TSRTimeEntry.IsChangeAllowedView())
                    {
                        if (Core.TimeEntryHelper.GetTimeEntryType(TSRTimeEntry) == TSR.Core.TimeEntryType.MissingCurrentDB)
                        {
                            if (TSRTimeEntry.ContactID.HasValue)
                            {
                                contactList = new Entity.ContactList();
                                contactList.Add(TSRTimeEntry.Contact);
                                cntID = contactID.Value;
                            }
                            else
                            {
                                contactList = new Entity.ContactList();
                                contactList.InsertSelectionDefaultItem();
                            }

                        }
                        else
                        {
                            if (TSRTimeEntry.Contact == null)
                            {
                                contactList = new Entity.ContactList();
                                contactList.InsertSelectionDefaultItem();
                            }
                            else
                            {
                                contactList = new Entity.ContactList();
                                contactList.Add(TSRTimeEntry.Contact);
                                cntID = contactID.Value;
                            }
                        }
                    }
                    else
                    {
                        contactList = (organizationID == -1) ? new Entity.ContactList() : Core.TSRFacade.GetContactsByOrganizationID(organizationID);//Core.TSRFacade.GetAllContacts();
                        contactList.InsertSelectionDefaultItem();
                        if (((contactID.HasValue) && (contactList.Exists(delegate(Entity.Contact cnt) { return cnt.ID == contactID; }))) &&(cbbOrg.SelectedIndex != 0))
                            cntID = contactID.Value;
                    }
                }

                List<Entity.Contact> sortedContactList = contactList.OrderByDescending(x => x == contactList.FirstOrDefault()).ThenBy(x => x.Name).ToList();
                UIHelper.FillComboBox(cbbCnt, sortedContactList, Entity.Contact.Property_Name, Entity.Contact.Property_ID, cntID, false);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// populates favorite combo box
        /// </summary>
        private void PopulateFavoritesCombo()
        {
            var listFavorites = (from a in RetrievePreferredPaths().AsEnumerable()
                select new ComboboxItem
                {
                    ID = string.Format("{0}{3}{1}{3}{2}", a.OrganizationID, a.ProjectID, a.ActivityID, Core.Constants.CONST_FAVORITE_ID_SEPERATOR),
                    Name = string.Format("{0}{3} {1}{3} {2}", a.OrganizationName, a.ProjectName, a.ActivityName, Core.Constants.CONST_FAVORITE_NAME_SEPERATOR)
                }).ToList();

            var selectDefault = string.Format("{0}{3}{1}{3}{2}", TSRTimeEntry.OrganizationID, TSRTimeEntry.ProjectID, TSRTimeEntry.ActivityID, Core.Constants.CONST_FAVORITE_ID_SEPERATOR);
            var isExistInFavorites = listFavorites.SingleOrDefault(x => x.ID.Equals(selectDefault));

            string defaultSelection = Core.Constants.DEFAULT_SELECTION_VALUE_INT.ToString(CultureInfo.InvariantCulture);
            if (isExistInFavorites != null)
                defaultSelection = selectDefault;

            listFavorites.Insert(0, new ComboboxItem() { ID = Core.Constants.DEFAULT_SELECTION_VALUE_INT.ToString(CultureInfo.InvariantCulture), Name = Core.ResourceHelper.SelectAFavotite });

            listFavorites = listFavorites.OrderByDescending(x => x == listFavorites.FirstOrDefault()).ThenBy(x => x.Name).ToList();
            UIHelper.FillComboBox(cmbFavorites, listFavorites, "Name", "ID", defaultSelection, false);
        }

        private void SelectedItemFavoritesCombo(Int64 organizationID, Int64 projectID, Int64 activityID)
        {
            cmbFavorites.SelectedValue = string.Format("{0}{3}{1}{3}{2}", organizationID, projectID, activityID, Core.Constants.CONST_FAVORITE_ID_SEPERATOR);
            if (cmbFavorites.SelectedIndex < 1)
                cmbFavorites.SelectedValue = Core.Constants.DEFAULT_SELECTION_VALUE_INT.ToString();
        }
        #endregion

        /// <summary>
        /// populate localized text resources
        /// </summary>
        private void PopulateLocalizedTextFromResource()
        {
            string subject = string.Empty;
            if (TSRTimeEntry != null)
            {
                if (string.IsNullOrEmpty(TSRTimeEntry.Subject))
                {
                    subject = " - [" + Core.ResourceHelper.Untitled + "]";
                }
                else
                {
                    subject = " - " + TSRTimeEntry.Subject;
                }
            }

            this.Text = Core.ResourceHelper.TimeEntryAdvancedFormHeadingText + subject;
            lblOrganization.Text = Core.ResourceHelper.Organization;
            lblProject.Text = Core.ResourceHelper.Project;
            lblActivity.Text = Core.ResourceHelper.Activity;
            lblTask.Text = Core.ResourceHelper.Task;
            lblContact.Text = Core.ResourceHelper.Contact;
            lblFavorites.Text = Core.ResourceHelper.Favorites;
            lblLocation.Text = Core.ResourceHelper.Location;
            btnOK.Text = Core.ResourceHelper.OK;
            btnCancel.Text = Core.ResourceHelper.Cancel;
            grpAdvancedAttributes.Text = Core.ResourceHelper.OtherInformation;
            grpMessage.Text = Core.ResourceHelper.MessageHistory;

            tbpAdvanced.Text = Core.ResourceManager.GetResourceString("Ribbon_AdvancedButton", "Advanced");
            tbpExpenses.Text = Core.ResourceManager.GetResourceString("Expenses", "Expenses");

            lblExpOrg.Text = Core.ResourceHelper.Organization;
            lblExpProj.Text = Core.ResourceHelper.Project;
            lblExpAct.Text = Core.ResourceHelper.Activity;
            lblExpCnt.Text = Core.ResourceHelper.Contact;

            btnAddExpense.Text = Core.ResourceManager.GetResourceString("AddExpense", "Add Expense");
            lblExpenseTotal.Text = Core.ResourceManager.GetResourceString("Expense Total", "Expense Total");
            btnSubmitExpenses.Text = Core.ResourceManager.GetResourceString("SubmitExpenses", "Submit Expenses");
            btnSaveExpenses.Text = Core.ResourceManager.GetResourceString("SaveExpenses", "Save Expenses");

            cbOutOfOffice.Text = Core.ResourceManager.GetResourceString("OutOfOffice", "Out of Office");

            lblStartDate.Text = Core.ResourceManager.GetResourceString("StartDate", "Start Date");
            lblStartTime.Text = Core.ResourceManager.GetResourceString("StartTime", "Start Time");
            lblDuration.Text = Core.ResourceManager.GetResourceString("Duration", "Duration"); 
        }

        /// <summary>
        /// populates notes with previous value
        /// </summary>
        private void PopulateNoteWithPreviousValue()
        {
            Entity.NoteList lst = null;
            try
            {
                lst = Core.TSRFacade.GetNotesByTimeEntryID(TSRTimeEntry.ID);
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                string message = Core.ResourceManager.GetResourceString("ErrorGettingListOfNotes","Error getting list of notes");
                MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (lst != null)
            {
                txtPreviousResponses.Text = lst.ToString();
            }

            if (!String.IsNullOrEmpty(TSRTimeEntry.Message))
            {
                txtNewResponse.Text = TSRTimeEntry.Message;
            }
        }

        /// <summary>
        /// populates Location combo
        /// </summary>
        /// <param name="locationID"></param>
        private void PopulateLocationCombo(Int64? locationID)
        {
            Entity.LocationList locationList = Core.TSRFacade.GetAllLocations();
            if (locationList == null)
                locationList = new Entity.LocationList();
            List<Entity.Location> tempList = locationList.OrderBy(x => x.Name).ToList();

            Entity.LocationList activeLocationList = new Entity.LocationList();
            foreach (var item in tempList)
            {
                if(item.IsActivate == true)
                    activeLocationList.Add(item);
            }

            activeLocationList.InsertSelectionDefaultItem();

            if (!locationID.HasValue || activeLocationList.FindByID(locationID.Value) == null)
                UIHelper.FillComboBox(cbxLocation, activeLocationList, Entity.Location.Property_Name, Entity.Location.Property_ID, false);
            else
                UIHelper.FillComboBox(cbxLocation, activeLocationList, Entity.Location.Property_Name, Entity.Location.Property_ID, locationID.Value, false);
        }
        #endregion

        #region Save Data

        /// <summary>
        /// save data from this screen, called before exit
        /// </summary>
        /// <returns></returns>
        private bool SaveAdvancedTimeEntryData()
        {
            //SaveComboItems();
            SaveNote();
            DialogResult = DialogResult.OK;
            return true;
        }

        /// <summary>
        /// saves combo items selections
        /// </summary>
        private void SaveComboItems()
        {
            if (cmbOrganizations.SelectedItem != null && cmbProjects.SelectedItem != null && cmbActivities.SelectedItem != null)
            {
                Entity.Organization org = cmbOrganizations.SelectedItem as Entity.Organization;
                TSRTimeEntry.OrganizationID = org.ID;

                Entity.Project prj = cmbProjects.SelectedItem as Entity.Project;
                TSRTimeEntry.ProjectID = prj.ID;

                Entity.Activity act = cmbActivities.SelectedItem as Entity.Activity;
                TSRTimeEntry.ActivityID = act.ID;

                Entity.Task tsk = cmbTasks.SelectedItem as Entity.Task;
                if (tsk != null && tsk.ID != -1)
                    TSRTimeEntry.TaskID = tsk.ID;

                Entity.Contact cnt = cmbContacts.SelectedItem as Entity.Contact;
                if (cnt != null && cnt.ID != -1)
                    TSRTimeEntry.ContactID = cnt.ID;
                else
                    TSRTimeEntry.ContactID = null;

                Entity.Location lc = cbxLocation.SelectedItem as Entity.Location;
                if (lc != null && lc.ID != -1)
                    TSRTimeEntry.LocationID = lc.ID;
                else
                    TSRTimeEntry.LocationID = -1;

                TSRTimeEntry.IsOutOfOffice = cbOutOfOffice.Checked;

                CalEndDateTime();
            }
        }

        private void CalEndDateTime()
        {
            var startDate = dtStartDate.Value;
            var startTime = dtStartTime.Value;
            var startDateTime = new DateTime(startDate.Year, startDate.Month, startDate.Day, startTime.Hour, startTime.Minute, 0);
            var duration = float.Parse(txtDuration.Text);

            if (TSRTimeEntry.OLAppointmentItem != null)
            {
                TSRTimeEntry.OLAppointmentItem.Start = startDateTime;
                TSRTimeEntry.OLAppointmentItem.End = startDateTime.AddHours(duration);
            }
        }

        private void SaveComboItemsExpense()
        {
            if (cmbOrganizations.SelectedItem != null && cmbProjects.SelectedItem != null &&
                cmbActivities.SelectedItem != null)
            {
                Entity.Organization org = cbbExpenseOrganization.SelectedItem as Entity.Organization;
                if(org != null)
                    TSRTimeEntry.OrganizationID = org.ID;

                Entity.Project prj = cbbExpenseProject.SelectedItem as Entity.Project;
                if(prj != null)
                    TSRTimeEntry.ProjectID = prj.ID;

                Entity.Activity act = cbbExpenseActivity.SelectedItem as Entity.Activity;
                if(act != null)
                    TSRTimeEntry.ActivityID = act.ID;

                Entity.Contact cnt = cbbExpenseContact.SelectedItem as Entity.Contact;
                if (cnt != null && cnt.ID != -1)
                    TSRTimeEntry.ContactID = cnt.ID;
            }
        }

        bool CheckDataValid()
        { 
            if(cbbExpenseOrganization.SelectedValue.ToString() == "-1")
                return false;
            if(cbbExpenseProject.SelectedValue.ToString() == "-1")
                return false;
            if(cbbExpenseActivity.SelectedValue.ToString() == "-1")
                return false;
            return true;
        }

        /// <summary>
        /// save note
        /// </summary>
        private void SaveNote()
        {
            TSRTimeEntry.Message = GetCurrentMessageContent();
        }

        /// <summary>
        /// retrieve current message contents
        /// </summary>
        /// <returns></returns>
        private String GetCurrentMessageContent()
        {
            if (!String.IsNullOrEmpty(txtNewResponse.Text.Trim()))
                return txtNewResponse.Text.Trim();

            return null;
        }

        #endregion

        /// <summary>
        /// closes window
        /// </summary>
        private void CloseWindow()
        {
            this.Close();
            //this.Dispose();
        }

        #endregion

        #region Advanced SelectedChanged
        /// <summary>
        /// organization combo's selection changed, so change project combo too to fill with related projects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbOrganizations_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Organization org = cmbOrganizations.SelectedItem as Entity.Organization;
            long orgId = -1, projId = -1, actId = -1;

            if (org != null)
            {
                orgId = org.ID;
                try
                {
                    Entity.PreferredPaths pp = Core.TSRFacade.GetPreferredPathsByOrganizationID(orgId);
                    if (pp != null)
                    {
                        projId = pp.ProjectID;
                        actId = pp.ActivityID;
                    }
                    else if (GetShowOnlyFavorites() && TSRTimeEntry.OrganizationID == org.ID)
                    {
                        projId = TSRTimeEntry.ProjectID;
                        actId = TSRTimeEntry.ActivityID;
                    }
                }
                catch (Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                    string message = Core.ResourceManager.GetResourceString("ErrorRetrievingPreferredPathEntryForOrganization",
                        "Error retrieving preferred path entry for an organization");
                    MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (TSR.Core.SettingsHelper.TSRDisplayTooltip)
                {
                    this.tooltipOrg = tooltipResource_Org + ": \n";
                    this.tooltipOrg += "    " + tooltipResource_Name + ": " + org.Name + "\n";
                    this.tooltipOrg += "    " + tooltipResource_Description + ": " + org.Description;

                    this.toolTip.SetToolTip(cmbOrganizations, this.tooltipOrg);
                }
            }
            PopulateProjectCombo(cmbOrganizations, cmbProjects, projId, orgId);
            PopulateActivityCombo(cmbProjects, cmbActivities, actId, projId);
            PopulateContactCombo(cmbOrganizations, cmbContacts, -1, orgId);

            SelectedItemFavoritesCombo(orgId, projId, actId);
        }

        /// <summary>
        /// project combo's selection changed, so update activity combo with related activities for the selected project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbProjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Project proj = cmbProjects.SelectedItem as Entity.Project;
            long projId = -1;

            if (proj != null)
            {
                projId = proj.ID;

                if (TSR.Core.SettingsHelper.TSRDisplayTooltip)
                {
                    tooltipProj = tooltipResource_Proj + ": \n";
                    tooltipProj += "    " + tooltipResource_Name + ": " + proj.Name + "\n";
                    tooltipProj += "    " + tooltipResource_Type + ": " + proj.ProjectTypeName + "\n";
                    tooltipProj += "    " + tooltipResource_Description + ": " + proj.Description;

                    this.toolTip.SetToolTip(cmbProjects, tooltipProj);
                }
            }

            PopulateActivityCombo(cmbProjects, cmbActivities, -1, projId);

            var org = (Entity.Organization) cmbOrganizations.SelectedItem;
            var act = (Entity.Activity)cmbActivities.SelectedItem;

            if (org == null || proj == null || act == null)
                SelectedItemFavoritesCombo(-1, -1, -1);
            else
                SelectedItemFavoritesCombo(org.ID, projId, act.ID);
        }

        private void cmbActivities_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Activity act = cmbActivities.SelectedItem as Entity.Activity;

            if (act != null && TSR.Core.SettingsHelper.TSRDisplayTooltip)
            {
                tooltipAct = tooltipResource_Act + ": \n";
                tooltipAct += "    " + tooltipResource_Name + ": " + act.Name + "\n";
                tooltipAct += "    " + tooltipResource_Type + ": " + act.ActivityTypeName + "\n";
                tooltipAct += "    " + tooltipResource_Description + ": " + act.Description;

                this.toolTip.SetToolTip(cmbActivities, tooltipAct);
            }

            var org = (Entity.Organization)cmbOrganizations.SelectedItem;
            var project = (Entity.Project)cmbProjects.SelectedItem;
            if(org == null || project == null || act == null)
                SelectedItemFavoritesCombo(-1, -1, -1);
            else
                SelectedItemFavoritesCombo(org.ID, project.ID, act.ID);
        }

        private void TimeEntryAdvanced_MouseMove(object sender, MouseEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (cmbOrganizations.Enabled && cmbProjects.Enabled && cmbActivities.Enabled)
            {
                return;
            }

            //Importance: MouseMove event of form can only effected on a certain control
            //when the control is disbale. So, in here, groupbox control grpAdvancedAttributes must be set disable at first

            //Control ctrl = this.GetChildAtPoint(e.Location);

            //Get current point within the groupbox
            Point p = this.grpAdvancedAttributes.PointToClient(Cursor.Position);
            //Get control of the current control within the groupbox
            Control ctrl = this.grpAdvancedAttributes.GetChildAtPoint(p);

            if (ctrl == this.cmbOrganizations || ctrl == this.cmbProjects || ctrl == this.cmbActivities)
            {
                if (!this.toolTipShown)
                {
                    string tip = "";
                    if (ctrl == this.cmbOrganizations)
                    {
                        tip = this.tooltipOrg;
                    }
                    else if (ctrl == this.cmbProjects)
                    {
                        tip = this.tooltipProj;
                    }
                    else if (ctrl == this.cmbActivities)
                    {
                        tip = this.tooltipAct;
                    }

                    this.toolTip.Show(tip, ctrl, p.X - ctrl.Location.X, p.Y - ctrl.Location.Y);
                    this.toolTipShown = true;
                }
            }
            else
            {
                this.toolTip.Hide(this.cmbOrganizations);
                this.toolTip.Hide(this.cmbProjects);
                this.toolTip.Hide(this.cmbActivities);

                this.toolTipShown = false;
            }
        }

        private void cmbFavorites_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_favoritesComboIndexChanged)
            {
                _favoritesComboIndexChanged = false;

                long orgId = -1, projId = -1, actId = -1;

                if (cmbFavorites.SelectedValue != null)
                {
                    var favorite = cmbFavorites.SelectedValue.ToString();
                    if (favorite.Split(char.Parse(Core.Constants.CONST_FAVORITE_ID_SEPERATOR)).Length == 3)
                    {
                        orgId = int.Parse(favorite.Split(char.Parse(Core.Constants.CONST_FAVORITE_ID_SEPERATOR))[0]);
                        projId = int.Parse(favorite.Split(char.Parse(Core.Constants.CONST_FAVORITE_ID_SEPERATOR))[1]);
                        actId = int.Parse(favorite.Split(char.Parse(Core.Constants.CONST_FAVORITE_ID_SEPERATOR))[2]);
                    }

                    if ((favorite.Split(char.Parse(Core.Constants.CONST_FAVORITE_ID_SEPERATOR)).Length == 3 ||
                        favorite.Equals(Core.Constants.DEFAULT_SELECTION_VALUE_INT.ToString(CultureInfo.InvariantCulture))))
                    {
                        PopulateOrganizationCombo(cmbOrganizations, orgId);
                        PopulateProjectCombo(cmbOrganizations, cmbProjects, projId, orgId);
                        PopulateActivityCombo(cmbProjects, cmbActivities, actId, projId);
                        PopulateContactCombo(cmbOrganizations, cmbContacts, -1, orgId);
                    }
                }
            }
        }
        #endregion

        #region Expense SelectedChanged
        /// <summary>
        /// organization combo's selection changed, so change project combo too to fill with related projects
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbbExpenseOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Organization org = cbbExpenseOrganization.SelectedItem as Entity.Organization;
            long orgId = -1, projId = -1, actId = -1;

            if (org != null)
            {
                orgId = org.ID;
                try
                {
                    Entity.PreferredPaths pp = Core.TSRFacade.GetPreferredPathsByOrganizationID(orgId);
                    if (pp != null)
                    {
                        projId = pp.ProjectID;
                        actId = pp.ActivityID;
                    }
                }
                catch (Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                    string message = Core.ResourceManager.GetResourceString("ErrorRetrievingPreferredPathEntryForOrganization",
                        "Error retrieving preferred path entry for an organization");
                    MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (TSR.Core.SettingsHelper.TSRDisplayTooltip)
                {
                    this.tooltipOrg = tooltipResource_Org + ": \n";
                    this.tooltipOrg += "    " + tooltipResource_Name + ": " + org.Name + "\n";
                    this.tooltipOrg += "    " + tooltipResource_Description + ": " + org.Description;

                    this.toolTip.SetToolTip(cbbExpenseOrganization, this.tooltipOrg);
                }
            }
            PopulateProjectCombo(cbbExpenseOrganization, cbbExpenseProject, projId, orgId);
            PopulateActivityCombo(cbbExpenseProject, cbbExpenseActivity, actId, projId);
            PopulateContactCombo(cbbExpenseOrganization, cbbExpenseContact, -1, orgId);
        }

        /// <summary>
        /// project combo's selection changed, so update activity combo with related activities for the selected project
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbbExpenseProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Project proj = cbbExpenseProject.SelectedItem as Entity.Project;
            long projId = -1;

            if (proj != null)
            {
                projId = proj.ID;

                if (TSR.Core.SettingsHelper.TSRDisplayTooltip)
                {
                    tooltipProj = tooltipResource_Proj + ": \n";
                    tooltipProj += "    " + tooltipResource_Name + ": " + proj.Name + "\n";
                    tooltipProj += "    " + tooltipResource_Type + ": " + proj.ProjectTypeName + "\n";
                    tooltipProj += "    " + tooltipResource_Description + ": " + proj.Description;

                    this.toolTip.SetToolTip(cbbExpenseProject, tooltipProj);
                }
            }

            PopulateActivityCombo(cbbExpenseProject, cbbExpenseActivity, -1, projId);
        }

        private void cbbExpenseActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            Entity.Activity act = cbbExpenseActivity.SelectedItem as Entity.Activity;

            if (act != null && TSR.Core.SettingsHelper.TSRDisplayTooltip)
            {
                tooltipAct = tooltipResource_Act + ": \n";
                tooltipAct += "    " + tooltipResource_Name + ": " + act.Name + "\n";
                tooltipAct += "    " + tooltipResource_Type + ": " + act.ActivityTypeName + "\n";
                tooltipAct += "    " + tooltipResource_Description + ": " + act.Description;

                this.toolTip.SetToolTip(cbbExpenseActivity, tooltipAct);
            }
        }

        private void TimeEntryExpense_MouseMove(object sender, MouseEventArgs e)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
                return;

            if (cbbExpenseOrganization.Enabled && cbbExpenseProject.Enabled && cbbExpenseActivity.Enabled)
            {
                return;
            }

            //Importance: MouseMove event of form can only effected on a certain control
            //when the control is disbale. So, in here, groupbox control grpAdvancedAttributes must be set disable at first

            //Control ctrl = this.GetChildAtPoint(e.Location);

            //Get current point within the groupbox
            Point p = this.grpAdvancedAttributes.PointToClient(Cursor.Position);
            //Get control of the current control within the groupbox
            Control ctrl = this.grpAdvancedAttributes.GetChildAtPoint(p);

            if (ctrl == this.cbbExpenseOrganization || ctrl == this.cbbExpenseProject || ctrl == this.cbbExpenseActivity)
            {
                if (!this.toolTipShown)
                {
                    string tip = "";
                    if (ctrl == this.cbbExpenseOrganization)
                    {
                        tip = this.tooltipOrg;
                    }
                    else if (ctrl == this.cbbExpenseProject)
                    {
                        tip = this.tooltipProj;
                    }
                    else if (ctrl == this.cbbExpenseActivity)
                    {
                        tip = this.tooltipAct;
                    }

                    this.toolTip.Show(tip, ctrl, p.X - ctrl.Location.X, p.Y - ctrl.Location.Y);
                    this.toolTipShown = true;
                }
            }
            else
            {
                this.toolTip.Hide(this.cbbExpenseOrganization);
                this.toolTip.Hide(this.cbbExpenseProject);
                this.toolTip.Hide(this.cbbExpenseActivity);

                this.toolTipShown = false;
            }
        }
        #endregion

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            if(TSRExpenseSheet == null)
            {
                TSRExpenseSheet = new Entity.ExpenseSheet();
                TSRExpenseSheet.Status = Core.UserAgentService.StatusEnum.PendingSubmission;
                TSRExpenseSheet.TimeEntryID = TSRTimeEntry.ID;
            }

            Entity.ExpenseEntry entry = new Entity.ExpenseEntry();
            entry.ExpenseSheetID = TSRExpenseSheet.ID;
            entry.TimeEntryID = TSRTimeEntry.ID;
            entry.LocationID = TSRTimeEntry.LocationID;

            editExpenseEntry(entry, true);
        }

        private void editExpenseEntry(Entity.ExpenseEntry entry, bool isNewEntry)
        {
            if (TSRTimeEntry.ID == Guid.Empty)
            {
                string error = Core.ResourceManager.GetResourceString("InvalidTimeEntryErrorMsg", "Invalid time entry");
                MessageBox.Show(error);
            }

            AddExpense popup = new AddExpense(entry, isNewEntry);
            var result = popup.ShowDialog();

            if (result == DialogResult.OK)
            {
                if (isNewEntry)
                {
                    if (TSRExpenseSheet.ExpenseEntryListLocal == null)
                        TSRExpenseSheet.ExpenseEntryListLocal = new Entity.ExpenseEntryList();

                    TSRExpenseSheet.ExpenseEntryListLocal.Add(entry);
                }
                BindExpenseSheet(TSRExpenseSheet);
            }

            btnSubmitExpenses.Enabled = (TSRExpenseSheet != null && TSRExpenseSheet.ExpenseEntryListLocal != null
                && TSRExpenseSheet.ExpenseEntryListLocal.Count > 0 && TSRExpenseSheet.IsChangeAllowed());
            
            Entity.TimeEntry teExisted = TSR.Core.TSRFacade.GetTimeEntryByTSRItemID(TSRTimeEntry.ID, false);
            if (teExisted == null)
                btnSubmitExpenses.Enabled = false;
        }

        private void btnSubmitExpenses_Click(object sender, EventArgs e)
        {
            string strQuestion = Core.ResourceManager.GetResourceString("HiddenExpensesSubmitQuestion", "Do you want to submit your expense sheet?");
            if (MessageBox.Show(strQuestion, "", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                return;

            bool success = false;
            success = CheckDataValid();
            if (!success)
            {
                string error = Core.ResourceManager.GetResourceString("PleaseEnterAppropriate", "Please select organization, project and activity");
                MessageBox.Show(error, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            success = saveCurrentExpensesData();
            if(success)
            {
                if (TSR.Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSRTimeEntry.ID) == null)
                    success = false;
                else
                    success = Core.TSRExpenseFacade.SubmitExpenses(TSRExpenseSheet);
            }

            if (success)
            {
                string message = Core.ResourceManager.GetResourceString("ExpensesSubmitedSuccessMessage", "Expenses submitted");
                MessageBox.Show(message);
                
                //update saved data to variable
                TSRExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSRTimeEntry.ID);
                BindExpenseSheet(TSRExpenseSheet);
                SetEnabledComboBoxExpense();
            }
            else
            {
                string message = Core.ResourceManager.GetResourceString("ExpensesNotSubmitedMessage", "Expenses not submitted");
                MessageBox.Show(message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSaveExpenses_Click(object sender, EventArgs e)
        {
            bool success = false;
            success = saveCurrentExpensesData();

            if (success)
            {
                string message = Core.ResourceManager.GetResourceString("ExpenseEntrySaveSuccessMessage", "Expenses saved");
                MessageBox.Show(message);
                BindExpenseSheet(TSRExpenseSheet);
            }
            else
            {
                string message = Core.ResourceManager.GetResourceString("Expenses", "Expenses") + Core.ResourceManager.GetResourceString("CommonUpdateFailureMessage", " has not been updated");
                MessageBox.Show(message,"", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsAllowEditExpenses(Entity.TimeEntry timeEntry, Entity.ExpenseSheet expenseSheet)
        {
            bool bResult = false;
            if (expenseSheet == null)
            {
                if ((timeEntry.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission) ||
                    (timeEntry.Status == TSR.Core.UserAgentService.StatusEnum.Rejected))
                {
                    bResult = true;
                }
            }
            else if (expenseSheet.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission ||
                    expenseSheet.Status == TSR.Core.UserAgentService.StatusEnum.Rejected)
            {
                bResult = true;
            }

            return bResult;
        }

        private void enableExpenseControls(Entity.TimeEntry timeEntry, Entity.ExpenseSheet sheet)
        {
            bool bAllowEdit = IsAllowEditExpenses(timeEntry, sheet);
            bool bAllowSubmit = (timeEntry.ID != Guid.Empty) && bAllowEdit && !(sheet == null || sheet.ExpenseEntryListLocal == null || sheet.ExpenseEntryListLocal.Count == 0);

            if (bAllowSubmit)
            {
                if (timeEntry.ID != Guid.Empty)
                {
                    Entity.TimeEntry teExisted = TSR.Core.TSRFacade.GetTimeEntryByTSRItemID(timeEntry.ID, false);
                    if (teExisted == null)
                        bAllowSubmit = false;
                }
            }

            btnAddExpense.Enabled = bAllowEdit;

            gvExpensesSheet.Columns[8].Visible = bAllowEdit;
            gvExpensesSheet.Columns[9].Visible = bAllowEdit;

            btnSubmitExpenses.Enabled = bAllowSubmit;
            if(TSRExpenseEntryDeleted != null && TSRExpenseEntryDeleted.Count > 0)
                btnSaveExpenses.Enabled = true;
            else
                btnSaveExpenses.Enabled = bAllowSubmit;

            if(timeEntry.Status != Core.UserAgentService.StatusEnum.PendingSubmission &&
                timeEntry.Status != Core.UserAgentService.StatusEnum.Rejected)
            {
                if (TSRExpenseSheet != null && 
                    (TSRExpenseSheet.Status == Core.UserAgentService.StatusEnum.PendingSubmission ||
                    TSRExpenseSheet.Status == Core.UserAgentService.StatusEnum.Rejected))
                    btnSaveExpenses.Visible = true;
                else
                    btnSaveExpenses.Visible = false;
            }
            else
            {
                btnSaveExpenses.Visible = false;
            }

            //Feature 348
            btnSaveExpenses.Visible = false;

            if (!bAllowEdit)
            {
                lblExpOrg.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblExpProj.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblExpAct.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
                lblExpCnt.ForeColor = UIHelper.GetColor(UIHelper.COLOR_LABAL_ADV_FORM);
            }
        }

        private bool saveCurrentExpensesData()
        {
            bool success = true;

            if (TSRExpenseEntryDeleted != null && TSRExpenseEntryDeleted.Count > 0)
            {
                foreach (var entry in TSRExpenseEntryDeleted)
                {
                    if (entry.ID > 0)
                    {
                        entry.RowState = Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        Core.TSRExpenseFacade.UpdateExpenseEntry(entry);

                        TSRExpenseSheet.ExpenseEntryListLocal.Remove(entry);
                    }
                }
            }

            if (TSRExpenseSheet == null || TSRTimeEntry.ID == Guid.Empty)
                return true;

            if(TSRExpenseSheet.ExpenseEntryListLocal.Count == 0)
            {
                //Delete sheet and return
                //TSRExpenseSheet.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                TSRExpenseSheet.IsDeleted = true;
                success = Core.TSRExpenseFacade.UpdateExpenseSheet(TSRExpenseSheet);
                return success;
            }

            long sheetID = TSRExpenseSheet.ID;

            if(TSRExpenseSheet.ID == 0)
            {
                success = false;
                TSRExpenseSheet.Status = TSR.Core.UserAgentService.StatusEnum.PendingSubmission;
                TSRExpenseSheet.TimeEntryID = TSRTimeEntry.ID;
                success = Core.TSRExpenseFacade.UpdateExpenseSheet(TSRExpenseSheet);
                if(success)
                {
                    Entity.ExpenseSheet insertedSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSRTimeEntry.ID);
                    sheetID = insertedSheet.ID;
                }
            }

            if(success)
            {
                foreach (var entry in TSRExpenseSheet.ExpenseEntryListLocal)
                {
                    entry.ExpenseSheetID = sheetID;
                    Core.TSRExpenseFacade.UpdateExpenseEntry(entry);
                }
            }

            return success;
        }

        private void gvExpensesSheet_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var senderGrid = (DataGridView)sender;

            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                if (e.ColumnIndex == 8)//edit
                {
                    if(e.RowIndex >= 0)
                    {
                        DataGridViewRow row = senderGrid.Rows[e.RowIndex];
                        Entity.ExpenseEntry rowEntry = row.DataBoundItem as Entity.ExpenseEntry;

                        Entity.ExpenseEntry entry = TSRExpenseSheet.ExpenseEntryListLocal.ElementAt(e.RowIndex);
                        editExpenseEntry(entry, false);

                        //var row = (DataGridRow)senderGrid.Data
                    }
                }
                else if (e.ColumnIndex == 9) //delete
                {
                    if(e.RowIndex >= 0)
                    {
                        string question = Core.ResourceManager.GetResourceString("Button_ClientClickMessage_Delete", "Do you want to delete?");
                        if (MessageBox.Show(question, "", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                        {
                            DataGridViewRow row = senderGrid.Rows[e.RowIndex];
                            //ExpenseEntry rowEntry = row.DataBoundItem as ExpenseEntry;

                            Entity.ExpenseEntry entry = TSRExpenseSheet.ExpenseEntryListLocal.ElementAt(e.RowIndex);
                            if (entry != null)
                            {
                                TSRExpenseEntryDeleted.Add(entry);
                                TSRExpenseSheet.ExpenseEntryListLocal.Remove(entry);

                                BindExpenseSheet(TSRExpenseSheet);
                            }

                            if (TSRExpenseSheet.ExpenseEntryListLocal != null && !TSRExpenseSheet.ExpenseEntryListLocal.Any())
                            {
                                pnlExpenseStatus.Visible = false;
                                lblExpenseSheetStatus.Visible = false;
                            }
                        }
                    }
                }
            }
        }

        public Entity.ExpenseSheet GetExpenseData()
        {
            if (TSRExpenseSheet == null || TSRExpenseSheet.ExpenseEntryListLocal == null)
            {
                if (TSRExpenseSheet != null)
                    TSRExpenseSheet.IsDeleted = true;
                return TSRExpenseSheet;
            }

            foreach( var entry in TSRExpenseEntryDeleted)
            {
                //entry.IsDeleted = true;
                entry.RowState = Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                TSRExpenseSheet.ExpenseEntryListLocal.Add(entry);
            }
            if (TSRExpenseSheet.ExpenseEntryListLocal.Count == 0)
            {
                TSRExpenseSheet.IsDeleted = true;
                //TSRExpenseSheet.RowState = Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
            }
            else
            {
                bool isExistEntry = false;
                foreach (Entity.ExpenseEntry exp in TSRExpenseSheet.ExpenseEntryListLocal)
                {
                    if (exp.RowState != Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
                    {
                        isExistEntry = true;
                        break;
                    }
                }
                if (!isExistEntry)
                {
                    TSRExpenseSheet.IsDeleted = true;
                    //TSRExpenseSheet.RowState = Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                }
            }

            saveCurrentExpensesData();

            return TSRExpenseSheet;
        }

		private void tableLayoutAdvanced_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tableLayoutAdvanced.SelectedTab.Name == "tbpAdvanced")
            {
                SaveComboItemsExpense();

                PopulateComboBoxes();
            }
            else if (tableLayoutAdvanced.SelectedTab.Name == "tbpExpenses")
            {
                SaveComboItems();
                PopulateComboBoxesExpense();
            }
        }

        private void cmbOrganizations_TextChanged(object sender, EventArgs e)
        {
            object[] originalList = (object[])cmbOrganizations.Tag;

            if (originalList == null)
            {
                // backup original list
                originalList = new object[cmbOrganizations.Items.Count];
                cmbOrganizations.Items.CopyTo(originalList, 0);
                cmbOrganizations.Tag = originalList;
            }

            // prepare list of matching items
            string s = cmbOrganizations.Text.ToLower();
            IEnumerable<object> newList = originalList;
            if (s.Length > 0) {
                newList = originalList.Where(item => item.ToString().ToLower().Contains(s));
            }
            else
            {
                cmbOrganizations.SelectedIndex = 0;
            }
            // clear list (loop through it, otherwise the cursor would move to the beginning of the textbox...)
            //while (cmbOrganizations.Items.Count > 0)
            //{
            //    cmbOrganizations.Items.RemoveAt(0);
            //}

            
            cmbOrganizations.ResetBindings();

            // re-set list
            //cmbOrganizations.Items.AddRange(newList.ToArray());
        }

        private IEnumerable<PreferredPaths> RetrievePreferredPaths()
        {
            return TSR.Core.TSRFacade.GetAllPreferredPathsList();
        }

        private bool GetShowOnlyFavorites()
        {
            return TSR.Core.SettingsHelper.ShowOnlyFavorites;
        }

        private Entity.OrganizationList CheckOrganizationShowOnlyFavorites(Entity.OrganizationList organizationList)
        {
            if (!GetShowOnlyFavorites())
                return organizationList;
            else
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.OrganizationID).ToList();
                favoriteIDs.Add(TSRTimeEntry.OrganizationID);
               
                var listNotDisplay = organizationList.Where(x => !favoriteIDs.Distinct().Contains(x.ID)).ToList();
                foreach (var item in listNotDisplay)
                {
                    if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                        organizationList.Remove(item);
                }
                   
                return organizationList;
            }
        }

        private Entity.ProjectList CheckProjectShowOnlyFavorites(Entity.ProjectList projectList)
        {
            if (!GetShowOnlyFavorites())
                return projectList;
            else
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.ProjectID).ToList();
                favoriteIDs.Add(TSRTimeEntry.ProjectID);
                
                var listNotDisplay = projectList.Where(x => !favoriteIDs.Distinct().Contains(x.ID)).ToList();
                foreach (var item in listNotDisplay)
                {
                    if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                        projectList.Remove(item);
                }

                return projectList;
            }
        }

        private Entity.ActivityList CheckActivityShowOnlyFavorites(Entity.ActivityList activityList, long projectId = -1)
        {
            if (!GetShowOnlyFavorites())
                return activityList;
            else
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.ActivityID).ToList();
                if (projectId > 0)
                    favoriteIDs = RetrievePreferredPaths().Where(x => x.ProjectID == projectId).Select(x => x.ActivityID).ToList();
                if(!favoriteIDs.Any())
                    favoriteIDs.Add(TSRTimeEntry.ActivityID);
                
                var listNotDisplay = activityList.Where(x => !favoriteIDs.Distinct().Contains(x.ID)).ToList();
                foreach (var item in listNotDisplay)
                {
                    if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                        activityList.Remove(item);
                }

                return activityList;
            }
        }

        private void cmbFavorites_MouseClick(object sender, MouseEventArgs e)
        {
            _favoritesComboIndexChanged = true;
        }

        private void cmbProjects_TextChanged(object sender, EventArgs e)
        {
            string s = cmbProjects.Text.ToLower();
            if (s.Length == 0)
            {
                if (cmbProjects.Items.Count > 0)
                    cmbProjects.SelectedIndex = 0;
            }
        }
 
        private void cmbActivities_TextChanged(object sender, EventArgs e)
        {
            string s = cmbActivities.Text.ToLower();
            if (s.Length == 0)
            {
                if (cmbActivities.Items.Count > 0)
                    cmbActivities.SelectedIndex = 0;
            }
        }

        private void cmbOrganizations_Leave(object sender, EventArgs e)
        {
            if (cmbOrganizations.SelectedIndex == -1)
                if (cmbOrganizations.Items.Count > 0)
                    cmbOrganizations.SelectedIndex = 0;
        }

        private void cmbProjects_Leave(object sender, EventArgs e)
        {
            if (cmbProjects.SelectedIndex == -1)
                if (cmbProjects.Items.Count > 0)
                    cmbProjects.SelectedIndex = 0;
        }

        private void cmbActivities_Leave(object sender, EventArgs e)
        {
            if (cmbActivities.SelectedIndex == -1)
                if (cmbActivities.Items.Count > 0)
                    cmbActivities.SelectedIndex = 0;
        }

        private void cbbExpenseOrganization_TextChanged(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            string s = cbbExpenseOrganization.Text.ToLower();
            if (s.Length == 0)
            {
                if (cbbExpenseOrganization.Items.Count > 0)
                    cbbExpenseOrganization.SelectedIndex = 0;
            }
        }

        private void cbbExpenseOrganization_Leave(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            if (cbbExpenseOrganization.SelectedIndex == -1)
                if (cbbExpenseOrganization.Items.Count > 0)
                    cbbExpenseOrganization.SelectedIndex = 0;
        }

        private void cbbExpenseProject_TextChanged(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            string s = cbbExpenseProject.Text.ToLower();
            if (s.Length == 0)
            {
                if (cbbExpenseProject.Items.Count > 0)
                    cbbExpenseProject.SelectedIndex = 0;
            }
        }

        private void cbbExpenseProject_Leave(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            if (cbbExpenseProject.SelectedIndex == -1)
                if (cbbExpenseProject.Items.Count > 0)
                    cbbExpenseProject.SelectedIndex = 0;
        }

        private void cbbExpenseActivity_TextChanged(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            string s = cbbExpenseActivity.Text.ToLower();
            if (s.Length == 0)
            {
                if (cbbExpenseActivity.Items.Count > 0)
                    cbbExpenseActivity.SelectedIndex = 0;
            }
        }

        private void cbbExpenseActivity_Leave(object sender, EventArgs e)
        {
            if (this.IsExpenseMode == false)
                return;

            if (cbbExpenseActivity.SelectedIndex == -1)
                if (cbbExpenseActivity.Items.Count > 0)
                    cbbExpenseActivity.SelectedIndex = 0;
        }

        private void cmbFavorites_Leave(object sender, EventArgs e)
        {
            if (cmbFavorites.SelectedIndex == -1)
                if (cmbFavorites.Items.Count > 0)
                    cmbFavorites.SelectedIndex = 0;
        }
        
        private void txtDuration_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != decimalSymbol))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == decimalSymbol) && ((sender as TextBox).Text.IndexOf(decimalSymbol) > -1))
            {
                e.Handled = true;
            }
        }

        private void tableLayoutAdvanced_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (IsExpenseMode == false)
            {
                e.Cancel = true;
                return;
            }

            if (cmbOrganizations.SelectedItem != null && cmbProjects.SelectedItem != null && cmbActivities.SelectedItem != null)
            {
                var org = cmbOrganizations.SelectedItem as Entity.Organization;

                var prj = cmbProjects.SelectedItem as Entity.Project;

                var act = cmbActivities.SelectedItem as Entity.Activity;

                if (org.ID == -1 || prj.ID == -1 || act.ID == -1)
                {
                    e.Cancel = true;

                    MessageBox.Show(Core.ResourceHelper.PleaseEnterAppropriateOUA);
                }
            }
        }

        private void gvExpensesSheet_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.ColumnIndex == 8)
            {
                e.Value = Core.ResourceManager.GetResourceString("Edit", "Edit");
            }
            if (e.ColumnIndex == 9)
            {
                e.Value = Core.ResourceManager.GetResourceString("Delete", "Delete");
            }
        }

        private void TimeEntryAdvanced_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!_isClickOk)
            {
                TSRTimeEntry.OrganizationID = organizationId;
                TSRTimeEntry.ProjectID = projectId;
                TSRTimeEntry.ActivityID = activityId;    
            }
            _isClickOk = false;
        }
    }

    public class ComboboxItem
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
}