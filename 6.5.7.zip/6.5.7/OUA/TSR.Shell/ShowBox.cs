﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.Collections;
using System.Diagnostics;
using System.Collections.Specialized;
using System.Globalization;
using Microsoft.Office.Interop.Outlook;
using TSR.Core.Entity.List;
using TSR.Core;
using TSR.Core.Entity;
using TSR.Core.DAL;
using Microsoft.Win32;	// For RegKey
namespace TSR.Shell
{
    public partial class ShowBox : Controls.OUAForm
    {
        public ShowBox()
        {
            
            InitializeComponent();
            this.Text = Core.ResourceHelper.ShowMessgaBoxFormText.ToString();
            btnYes.Text = Core.ResourceHelper.ShowMessgaBoxYes.ToString();
            btnNo.Text = Core.ResourceHelper.ShowMessgaBoxNo.ToString();
        }

        private void ShowBox_Load(object sender, EventArgs e)
        {
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            lblMessegaBox.Text = ResourceManager.GetResourceString("DoYouWantToSaveSettingToServerChanges", "Do you want to save your settings to the server ?");
            
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Yes;
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.No;
        }
    }
}
