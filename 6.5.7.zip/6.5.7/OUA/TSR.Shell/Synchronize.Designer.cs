namespace TSR.Shell
{
    partial class Synchronize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResponse = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.llExpandCollapse = new System.Windows.Forms.LinkLabel();
            this.grpSyncSettings = new System.Windows.Forms.GroupBox();
            this.grpSettings = new System.Windows.Forms.GroupBox();
            this.rdbRetrieveDefaultSetting = new System.Windows.Forms.RadioButton();
            this.rdbRetrieveSetting = new System.Windows.Forms.RadioButton();
            this.rdbSaveSetting = new System.Windows.Forms.RadioButton();
            this.grpFavorites = new System.Windows.Forms.GroupBox();
            this.rdbRetrieveFav = new System.Windows.Forms.RadioButton();
            this.rdbSaveFav = new System.Windows.Forms.RadioButton();
            this.ucTSRItemList1 = new TSR.Shell.Controls.ucTSRItemList();
            this.chkForceFullSync = new System.Windows.Forms.CheckBox();
            this.grpSyncSettings.SuspendLayout();
            this.grpSettings.SuspendLayout();
            this.grpFavorites.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtResponse
            // 
            this.txtResponse.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtResponse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(210)))), ((int)(((byte)(239)))));
            this.txtResponse.Location = new System.Drawing.Point(3, 176);
            this.txtResponse.Multiline = true;
            this.txtResponse.Name = "txtResponse";
            this.txtResponse.ReadOnly = true;
            this.txtResponse.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResponse.Size = new System.Drawing.Size(713, 42);
            this.txtResponse.TabIndex = 0;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnClose.Location = new System.Drawing.Point(635, 145);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(81, 23);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnStart.Location = new System.Drawing.Point(286, 144);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(148, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnShow
            // 
            this.btnShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnShow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnShow.Location = new System.Drawing.Point(440, 145);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(187, 23);
            this.btnShow.TabIndex = 1;
            this.btnShow.Text = "Show";
            this.btnShow.UseVisualStyleBackColor = false;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // llExpandCollapse
            // 
            this.llExpandCollapse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llExpandCollapse.AutoEllipsis = true;
            this.llExpandCollapse.AutoSize = true;
            this.llExpandCollapse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.llExpandCollapse.Location = new System.Drawing.Point(618, 179);
            this.llExpandCollapse.Name = "llExpandCollapse";
            this.llExpandCollapse.Size = new System.Drawing.Size(69, 13);
            this.llExpandCollapse.TabIndex = 3;
            this.llExpandCollapse.TabStop = true;
            this.llExpandCollapse.Text = "Show Details";
            this.llExpandCollapse.Visible = false;
            this.llExpandCollapse.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExpandCollapse_LinkClicked);
            // 
            // grpSyncSettings
            // 
            this.grpSyncSettings.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.grpSyncSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.grpSyncSettings.Controls.Add(this.grpSettings);
            this.grpSyncSettings.Controls.Add(this.grpFavorites);
            this.grpSyncSettings.ForeColor = System.Drawing.Color.Black;
            this.grpSyncSettings.Location = new System.Drawing.Point(3, 8);
            this.grpSyncSettings.Name = "grpSyncSettings";
            this.grpSyncSettings.Size = new System.Drawing.Size(713, 128);
            this.grpSyncSettings.TabIndex = 9;
            this.grpSyncSettings.TabStop = false;
            this.grpSyncSettings.Text = "Settings for current synchronization";
            // 
            // grpSettings
            // 
            this.grpSettings.Controls.Add(this.rdbRetrieveDefaultSetting);
            this.grpSettings.Controls.Add(this.rdbRetrieveSetting);
            this.grpSettings.Controls.Add(this.rdbSaveSetting);
            this.grpSettings.ForeColor = System.Drawing.Color.Black;
            this.grpSettings.Location = new System.Drawing.Point(8, 68);
            this.grpSettings.Name = "grpSettings";
            this.grpSettings.Size = new System.Drawing.Size(600, 52);
            this.grpSettings.TabIndex = 1;
            this.grpSettings.TabStop = false;
            this.grpSettings.Text = "Settings";
            // 
            // rdbRetrieveDefaultSetting
            // 
            this.rdbRetrieveDefaultSetting.Location = new System.Drawing.Point(384, 24);
            this.rdbRetrieveDefaultSetting.Name = "rdbRetrieveDefaultSetting";
            this.rdbRetrieveDefaultSetting.Size = new System.Drawing.Size(208, 17);
            this.rdbRetrieveDefaultSetting.TabIndex = 2;
            this.rdbRetrieveDefaultSetting.TabStop = true;
            this.rdbRetrieveDefaultSetting.Text = "Retrieve Default Settings from Server";
            this.rdbRetrieveDefaultSetting.UseVisualStyleBackColor = true;
            // 
            // rdbRetrieveSetting
            // 
            this.rdbRetrieveSetting.Location = new System.Drawing.Point(198, 24);
            this.rdbRetrieveSetting.Name = "rdbRetrieveSetting";
            this.rdbRetrieveSetting.Size = new System.Drawing.Size(178, 17);
            this.rdbRetrieveSetting.TabIndex = 1;
            this.rdbRetrieveSetting.TabStop = true;
            this.rdbRetrieveSetting.Text = "Retrieve Settings from Server";
            this.rdbRetrieveSetting.UseVisualStyleBackColor = true;
            // 
            // rdbSaveSetting
            // 
            this.rdbSaveSetting.Location = new System.Drawing.Point(37, 24);
            this.rdbSaveSetting.Name = "rdbSaveSetting";
            this.rdbSaveSetting.Size = new System.Drawing.Size(155, 17);
            this.rdbSaveSetting.TabIndex = 0;
            this.rdbSaveSetting.TabStop = true;
            this.rdbSaveSetting.Text = "Save Settings to Server";
            this.rdbSaveSetting.UseVisualStyleBackColor = true;
            // 
            // grpFavorites
            // 
            this.grpFavorites.Controls.Add(this.rdbRetrieveFav);
            this.grpFavorites.Controls.Add(this.rdbSaveFav);
            this.grpFavorites.ForeColor = System.Drawing.Color.Black;
            this.grpFavorites.Location = new System.Drawing.Point(8, 16);
            this.grpFavorites.Name = "grpFavorites";
            this.grpFavorites.Size = new System.Drawing.Size(600, 48);
            this.grpFavorites.TabIndex = 0;
            this.grpFavorites.TabStop = false;
            this.grpFavorites.Text = "Favorites";
            // 
            // rdbRetrieveFav
            // 
            this.rdbRetrieveFav.Location = new System.Drawing.Point(198, 20);
            this.rdbRetrieveFav.Name = "rdbRetrieveFav";
            this.rdbRetrieveFav.Size = new System.Drawing.Size(210, 17);
            this.rdbRetrieveFav.TabIndex = 1;
            this.rdbRetrieveFav.TabStop = true;
            this.rdbRetrieveFav.Text = "Retrieve Favorites from Server";
            this.rdbRetrieveFav.UseVisualStyleBackColor = true;
            // 
            // rdbSaveFav
            // 
            this.rdbSaveFav.Location = new System.Drawing.Point(37, 20);
            this.rdbSaveFav.Name = "rdbSaveFav";
            this.rdbSaveFav.Size = new System.Drawing.Size(155, 17);
            this.rdbSaveFav.TabIndex = 0;
            this.rdbSaveFav.TabStop = true;
            this.rdbSaveFav.Text = "Save Favorites to Server";
            this.rdbSaveFav.UseVisualStyleBackColor = true;
            // 
            // ucTSRItemList1
            // 
            this.ucTSRItemList1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.ucTSRItemList1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ucTSRItemList1.EnableSelection = true;
            this.ucTSRItemList1.Location = new System.Drawing.Point(3, 232);
            this.ucTSRItemList1.Name = "ucTSRItemList1";
            this.ucTSRItemList1.Size = new System.Drawing.Size(713, 262);
            this.ucTSRItemList1.TabIndex = 6;
            // 
            // chkForceFullSync
            // 
            this.chkForceFullSync.AutoSize = true;
            this.chkForceFullSync.Location = new System.Drawing.Point(48, 146);
            this.chkForceFullSync.Name = "chkForceFullSync";
            this.chkForceFullSync.Size = new System.Drawing.Size(150, 17);
            this.chkForceFullSync.TabIndex = 10;
            this.chkForceFullSync.Text = "Force Full Synchronization";
            this.chkForceFullSync.UseVisualStyleBackColor = true;
            // 
            // Synchronize
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(718, 496);
            this.Controls.Add(this.chkForceFullSync);
            this.Controls.Add(this.grpSyncSettings);
            this.Controls.Add(this.llExpandCollapse);
            this.Controls.Add(this.ucTSRItemList1);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtResponse);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Synchronize";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Synchronize";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Synchronize_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Synchronize_FormClosed);
            this.Load += new System.EventHandler(this.Synchronize_Load);
            this.grpSyncSettings.ResumeLayout(false);
            this.grpSettings.ResumeLayout(false);
            this.grpFavorites.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtResponse;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.LinkLabel llExpandCollapse;
        private System.Windows.Forms.GroupBox grpSyncSettings;
        private System.Windows.Forms.GroupBox grpFavorites;
        private System.Windows.Forms.RadioButton rdbSaveFav;
        private System.Windows.Forms.RadioButton rdbRetrieveFav;
        private System.Windows.Forms.GroupBox grpSettings;
        private System.Windows.Forms.RadioButton rdbRetrieveSetting;
        private System.Windows.Forms.RadioButton rdbSaveSetting;
        private System.Windows.Forms.RadioButton rdbRetrieveDefaultSetting;
        private TSR.Shell.Controls.ucTSRItemList ucTSRItemList1;
        private System.Windows.Forms.CheckBox chkForceFullSync;
    }
}