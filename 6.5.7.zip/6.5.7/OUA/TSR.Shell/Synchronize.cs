using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using TSR.Core;
using TSR.Core.Entity;

namespace TSR.Shell
{
    /// <summary>
    /// This is the synchronization screen..form..
    /// Synchronization is done in background thread.. so that it will not hamper normal user interaction..
    /// </summary>
    public partial class Synchronize : Controls.OUAForm
    {
        //private BackgroundWorker worker;
        private bool IsWorkInProgress = false;
        private StringBuilder _MultiLinerString = new StringBuilder();
        private bool _IsOneLinerMessage = true;
        private SyncEngine.SyncStatus _syncStatus = SyncEngine.SyncStatus.Undefined; // to keep a copy of status received from background thred
        private const int EXPANDED_HEIGHT = 154;
        private const int COLLAPSED_HEIGHT = 32;

        private static Synchronize instance;

         #region Constructor

        /// <summary>
        /// The constructor
        /// </summary>
        private Synchronize()
        {
            InitializeComponent();
        }

        #endregion

        #region singleton

        /// <summary>
        /// This priperty checks 
        /// whether the class is instanciated 
        /// </summary>
        public static bool HasInstance
        {
            get { return (instance != null); }
        }

        /// <summary>
        /// Method
        /// GetInstance
        /// Gets the instnce of this class
        /// </summary>
        /// <returns>
        /// Synchronize
        /// </returns>
        public static Synchronize GetInstance()
        {
            if (instance == null)
            {
                instance = new Synchronize();
            }
            return instance;
        }

        #endregion

        private TimeEntryList _timeEntryList;

        private void Synchronize_Load(object sender, EventArgs e)
        {
            this.Icon = TSR.Core.ResourceHelper.TSRIcon; // set icon
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            grpFavorites.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            grpSettings.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            grpSyncSettings.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            txtResponse.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);
            llExpandCollapse.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_CONTENT_DEFAULT);

            PopulateLocalizedTextFromResource();

            SetEnabledToSaveUserSettings();
            
            btnShow.Enabled = false; //disable the show button 
        }

        private void SetEnabledToSaveUserSettings()
        {
            bool isLocked = TSR.Core.Constants.ISLOCKEDUSERSETTING;
            rdbSaveSetting.Enabled = !isLocked;
        }
        /// <summary>
        /// populate localized text resources
        /// </summary>
        private void PopulateLocalizedTextFromResource()
        {
            //Set the language specific to labels and buttons
            btnClose.Text = TSR.Core.ResourceHelper.OK;
            btnStart.Text = TSR.Core.ResourceHelper.StartSynchronization;
            btnShow.Text = TSR.Core.ResourceHelper.ViewSynchronizedTimeEntries;

            //The name of the form
            this.Text = TSR.Core.ResourceHelper.Synchronization;

            //GroupBox Current Settings for synchronization
            grpSyncSettings.Text = TSR.Core.ResourceHelper.Settings + Core.Constants.SPACE
                + TSR.Core.ResourceHelper.For.ToLower() + Core.Constants.SPACE
                + TSR.Core.ResourceHelper.Current.ToLower()
                + Core.Constants.SPACE + TSR.Core.ResourceHelper.Synchronization.ToLower();

            //group box Favorites
            rdbSaveFav.Text = TSR.Core.ResourceHelper.SaveFavoritesToServer;
            rdbRetrieveFav.Text = TSR.Core.ResourceHelper.RetriveFavoriteFromServer;
            grpFavorites.Text = TSR.Core.ResourceHelper.Favorite;

            //Groupbox Settings
            grpSettings.Text = TSR.Core.ResourceHelper.Settings;
            rdbSaveSetting.Text = TSR.Core.ResourceHelper.SaveSettingsToServer;
            rdbRetrieveSetting.Text = TSR.Core.ResourceHelper.RetriveSettingsFromServer;
            rdbRetrieveDefaultSetting.Text = TSR.Core.ResourceHelper.RetriveDefaultSettings;

            //labelButtonText
            llExpandCollapse.Text = ResourceManager.GetResourceString("Synchronize_ShowDetails", "Show Details");//TSR.Core.ResourceHelper.Show + " " + TSR.Core.ResourceHelper.Details;

            //checkbox force full synchronization
            chkForceFullSync.Text = ResourceManager.GetResourceString("ForceFullSync", "Force Full Synchronization");
        }       
        /// <summary>
        /// Method called when synchronization needs to be started
        /// </summary>
        private void StartSynchronization()
        {
            string message = string.Empty;

            try
            {
                txtResponse.Text = string.Empty;
                _MultiLinerString = new StringBuilder();
                //Login loginForm = new Login();
                Settings settingsForm = new Settings();

                //settings form are passed to syncEngine, so that if needed.. it would be able to show the screen..
                //if server address is not found.. user might want to populate server address field from there..
                Core.SyncEngine syncEngine = Core.SyncEngine.GetInstance(settingsForm);
                if (syncEngine == null)//Only one instance of syncEngine can run at a time.. singleton.. 
                    //so, it must be automatic synchronization that is already using the class
                {
                    message = ResourceManager.GetResourceString("AutomaticSynchronizationInProgress", 
                        "Automatic synchronization is in progress. Please try again later.");
                    txtResponse.Text = message;
                    Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = message,
                        Priority = 0
                    });
                    return;
                }
                syncEngine.ProgressChanged += new SyncEngine.SynchronizationProgressChanged(syncEngine_ProgressChanged);
                syncEngine.Completed += new SyncEngine.SynchronizationCompleted(syncEngine_Completed);
                IMemoryBox memBox = new MemoryBox();
                ISyncEngineCheckListTimeEntry checkListTiemEntry = new CheckListTimeEntry();
                syncEngine._checkListTimeEntry = checkListTiemEntry;
                syncEngine._overwriteTimeEntries = new OverwriteTimeEntries();

                if (TSRFacade.IsServiceUp(Core.SettingsHelper.TSRServerAddress))
                {
                    bool isWrongUserPass = !TSRFacade.LogInToServer();
                    {
                        if (isWrongUserPass && !TSRFacade.TSRLoginDismiss)
                        {
                            frmTSRLoginRequired frmLogin = frmTSRLoginRequired.GetInstance(false);
                            frmLogin.ShowDialog(this);
                        }
                    }
                }
                // add force full sync radio button
                //syncEngine.StartSynchornization(rdbSaveFav.Checked, rdbRetrieveFav.Checked, rdbSaveSetting.Checked, rdbRetrieveSetting.Checked, rdbRetrieveDefaultSetting.Checked, memBox);             
                syncEngine.StartSynchornization(rdbSaveFav.Checked, rdbRetrieveFav.Checked, rdbSaveSetting.Checked, rdbRetrieveSetting.Checked, rdbRetrieveDefaultSetting.Checked, chkForceFullSync.Checked, memBox);
            }
            catch (Exception ex)
            {
                txtResponse.Text = ex.Message;
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }        
        /// <summary>
        /// This method is called when some message is passed from background thread for synchronization..
        /// Synchronization process is running.. in the mean time, user will be viewing these texts.. how it is going..
        /// </summary>
        /// <param name="message"></param>
        /// <param name="status"></param>
        private void LogAppend(string message, TSR.Core.SyncEngine.SyncStatus status)
        {
            _MultiLinerString.Append(message);

            if (_IsOneLinerMessage)
            {
                switch (status)
                {
                    case SyncEngine.SyncStatus.Undefined:
                        //txtResponse.Text = string.Empty;
                        this.Cursor = Cursors.Default;
                        break;
                    case SyncEngine.SyncStatus.Normal:
                        txtResponse.Text = ResourceManager.GetResourceString("SynchronizationInProgress", "Synchronization in progress") + "..";
                        this.Cursor = Cursors.WaitCursor;
                        break;
                    case SyncEngine.SyncStatus.Error:
                        txtResponse.Text = ResourceManager.GetResourceString("ThereWereSomeProblems.PleaseShowDetails", "There were some problems, please show details");
                        this.Cursor = Cursors.Default;
                        break;
                    case SyncEngine.SyncStatus.Completed:
                        txtResponse.Text =ResourceManager.GetResourceString("Completed.ForDetailsPleaseClickShowDetails", "Completed. For details, please click 'Show Details'");
                        this.Cursor = Cursors.Default;
                        break;
                    case SyncEngine.SyncStatus.CompletedWithErrors:
                        txtResponse.Text = ResourceManager.GetResourceString("CompletedWithErrorsForDetailsPleaseClickShowDetails", "Completed with errors. For details, please click 'Show Details'");
                        this.Cursor = Cursors.Default;
                        break;
                }
            }
            else
            {
                if(_MultiLinerString.ToString().Length > 0)
                    txtResponse.Text = _MultiLinerString.ToString();
                if (status == SyncEngine.SyncStatus.Completed)
                {
                    this.Cursor = Cursors.Default;
                }
            }
        }

        /// <summary>
        /// Event raised when synchronization is complete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void syncEngine_Completed(object sender, RunWorkerCompletedEventArgs e)
        {
            IsWorkInProgress = false;
            if(_syncStatus != SyncEngine.SyncStatus.CompletedWithErrors)
                _syncStatus = SyncEngine.SyncStatus.Completed;
            SetEnabledToSaveUserSettings();
            if ((ucTSRItemList1.DataSource != null) && (ucTSRItemList1.DataSource.Count>0))
                showTimeEntriesInGrid();
        }

        /// <summary>
        /// Background thread event during Synchronization.. as status changed..
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void syncEngine_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.UserState != null)
            {
                SyncEngine.SyncMessage progressMessage = (SyncEngine.SyncMessage)e.UserState;
                _syncStatus = progressMessage.Status;

                if (!string.IsNullOrEmpty(progressMessage.Message))
                {
                    LogAppend(progressMessage.Message, progressMessage.Status);
                }
                switch (progressMessage.Status)
                {
                    case SyncEngine.SyncStatus.Completed:
                        _timeEntryList = progressMessage.UpdatedTimeEntries;
                        btnShow.Enabled = true;
                        btnStart.Enabled = true;
                        LogAppend(string.Empty, SyncEngine.SyncStatus.Completed);
                        break;
                    case SyncEngine.SyncStatus.CompletedWithErrors:
                        LogAppend(string.Empty, SyncEngine.SyncStatus.CompletedWithErrors);
                        break;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            llExpandCollapse.Visible = true;
            StartSynchronization();

            //SetEnabledToSaveUserSettings();

        }

        /// <summary>
        /// show button click event for showing synchronized time entries
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShow_Click(object sender, EventArgs e)
        {
            if (!showTimeEntriesInGrid())
            {
                string NoTimeEntriesHaveBeenUpdatedMsg = Core.ResourceManager.GetResourceString("noTimeEntriesHaveBeenUpdatedMsg", "No time entries have been updated");
                Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    MessageSummary = NoTimeEntriesHaveBeenUpdatedMsg,
                    Priority = 0
                });
                MessageBox.Show(NoTimeEntriesHaveBeenUpdatedMsg);
            }
        }

        private bool showTimeEntriesInGrid()
        {
            if ((_timeEntryList != null) && (_timeEntryList.Count > 0))
            {
                ucTSRItemList1.EnableSelection = false;
                ucTSRItemList1.DataSource = _timeEntryList;
                return true;
            }
            return false;
        }

        private void Synchronize_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (IsWorkInProgress)
                e.Cancel = true;
        }


        /// <summary>
        /// Click event to expand or collapse the messages during synchronization.. by default user will
        /// see a short/simple message.. if, the link button is clicked.. details will be shown..        
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void llExpandCollapse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int diff = EXPANDED_HEIGHT - COLLAPSED_HEIGHT;
            if (_IsOneLinerMessage)
            {
                //one liner message.. so move things up..
                _IsOneLinerMessage = false;
                llExpandCollapse.Text = ResourceManager.GetResourceString("Synchronize_HideDetails","Hide Details");
                txtResponse.Height = EXPANDED_HEIGHT;
                ucTSRItemList1.Top += diff;
                this.Height += diff;
            }
            else
            {
                // multi liner message.. move things down..
                _IsOneLinerMessage = true;
                llExpandCollapse.Text = ResourceManager.GetResourceString("Synchronize_ShowDetails", "Show Details");
                txtResponse.Height = COLLAPSED_HEIGHT;
                ucTSRItemList1.Top -= diff;
                this.Height -= diff;
            }
            //show the message..
            LogAppend(string.Empty, _syncStatus);
        }

        private void Synchronize_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance.Dispose(); //Free the resources
            instance = null;
        }

       

       
    }
}