using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using TSR.Core;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Diagnostics;
using System.Threading;
using System.IO.IsolatedStorage;
using System.IO;
using TSR.Core.Logging;
using System.Reflection;
using Microsoft.Office.Interop.Outlook;

namespace TSR.Shell
{
    public partial class About : Controls.OUAForm
    {
        private bool isCreateSupportFile = false;
        public About()
        {
            InitializeComponent();
            this.lblCreateSupportLog.Text = Core.ResourceManager.GetResourceString("CreateSupportLog", "Create Support Log Files");
        }

        private void About_Load(object sender, EventArgs e)
        {
            PopulateLocalizedTextFromResource();

            string strVersion = "";
            strVersion = ResourceManager.GetResourceString("OutlookAgentVersion", "Version") + " ";
            if (TSR.Core.Constants.Version3 != "0")
            {
                strVersion = strVersion + TSR.Core.Constants.Version3;
            }
            else
            {
                strVersion = strVersion + TSR.Core.Constants.Version;
            }

            if (TSR.Core.Constants.VersionRevision != "0")
            {
                strVersion = strVersion + " Build # " + TSR.Core.Constants.VersionRevision;
            }
            lblVersionNumber.Text = strVersion;
            lblVersionNumber.Location = new Point((this.Width - lblVersionNumber.Width) / 2 - (this.Width - this.ClientSize.Width), lblVersionNumber.Location.Y);

            //lblExchangeFlag.Text = "Exchangeflag: " + (TSRFacade.GetExchangeMode() ? "Yes" : "No");
            //lblExchangeFlag.Location = new Point((this.Width - lblExchangeFlag.Width) / 2 - (this.Width - this.ClientSize.Width), lblExchangeFlag.Location.Y);

            txtLicense.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            lblLegalWarning.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            txtOrgantionName.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            this.BackColor = UIHelper.GetColor(UIHelper.BACK_COLOR_DEFAULT);
            Core.LicenseInfo licenseInfo = Core.TSRFacade.GetLicenseInfo();

            StringBuilder sbLicense = new StringBuilder();

            if (!string.IsNullOrEmpty(licenseInfo.LicenseText))
            {
                sbLicense.Append(licenseInfo.LicenseText);
                sbLicense.Append(Environment.NewLine);
            }

            if (!string.IsNullOrEmpty(licenseInfo.CompanyName))
            {
                sbLicense.Append(ResourceManager.GetResourceString("ThePLicensedTo", "This Product is licensed to "));
                sbLicense.Append(licenseInfo.CompanyName);
                sbLicense.Append(Environment.NewLine);
            }

            txtOrgantionName.Text = licenseInfo.CompanyName;

            if (licenseInfo.ExpiryDate.HasValue)
            {
                sbLicense.Append(ResourceManager.GetResourceString("LicenseExpireBy", "License will expire by "));
                sbLicense.Append(licenseInfo.ExpiryDate.Value.ToShortDateString());
            }
            this.Icon = TSR.Core.ResourceHelper.TSRIcon;

        }

        private void lblCompanyName_Click(object sender, EventArgs e)
        {
            if (lblCompanyName.Text.Trim() == string.Empty)
            {
                return;
            }
            try
            {
                System.Diagnostics.Process.Start(lblCompanyName.Text);
            }
            catch { }
        }

        private void PopulateLocalizedTextFromResource()
        {
            this.Text = ResourceManager.GetResourceString("_aboutText", "About") + " TSR";
            txtLicense.Text = ResourceManager.GetResourceString("ThePLicensedTo", "This product is licensed to") + " ";
            lblLegalWarning.Text = ResourceManager.GetResourceString("CopyrightTSR", "Copyright TimeSheet Reporter. All rights reserved") + ".";
        }

        private void lblCreateSupportLog_Click(object sender, EventArgs e)
        {
            isCreateSupportFile = true;
            this.Close();
        }

        private void About_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.isCreateSupportFile && frmCreateSupportLogFile.Instances == 0)
            {
                frmCreateSupportLogFile frm = new frmCreateSupportLogFile();
                frm.FormClosed += new FormClosedEventHandler(frm_FormClosed);
                frm.Show();
                frmCreateSupportLogFile.Instances = 1;
                frm.Visible = true;
            }
        }

        void frm_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmCreateSupportLogFile.Instances = 0;
        }
    }
}