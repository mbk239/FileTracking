using TSR.Shell.Controls;
using TSR.Shell.Controls.SuggestComboBoxControl;

namespace TSR.Shell
{
    partial class TimeEntryAdvanced
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnOK = new System.Windows.Forms.Button();
            this.tableLayoutAdvanced = new System.Windows.Forms.TabControl();
            this.tbpAdvanced = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.grpMessage = new System.Windows.Forms.GroupBox();
            this.txtNewResponse = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPreviousResponses = new System.Windows.Forms.TextBox();
            this.grpAdvancedAttributes = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.txtDuration = new System.Windows.Forms.TextBox();
            this.dtStartTime = new System.Windows.Forms.DateTimePicker();
            this.lblDuration = new System.Windows.Forms.Label();
            this.dtStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblStartTime = new System.Windows.Forms.Label();
            this.cbOutOfOffice = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblOrganization = new System.Windows.Forms.Label();
            this.lblActivity = new System.Windows.Forms.Label();
            this.cmbOrganizations = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.cmbProjects = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.cmbActivities = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.cmbFavorites = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.lblFavorites = new System.Windows.Forms.Label();
            this.cbxLocation = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.lblContact = new System.Windows.Forms.Label();
            this.cmbTasks = new System.Windows.Forms.ComboBox();
            this.cmbContacts = new System.Windows.Forms.ComboBox();
            this.lblLocation = new System.Windows.Forms.Label();
            this.lblTask = new System.Windows.Forms.Label();
            this.lblProject = new System.Windows.Forms.Label();
            this.tbpExpenses = new System.Windows.Forms.TabPage();
            this.tableLayoutExpense = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.cbbExpenseActivity = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.cbbExpenseOrganization = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.cbbExpenseContact = new System.Windows.Forms.ComboBox();
            this.cbbExpenseProject = new TSR.Shell.Controls.SuggestComboBoxControl.SuggestComboBox();
            this.lblExpProj = new System.Windows.Forms.Label();
            this.lblExpOrg = new System.Windows.Forms.Label();
            this.lblExpCnt = new System.Windows.Forms.Label();
            this.lblExpAct = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnSaveExpenses = new System.Windows.Forms.Button();
            this.btnSubmitExpenses = new System.Windows.Forms.Button();
            this.pnlExpenseStatus = new System.Windows.Forms.Panel();
            this.lblExpenseSheetStatus = new System.Windows.Forms.Label();
            this.gvExpensesSheet = new TSR.Shell.Controls.DataGridViewTSR();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseTypeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btnDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnAddExpense = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblExpenseTotalValue = new System.Windows.Forms.Label();
            this.lblExpenseTotal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tableLayoutAdvanced.SuspendLayout();
            this.tbpAdvanced.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.grpMessage.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpAdvancedAttributes.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tbpExpenses.SuspendLayout();
            this.tableLayoutExpense.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlExpenseStatus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvExpensesSheet)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(687, 5);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.btnOK);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Location = new System.Drawing.Point(0, 515);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(796, 33);
            this.panel1.TabIndex = 9;
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.btnOK.Location = new System.Drawing.Point(606, 5);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = false;
            this.btnOK.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // tableLayoutAdvanced
            // 
            this.tableLayoutAdvanced.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutAdvanced.Controls.Add(this.tbpAdvanced);
            this.tableLayoutAdvanced.Controls.Add(this.tbpExpenses);
            this.tableLayoutAdvanced.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutAdvanced.Name = "tableLayoutAdvanced";
            this.tableLayoutAdvanced.SelectedIndex = 0;
            this.tableLayoutAdvanced.Size = new System.Drawing.Size(796, 511);
            this.tableLayoutAdvanced.TabIndex = 9;
            this.tableLayoutAdvanced.SelectedIndexChanged += new System.EventHandler(this.tableLayoutAdvanced_SelectedIndexChanged);
            this.tableLayoutAdvanced.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tableLayoutAdvanced_Selecting);
            // 
            // tbpAdvanced
            // 
            this.tbpAdvanced.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tbpAdvanced.Controls.Add(this.tableLayoutPanel1);
            this.tbpAdvanced.Location = new System.Drawing.Point(4, 22);
            this.tbpAdvanced.Name = "tbpAdvanced";
            this.tbpAdvanced.Padding = new System.Windows.Forms.Padding(3);
            this.tbpAdvanced.Size = new System.Drawing.Size(788, 485);
            this.tbpAdvanced.TabIndex = 0;
            this.tbpAdvanced.Text = "Advanced";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.grpMessage, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.grpAdvancedAttributes, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 6);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.23197F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.76803F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(779, 479);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // grpMessage
            // 
            this.grpMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.grpMessage.Controls.Add(this.txtNewResponse);
            this.grpMessage.Controls.Add(this.groupBox2);
            this.grpMessage.Location = new System.Drawing.Point(3, 181);
            this.grpMessage.Name = "grpMessage";
            this.grpMessage.Size = new System.Drawing.Size(773, 290);
            this.grpMessage.TabIndex = 7;
            this.grpMessage.TabStop = false;
            this.grpMessage.Text = "Message History";
            // 
            // txtNewResponse
            // 
            this.txtNewResponse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNewResponse.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtNewResponse.Location = new System.Drawing.Point(11, 157);
            this.txtNewResponse.Multiline = true;
            this.txtNewResponse.Name = "txtNewResponse";
            this.txtNewResponse.Size = new System.Drawing.Size(759, 123);
            this.txtNewResponse.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.txtPreviousResponses);
            this.groupBox2.Location = new System.Drawing.Point(11, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(759, 131);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // txtPreviousResponses
            // 
            this.txtPreviousResponses.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPreviousResponses.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtPreviousResponses.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtPreviousResponses.Location = new System.Drawing.Point(3, 16);
            this.txtPreviousResponses.Multiline = true;
            this.txtPreviousResponses.Name = "txtPreviousResponses";
            this.txtPreviousResponses.ReadOnly = true;
            this.txtPreviousResponses.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtPreviousResponses.Size = new System.Drawing.Size(756, 112);
            this.txtPreviousResponses.TabIndex = 0;
            // 
            // grpAdvancedAttributes
            // 
            this.grpAdvancedAttributes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpAdvancedAttributes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.grpAdvancedAttributes.Controls.Add(this.tableLayoutPanel4);
            this.grpAdvancedAttributes.Controls.Add(this.tableLayoutPanel2);
            this.grpAdvancedAttributes.Location = new System.Drawing.Point(3, 3);
            this.grpAdvancedAttributes.Name = "grpAdvancedAttributes";
            this.grpAdvancedAttributes.Size = new System.Drawing.Size(773, 172);
            this.grpAdvancedAttributes.TabIndex = 6;
            this.grpAdvancedAttributes.TabStop = false;
            this.grpAdvancedAttributes.Text = "Other Information";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 7;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.80952F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.57143F));
            this.tableLayoutPanel4.Controls.Add(this.lblStartDate, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.txtDuration, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.dtStartTime, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblDuration, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.dtStartDate, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblStartTime, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.cbOutOfOffice, 6, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(9, 139);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(761, 33);
            this.tableLayoutPanel4.TabIndex = 61;
            // 
            // lblStartDate
            // 
            this.lblStartDate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(53, 10);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(55, 13);
            this.lblStartDate.TabIndex = 54;
            this.lblStartDate.Text = "Start Date";
            // 
            // txtDuration
            // 
            this.txtDuration.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDuration.Location = new System.Drawing.Point(561, 6);
            this.txtDuration.Name = "txtDuration";
            this.txtDuration.Size = new System.Drawing.Size(56, 20);
            this.txtDuration.TabIndex = 57;
            this.txtDuration.TabStop = false;
            this.txtDuration.Text = "0";
            this.txtDuration.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDuration_KeyPress);
            // 
            // dtStartTime
            // 
            this.dtStartTime.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtStartTime.Location = new System.Drawing.Point(350, 6);
            this.dtStartTime.Name = "dtStartTime";
            this.dtStartTime.ShowUpDown = true;
            this.dtStartTime.Size = new System.Drawing.Size(83, 20);
            this.dtStartTime.TabIndex = 59;
            // 
            // lblDuration
            // 
            this.lblDuration.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblDuration.AutoSize = true;
            this.lblDuration.Location = new System.Drawing.Point(503, 10);
            this.lblDuration.Name = "lblDuration";
            this.lblDuration.Size = new System.Drawing.Size(47, 13);
            this.lblDuration.TabIndex = 56;
            this.lblDuration.Text = "Duration";
            // 
            // dtStartDate
            // 
            this.dtStartDate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtStartDate.Location = new System.Drawing.Point(121, 6);
            this.dtStartDate.Name = "dtStartDate";
            this.dtStartDate.Size = new System.Drawing.Size(100, 20);
            this.dtStartDate.TabIndex = 53;
            // 
            // lblStartTime
            // 
            this.lblStartTime.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblStartTime.AutoSize = true;
            this.lblStartTime.Location = new System.Drawing.Point(284, 10);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(55, 13);
            this.lblStartTime.TabIndex = 55;
            this.lblStartTime.Text = "Start Time";
            // 
            // cbOutOfOffice
            // 
            this.cbOutOfOffice.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.cbOutOfOffice.AutoSize = true;
            this.cbOutOfOffice.Location = new System.Drawing.Point(672, 8);
            this.cbOutOfOffice.Name = "cbOutOfOffice";
            this.cbOutOfOffice.Size = new System.Drawing.Size(86, 17);
            this.cbOutOfOffice.TabIndex = 46;
            this.cbOutOfOffice.Text = "Out of Office";
            this.cbOutOfOffice.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lblOrganization, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblActivity, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbOrganizations, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbProjects, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmbActivities, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbFavorites, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblFavorites, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.cbxLocation, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblContact, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.cmbTasks, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.cmbContacts, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblLocation, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblTask, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblProject, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(9, 19);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(764, 112);
            this.tableLayoutPanel2.TabIndex = 60;
            // 
            // lblOrganization
            // 
            this.lblOrganization.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblOrganization.Location = new System.Drawing.Point(3, 7);
            this.lblOrganization.Name = "lblOrganization";
            this.lblOrganization.Size = new System.Drawing.Size(94, 13);
            this.lblOrganization.TabIndex = 38;
            this.lblOrganization.Text = "Organization";
            // 
            // lblActivity
            // 
            this.lblActivity.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblActivity.Location = new System.Drawing.Point(385, 7);
            this.lblActivity.Name = "lblActivity";
            this.lblActivity.Size = new System.Drawing.Size(94, 13);
            this.lblActivity.TabIndex = 40;
            this.lblActivity.Text = "Activity";
            // 
            // cmbOrganizations
            // 
            this.cmbOrganizations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbOrganizations.FormattingEnabled = true;
            this.cmbOrganizations.Location = new System.Drawing.Point(103, 3);
            this.cmbOrganizations.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cmbOrganizations.Name = "cmbOrganizations";
            this.cmbOrganizations.Size = new System.Drawing.Size(276, 21);
            this.cmbOrganizations.TabIndex = 0;
            this.cmbOrganizations.SelectedIndexChanged += new System.EventHandler(this.cmbOrganizations_SelectedIndexChanged);
            this.cmbOrganizations.TextChanged += new System.EventHandler(this.cmbOrganizations_TextChanged);
            this.cmbOrganizations.Leave += new System.EventHandler(this.cbbExpenseOrganization_Leave);
            // 
            // cmbProjects
            // 
            this.cmbProjects.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbProjects.FormattingEnabled = true;
            this.cmbProjects.Location = new System.Drawing.Point(103, 31);
            this.cmbProjects.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cmbProjects.Name = "cmbProjects";
            this.cmbProjects.Size = new System.Drawing.Size(276, 21);
            this.cmbProjects.TabIndex = 1;
            this.cmbProjects.SelectedIndexChanged += new System.EventHandler(this.cmbProjects_SelectedIndexChanged);
            this.cmbProjects.TextChanged += new System.EventHandler(this.cmbProjects_TextChanged);
            this.cmbProjects.Leave += new System.EventHandler(this.cmbProjects_Leave);
            // 
            // cmbActivities
            // 
            this.cmbActivities.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbActivities.FormattingEnabled = true;
            this.cmbActivities.Location = new System.Drawing.Point(485, 3);
            this.cmbActivities.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cmbActivities.Name = "cmbActivities";
            this.cmbActivities.Size = new System.Drawing.Size(276, 21);
            this.cmbActivities.TabIndex = 2;
            this.cmbActivities.SelectedIndexChanged += new System.EventHandler(this.cmbActivities_SelectedIndexChanged);
            this.cmbActivities.TextChanged += new System.EventHandler(this.cmbActivities_TextChanged);
            this.cmbActivities.Leave += new System.EventHandler(this.cmbActivities_Leave);
            // 
            // cmbFavorites
            // 
            this.cmbFavorites.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbFavorites.FormattingEnabled = true;
            this.cmbFavorites.Location = new System.Drawing.Point(103, 59);
            this.cmbFavorites.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cmbFavorites.Name = "cmbFavorites";
            this.cmbFavorites.Size = new System.Drawing.Size(276, 21);
            this.cmbFavorites.TabIndex = 41;
            this.cmbFavorites.SelectedIndexChanged += new System.EventHandler(this.cmbFavorites_SelectedIndexChanged);
            this.cmbFavorites.Leave += new System.EventHandler(this.cmbFavorites_Leave);
            this.cmbFavorites.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbFavorites_MouseClick);
            // 
            // lblFavorites
            // 
            this.lblFavorites.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblFavorites.Location = new System.Drawing.Point(3, 63);
            this.lblFavorites.Name = "lblFavorites";
            this.lblFavorites.Size = new System.Drawing.Size(94, 13);
            this.lblFavorites.TabIndex = 42;
            this.lblFavorites.Text = "Favorites";
            // 
            // cbxLocation
            // 
            this.cbxLocation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxLocation.FormattingEnabled = true;
            this.cbxLocation.Location = new System.Drawing.Point(485, 59);
            this.cbxLocation.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cbxLocation.Name = "cbxLocation";
            this.cbxLocation.Size = new System.Drawing.Size(276, 21);
            this.cbxLocation.TabIndex = 51;
            // 
            // lblContact
            // 
            this.lblContact.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblContact.Location = new System.Drawing.Point(385, 35);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(94, 13);
            this.lblContact.TabIndex = 0;
            this.lblContact.Text = "Contact";
            // 
            // cmbTasks
            // 
            this.cmbTasks.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbTasks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTasks.FormattingEnabled = true;
            this.cmbTasks.Location = new System.Drawing.Point(103, 86);
            this.cmbTasks.Name = "cmbTasks";
            this.cmbTasks.Size = new System.Drawing.Size(276, 21);
            this.cmbTasks.TabIndex = 3;
            this.cmbTasks.Visible = false;
            // 
            // cmbContacts
            // 
            this.cmbContacts.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbContacts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContacts.FormattingEnabled = true;
            this.cmbContacts.Location = new System.Drawing.Point(485, 31);
            this.cmbContacts.Name = "cmbContacts";
            this.cmbContacts.Size = new System.Drawing.Size(276, 21);
            this.cmbContacts.TabIndex = 3;
            // 
            // lblLocation
            // 
            this.lblLocation.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblLocation.Location = new System.Drawing.Point(385, 63);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(94, 13);
            this.lblLocation.TabIndex = 52;
            this.lblLocation.Text = "Location";
            // 
            // lblTask
            // 
            this.lblTask.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblTask.Location = new System.Drawing.Point(3, 91);
            this.lblTask.Name = "lblTask";
            this.lblTask.Size = new System.Drawing.Size(94, 13);
            this.lblTask.TabIndex = 2;
            this.lblTask.Text = "Task";
            this.lblTask.Visible = false;
            // 
            // lblProject
            // 
            this.lblProject.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblProject.Location = new System.Drawing.Point(3, 35);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(94, 13);
            this.lblProject.TabIndex = 36;
            this.lblProject.Text = "Project";
            // 
            // tbpExpenses
            // 
            this.tbpExpenses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tbpExpenses.Controls.Add(this.tableLayoutExpense);
            this.tbpExpenses.Location = new System.Drawing.Point(4, 22);
            this.tbpExpenses.Name = "tbpExpenses";
            this.tbpExpenses.Padding = new System.Windows.Forms.Padding(3);
            this.tbpExpenses.Size = new System.Drawing.Size(788, 485);
            this.tbpExpenses.TabIndex = 1;
            this.tbpExpenses.Text = "Expenses";
            // 
            // tableLayoutExpense
            // 
            this.tableLayoutExpense.ColumnCount = 1;
            this.tableLayoutExpense.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutExpense.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutExpense.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutExpense.Controls.Add(this.gvExpensesSheet, 0, 1);
            this.tableLayoutExpense.Controls.Add(this.panel2, 0, 2);
            this.tableLayoutExpense.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutExpense.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutExpense.Name = "tableLayoutExpense";
            this.tableLayoutExpense.RowCount = 4;
            this.tableLayoutExpense.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutExpense.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64F));
            this.tableLayoutExpense.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutExpense.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutExpense.Size = new System.Drawing.Size(782, 479);
            this.tableLayoutExpense.TabIndex = 9;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.cbbExpenseActivity, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.cbbExpenseOrganization, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.cbbExpenseContact, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.cbbExpenseProject, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblExpProj, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblExpOrg, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblExpCnt, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblExpAct, 2, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.39759F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.60241F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(776, 83);
            this.tableLayoutPanel3.TabIndex = 49;
            // 
            // cbbExpenseActivity
            // 
            this.cbbExpenseActivity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbExpenseActivity.FormattingEnabled = true;
            this.cbbExpenseActivity.Location = new System.Drawing.Point(491, 51);
            this.cbbExpenseActivity.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cbbExpenseActivity.Name = "cbbExpenseActivity";
            this.cbbExpenseActivity.Size = new System.Drawing.Size(282, 21);
            this.cbbExpenseActivity.TabIndex = 44;
            this.cbbExpenseActivity.SelectedIndexChanged += new System.EventHandler(this.cbbExpenseActivity_SelectedIndexChanged);
            this.cbbExpenseActivity.TextChanged += new System.EventHandler(this.cbbExpenseActivity_TextChanged);
            this.cbbExpenseActivity.Leave += new System.EventHandler(this.cbbExpenseActivity_Leave);
            // 
            // cbbExpenseOrganization
            // 
            this.cbbExpenseOrganization.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbExpenseOrganization.FormattingEnabled = true;
            this.cbbExpenseOrganization.Location = new System.Drawing.Point(103, 10);
            this.cbbExpenseOrganization.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cbbExpenseOrganization.Name = "cbbExpenseOrganization";
            this.cbbExpenseOrganization.Size = new System.Drawing.Size(282, 21);
            this.cbbExpenseOrganization.TabIndex = 42;
            this.cbbExpenseOrganization.SelectedIndexChanged += new System.EventHandler(this.cbbExpenseOrganization_SelectedIndexChanged);
            this.cbbExpenseOrganization.TextChanged += new System.EventHandler(this.cbbExpenseOrganization_TextChanged);
            this.cbbExpenseOrganization.Leave += new System.EventHandler(this.cbbExpenseOrganization_Leave);
            // 
            // cbbExpenseContact
            // 
            this.cbbExpenseContact.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbExpenseContact.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbExpenseContact.FormattingEnabled = true;
            this.cbbExpenseContact.Location = new System.Drawing.Point(491, 10);
            this.cbbExpenseContact.Name = "cbbExpenseContact";
            this.cbbExpenseContact.Size = new System.Drawing.Size(282, 21);
            this.cbbExpenseContact.TabIndex = 45;
            // 
            // cbbExpenseProject
            // 
            this.cbbExpenseProject.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbbExpenseProject.FormattingEnabled = true;
            this.cbbExpenseProject.Location = new System.Drawing.Point(103, 51);
            this.cbbExpenseProject.MatchingMethod = TSR.Shell.Controls.SuggestComboBoxControl.StringMatchingMethod.UseWildcards;
            this.cbbExpenseProject.Name = "cbbExpenseProject";
            this.cbbExpenseProject.Size = new System.Drawing.Size(282, 21);
            this.cbbExpenseProject.TabIndex = 43;
            this.cbbExpenseProject.SelectedIndexChanged += new System.EventHandler(this.cbbExpenseProject_SelectedIndexChanged);
            this.cbbExpenseProject.TextChanged += new System.EventHandler(this.cbbExpenseProject_TextChanged);
            this.cbbExpenseProject.Leave += new System.EventHandler(this.cbbExpenseProject_Leave);
            // 
            // lblExpProj
            // 
            this.lblExpProj.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblExpProj.Location = new System.Drawing.Point(3, 55);
            this.lblExpProj.Name = "lblExpProj";
            this.lblExpProj.Size = new System.Drawing.Size(94, 13);
            this.lblExpProj.TabIndex = 46;
            this.lblExpProj.Text = "Project";
            // 
            // lblExpOrg
            // 
            this.lblExpOrg.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblExpOrg.Location = new System.Drawing.Point(3, 14);
            this.lblExpOrg.Name = "lblExpOrg";
            this.lblExpOrg.Size = new System.Drawing.Size(94, 13);
            this.lblExpOrg.TabIndex = 47;
            this.lblExpOrg.Text = "Organization";
            // 
            // lblExpCnt
            // 
            this.lblExpCnt.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblExpCnt.Location = new System.Drawing.Point(391, 14);
            this.lblExpCnt.Name = "lblExpCnt";
            this.lblExpCnt.Size = new System.Drawing.Size(94, 13);
            this.lblExpCnt.TabIndex = 41;
            this.lblExpCnt.Text = "Contact";
            // 
            // lblExpAct
            // 
            this.lblExpAct.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblExpAct.Location = new System.Drawing.Point(391, 55);
            this.lblExpAct.Name = "lblExpAct";
            this.lblExpAct.Size = new System.Drawing.Size(94, 13);
            this.lblExpAct.TabIndex = 48;
            this.lblExpAct.Text = "Activity";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnSaveExpenses);
            this.panel3.Controls.Add(this.btnSubmitExpenses);
            this.panel3.Controls.Add(this.pnlExpenseStatus);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 442);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(776, 34);
            this.panel3.TabIndex = 9;
            // 
            // btnSaveExpenses
            // 
            this.btnSaveExpenses.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSaveExpenses.AutoSize = true;
            this.btnSaveExpenses.Location = new System.Drawing.Point(539, 7);
            this.btnSaveExpenses.Name = "btnSaveExpenses";
            this.btnSaveExpenses.Size = new System.Drawing.Size(114, 23);
            this.btnSaveExpenses.TabIndex = 2;
            this.btnSaveExpenses.Text = "Save expenses";
            this.btnSaveExpenses.UseVisualStyleBackColor = true;
            this.btnSaveExpenses.Visible = false;
            this.btnSaveExpenses.Click += new System.EventHandler(this.btnSaveExpenses_Click);
            // 
            // btnSubmitExpenses
            // 
            this.btnSubmitExpenses.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnSubmitExpenses.AutoSize = true;
            this.btnSubmitExpenses.Location = new System.Drawing.Point(659, 7);
            this.btnSubmitExpenses.Name = "btnSubmitExpenses";
            this.btnSubmitExpenses.Size = new System.Drawing.Size(114, 23);
            this.btnSubmitExpenses.TabIndex = 2;
            this.btnSubmitExpenses.Text = "Submit expenses";
            this.btnSubmitExpenses.UseVisualStyleBackColor = true;
            this.btnSubmitExpenses.Click += new System.EventHandler(this.btnSubmitExpenses_Click);
            // 
            // pnlExpenseStatus
            // 
            this.pnlExpenseStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlExpenseStatus.Controls.Add(this.lblExpenseSheetStatus);
            this.pnlExpenseStatus.Location = new System.Drawing.Point(3, 3);
            this.pnlExpenseStatus.Name = "pnlExpenseStatus";
            this.pnlExpenseStatus.Size = new System.Drawing.Size(195, 23);
            this.pnlExpenseStatus.TabIndex = 1;
            // 
            // lblExpenseSheetStatus
            // 
            this.lblExpenseSheetStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblExpenseSheetStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenseSheetStatus.Location = new System.Drawing.Point(0, 0);
            this.lblExpenseSheetStatus.Name = "lblExpenseSheetStatus";
            this.lblExpenseSheetStatus.Size = new System.Drawing.Size(193, 21);
            this.lblExpenseSheetStatus.TabIndex = 1;
            this.lblExpenseSheetStatus.Text = "Expense sheet status";
            this.lblExpenseSheetStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gvExpensesSheet
            // 
            this.gvExpensesSheet.AllowUserToAddRows = false;
            this.gvExpensesSheet.AllowUserToDeleteRows = false;
            this.gvExpensesSheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gvExpensesSheet.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.gvExpensesSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvExpensesSheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.ExpenseTypeID,
            this.colName,
            this.colText,
            this.colLocation,
            this.colQuantity,
            this.colValue,
            this.colTotal,
            this.btnEdit,
            this.btnDelete});
            this.gvExpensesSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvExpensesSheet.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gvExpensesSheet.Location = new System.Drawing.Point(3, 98);
            this.gvExpensesSheet.MultiSelect = false;
            this.gvExpensesSheet.Name = "gvExpensesSheet";
            this.gvExpensesSheet.ReadOnly = true;
            this.gvExpensesSheet.RowHeadersVisible = false;
            this.gvExpensesSheet.ShowEditingIcon = false;
            this.gvExpensesSheet.Size = new System.Drawing.Size(776, 300);
            this.gvExpensesSheet.TabIndex = 7;
            this.gvExpensesSheet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvExpensesSheet_CellContentClick);
            this.gvExpensesSheet.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.gvExpensesSheet_CellFormatting);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.FillWeight = 2F;
            this.ID.HeaderText = "";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // ExpenseTypeID
            // 
            this.ExpenseTypeID.DataPropertyName = "ExpenseTypeID";
            this.ExpenseTypeID.FillWeight = 2F;
            this.ExpenseTypeID.HeaderText = "";
            this.ExpenseTypeID.Name = "ExpenseTypeID";
            this.ExpenseTypeID.ReadOnly = true;
            this.ExpenseTypeID.Visible = false;
            // 
            // colName
            // 
            this.colName.DataPropertyName = "ExpenseTypeName";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colName.DefaultCellStyle = dataGridViewCellStyle6;
            this.colName.FillWeight = 45.33279F;
            this.colName.HeaderText = "Name";
            this.colName.Name = "colName";
            this.colName.ReadOnly = true;
            // 
            // colText
            // 
            this.colText.DataPropertyName = "Description";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.colText.DefaultCellStyle = dataGridViewCellStyle7;
            this.colText.FillWeight = 52.55561F;
            this.colText.HeaderText = "Text";
            this.colText.Name = "colText";
            this.colText.ReadOnly = true;
            // 
            // colLocation
            // 
            this.colLocation.DataPropertyName = "LocationName";
            this.colLocation.FillWeight = 35.51892F;
            this.colLocation.HeaderText = "Location";
            this.colLocation.Name = "colLocation";
            this.colLocation.ReadOnly = true;
            // 
            // colQuantity
            // 
            this.colQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "F2";
            this.colQuantity.DefaultCellStyle = dataGridViewCellStyle8;
            this.colQuantity.FillWeight = 15.68983F;
            this.colQuantity.HeaderText = "Quantity";
            this.colQuantity.Name = "colQuantity";
            this.colQuantity.ReadOnly = true;
            // 
            // colValue
            // 
            this.colValue.DataPropertyName = "Value";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "F2";
            this.colValue.DefaultCellStyle = dataGridViewCellStyle9;
            this.colValue.FillWeight = 17.27802F;
            this.colValue.HeaderText = "Value";
            this.colValue.Name = "colValue";
            this.colValue.ReadOnly = true;
            // 
            // colTotal
            // 
            this.colTotal.DataPropertyName = "Total";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "F2";
            this.colTotal.DefaultCellStyle = dataGridViewCellStyle10;
            this.colTotal.FillWeight = 19.04568F;
            this.colTotal.HeaderText = "Total";
            this.colTotal.Name = "colTotal";
            this.colTotal.ReadOnly = true;
            // 
            // btnEdit
            // 
            this.btnEdit.FillWeight = 17.8279F;
            this.btnEdit.HeaderText = "";
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.ReadOnly = true;
            this.btnEdit.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.btnEdit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseColumnTextForButtonValue = true;
            // 
            // btnDelete
            // 
            this.btnDelete.FillWeight = 16.75127F;
            this.btnDelete.HeaderText = "";
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.ReadOnly = true;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseColumnTextForButtonValue = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnAddExpense);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 404);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(776, 32);
            this.panel2.TabIndex = 8;
            // 
            // btnAddExpense
            // 
            this.btnAddExpense.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnAddExpense.AutoSize = true;
            this.btnAddExpense.Location = new System.Drawing.Point(3, 5);
            this.btnAddExpense.Name = "btnAddExpense";
            this.btnAddExpense.Size = new System.Drawing.Size(103, 23);
            this.btnAddExpense.TabIndex = 3;
            this.btnAddExpense.Text = "Add expenses";
            this.btnAddExpense.UseVisualStyleBackColor = true;
            this.btnAddExpense.Click += new System.EventHandler(this.btnAddExpense_Click);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.lblExpenseTotalValue);
            this.panel4.Controls.Add(this.lblExpenseTotal);
            this.panel4.Location = new System.Drawing.Point(496, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(277, 21);
            this.panel4.TabIndex = 0;
            // 
            // lblExpenseTotalValue
            // 
            this.lblExpenseTotalValue.AutoSize = true;
            this.lblExpenseTotalValue.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblExpenseTotalValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenseTotalValue.Location = new System.Drawing.Point(242, 0);
            this.lblExpenseTotalValue.Name = "lblExpenseTotalValue";
            this.lblExpenseTotalValue.Padding = new System.Windows.Forms.Padding(0, 2, 5, 0);
            this.lblExpenseTotalValue.Size = new System.Drawing.Size(33, 15);
            this.lblExpenseTotalValue.TabIndex = 1;
            this.lblExpenseTotalValue.Text = "0.00";
            this.lblExpenseTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExpenseTotal
            // 
            this.lblExpenseTotal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lblExpenseTotal.AutoSize = true;
            this.lblExpenseTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpenseTotal.Location = new System.Drawing.Point(5, 2);
            this.lblExpenseTotal.Name = "lblExpenseTotal";
            this.lblExpenseTotal.Size = new System.Drawing.Size(71, 13);
            this.lblExpenseTotal.TabIndex = 0;
            this.lblExpenseTotal.Text = "Expense total";
            this.lblExpenseTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TimeEntryAdvanced
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(796, 560);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tableLayoutAdvanced);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TimeEntryAdvanced";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Time Entry - Advanced";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TimeEntryAdvanced_FormClosed);
            this.Load += new System.EventHandler(this.TimeEntryAdvanced_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TimeEntryAdvanced_MouseMove);
            this.panel1.ResumeLayout(false);
            this.tableLayoutAdvanced.ResumeLayout(false);
            this.tbpAdvanced.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.grpMessage.ResumeLayout(false);
            this.grpMessage.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpAdvancedAttributes.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tbpExpenses.ResumeLayout(false);
            this.tableLayoutExpense.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnlExpenseStatus.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvExpensesSheet)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox grpMessage;
        private System.Windows.Forms.TextBox txtNewResponse;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPreviousResponses;
        private System.Windows.Forms.GroupBox grpAdvancedAttributes;
        SuggestComboBox cmbActivities;
        SuggestComboBox cmbProjects;
        private System.Windows.Forms.Label lblProject;
        private System.Windows.Forms.Label lblActivity;
        private System.Windows.Forms.ComboBox cmbTasks;
        private System.Windows.Forms.Label lblTask;
        private System.Windows.Forms.ComboBox cmbContacts;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabControl tableLayoutAdvanced;
        private System.Windows.Forms.TabPage tbpAdvanced;
        private System.Windows.Forms.TabPage tbpExpenses;
        private System.Windows.Forms.Label lblFavorites;
        private SuggestComboBox cmbFavorites;
        private System.Windows.Forms.CheckBox cbOutOfOffice;
        private System.Windows.Forms.Label lblLocation;
        private SuggestComboBox cbxLocation;
        private System.Windows.Forms.DateTimePicker dtStartDate;
        private System.Windows.Forms.TextBox txtDuration;
        private System.Windows.Forms.Label lblDuration;
        private System.Windows.Forms.Label lblStartTime;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.DateTimePicker dtStartTime;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblOrganization;
        private SuggestComboBox cmbOrganizations;
        private System.Windows.Forms.TableLayoutPanel tableLayoutExpense;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblExpAct;
        private SuggestComboBox cbbExpenseActivity;
        private SuggestComboBox cbbExpenseOrganization;
        private System.Windows.Forms.ComboBox cbbExpenseContact;
        private SuggestComboBox cbbExpenseProject;
        private System.Windows.Forms.Label lblExpProj;
        private System.Windows.Forms.Label lblExpOrg;
        private System.Windows.Forms.Label lblExpCnt;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnSaveExpenses;
        private System.Windows.Forms.Button btnSubmitExpenses;
        private System.Windows.Forms.Panel pnlExpenseStatus;
        private System.Windows.Forms.Label lblExpenseSheetStatus;
        private DataGridViewTSR gvExpensesSheet;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnAddExpense;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblExpenseTotalValue;
        private System.Windows.Forms.Label lblExpenseTotal;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseTypeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colText;
        private System.Windows.Forms.DataGridViewTextBoxColumn colLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn colValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotal;
        private System.Windows.Forms.DataGridViewButtonColumn btnEdit;
        private System.Windows.Forms.DataGridViewButtonColumn btnDelete;
    }
}