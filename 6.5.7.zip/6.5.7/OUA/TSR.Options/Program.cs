﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using Microsoft.Win32;

namespace TSR.Options
{
    class Program
    {
        private const string OUAOptionsLocation_2007 = "Timesheet Reporter";
        private const string OUAOptionsLocation_2010 = "Timesheet Reporter";
        private static string OUAOptionsLocationRoot = @"Software";
        private const string CONST_OPTION_OPENMODE = "OpenMode";
        private const string CONST_OPTION_OPENMODE_VALUE_DEFAULT = "0";
        private const string CONST_OPTION_OPENMODE_VALUE_SETTINGSWINDOW = "1";

        public const string OUA2007 = "TSR_OL2007";
        public const string OUA2010 = "TSR_OL2010";

        static void Main()
        {
            if (IsProcessRunning("outlook"))
                return;

            OUAOptionsLocationRoot = GetCurrentUserSID() + @"\Software";

            writeReg(OUA2010);

            Process.Start("outlook.exe");

            System.Environment.Exit(0);
        }

        static void writeReg(string addinName)
        {
            RegistryKey softwareKey = null;
            RegistryKey tsrOptionKey = null;
            try
            {
                //Store private user name and password
                softwareKey = Registry.CurrentUser.OpenSubKey(OUAOptionsLocationRoot, true);
                if (softwareKey != null)
                {
                    if (addinName == OUA2010)
                    {
                        tsrOptionKey = softwareKey.OpenSubKey(OUAOptionsLocation_2010, true);
                    }
                    else if (addinName == OUA2007)
                    {
                        tsrOptionKey = softwareKey.OpenSubKey(OUAOptionsLocation_2007, true);
                    }
                    if (tsrOptionKey != null)
                    {
                        tsrOptionKey.SetValue(CONST_OPTION_OPENMODE, CONST_OPTION_OPENMODE_VALUE_SETTINGSWINDOW);
                    }
                }
            }
            catch
            {

            }
            finally
            {
                if (tsrOptionKey != null)
                    tsrOptionKey.Close();
                if (softwareKey != null)
                    softwareKey.Close();
            }
        }

        static bool IsProcessRunning(string name)
        {
            foreach (Process clsProcess in Process.GetProcesses())
            {
                if (clsProcess.ProcessName.ToLower().Contains(name))
                {
                    return true;
                }
            }
            return false;
        }

        static string GetCurrentUserSID()
        {
            string sid = string.Empty;
            System.Security.Principal.WindowsIdentity wi = System.Security.Principal.WindowsIdentity.GetCurrent();
            if (wi != null && wi.User != null)
                sid = wi.User.Value;
            return sid;
        }
    }
}
