using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Globalization;
using TSR.Core.Entity;

namespace TSR.Core
{
    /// <summary>
    /// Class
    /// Name: ResourceManager
    /// Description: This class is a static Class 
    /// handles some static properties & functions to manage resources.
    /// </summary>
    public class ResourceManager
    {
        /// <summary>
        /// retrieves resource from local storage, if a key with default value is passed, will search in local storage
        /// if found, will be returned that value Otherwise, default value will be returned
        /// </summary>
        /// <param name="key"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static string GetResourceString(string key, string defaultValue)
        {
            XMLResourceManager xmlrm = new XMLResourceManager();
            //string value = xmlrm.GetString(key,GetCurrentLanguageName());//(key, GetPrefferedCI());
            LanguageResources res = TSRFacade.GetLanguageResourcesByLanguageNameAndResourceKey(GetCurrentLanguageName(), key);
            if (string.IsNullOrEmpty(res.LanguageID))
            {
//#if(DEBUG)
//                LanguageResources lr = new LanguageResources(Constants.DEFAULT_CULTURE_LCID, Constants.DEFAULT_LANGUAGE_NAME, key, defaultValue);
//                TSR.Core.TSRFacade.UpdateLanguageResources(lr);

//#else
                    if (GetPrefferedCI().TwoLetterISOLanguageName.Equals(Constants.DEFAULT_CULTURE_LCID) )
                    {
                        LanguageResources lr = new LanguageResources(GetPrefferedCI().TwoLetterISOLanguageName, Constants.DEFAULT_LANGUAGE_NAME, key, defaultValue);
                        TSR.Core.TSRFacade.UpdateLanguageResources(lr);
                    }
//#endif
                return defaultValue;
            }
            return res.ResourceValue;
        }

        /// <summary>
        /// current culture info is returned, utility method
        /// </summary>
        /// <returns></returns>
        private static CultureInfo GetPrefferedCI()
        {
            if (Thread.CurrentThread.CurrentUICulture != null)
            {
                return Thread.CurrentThread.CurrentUICulture;
            }
            return new CultureInfo(Constants.DEFAULT_CULTURE_INFO_NAME);
        }

        public static string GetCurrentLanguageName()
        {
            if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRLanguageName))
            {
                String[] array = TSR.Core.SettingsHelper.TSRLanguageName.Split( new Char[]{Constants.DEFAULT_SEPERATOR_LANGUAGENAME_LANGUAGEID},StringSplitOptions.RemoveEmptyEntries);
                return array[0];
            }
            return Constants.DEFAULT_LANGUAGE_NAME;
        }

    }
}
