﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO.IsolatedStorage;
using System.IO;

namespace TSR.Core.Logging
{
    #region RollingFileLoggingHandler
    /// Class
    /// Name: RollingFileLoggingHandler
    /// Description: This is a custom Rolling File Tracer which inherits from Text Writer Trace Listener.
    /// The class store Log entity into Rolling File.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public class RollingFileLoggingHandler : TextWriterTraceListener
    {
        #region Constructors
        public RollingFileLoggingHandler()
            : base()
        {
        }

        public RollingFileLoggingHandler(Stream stream)
            : base(stream)
        {
        }

        public RollingFileLoggingHandler(string path)
            : base(path)
        {
        }

        public RollingFileLoggingHandler(TextWriter writer)
            : base(writer)
        {
        }

        public RollingFileLoggingHandler(Stream stream, string name)
            : base(stream, name)
        {
        }

        public RollingFileLoggingHandler(string path, string name)
            : base(path, name)
        {
        }

        public RollingFileLoggingHandler(TextWriter writer, string name)
            : base(writer, name)
        {
        }
        #endregion

        #region Methods
        /// <summary>
        /// Override Write Line method
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="message"></param>
        public override void WriteLine(string message)
        {
            base.Write(DateTime.Now.ToString());
            base.Write(" ");
            base.WriteLine(message);
        }
        public override void WriteLine(object obj)
        {
            base.WriteLine("--------Start Logging------------------");
            base.WriteLine(DateTime.Now.ToString());
            base.WriteLine("---------------------------------------");
            base.WriteLine(obj.ToString());
            base.WriteLine("--------End Logging------------------");
        }
        #endregion
    }
    #endregion

    #region RollingFileStream
    // Class
    /// Name: RollingFileLoggingHandler
    /// Description: This is a custom Rolling File Stream which inherits from File Stream class.
    /// The class contains common perperties and methods to read, write, append rolling file.
    /// 
    /// Last updated on:
    /// September 05, 2009
    /// Change description:
    /// </summary>
    public sealed class RollingFileStream : IsolatedStorageFileStream
    {
        #region Constructors
        public RollingFileStream(string path, long maxFileLength, int maxFileCount, FileMode mode)
            : base(path, BaseFileMode(mode), FileAccess.Write, Storage)
        {
            Init(path, maxFileLength, maxFileCount, mode);
        }

        public RollingFileStream(string path, long maxFileLength, int maxFileCount, FileMode mode, FileShare share)
            : base(path, BaseFileMode(mode), FileAccess.Write, share, Storage)
        {
            Init(path, maxFileLength, maxFileCount, mode);
        }

        public RollingFileStream(string path, long maxFileLength, int maxFileCount, FileMode mode, FileShare share, int bufferSize)
            : base(path, BaseFileMode(mode), FileAccess.Write, share, bufferSize, Storage)
        {
            Init(path, maxFileLength, maxFileCount, mode);
        }

        //public RollingFileStream(string path, long maxFileLength, int maxFileCount, FileMode mode, FileShare share, int bufferSize, bool isAsync)
        //    : base(path, BaseFileMode(mode), FileAccess.Write, share, bufferSize, isAsync)
        //{
        //    Init(path, maxFileLength, maxFileCount, mode);
        //}
        #endregion

        #region Properties
        public override bool CanRead { get { return false; } }
        public long MaxFileLength { get { return m_maxFileLength; } }
        public int MaxFileCount { get { return m_maxFileCount; } }
        public bool CanSplitData { get { return m_canSplitData; } set { m_canSplitData = value; } }
        public static IsolatedStorageFile Storage
        {
            get
            {
                IsolatedStorageFile store = IsolatedStorageFile.GetUserStoreForAssembly();
                store.CreateDirectory("TSRLog");
                return store;
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// Initialize the Rolling File Stream object by passing 
        /// path, maxFileLength, maxFileCount and mode parameters
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="path">String type</param>
        /// <param name="maxFileLength">Int64 type</param>
        /// <param name="maxFileCount">Int32</param>
        /// <param name="mode">FileMode type</param>
        private void Init(string path, long maxFileLength, int maxFileCount, FileMode mode)
        {
            if (maxFileLength <= 0)
                throw new ArgumentOutOfRangeException("Invalid maximum file length");
            if (maxFileCount <= 0)
                throw new ArgumentOutOfRangeException("Invalid maximum file count");

            m_maxFileLength = maxFileLength;
            m_maxFileCount = maxFileCount;
            m_canSplitData = true;

            string fullPath = Path.GetFullPath(path);
            m_fileDir = Path.GetDirectoryName(fullPath);
            m_fileBase = Path.GetFileNameWithoutExtension(fullPath);
            m_fileExt = Path.GetExtension(fullPath);

            m_fileDecimals = 1;
            int decimalBase = 10;
            while (decimalBase < m_maxFileCount)
            {
                ++m_fileDecimals;
                decimalBase *= 10;
            }

            switch (mode)
            {
                case FileMode.Create:
                case FileMode.CreateNew:
                case FileMode.Truncate:
                    // Delete old files
                    for (int iFile = 0; iFile < m_maxFileCount; ++iFile)
                    {
                        string file = GetBackupFileName(iFile);
                        if (File.Exists(file))
                            File.Delete(file);
                    }
                    break;

                default:
                    // Position file pointer to the last backup file
                    for (int iFile = 0; iFile < m_maxFileCount; ++iFile)
                    {
                        if (File.Exists(GetBackupFileName(iFile)))
                            m_nextFileIndex = iFile + 1;
                    }
                    if (m_nextFileIndex == m_maxFileCount)
                        m_nextFileIndex = 0;
                    Seek(0, SeekOrigin.End);
                    break;
            }
        }

        /// <summary>
        /// Backup and Reset Stream method
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        private void BackupAndResetStream()
        {
            Flush();
            File.Copy(Name, GetBackupFileName(m_nextFileIndex), true);
            SetLength(0);

            ++m_nextFileIndex;
            if (m_nextFileIndex >= m_maxFileCount)
                m_nextFileIndex = 0;
        }

        /// <summary>
        /// Get Backup file name by passing index parameter
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        private string GetBackupFileName(int index)
        {
            StringBuilder format = new StringBuilder();
            format.AppendFormat("D{0}", m_fileDecimals);
            StringBuilder sb = new StringBuilder();
            if (m_fileExt.Length > 0)
                sb.AppendFormat("{0}{1}{2}", m_fileBase, index.ToString(format.ToString()), m_fileExt);
            else
                sb.AppendFormat("{0}{1}", m_fileBase, index.ToString(format.ToString()));
            return Path.Combine(m_fileDir, sb.ToString());
        }

        private static FileMode BaseFileMode(FileMode mode)
        {
            return mode == FileMode.Append ? FileMode.OpenOrCreate : mode;
        }

        /// <summary>
        /// override Write method
        /// 
        /// Last updated on:
        /// September 05, 2009
        /// Change description:
        /// </summary>
        /// <param name="array"></param>
        /// <param name="offset"></param>
        /// <param name="count"></param>
        public override void Write(byte[] array, int offset, int count)
        {
            int actualCount = System.Math.Min(count, array.GetLength(0));
            if (Position + actualCount <= m_maxFileLength)
            {
                base.Write(array, offset, count);
            }
            else
            {
                if (CanSplitData)
                {
                    int partialCount = (int)(System.Math.Max(m_maxFileLength, Position) - Position);
                    base.Write(array, offset, partialCount);
                    offset += partialCount;
                    count = actualCount - partialCount;
                }
                else
                {
                    if (count > m_maxFileLength)
                        throw new ArgumentOutOfRangeException("Buffer size exceeds maximum file length");
                }
                BackupAndResetStream();
                Write(array, offset, count);
            }
        }
        #endregion

        #region Variables
        private long m_maxFileLength;
        private int m_maxFileCount;
        private string m_fileDir;
        private string m_fileBase;
        private string m_fileExt;
        private int m_fileDecimals;
        private bool m_canSplitData;
        private int m_nextFileIndex;
        #endregion
    }
    #endregion
}
