﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using TSR.Core.Entity;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace TSR.Core
{
    public class AppointmentRetriever
    {
        #region
        
        private const int MAX_NUM_DAYS = 20;
        private const int MAX_NUM_RECORDS = 5;
        #endregion

        #region Private shared variables

        //private Form _settings;
        private TimeEntryList _timeEntryList = new TimeEntryList();
        private BackgroundWorker _worker;
        private static AppointmentRetriever appRetriever;
        private DateTime _start;
        private DateTime _end;
        private string _subject;
        private List<Int64> _lstOrganizationID;
        private List<Int64> _lstProjectID;
        private List<Int64> _lstActivityID;
        
        #endregion

        #region Message Structure for progress change event

        public struct SyncMessage
        {
            public string Message;
            public SyncStatus Status;
            public TimeEntryList UpdatedTimeEntries;
        }

        public enum SyncStatus
        {
            Undefined,
            Normal,
            Error,
            Completed,
            CompletedWithErrors
        };

        #endregion

        #region Progress change events [to use from outside]

        public delegate void SynchronizationProgressChanged(object sender, ProgressChangedEventArgs e);
        public event SynchronizationProgressChanged ProgressChanged;

        public delegate void SynchronizationCompleted(object sender, RunWorkerCompletedEventArgs e);
        public event SynchronizationCompleted Completed;

        #endregion

        #region Singleton methods

        public static AppointmentRetriever GetInstance()
        {
            if (appRetriever == null)
            {
                appRetriever = new AppointmentRetriever();
                return appRetriever;
            }
            else
            {
                return null;
            }
        }

        public static AppointmentRetriever NewInstance()
        {
            appRetriever = null;
            appRetriever = new AppointmentRetriever();
            return appRetriever;
        }
        //public static AppointmentRetriever GetInstance()
        //{
        //    return GetInstance(null);
        //}

        private AppointmentRetriever()
        {
            InitializeSynchronizationBackgroundWorker();
        }

        #endregion

        #region Threading methods

        /// <summary>
        /// Initializes background thread
        /// </summary>
        private void InitializeSynchronizationBackgroundWorker()
        {
            _worker = new BackgroundWorker();
            _worker.WorkerReportsProgress = true;
            //worker.WorkerSupportsCancellation = true;
            _worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            _worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);
            _worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
        }
                
        /// <summary>
        /// starts synchronization in background thread
        /// </summary>
        public void StartSynchornization(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
     DateTime start, DateTime end)
        {
            _subject = subject;
            _lstOrganizationID = lstOrganizationID;
            _lstProjectID = lstProjectID;
            _lstActivityID = lstActivityID;

            _start = start;
            _end = end;
            _worker.RunWorkerAsync();
        }

        /// <summary>
        /// event, when background thread starts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = sender as BackgroundWorker;
            if (bw != null)
            {
                RetrieveTimeEntries(bw);
            }
        }

        /// <summary>
        /// event when a status is changed in thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.UserState != null)
            {
                Core.AppointmentRetriever.SyncMessage progressMessage = (Core.AppointmentRetriever.SyncMessage)e.UserState;

                switch (progressMessage.Status)
                {
                    case Core.AppointmentRetriever.SyncStatus.Completed:
                        break;
                }

                if (ProgressChanged != null)
                {
                    ProgressChanged(sender, e);
                }
            }
        }

        /// <summary>
        /// background thread's task is done
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (Completed != null)
            {
                Completed(sender, e);
            }
            appRetriever = null;
        }

        #endregion

        #region Synchronization Methods

        /// <summary>
        /// main method which centrally calls all other methods to call the necessary services
        /// </summary>
        /// <param name="bgWorker"></param>
        private void RetrieveTimeEntries(BackgroundWorker bgWorker)
        {
            try
            {
                updateUnchangedRecurringOccurrences(_subject, _lstOrganizationID, _lstProjectID, _lstActivityID, _start, _end, bgWorker);
                ReportBackgroundThreadMessage(bgWorker, string.Empty, SyncStatus.Completed, null);
            }
            catch(Exception ex)
            { 
                Logging.LoggingHandler.LogUnhandledException(ex);
                ReportBackgroundThreadMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, _timeEntryList);//report to user that process is done
            }
        }


        /// <summary>
        /// Method to retrieve tsr entries which were not actually inserted in data store, these will be generated on the fly for
        /// view. but, if saved or changed from here, these will be saved
        /// </summary>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <returns></returns>
        private void updateUnchangedRecurringOccurrences(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
     DateTime start, DateTime end, BackgroundWorker bgWorker)
        {
            //List<Outlook.AppointmentItem> appList = getRecurringAppointmentsWithInaTimeRange(startTime, endTime);
            addTimeEntriesOnTheFlyForUnsavedRecurringEntries(subject, lstOrganizationID, lstProjectID, lstActivityID, start, end, bgWorker);//method call to retrieve time entries on the fly

        }

        /// <summary>
        /// this method generated time entries on the fly, which were never stored locally, and user did not
        /// create these entries one by one, these were created as part of recurring appointment, but
        /// as these were not changed specifically, all of these will be generated on the fly for viewing, and will
        /// be saved only if user individually opens an appointment and saves it
        /// </summary>
        /// <param name="teList"></param>
        /// <param name="AppList"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        private void addTimeEntriesOnTheFlyForUnsavedRecurringEntries(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
    DateTime start, DateTime end, BackgroundWorker bgWorker)
        {
            //foreach (Outlook.AppointmentItem oAppt in AppList)
            //{
            TimeEntryList teList = new TimeEntryList();
            List<RecurringMaster> recurringMasters = Core.TSRFacade.GetRecurringMastersByAllParams(subject,lstOrganizationID, lstProjectID, lstActivityID, start, end);


            foreach (RecurringMaster rm in recurringMasters)
            {
                //Outlook.AppointmentItem oAppt = OutlookHelper.GetAppointmentItemByEntryID(rm.ID);
                Outlook.AppointmentItem oAppt = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(rm.ID);
                DateTime startTime, endTime;
                if (oAppt != null)
                {
                    //RecurringMaster rm = Core.TSRFacade.GetRecurringMasterByOutlookEntryID(oAppt.EntryID);
                    //if (rm != null)
                    //{
                    Microsoft.Office.Interop.Outlook.RecurrencePattern recurrPattern = null;
                    try
                    {
                        recurrPattern = oAppt.GetRecurrencePattern();
                    }
                    catch //(Exception ex)
                    {
                        //TSR.Core.Logging.LoggingHandler.LogError(ex);
                        continue;
                    }
                    if (recurrPattern == null)
                        continue;
                    if (recurrPattern.PatternStartDate > start)
                        startTime = recurrPattern.PatternStartDate;
                    else
                        startTime = start;
                    if (recurrPattern.PatternEndDate < end)
                        endTime = recurrPattern.PatternEndDate.AddDays(1);
                    else
                        endTime = end;
                    //oAppt.GetRecurrencePattern().
                    DateTime date = startTime;
                    int counter = 0;
                    while (date < endTime) // this huge loop can be changed by retrieving information from recurrence pattern
                    {
                        date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);                        
                        Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence = null;
                        try
                        {                            
                            bool isException = false;
                            if (recurrPattern != null)
                            {
                                if(recurrPattern.Exceptions != null)
                                    foreach (Microsoft.Office.Interop.Outlook.Exception exceptionRecurrence in recurrPattern.Exceptions)
                                    {
                                        try
                                        {
                                            if (exceptionRecurrence.AppointmentItem.Start.Date.Equals(date.Date))
                                            {
                                                isException = true;
                                                break;
                                            }
                                        }
                                        catch //(Exception ex)
                                        {
                                            //TSR.Core.Logging.LoggingHandler.LogError(ex);
                                        }
                                    }
                                if (!isException)
                                    appointmentOccurrence = recurrPattern.GetOccurrence(date);
                            }
                            if (appointmentOccurrence != null)
                            {
                                //get list of recurring entries including deleted ones, if even a deleted one exists, we dont want to list it
                                TimeEntry te = Core.TSRFacade.GetTimeEntryForRecurringAppointment(oAppt.EntryID, appointmentOccurrence.Start, appointmentOccurrence.End, false, true);
                                if (te == null)
                                {
                                    te = new TimeEntry(Guid.NewGuid(), appointmentOccurrence);
                                    te.Subject = rm.Subject;
                                    te.Body = rm.Body;
                                    te.Location = rm.Location;

                                    te.OrganizationID = rm.OrganizationID;
                                    te.ProjectID = rm.ProjectID;
                                    te.ActivityID = rm.ActivityID;
                                    //date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);
                                    te.StartTimeStamp = appointmentOccurrence.Start;
                                    te.EndTimeStamp = appointmentOccurrence.End;//new DateTime(date.Year, date.Month, date.Day, oAppt.End.Hour, oAppt.End.Minute, oAppt.End.Second);//oAppt.End;

                                    te.Organization = Core.TSRFacade.GetOrganizationByID(rm.OrganizationID);
                                    te.Project = Core.TSRFacade.GetProjectByID(rm.ProjectID);
                                    te.Activity = Core.TSRFacade.GetActivityByID(rm.ActivityID);
                                    te.IsRecurring = true;

                                    //Add information about link
                                    if (OutlookHelper.UserSelectedAppointmentFolderForSync != null && TSRFacade.GetExchangeMode())
                                        te.CalendarID = OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID;

                                    teList.Add(te);
                                    counter++;
                                }                               
                            }                         
                        }
                        catch //(Exception ex)
                        {
                            //TSR.Core.Logging.LoggingHandler.LogError(ex);
                        }
                        //if (recurrPattern != null && (appointmentOccurrence != null))
                        //{
                        //    switch (recurrPattern.RecurrenceType)
                        //    {
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursDaily:
                        //            date = date.AddDays(1);
                        //            break;
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursMonthly:
                        //            date = date.AddMonths(1);
                        //            break;
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursMonthNth:
                        //            date = date.AddMonths(recurrPattern.Interval);
                        //            break;
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursWeekly:
                        //            date = date.AddDays(7);
                        //            break;
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursYearly:
                        //            date = date.AddYears(1);
                        //            break;
                        //        case Microsoft.Office.Interop.Outlook.OlRecurrenceType.olRecursYearNth:
                        //            date = date.AddYears(recurrPattern.Interval);
                        //            break;
                        //        default: break;
                        //    }                                                                                        
                        //}
                        //else
                            date = date.AddDays(1);
                        
                        //every time count of days are more than maximum, send the time entries in a chunk
                        //if (counter >= MAX_NUM_RECORDS)
                        //{
                        //    counter = 0;                            
                        //    ReportBackgroundThreadMessage(bgWorker, string.Empty, SyncStatus.Normal, teList);
                        //    teList = new TimeEntryList();                            
                        //}
                    }
                    //it was less than maximum number of time entries found, so this was not sent yet. send these now..
                    //if (counter < MAX_NUM_RECORDS && counter > 0)
                    //{                        
                    //    ReportBackgroundThreadMessage(bgWorker, string.Empty, SyncStatus.Normal, teList);
                    //    teList = new TimeEntryList();
                    //}                    
                    //}
                    recurrPattern = null;
                }                
            }
            ReportBackgroundThreadMessage(bgWorker, string.Empty, SyncStatus.Normal, teList);
            //}

        }

        //private List<Outlook.AppointmentItem> getRecurringAppointmentsWithInaTimeRange(DateTime startTime, DateTime endTime)
        //{
        //    List<Outlook.AppointmentItem> appList = new List<Outlook.AppointmentItem>();

        //    Outlook.MAPIFolder oCalendar = OutlookHelper.CurrentApplication.Session.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderCalendar);

        //    Outlook.Items oItems = (Outlook.Items)oCalendar.Items;

        //    oItems.Sort("[Start]", false);

        //    oItems.IncludeRecurrences = true;

        //    //string sCriteria = (@"[End] >= " + Quote("May 16, 2009 12:00 AM") + " AND [Start] < " + Quote("May 30, 2009 12:00 AM"));

        //    string sCriteria = "[Start] <= '" + endTime + "' " +
        //              "And [End] > '" + startTime + "'";

        //    Outlook.Items oRestrictedItems = oItems.Restrict(sCriteria);

        //    oRestrictedItems.Sort("[Start]", true);

        //    oRestrictedItems.IncludeRecurrences = true;



        //    Outlook.AppointmentItem oAppt;

        //    oAppt = (Outlook.AppointmentItem)oRestrictedItems.GetFirst();
        //    //for each appointment if it is recurring.. add it to list
        //    while (oAppt != null)
        //    {
        //        if (oAppt.IsRecurring)
        //            appList.Add(oAppt);

        //        oAppt = (Outlook.AppointmentItem)oRestrictedItems.FindNext();
        //    }
        //    return appList;
        //}
        ///// <summary>
        ///// this method generated time entries on the fly, which were never stored locally, and user did not
        ///// create these entries one by one, these were created as part of recurring appointment, but
        ///// as these were not changed specifically, all of these will be generated on the fly for viewing, and will
        ///// be saved only if user individually opens an appointment and saves it
        ///// </summary>
        ///// <param name="teList"></param>
        ///// <param name="AppList"></param>
        ///// <param name="start"></param>
        ///// <param name="end"></param>
        //private void addTimeEntriesOnTheFlyForUnsavedRecurringEntries(List<Outlook.AppointmentItem> AppList, DateTime start, DateTime end, BackgroundWorker bgWorker)
        //{
        //    TimeEntryList teList = new TimeEntryList();
            
            
        //    foreach (Outlook.AppointmentItem oAppt in AppList)
        //    {
        //        RecurringMaster rm = Core.TSRFacade.GetRecurringMasterByOutlookEntryID(oAppt.EntryID);
        //        if (rm != null)
        //        {
        //            if (oAppt.GetRecurrencePattern().PatternStartDate > start)
        //                start = oAppt.GetRecurrencePattern().PatternStartDate;
        //            if (oAppt.GetRecurrencePattern().PatternEndDate < end)
        //                end = oAppt.GetRecurrencePattern().PatternEndDate.AddDays(1);
        //            //oAppt.GetRecurrencePattern().
        //            int counter = 0;
        //            DateTime date = start;
        //            while (date <= end) // this huge loop can be changed by retrieving information from recurrence pattern
        //            {
        //                date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);
        //                try
        //                {

        //                    Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence = oAppt.GetRecurrencePattern().GetOccurrence(date);

        //                    if (appointmentOccurrence != null)
        //                    {
        //                        //get list of recurring entries including deleted ones, if even a deleted one exists, we dont want to list it
        //                        TimeEntry te = Core.TSRFacade.GetTimeEntryForRecurringAppointment(oAppt.EntryID, appointmentOccurrence.Start, appointmentOccurrence.End, false, true);
        //                        if (te == null)
        //                        {
        //                            te = new TimeEntry(new Guid(), appointmentOccurrence);
        //                            te.Subject = rm.Subject;
        //                            te.Body = rm.Body;
        //                            te.OrganizationID = rm.OrganizationID;
        //                            te.ProjectID = rm.ProjectID;
        //                            te.ActivityID = rm.ActivityID;
        //                            //date = new DateTime(date.Year, date.Month, date.Day, oAppt.Start.Hour, oAppt.Start.Minute, oAppt.Start.Second);
        //                            te.StartTimeStamp = appointmentOccurrence.Start;
        //                            te.EndTimeStamp = appointmentOccurrence.End;//new DateTime(date.Year, date.Month, date.Day, oAppt.End.Hour, oAppt.End.Minute, oAppt.End.Second);//oAppt.End;

        //                            te.Organization = Core.TSRFacade.GetOrganizationByID(rm.OrganizationID);
        //                            te.Project = Core.TSRFacade.GetProjectByID(rm.ProjectID);
        //                            te.Activity = Core.TSRFacade.GetActivityByID(rm.ActivityID);
        //                            te.IsRecurring = true;
        //                            teList.Add(te);
        //                        }
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    TSR.Core.Logging.LoggingHandler.LogError(ex);
        //                }
        //                date = date.AddDays(1);
        //                counter++;
        //                if (counter > 20)
        //                {
        //                    counter = 0;
        //                    if (teList.Count > 0)
        //                    {
        //                        ReportSyncMessage(bgWorker, string.Empty, SyncStatus.Normal, teList);
        //                        //teList = new TimeEntryList();
        //                    }
        //                }
        //            }
        //        }
        //    }

        //}

        /// <summary>
        /// send a message to the user of the class
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <param name="te"></param>
        private void ReportBackgroundThreadMessage(BackgroundWorker bgWorker, string message, SyncStatus status, TimeEntryList te)
        {
            SyncMessage syncMessage = new SyncMessage();
            syncMessage.Message = message;
            syncMessage.Status = status;
            //syncMessage.UpdatedTimeEntries = te;
            if (syncMessage.UpdatedTimeEntries == null)
                syncMessage.UpdatedTimeEntries = new TimeEntryList();
            if (te != null)
                syncMessage.UpdatedTimeEntries.PushTimeEntry(te);
            if (bgWorker != null)
                bgWorker.ReportProgress(-1, syncMessage);
        }

        

        #endregion
    }
}
