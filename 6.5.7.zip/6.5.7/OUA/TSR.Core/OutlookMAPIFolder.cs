using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core
{
    /// <summary>
    /// Outlook Mapi folder's values are stored in this class
    /// </summary>
    public class OutlookMAPIFolder
    {
        private string _FolderName;
        private string _EntryID;
        private string _FolderPath;
        private string _FolderFullPath;
        private string _StoreID;

        public string EntryID
        {
            get { return _EntryID; }
            set { _EntryID = value; }
        }

        public string StoreID
        {
            get { return _StoreID; }
            set { _StoreID = value; }
        }

        public string FolderPath
        {
            get { return _FolderPath; }
            set { _FolderPath = value; }
        }

        public string FolderFullPath
        {
            get { return _FolderFullPath; }
            set { _FolderFullPath = value; }
        }

        public string FolderName
        {
            get { return _FolderName; }
            set { _FolderName = value; }
        }
    }

    /// <summary>
    /// list of Outlook MapiFolder objects
    /// </summary>
    public class OutlookMAPIFolderList : IList
    {
        ArrayList list;

        public OutlookMAPIFolderList()
        {
            list = new ArrayList();
        }

        #region IList Members

        public int Add(object value)
        {
            return list.Add(value);
        }

        public void Clear()
        {
            list.Clear();
        }

        public bool Contains(object value)
        {
            return list.Contains(value);
        }

        public int IndexOf(object value)
        {
            return list.IndexOf(value);
        }

        public void Insert(int index, object value)
        {
            list.Insert(index, value);
        }

        public bool IsFixedSize
        {
            get { return list.IsFixedSize; }
        }

        public bool IsReadOnly
        {
            get { return list.IsReadOnly; }
        }

        public void Remove(object value)
        {
            list.Remove(value);
        }

        public void RemoveAt(int index)
        {
            list.RemoveAt(index);
        }

        public object this[int index]
        {
            get
            {
                return list[index];
            }
            set
            {
                list[index] = value;
            }
        }

        #endregion

        #region ICollection Members

        public void CopyTo(Array array, int index)
        {
            list.CopyTo(array, index);
        }

        public int Count
        {
            get { return list.Count; }
        }

        public bool IsSynchronized
        {
            get { return list.IsSynchronized; }
        }

        public object SyncRoot
        {
            get { return list.SyncRoot; }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            return list.GetEnumerator();
        }

        #endregion
    }
}
