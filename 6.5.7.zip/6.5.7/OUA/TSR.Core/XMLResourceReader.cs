using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;
using System.Globalization;
using TSR.Core.Entity.List;
using TSR.Core.DAL;
using TSR.Core.Entity;
using System.Collections;
using WS = TSR.Core.UserAgentService;

namespace TSR.Core
{
    /// <summary>
    /// Class
    /// Name: XMLResourceReader
    /// Description: This class is a custom ResourceReader 
    /// who implements IResourceReader & handles 
    /// ResourceReader related properties & functions.
    /// </summary>
    public class XMLResourceReader : IResourceReader
    {
        private string _Language;

        public XMLResourceReader
           (CultureInfo culture)
        {
            this._Language = culture.Name;
        }

        /// <summary>
        /// gets enumerator for resource list, useful for iteration
        /// </summary>
        /// <returns></returns>
        public System.Collections.IDictionaryEnumerator GetEnumerator()
        {
            Hashtable dict = new Hashtable();
            if (String.IsNullOrEmpty(_Language))
                _Language = "Default";
            try
            {
                LanguageResourcesList list = new LanguageResourcesList();

                using (LanguageResourcesDAL dal = new LanguageResourcesDAL())
                {
                    list = dal.GetLanguageResourcesByLanguageId(_Language);
                }
                foreach (LanguageResources lr in list)
                {
                    if (!dict.ContainsKey(lr.ResourceKey))
                    {
                        dict.Add(lr.ResourceKey, lr.ResourceValue);
                    }
                }

            }
            catch (Exception ex)   // ignore missing columns in the database
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
            }
            finally
            {
            }
            return dict.GetEnumerator();
        }

        public void Close()
        {
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        void IDisposable.Dispose()
        {
        }
    }
}
