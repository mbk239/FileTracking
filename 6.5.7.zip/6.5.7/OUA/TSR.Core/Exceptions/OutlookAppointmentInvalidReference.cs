using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core.Exceptions
{
    class OutlookAppointmentInvalidReference : Exception
    {
    }
}
