using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core.Exceptions
{
    /// <summary>
    /// Custom exception class
    /// </summary>
    class OLAppointmentNotFound : Exception
    {
    }
}
