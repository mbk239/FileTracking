using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core
{
    /// <summary>
    /// If an appointment is changed, with this class, users of all screen are informed.
    /// If one class registers, it will be notified by the class, who is changing the appointment,
    /// which is in this case, outlookinspector class.
    /// </summary>
    public class AppointmentInformer
    {
        #region Instance Variables

        public delegate void Appointment_Listener(Object Sender, EventArgs e);
        private static AppointmentInformer instance;
        private static List<IAppointmentObserver> _observerContainer = new List<IAppointmentObserver>();

        #endregion        

        #region Constructor
        
        private AppointmentInformer(){ }
        
        #endregion

        /// <summary>
        /// singleton pattern
        /// </summary>
        /// <returns></returns>
        public static AppointmentInformer GetInstance()
        {
            if (instance == null)
            {
                instance = new AppointmentInformer();
            }
            return instance;            
        }
        
        /// <summary>
        /// observer pattern, subscription method
        /// </summary>
        /// <param name="anAppointmentObserver"></param>
        public void Register(IAppointmentObserver anAppointmentObserver)
        {
            _observerContainer.Add(anAppointmentObserver);
        }

        /// <summary>
        /// observer pattern, unsubscribe method
        /// </summary>
        /// <param name="anAppointmentObserver"></param>
        public void UnRegister(IAppointmentObserver anAppointmentObserver)
        {
            _observerContainer.Remove(anAppointmentObserver);
        }        

        /// <summary>
        /// observer pattern, notification method
        /// </summary>
        /// <param name="anObject"></param>
        public void NotifyAppointmentObservers(object anObject)
        {
            foreach (IAppointmentObserver anObserver in _observerContainer)
            {
                anObserver.Notify(anObject);
            }
        }
    }

    /// <summary>
    /// Observer pattern interface
    /// </summary>
    public interface IAppointmentObserver
    {
        void Notify(object anObject);
    }
    
}
