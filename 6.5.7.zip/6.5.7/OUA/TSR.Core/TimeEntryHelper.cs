﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Core.Entity;
using WS = TSR.Core.UserAgentService;

namespace TSR.Core
{
    public enum TimeEntryType
    {
        Valid = 0,
        MissingCurrentDB = 1,
        OldDB = 2
    }
    public class TimeEntryHelper
    {
        public static TimeEntryType GetTimeEntryType(TimeEntry timeEntry)
        {
            if ((timeEntry.Organization != null) && (timeEntry.Project != null) && (timeEntry.Activity != null)
                &&((timeEntry.ContactID.HasValue && timeEntry.Contact != null)||(!(timeEntry.ContactID.HasValue))))
            {
                OrganizationList listAllOrganization = TSRFacade.GetAllOrganizations();
                if ((listAllOrganization != null) && (listAllOrganization.FindByID(timeEntry.OrganizationID) != null))
                {
                    ContactList listContact = TSRFacade.GetContactsByOrganizationID(timeEntry.OrganizationID);
                    if ((timeEntry.ContactID.HasValue) && ((listContact == null) || ((listContact != null) &&(listContact.FindByID(timeEntry.ContactID.Value) == null))))
                    {
                        return TimeEntryType.MissingCurrentDB;
                    }
                    ProjectList listProject = TSRFacade.GetProjectsForOrganization(timeEntry.OrganizationID);
                    if ((listProject != null) && (listProject.FindByID(timeEntry.ProjectID) != null))
                    {
                        ActivityList listActivity = TSRFacade.GetActivitiesForProject(timeEntry.ProjectID);
                        if ((listActivity != null) && (listActivity.FindByID(timeEntry.ActivityID) != null))
                            return TimeEntryType.Valid;
                        else
                            return TimeEntryType.MissingCurrentDB;
                    }
                    else
                        return TimeEntryType.MissingCurrentDB;
                }
                else
                    return TimeEntryType.MissingCurrentDB;
            }
            else
                return TimeEntryType.OldDB;
        }

        public static bool IsDifferentTimeEntries(WS.TimeEntry timeEntryServer, TimeEntry timeEntryClient)
        {            
            if (timeEntryServer.ID == timeEntryClient.ID)
            {
                if (((timeEntryServer.ActivityID <= 0 && timeEntryClient.ActivityID <= 0) || 
                    (timeEntryServer.ActivityID == timeEntryClient.ActivityID))
                    && ((timeEntryServer.ProjectID <= 0 && timeEntryClient.ProjectID <= 0) || 
                    (timeEntryServer.ProjectID == timeEntryClient.ProjectID))
                    && ((timeEntryServer.OrganizationID <= 0 && timeEntryClient.OrganizationID <= 0) || 
                    (timeEntryServer.OrganizationID == timeEntryClient.OrganizationID))
                    && (((timeEntryServer.ContactID == null || !(timeEntryServer.ContactID.HasValue) || timeEntryServer.ContactID <= 0) && 
                    (timeEntryClient.ContactID == null || !(timeEntryClient.ContactID.HasValue) || timeEntryClient.ContactID <= 0)) 
                    || (timeEntryServer.ContactID == timeEntryClient.ContactID))
                    && (((timeEntryServer.StartTimeStamp == null || timeEntryServer.StartTimeStamp == DateTime.MinValue) && 
                    (timeEntryClient.StartTimeStamp == null || timeEntryClient.StartTimeStamp == DateTime.MinValue)) || 
                    (timeEntryServer.StartTimeStamp == timeEntryClient.StartTimeStamp))
                    && (((timeEntryServer.EndTimeStamp == null || timeEntryServer.EndTimeStamp == DateTime.MinValue) && 
                    (timeEntryClient.EndTimeStamp == null || timeEntryClient.EndTimeStamp == DateTime.MinValue)) || 
                    (timeEntryServer.EndTimeStamp == timeEntryClient.EndTimeStamp))
                    && ( (string.IsNullOrEmpty(timeEntryServer.Location) && string.IsNullOrEmpty(timeEntryClient.Location)) || 
                    (timeEntryServer.Location == timeEntryClient.Location))
                    //&& (timeEntryServer.Notes == timeEntryClient.Notes)
                    && ((string.IsNullOrEmpty(timeEntryServer.Body) && string.IsNullOrEmpty(timeEntryClient.Body))|| 
                    (timeEntryServer.Body == timeEntryClient.Body))
                    && ((string.IsNullOrEmpty(timeEntryServer.Subject) && string.IsNullOrEmpty(timeEntryClient.Subject)) || 
                    (timeEntryServer.Subject == timeEntryClient.Subject))
                    && (((timeEntryServer.TaskID == null || !(timeEntryServer.TaskID.HasValue) || timeEntryServer.TaskID <= 0) && 
                    (timeEntryClient.TaskID == null ||!(timeEntryClient.TaskID.HasValue) ||timeEntryClient.TaskID <= 0))||
                    (timeEntryServer.TaskID == timeEntryClient.TaskID))
                    //&& (timeEntryServer.UserID == timeEntryClient.UserID)
                    && (timeEntryServer.Status == timeEntryClient.Status)
                    && ((string.IsNullOrEmpty(timeEntryServer.Names) && string.IsNullOrEmpty(timeEntryClient.Names)) || 
                    (timeEntryServer.Names == timeEntryClient.Names))
                    //&& ((string.IsNullOrEmpty(timeEntryServer.SubmitterName) && string.IsNullOrEmpty(timeEntryClient.SubmitterName)) ||
                    //(timeEntryServer.SubmitterName == timeEntryClient.SubmitterName))
                    && (((timeEntryServer.Revision == null || !(timeEntryServer.Revision.HasValue) || timeEntryServer.Revision <= 0) &&
                    (timeEntryClient.Revision == null || !(timeEntryClient.Revision.HasValue) || timeEntryClient.Revision <= 0)) ||
                    (timeEntryServer.Revision == timeEntryClient.Revision)))
                {                   
                    return false;
                }                    
                else
                    return true;
            }
            else
            {
                return false;
            }
        }
    }
}
