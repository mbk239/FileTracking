using System;
using System.Collections.Generic;
using System.Text;

//using AUS = TSR.Core.AuthenticationService;
using UAS = TSR.Core.UserAgentService;
using System.ServiceModel;
using System.Net;
using Org.Mentalis.Network.ProxySocket;
using System.Net.Sockets;
using System.ServiceModel.Description;

namespace TSR.Core
{
    /// <summary>
    /// A class to provide proxy class's client objects
    /// </summary>
    public static class ServiceProvider
    {        
        //private static AUS.AuthenticationService _AUService;
        private static UAS.UserAgentServiceClient _UAService;
        private static System.Net.CookieContainer _Container;
        //private static System.Net.ICredentials _Credentials;

        private static System.Net.CookieContainer Container
        {
            get
            {
                if (_Container == null)
                    _Container = new System.Net.CookieContainer();
                return _Container;
            }
        }
       
        //public static UAS.UserAgentServiceClient GetUserAgentService()
        //{
        //    return GetUserAgentService(string.Empty);
        //}

        public static UAS.UserAgentServiceClient GetUserAgentService(bool sslMode)
        {
            return GetUserAgentService(string.Empty,sslMode);
        }

        /// <summary>
        /// retrieves user agent service
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        //public static UAS.UserAgentServiceClient GetUserAgentService(string address)
        //{                        

        //    string serverAdd = (string.IsNullOrEmpty(address) ? SettingsHelper.TSRServerAddress + "/UserAgentService.svc" : address + "/UserAgentService.svc");                        

        //    BasicHttpBinding CurrentBasicHttpBinding;
        //    CurrentBasicHttpBinding = new BasicHttpBinding();
        //    CurrentBasicHttpBinding.MaxReceivedMessageSize = 204003200; // Int32.MaxValue;
        //    CurrentBasicHttpBinding.MaxBufferSize = 204003200;
        //    CurrentBasicHttpBinding.TransferMode = TransferMode.Buffered;
        //    //CurrentBasicHttpBinding.MessageEncoding = WSMessageEncoding.Mtom;
        //    CurrentBasicHttpBinding.ReaderQuotas.MaxStringContentLength = 2147483647;

        //    CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
        //    CurrentBasicHttpBinding.SendTimeout = new System.TimeSpan(0, 10, 0);
            

        //    CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Windows;

        //    EndpointAddress endpoint = new EndpointAddress(serverAdd); //"http://localhost:49585/Contest.TSR.AdvancedServices/UserAgentService.svc");
        //    _UAService = new UserAgentService.UserAgentServiceClient(CurrentBasicHttpBinding, endpoint);
        //    _UAService.ChannelFactory.Credentials.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;
        //    _UAService.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
            

        //    return _UAService;
        //}

        /// <summary>
        /// retrieves user agent service with ssl mode
        /// </summary>
        /// <param name="address"></param>
        /// <param name="sslMode"></param>
        /// <returns></returns>
        public static UAS.UserAgentServiceClient GetUserAgentService(string address, bool sslMode, 
            SettingsHelper.ProxyTypeEnum proxyType, string proxyHost, string proxyPort, bool isAuthentication, string proxyUsername, string proxyPassword,
            bool proxyAutoSwitch, int timeOutValue)
        {          
            string serverAdd = (string.IsNullOrEmpty(address) ? SettingsHelper.TSRServerAddress + "/UserAgentService.svc" : address + "/UserAgentService.svc");

            BasicHttpBinding CurrentBasicHttpBinding;
            CurrentBasicHttpBinding = new BasicHttpBinding();
            CurrentBasicHttpBinding.MaxReceivedMessageSize = 204003200; // Int32.MaxValue;
            CurrentBasicHttpBinding.MaxBufferSize = 204003200;
            CurrentBasicHttpBinding.TransferMode = TransferMode.Buffered;
            //CurrentBasicHttpBinding.MessageEncoding = WSMessageEncoding.Mtom;
            CurrentBasicHttpBinding.ReaderQuotas.MaxStringContentLength = 204003200;

            if (sslMode)
            {
                System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(RemoteServerCertificateValidationCallback);
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.Transport;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.None;
            }
            else
            {
                CurrentBasicHttpBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
                CurrentBasicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Windows;
            }

            //int timeOutValue = SettingsHelper.ConnectionTimeOut;

            CurrentBasicHttpBinding.SendTimeout = new System.TimeSpan(0, 0, timeOutValue);
            CurrentBasicHttpBinding.ReceiveTimeout = new System.TimeSpan(0, 0, timeOutValue);
            CurrentBasicHttpBinding.OpenTimeout = new System.TimeSpan(0, 0, timeOutValue);
            CurrentBasicHttpBinding.CloseTimeout = new System.TimeSpan(0, 0, timeOutValue);

            //CurrentBasicHttpBinding.BypassProxyOnLocal = true;
            //CurrentBasicHttpBinding.UseDefaultWebProxy = false;

            EndpointAddress endpoint = new EndpointAddress(serverAdd); //"http://localhost:49585/Contest.TSR.AdvancedServices/UserAgentService.svc");
            _UAService = new UserAgentService.UserAgentServiceClient(CurrentBasicHttpBinding, endpoint);

            _UAService.ChannelFactory.Credentials.Windows.ClientCredential = System.Net.CredentialCache.DefaultNetworkCredentials;
            try
            {
                if (_UAService.Endpoint.Contract.Operations.Count > 0)
                {
                    foreach (OperationDescription op in _UAService.Endpoint.Contract.Operations)
                    {
                        DataContractSerializerOperationBehavior dataContractBehavior =
                                    op.Behaviors.Find<DataContractSerializerOperationBehavior>() as DataContractSerializerOperationBehavior;
                        if (dataContractBehavior != null)
                        {
                            dataContractBehavior.MaxItemsInObjectGraph = 204003200;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            
            if (!sslMode)
                _UAService.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;

            if (proxyType == SettingsHelper.ProxyTypeEnum.NoProxy ||
                proxyType == SettingsHelper.ProxyTypeEnum.SystemProxy ||
                proxyType == SettingsHelper.ProxyTypeEnum.Https)
            {
                if (proxyType == SettingsHelper.ProxyTypeEnum.NoProxy)
                {
                    WebRequest.DefaultWebProxy = null;
                }
                else if (proxyType == SettingsHelper.ProxyTypeEnum.SystemProxy)
                {
                    WebRequest.DefaultWebProxy = WebRequest.GetSystemWebProxy();
                }
                else if (proxyType == SettingsHelper.ProxyTypeEnum.Https)
                {
                    string proxyAddress = proxyHost + ":" + proxyPort;
                    if (!proxyAddress.StartsWith("http://"))
                        proxyAddress = "http://" + proxyAddress;

                    WebRequest.DefaultWebProxy = new WebProxy(proxyAddress, true);
                }
                if (isAuthentication && WebRequest.DefaultWebProxy != null)
                {
                    WebRequest.DefaultWebProxy.Credentials = new NetworkCredential(proxyUsername, proxyPassword);
                }
                else
                {
                    if (WebRequest.DefaultWebProxy != null)
                        WebRequest.DefaultWebProxy.Credentials = null;
                }

                
            }
            else if (proxyType == SettingsHelper.ProxyTypeEnum.Socks4 || proxyType == SettingsHelper.ProxyTypeEnum.Socks5)
            {
                ProxySocket ps = new ProxySocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                // set the proxy settings
                long lHost = 0;
                IPAddress ipHost;
                int iPort = 0;
                if (int.TryParse(proxyPort, out iPort))
                {
                    if (long.TryParse(proxyHost, out lHost))
                        ps.ProxyEndPoint = new IPEndPoint(lHost, iPort);
                    else if(IPAddress.TryParse(proxyHost, out ipHost))
                        ps.ProxyEndPoint = new IPEndPoint(ipHost, iPort);
                }
                if (isAuthentication)
                {
                    ps.ProxyUser = proxyUsername;
                    ps.ProxyPass = proxyPassword;
                }

                //if you set this to ProxyTypes.None, the ProxySocket will act as a normal Socket
                if (proxyType == SettingsHelper.ProxyTypeEnum.Socks4)
                    ps.ProxyType = ProxyTypes.Socks4;
                else if (proxyType == SettingsHelper.ProxyTypeEnum.Socks5)
                    ps.ProxyType = ProxyTypes.Socks5;
            }

            if (proxyAutoSwitch && WebRequest.DefaultWebProxy != null)
            {
                try
                {
                    _UAService.IsServiceUp();
                }
                catch (Exception ex)
                {
                    WebRequest.DefaultWebProxy = null;
                    if (WebRequest.DefaultWebProxy != null)
                        WebRequest.DefaultWebProxy.Credentials = null;

                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }
            return _UAService;
        }

        public static UAS.UserAgentServiceClient GetUserAgentService(string address, bool sslMode)
        {
            return GetUserAgentService(address, sslMode, SettingsHelper.ProxyType, SettingsHelper.ProxyHost, SettingsHelper.ProxyPort, 
                SettingsHelper.ProxyAuthenticationEnable, SettingsHelper.ProxyUsername, SettingsHelper.ProxyPassword, SettingsHelper.ProxyAutoSwitch, SettingsHelper.ConnectionTimeOut);
        }

        private static bool RemoteServerCertificateValidationCallback(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certificate, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}
