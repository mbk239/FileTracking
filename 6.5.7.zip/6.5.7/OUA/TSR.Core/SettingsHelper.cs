using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Globalization;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Collections;
//using Microsoft.Win32;
//using System.Security.Principal;
using System.IO;
//using System.Security.AccessControl;

namespace TSR.Core
{
    public class SettingsHelper
    {
        public enum PeriodType
        {
            Minute,
            Hour
        };

        public enum AllTimePeriodTypes
        {
            Hour,
            Day,
            Week,
            Month,
            Year
        }

        public enum ProxyTypeEnum
        {
            NoProxy = 0,
            SystemProxy = 1,
            Https = 2,
            Socks4 = 3,
            Socks5 = 4
        }

        public enum OUAScreens
        {
            About = 1,
            CheckListTimeEntry = 2,
            DisableAddin = 3,
            frmCreateSupportLogFile = 4,
            frmTSRLoginRequired = 5,
            ItemList = 6,
            MemoryBox = 7,
            OverwriteTimeEntries = 8,
            Preferences = 9,
            Settings = 10,
            ShowBox = 11,
            TimeEntryAdvanced = 12
        }


        public enum OutlookUserAgentEnum
        {
            AsWebInterface = 0,
            CurrentWeek = 1,
            CurrentMonth = 2,
            PreviousWeek = 3,
            PreviousMonth = 4
        }

        #region Default Settings related Members

        /// <summary>
        /// Method
        /// GetAutoSyncIndexes
        /// </summary>
        /// <returns>NameValueCollection</returns>
        //public static NameValueCollection GetAutoSyncIndexes()
        //{
        //    NameValueCollection collection = new NameValueCollection();
        //    collection.Add("0", "1");
        //    collection.Add("1", "2");
        //    collection.Add("2", "3");
        //    collection.Add("3", "4");
        //    collection.Add("4", "5");
        //    collection.Add("5", "10");
        //    collection.Add("6", "15");
        //    collection.Add("7", "20");
        //    collection.Add("8", "25");

        //    return collection;
        //}

        /// <summary>
        /// Method
        /// GetPeriods
        /// </summary>
        /// <returns>NameValueCollection</returns>
        public static NameValueCollection GetPeriods()
        {
            NameValueCollection collection = new NameValueCollection();
            IList lst = EnumHelper.GetListFromEnum(typeof(AllTimePeriodTypes), null);
            for (int i = 0; i < lst.Count; i++)
            {
                EnumListItem eli = lst[i] as EnumListItem;
                if(eli!=null)
                    collection.Add(i.ToString(), eli.Name);
            }
            //collection.Add("0", "hour(s)");
            //collection.Add("1", "day(s)");
            //collection.Add("2", "week(s)");
            //collection.Add("3", "month(s)");
            //collection.Add("4", "year(s)");

            return collection;
        }

        /// <summary>
        /// Method
        /// GetAutoSyncPeriods
        /// </summary>
        /// <returns>NameValueCollection</returns>
        public static NameValueCollection GetAutoSyncPeriods()
        {
            //NameValueCollection collection = new NameValueCollection();
            //collection.Add("0", "Minute");
            //collection.Add("1", "Hour");

            NameValueCollection collection = new NameValueCollection();
            IList lst = EnumHelper.GetListFromEnum(typeof(PeriodType), null);
            for (int i = 0; i < lst.Count; i++)
            {
                EnumListItem eli = lst[i] as EnumListItem;
                if (eli != null)
                    collection.Add(i.ToString(), eli.Name);
            }
                        
            return collection;
        }

        /// <summary>
        /// Method
        /// GetOptions
        /// </summary>
        /// <returns>NameValueCollection</returns>
        public static NameValueCollection GetOptions()
        {
            NameValueCollection collection = new NameValueCollection();
            collection.Add("1", "Yes");
            collection.Add("0", "No");

            return collection;
        }

        #endregion

        #region Outlook Specfic Settings

        public static string GetTSROutlookFolderToSync()
        {
            return TSRFacade.GetDefaultCalendarForTSRSync();
        }

        public static bool SetTSROutlookFolderToSync(string value)
        {
            return TSRFacade.SetDefaultCalendarForTSRSync(value);
        }

        #endregion

        #region Constants


        public const string TSRWEBINTERFACE_SETTING = "TSRWebinterface";
        public const string TSRUSERNAME_SETTING = "TSRUserName";
        public const string TSRPASSWORD_SETTING = "TSRPassword";
        public const string TSRSERVERADDRESS_SETTING = "TSRServerAddress";
        public const string _TSRDontShowAgain = "TSRDontShowAgain";
        public const string TSRDO_NOT_RETRIEVE_SETTING_SERVER = "TSRDoNotRetrieveSettingsServer";
        public const string TSRAUTO_SYNC_INDEX = "TSRAutoSyncIndex";
        public const string TSRSYNCHRONIZE_TSRSETUP_DATA = "SynchronizeTSRSetupData";
        public const string TSRSYNCHRONIZE_TSRENTRIES = "SynchronizeTSREntries";
        public const string TSRSYNC_RANGE_INDEX = "TSRSyncRangeIndex";
        public const string TSRSYNC_RANGE_INDEX_FUTURE = "TSRSyncRangeIndexFuture";
        public const string TSRBTN_AUTO_SYNC_EVERYTIIME = "TSRAutoSyncWhenOutlookOpen";
        public const string TSRMISC_LAUNCH = "TSRMiscLaunch";
        public const string TSRMISC_NOT_SYNC_COMPLETED_DATA = "TSRMiscNotSyncCompletedData";
        public const string TSRMISC_NOT_SYNC_TECREATED_VIA_WEB= "TSRMiscNotSyncTECreatedViaWeb";
        public const string TSRMISC_SYNC_REMOVED_DATA = "TSRMiscSyncRemovedData";
        public const string TSRSYNC_RANGE_PERIOD = "TSRSyncRangePeriod";
        public const string TSRSYNC_RANGE_PERIOD_FUTURE = "TSRSyncRangePeriodFuture";
        public const string TSRAUTO_SYNC_PERIOD = "TSRAutoSyncPeriod";
        public const string TSRMISC_PAST_INDEX = "TSRMiscPastIndex";                                                  
        public const string TSRMISC_FUTURE_INDEX = "TSRMiscFutureIndex";
        public const string TSRAUTO_SYNC_WHEN_OUTLOOK_CLOSE = "TSRAutoSyncWhenOutlookClose";
        public const string TSRAUTO_SYNC_PERIOD_OPTION = "TSRAutoSyncPeriodOption";
        public const string TSRAUTO_SYNC_OPTION = "TSRAutoSyncOption";
        public const string TSRLANGUAGE_ID = "TSRLanguageId";
        public const string TSRMISC_PAST_PERIOD = "TSRMiscPastPeriod";
        public const string TSRMISC_FUTURE_PERIOD = "TSRMiscFuturePeriod";
        public static string TSR_LANGUAGE_ID = "";
        public const string TSRDISPLAY_TOOLTIP = "TSRDisplayTooltip";
        //the consts related to proxy configuration must be include "Proxy" in start
        public const string PROXY_TYPE = "ProxyType";
        public const string PROXY_HOST = "ProxyHost";
        public const string PROXY_PORT = "ProxyPort";
        public const string PROXY_ENABLE_AUTHENTICATION = "ProxyAuthenticationEnable";
        public const string PROXY_USERNAME = "ProxyUsername";
        public const string PROXY_PASSWORD= "ProxyPassword";
        public const string PROXY_CONNECTION_TIMEOUT = "ConnectionTimeOut";
        public const int PROXY_CONNECTION_TIMEOUT_DEFAULTVALUE = 30;
        public const string PROXY_AUTOSWITCH = "ProxyAutoSwitch";

        public const string TSRMISC_DATEFORMAT = "TSRDateFormat";
        public const string TSRMISC_TIMEFORMAT = "TSRTimeFormat";

        public const string TIMEINTERVAL_TIMESHEETWEB_FROM = "TimeIntervalTimeSheetWebFrom";
        public const string TIMEINTERVAL_TIMESHEETWEB_TO = "TimeIntervalTimeSheetWebTo";

        public const int TSRAUTO_SYNC_INDEX_MINIMUM = 5;

        public const string SCREEN_SIZES = "ScreenSizes";

        public const string SHOWONLYFAVORITES = "ShowOnlyFavorites";

        public const string TSRLOCKPERIOD = "TSRLockPeriod";

        public const string DurationWarning = "DurationWarning";

        public const string IsDurationWarningEnable = "IsDurationWarningEnable";

        //public const string TSRLISTTIMEENTRIES_OUA = "TSRListTimeEntriesOutlookUserAgent";

        #endregion

        public static bool UpdateCurrentCulture()
        {
            bool success = true;

            try
            {
                CultureInfo culture = System.Threading.Thread.CurrentThread.CurrentUICulture;

                if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRLanguageId))
                {
                    if (culture.Name != TSR.Core.SettingsHelper.TSRLanguageId || TSR.Core.SettingsHelper.TSRLanguageId != culture.TwoLetterISOLanguageName)
                        culture = new CultureInfo(TSR.Core.SettingsHelper.TSRLanguageId, true);
                    if (culture.IsNeutralCulture)
                    {
                        culture = CultureInfo.CreateSpecificCulture(TSR.Core.SettingsHelper.TSRLanguageId);
                    }
                    System.Threading.Thread.CurrentThread.CurrentCulture = culture; //new System.Globalization.CultureInfo(cmbPreferredLanguage.SelectedItem.ToString());                
                    System.Threading.Thread.CurrentThread.CurrentUICulture = culture; //new System.Globalization.CultureInfo(cmbPreferredLanguage.SelectedItem.ToString());
                }
            }
            catch (Exception exp)
            {
                Logging.LoggingHandler.LogUnhandledException(exp);
                success = false;
                System.Diagnostics.Debug.WriteLine(exp.Message);
            }

            return success;
        }

        public static string TSRLanguageId
        {
            get
            {
                string result ="en";
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRLanguageId")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRLanguageId");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRLanguageId", value.ToString());
            }
        }              

        public static string TSRLanguageName
        {
            get
            {
                string result = Constants.DEFAULT_LANGUAGE_NAME;
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRLanguageName")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRLanguageName");
            }
            set
            {
                value = value.Replace("&#47;", "/");
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRLanguageName", value.ToString());
            }
        }               

        public static System.Collections.Specialized.StringCollection TSRPreferredLanguages
        {
            get
            {
                StringCollection spCollection = new StringCollection();
                string sVal = TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRPreferredLanguages");
                if (string.IsNullOrEmpty(sVal))
                {
                    //spCollection.Add("en");
                    spCollection.Add(Constants.DEFAULT_LANGUAGE_NAME + "#" + Constants.DEFAULT_CULTURE_LCID); // "US English"
                    return spCollection;
                }
                //string[] tempStrings = Regex.Split(sVal, "<>");                
                //foreach (string s in tempStrings)
                //{
                //    spCollection.Add(s);
                //}
                spCollection.Add(sVal);
                return spCollection;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRPreferredLanguages", TSRFacade.GetPreferredPathAsString(value));
            }

            //get { return TSR.Core.Properties.Settings.Default.TSRPreferredLanguage; }
            //set
            //{
            //    TSR.Core.Properties.Settings.Default.TSRPreferredLanguage = value;
            //    Save();
            //}
        }

        //public static string TSRPluginDBConnectionString
        //{
        //    get
        //    {
        //        return TSR.Core.Properties.Settings.Default.TSRConnectionString;
        //    }
        //    set
        //    {
        //        TSR.Core.Properties.Settings.Default.TSRConnectionString = value;
        //        Save();
        //    }
        //}
        public static bool ProxyAutoUsing //use auto proxy
        {
            get
            {
                bool result = false;
                bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USE_AUTO_PROXY_VALUE), out result);
                return result;
            }
        }

        public static string TSRUserName
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRUserName");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRUserName", value.ToString());
            }
        }

        public static string TSRSyncRangePeriod
        {
            get
            {
                string result = "0";
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangePeriod")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangePeriod");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRSyncRangePeriod", value.ToString());
            }
        }

        public static string TSRSyncRangePeriodFuture
        {
            get
            {
                string result = "0";
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangePeriodFuture")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangePeriodFuture");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRSyncRangePeriodFuture", value.ToString());
            }
        }

        public static int TSRSyncRangeIndex
        {
            get
            {
                int result = 0;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangeIndex"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRSyncRangeIndex", value.ToString());
            }
        }

        public static int TSRSyncRangeIndexFuture
        {
            get
            {
                int result = 0;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRSyncRangeIndexFuture"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRSyncRangeIndexFuture", value.ToString());
            }
        }
       
        public static string TSRServerAddress
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSRSERVERADDRESS_SETTING);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSRSERVERADDRESS_SETTING, value.ToString());
            }
        }      

        public static string TSRWebinterface
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSRWEBINTERFACE_SETTING);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSRWEBINTERFACE_SETTING, value.ToString());
            }
        }   
       
        public static string TSRPassword
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRPassword");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRPassword", value.ToString());
            }
        }

        public static bool TSRMiscSyncRemovedData
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscSyncRemovedData"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscSyncRemovedData", value.ToString());
            }
        }

        public static string TSRMiscPastPeriod
        {
            get
            {
                string result = "0";
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscPastPeriod")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscPastPeriod");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscPastPeriod", value.ToString());
            }
        }

        public static string TSRMiscFuturePeriod
        {
            get
            {
                string result = "0";
                if (string.IsNullOrEmpty(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscFuturePeriod")))
                    return result;
                else
                    return TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscFuturePeriod");
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscFuturePeriod", value.ToString());
            }
        }

        public static bool TSRMiscNotSyncCompletedData
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscNotSyncCompletedData"), out result);
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscNotSyncCompletedData", value.ToString());
            }
        }

        public static bool TSRMiscNotSyncTECreatedViaWeb
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscNotSyncTECreatedViaWeb"), out result);
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscNotSyncTECreatedViaWeb", value.ToString());
            }
        }

        public static bool TSRMiscLaunch
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscLaunch"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscLaunch", value.ToString());
            }
        }

        public static int TSRMiscPastIndex
        {
            get
            {
                int result = 0;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscPastIndex"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscPastIndex", value.ToString());
            }
        }

        public static int TSRMiscFutureIndex
        {
            get
            {
                int result = 0;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRMiscFutureIndex"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRMiscFutureIndex", value.ToString());
            }
        }

        //public static string TSRConnectionString
        //{
        //    get { return TSR.Core.Properties.Settings.Default.TSRConnectionString; }

        //}

        public static int TSRAutoSyncPeriod
        {
            get
            {
                int result = 0;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncPeriod"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncPeriod", value.ToString());
            }
        }

        public static bool TSRAutoSyncOption
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncOption"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncOption", value.ToString());
            }
        }

        public static int TSRAutoSyncIndex
        {
            get
            {
                int result = 5;
                Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncIndex"), out result);
                if (result < 5) result = 5;
                return result;
            }
            set
            {
                if (value < 5) value = 5;
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncIndex", value.ToString());
            }
        }

        public static bool SynchronizeTSREntries
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("SynchronizeTSREntries"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("SynchronizeTSREntries", value.ToString());
            }
        }

        public static bool SynchronizeTSRSetupData
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("SynchronizeTSRSetupData"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("SynchronizeTSRSetupData", value.ToString());
            }

        }


        //public static string TSROutlookFolderToSync
        //{
        //    get { return TSR.Core.Properties.Settings.Default.TSROutlookFolderToSync; }
        //    set
        //    {
        //        TSR.Core.Properties.Settings.Default.TSROutlookFolderToSync = value;
        //        Save();
        //    }
        //}

        public static bool TSRAutoSyncWhenOutlookOpen
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncWhenOutlookOpen"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncWhenOutlookOpen", value.ToString());
            }
        }

        public static bool TSRAutoSyncWhenOutlookClose
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncWhenOutlookClose"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncWhenOutlookClose", value.ToString());
            }
        }

        public static bool TSRAutoSyncPeriodOption
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRAutoSyncPeriodOption"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRAutoSyncPeriodOption", value.ToString());
            }
        }
        public static bool TSRDontShowAgain
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRDontShowAgain"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRDontShowAgain", value.ToString());
            }
        }
        /// <summary>
        /// Property get and set of DoNotRetrieveSettingsServer
        /// </summary>
        public static bool TSRDoNotRetrieveSettingsServer
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRDoNotRetrieveSettingsServer"), out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRDoNotRetrieveSettingsServer", value.ToString());
            }
        }

        private static void Save()
        {
            TSR.Core.Properties.Settings.Default.Save();
        }

        public static bool TSRDisplayTooltip
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSRDISPLAY_TOOLTIP), out result);
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSRDISPLAY_TOOLTIP, value.ToString());
            }
        }

        public static ProxyTypeEnum ProxyType
        {
            get
            {
                int result = 0;                
                if (!Int32.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_TYPE), out result))
                {
                    bool isUseAutoProxy = false;
                    bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USE_AUTO_PROXY_VALUE), out isUseAutoProxy);
                    if (isUseAutoProxy)
                        result = (int)ProxyTypeEnum.SystemProxy;
                }
                return (ProxyTypeEnum)result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_TYPE, ((int)value).ToString());
            }
        }

        public static string ProxyHost
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_HOST);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_HOST, value);
            }
        }

        public static string ProxyPort
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_PORT);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_PORT, value);
            }
        }

        public static string ProxyUsername
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_USERNAME);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_USERNAME, value);
            }
        }

        public static string ProxyPassword
        {
            get
            {
                return TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_PASSWORD);
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_PASSWORD, value);
            }
        }

        public static bool ProxyAuthenticationEnable
        {
            get
            {
                bool result = false;
                Boolean.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_ENABLE_AUTHENTICATION), out result);
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_ENABLE_AUTHENTICATION, value.ToString());
            }
        }

        public static int ConnectionTimeOut
        {
            get
            {
                int result = 0;
                if (!int.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_CONNECTION_TIMEOUT_VALUE), out result))
                {
                    result = PROXY_CONNECTION_TIMEOUT_DEFAULTVALUE;
                }
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(Constants.CONST_CONNECTION_TIMEOUT_VALUE, value.ToString());
            }
        }

        public static bool ProxyAutoSwitch
        {
            get
            {
                bool result = false;
                if (!bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(PROXY_AUTOSWITCH), out result))
                {
                    bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(Constants.CONST_USE_AUTO_PROXY_VALUE), out result);
                }
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(PROXY_AUTOSWITCH, value.ToString());
            }
        }

        public static string TSRDateFormat
        {
            get
            {
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSRMISC_DATEFORMAT);
                if (string.IsNullOrEmpty(value))
                {
                    value = "NA";
                }
                else
                {
                    value = value.Replace("mm", "MM");
                }
                return value;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSRMISC_DATEFORMAT, value);
            }
        }

        public static string TSRTimeFormat
        {
            get
            {
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSRMISC_TIMEFORMAT);
                if(string.IsNullOrEmpty(value))
                    value = "NA";
                return value;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TSRMISC_TIMEFORMAT, value);
            }
        }

        public static int TimeIntervalTimeSheetWebFrom
        {
            get
            {
                int result = 45;
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TIMEINTERVAL_TIMESHEETWEB_FROM);
                if (string.IsNullOrEmpty(value))
                    return result;
                if (!int.TryParse(value, out result))
                    result = 45;
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TIMEINTERVAL_TIMESHEETWEB_FROM, value.ToString());
            }
        }

        public static int TimeIntervalTimeSheetWebTo
        {
            get
            {
                int result = 10;
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TIMEINTERVAL_TIMESHEETWEB_TO);
                if (string.IsNullOrEmpty(value))
                    return result;
                if (!int.TryParse(value, out result))
                    result = 10;
                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(TIMEINTERVAL_TIMESHEETWEB_TO, value.ToString());
            }
        }

        /// <summary>
        /// value of SCREEN_SIZES is formated as 1:w,h;2:w,h;...
        /// </summary>
        /// <param name="frmName"></param>
        /// <returns></returns>
        public static void SaveScreenSize(string frmName, string[] size)
        {
            string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(SCREEN_SIZES);
            string newSize = string.Format("{0}:{1},{2}", frmName, size[0], size[1]);

            if (value.Length > 0)
            {
                int index = value.IndexOf(string.Format("{0}:", frmName));
                if (index >= 0)
                {
                    string tmp = string.Empty;
                    int tmpIndex = value.IndexOf(";", index);
                    if (tmpIndex >= 0)
                        tmp = value.Substring(index, tmpIndex - index);
                    else
                        tmp = value.Substring(index);
                    if (tmp.Length > 0)
                        value = value.Replace(tmp, newSize);
                }
                else
                    value += ";" + newSize;
            }
            else value += newSize;

            TSR.Core.TSRFacade.SetUserSettingsValueByKey(SCREEN_SIZES, value);
        }

        /// <summary>
        /// value of SCREEN_SIZES is formated as 1:w,h;2:w,h;...
        /// </summary>
        /// <param name="frmName"></param>
        /// <returns></returns>
        public static int[] GetScreenSize(string frmName)
        {
            string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(SCREEN_SIZES);
            if (string.IsNullOrEmpty(value))
                return new int[0];
            string[] lstScreens = value.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
            if (lstScreens.Length > 0)
            {
                for (int i = 0; i < lstScreens.Length; i++)
                {
                    if (lstScreens[i].Length > 0 && lstScreens[i].Contains(frmName))
                    {
                        string[] tmp = lstScreens[i].Split(new string[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                        if (tmp.Length == 2 && tmp[0] == frmName)
                        {
                            string[] size = tmp[1].Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                            if (size.Length == 2)
                            {
                                int w = 0, h = 0;
                                if (int.TryParse(size[0], out w) && int.TryParse(size[1], out h))
                                {
                                    return new int[2] { w, h };
                                }
                            }
                        }
                        break;
                    }
                }
            }
            return new int[0];
        }

        public static bool ShowOnlyFavorites
        {
            get
            {
                bool result = false;
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey(SHOWONLYFAVORITES);
                if (string.IsNullOrEmpty(value))
                    return false;

                bool.TryParse(value, out result);

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey(SHOWONLYFAVORITES, value.ToString());
            }
        }

        public static int TSRListTimeEntriesOutlookUserAgent
        {
            get
            {
                int result = (int)OutlookUserAgentEnum.AsWebInterface;
                string value = TSR.Core.TSRFacade.GetUserSettingsValueByKey("TSRListTimeEntriesOutlookUserAgent");
                if (string.IsNullOrEmpty(value))
                    return result;
                if (!int.TryParse(value, out result))
                    result = (int)OutlookUserAgentEnum.AsWebInterface;

                return result;
            }
            set
            {
                TSR.Core.TSRFacade.SetUserSettingsValueByKey("TSRListTimeEntriesOutlookUserAgent", value.ToString());
            }
        }    
    }
}
