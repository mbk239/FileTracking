using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core
{
    public enum TimeEntryStatus
    {
        PendingSubmission = 11,
        InSubmissionQue = 12,
        Submitted = UserAgentService.StatusEnum.Inactive,
        InProgress = UserAgentService.StatusEnum.InProgress,
        Approved = UserAgentService.StatusEnum.Approved,
        Rejected = UserAgentService.StatusEnum.Rejected
    }

}
