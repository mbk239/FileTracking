using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using Microsoft.Office.Interop.Outlook;
using System.Linq;
using TSR.Core.Logging;
using System.IO;
using System.Reflection;

namespace TSR.Core
{
    public class OutlookHelper
    {
        private static bool GetExchangeMode()
        {
            string strExchangeMode = string.Empty;
            DAL.UserSettingsDAL dal = new DAL.UserSettingsDAL();
            TSR.Core.Entity.UserSettings userSettings = dal.GetUserSettingsByKey(Constants.CONST_EXCHANGEMODE_KEY);
            if (userSettings != null)
                strExchangeMode = userSettings.Value;

            if (string.IsNullOrEmpty(strExchangeMode))
                return false;
            else
            {
                if (strExchangeMode.ToUpper() == ExchangeMode.Yes.ToString().ToUpper())
                    return true;
                else return false;
            }
        }

        #region Outlook Static Properties

        private static Application _CurrentApplication;
        private static NameSpace _CurrentNameSpace;
        private static MAPIFolder _DefaultAppointmentFolder;
        private static MAPIFolder _AppointmentFolder;
        public static string shortDate = string.Empty;
        public static string GetCul()
        {
            CultureInfo info = new CultureInfo(CultureInfo.CurrentCulture.LCID, true);
            string shortDateFormat = info.DateTimeFormat.ShortDatePattern;
            shortDate = shortDateFormat;
            return shortDateFormat;
        }

        /// <summary>
        /// retrieves Outlook Application object
        /// </summary>
        public static Application CurrentApplication
        {
            get
            {
                return _CurrentApplication;
            }
            set
            {
                _CurrentApplication = value;
                _CurrentNameSpace = value.GetNamespace("MAPI");
            }
        }

        /// <summary>
        /// namespace needed to access Outlook Inspectors/folders/appointments, etc
        /// </summary>
        public static NameSpace CurrentNameSpace
        {
            get
            {
                if (_CurrentApplication == null)
                {
                    string OUACurrentApplicationNotInitializedErrorMsg = Core.ResourceManager.GetResourceString("OUACurrentApplicationNotInitializedErrorMsg", "Current Application not initialised.");
                    throw new System.Exception(OUACurrentApplicationNotInitializedErrorMsg);
                }
                return _CurrentNameSpace;
            }
        }

        /// <summary>
        /// retrieves outlook default appointment folder
        /// </summary>
        public static MAPIFolder DefaultAppointmentFolder
        {
            get
            {
                if (_CurrentApplication == null)
                {
                    string OUACurrentApplicationNotInitializedErrorMsg = Core.ResourceManager.GetResourceString("OUACurrentApplicationNotInitializedErrorMsg", "Current Application not initialised.");
                    throw new System.Exception(OUACurrentApplicationNotInitializedErrorMsg);
                }
                if (_DefaultAppointmentFolder != null)
                    return _DefaultAppointmentFolder;
                _DefaultAppointmentFolder = _CurrentNameSpace.GetDefaultFolder(OlDefaultFolders.olFolderCalendar);
                return _DefaultAppointmentFolder;
            }
        }

        /// <summary>
        /// retrieves MAPI folder
        /// </summary>
        public static MAPIFolder UserSelectedAppointmentFolderForSync
        {
            get
            {
                if (_CurrentApplication == null)
                {
                    string OUACurrentApplicationNotInitializedErrorMsg = Core.ResourceManager.GetResourceString("OUACurrentApplicationNotInitializedErrorMsg", "Current Application not initialised.");
                    throw new System.Exception(OUACurrentApplicationNotInitializedErrorMsg);
                }

                //get folder name and entry id as saved in settings
                string[] appFolderEntryIdandName = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync(), Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);
                string savedFolderEntryID = string.Empty;
                if (appFolderEntryIdandName != null && appFolderEntryIdandName.Length > 0)
                {
                    savedFolderEntryID = appFolderEntryIdandName[0];
                }
                if (!string.IsNullOrEmpty(savedFolderEntryID) && _AppointmentFolder != null && (_AppointmentFolder.EntryID == savedFolderEntryID))
                    return _AppointmentFolder;
                //Edit
                _AppointmentFolder = DefaultAppointmentFolder;
                ///Check the selected folder for TSR Items
                if (!String.IsNullOrEmpty(Core.SettingsHelper.GetTSROutlookFolderToSync()))
                {
                    ///Get Folder by Entry ID and set the folder as Appointment Folder
                    MAPIFolder _appFolder = GetUserSelectedAppointmentFolderForSynchronization();
                    if (_appFolder != null)
                        _AppointmentFolder = _appFolder;
                }

                return _AppointmentFolder;
            }
            set
            {
                _AppointmentFolder = value;
            }
        }

        #endregion

        /// <summary>
        /// Create categories for tsr appointment
        /// </summary>        
        /// <returns></returns>
        public static void CreateCategoriesForTSREntry()
        {
            if (CurrentNameSpace != null)
            {
                try
                {
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.ACTIVE_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.ACTIVE_CATEGORY, OlCategoryColor.olCategoryColorBlue,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.ALLMINUSREJECTED_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.ALLMINUSREJECTED_CATEGORY, OlCategoryColor.olCategoryColorDarkMaroon,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.APPROVED_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.APPROVED_CATEGORY, OlCategoryColor.olCategoryColorDarkYellow,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.CANCELLED_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.CANCELLED_CATEGORY, OlCategoryColor.olCategoryColorTeal,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.ERROR_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.ERROR_CATEGORY, OlCategoryColor.olCategoryColorDarkRed,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.INACTIVE_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.INACTIVE_CATEGORY, OlCategoryColor.olCategoryColorGray,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.INPROGESS_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.INPROGESS_CATEGORY, OlCategoryColor.olCategoryColorGreen,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.INSUBMISSIONQUEUE_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.INSUBMISSIONQUEUE_CATEGORY, OlCategoryColor.olCategoryColorNone,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.PENDINGSUBMISSION_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.PENDINGSUBMISSION_CATEGORY, OlCategoryColor.olCategoryColorDarkGray,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.REJECTED_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.REJECTED_CATEGORY, OlCategoryColor.olCategoryColorMaroon,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                    if (CurrentNameSpace.Categories[TSR.Core.Constants.SUBMITTED_CATEGORY] == null)
                        CurrentNameSpace.Categories.Add(TSR.Core.Constants.SUBMITTED_CATEGORY, OlCategoryColor.olCategoryColorDarkOrange,
                            OlCategoryShortcutKey.olCategoryShortcutKeyNone);
                }
                catch (System.Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }

        }

        /// <summary>
        /// gets Outlook folder by [appointment] entry id
        /// </summary>
        /// <param name="entryID"></param>
        /// <returns></returns>
        public static MAPIFolder GetFolderByEntryID(string entryID)
        {
            try
            {
                return CurrentNameSpace.GetFolderFromID(entryID, System.Reflection.Missing.Value);
            }
            catch//(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return null;
            }
        }

        /// <summary>
        /// retrieves all appointment items in all folders
        /// </summary>
        /// <returns></returns>
        public static OutlookMAPIFolderList GetAllAppointmentItemFolders()
        {
            return GetFoldersForItem(OlItemType.olAppointmentItem);
        }

        /// <summary>
        /// utility method to traverse outlook folder and adding items to list
        /// </summary>
        /// <param name="_folder"></param>
        /// <param name="type"></param>
        /// <param name="result"></param>
        private static void TraverseFolder(MAPIFolder mapiFolder, OlItemType type, OutlookMAPIFolderList mapiFolderList)
        {
            bool cont = true;
            if (mapiFolder.DefaultItemType == type)
            {
                MAPIFolder mParentFolder = mapiFolder.Parent as MAPIFolder;
                if (mParentFolder != null)
                {
                    if (mParentFolder.Name == "Deleted Items")
                    {
                        cont = false;
                    }
                }
                if (cont)
                {
                    OutlookMAPIFolder currentFolder = FillOutlookMAPIFolder(mapiFolder);
                    mapiFolderList.Add(currentFolder);
                }
            }
            if (cont)
                foreach (MAPIFolder folder in mapiFolder.Folders)
                {
                    TraverseFolder(folder, type, mapiFolderList);
                }
        }

        public static OutlookMAPIFolder FillOutlookMAPIFolder(MAPIFolder mapiFolder)
        {
            OutlookMAPIFolder currentFolder = new OutlookMAPIFolder();
            if (mapiFolder == null) return currentFolder;

            currentFolder.EntryID = mapiFolder.EntryID;
            currentFolder.FolderFullPath = mapiFolder.FullFolderPath;
            currentFolder.FolderName = mapiFolder.Name;
            currentFolder.FolderPath = mapiFolder.FolderPath;
            if (!string.IsNullOrEmpty(currentFolder.FolderPath))
            {
                string folderPath = currentFolder.FolderPath;
                while (true)
                {
                    if (folderPath[0].Equals('\\'))
                    {
                        folderPath = folderPath.Remove(0, 1);
                    }
                    else
                        break;
                }
                string ownerName = folderPath.Substring(0, folderPath.IndexOf("\\"));
                if (!string.IsNullOrEmpty(ownerName))
                {
                    currentFolder.FolderName += " " + ResourceManager.GetResourceString("OutlookCalendarSeperator", "in") + " " + ownerName;
                }
            }
            currentFolder.StoreID = mapiFolder.StoreID;
            return currentFolder;
        }

        /// <summary>
        /// gets list of folders depending of type of outlook item
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static OutlookMAPIFolderList GetFoldersForItem(OlItemType type)
        {
            OutlookMAPIFolderList result = new OutlookMAPIFolderList();
            try
            {
                foreach (MAPIFolder folder in CurrentNameSpace.Folders)
                {
                    if (folder.DefaultItemType == OlItemType.olPostItem)
                    {
                        continue;
                    }
                    TraverseFolder(folder, type, result);
                }
            }
            catch (System.Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return result;
        }

        /// <summary>
        /// retrieves appointment object from outlook appointment's entry id
        /// </summary>
        /// <param name="entryID"></param>
        /// <returns></returns>
        public static AppointmentItem GetAppointmentItemByEntryID(string entryID)
        {
            try
            {
                //Edit
                object item = CurrentNameSpace.GetItemFromID(entryID, DefaultAppointmentFolder.StoreID);
                //System.Reflection.Missing.Value);

                AppointmentItem appointment = item as AppointmentItem;

                //it is possible that appointment was manually deleted and is still in deleted folder, and GetItemFromID
                //method will return that appointment [even if it was deleted, so need to avoid that..]
                MAPIFolder mfolder = appointment.Parent as MAPIFolder;
                if (mfolder != null)
                {
                    //if the appointment was not deleted, it will be inside a calendar folder, 
                    //whose DefaultItemType will be olAppointmentItem
                    if (mfolder.DefaultItemType != OlItemType.olAppointmentItem)
                    {
                        return null;
                    }
                }

                return appointment;
            }
            catch //(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);
                return null;
            }
        }


        //Added by tsrdev1
        //Added datetime 29/10/2010
        /// <summary>
        /// retrieves appointment object from outlook appointment's entry id and calendar folder id
        /// </summary>
        /// <param name="entryID"></param>
        /// <param name="storeID"></param>
        /// <returns></returns>
        public static AppointmentItem GetAppointmentItemByEntryIDAndFolder(string entryID, string storeID)
        {
            try
            {
                //Edit
                object item = CurrentNameSpace.GetItemFromID(entryID, storeID);
                //System.Reflection.Missing.Value);
                AppointmentItem appointment = item as AppointmentItem;
                return appointment;
            }
            catch //(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);
                return null;
            }
        }
        /// <summary>
        /// retrieves calendar folder ID from outlook appointment
        /// </summary>
        ///<param name="item"></param>
        /// <returns></returns>
        public static string GetCalendarFolderIDByAppointmentItem(AppointmentItem appItem)
        {
            string calendarID = string.Empty;
            try
            {
                if (appItem != null)
                {
                    MAPIFolder mfolder = appItem.Parent as MAPIFolder;
                    if (mfolder != null)
                        calendarID = mfolder.EntryID;
                    else
                    {
                        //OutlookMAPIFolderList listFolder = GetAllAppointmentItemFolders();
                        //if (listFolder != null)
                        //{
                        //    foreach (OutlookMAPIFolder folder in listFolder)
                        //    {                                                                
                        //        if (GetAppointmentItemByEntryIDAndFolder(appItem.EntryID, folder.StoreID) != null)
                        //        {                                    
                        //            calendarID = folder.EntryID;                                        
                        //        }
                        //    }
                        //}
                        AppointmentItem parentApp = appItem.Parent as AppointmentItem;
                        if (parentApp != null)
                        {
                            MAPIFolder mfolder2 = parentApp.Parent as MAPIFolder;
                            if (mfolder2 != null)
                                calendarID = mfolder2.EntryID;
                        }
                    }
                }
            }
            catch //(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);             
            }
            return calendarID;
        }

        //Added by tsrdev1
        //Added datetime 25/10/2010
        public static AppointmentItem GetAppointmentItemInCurrentFolderByEntryIDAndDatetime(string entryID, DateTime startTimeStamp)
        {
            AppointmentItem _OLAppointmentItem = null;

            if (!String.IsNullOrEmpty(entryID) && (entryID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID)) //Retrieves outlook appointment object from outlook entry id
            {
                try
                {
                    //_OLAppointmentItem = OutlookHelper.GetAppointmentItemByEntryID(_OutlookItemID);
                    _OLAppointmentItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(entryID);

                }
                catch (System.Runtime.InteropServices.COMException ex)
                {
                    //Logging.LoggingHandler.LogUnhandledException(ex);
                    _OLAppointmentItem = null;
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
                ///Catch Added for Handling Automatic Synchronization before Closing Outlook
                catch (System.Exception exp)
                {
                    //Logging.LoggingHandler.LogUnhandledException(exp);
                    _OLAppointmentItem = null;
                    System.Diagnostics.Debug.WriteLine(exp.Message);
                }
            }
            if (_OLAppointmentItem != null && _OLAppointmentItem.IsRecurring && _OLAppointmentItem.RecurrenceState == OlRecurrenceState.olApptMaster)
            {
                //Microsoft.Office.Interop.Outlook.AppointmentItem tmpItem = null;
                //if (!String.IsNullOrEmpty(entryID) && (entryID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID)) //Retrieves outlook appointment object from outlook entry id
                //{
                //    try
                //    {
                //        //_OLAppointmentItem = OutlookHelper.GetAppointmentItemByEntryID(_OutlookItemID);
                //        tmpItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(entryID);

                //    }
                //    catch (System.Runtime.InteropServices.COMException ex)
                //    {
                //        //Logging.LoggingHandler.LogUnhandledException(ex);
                //        tmpItem = null;
                //        System.Diagnostics.Debug.WriteLine(ex.Message);
                //    }
                //    ///Catch Added for Handling Automatic Synchronization before Closing Outlook
                //    catch (System.Exception exp)
                //    {
                //        //Logging.LoggingHandler.LogUnhandledException(exp);
                //        tmpItem = null;
                //        System.Diagnostics.Debug.WriteLine(exp.Message);
                //    }
                //}
                //else
                //    tmpItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(_OLAppointmentItem.EntryID);

                DateTime start;
                if (startTimeStamp.Equals(DateTime.MinValue))
                    start = _OLAppointmentItem.Start;
                else
                    start = startTimeStamp;

                //if (tmpItem != null && tmpItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                //{
                try
                {
                    RecurrencePattern pattern = null;
                    pattern = _OLAppointmentItem.GetRecurrencePattern();
                    if (pattern != null)
                    {
                        Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence;
                        try
                        {
                            appointmentOccurrence = pattern.GetOccurrence(start);
                        }
                        catch
                        {
                            appointmentOccurrence = null;
                        }
                        if (appointmentOccurrence != null)
                            return appointmentOccurrence;
                        if (pattern.Exceptions != null)
                        {
                            foreach (Microsoft.Office.Interop.Outlook.Exception exceptionRecurr in pattern.Exceptions)
                            {
                                try
                                {
                                    if (exceptionRecurr.AppointmentItem.Start.Date.Equals(start.Date))
                                    {
                                        return exceptionRecurr.AppointmentItem;
                                    }
                                }
                                catch //(System.Exception ex)
                                {
                                    //TSR.Core.Logging.LoggingHandler.LogError(ex);
                                }
                            }
                        }
                    }
                }
                catch //(System.Exception ex)
                {
                    //TSR.Core.Logging.LoggingHandler.LogError(ex);
                }
                return null;
                //}
                //else
                //    _OLAppointmentItem = null;
            }

            return _OLAppointmentItem;
        }
        /// <summary>
        /// retrieves appointment object in current folder from outlook appointment's entry id
        /// </summary>
        /// <param name="entryID"></param>
        /// <returns></returns>
        public static AppointmentItem GetAppointmentItemInCurrentFolderByEntryID(string entryID)
        {
            try
            {
                //Edit
                MAPIFolder currentfolder = UserSelectedAppointmentFolderForSync;
                if (currentfolder == null)
                    return null;

                object item = CurrentNameSpace.Session.GetItemFromID(entryID, currentfolder.StoreID);
                //System.Reflection.Missing.Value);

                AppointmentItem appointment = item as AppointmentItem;

                //it is possible that appointment was manually deleted and is still in deleted folder, and GetItemFromID
                //method will return that appointment [even if it was deleted, so need to avoid that..]
                MAPIFolder mfolder = appointment.Parent as MAPIFolder;
                if (mfolder != null)
                {
                    //if the appointment was not deleted, it will be inside a calendar folder, 
                    //whose DefaultItemType will be olAppointmentItem
                    if ((mfolder.DefaultItemType != OlItemType.olAppointmentItem) || (mfolder.EntryID != currentfolder.EntryID))
                    {
                        return null;
                    }
                }
                else
                {
                    AppointmentItem parentApp = appointment.Parent as AppointmentItem;
                    if (parentApp != null)
                    {
                        MAPIFolder mfolder2 = parentApp.Parent as MAPIFolder;
                        if (!(mfolder2 != null && mfolder2.EntryID == currentfolder.EntryID))
                            return null;
                    }
                    else
                        return null;
                }
                return appointment;
            }
            catch //(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);
                return null;
            }
        }
        /// <summary>
        /// creates a new appointment from the details retrieved from a time entry object. And that appointment
        /// is tagged to the time entry object
        /// </summary>
        /// <param name="obj"></param>
        public static void CreateNewTimeEntryAppointment(Entity.TimeEntry obj)
        {
            Core.OutlookHelper.CreateCategoriesForTSREntry();
            AppointmentItem ai = UserSelectedAppointmentFolderForSync.Items.Add(OlItemType.olAppointmentItem) as AppointmentItem;
            ai.Subject = obj.Subject;
            ai.Start = obj.StartTimeStamp;
            ai.End = obj.EndTimeStamp;
            ai.Body = obj.Body;
            ai.Location = obj.Location;
            ai.Categories = SetTSRCategory(ai.Categories, obj.Status);

            ai.Save();
            obj.OLAppointmentItem = ai;
            if (GetExchangeMode())
                obj.CalendarID = UserSelectedAppointmentFolderForSync.EntryID;

            Core.TSRFacade.UpdateTimeEntry(obj);

            //Microsoft.Office.Interop.Outlook.Application app = new Microsoft.Office.Interop.Outlook.Application();                        
            //AppointmentItem ai = app.CreateItem(OlItemType.olAppointmentItem) as AppointmentItem;
            //ai.Subject = obj.Subject;
            //ai.Start = obj.StartTimeStamp;
            //ai.End = obj.EndTimeStamp;
            ////string msg = 
            ////if (app.ActiveExplorer().CurrentFolder != AppointmentFolder)
            ////{
            ////    //System.Windows.Forms.MessageBox.Show("You can not create an appointment from selected folder.", "Missing Appointment Folder");
            ////}
            ////else
            ////{
            //    ai.Save();
            ////}
            //obj.OLAppointmentItem = ai;
            //Core.TSRFacade.UpdateTimeEntry(obj);
        }

        public static void CreateNewTimeEntryAppointmentForRecurring(Entity.TimeEntry obj)
        {
            Core.OutlookHelper.CreateCategoriesForTSREntry();
            AppointmentItem ai = UserSelectedAppointmentFolderForSync.Items.Add(OlItemType.olAppointmentItem) as AppointmentItem;
            ai.Subject = obj.Subject;
            ai.Start = obj.StartTimeStamp;
            ai.End = obj.EndTimeStamp;
            ai.Body = obj.Body;
            ai.Location = obj.Location;
            ai.Categories = SetTSRCategory(ai.Categories, obj.Status);

            ai.Save();
            obj.OLAppointmentItem = ai;
            if (GetExchangeMode())
                obj.CalendarID = UserSelectedAppointmentFolderForSync.EntryID;

            Core.TSRFacade.UpdateTimeEntryForRecurring(obj);
        }

        //Added by tsrdev1
        //Added datetime 26/10/2010
        /// <summary>
        /// creates a new appointment from the details retrieved from a time entry object. And that appointment
        /// is tagged to the time entry object
        /// </summary>
        /// <param name="obj"></param>
        public static AppointmentItem CreateNewTimeEntryAppointmentWithoutUpdatingTimeEntry(Entity.TimeEntry obj)
        {
            Core.OutlookHelper.CreateCategoriesForTSREntry();
            AppointmentItem ai = UserSelectedAppointmentFolderForSync.Items.Add(OlItemType.olAppointmentItem) as AppointmentItem;
            ai.Subject = obj.Subject;
            ai.Start = obj.StartTimeStamp;
            ai.End = obj.EndTimeStamp;
            ai.Body = obj.Body;
            ai.Location = obj.Location;
            ai.Categories = SetTSRCategory(ai.Categories, obj.Status);
            ai.Save();
            return ai;
        }


        //added by tsrdev2
        /// <summary>
        /// update for existed appointment from the details retrieved from a time entry object.
        /// return true if appoiment has been changed.
        /// </summary>
        /// <param name="obj"></param>
        public static bool UpdateTimeEntryAppointment(AppointmentItem appOld, Entity.TimeEntry obj)
        {
            bool success = false;
            try
            {
                appOld.Subject = obj.Subject;
                appOld.Start = obj.StartTimeStamp;
                appOld.End = obj.EndTimeStamp;
                appOld.Body = obj.Body;
                appOld.Location = obj.Location;
                if (!appOld.IsRecurring)
                    appOld.Categories = SetTSRCategory(appOld.Categories, obj.Status); ;

                appOld.Save();
                success = true;
            }
            catch //(System.Exception ex)
            {
                //Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return success;
        }


        //Added by tsrdev1
        //Added datetime 03/11/2010
        public static bool IsChangedAppointment(AppointmentItem appOld, TSR.Core.UserAgentService.TimeEntry obj)
        {
            bool isChanged = false;
            if (((!string.IsNullOrEmpty(appOld.Subject) && string.IsNullOrEmpty(obj.Subject)) ||
                (string.IsNullOrEmpty(appOld.Subject) && !string.IsNullOrEmpty(obj.Subject))) ||
                (!string.IsNullOrEmpty(appOld.Subject) && !string.IsNullOrEmpty(obj.Subject) && appOld.Subject != obj.Subject))
            {
                return true;
            }
            if (appOld.Start != obj.StartTimeStamp)
            {
                return true;
            }
            if (appOld.End != obj.EndTimeStamp)
            {
                return true;
            }
            if (((!string.IsNullOrEmpty(appOld.Body) && string.IsNullOrEmpty(obj.Body)) ||
                (string.IsNullOrEmpty(appOld.Body) && !string.IsNullOrEmpty(obj.Body))) ||
                (!string.IsNullOrEmpty(appOld.Body) && !string.IsNullOrEmpty(obj.Body) && appOld.Body != obj.Body))
            {
                return true;
            }
            if (((!string.IsNullOrEmpty(appOld.Location) && string.IsNullOrEmpty(obj.Location)) ||
                (string.IsNullOrEmpty(appOld.Location) && !string.IsNullOrEmpty(obj.Location))) ||
                (!string.IsNullOrEmpty(appOld.Location) && !string.IsNullOrEmpty(obj.Location) && appOld.Location != obj.Location))
            {
                return true;
            }
            string newCategories = SetTSRCategory(appOld.Categories, obj.Status);

            if (!appOld.IsRecurring)
            {
                if (appOld.Categories != newCategories)
                {
                    return true;
                }
            }
            return isChanged;
        }


        /// <summary>
        /// creates a new appointment from the details retrieved from a time entry object. And that appointment
        /// is tagged to the time entry object to Appointment Folder
        /// </summary>
        /// <param name="obj"></param>
        //public static void CreateNewTimeEntryAppointmentInAppointmentFolder(Entity.TimeEntry obj)
        //{
        //    AppointmentItem ai = AppointmentFolder.Items.Add(OlItemType.olAppointmentItem) as AppointmentItem;
        //    ai.Subject = obj.Subject;
        //    ai.Start = obj.StartTimeStamp;
        //    ai.End = obj.EndTimeStamp;
        //    ai.Save();
        //    obj.OLAppointmentItem = ai;
        //    Core.TSRFacade.UpdateTimeEntry(obj);
        //}


        /// <summary>
        /// Method for creating outlook folder, might needed if calendar folder needs to be created
        /// </summary>
        /// <param name="folderName"></param>
        /// <returns></returns>
        public static MAPIFolder AddFolder(String folderName)
        {
            MAPIFolder _folder = null;
            try
            {
                _folder = CurrentNameSpace.Folders.Add(folderName, OlDefaultFolders.olPublicFoldersAllPublicFolders);
            }
            catch //(System.Exception exp)
            {
                //Core.Logging.LoggingHandler.LogError(exp);
            }
            return _folder;
        }

        /// <summary>
        /// Retrieves user selected appointment folder for synchronization
        /// </summary>
        /// <returns></returns>
        public static MAPIFolder GetUserSelectedAppointmentFolderForSynchronization()
        {
            string savedFolderEntryID = string.Empty;
            string savedFolderName = string.Empty;
            string folderEntryIdForExistingSameNamedFolder = string.Empty;

            MAPIFolder userSelectedAppFolderForSync = null;

            //get folder name and entry id as saved in settings
            string[] appFolderEntryIdandName = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync(), Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);

            if (appFolderEntryIdandName != null && appFolderEntryIdandName.Length > 0)
            {
                savedFolderEntryID = appFolderEntryIdandName[0];
                if (appFolderEntryIdandName.Length > 1)
                {
                    savedFolderName = appFolderEntryIdandName[1];
                }
            }


            //loop through appointment folders to check whether any matching folder 
            //with same entry id, or if not entry id at least same folder name exists
            Core.OutlookMAPIFolderList appFolderList = GetAllAppointmentItemFolders();

            foreach (Core.OutlookMAPIFolder appFolder in appFolderList)
            {
                if (appFolder.EntryID == savedFolderEntryID)
                {
                    //we got a matching entry id, so try to get the folder..
                    try
                    {
                        userSelectedAppFolderForSync = Core.OutlookHelper.GetFolderByEntryID(savedFolderEntryID.ToString());
                    }
                    catch //(System.Exception ex)
                    {
                        //could not get the appointment folder from it's entry id!
                        //Logging.LoggingHandler.LogUnknownException(ex);
                        userSelectedAppFolderForSync = null;
                    }
                    if (userSelectedAppFolderForSync != null)
                        return userSelectedAppFolderForSync;
                }
                //save the entry id in case we need it [if entry id match is not found during the loop processing,
                //when loop is done, we will use this id to at least return a calendar folder which has the same name
                if (appFolder.FolderName == savedFolderName)
                    folderEntryIdForExistingSameNamedFolder = appFolder.EntryID;

            }

            //as we are here, it means entry id match is not found during the loop processing,
            //now, we will use folder Entry Id For Existing Same Named Folder to at least 
            //return a calendar folder which has the same name
            if (!string.IsNullOrEmpty(folderEntryIdForExistingSameNamedFolder))
            {
                try
                {
                    userSelectedAppFolderForSync = Core.OutlookHelper.GetFolderByEntryID(folderEntryIdForExistingSameNamedFolder);
                }
                catch //(System.Exception ex)
                {
                    //Logging.LoggingHandler.LogUnknownException(ex);
                    userSelectedAppFolderForSync = null;
                }
                return userSelectedAppFolderForSync;
            }
            //if (!String.IsNullOrEmpty(_folderEntityID) && objectInList)
            //{

            //    _appointmentFolder = Core.OutlookHelper.GetFolderByEntryID(_folderEntityID.ToString());
            //    if (_appointmentFolder == null)
            //        objectInList = false;

            //}
            //else if (_appointmentFolder == null && !String.IsNullOrEmpty(_folderName) && !objectInList)
            //{
            //    try
            //    {
            //        _appointmentFolder = Core.OutlookHelper.AddFolder(_folderName);
            //    }
            //    catch (System.Exception exp)
            //    {
            //        Core.Logging.LoggingHandler.LogError(exp);
            //    }
            //}
            return null;
        }

        /// <summary>
        /// Retrieves user selected appointment folder for synchronization. Don't check existing name in the case ID is not found
        /// </summary>
        /// <returns></returns>
        public static MAPIFolder GetUserSelectedAppointmentFolderForSynchronization_NotCheckedSameName()
        {
            string savedFolderEntryID = string.Empty;
            MAPIFolder userSelectedAppFolderForSync = null;

            //get folder name and entry id as saved in settings
            string[] appFolderEntryIdandName = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync(), Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);

            if (appFolderEntryIdandName != null && appFolderEntryIdandName.Length > 0)
            {
                savedFolderEntryID = appFolderEntryIdandName[0];
            }
            try
            {
                userSelectedAppFolderForSync = Core.OutlookHelper.GetFolderByEntryID(savedFolderEntryID.ToString());
            }
            catch (System.Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                userSelectedAppFolderForSync = null;
            }
            return userSelectedAppFolderForSync;
        }

        internal static bool IsAppointmentInThisFolderIfExists(string OutlookAppointmentEntryID, MAPIFolder MapiFolder)
        {
            //string logTime = string.Format("OutlookHelper.IsAppointmentInThisFolderIfExists: {0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());                       
            object item;
            try
            {
                MAPIFolder currentfolder = UserSelectedAppointmentFolderForSync;
                //logTime += "-->" + string.Format("{0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());
                if (currentfolder == null)
                    return true;
                //item = CurrentNameSpace.GetItemFromID(OutlookAppointmentEntryID, DefaultAppointmentFolder.StoreID);
                item = CurrentNameSpace.GetItemFromID(OutlookAppointmentEntryID, currentfolder.StoreID);
                //System.Reflection.Missing.Value);
                //logTime += "-->" + string.Format("{0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());

            }
            catch //(System.Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);
                return true; //appointment not found, that means appointment is not in this folder, but method will return
                //false only when appointment is there and it is not in given folder
            }
            AppointmentItem appointment = item as AppointmentItem;
            //check the parent folder
            bool result = IsAppointmentInGivenFolder(appointment, MapiFolder);

            //logTime += "-->" + string.Format("{0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());
            //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = logTime });

            return result;
        }

        public static bool IsAppointmentInGivenFolder(AppointmentItem Appointment, MAPIFolder MapiFolder)
        {
            MAPIFolder mfolder = Appointment.Parent as MAPIFolder;
            if (mfolder != null)
                return (mfolder.EntryID == MapiFolder.EntryID);
            else
            {
                AppointmentItem parentApp = Appointment.Parent as AppointmentItem;
                if (parentApp != null)
                {
                    MAPIFolder mfolder2 = parentApp.Parent as MAPIFolder;
                    if (mfolder2 != null)
                        return (mfolder2.EntryID == MapiFolder.EntryID);
                }
            }
            return false;
        }

        public static bool IsAppointmentInGivenFolder_temp(AppointmentItem Appointment, MAPIFolder MapiFolder)
        {
            string[] appFolderEntryIdandName = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync(),
                Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);

            if (MapiFolder != null && appFolderEntryIdandName != null && appFolderEntryIdandName.Length > 0)
            {
                if (MapiFolder.EntryID != appFolderEntryIdandName[0])
                {
                    TSR.Core.SettingsHelper.SetTSROutlookFolderToSync(MapiFolder.EntryID + Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR + MapiFolder.Name);
                }
            }
            try
            {
                MAPIFolder mfolder = Appointment.Parent as MAPIFolder;
                if (mfolder != null)
                    return (mfolder.EntryID == MapiFolder.EntryID);
                else
                {
                    AppointmentItem parentApp = Appointment.Parent as AppointmentItem;
                    if (parentApp != null)
                    {
                        MAPIFolder mfolder2 = parentApp.Parent as MAPIFolder;
                        if (mfolder2 != null)
                            return (mfolder2.EntryID == MapiFolder.EntryID);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
                return false;
            }
            return false;
        }

        public static bool IsAppointmentInGivenFolder(AppointmentItem Appointment)
        {
            bool result = false;
            MAPIFolder mfolder = Appointment.Parent as MAPIFolder;
            string[] appFolderEntryIdandName = Core.MiscHelper.ParseStringBySeperator(TSR.Core.SettingsHelper.GetTSROutlookFolderToSync(), Core.Constants.DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR);

            if (appFolderEntryIdandName == null || appFolderEntryIdandName.Length == 0)
            {
                MAPIFolder defaultAppointmentFolder = DefaultAppointmentFolder;
                appFolderEntryIdandName = new string[2] { defaultAppointmentFolder.EntryID, defaultAppointmentFolder.Name };
            }

            if (mfolder != null)
                return (string.Compare(mfolder.EntryID, appFolderEntryIdandName[0], true) == 0);
            else
            {
                AppointmentItem parentApp = Appointment.Parent as AppointmentItem;
                if (parentApp != null)
                {
                    MAPIFolder mfolder2 = parentApp.Parent as MAPIFolder;
                    if (mfolder2 != null)
                        return (string.Compare(mfolder2.EntryID, appFolderEntryIdandName[0], true) == 0);
                }
            }

            return result;
        }

        /// <summary>
        /// Checks whether a time entry is in user selected calendar folder for synchronization
        /// </summary>
        /// <param name="te"></param>
        /// <returns></returns>
        public static bool TimeEntryIsInSelectedFolderForSynchronization(string OutlookItemID)
        {
            //string logTime = string.Format("OutlookHelper.TimeEntryIsInSelectedFolderForSynchronization: {0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());
            MAPIFolder userSelectedAppointmentFolderForSync = UserSelectedAppointmentFolderForSync;
            //logTime += "-->" + string.Format("{0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());
            bool result = IsAppointmentInThisFolderIfExists(OutlookItemID, userSelectedAppointmentFolderForSync);
            //logTime += "-->" + string.Format("{0}:{1}:{2}", DateTime.Now.Minute.ToString(), DateTime.Now.Second.ToString(), DateTime.Now.Millisecond.ToString());
            //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = logTime});
            return result;
        }

        public static void GetDateTimeFormat(out string dateFormat, out string timeFormat, bool includeSecond)
        {
            dateFormat = string.Empty;
            timeFormat = string.Empty;
            if (!TSR.Core.SettingsHelper.TSRDateFormat.Equals("NA"))
                dateFormat = ReverseToHTMLCode(TSR.Core.SettingsHelper.TSRDateFormat);
            else
                dateFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            if (!TSR.Core.SettingsHelper.TSRTimeFormat.Equals("NA"))
                timeFormat = TSR.Core.SettingsHelper.TSRTimeFormat;
            else
                timeFormat = CultureInfo.CurrentCulture.DateTimeFormat.ShortTimePattern;
            if (!includeSecond)
                timeFormat = timeFormat.Replace(":ss", "");
        }

        public static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck.GetType() == typeof(string))
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }

        public static string SetTSRCategory(string appCategories, UserAgentService.StatusEnum teStatus)
        {
            string result = string.Empty;
            string currentCategories = !string.IsNullOrEmpty(appCategories) ? appCategories : string.Empty;
            string tsrCategory = teStatus.ToString() + " " + TSR.Core.Constants.CATEGORY;
            if (currentCategories.Length > 0)
            {
                string cateSeparator = GetCategorySeparator();
                List<string> lstCurrentCategories = currentCategories.Split(new string[] { cateSeparator }, StringSplitOptions.RemoveEmptyEntries).ToList();
                List<string> lstTSRCategories = new List<string>();
                var values = Enum.GetValues(typeof(UserAgentService.StatusEnum));
                foreach (UserAgentService.StatusEnum status in values)
                {
                    lstTSRCategories.Add(status.ToString() + " " + TSR.Core.Constants.CATEGORY);
                }
                //check if one TSR category has been existed in the currentCategories
                List<string> lstExisted = lstTSRCategories.FindAll(delegate(string s)
                {
                    return lstCurrentCategories.Contains(s);
                });

                if (lstExisted.Count > 0)
                    foreach (string existedStatus in lstExisted)
                    {
                        lstCurrentCategories.Remove(existedStatus);
                    }
                //add new TSR category
                lstCurrentCategories.Add(tsrCategory);

                for (int i = 0; i < lstCurrentCategories.Count; i++)
                {
                    if (i == lstCurrentCategories.Count - 1)
                        result += lstCurrentCategories[i];
                    else
                        result += lstCurrentCategories[i] + Core.Constants.CATEGORIES_SEPARATOR_DEFAULT;
                }
            }
            else result = tsrCategory;

            return result;
        }

        public static string RemoveTSRCategory(string appCategories, UserAgentService.StatusEnum teStatus)
        {
            string result = string.Empty;
            string currentCategories = !string.IsNullOrEmpty(appCategories) ? appCategories : string.Empty;
            string tsrCategory = teStatus.ToString() + " " + TSR.Core.Constants.CATEGORY;
            if (currentCategories.Length > 0)
            {
                string cateSeparator = GetCategorySeparator();
                List<string> lstCurrentCategories = currentCategories.Split(new string[] { cateSeparator }, StringSplitOptions.RemoveEmptyEntries).ToList();
                if (lstCurrentCategories.Contains(tsrCategory))
                    lstCurrentCategories.RemoveAt(lstCurrentCategories.IndexOf(tsrCategory));

                for (int i = 0; i < lstCurrentCategories.Count; i++)
                {
                    if (i == lstCurrentCategories.Count - 1)
                        result += lstCurrentCategories[i];
                    else
                        result += lstCurrentCategories[i] + Core.Constants.CATEGORIES_SEPARATOR_DEFAULT;
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appCategories">Categories of the appointment</param>
        /// <param name="isLast">true if the TSR category is last added</param>
        /// <returns></returns>
        public static bool CheckInvalidTSRCategory(string appCategories)
        {
            string cateSeparator = GetCategorySeparator();
            string currentCategories = !string.IsNullOrEmpty(appCategories) ? appCategories : string.Empty;
            List<string> lstCurrentCategories = currentCategories.Split(new string[] { cateSeparator }, StringSplitOptions.RemoveEmptyEntries).ToList();

            if (lstCurrentCategories.Count == 0) return true;

            List<string> lstTSRCategories = new List<string>();
            var values = Enum.GetValues(typeof(UserAgentService.StatusEnum));
            foreach (UserAgentService.StatusEnum status in values)
            {
                lstTSRCategories.Add(status.ToString() + " " + TSR.Core.Constants.CATEGORY);
            }

            //check if one TSR category has been existed in the currentCategories
            List<string> lstExisted = lstTSRCategories.FindAll(delegate(string s)
            {
                return lstCurrentCategories.Contains(s);
            });

            return lstExisted.Count >= 2 || lstExisted.Count == 0;
        }

        private static string GetCategorySeparator()
        {
            System.Threading.Thread.CurrentThread.CurrentCulture.ClearCachedData();
            return System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ListSeparator + " ";
        }

        public static MailItem CreateNewEmail(params string[]files)
        {
            MailItem mailItem = null;
            try
            {
                mailItem = (MailItem)OutlookHelper.CurrentApplication.CreateItem(OlItemType.olMailItem);
                mailItem.Subject = "Support Log Files";
                mailItem.To = "support@timesheetreporter.com";
                mailItem.Body = "Write some additional info here if you wish.";
                mailItem.Importance = OlImportance.olImportanceLow;
                foreach (string file in files)
                {
                    mailItem.Attachments.Add(file, OlAttachmentType.olByValue, Type.Missing, Type.Missing);
                }
                //mailItem.Attachments.Add(path + "settings.txt", OlAttachmentType.olByValue, Type.Missing, Type.Missing);
                //mailItem.Attachments.Add(path + LoggingHandler.GetLogFileName(), OlAttachmentType.olByValue, Type.Missing, Type.Missing);
            }
            catch (System.Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            return mailItem;
        }

    }
}
