using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using TSR.Core.Entity;
using TSR.Core.Entity.List;
using Microsoft.Win32;
using WS = TSR.Core.UserAgentService;
using System.Threading;

namespace TSR.Core
{
    /// <summary>
    /// This class is used to synchronize setup and time entry data from tsr database by using web services. It works in a background thread
    /// so that the process will not block the ui from normal interaction. This also makes sure multiple synchronizations [automatic 
    /// and manual] do not happen at the same time.
    /// </summary>
    public class SyncEngine : IDisposable
    {
        #region Private shared variables

        private Form _settings;
        private TimeEntryList _timeEntryList;
        private TimeEntryList _needOverwriteTimeEntries;
        //Added by tsrdev1
        //Added datetime 19/11/2010
        private List<Guid> _listNeverRecreatedTimeEntryIDs;
        private BackgroundWorker _worker;
        private static SyncEngine syncEngine;

        private bool _saveFavorites = false;
        private bool _getFavorites = false;
        private bool _saveSettings = false;
        private bool _getSettings = false;
        private bool _getDefaultSettings = false;

        //
        private bool _forceFulSync = false;

        public bool DoAsBackGroundWorker = true; //check for backgroud wroker
        private IMemoryBox _memBox;
        public ISyncEngineCheckListTimeEntry _checkListTimeEntry;
        public ISyncEngineOverwriteTimeEntry _overwriteTimeEntries;

        public static bool _IsFirstSyncOfOutlookSession = true;
        public static bool _IsAccountHasBeenChanged = false;

        public static AutoResetEvent _resetEvent = new AutoResetEvent(false);

        #endregion

        #region Message Structure for progress change event

        public struct SyncMessage
        {
            public string Message;
            public SyncStatus Status;
            public TimeEntryList UpdatedTimeEntries;
        }

        public enum SyncStatus
        {
            Undefined,
            Normal,
            Error,
            Completed,
            CompletedWithErrors
        };

        #endregion

        #region Progress change events [to use from outside]

        public delegate void SynchronizationProgressChanged(object sender, ProgressChangedEventArgs e);
        public event SynchronizationProgressChanged ProgressChanged;

        public delegate void SynchronizationCompleted(object sender, RunWorkerCompletedEventArgs e);
        public event SynchronizationCompleted Completed;

        #endregion

        #region Singleton methods

        public static SyncEngine GetInstance(Form SettingsForm)
        {
            if (syncEngine == null)
            {
                syncEngine = new SyncEngine();
                syncEngine._settings = SettingsForm;
                return syncEngine;
            }
            else
            {
                return syncEngine;
            }
        }

        public static SyncEngine GetSingleton()
        {
            return syncEngine;
        }
        /// <summary>
        /// Save User Settings In Server form OUA 
        /// </summary>
        public void SaveUserSettingsInServer()
        {
            try
            {
                bool success = TSRFacade.SaveUserSettingsInServer();
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        public static SyncEngine GetInstance()
        {
            return GetInstance(null);
        }

        private SyncEngine()
        {
            if (DoAsBackGroundWorker) ///check backgroudwroker status
                InitializeSynchronizationBackgroundWorker();

        }

        #endregion

        #region Threading methods

        /// <summary>
        /// Initializes background thread
        /// </summary>
        private void InitializeSynchronizationBackgroundWorker()
        {
            _worker = new BackgroundWorker();            
            _worker.WorkerReportsProgress = true;
            //worker.WorkerSupportsCancellation = true;
            _worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            _worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);
            _worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
        }

        /// <summary>
        /// starts synchronization in background thread, overloaded method 
        /// unless these parameters are passed, favorites and user settings will not be sent or recieved from server.
        /// </summary>
        /// <param name="SaveFavorites"></param>
        /// <param name="GetFavorites"></param>
        /// <param name="SaveSettings"></param>
        /// <param name="GetSettings"></param>
        public void StartSynchornization(bool SaveFavorites, bool GetFavorites, bool SaveSettings, bool GetSettings, bool GetDefaultSettings, bool ForceFullSync, IMemoryBox MemoryBox)
        {
            _saveFavorites = SaveFavorites;
            _getFavorites = GetFavorites;
            _saveSettings = SaveSettings;
            _getSettings = GetSettings;
            _getDefaultSettings = GetDefaultSettings;
            _forceFulSync = ForceFullSync;
            StartSynchornization(MemoryBox);
        }
        /// <summary>
        /// starts synchronization in background thread
        /// </summary>
        public void StartSynchornization(IMemoryBox MemoryBox)
        {
            _memBox = MemoryBox;

            _resetEvent = new AutoResetEvent(false);
            ///check backgroudwroker status
            if (!_worker.IsBusy)
            {
                if (DoAsBackGroundWorker)
                    _worker.RunWorkerAsync();
                else
                {
                    if (!TSR.Core.TSRFacade.GetExchangeMode())
                        SyncronizeTimeEntries(null);
                    else
                        SyncronizeTimeEntriesWithExchange(null);
                }
            }
        }
        /// <summary>
        /// event, when background thread starts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = sender as BackgroundWorker;
            if (bw != null)
            {
                if (!TSR.Core.TSRFacade.GetExchangeMode())
                    SyncronizeTimeEntries(bw);
                else
                    SyncronizeTimeEntriesWithExchange(bw);
            }
            syncEngine = null;
            _resetEvent.Set();
        }

        /// <summary>
        /// event when a status is changed in thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.UserState != null)
            {
                Core.SyncEngine.SyncMessage progressMessage = (Core.SyncEngine.SyncMessage)e.UserState;

                switch (progressMessage.Status)
                {
                    case Core.SyncEngine.SyncStatus.Completed:
                        //InformChangesToOpenScreens();
                        break;
                }

                if (ProgressChanged != null)
                {
                    ProgressChanged(sender, e);
                }
            }
        }

        /// <summary>
        /// background thread's task is done
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (Completed != null)
            {
                if (DoAsBackGroundWorker) ///check the process works as a backgroudworker
                    Completed(sender, e);
            }
            syncEngine = null;
        }

        #endregion

        #region Synchronization Methods

        /// <summary>
        /// main method which centrally calls all other methods to call the necessary services
        /// </summary>
        /// <param name="bgWorker"></param>
        private void SyncronizeTimeEntries(BackgroundWorker bgWorker)
        {
            try
            {
                bool isLoadUserAgentData = false;

                if (!ServerAddressFound(bgWorker))
                {
                    ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, null);//report to user that process is done
                    return;
                }
                if (!LogInUserToServer(bgWorker))
                {
                    ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, null);//report to user that process is done
                    return;
                }
                TSR.Core.Constants.ISLOCKEDUSERSETTING = TSRFacade.IsLockedUserSetitng();

                if (FetchAndProcessLicenseInformation(bgWorker))
                {
                    if (!TSRFacade.LocalDataExists() || _IsAccountHasBeenChanged)
                    {
                        isLoadUserAgentData = true;
                        _IsFirstSyncOfOutlookSession = true;
                        FetchAndProcessUserAgentData(bgWorker);
                    }
                    if (_saveFavorites)
                        SaveFavoritesInServer(bgWorker);//saves favorites in sevre
                    if (_getFavorites)
                        FetchAndProcessFavorites(bgWorker);//gets favorites from server

                    if (!(TSR.Core.Constants.ISLOCKEDUSERSETTING))
                    {
                        if (_saveSettings)
                            SaveSettingsInServer(bgWorker);//saves settings in server                    
                    }

                    //Restore setup data
                    if (!(isLoadUserAgentData) && (_IsFirstSyncOfOutlookSession || _forceFulSync))
                    {
                        RestoreSetupDataFromServer(bgWorker);
                    }

                    //Checks valid setup data
                    if (_IsFirstSyncOfOutlookSession || _forceFulSync)
                    {
                        CheckValidDataBeforeSynchronizing(bgWorker);
                        _IsFirstSyncOfOutlookSession = false;
                    }

                    if (TSR.Core.SettingsHelper.SynchronizeTSRSetupData)//check the setting and gets setup data from server and store it locally
                        FetchAndProcessSetupData(bgWorker, _forceFulSync);

                    if (TSR.Core.SettingsHelper.SynchronizeTSREntries)
                    {
                        SubmitTimeEntries(bgWorker);//submits time entries

                        ProcessTimeEntries(bgWorker, _memBox);//gets the response/status of the time entries from server

                        //Delete never recreated time entries (if necessary)
                        if (_listNeverRecreatedTimeEntryIDs != null && _listNeverRecreatedTimeEntryIDs.Count > 0)
                            DeleteTimeEntries(bgWorker);
                    }

                    //Sync Lock period
                    SyncLockPeriod(bgWorker);

                    //Update lockperiod setting
                    UpdateLockPeriodSetting(bgWorker);

                    if ((_getSettings) || (_getDefaultSettings))
                        FetchAndProcessSettings(bgWorker, _getDefaultSettings);//gets settings from server

                    FetchAndProcessPreferredLanguages(bgWorker);//gets preferred languages from server
                    FetchAndProcessResourceData(bgWorker);//gets resource data from server

                    SaveUserAgentData(bgWorker);
                }

                ReportSyncMessage(bgWorker, string.Empty, SyncStatus.Completed, _timeEntryList);//report to user that process is done
            }
            catch (Exception exp)
            {
                Logging.LoggingHandler.LogUnhandledException(exp);
                System.Diagnostics.Debug.WriteLine(exp.Message);
                ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, _timeEntryList);//report to user that process is done
            }
        }

        //Added by tsrdev1
        //Added datetime 13/10/2010
        /// <summary>
        /// main method which centrally calls all other methods to call the necessary services with exchange mode
        /// </summary>
        /// <param name="bgWorker"></param>
        private void SyncronizeTimeEntriesWithExchange(BackgroundWorker bgWorker)
        {
            try
            {
                bool isLoadUserAgentData = false;
                if (!ServerAddressFound(bgWorker))
                {
                    ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, null);//report to user that process is done
                    return;
                }

                if (!LogInUserToServer(bgWorker))
                {
                    ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, null);//report to user that process is done
                    return;
                }                

                TSR.Core.Constants.ISLOCKEDUSERSETTING = TSRFacade.IsLockedUserSetitng();

                if (FetchAndProcessLicenseInformation(bgWorker))
                {

                    TSR.Core.Constants.USERINEXPENSELICENSE = TSRExpenseFacade.UserInExpenseLicense();

                    //Add by tsrdev: remove local data

                    if (TSRFacade.LocalDataExists() && _forceFulSync)
                    {
                        RemoveDataFromDataSet();
                    }

                    if (!TSRFacade.LocalDataExists() || _IsAccountHasBeenChanged)
                    {
                        _IsAccountHasBeenChanged = false;
                        isLoadUserAgentData = true;
                        _IsFirstSyncOfOutlookSession = true;
                        FetchAndProcessUserAgentData(bgWorker);
                    }

                    if (_saveFavorites)
                        SaveFavoritesInServer(bgWorker);//saves favorites in sevre
                    if (_getFavorites)
                        FetchAndProcessFavorites(bgWorker);//gets favorites from server
                    if (!(TSR.Core.Constants.ISLOCKEDUSERSETTING))
                    {
                        if (_saveSettings)
                            SaveSettingsInServer(bgWorker);//saves settings in server                    
                    }
                    //Restore setup data
                    if (!isLoadUserAgentData && _IsFirstSyncOfOutlookSession && !_forceFulSync)
                    {
                        RestoreSetupDataFromServer(bgWorker);
                    }
                    //Checks valid setup data
                    if (_IsFirstSyncOfOutlookSession || _forceFulSync)
                    {
                        CheckValidDataBeforeSynchronizing(bgWorker);
                        _IsFirstSyncOfOutlookSession = false;
                    }
                    if (TSR.Core.SettingsHelper.SynchronizeTSRSetupData)//check the setting and gets setup data from server and store it locally
                        FetchAndProcessSetupData(bgWorker, _forceFulSync);

                    if (TSR.Core.SettingsHelper.SynchronizeTSREntries)
                    {
                        SubmitTimeEntries(bgWorker);//submits time entries

                        if (TSR.Core.Constants.USERINEXPENSELICENSE)
                        {
                            SubmitExpenses(bgWorker);
                        }

                        if (_needOverwriteTimeEntries != null && _needOverwriteTimeEntries.Count > 0)
                        {
                            OverwriteTimeEntries(bgWorker); //overwrite time entries
                        }

                        //SubmitRecurringMasters(bgWorker);

                        ProcessTimeEntries(bgWorker, _memBox);//gets the response/status of the time entries from server                                                
                        //ProcessRecurringMasters(bgWorker);

                        if (TSR.Core.Constants.USERINEXPENSELICENSE)
                        {
                            ProcessExpenses(bgWorker, _memBox);
                        }

                        //Delete never recreated time entries (if necessary)
                        if (_listNeverRecreatedTimeEntryIDs != null && _listNeverRecreatedTimeEntryIDs.Count > 0)
                        {
                            DeleteTimeEntries(bgWorker);
                        }
                    }

                    //Sync Lock period
                    SyncLockPeriod(bgWorker);
                    //Update lockperiod setting
                    UpdateLockPeriodSetting(bgWorker);

                    if ((_getSettings) || (_getDefaultSettings))
                        FetchAndProcessSettings(bgWorker, _getDefaultSettings);//gets settings from server

                    FetchAndProcessPreferredLanguages(bgWorker);//gets preferred languages from server
                    FetchAndProcessResourceData(bgWorker);//gets resource data from server

                    SaveUserAgentData(bgWorker);
                }
                
                ReportSyncMessage(bgWorker, string.Empty, SyncStatus.Completed, _timeEntryList);//report to user that process is done
            }
            catch (Exception exp)
            {
                Logging.LoggingHandler.LogUnhandledException(exp);
                System.Diagnostics.Debug.WriteLine(exp.Message);
                ReportSyncMessage(bgWorker, string.Empty, SyncStatus.CompletedWithErrors, _timeEntryList);//report to user that process is done
            }
        }

        //add by tsrdev: remove local data
        private void RemoveDataFromDataSet()
        {
            try
            {
                //DAL.BaseDAL.MyDataSet.TimeEntry.Clear();
                //DAL.BaseDAL.MyDataSet.TimeEntry_OutlookAppointment.Clear();
                DAL.BaseDAL.MyDataSet.Organization.Clear();
                DAL.BaseDAL.MyDataSet.Organization_Contact.Clear();
                DAL.BaseDAL.MyDataSet.Organization_Project.Clear();
                DAL.BaseDAL.MyDataSet.Project.Clear();
                DAL.BaseDAL.MyDataSet.Project_Activity.Clear();
                DAL.BaseDAL.MyDataSet.Activity.Clear();
                DAL.BaseDAL.MyDataSet.Contact.Clear();
                DAL.BaseDAL.MyDataSet.ExpenseType.Clear();
                DAL.BaseDAL.MyDataSet.Location.Clear();
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnhandledException(ex);
            }
        }
        //End remove local data

        /// <summary>
        /// tsrdev4
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        protected bool CheckLicenseDemo()
        {
            string error = string.Empty;
            WS.ApplicationLicense license = TSRFacade.FetchAndProcessLicenseInformation(ref error);
            if (license != null)
            {
                if (license.LicenseType == TSR.Core.UserAgentService.LicenseTypes.Demo)
                {
                    string val = string.Empty;

                    val = license.MaintenanceExpiry.Date.ToString();
                    if (val != "")
                    {
                        DateTime dateEnd = license.MaintenanceExpiry.Date;
                        if (dateEnd > DateTime.Today)
                            return true;
                    }

                }
            }
            return false;
        }


        // end edit

        private bool CheckLicenseVersion(WS.ApplicationLicense aLicense)
        {
            string strVersion = aLicense.Version;
            string[] arrSubVersion = strVersion.Split('.');
            if (arrSubVersion.Length == 1)
            {
                strVersion = strVersion + ".0";
            }
            else if (arrSubVersion.Length == 2)
            {

            }
            else if (arrSubVersion.Length > 2)
            {
                strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
            }

            //if (strVersion != TSR.Core.Constants.Version)
            //{
            //    //MessageContainer msgContainer;
            //    //string message = string.Empty;

            //    //message = ResourceManager.GetResourceString("InvalidLicense", "Invalid license");
            //    //msgContainer = new MessageContainer(MessageTypeEnum.Failure, message, null);
            //    //CustomMaster.Parameters.Add(msgContainer);
            //    return false;
            //}
            return true;
        }

        private bool FetchAndProcessLicenseInformation(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = false;
                string error = string.Empty;
                bool isDemo = false;
                WS.ApplicationLicense license = TSRFacade.FetchAndProcessLicenseInformation(ref error);
                if (license != null)
                {
                    if (!CheckLicenseVersion(license))
                    {
                        //success = false;
                    }
                    else
                    {
                        success = true;
                        if (license.LicenseType == TSR.Core.UserAgentService.LicenseTypes.Demo)
                        {
                            isDemo = true;
                            success = CheckLicenseDemo();

                        }
                    }
                }

                if (success)
                {

                    ReportSyncMessage(bgWorker, TSR.Core.ResourceHelper.LicenseRetrievalInOUASuccessful + Environment.NewLine, SyncStatus.Normal, null);
                    if (!isDemo)
                    {
                        foreach (Core.UserAgentService.ModuleLicense item in license.Modules)
                        {
                            if (item.Key.Contains("TSR-EXP"))
                                continue;

                            if (item.FunctionalExpiryDate < DateTime.Today)
                            {
                                success = false;
                                string strSynchroinzation = ResourceManager.GetResourceString("SynchronizationWillStopNow", "Synchronization will stop now..");
                                ReportSyncMessage(bgWorker, ResourceHelper.LicenseHasBeenExpired + Environment.NewLine + strSynchroinzation + Environment.NewLine, SyncStatus.Normal, null);
                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    Priority = 0,
                                    MessageSummary = ResourceHelper.LicenseHasBeenExpired
                                });
                                break;
                            }
                        }
                    }
                }
                else
                {
                    ReportSyncMessage(bgWorker, ResourceHelper.LicenseRetrievalInOUAFailed + Environment.NewLine
                        + ResourceHelper.PleaseContactYourAdministrator + Environment.NewLine, SyncStatus.Error, null);
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.LicenseRetrievalInOUAFailed
                    });
                }

                if (!string.IsNullOrEmpty(error))
                {
                    ReportSyncMessage(bgWorker, error + Environment.NewLine, SyncStatus.Error, null);
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = error
                    });
                }

                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, Environment.NewLine +
                    ResourceHelper.ErrorRetrievingLicenseInfoInOUA
                    + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        private bool FetchAndProcessUserAgentData(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.GetUserAgentDataFromServer();
                if (success)
                {
                    #region Reset Proxy settings for the first time if UseAutoProxy is set
                    if (SettingsHelper.ProxyAutoUsing)
                    {
                        SettingsHelper.ProxyType = SettingsHelper.ProxyTypeEnum.SystemProxy;
                        SettingsHelper.ProxyAutoSwitch = true;
                    }
                    #endregion

                    ReportSyncMessage(bgWorker,
                                        ResourceHelper.RetrievingUserAgentDataSuccessful
                                        + Environment.NewLine, SyncStatus.Normal, null);
                }
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.RetrievingUserAgentDataFailed
                    });
                    ReportSyncMessage(bgWorker, ResourceHelper.RetrievingUserAgentDataFailed + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, Environment.NewLine + ResourceHelper.ErrorRetrievingUserAgentData + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        // Add by tsrdev1
        /// <summary>
        /// Check valid setup data before synchronizing
        /// </summary>        
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool CheckValidDataBeforeSynchronizing(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.CheckInValidSetupData();
                if (success)
                    ReportSyncMessage(bgWorker, ResourceHelper.CheckingSetupDataSuccessful + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.CheckingSetupDataFailed
                    });
                    ReportSyncMessage(bgWorker, ResourceHelper.CheckingSetupDataFailed + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceHelper.ErrorCheckingSetupData + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        // Add by tsrdev1
        /// <summary>
        /// Restore setup data from server before getting setup data
        /// </summary>        
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool RestoreSetupDataFromServer(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.RestoreSetupDataFromServer();
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.RestoreSetupDataSuccessful
                        + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.RestoreSetupDataFailed
                    });
                    ReportSyncMessage(bgWorker, ResourceHelper.RestoreSetupDataFailed + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ErrorRestoringSetupData
                    + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }


        private bool SaveUserAgentData(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.SaveUserAgentDataIntoServer();
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingUserAgentDataIntoServerSuccess
                        + "..." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.SavingUserAgentDataIntoServerFailure
                    });
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingUserAgentDataIntoServerFailure
                        + "..." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ErrorSavingUserAgentDataIntoServer
                    + "..." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        /// <summary>
        /// A method called at the beginning, just to check whether server address is found/was saved in settings
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool ServerAddressFound(BackgroundWorker bgWorker)
        {
            bool success = false;

            ReportSyncMessage(bgWorker,
                ResourceHelper.CheckingServerAddress
                + "..." + Environment.NewLine, SyncStatus.Normal, null);

            success = !(string.IsNullOrEmpty(Core.SettingsHelper.TSRServerAddress));

            if ((!success) && (_settings != null))
            {
                DialogResult dr = MessageBox.Show(Core.ResourceHelper.ServerSettingWarningMessage, Core.ResourceHelper.ServerSettingWarningMessageCaption, MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (dr == DialogResult.Yes)
                {
                    _settings.ShowDialog();
                    success = (!string.IsNullOrEmpty(Core.SettingsHelper.TSRServerAddress));
                }
            }
            if (success)
            {
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ServerAddressFound
                    + "..." + Environment.NewLine, SyncStatus.Normal, null);
                string error = string.Empty;
                success = TSR.Core.TSRFacade.IsServiceUp(ref error);
                if (!success)
                {
                    if (string.IsNullOrEmpty(error))
                    {
                        error = ResourceHelper.ProblemWithRemoteService
                            + ResourceHelper.PleaseContactYourAdministrator;
                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            Priority = 0,
                            MessageSummary = error
                        });
                    }
                    ReportSyncMessage(bgWorker, error + Environment.NewLine, SyncStatus.Error, null);
                }
            }
            else
            {
                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceHelper.ServerAddressNotFound
                });
                ReportSyncMessage(bgWorker, ResourceHelper.ServerAddressNotFound
                    + ResourceHelper.PleaseSaveRightServerAddressInSettings
                    + Environment.NewLine, SyncStatus.Error, null);
            }

            return success;
        }
        /// <summary>
        /// saves favorites in server
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool SaveFavoritesInServer(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.SavePreferredPathsInServer();
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingFavouritesInServerSuccessful
                        + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.SavingFavouritesInServerFailed
                    });
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingFavouritesInServerFailed
                        + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ErrorSavingFavoritesInServer
                    + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        /// <summary>
        /// retrieves prefreed paths from server and save it locally
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool FetchAndProcessFavorites(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.GetPreferredPathFromServer();
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.RetrievingFavoritesFromServerSuccessful
                        + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.RetrievingFavoritesFromServerFailed
                    });
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.RetrievingFavoritesFromServerFailed
                        + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ErrorRetrievingFavoritesFromServer
                    + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }
        /// <summary>
        /// saves local settings in server
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool SaveSettingsInServer(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.SaveUserSettingsInServer();
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingSettingsInServerSuccessful
                        + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceHelper.SavingSettingsInServerFailed
                    });
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.SavingSettingsInServerFailed
                        + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker,
                    ResourceHelper.ErrorSavingSettingsInServer
                    + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }
        /// <summary>
        /// gets user settings that were previously saved in server, and update the local setting
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool FetchAndProcessSettings(BackgroundWorker bgWorker, bool isDefault)
        {
            try
            {
                bool success = TSRFacade.GetUserSettingFromServer(isDefault);
                if (success)
                    ReportSyncMessage(bgWorker,
                        ResourceHelper.RetrievingSettingsfromServerSuccessful + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("RetrievingSettingsfromServerFailed", "Retrieving Settings from Server failed")
                    });
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("RetrievingSettingsfromServerFailed", "Retrieving Settings from Server failed") + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorRetrievingSettingsFromServer", "Error Retrieving Settings from Server") + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }


        /// <summary>
        /// gets resource data from server, save it locally
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool FetchAndProcessResourceData(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.FetchAndProcessResourceData();
                if (success)
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("OfflineLanguageDataUpdateSuccessful", "Offline language data update successful") + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("OfflineLanguageDataUpdateFailed", "Offline language data update failed")
                    });
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("OfflineLanguageDataUpdateFailed", "Offline language data update failed") + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorFetchingResourceData", "Error fetching resource data") + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        /// <summary>
        /// gets preferred languages from server and saves locally
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool FetchAndProcessPreferredLanguages(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.FetchAndProcessPreferredLanguages();
                if (success)
                    ReportSyncMessage(bgWorker, Environment.NewLine + ResourceManager.GetResourceString("OfflinePreferredLanguageDataUpdateSuccessful", "Offline preferred language data update successful") + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("OfflinePreferredLanguageDataUpdateFailed", "Offline preferred language data update failed")
                    });
                    ReportSyncMessage(bgWorker, Environment.NewLine + ResourceManager.GetResourceString("OfflinePreferredLanguageDataUpdateFailed", "Offline preferred language data update failed") + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, Environment.NewLine + ResourceManager.GetResourceString("ErrorFetchingPreferredLanguage", "Error fetching preferred languages") + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        /// <summary>
        /// gets setup data from server and updates local storage with it
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private bool FetchAndProcessSetupData(BackgroundWorker bgWorker, bool forceFullSync)
        {
            try
            {
                bool success = false;
                if (forceFullSync)
                    success = TSRFacade.FetchAndProcessSetupData_FullUpdate();
                else
                    success = TSRFacade.FetchAndProcessSetupData_CheckChanges();

                if(TSR.Core.Constants.USERINEXPENSELICENSE)
                    success = TSRExpenseFacade.FetchAndProcessExpenseType();

                if (success)
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("SetupDataUpdateSuccessful", "Setup data update successful") + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("SetupDataUpdateFailed", "Setup data update failed")
                    });
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("SetupDataUpdateFailed", "Setup data update failed") + ".." + Environment.NewLine, SyncStatus.Error, null);
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorFetchingSetupData", "Error fetching setup data") + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        /// <summary>
        /// submits time entries that are queued for submission
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <returns></returns>
        private Dictionary<Guid, string> _listDetailErroMesage = new Dictionary<Guid, string>();
        private bool SubmitTimeEntries(BackgroundWorker bgWorker)
        {
            try
            {
                string message = string.Empty;
                bool success = false;
                bool isSubmitSuccess = false;
                _listDetailErroMesage = new Dictionary<Guid, string>();
                int startDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndex * -1;
                int endDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture;
                DateTime start = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriod);
                DateTime end = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture);
                //TimeEntryList teList = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.InSubmissionQueue), string.Empty, start, end, false);

                TimeEntryList teList = (TSRFacade.GetExchangeMode()) ? this.GetTimeEntriesToSubmitInCurrentCalendar(start, end) : this.GetTimeEntriesToSubmit(start, end);

                //Added by tsrdev1
                //Added datetime 21/10/2010
                _needOverwriteTimeEntries = new TimeEntryList();
                List<Guid> noOverwrite = new List<Guid>();
                //TimeEntryList teList = TSRFacade.GetTimeEntriesByStatus(Convert.ToInt32(WS.StatusEnum.InSubmissionQueue));
                if (teList.Count > 0)
                {
                    //Modified by tsrdev1
                    //Modified datetime 13/10/2010                    

                    if (!TSR.Core.TSRFacade.GetExchangeMode())
                    {
                        _listDetailErroMesage = TSRFacade.SubmitTimeEntriesWithErrorMessage(teList, out success);
                    }
                    else
                    {
                        TSRFacade._overwriteTimeEntries = _overwriteTimeEntries;
                        _listDetailErroMesage = TSRFacade.SubmitTimeEntriesForEX(teList, out _needOverwriteTimeEntries, out noOverwrite, out success);
                    }
                    if (success)
                    {
                        ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("TimeSubmissionSuccessful", "Time Submission successful") + "." + Environment.NewLine, SyncStatus.Normal, null);
                    }
                    else
                    {
                        if ((_listDetailErroMesage != null) && (_listDetailErroMesage.Count > 0))
                        {
                            int countTENotChanged = 0;
                            int teListCount = teList.Count;

                            System.Collections.IDictionaryEnumerator listTemp = _listDetailErroMesage.GetEnumerator();
                            while (listTemp.MoveNext())
                            {
                                TimeEntry timeEntry = TSRFacade.GetTimeEntryByTSRItemID((Guid)listTemp.Key, true, true); // include deleted time entry
                                if (timeEntry != null)
                                {
                                    teList.RemoveAll(delegate(TimeEntry entry) { return entry.ID == timeEntry.ID; });
                                    if (listTemp.Value.ToString() == Constants.TIMEENTRY_NOTCHANGED) // time entry is not changed
                                    {
                                        countTENotChanged++;
                                        continue;
                                    }

                                    //Feature 340
                                    var subject = timeEntry.Subject;
                                    if (string.IsNullOrEmpty(timeEntry.Subject))
                                        subject = "[" + Core.ResourceHelper.Untitled + "]";
                                    
                                    if (listTemp.Value.ToString() == Constants.OUAChangeTimeEntryInLockPeriod)
                                    {
                                        var mes = String.Format(ResourceManager.GetResourceString("OUAChangeTimeEntryInLockPeriod", "Time entry {0} cannot change in lock period. All changes discarded"), subject);
                                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                        {
                                            LoggingTime = DateTime.Now,
                                            CreatedTimeStamp = DateTime.Now,
                                            SessionID = string.Empty,
                                            Priority = 0,
                                            MessageSummary = mes
                                        });
                                        ReportSyncMessage(bgWorker, mes + Environment.NewLine, SyncStatus.Normal, null);
                                        continue;
                                    }

                                    if (listTemp.Value.ToString() == Constants.OUADeleteTimeEntryInLockPeriod)
                                    {
                                        var mes = String.Format(ResourceManager.GetResourceString("OUADeleteTimeEntryInLockPeriod", "Time entry {0} cannot delete in lock period. Delete discarded"), subject);
                                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                        {
                                            LoggingTime = DateTime.Now,
                                            CreatedTimeStamp = DateTime.Now,
                                            SessionID = string.Empty,
                                            Priority = 0,
                                            MessageSummary = mes
                                        });
                                        ReportSyncMessage(bgWorker, mes + Environment.NewLine, SyncStatus.Normal, null);
                                        continue;
                                    }

                                    if (listTemp.Value.ToString() == Constants.OUASubmitTimeEntryInLockPeriod)
                                    {
                                        var mes = String.Format(ResourceManager.GetResourceString("OUASubmitTimeEntryInLockPeriod", "Time entry {0} cannot submit in lock period. Submit discarded"),subject);
                                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                        {
                                            LoggingTime = DateTime.Now,
                                            CreatedTimeStamp = DateTime.Now,
                                            SessionID = string.Empty,
                                            Priority = 0,
                                            MessageSummary = mes
                                        });
                                        ReportSyncMessage(bgWorker, mes + Environment.NewLine, SyncStatus.Normal, null);
                                        continue;
                                    }

                                    string strDetailMess = listTemp.Value.ToString();
                                    //in case time entry has been changed User value on server
                                    if (strDetailMess == Constants.TIMEENTRY_USER_CHANGED)
                                    {
                                        if (timeEntry.IsDeleted)
                                            continue; //nothing to do if this time entry has been deleted on local

                                        //delete the time entry (include the appointment linked with) on local
                                        try
                                        {
                                            TSRFacade.DeleteTimeEntry(timeEntry);
                                            //remove from dataset and xml file
                                            TSRFacade.RemoveTimeEntry(timeEntry.ID);
                                        }
                                        catch (Exception ex)
                                        {
                                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                            {
                                                LoggingTime = DateTime.Now,
                                                CreatedTimeStamp = DateTime.Now,
                                                SessionID = string.Empty,
                                                Priority = 0,
                                                MessageSummary = "Delete and remove time entry",
                                                MessageDetail = ex.Message
                                            });
                                        }
                                        strDetailMess = ResourceManager.GetResourceString("TimeEntryUserChangedOnServer", "Time entry has been assigned to other user on server");
                                        //strDetailMess += ResourceManager.GetResourceString("DeleteTimeEntryWarning", "This time entry will be deleted on local");
                                    }

                                    string errorMessage = ResourceManager.GetResourceString("TimeEntry", "Time Entry") + " \"" + timeEntry.Subject + "\" " + ResourceManager.GetResourceString("From", "from") + " " + timeEntry.StartTimeStamp.ToString() + " " + ResourceManager.GetResourceString("To", "to") + " " + timeEntry.EndTimeStamp.ToString() + " ";
                                    if (timeEntry.IsChangeAllowed())
                                    {
                                        errorMessage += ResourceManager.GetResourceString("SynchronizationFailed", "Synchronization failed");
                                    }
                                    else
                                        errorMessage += ResourceManager.GetResourceString("SubmissionFailed", "Submission failed");
                                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                    {
                                        LoggingTime = DateTime.Now,
                                        CreatedTimeStamp = DateTime.Now,
                                        SessionID = string.Empty,
                                        Priority = 0,
                                        MessageSummary = errorMessage
                                    });
                                    ReportSyncMessage(bgWorker, errorMessage + "." + Environment.NewLine, SyncStatus.Error, null);

                                    if (!(string.IsNullOrEmpty(strDetailMess)))
                                        //listTemp.Value.ToString()//ResourceManager.GetResourceString("NoExistUserInProjectUserGroups", "User does not exist in the project's user groups")
                                        ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("Details", "Details") + ": " + strDetailMess + "." + Environment.NewLine, SyncStatus.Error, null);
                                }
                            }
                            //added by tsrdev2
                            if (countTENotChanged == teListCount)
                            {
                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    Priority = 0,
                                    MessageSummary = ResourceManager.GetResourceString("NoTimeEntriesFoundForSubmission", "No time entries found for submission")
                                });
                                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("NoTimeEntriesFoundForSubmission", "No time entries found for submission") + "." + Environment.NewLine, SyncStatus.Normal, null);
                                isSubmitSuccess = true;
                            }
                            foreach (TimeEntry tmSucess in teList)
                            {
                                if (_needOverwriteTimeEntries != null && _needOverwriteTimeEntries.Count > 0 && _needOverwriteTimeEntries.FindByID(tmSucess.ID) != null)
                                    continue;

                                string sucessMessage = ResourceManager.GetResourceString("TimeEntry", "Time Entry") + " \"" + tmSucess.Subject + "\" " + ResourceManager.GetResourceString("From", "from") + " " + tmSucess.StartTimeStamp.ToString() + " " + ResourceManager.GetResourceString("To", "to") + " " + tmSucess.EndTimeStamp.ToString() + " ";
                                if (tmSucess.IsChangeAllowed())
                                {
                                    sucessMessage += ResourceManager.GetResourceString("SynchronizationSuccessful", "Synchronize successful");
                                }
                                else
                                    sucessMessage += ResourceManager.GetResourceString("SubmissionSuccessful", "Submission successful");
                                ReportSyncMessage(bgWorker, sucessMessage + "." + Environment.NewLine, SyncStatus.Normal, null);
                            }
                            if (TSR.Core.TSRFacade.GetExchangeMode())
                            {
                                if (noOverwrite != null && noOverwrite.Count > 0)
                                {
                                    //Remove no overwrite time entries from local
                                    foreach (Guid teID in noOverwrite)
                                        TSRFacade.RemoveTimeEntry(teID);
                                }
                            }
                            isSubmitSuccess = false;
                        }
                        else
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                Priority = 0,
                                MessageSummary = ResourceManager.GetResourceString("TimeSubmissionFailed", "Time Submission Failed")
                            });
                            ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("TimeSubmissionFailed", "Time Submission Failed") + "." + Environment.NewLine, SyncStatus.Error, null);
                            isSubmitSuccess = false;
                        }
                    }
                }
                else
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("NoTimeEntriesFoundForSubmission", "No time entries found for submission")
                    });
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("NoTimeEntriesFoundForSubmission", "No time entries found for submission") + "." + Environment.NewLine, SyncStatus.Normal, null);
                    isSubmitSuccess = false;
                }
                isSubmitSuccess = true;


                return isSubmitSuccess;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorSubmittingTimeEntry", "Error submitting time entry") + "." + Environment.NewLine + ex.Message, SyncStatus.Error, null);
                return false;
            }
        }

        private bool SubmitExpenses(BackgroundWorker bgWorker)
        {
            if (!TSR.Core.Constants.USERINEXPENSELICENSE)
            {
                return true;
            }
            bool success = false;
            string message = string.Empty;
            try
            {
                Dictionary<long, string> listDetailErroMesage = new Dictionary<long, string>();

                int startDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndex * -1;
                int endDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture;

                DateTime start = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriod);
                DateTime end = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture);

                ExpenseSheetList lstExpenseSheets = new ExpenseSheetList();
                lstExpenseSheets = TSRExpenseFacade.GetExpenseSheetsInCurrentCalendarForSync(start, end);

                if (lstExpenseSheets.Count > 0)
                {
                    listDetailErroMesage = TSRExpenseFacade.SubmitExpenses(lstExpenseSheets, out success);
                }
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorSubmittingExpense", "Error submitting expenses") + "." + Environment.NewLine + ex.Message, SyncStatus.Error, null);
                return false;
            }
            return success;
        }

        //added by tsrdev2
        //feature 31
        /// <summary>
        /// gets time entries to submit into server
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        private TimeEntryList GetTimeEntriesToSubmit(DateTime start, DateTime end)
        {
            TimeEntryList teList = new TimeEntryList();
            TimeEntryList teListToSubmit = new TimeEntryList();
            TimeEntryList teListOfInSubmissionQueue = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.InSubmissionQueue), string.Empty, start, end, false);
            TimeEntryList teListOfPendingSubmission = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.PendingSubmission), string.Empty, start, end, false, true);
            TimeEntryList teListOfRejected = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.Rejected), string.Empty, start, end, false);
            if (teListOfPendingSubmission != null && teListOfPendingSubmission.Count > 0)
            {
                //not be submitted if this te has been deleted on server
                foreach (TimeEntry te in teListOfPendingSubmission)
                {
                    if ((te.IsDeleted) && (te.IsDeletedOnServer.HasValue))
                        if (te.IsDeletedOnServer.Value)
                        {
                            te.IsDeletedOnServer = true;
                            continue;
                        }
                    teList.Add(te);
                }
            }
            if (teListOfInSubmissionQueue != null && teListOfInSubmissionQueue.Count > 0)
            {
                teList.AddRange(teListOfInSubmissionQueue);
            }
            if (teListOfRejected != null && teListOfRejected.Count > 0)
            {
                teList.AddRange(teListOfRejected);
            }
            //do not synchronize time entry of OLD Database
            foreach (TimeEntry te in teList)
            {
                //not sync the time entry has been deleted on server and local
                if (te.IsDeleted)// && te.IsDeletedOnServer.Value)
                {
                    if ((te.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission) || !te.Revision.HasValue || (te.Revision.HasValue && te.Revision == 0))
                        continue;
                }
                TimeEntry teFull = TSRFacade.GetTimeEntryByTSRItemID(te.ID, true, true);
                if (Core.TimeEntryHelper.GetTimeEntryType(teFull) == TimeEntryType.OldDB)
                {
                    if (te.Status != WS.StatusEnum.PendingSubmission)
                    {
                        te.Status = TSR.Core.UserAgentService.StatusEnum.PendingSubmission;
                        te.SubmitterName = string.Empty;
                        TSRFacade.UpdateTimeEntry(te);

                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = te.OLAppointmentItem;
                        }
                        catch //(Exception ex)
                        {
                            //Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                        if (appItem != null)
                            TSR.Core.OutlookHelper.UpdateTimeEntryAppointment(appItem, te);
                    }
                }
                else
                {
                    teListToSubmit.Add(te);
                }
            }
            return teListToSubmit;
        }

        //added by tsrdev1
        //feature 81
        /// <summary>
        /// gets time entries to submit into server in current calendar folder
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        private TimeEntryList GetTimeEntriesToSubmitInCurrentCalendar(DateTime start, DateTime end)
        {
            TimeEntryList teList = new TimeEntryList();
            TimeEntryList teListToSubmit = new TimeEntryList();
            TimeEntryList teListOfInSubmissionQueue = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.InSubmissionQueue), string.Empty, start, end, false);
            TimeEntryList teListOfPendingSubmission = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.PendingSubmission), string.Empty, start, end, false, true);
            TimeEntryList teListOfRejected = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.Rejected), string.Empty, start, end, false);
            if (teListOfPendingSubmission != null && teListOfPendingSubmission.Count > 0)
            {
                //teList.AddRange(teListOfPendingSubmission);
                //not be submitted if this te has been deleted on server
                foreach (TimeEntry te in teListOfPendingSubmission)
                {
                    if ((te.IsDeleted) && (te.IsDeletedOnServer.HasValue))
                        if (te.IsDeletedOnServer.Value)
                        {
                            te.IsDeletedOnServer = true;
                            continue;
                        }
                    teList.Add(te);
                }
            }
            if (teListOfInSubmissionQueue != null && teListOfInSubmissionQueue.Count > 0)
            {
                teList.AddRange(teListOfInSubmissionQueue);
            }
            if (teListOfRejected != null && teListOfRejected.Count > 0)
            {
                teList.AddRange(teListOfRejected);
            }

            string currentCalendarID = (OutlookHelper.UserSelectedAppointmentFolderForSync != null) ? OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID : string.Empty;

            //do not synchronize time entry of OLD Database
            foreach (TimeEntry te in teList)
            {
                //not sync the time entry has been deleted on server and local
                if (te.IsDeleted)// && te.IsDeletedOnServer.Value)
                {
                    if ((te.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission) || !te.Revision.HasValue || (te.Revision.HasValue && te.Revision == 0))
                        continue;
                }
                TimeEntry teFull = TSRFacade.GetTimeEntryByTSRItemID(te.ID, true, true);
                if (Core.TimeEntryHelper.GetTimeEntryType(teFull) == TimeEntryType.OldDB)
                {
                    if (te.Status != WS.StatusEnum.PendingSubmission)
                    {
                        te.Status = TSR.Core.UserAgentService.StatusEnum.PendingSubmission;
                        te.SubmitterName = string.Empty;
                        TSRFacade.UpdateTimeEntry(te);

                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = te.OLAppointmentItem;
                        }
                        catch //(Exception ex)
                        {
                            //Logging.LoggingHandler.LogUnhandledException(ex);
                        }

                        if (appItem != null)
                            TSR.Core.OutlookHelper.UpdateTimeEntryAppointment(appItem, te);
                    }
                }
                else if (Core.TimeEntryHelper.GetTimeEntryType(teFull) != TimeEntryType.OldDB && (string.IsNullOrEmpty(te.CalendarID) || te.CalendarID.Equals(currentCalendarID)))
                {
                    teListToSubmit.Add(te);
                }
            }
            return teListToSubmit;
        }              

        private DateTime GetStartEndTime(DateTime currentTime, int difference, string periodType)
        {
            int val;
            if (int.TryParse(periodType, out val))
            {
                TSR.Core.SettingsHelper.AllTimePeriodTypes type = (TSR.Core.SettingsHelper.AllTimePeriodTypes)val;
                switch (type)
                {
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Hour:
                        currentTime = currentTime.AddHours(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Day:
                        currentTime = currentTime.AddDays(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Week:
                        currentTime = currentTime.AddDays(difference * 7);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Month:
                        currentTime = currentTime.AddMonths(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Year:
                        currentTime = currentTime.AddYears(difference);
                        break;

                }
            }

            return currentTime;
        }

        /// <summary>
        /// retrieves time entries 
        /// </summary>
        /// <param name="bgWorker"></param>
        private void ProcessTimeEntries(BackgroundWorker bgWorker, IMemoryBox memBox)
        {
            string message = string.Empty;

            TimeEntry_OutlookAppointmentList listNewLinks = new TimeEntry_OutlookAppointmentList();

            try
            {
                int startDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndex * -1;
                int endDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture;
                int countRecreateAppointment = 0;
                int countCreateNewAppointment = 0;
                int countUpdatedAppointment = 0;
                int countDeletedTEAndAPP = 0;
                int countTESynchronized = 0;
                DateTime start = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriod);
                DateTime end = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture);
                bool retrieveCompleted = !(TSR.Core.SettingsHelper.TSRMiscNotSyncCompletedData);
                bool retrieveTECreatedViaWeb = !(TSR.Core.SettingsHelper.TSRMiscNotSyncTECreatedViaWeb);
                if (_checkListTimeEntry != null)
                {
                    TSRFacade._chekListTimeEntry = _checkListTimeEntry;
                }
                Entity.TimeEntryList createdNewTEList = new TimeEntryList();
                Entity.TimeEntryList deletedTEList = new TimeEntryList();
                Entity.TimeEntryList updatedTEList = new TimeEntryList();
                Entity.TimeEntryList recreatedTEList = new TimeEntryList();

                //Modified by tsrdev1
                //Modified datetime 13/10/2010                
                if (!TSR.Core.TSRFacade.GetExchangeMode())
                {
                    _timeEntryList = TSRFacade.ProcessTimeEntryResponse1(start, end, retrieveCompleted, retrieveTECreatedViaWeb, memBox, out createdNewTEList, out _listNeverRecreatedTimeEntryIDs);
                }
                else
                {
                    _timeEntryList = TSRFacade.ProcessTimeEntryResponseForEX(start, end, retrieveCompleted,retrieveTECreatedViaWeb, memBox, out createdNewTEList, out _listNeverRecreatedTimeEntryIDs, out listNewLinks);
                }
                if (_timeEntryList != null)
                {
                    message = Environment.NewLine + ResourceManager.GetResourceString("ResponseUpdated", "Response Updated") + "..";
                    foreach (TimeEntry te in _timeEntryList)
                    {
                        if (te.IsDeleted)
                        {
                            deletedTEList.Add(te);
                        }
                        else if (createdNewTEList.FindByID(te.ID) == null)
                            recreatedTEList.Add(te);
                    }

                    countDeletedTEAndAPP = deletedTEList.Count;
                    countTESynchronized = _timeEntryList.Count;// +createdNewTEList.Count;// -countDeletedTEAndAPP;

                    message += Environment.NewLine + ResourceManager.GetResourceString("NumberOfTimeEntriesThatWereSync", "Number of time entries that were synchronized") + " : " + countTESynchronized.ToString();
                    if (countDeletedTEAndAPP > 0)
                        message += Environment.NewLine + ResourceManager.GetResourceString("NumberOfTimeEntriesThatWereDeleted", "Number of time entries that were deleted") + " : " + countDeletedTEAndAPP.ToString();

                    //recreating appointment
                    if (TSR.Core.SettingsHelper.TSRMiscSyncRemovedData)
                        message += Environment.NewLine + ResourceManager.GetResourceString("RecreatingRemovedAppointments", "Recreating removed appointments") + "..";
                    ReportSyncMessage(bgWorker, message, SyncStatus.Normal, null);

                    TSR.Core.OutlookHelper.CreateCategoriesForTSREntry();


                    foreach (TimeEntry te in recreatedTEList)
                    {
                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = te.OLAppointmentItem;
                        }
                        catch //(Exception exp)
                        {
                            //Core.Logging.LoggingHandler.LogError(exp);
                        }
                        if (te.IsCreatedAppointment)
                        {
                            Core.OutlookHelper.CreateNewTimeEntryAppointment(te);
                            //appItem = te.OLAppointmentItem;
                            countRecreateAppointment++;

                            if (TSR.Core.TSRFacade.GetExchangeMode())
                            {
                                TimeEntry_OutlookAppointment tmp = TSRFacade.GetTimeEntry_OutlookAppointmentByTimeEntryID(te.ID);
                                if (tmp != null)
                                    listNewLinks.Add(tmp);
                            }

                            //if (appItem != null && !appItem.IsRecurring)
                            //{
                            //    appItem.Categories = te.Status.ToString() + " " + TSR.Core.Constants.CATEGORY;
                            //    appItem.Save();
                            //}
                        }
                        else
                        {
                            updatedTEList.Add(te);
                        }
                    }
                    if (TSR.Core.SettingsHelper.TSRMiscSyncRemovedData)
                    {
                        if (countRecreateAppointment > 0)
                            message = Environment.NewLine + ResourceManager.GetResourceString("NumberOfRecreatedAppointment", "Number of recreated appointment") + " : " + countRecreateAppointment.ToString();
                        else
                            message = Environment.NewLine + ResourceManager.GetResourceString("NoRecreatedAppointment", "No recreated appointment");
                        ReportSyncMessage(bgWorker, message, SyncStatus.Normal, null);
                    }

                    //creating new appointment
                    message = Environment.NewLine + ResourceManager.GetResourceString("CreatingNewAppointments", "Creating new appointments") + "..";
                    ReportSyncMessage(bgWorker, message, SyncStatus.Normal, null);
                    foreach (TimeEntry te in createdNewTEList)
                    {
                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = te.OLAppointmentItem;
                        }
                        catch //(Exception exp)
                        {
                            //Core.Logging.LoggingHandler.LogError(exp);
                        }
                        if (appItem == null)
                        {
                            Core.OutlookHelper.CreateNewTimeEntryAppointment(te);
                            //appItem = te.OLAppointmentItem;
                            countCreateNewAppointment++;

                            if (TSR.Core.TSRFacade.GetExchangeMode())
                            {
                                TimeEntry_OutlookAppointment tmp = TSRFacade.GetTimeEntry_OutlookAppointmentByTimeEntryID(te.ID);
                                if (tmp != null)
                                    listNewLinks.Add(tmp);
                            }
                        }
                        if (appItem != null && te.IsChangedAppointment)
                        {
                            bool isSuccess = true;
                            //Feature 340
                            if (!Core.TSRFacade.IsLockPeriod(te.StartTimeStamp))
                            {
                                isSuccess = Core.OutlookHelper.UpdateTimeEntryAppointment(appItem, te);
                            }
                            
                            if (isSuccess)
                            {
                                //appItem = te.OLAppointmentItem;
                                countUpdatedAppointment++;
                            }
                        }
                    }
                    if (countCreateNewAppointment > 0)
                    {
                        message = Environment.NewLine + ResourceManager.GetResourceString("NumberOfCreatedAppointment", "Number of created new appointment") + " : " + countCreateNewAppointment.ToString();
                    }
                    else
                        message = Environment.NewLine + ResourceManager.GetResourceString("NoCreatedNewAppointment", "No created new appointment");

                    //updating the existed appointment
                    message += Environment.NewLine + ResourceManager.GetResourceString("UpdatingAppointments", "Updating changed appointments") + "..";
                    ReportSyncMessage(bgWorker, message, SyncStatus.Normal, null);
                    foreach (TimeEntry te in updatedTEList)
                    {
                        if (te.IsChangedAppointment)
                        {
                            Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                            try
                            {
                                appItem = te.OLAppointmentItem;
                            }
                            catch //(Exception exp)
                            {
                                //Core.Logging.LoggingHandler.LogError(exp);
                            }
                            if (appItem != null)
                            {
                                bool isSuccess = Core.OutlookHelper.UpdateTimeEntryAppointment(appItem, te);
                                if (isSuccess)
                                {
                                    //appItem = te.OLAppointmentItem;
                                    countUpdatedAppointment++;
                                }
                            }
                        }
                        //if (appItem != null && !appItem.IsRecurring)
                        //{
                        //    appItem.Categories = te.Status.ToString() + " " + TSR.Core.Constants.CATEGORY;
                        //    appItem.Save();
                        //}
                    }
                    if (countUpdatedAppointment > 0)
                    {
                        message = Environment.NewLine + ResourceManager.GetResourceString("NumberOfUpdatedAppointment", "Number of updated appointment") + " : " + countUpdatedAppointment.ToString();
                    }
                    else
                        message = Environment.NewLine + ResourceManager.GetResourceString("NoUpdatedAppointment", "No updated appointment");
                }
                ReportSyncMessage(bgWorker, message, SyncStatus.Normal, null);

            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, Environment.NewLine + ResourceManager.GetResourceString("ErrorProcessingTimeEntry", "Error processing time entry") + ".." + Environment.NewLine + ex.Message, SyncStatus.Error, null);
            }
            if (listNewLinks != null && listNewLinks.Count > 0 && TSR.Core.TSRFacade.GetExchangeMode())
            {
                try
                {
                    ReportSyncMessage(bgWorker,
                        Environment.NewLine + ResourceManager.GetResourceString("UpdateLinkTE_APP", "Updating links between time entry and appointment" + ".."),
                        SyncStatus.Normal, null);
                    if (TSRFacade.UpdateTimeEntry_OutlookAppointmentLinksToServer(listNewLinks))
                    {
                        ReportSyncMessage(bgWorker,
                        Environment.NewLine + ResourceManager.GetResourceString("UpdateLinkTE_APPSuccess", "Links between time entry and appointment were updated sucessfully"),
                        SyncStatus.Normal, null);
                    }
                    else
                    {
                        ReportSyncMessage(bgWorker,
                        Environment.NewLine + ResourceManager.GetResourceString("UpdateLinkTE_APPUnsuccess", "Links between time entry and appointment were updated unsucessfully"),
                        SyncStatus.Normal, null);
                    }
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                    ReportSyncMessage(bgWorker,
                        Environment.NewLine + ResourceManager.GetResourceString("UpdateLinkTE_APPError", "Error updating links between time entry and appointment"),
                        SyncStatus.Normal, null);
                }
            }

            ReportSyncMessage(bgWorker, Environment.NewLine + Environment.NewLine + ResourceManager.GetResourceString("Completed", "Completed") + ".." + Environment.NewLine, SyncStatus.Normal, null);

            try
            {
                //Remove TSR infomation if in lockperiod
                foreach (var item in _listDetailErroMesage)
                {
                    if (
                        item.Value.Equals(Constants.OUAChangeTimeEntryInLockPeriod,
                            StringComparison.CurrentCultureIgnoreCase) ||
                        item.Value.Equals(Constants.OUASubmitTimeEntryInLockPeriod,
                            StringComparison.CurrentCultureIgnoreCase) ||
                        item.Value.Equals(Constants.OUADeleteTimeEntryInLockPeriod,
                            StringComparison.CurrentCultureIgnoreCase))
                    {
                        var timeEntry = TSRFacade.GetTimeEntryByTSRItemID(item.Key);
                        if (timeEntry != null && (timeEntry.Revision <= 0) || timeEntry.Revision == null)
                            TSR.Core.TSRFacade.RemoveTimeEntry(item.Key);

                        //Update TimeEntry
                        var obj = _timeEntryList.FindByID(item.Key);
                        TSR.Core.TSRFacade.UpdateTimeEntry(obj);
                    }
                }
            }
            catch { }
        }

        private void ProcessExpenses(BackgroundWorker bgWorker, IMemoryBox memBox)
        {
            int startDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndex * -1;
            int endDiffFromNow = TSR.Core.SettingsHelper.TSRSyncRangeIndexFuture;

            DateTime start = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriod);
            DateTime end = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRSyncRangePeriodFuture);

            TSRExpenseFacade.ProcessExpenses(start, end);
        }

        //Added by tsrdev1
        //Added datetime 14/10/2010
        /// <summary>
        /// Submit RecurringMaster to TSR Server
        /// </summary>
        /// <param name="bgWorker"></param>
        private void SubmitRecurringMasters(BackgroundWorker bgWorker)
        {

        }
        //Added by tsrdev1
        //Added datetime 14/10/2010
        /// <summary>
        /// Retrieve RecurringMaster from TSR Server
        /// </summary>
        /// <param name="bgWorker"></param>
        private void ProcessRecurringMasters(BackgroundWorker bgWorker)
        {
        }

        //Added by tsrdev1
        //Added datetime 22/10/2010
        private bool OverwriteTimeEntries(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = false;
                Dictionary<Guid, string> listMessageDetail = TSRFacade.OverwriteTimeEntriesToServer(_needOverwriteTimeEntries, out success);
                if (success)
                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("OverwriteTimeEntriesSuccess", "Time entries were overwritten successfully") + ".." + Environment.NewLine, SyncStatus.Normal, null);
                else
                {
                    if (listMessageDetail != null && listMessageDetail.Count > 0)
                    {
                        System.Collections.IDictionaryEnumerator listTemp = listMessageDetail.GetEnumerator();
                        while (listTemp.MoveNext())
                        {
                            TimeEntry timeEntry = TSRFacade.GetTimeEntryByTSRItemID((Guid)listTemp.Key, true);
                            if (timeEntry != null)
                            {
                                _needOverwriteTimeEntries.RemoveAll(delegate(TimeEntry entry) { return entry.ID == timeEntry.ID; });
                                string errorMessage = ResourceManager.GetResourceString("TimeEntry", "Time Entry") + " \"" + timeEntry.Subject + "\" " + ResourceManager.GetResourceString("From", "from") + " " + timeEntry.StartTimeStamp.ToString() + " " + ResourceManager.GetResourceString("To", "to") + " " + timeEntry.EndTimeStamp.ToString() + " ";
                                errorMessage += ResourceManager.GetResourceString("BeOverwrittenUnSuccess", "was overwritten unsuccessfully");
                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    Priority = 0,
                                    MessageSummary = errorMessage
                                });
                                ReportSyncMessage(bgWorker, errorMessage + "." + Environment.NewLine, SyncStatus.Error, null);
                                if (!(string.IsNullOrEmpty(listTemp.Value.ToString())))
                                    //listTemp.Value.ToString()//ResourceManager.GetResourceString("NoExistUserInProjectUserGroups", "User does not exist in the project's user groups")
                                    ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("Details", "Details") + ": " + listTemp.Value.ToString() + "." + Environment.NewLine, SyncStatus.Error, null);
                            }
                        }
                        foreach (TimeEntry tmSucess in _needOverwriteTimeEntries)
                        {
                            string sucessMessage = ResourceManager.GetResourceString("TimeEntry", "Time Entry") + " \"" + tmSucess.Subject + "\" " + ResourceManager.GetResourceString("From", "from") + " " + tmSucess.StartTimeStamp.ToString() + " " + ResourceManager.GetResourceString("To", "to") + " " + tmSucess.EndTimeStamp.ToString() + " " + ResourceManager.GetResourceString("BeOverwrittenSuccess", "was overwritten successfully");
                            ReportSyncMessage(bgWorker, sucessMessage + "." + Environment.NewLine, SyncStatus.Normal, null);
                        }
                    }
                    else
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            Priority = 0,
                            MessageSummary = ResourceManager.GetResourceString("OverwriteTimeEntriesUnSuccess", "Time entries were overwritten unsuccessfully")
                        });
                        ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("OverwriteTimeEntriesUnSuccess", "Time entries were overwritten unsuccessfully") + ".." + Environment.NewLine, SyncStatus.Error, null);
                    }
                }
                return success;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorOverwrittingTimeEntries", "Error overwritting time entries") + ".." + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        //Added by tsrdev1
        //Added datetime 17/11/2010
        private bool LogInUserToServer(BackgroundWorker bgWorker)
        {
            try
            {
                WS.ResponseMessageOfboolean response = TSRFacade.LogInUserToServer();

                if (!response.Data)
                {
                    if (!string.IsNullOrEmpty(response.ErrorMessage))
                    {
                        //response.ErrorMessage = index of typeofevent
                        string message = "";
                        int intType = 4; //UnknownUser
                        if (int.TryParse(response.ErrorMessage, out intType))
                        {
                            WS.TypeOfEventEnum1 type = (WS.TypeOfEventEnum1)intType;
                            switch (type)
                            {
                                case WS.TypeOfEventEnum1.UnknownUser:
                                    message = ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.");
                                    break;
                                case WS.TypeOfEventEnum1.WrongPassword:
                                    message = ResourceManager.GetResourceString("LoginFailedMessage", "Login failed, User Name or Password is invalid.");
                                    break;
                                case WS.TypeOfEventEnum1.AccountLocked:
                                    message = ResourceManager.GetResourceString("LoginLockedAccount", "This account has been locked. Please contact your TSR administrator.");
                                    break;
                                default:
                                    message = response.ErrorMessage;
                                    break;
                            }
                        }
                        else message = ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.");
                        ReportSyncMessage(bgWorker, message + Environment.NewLine, SyncStatus.Normal, null);
                    }
                    else
                        ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.") + Environment.NewLine, SyncStatus.Normal, null);
                }
                return response.Data;
            }
            catch (TimeoutException timeoutEx)
            {
                string error = ResourceManager.GetResourceString("ServerTimeoutException",
                    "TimeSheet Reporter Outlook User Agent could not connect to server. Please restart Outlook when convenient. If the problem persists, please contact your system administrator.");
                error += Environment.NewLine + ResourceManager.GetResourceString("PressOKToContinue", "Press OK to continue");

                ReportSyncMessage(bgWorker, error + Environment.NewLine, SyncStatus.Error, null);

                Core.Logging.LoggingHandler.LogError(timeoutEx);
                return false;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.") + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
                return false;
            }
        }

        //Added by tsrdev1
        //Added datetime 19/11/2010
        private void DeleteTimeEntries(BackgroundWorker bgWorker)
        {
            try
            {
                bool success = TSRFacade.DeleteTimeEntriesOnServer(_listNeverRecreatedTimeEntryIDs);
                if (success)
                {
                    string msg = ResourceManager.GetResourceString("TimeSheetDeleteSuccessMessage", "TimeSheet has been deleted successfully");
                    ReportSyncMessage(bgWorker, msg
                                        + Environment.NewLine, SyncStatus.Normal, null);
                }
                else
                {
                    string msg = ResourceManager.GetResourceString("TimeSheetDeleteFailureMessage", "TimeSheet has not been deleted");
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = msg
                    });
                    ReportSyncMessage(bgWorker, msg + Environment.NewLine, SyncStatus.Error, null);
                }
            }
            catch (Exception ex)
            {
                string msg = ResourceManager.GetResourceString("TimeSheetDeleteFailureMessage", "TimeSheet has not been deleted");
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, Environment.NewLine + msg + Environment.NewLine + ex.Message + Environment.NewLine, SyncStatus.Error, null);
            }
        }

        /// <summary>
        /// send a message to the user of the class
        /// </summary>
        /// <param name="bgWorker"></param>
        /// <param name="message"></param>
        /// <param name="status"></param>
        /// <param name="te"></param>
        private void ReportSyncMessage(BackgroundWorker bgWorker, string message, SyncStatus status, TimeEntryList te)
        {
            if (DoAsBackGroundWorker)  ///check the process works as a backgroudworker
            {
                SyncMessage syncMessage = new SyncMessage();
                syncMessage.Message = message;
                syncMessage.Status = status;
                syncMessage.UpdatedTimeEntries = te;
                if (bgWorker != null)
                {
                    bgWorker.ReportProgress(-1, syncMessage);
                }

            }
            else if (status == SyncStatus.Completed || status == SyncStatus.CompletedWithErrors)
            {
                Dispose();
            }
        }

        ///// <summary>
        ///// if time entry is updated, and some other screen is showing it, let them know..
        ///// </summary>
        //private void InformChangesToOpenScreens()
        //{
        //    Core.AppointmentInformer appInformer = Core.AppointmentInformer.GetInstance();
        //    appInformer.NotifyAppointmentObservers(null);
        //}

        #endregion

        #region LockPeriod

        private bool UpdateLockPeriodSetting(BackgroundWorker bgWorker)
        {
            bool success;
            try
            {
                success = TSRFacade.UpdateLockPeriodSetting();
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorLockPeriodSync", "Error LockPeriod Sync") + "." + Environment.NewLine + ex.Message, SyncStatus.Error, null);
                return false;
            }

            return success;
        }

        private bool SyncLockPeriod(BackgroundWorker bgWorker)
        {
            bool success;
            try
            {
               success = TSRFacade.SyncLockPeriod();
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                ReportSyncMessage(bgWorker, ResourceManager.GetResourceString("ErrorLockPeriodSync", "Error LockPeriod Sync") + "." + Environment.NewLine + ex.Message, SyncStatus.Error, null);
                return false;
            }
            return success;
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            syncEngine = null;
        }

        #endregion
    }
}