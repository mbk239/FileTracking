using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;
using System.Globalization;

namespace TSR.Core
{
    public class XMLResourceSet : ResourceSet
    {
        internal XMLResourceSet
           (CultureInfo culture)
            : base(new XMLResourceReader(culture))
        {
        }

        public override Type GetDefaultReader()
        {
            return typeof(XMLResourceReader);
        }
    }
}
