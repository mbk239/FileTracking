using System;
using System.Collections.Generic;
using System.Text;
using System.DirectoryServices;

namespace TSR.Core
{
    /// <summary>
    /// Deprecated code
    /// </summary>
    public class ADHelper
    {
        public static DirectoryEntry GetDirectoryEntry()
        {
            DirectoryEntry de = new DirectoryEntry();
            de.Path = "";
            de.AuthenticationType = AuthenticationTypes.Secure;

            return de;
        }

        public static DirectoryEntry UserExists(string username)
        {
            DirectoryEntry root = GetDirectoryEntry();
            DirectoryEntry userDE = null;
            DirectorySearcher deSearch = new DirectorySearcher();

            deSearch.SearchRoot = root;
            deSearch.Filter = "(&(objectCategory=person)(objectClass=user))";
            deSearch.PropertiesToLoad.Add("cn");
            SearchResultCollection results = deSearch.FindAll();

            foreach (SearchResult sr in results)
            {
                if (sr.GetDirectoryEntry().Properties["SAMAccountName"].Value.Equals(username))
                {
                    userDE = sr.GetDirectoryEntry();
                    break;
                }
            }
            
            return userDE;
        }

        
        public static void PrintDirectoryEntryProperties(DirectoryEntry entry)
        {
            foreach (string Key in entry.Properties.PropertyNames)
            {

                string sPropertyValues = String.Empty;

                foreach (object Value in entry.Properties[Key])
                    sPropertyValues += Convert.ToString(Value) + ";";

                sPropertyValues = sPropertyValues.Substring(0, sPropertyValues.Length - 1);

                System.Console.WriteLine(Key + "=" + sPropertyValues);

            }

        }
    }
}
