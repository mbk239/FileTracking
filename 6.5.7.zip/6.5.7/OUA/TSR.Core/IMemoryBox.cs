﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core
{
    public enum MemoryBoxResult { Yes, YesToAll, No, NoToAll, Cancel }

    public interface IMemoryBox
    {
        MemoryBoxResult ShowMemoryDialog(String label, string title);
    }
}
