using System;
using System.Collections.Generic;
using System.Text;

using DAL = TSR.Core.DAL;
using TSR.Core.Entity;
using WS = TSR.Core.UserAgentService;
//using AUTH = TSR.Core.AuthenticationService;
using TSR.Core.Entity.List;
//using TSR.Core.UserAgentService;
using System.Collections.Specialized;
using System.Security.Principal;
using System.DirectoryServices;
using System.Windows.Forms;
using TSR.Core.Logging;

using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Data;
using System.Collections;
using System.Globalization;
using System.Diagnostics;

namespace TSR.Core
{

    public class LicenseInfo
    {
        public string LicenseText { get; set; }
        public string CompanyName { get; set; }
        public string Version { get; set; }
        public DateTime? ExpiryDate { get; set; }
    }

    /// <summary>
    /// This is the class that presentation layer uses to interact with the business and data layer
    /// </summary>
    public static class TSRFacade
    {
        public static bool bCheckSetting = false;
        public static bool bCheckTimer = false;
        public static ISyncEngineCheckListTimeEntry _chekListTimeEntry;
        public static ISyncEngineOverwriteTimeEntry _overwriteTimeEntries;
        public static long? _userid;
        private const int TryConnectToServerCount = 1;

        public static bool TSRLoginDismiss = false;

        public static string GetAppConfigValueByKey(string key)
        {
            DAL.AppConfigDAL dal = new DAL.AppConfigDAL();
            AppConfig appConfig = dal.GetAppConfigByKey(key);
            if (appConfig != null)
                return appConfig.Value;
            return string.Empty;

        }
        public static string GetSettingsValueByKey(string key)
        {
            DAL.SettingsDAL dal = new DAL.SettingsDAL();
            Settings settings = dal.GetSettingsByKey(key);
            if (settings != null)
                return settings.Value;
            return string.Empty;
        }
        public static bool SetSettingsValueByKey(string key, string value)
        {
            Settings settings = new Settings();
            settings.Key = key;
            settings.Value = value;

            DAL.SettingsDAL dal = new DAL.SettingsDAL();
            return dal.UpdateSettings(settings);
        }

        public static string GetUserSettingsValueByKey(string key)
        {
            DAL.UserSettingsDAL dal = new DAL.UserSettingsDAL();
            UserSettings userSettings = dal.GetUserSettingsByKey(key);
            if (userSettings != null)
                return userSettings.Value;
            return string.Empty;
        }

        public static bool SetUserSettingsValueByKey(string key, string value)
        {
            UserSettings userSettings = new UserSettings();
            userSettings.Key = key;
            userSettings.Value = value;

            DAL.UserSettingsDAL dal = new DAL.UserSettingsDAL();
            return dal.UpdateUserSettings(userSettings);
        }

        public static bool IsLockedUserSetitng()
        {
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();
            try
            {
                if (!ServerAddressFound())
                    return true;

                //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
                WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

                //get user specific data [time entry, setup data]
                WS.ResponseMessageOfboolean response = new TSR.Core.UserAgentService.ResponseMessageOfboolean();
                response = service.IsLockedUserSettings(userName, pass);
                return response.Data;
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return true;
            }
        }

        public static bool ServerAddressFound()
        {
            bool success = false;
            success = !(string.IsNullOrEmpty(Core.SettingsHelper.TSRServerAddress));
            if (success)
            {
                string error = string.Empty;
                success = TSR.Core.TSRFacade.IsServiceUp(ref error);
                if (!success)
                {
                    if (string.IsNullOrEmpty(error))
                    {
                        error = ResourceManager.GetResourceString("ProblemWithRemoteService", "There were some problems with remote service.") + ResourceManager.GetResourceString("PleaseContactYourAdministrator", "Please contact your administrator.");
                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            Priority = 0,
                            MessageSummary = error
                        });
                    }
                }
            }
            else
            {
                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("ServerAddressNotFound", "Server address not found.")
                });
            }

            return success;
        }

        public static bool LocalDataExists()
        {
            TSRDataSet tsrDataset = DAL.BaseDAL.MyDataSet;
            if (tsrDataset.TimeEntry.Rows.Count == 0)
                if (tsrDataset.Organization.Rows.Count == 0)
                    if (tsrDataset.RecurringMaster.Rows.Count == 0)
                        return false;
            return true;
        }

        public static LanguageResourcesList GetLanguageResourcesByCurrentCulture()
        {
            using (DAL.LanguageResourcesDAL dal = new TSR.Core.DAL.LanguageResourcesDAL())
            {
                return dal.GetLanguageResourcesByCurrentCulture();
            }
        }

        /// <summary>
        /// gets a language resource object by language name and resource key
        /// added by tsrdev2
        /// </summary>
        /// <param name="langName"></param>
        /// <param name="resKey"></param>
        /// <returns></returns>
        public static LanguageResources GetLanguageResourcesByLanguageNameAndResourceKey(string langName, string resKey)
        {
            using (DAL.LanguageResourcesDAL dal = new TSR.Core.DAL.LanguageResourcesDAL())
            {
                return dal.GetLanguageResourcesByLanguageNameAndResourceKey(langName, resKey);
            }
        }

        /// <summary>
        /// gets list of language resources by language name
        /// added by tsrdev2
        /// </summary>
        /// <param name="langName"></param>        
        /// <returns></returns>
        public static LanguageResourcesList GetLanguageResourcesByLanguageName(string langName)
        {
            //LanguageResourcesList list = new LanguageResourcesList();
            using (DAL.LanguageResourcesDAL dal = new TSR.Core.DAL.LanguageResourcesDAL())
            {
                return dal.GetLanguageResourcesByLanguageName(langName);
            }
        }

        /// <summary>
        /// gets list of preferred Language object
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public static List<Language> GetPreferredLanguages()
        {
            StringCollection preferredlanguages2 = TSR.Core.SettingsHelper.TSRPreferredLanguages;
            StringCollection preferredlanguages = new StringCollection();

            foreach (string s in preferredlanguages2)
            {
                String[] myArray = s.Split(new char[] { Constants.DEFAULT_SEPERATOR_PREFERREDLANGUAGE }, StringSplitOptions.RemoveEmptyEntries);

                foreach (String lan in myArray)
                {
                    preferredlanguages.Add(lan);
                }
            }

            //UIHelper.FillComboBox(cmbPreferredLanguage, UIHelper.GetCultureByLanguageIds(preferredlanguages));
            List<Language> preferredLanguageList = new List<Language>();
            foreach (String item in preferredlanguages)
            {
                Language language = new Language();
                String[] fields = item.Split(new char[] { Constants.DEFAULT_SEPERATOR_LANGUAGENAME_LANGUAGEID }, StringSplitOptions.RemoveEmptyEntries);

                language.LanguageName = fields[0];
                if (fields.Length > 1)
                {
                    language.LanguageID = fields[1];
                }
                else if (language.LanguageName.Equals(Constants.DEFAULT_LANGUAGE_NAME))
                {

                    language.LanguageID = Constants.DEFAULT_CULTURE_LCID;
                }

                preferredLanguageList.Add(language);
            }

            return preferredLanguageList.OrderBy(la => la.LanguageName).ToList();
        }

        public static string GetLanguageIDByLanguageName(string langName)
        {
            List<Language> preferredLanguageList = GetPreferredLanguages();
            if (preferredLanguageList != null && preferredLanguageList.Count > 0)
            {
                foreach (Language lang in preferredLanguageList)
                {
                    if (lang.LanguageName.Equals(langName))
                    {
                        return lang.LanguageID;
                    }
                }
            }
            return string.Empty;
        }

        #region PreferredPaths
        /// <summary>
        /// Single method, deletes and insets preferred paths
        /// </summary>
        /// <param name="insList">list to be inserted</param>
        /// <param name="delList">list to be deleted</param>
        /// <returns></returns>
        public static bool InsDelPreferredPath(Entity.PreferredPathsList insList, Entity.PreferredPathsList delList)
        {
            bool isInsDel = false;
            bool[] isInserted = new bool[insList.Count];
            bool[] isDeleted = new bool[delList.Count];

            int i = 0;
            foreach (Entity.PreferredPaths obj in insList)
            {
                isInserted[i++] = UpdatePreferredPath(obj);
            }
            i = 0;
            foreach (Entity.PreferredPaths obj in delList)
            {
                isDeleted[i++] = DeletePreferredPath(obj);
            }

            return isInsDel;
        }

        /// <summary>
        /// Method to delete all preferred paths
        /// </summary>
        /// <returns></returns>
        public static bool DeleteAllPreferredPaths()
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.DeleteAll();
            }
        }

        /// <summary>
        /// Deletes preferred paths from the list of pref paths as param
        /// </summary>
        /// <param name="list">list to be deleted</param>
        /// <returns></returns>        
        public static bool[] DeletePreferredPaths(Entity.PreferredPathsList list)
        {
            bool[] isDeleted = new bool[list.Count];
            int i = 0;
            foreach (Entity.PreferredPaths obj in list)
            {
                isDeleted[i++] = DeletePreferredPath(obj);
            }
            return isDeleted;
        }

        /// <summary>
        /// method to delete a single pref path entry
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>        
        public static bool DeletePreferredPath(Entity.PreferredPaths obj)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.DeletePreferredPaths(obj.ID);
            }
        }

        /// <summary>
        /// updates pref paths
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public static bool[] UpdatePreferredPaths(Entity.PreferredPathsList list)
        {
            bool[] isUpdated = new bool[list.Count];
            int i = 0;
            foreach (Entity.PreferredPaths obj in list)
            {
                isUpdated[i++] = UpdatePreferredPath(obj);
            }
            return isUpdated;
        }

        /// <summary>
        /// Updates single pref path
        /// </summary>
        /// <param name="obj">pref path obj to be updated</param>
        /// <returns></returns>
        public static bool UpdatePreferredPath(Entity.PreferredPaths obj)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.UpdatePreferredPaths(obj);
            }
        }

        /// <summary>
        /// retrieves pref path entry for an organization
        /// </summary>
        /// <param name="organizationID">organization id for which pref paths entity will be retrieved</param>
        /// <returns></returns>
        public static Entity.PreferredPaths GetPreferredPathsByOrganizationID(Int64 organizationID)
        {
            return GetPreferredPathsByOrganizationID(organizationID, true);
        }

        public static Entity.PreferredPaths GetPreferredPathsByOrganizationID(Int64 organizationID, bool fillChilds)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                Entity.PreferredPaths obj = dal.GetPreferredPathsByOrganizationID(organizationID);

                if (fillChilds)
                    FillChilds(obj);

                return obj;
            }
        }
        /// <summary>
        /// Retrieves all pref paths
        /// </summary>
        /// <returns></returns>
        public static Entity.PreferredPathsList GetAllPreferredPathsList()
        {
            return GetAllPreferredPathsList(true);
        }

        /// <summary>
        /// retrieves all pref paths. but options are there to
        /// fill the child entities or not
        /// </summary>
        /// <param name="fillChilds">decides whether to populate the children of pref path entity</param>
        /// <returns></returns>
        public static Entity.PreferredPathsList GetAllPreferredPathsList(bool fillChilds)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                Entity.PreferredPathsList list = dal.GetAllPreferredPaths();

                if (fillChilds)
                    FillChilds(list);

                return list;
            }
        }

        public static PreferredPathsList GetPreferredPathsListByOrganizationID(long organizationID)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.GetPreferredPathsListByOrganizationID(organizationID);
            }
        }

        public static PreferredPathsList GetPreferredPathsListByProjectID(long projectID)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.GetPreferredPathsListByProjectID(projectID);
            }
        }

        public static PreferredPathsList GetPreferredPathsListByActivityID(long activityID)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.GetPreferredPathsListByActivityID(activityID);
            }
        }
        public static PreferredPathsList GetPreferredPathsListByContactID(long contactID)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.GetPreferredPathsListByContactID(contactID);
            }
        }

        public static PreferredPathsList GetPreferredPathsListByLocationID(long locationID)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.GetPreferredPathsListByLocationID(locationID);
            }
        }

        public static bool DeletePreferredPathsList(PreferredPathsList listPaths)
        {
            using (DAL.PreferredPathsDAL dal = new DAL.PreferredPathsDAL())
            {
                return dal.DeletePreferredPathsList(listPaths);
            }
        }

        /// <summary>
        /// method to populate children entities of list of pref path entities
        /// </summary>
        /// <param name="list"></param>
        private static void FillChilds(Entity.PreferredPathsList list)
        {
            if (list != null)
            {
                foreach (Entity.PreferredPaths obj in list)
                {
                    FillChilds(obj);
                }
            }
        }

        /// <summary>
        /// method for populating single pref path entity
        /// </summary>
        /// <param name="obj"></param>
        public static void FillChilds(Entity.PreferredPaths obj)
        {
            if (obj != null)
            {
                obj.Organization = GetOrganizationByID(obj.OrganizationID);
                obj.Project = GetProjectByID(obj.ProjectID);
                obj.Activity = GetActivityByID(obj.ActivityID);

                if ((obj.TaskID.HasValue) && (obj.TaskID != -1))
                    obj.Task = GetTaskByID((Int64)obj.TaskID.Value);
                if ((obj.ContactID.HasValue) && (obj.ContactID != -1))
                    obj.Contact = GetContactByID((Int64)obj.ContactID.Value);

            }
        }

        #endregion

        #region TimeEntry
        //Feature 348
        public static bool IsLockPeriod(DateTime date)
        {
            var setting = false;
            var lockPeriod = false;

            string lockPeriodSetting = GetSettingsValueByKey(SettingsHelper.TSRLOCKPERIOD);

            if (!string.IsNullOrEmpty(lockPeriodSetting))
                setting = Boolean.Parse(lockPeriodSetting);

            if (!setting)
                return false;

            using (var dalLock = new DAL.LockPeriodDAL())
            {
                lockPeriod = dalLock.IsUserInLockPeriod(date);
            }

            return lockPeriod;
        }

        //Feature 370
        public static bool IsDurationWarning(double duration)
        {
            var setting = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_IS_DURATION_WARNING_ENABLE);
            if (!string.IsNullOrEmpty(setting) && bool.Parse(setting))
            {
                setting = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_DURATION_WARNING);
                var settingDurationWarning = (double.Parse(setting.Split(':')[0]) * 60) + double.Parse(setting.Split(':')[1]);
                if (duration > settingDurationWarning)
                {
                    return true;
                }
            }

            return false;
        }
        public static bool GetEnforce()
        {
            DAL.UserSettingsDAL dal = new DAL.UserSettingsDAL();
            UserSettings userSettings = dal.GetUserSettingsByKey(Constants.CONST_ENFORCE);

            if (userSettings != null)
                return bool.Parse(userSettings.Value);
            return false;
        }

        /*
        /// <summary>
        /// Method for inserting time entry
        /// </summary>
        /// <param name="obj">time entry object to be inserted</param>
        /// <returns></returns>
        public static bool InsertTimeEntry(Entity.TimeEntry obj)
        {
            if (obj.Recurrence != null && obj.RecurrenceID.HasValue)
            {
                if (GetRecurrenceByID(obj.RecurrenceID.Value) == null)
                    UpdateRecurrence(obj.Recurrence);
            }

            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.Insert(obj);
            }
        }
        */
        /// <summary>
        /// method to update single time entry
        /// </summary>
        /// <param name="obj">time entry object - to be updated</param>
        /// <returns></returns>
        public static bool UpdateTimeEntry(Entity.TimeEntry obj)
        {
            bool isSuccess = false;
           
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                isSuccess = dal.UpdateTimeEntry(obj);
            }
            
            using (DAL.ExpenseDAL expDAL = new DAL.ExpenseDAL())
            {
                if (obj.ExpenseSheet == null && obj.Status == WS.StatusEnum.InSubmissionQueue)
                    obj.ExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(obj.ID);

                if (TSR.Core.Constants.USERINEXPENSELICENSE && isSuccess && obj.ExpenseSheet != null)
                {
                    obj.ExpenseSheet.TimeEntryID = obj.ID;
                    if (obj.Status == WS.StatusEnum.InSubmissionQueue)
                    {
                        if (obj.ExpenseSheet.Status == WS.StatusEnum.PendingSubmission
                            || obj.ExpenseSheet.Status == WS.StatusEnum.Rejected)
                            obj.ExpenseSheet.Status = WS.StatusEnum.InSubmissionQueue;
                    }

                    if (obj.ExpenseSheet.ExpenseEntryListLocal == null || obj.ExpenseSheet.ExpenseEntryListLocal.Count == 0)
                        obj.ExpenseSheet.IsDeleted = true;

                    isSuccess = expDAL.UpdateExpenseSheet(obj.ExpenseSheet, true);
                }
            }
            return isSuccess;
        }

        public static bool UpdateExpense(Entity.TimeEntry obj)
        {
            bool isSuccess = false;
            using (DAL.ExpenseDAL expDAL = new DAL.ExpenseDAL())
            {
                if (obj.ExpenseSheet == null && obj.Status == WS.StatusEnum.InSubmissionQueue)
                    obj.ExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(obj.ID);

                if (TSR.Core.Constants.USERINEXPENSELICENSE && obj.ExpenseSheet != null)
                {
                    if (obj.ExpenseSheet.Status == WS.StatusEnum.PendingSubmission ||
                        obj.ExpenseSheet.Status == WS.StatusEnum.Rejected)
                    {
                        obj.ExpenseSheet.TimeEntryID = obj.ID;

                        if (obj.ExpenseSheet.ExpenseEntryListLocal == null || obj.ExpenseSheet.ExpenseEntryListLocal.Count == 0)
                            obj.ExpenseSheet.IsDeleted = true;

                        isSuccess = expDAL.UpdateExpenseSheet(obj.ExpenseSheet, true);
                    }
                }
            }
            return isSuccess;
        }

        public static bool UpdateTimeEntryForRecurring(Entity.TimeEntry obj)
        {
            bool isSuccess = false;
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                if (obj.Status == WS.StatusEnum.Rejected)
                    obj.Status = WS.StatusEnum.PendingSubmission;

                isSuccess = dal.UpdateTimeEntry(obj);
            }

            using (DAL.ExpenseDAL expDAL = new DAL.ExpenseDAL())
            {
                if (TSR.Core.Constants.USERINEXPENSELICENSE && isSuccess && obj.ExpenseSheet != null)
                {
                    obj.ExpenseSheet.Status = WS.StatusEnum.PendingSubmission;
                    obj.ExpenseSheet.Revision = 0;

                    obj.ExpenseSheet.TimeEntryID = obj.ID;
                    if (obj.Status == WS.StatusEnum.InSubmissionQueue)
                    {
                        if (obj.ExpenseSheet.Status == WS.StatusEnum.PendingSubmission
                            || obj.ExpenseSheet.Status == WS.StatusEnum.Rejected)
                            obj.ExpenseSheet.Status = WS.StatusEnum.InSubmissionQueue;
                    }
                    if (obj.ExpenseSheet.ExpenseEntryListLocal == null || obj.ExpenseSheet.ExpenseEntryListLocal.Count == 0)
                        obj.ExpenseSheet.IsDeleted = true;
                    isSuccess = expDAL.UpdateExpenseSheet(obj.ExpenseSheet, true);
                }
            }
            return isSuccess;
        }


        //Added by tsrdev1
        //Added datetime 25/10/2010
        /// <summary>
        /// method to update single time entry
        /// </summary>
        /// <param name="obj">time entry object - to be updated</param>
        /// <param name="te_app"></param>
        /// <returns></returns>
        public static bool UpdateTimeEntry(Entity.TimeEntry obj, Entity.TimeEntry_OutlookAppointment te_app)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.UpdateTimeEntry(obj, te_app);
            }
        }

        /// <summary>
        /// method to update/insert recurring master
        /// </summary>
        /// <param name="obj">recurring master object - to be updated/inserted</param>
        /// <returns></returns>
        public static bool UpdateRecurringMaster(Entity.RecurringMaster obj)
        {
            using (DAL.RecurringMasterDAL dal = new DAL.RecurringMasterDAL())
            {
                return dal.UpdateRecurringMaster(obj);
            }
        }

        public static bool DeleteRecurringMasterByID(string recurringMasterID)
        {
            using (DAL.RecurringMasterDAL dal = new DAL.RecurringMasterDAL())
            {
                return dal.DeleteRecurringMaster(recurringMasterID);
            }
        }

        public static RecurringMaster GetRecurringMasterByOutlookEntryID(string ID)
        {
            using (DAL.RecurringMasterDAL dal = new DAL.RecurringMasterDAL())
            {
                return dal.GetRecurringMasterByID(ID);
            }
        }

        public static List<RecurringMaster> GetRecurringMastersByAllParams(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
     DateTime start, DateTime end)
        {
            using (DAL.RecurringMasterDAL dal = new DAL.RecurringMasterDAL())
            {
                return dal.GetDataByAllParams(subject, lstOrganizationID, lstProjectID, lstActivityID, start, end);
            }
        }

        /// <summary>
        /// method to delete a time entry
        /// </summary>
        /// <param name="id">guid, which is primary key for time entry needs to be passed as param for deleting</param>
        /// <returns></returns>
        public static bool DeleteTimeEntry(TimeEntry obj)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                if (obj.IsRecurring)
                {
                    TimeEntry te = GetTimeEntryByTSRItemID(obj.ID);
                    if (te == null)
                    {
                        UpdateTimeEntry(obj);
                    }
                }
                return dal.DeleteTimeEntry(obj.ID);
            }
        }

        /// <summary>
        /// method to delete a time entry
        /// </summary>
        /// <param name="id">guid, which is primary key for time entry needs to be passed as param for deleting</param>
        /// <returns></returns>
        public static bool DeleteTimeEntry(Guid id)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.DeleteTimeEntry(id);
            }
        }

        public static bool DeleteTimeEntryForRecurring(Guid id)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.DeleteTimeEntryForRecurring(id);
            }
        }

        /// <summary>
        /// retrieves time entry object from TSR item id
        /// </summary>
        /// <param name="tsrItemID">tsr item id [Guid]</param>
        /// <returns></returns>
        public static Entity.TimeEntry GetTimeEntryByTSRItemID(Guid tsrItemID)
        {
            return GetTimeEntryByTSRItemID(tsrItemID, true);
        }

        /// <summary>
        /// retrieves time entry object, with options to fill the children entities or not
        /// </summary>
        /// <param name="tsrItemID">time entry id to be grabbed [Guid]</param>
        /// <param name="fillChilds">if true, fills children entities too</param>
        /// <returns></returns>
        public static Entity.TimeEntry GetTimeEntryByTSRItemID(Guid tsrItemID, bool fillChilds)
        {
            return GetTimeEntryByTSRItemID(tsrItemID, fillChilds, false);
        }

        /// <summary>
        /// retrieves time entry object, with options to fill the children entities or not
        /// </summary>
        /// <param name="tsrItemID">time entry id to be grabbed [Guid]</param>
        /// <param name="fillChilds">if true, fills children entities too</param>
        /// <returns></returns>
        public static Entity.TimeEntry GetTimeEntryByTSRItemID(Guid tsrItemID, bool fillChilds, bool includeDeleted)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntry obj = dal.GetTimeEntryByID(tsrItemID, includeDeleted);

                if (fillChilds)
                    FillChilds(obj);

                return obj;
            }
        }

        /// <summary>
        /// Every time entry is associated with an outlook appointment, this method retreieves
        /// the time entry object from outlook item id [appointment entry id]
        /// </summary>
        /// <param name="outlookItemID">outlook item id [appointment entry id]</param>
        /// <returns></returns>
        public static Entity.TimeEntry GetTimeEntryByOutlookItemID(string outlookItemID)
        {
            return GetTimeEntryByOutlookItemID(outlookItemID, true);
        }

        /// <summary>
        /// retreieves time entry object from outlook item id [outlook appointment entry id]
        /// has options to fill children entities of time entry or not
        /// </summary>
        /// <param name="outlookItemID">outlook appointment id [entry id]</param>
        /// <param name="fillChilds">if true, fills children entities</param>
        /// <returns></returns>
        public static Entity.TimeEntry GetTimeEntryByOutlookItemID(string outlookItemID, bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntry obj = dal.GetTimeEntryByOutlookItemID(outlookItemID);

                if (fillChilds)
                    FillChilds(obj);

                return obj;
            }
        }

        ///// <summary>
        ///// retreieves time entries from a recurring outlook item id [outlook appointment entry id]
        ///// has options to fill children entities of time entry or not
        ///// </summary>
        ///// <param name="outlookItemID">outlook appointment id [entry id]</param>
        ///// <param name="fillChilds">if true, fills children entities</param>
        ///// <returns></returns>
        //public static Entity.TimeEntryList GetTimeEntriesByRecurringOutlookItemID(string outlookItemID, bool fillChilds)
        //{
        //    using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
        //    {
        //        TimeEntryList list = dal.GetTimeEntriesByRecurringOutlookItemID(outlookItemID);

        //        if (fillChilds)
        //            FillChilds(list);

        //        return list;
        //    }
        //}

        /// <summary>
        /// When a recurring appointment's series is opened and subject/body was changed
        /// then rule is it updates exception appointments' subject/body, if it did not change these itself.
        /// </summary>
        /// <param name="outlookItemID"></param>
        /// <param name="oldSubject"></param>
        /// <param name="oldBody"></param>
        /// <param name="newSubject"></param>
        /// <param name="newBody"></param>
        /// <returns></returns>
        public static bool UpdateExistingRecrruingTSREntriesForSeriesUpdate(string outlookItemID, string oldSubject, string oldBody, string newSubject, string newBody)
        {
            bool success = true;
            bool tempSuccess = false;
            try
            {
                using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
                {
                    TimeEntryList list = dal.GetTimeEntriesByRecurringOutlookItemID(outlookItemID);
                    foreach (TimeEntry te in list)
                    {
                        //change will be made only if change is allowed, check the rules in IsChangeAllowed method description
                        if (te.IsChangeAllowed())
                        {
                            //if the subject/body was not changed by specific occurrence, 
                            //series update changes subject/body. and to be synched with outlook appointment, 
                            //we have to update time entries' subject and/or body
                            if (te.Subject == oldSubject)
                                te.Subject = newSubject;
                            if (te.Body == oldBody)
                                te.Body = newBody;
                            tempSuccess = UpdateTimeEntry(te);
                        }
                        if (!tempSuccess)
                            success = false;
                    }

                }
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                success = false;
            }

            return success;
        }

        //Created by tsrdev1
        //Created date 05/08/2010
        /// <summary>
        /// When a recurring appointment's series is opened and subject/body/location was changed
        /// then rule is it updates exception appointments' subject/body/location, if it did not change these itself.
        /// </summary>
        /// <param name="outlookItemID"></param>
        /// <param name="oldSubject"></param>
        /// <param name="oldBody"></param>
        /// <param name="oldLocation"></param>
        /// <param name="newSubject"></param>
        /// <param name="newBody"></param>
        /// <param name="newLocation"></param>
        /// <returns></returns>
        public static bool UpdateExistingRecrruingTSREntriesForSeriesUpdate(string outlookItemID, string oldSubject, string oldBody, string oldLocation, string newSubject, string newBody, string newLocation)
        {
            bool success = true;
            bool tempSuccess = false;
            try
            {
                using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
                {
                    TimeEntryList list = dal.GetTimeEntriesByRecurringOutlookItemID(outlookItemID);
                    foreach (TimeEntry te in list)
                    {
                        //change will be made only if change is allowed, check the rules in IsChangeAllowed method description
                        if (te.IsChangeAllowed())
                        {
                            //if the subject/body was not changed by specific occurrence, 
                            //series update changes subject/body. and to be synched with outlook appointment, 
                            //we have to update time entries' subject and/or body
                            if (te.Subject == oldSubject)
                                te.Subject = newSubject;
                            if (te.Body == oldBody)
                                te.Body = newBody;
                            if (te.Location == oldLocation)
                                te.Location = newLocation;
                            tempSuccess = UpdateTimeEntry(te);
                        }
                        if (!tempSuccess)
                            success = false;
                    }

                }
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                success = false;
            }

            return success;
        }
        public static bool SetExistingRecrruingTSREntriesIntoOrphans(string outlookItemID)
        {
            bool success = true;
            bool tempSuccess = false;
            try
            {
                using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
                {
                    TimeEntryList list = dal.GetTimeEntriesByRecurringOutlookItemID(outlookItemID);
                    foreach (TimeEntry te in list)
                    {
                        te.SetAppointmentIDForNonExistingAppointment();
                        tempSuccess = UpdateTimeEntry(te);
                        if (!tempSuccess)
                            success = false;
                    }

                }
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                success = false;
            }

            return success;
        }

        public static bool UpdateExistingTimeEntriesForRemovedRecurringAppointment(string outlookItemID, DateTime start, DateTime end)
        {
            bool success = true;
            bool tempSuccess = false;
            try
            {
                using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
                {
                    TimeEntryList list = dal.GetTimeEntriesByRecurringOutlookItemID(outlookItemID);
                    foreach (TimeEntry te in list)
                    {
                        te.IsRecurring = false;
                        if (!((te.StartTimeStamp == start) && (te.EndTimeStamp == end)))
                        {
                            te.SetAppointmentIDForNonExistingAppointment();
                        }
                        tempSuccess = UpdateTimeEntry(te);
                        if (!tempSuccess)
                            success = false;
                    }

                }
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                success = false;
            }

            return success;
        }

        public static Entity.TimeEntry GetTimeEntryForRecurringAppointment(string outlookItemID, DateTime start, DateTime end, bool fillChilds, bool includeDeleted)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntry obj = dal.GetTimeEntryForRecurringAppointment(outlookItemID, start, end, includeDeleted);

                if (fillChilds)
                    FillChilds(obj);

                return obj;
            }
        }

        /// <summary>
        /// method to retrieve time entry by all possible paramaeters [except start and end time]. if one param
        /// passed as -1, filtration will ignore that param
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="projectID">project id</param>
        /// <param name="activityID">activity id</param>
        /// <param name="taskID">task id</param>
        /// <param name="contactID">contact id</param>
        /// <param name="status">status</param>
        /// <param name="subject">appointment subject</param>
        /// <param name="fillChilds">if true, fills the children entities</param>
        /// <returns></returns>
        public static TimeEntryList GetTimeEntriesByAllParams(Int64 organizationID, Int64 projectID, Int64 activityID,
            Int64 taskID, Int64 contactID, Int32 status, string subject, bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                TimeEntryList list = dal.GetDataByAllParams(organizationID, projectID,
                    activityID, taskID, contactID, status, subject);

                if (fillChilds)
                    FillChilds(list);

                return list;
            }
        }
        /// <summary>
        /// method to retrieve time entry by all possible paramaeters. if one param
        /// passed as -1, filtration will ignore that param; But, start and end time
        /// must be valid datetime objects
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="projectID">project id</param>
        /// <param name="activityID">activity id</param>
        /// <param name="taskID">task id</param>
        /// <param name="contactID">contact id</param>
        /// <param name="status">status</param>
        /// <param name="subject">appointment subject</param>
        /// <param name="startTime">appointment start time</param>
        /// <param name="endTime">appointment end time</param>
        /// <param name="fillChilds">if true, fills the children entities</param>
        /// <returns></returns>
        public static Entity.TimeEntryList GetTimeEntriesByAllParams(Int64 organizationID, Int64 projectID, Int64 activityID,
            Int64 taskID, Int64 contactID, Int32 status, string subject, DateTime startTime, DateTime endTime, bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntryList list = dal.GetDataByAllParams(organizationID, projectID,
                    activityID, taskID, contactID, status, subject);

                Entity.TimeEntryList filteredWithTime = new TSR.Core.Entity.TimeEntryList();

                foreach (TSR.Core.Entity.TimeEntry te in list)
                {
                    if ((te.StartTimeStamp >= startTime) && (te.EndTimeStamp < endTime))
                    {
                        filteredWithTime.Add(te);
                    }
                }
                if (fillChilds)
                    FillChilds(filteredWithTime);

                return filteredWithTime;
            }
        }

        //added by tsrdev2
        /// <summary>
        /// method to retrieve time entry by all possible paramaeters. if one param
        /// passed as -1, filtration will ignore that param; But, start and end time
        /// must be valid datetime objects
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="projectID">project id</param>
        /// <param name="activityID">activity id</param>
        /// <param name="taskID">task id</param>
        /// <param name="contactID">contact id</param>
        /// <param name="status">status</param>
        /// <param name="subject">appointment subject</param>
        /// <param name="startTime">appointment start time</param>
        /// <param name="endTime">appointment end time</param>
        /// <param name="fillChilds">if true, fills the children entities</param>
        /// <param name="includeDeleted">if true, fills both the active and deleted entries</param>
        /// <returns></returns>
        public static Entity.TimeEntryList GetTimeEntriesByAllParams(Int64 organizationID, Int64 projectID, Int64 activityID,
            Int64 taskID, Int64 contactID, Int32 status, string subject, DateTime startTime, DateTime endTime, bool fillChilds, bool includeDeleted)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntryList list = dal.GetDataByAllParams(organizationID, projectID,
                    activityID, taskID, contactID, status, subject, includeDeleted);

                Entity.TimeEntryList filteredWithTime = new TSR.Core.Entity.TimeEntryList();

                foreach (TSR.Core.Entity.TimeEntry te in list)
                {
                    if ((te.StartTimeStamp >= startTime) && (te.EndTimeStamp < endTime))
                    {
                        filteredWithTime.Add(te);
                    }
                }
                if (fillChilds)
                    FillChilds(filteredWithTime);

                return filteredWithTime;
            }
        }

        public static Entity.TimeEntryList GetTimeEntriesByAllParams(List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
            List<Int64> lstTaskID, List<Int64> lstContactID, List<Int32> lstStatus, string subject, DateTime startTime, DateTime endTime, bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntryList list = dal.GetDataByAllParams(lstOrganizationID, lstProjectID,
                    lstActivityID, lstTaskID, lstContactID, lstStatus, subject);

                Entity.TimeEntryList filteredWithTime = new TSR.Core.Entity.TimeEntryList();

                foreach (TSR.Core.Entity.TimeEntry te in list)
                {
                    if ((te.StartTimeStamp >= startTime) && (te.EndTimeStamp < endTime))
                    {
                        filteredWithTime.Add(te);
                    }
                }
                if (fillChilds)
                    FillChilds(filteredWithTime);

                return filteredWithTime;
            }
        }

        //Added by tsrdev1
        //Added datetime 27/10/2010
        public static Entity.TimeEntryList GetTimeEntriesByAllParamsForCurrentCalendarFolder(List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
            List<Int64> lstTaskID, List<Int64> lstContactID, List<Int32> lstStatus, string subject, DateTime startTime, DateTime endTime, bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntryList list = dal.GetDataByAllParams(lstOrganizationID, lstProjectID,
                    lstActivityID, lstTaskID, lstContactID, lstStatus, subject);

                Entity.TimeEntryList filteredWithTime = new TSR.Core.Entity.TimeEntryList();

                string currentCalendarID = (OutlookHelper.UserSelectedAppointmentFolderForSync != null) ? OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID : string.Empty;

                foreach (TSR.Core.Entity.TimeEntry te in list)
                {
                    if ((te.StartTimeStamp >= startTime) && (te.StartTimeStamp < endTime) && (string.IsNullOrEmpty(te.CalendarID) || te.CalendarID.Equals(currentCalendarID)))
                    {
                        filteredWithTime.Add(te);
                    }
                }
                if (fillChilds)
                    FillChilds(filteredWithTime);

                return filteredWithTime;
            }
        }

        /// <summary>
        /// Retrieves time entry object filtered with status
        /// </summary>
        /// <param name="status">status used to filter</param>
        /// <returns></returns>
        public static Entity.TimeEntryList GetTimeEntriesByStatus(Int32 status)
        {
            return GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, status, String.Empty, false);
        }

        /// <summary>
        /// retrieves all time entries
        /// </summary>
        /// <returns></returns>
        public static Entity.TimeEntryList GetAllTimeEntries()
        {
            return GetAllTimeEntries(false);
        }

        /// <summary>
        /// retrieves all time entries with option to populate children entities
        /// </summary>
        /// <param name="fillChilds">if true, will populate the children</param>
        /// <returns></returns>
        public static Entity.TimeEntryList GetAllTimeEntries(bool fillChilds)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                Entity.TimeEntryList list = dal.GetAllTimeEntries();

                if (fillChilds)
                    FillChilds(list);

                return list;
            }
        }

        ///// <summary>
        ///// retrieves time entry filtered with recurrence id
        ///// </summary>
        ///// <param name="id">recurrence id</param>
        ///// <param name="fillChilds">if true, fills children entities</param>
        ///// <returns></returns>
        //public static Entity.TimeEntryList GetTimeEntriesByReccurrenceID(System.Guid id, bool fillChilds)
        //{
        //    Entity.TimeEntryList teList = GetAllTimeEntries(fillChilds);
        //    Entity.TimeEntryList teListByReccurrence = new TSR.Core.Entity.TimeEntryList();

        //    foreach (Entity.TimeEntry te in teList)
        //    {
        //        if (te.RecurrenceID.HasValue)
        //        {
        //            if (te.RecurrenceID.Value == id)
        //            {
        //                teListByReccurrence.Add(te);
        //            }
        //        }
        //    }

        //    return teListByReccurrence;
        //}


        /// <summary>
        /// fills children entities for list of time entries
        /// </summary>
        /// <param name="list">list of time entries</param>
        private static void FillChilds(Entity.TimeEntryList list)
        {
            if (list != null)
            {
                foreach (Entity.TimeEntry obj in list)
                {
                    FillChilds(obj);
                }
            }
        }

        /// <summary>
        /// method to populate time entry object with children entities
        /// </summary>
        /// <param name="obj">time entry object to be populated</param>
        public static void FillChilds(Entity.TimeEntry obj)
        {
            if (obj != null)
            {
                obj.Organization = (GetOrganizationByID(obj.OrganizationID) != null) ?
                    GetOrganizationByID(obj.OrganizationID) : GetOrganizationByID(obj.OrganizationID, false);
                if (obj.Organization != null)
                {
                    obj.Project = (GetProjectByID(obj.ProjectID) != null) ?
                        GetProjectByID(obj.ProjectID) : GetProjectByID(obj.ProjectID, false);
                }
                if (obj.Project != null)
                {
                    obj.Activity = (GetActivityByID(obj.ActivityID) != null) ?
                        GetActivityByID(obj.ActivityID) : GetActivityByID(obj.ActivityID, false);
                }
                if (obj.Organization != null)
                {
                    if (obj.TaskID.HasValue && obj.TaskID.Value != -1)
                        obj.Task = (GetTaskByID(obj.TaskID.Value) != null) ?
                            GetTaskByID(obj.TaskID.Value) : GetTaskByID(obj.TaskID.Value, false);
                    if (obj.ContactID.HasValue && obj.ContactID.Value != -1)
                        obj.Contact = (GetContactByID(obj.ContactID.Value) != null) ?
                            GetContactByID(obj.ContactID.Value) : GetContactByID(obj.ContactID.Value, false);
                }
                //obj.NoteList = GetNotesByTimeEntryID(obj.ID);
            }
        }

        //Added by tsrdev1
        //Added datetime 15/10/2010
        /// <summary>
        /// Update link between time entry and appointment
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool UpdateTimeEntry_OutlookAppointment(Entity.TimeEntry_OutlookAppointment obj)
        {
            using (DAL.TimeEntry_OutlookAppointmentDAL dal = new DAL.TimeEntry_OutlookAppointmentDAL())
            {
                return dal.UpdateTimeEntry_OutlookAppointment(obj);
            }
        }

        /// <summary>
        /// Get all links between time entry and appointment
        /// </summary>
        /// <returns></returns>
        public static TimeEntry_OutlookAppointmentList GetAllTimeEntry_OutlookAppointment()
        {
            using (DAL.TimeEntry_OutlookAppointmentDAL dal = new DAL.TimeEntry_OutlookAppointmentDAL())
            {
                return dal.GetAllTimeEntry_OutlookAppointment();
            }
        }

        /// <summary>
        /// Get link between time entry and appointment by time entry id
        /// </summary>
        ///<param name="teID"></param>
        /// <returns></returns>
        public static TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByTimeEntryID(Guid teID)
        {
            using (DAL.TimeEntry_OutlookAppointmentDAL dal = new DAL.TimeEntry_OutlookAppointmentDAL())
            {
                return dal.GetTimeEntry_OutlookAppointmentByTimeEntryID(teID);
            }
        }

        /// <summary>
        /// Get link between time entry and appointment by appointment id
        /// </summary>
        /// <param name="outlookItemID"></param>
        /// <returns></returns>
        public static TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByOutlookItemID(string outlookItemID)
        {
            using (DAL.TimeEntry_OutlookAppointmentDAL dal = new DAL.TimeEntry_OutlookAppointmentDAL())
            {
                return dal.GetTimeEntry_OutlookAppointmentByOutlookItemID(outlookItemID);
            }
        }
        //End

        //Added by tsrdev1
        //Added datetime 20/10/2010
        private static bool OverwriteTimeEntry(Guid newID, Guid oldID)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.OverwriteTimeEntry(newID, oldID);
            }
        }

        //Added by tsrdev1
        //Added datetime 20/10/2010
        public static bool RemoveTimeEntry(Guid teID)
        {
            using (DAL.TimeEntryDAL dal = new DAL.TimeEntryDAL())
            {
                return dal.RemoveTimeEntry(teID);
            }
        }

        //Added by tsrdev1
        //Added datetime 29/10/2010
        public static bool RemoveTimeEntry_OutlookAppointment(TimeEntry_OutlookAppointment obj)
        {
            using (DAL.TimeEntry_OutlookAppointmentDAL dal = new DAL.TimeEntry_OutlookAppointmentDAL())
            {
                obj.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                return dal.UpdateTimeEntry_OutlookAppointment(obj);
            }
        }

        internal static bool UpdateOverwriteTimeEntries(Dictionary<Guid, Guid> listOverwriteTE)
        {
            System.Collections.IDictionaryEnumerator idic = listOverwriteTE.GetEnumerator();
            while (idic.MoveNext())
            {
                OverwriteTimeEntry((Guid)idic.Key, (Guid)idic.Value);
            }
            return true;
        }
        #endregion

        #region Organization

        /// <summary>
        /// method to update organization
        /// </summary>
        /// <param name="obj">organization object to be updated</param>
        /// <returns></returns>
        public static bool UpdateOrganization(Entity.Organization obj)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.UpdateOrganization(obj);
            }
        }

        /// <summary>
        /// method to update organization
        /// </summary>
        /// <param name="obj">organization object to be updated</param>
        /// <returns></returns>        
        public static bool UpdateOrganization(WS.Organization obj)
        {
            Entity.Organization locObj = new Entity.Organization();
            locObj.ID = obj.ID;
            locObj.Name = obj.Name;
            locObj.Visible = true;
            locObj.Description = obj.Description;
            locObj.Modified = obj.Reversion;

            return UpdateOrganization(locObj);
        }

        /// <summary>
        /// method to retrieve organization by organization id
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <returns></returns>
        public static Entity.Organization GetOrganizationByID(Int64 organizationID)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetOrganizationByID(organizationID);
            }
        }

        /// <summary>
        /// method to retrieve organization by organization id
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.Organization GetOrganizationByID(Int64 organizationID, bool visible)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetOrganizationByID(organizationID, visible);
            }
        }
        /// <summary>
        /// method to retrieve all organizations
        /// </summary>
        /// <returns></returns>
        public static Entity.OrganizationList GetAllOrganizations()
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetAllOrganizations();
            }
        }
        /// <summary>
        /// method to retrieve all organizations
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.OrganizationList GetAllOrganizations(bool visible)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetAllOrganizations(visible);
            }
        }

        /// <summary>
        /// gets organization for a project
        /// </summary>
        /// <param name="projectId">project id for which organization object will be retireved</param>
        /// <returns></returns>
        public static Entity.OrganizationList GetOrganizationsForProject(long projectId)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetOrganizationsByProjectID(projectId);
            }
        }

        /// <summary>
        /// gets organization for a project
        /// </summary>
        /// <param name="projectId">project id for which organization object will be retireved</param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.OrganizationList GetOrganizationsForProject(long projectId, bool visible)
        {
            using (DAL.OrganizationDAL dal = new DAL.OrganizationDAL())
            {
                return dal.GetOrganizationsByProjectID(projectId, visible);
            }
        }
        #endregion

        #region Project

        /// <summary>
        /// method for assigning an organization to a project
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="projectID">project id</param>
        /// <returns></returns>
        public static bool AssignOrganizationToProject(long organizationID, long projectID)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.AssignOrganization(organizationID, projectID);
            }
        }

        /// <summary>
        /// method for removing a project from an organization
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="projectID">project id</param>
        /// <returns></returns>
        public static bool RemoveProjectFromOrganization(long organizationID, long projectID)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.RemoveOrganization(organizationID, projectID);
            }
        }

        /// <summary>
        /// method for removing a project from an organization
        /// </summary>        
        /// <param name="projectID">project id</param>
        /// <returns></returns>
        public static bool RemoveProjectFromOrganization(long projectID)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.RemoveOrganization(projectID);
            }
        }

        /// <summary>
        /// method to update a project
        /// </summary>
        /// <param name="obj">project object to be updated</param>
        /// <returns></returns>
        public static bool UpdateProject(Entity.Project obj)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.UpdateProject(obj);
            }
        }

        /// <summary>
        /// method to update a project
        /// </summary>
        /// <param name="obj">project object to be updated</param>
        /// <returns></returns>        
        public static bool UpdateProject(WS.Project obj)
        {
            Entity.Project locObj = new Entity.Project();
            locObj.ID = obj.ID;
            locObj.Name = obj.Name;

            locObj.Visible = (obj.RowState != WS.BaseBusinessEntity.RowStateEnum.DeletedRow);

            locObj.ProjectTypeName = obj.ProjectTypeName;
            locObj.Description = obj.Description;
            locObj.Modified = obj.Reversion;

            return UpdateProject(locObj);
        }

        /// <summary>
        /// method to retrieve project from its id
        /// </summary>
        /// <param name="projectID">project id</param>
        /// <returns></returns>
        public static Entity.Project GetProjectByID(Int64 projectID)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectByID(projectID);
            }
        }

        /// <summary>
        /// method to retrieve project from its id
        /// </summary>
        /// <param name="projectID">project id</param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.Project GetProjectByID(Int64 projectID, bool visible)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectByID(projectID, visible);
            }
        }


        /// <summary>
        /// retrieves available projects for an organization
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <returns></returns>
        public static Entity.ProjectList GetProjectsForOrganization(Int64 organizationID)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectsForOrganization(organizationID);
            }
        }

        /// <summary>
        /// retrieves available projects for an organization
        /// </summary>
        /// <param name="organizationID">organization id</param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.ProjectList GetProjectsForOrganization(Int64 organizationID, bool visible)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectsForOrganization(organizationID, visible);
            }
        }

        public static Entity.ProjectList GetProjectsForMultipleOrganizations(List<Int64> organizationIDs)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectsForMultipleOrganizations(organizationIDs);
            }
        }


        public static Entity.ProjectList GetProjectsForMultipleOrganizations(List<Int64> organizationIDs, bool visible)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetProjectsForMultipleOrganizations(organizationIDs, visible);
            }
        }

        /// <summary>
        /// method to retrieve all projects
        /// </summary>
        /// <returns></returns>
        public static Entity.ProjectList GetAllProjects()
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetAllProjects();
            }
        }

        /// <summary>
        /// method to retrieve all projects
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.ProjectList GetAllProjects(bool visible)
        {
            using (DAL.ProjectDAL dal = new DAL.ProjectDAL())
            {
                return dal.GetAllProjects(visible);
            }
        }
        #endregion

        #region Activity

        /// <summary>
        /// method to assign project to activity
        /// </summary>
        /// <param name="projectID">project id</param>
        /// <param name="activityID">activity id</param>
        /// <returns></returns>
        public static bool AssignProjectToActivity(long projectID, long activityID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.AssignProject(projectID, activityID);
            }
        }

        /// <summary>
        /// method to remove project from activity
        /// </summary>
        /// <param name="projectID">project id</param>
        /// <param name="activityID">activity id</param>
        /// <returns></returns>
        public static bool RemoveActivityFromProject(long projectID, long activityID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.RemoveProject(projectID, activityID);
            }
        }

        /// <summary>
        /// method to remove all projects from activity
        /// </summary>        
        /// <param name="activityID">activity id</param>
        /// <returns></returns>
        public static bool RemoveActivityFromAllProjects(long activityID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.RemoveActivityFromAllProjects(activityID);
            }
        }

        /// <summary>
        /// method to remove project from all activities
        /// </summary>
        /// <param name="projectID">project id</param>        
        /// <returns></returns>
        public static bool RemoveAllActivitiesFromProject(long projectID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.RemoveAllActitvitiesFromProject(projectID);
            }
        }

        /// <summary>
        /// updates activity
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool UpdateActivity(Entity.Activity obj)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.UpdateActivity(obj);
            }
        }

        /// <summary>
        /// updates activity, overloaded method, used after synchronization
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool UpdateActivity(WS.Activity obj)
        {
            Entity.Activity locObj = new Entity.Activity();
            locObj.ID = obj.ID;
            locObj.Name = obj.Name;
            locObj.Visible = true;
            locObj.IsActivate = obj.IsActivate;

            locObj.ActivityTypeName = obj.ActivityTypeName;
            locObj.Description = obj.Description;
            locObj.Modified = obj.Reversion;

            return UpdateActivity(locObj);
        }

        /// <summary>
        /// retrieves activity by activity id
        /// </summary>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public static Entity.Activity GetActivityByID(Int64 activityID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivityByID(activityID);
            }
        }

        /// <summary>
        /// retrieves activity by activity id
        /// </summary>
        /// <param name="activityID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.Activity GetActivityByID(Int64 activityID, bool visible)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivityByID(activityID, visible);
            }
        }

        /// <summary>
        /// retrieves list of activities for a project
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public static Entity.ActivityList GetActivitiesForProject(Int64 projectID)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivitiesForProject(projectID);
            }
        }

        /// <summary>
        /// retrieves list of activities for a project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.ActivityList GetActivitiesForProject(Int64 projectID, bool visible)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivitiesForProject(projectID, visible);
            }
        }

        public static Entity.ActivityList GetActivitiesForMultipleProjects(List<Int64> projectIDs)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivitiesForMultipleProjects(projectIDs);
            }
        }

        public static Entity.ActivityList GetActivitiesForMultipleProjects(List<Int64> projectIDs, bool visible)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetActivitiesForMultipleProjects(projectIDs, visible);
            }
        }
        /// <summary>
        /// retrieves list of all activities
        /// </summary>
        /// <returns></returns>
        public static Entity.ActivityList GetAllActivities()
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetAllActivities();
            }
        }

        /// <summary>
        /// retrieves list of all activities
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.ActivityList GetAllActivities(bool visible)
        {
            using (DAL.ActivityDAL dal = new DAL.ActivityDAL())
            {
                return dal.GetAllActivities(visible);
            }
        }
        #endregion

        #region Task

        /// <summary>
        /// retrieves task by task id
        /// </summary>
        /// <param name="taskID"></param>
        /// <returns></returns>
        public static Entity.Task GetTaskByID(Int64 taskID)
        {
            using (DAL.TaskDAL dal = new DAL.TaskDAL())
            {
                return dal.GetTaskByID(taskID);
            }
        }

        /// <summary>
        /// retrieves task by task id
        /// </summary>
        /// <param name="taskID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.Task GetTaskByID(Int64 taskID, bool visible)
        {
            using (DAL.TaskDAL dal = new DAL.TaskDAL())
            {
                return dal.GetTaskByID(taskID, visible);
            }
        }
        public static Entity.TaskList GetAllTasks()
        {
            using (DAL.TaskDAL dal = new DAL.TaskDAL())
            {
                return dal.GetAllTasks();
            }
        }

        public static Entity.TaskList GetAllTasks(bool visible)
        {
            using (DAL.TaskDAL dal = new DAL.TaskDAL())
            {
                return dal.GetAllTasks(visible);
            }
        }

        #endregion

        #region Contact

        public static bool AssignOrganizationToContact(long organizationID, long contactID)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.AssignOrganization(organizationID, contactID);
            }
        }
        public static bool RemoveContactFromOrganization(long organizationID, long contactID)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.RemoveOrganization(organizationID, contactID);
            }
        }
        public static bool RemoveContactFromAllOrganizations(long contactID)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.RemoveContactFromAllOrganizations(contactID);
            }
        }
        public static bool UpdateContact(Entity.Contact obj)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.UpdateContact(obj);
            }
        }

        public static bool UpdateContact(WS.Contact obj)
        {
            Entity.Contact locObj = new Entity.Contact();
            locObj.ID = obj.ID;
            if (obj.Person != null)
                locObj.Person = obj.Person;
            else
                locObj.Person = new TSR.Core.UserAgentService.Person();
            locObj.Visible = true;

            return UpdateContact(locObj);
        }

        public static Entity.Contact GetContactByID(Int64 contactID)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetContactByID(contactID);
            }
        }

        public static Entity.Contact GetContactByID(Int64 contactID, bool visible)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetContactByID(contactID, visible);
            }
        }

        public static Entity.ContactList GetAllContacts()
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetAllContacts();
            }
        }

        public static Entity.ContactList GetAllContacts(bool visible)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetAllContacts(visible);
            }
        }
        public static Entity.ContactList GetContactsByOrganizationID(Int64 organizationID)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetContactsForOrganization(organizationID);
            }
        }

        public static Entity.ContactList GetContactsByOrganizationID(Int64 organizationID, bool visible)
        {
            using (DAL.ContactDAL dal = new DAL.ContactDAL())
            {
                return dal.GetContactsForOrganization(organizationID, visible);
            }
        }

        #endregion

        #region Note

        public static bool UpdateNote(Entity.Note note)
        {
            using (DAL.NoteDAL dal = new DAL.NoteDAL())
            {
                return dal.UpdateNote(note);
            }
        }

        public static bool UpdateNote(WS.Note note, Guid timeEntryID)
        {
            Entity.Note obj = new Entity.Note();

            obj.ID = note.ID;
            obj.TimeEntryID = timeEntryID;
            obj.Username = note.UserName;
            obj.FullName = note.FullName;
            //obj.FullName = ((note.User == null || note.User.Person == null) ? String.Empty : note.User.Person.FirstName + note.User.Person.LastName);
            //obj.Username = (note.User == null ? String.Empty : note.User.Username);
            obj.Subject = (String.IsNullOrEmpty(note.Subject) ? String.Empty : note.Subject);
            obj.Note = note.Note;
            obj.Timestamp = note.Timestamp;

            return UpdateNote(obj);
        }

        public static Entity.Note GetNoteByID(Int64 blogID)
        {
            using (DAL.NoteDAL dal = new DAL.NoteDAL())
            {
                return dal.GetNoteByID(blogID);
            }
        }

        public static NoteList GetAllNotes()
        {
            using (DAL.NoteDAL dal = new DAL.NoteDAL())
            {
                return dal.GetAllNotes();
            }
        }

        public static NoteList GetNotesByTimeEntryID(Guid timeEntryID)
        {
            using (DAL.NoteDAL dal = new DAL.NoteDAL())
            {
                return dal.GetNotesByTimeEntryID(timeEntryID);
            }
        }

        #endregion

        #region Web Service

        public static bool IsServiceUp(string serverAddress)
        {
            string error = string.Empty;
            return IsServiceUp(serverAddress, ref error);
        }

        public static bool IsServiceUp(ref string error)
        {
            string serverAddress = string.Empty;
            return IsServiceUp(serverAddress, ref error);
        }

        public static bool IsServiceUp(string serverAddress, ref string error)
        {
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(serverAddress);
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(serverAddress, GetTSRSSLMode());
            int count = 0;
            while (true)
            {
                if (count == TryConnectToServerCount - 1)
                {
                    try
                    {
                        success = service.IsServiceUp();
                    }
                    catch (System.ServiceModel.CommunicationException ex)
                    {
                        if (ex.InnerException != null)
                        {
                            if (ex.InnerException.GetType() == typeof(System.Net.WebException))
                                //error = ex.InnerException.Message; //much cleaner message
                                error = ResourceManager.GetResourceString("ServerUpFailureOrProxyWrongMsg", "Server address or proxy configuration is incorrect");
                        }
                        Core.Logging.LoggingHandler.LogError(ex);
                    }
                    catch (TimeoutException timeoutEx)
                    {
                        error = ResourceManager.GetResourceString("ServerTimeoutException",
                            "TimeSheet Reporter Outlook User Agent could not connect to server. Please restart Outlook when convenient. If the problem persists, please contact your system administrator.");
                        error += Environment.NewLine + ResourceManager.GetResourceString("PressOKToContinue", "Press OK to continue");

                        Core.Logging.LoggingHandler.LogError(timeoutEx);
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogError(ex);
                    }
                    break;
                }
                try
                {
                    success = service.IsServiceUp();
                }
                catch
                {
                }
                count++;
            }

            return success;
        }

        public static bool IsServiceUp(string serverAddress, ref string error, bool sslMode)
        {
            return IsServiceUp(serverAddress, ref error, sslMode, null, "", "", false, "", "", false, 0);
        }

        public static bool IsServiceUp(string serverAddress, ref string error, bool sslMode,
            SettingsHelper.ProxyTypeEnum? proxyType, string proxyHost, string proxyPort, bool isAuthentication, string proxyUsername, string proxyPassword,
            bool proxyAutoSwitch, int connectionTimeout)
        {
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(serverAddress);
            WS.UserAgentServiceClient service;
            if (proxyType != null)
                service = ServiceProvider.GetUserAgentService(serverAddress, sslMode, proxyType.Value, proxyHost, proxyPort, isAuthentication,
                    proxyUsername, proxyPassword, proxyAutoSwitch, connectionTimeout);
            else
                service = ServiceProvider.GetUserAgentService(serverAddress, sslMode);

            int count = 0;
            while (true)
            {
                if (count == TryConnectToServerCount - 1)
                {
                    try
                    {
                        success = service.IsServiceUp();
                    }
                    catch (System.ServiceModel.CommunicationException ex)
                    {
                        if (ex.InnerException != null)
                        {
                            if (ex.InnerException.GetType() == typeof(System.Net.WebException))
                                //error = ex.InnerException.Message; //much cleaner message
                                error = ResourceManager.GetResourceString("ServerUpFailureOrProxyWrongMsg", "Server address or proxy configuration is incorrect");
                        }
                        Core.Logging.LoggingHandler.LogError(ex);
                    }
                    catch (TimeoutException timeoutEx)
                    {
                        error = ResourceManager.GetResourceString("ServerTimeoutException",
                            "TimeSheet Reporter Outlook User Agent could not connect to server. Please restart Outlook when convenient. If the problem persists, please contact your system administrator.");
                        error += Environment.NewLine + ResourceManager.GetResourceString("PressOKToContinue", "Press OK to continue");

                        Core.Logging.LoggingHandler.LogError(timeoutEx);
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogError(ex);
                    }
                    break;
                }
                try
                {
                    success = service.IsServiceUp();
                    break;
                }
                catch
                {
                }
                count++;
            }
            return success;
        }

        public static string GetCurrentUsername()
        {
            string username = string.Empty;

            WindowsIdentity wi = WindowsIdentity.GetCurrent();

            if (wi.IsAuthenticated)
            {
                username = wi.Name.Substring(wi.Name.LastIndexOf('\\') + 1);
            }
            return username;
        }


        //public static bool IsUserAuthenticated()
        //{
        //    return AuthenticateUser(TSR.Core.SettingsHelper.TSRUserName, TSR.Core.SettingsHelper.TSRPassword);
        //}

        //public static bool IsADUserAuthenticated()
        //{
        //    WindowsIdentity wi = WindowsIdentity.GetCurrent();

        //    if (wi.IsAuthenticated)
        //    {
        //        WindowsPrincipal principal = new WindowsPrincipal(wi);
        //        System.Threading.Thread.CurrentPrincipal = principal;
        //        DirectoryEntry de = ADHelper.UserExists(wi.Name.Substring(wi.Name.LastIndexOf('\\') + 1));

        //        if (de != null)
        //        {
        //            AUTH.AuthenticationService service = ServiceProvider.GetAuthenticationService(String.Empty);
        //            AUTH.ResponseMessageOfBoolean response = service.PerformADLogin(wi.Name.Substring(wi.Name.LastIndexOf('\\') + 1), wi.User.Value);
        //            return response.Data;
        //        }
        //    }
        //    return false;
        //}

        //public static bool AuthenticateUser(string UserName, string Password, string serveraddress)
        //{
        //    AUTH.AuthenticationService service = ServiceProvider.GetAuthenticationService(serveraddress);
        //    AUTH.ResponseMessageOfBoolean response = service.PerformLogin(UserName, Password);
        //    return response.Data;
        //}

        //public static bool AuthenticateUser(string UserName, string Password)
        //{
        //    return AuthenticateUser(UserName, Password, String.Empty);
        //}

        public static bool UpdateLanguageResources(TSR.Core.Entity.LanguageResources lr)
        {
            using (DAL.LanguageResourcesDAL dal = new TSR.Core.DAL.LanguageResourcesDAL())
            {
                return dal.UpdateLanguageResources(lr);
            }
        }

        internal static bool FetchAndProcessResourceData()
        {
            bool success = false;
            try
            {
                //SettingsHelper.UpdateCurrentCulture(); //comment by tsrdev2
                WS.RequestMessageOfLanguageResourcesListWM9H3p7p lrList;
                WS.RequestMessageOfstring languageName = new WS.RequestMessageOfstring();
                WS.RequestMessageOfstring languageId = new WS.RequestMessageOfstring();
                WS.LanguageResourcesList list = new WS.LanguageResourcesList();

                WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
                WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
                userName.Data = GetNONADUserName();
                pass.Data = GetNONADPassword();

                LanguageResourcesList localList = new LanguageResourcesList();
                LanguageResourcesList englishList = new LanguageResourcesList();
                string currentLanguageName = TSR.Core.SettingsHelper.TSRLanguageName;
                //get local list
                using (DAL.LanguageResourcesDAL dal = new DAL.LanguageResourcesDAL())
                {
                    localList = dal.GetLanguageResourcesByLanguageName(currentLanguageName);
                    englishList = dal.GetLanguageResourcesForEnglish(); //languageName is "US English"
                    //if (localList.Count == 0)
                    //{
                    //    localList = dal.GetLanguageResourcesByLanguageId("en");
                    //}
                    if (localList.Count < englishList.Count)
                    {
                        localList = dal.GetLanguageResourcesForEnglish();
                    }
                }

                //transfer it to service request
                foreach (var item in localList)
                {
                    list.Add(new WS.LanguageResources
                    {
                        LanguageID = item.LanguageID,
                        LanguageName = item.LanguageName,
                        ResourceKey = item.ResourceKey,
                        ResourceValue = item.ResourceValue
                    });
                }
                lrList = new WS.RequestMessageOfLanguageResourcesListWM9H3p7p();
                lrList.Data = list;

                //get the service
                //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
                WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

                //languageID.Data = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
                languageName.Data = currentLanguageName;
                languageId.Data = TSR.Core.SettingsHelper.TSRLanguageId;
                //call the service method
                WS.ResponseMessageOfLanguageResourcesListWM9H3p7p response = service.GetLanguageXML(userName, pass, languageName, lrList);
                success = response.IsSuccessful;

                if (success)
                {//got the data
                    if (response.Data != null)
                    {
                        //list = lrList.Data;
                        list = response.Data;
                        foreach (WS.LanguageResources lr in list)
                        {
                            using (DAL.LanguageResourcesDAL dal = new DAL.LanguageResourcesDAL())
                            {
                                LanguageResources exlr = dal.GetLanguageResourcesByLanguageNameAndResourceKey(languageName.Data, lr.ResourceKey);

                                TSR.Core.Entity.LanguageResources lrEntity = new TSR.Core.Entity.LanguageResources(lr.LanguageID, lr.LanguageName, lr.ResourceKey, lr.ResourceValue);
                                if (!String.IsNullOrEmpty(exlr.LanguageID))
                                {
                                    lrEntity.ID = exlr.ID;
                                }
                                success = dal.UpdateLanguageResources(lrEntity);
                            }
                            //list.Add(lrEntity);
                        }
                    }
                }
                else
                {
                    //if (!string.IsNullOrEmpty(response.ErrorMessage))
                    //    throw new Exception(response.ErrorMessage);
                }
            }
            catch (Exception exp)
            {
                TSR.Core.Logging.LoggingHandler.LogError(exp);
                throw exp;
            }
            return success;
        }

        /// <summary>
        /// Retrieves preferred paths/ favorites settings from server through WCF service
        /// </summary>
        /// <returns></returns>
        internal static bool GetPreferredPathFromServer()
        {
            bool success = false;
            PreferredPathsList preferredPathsList = new PreferredPathsList();
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfArrayOfPreferredPathLJ8bkyxQ response = service.GetPreferredPathsFromServer(userName, pass);

            if (response.IsSuccessful)
            {
                //got response, now convert it to local format, before local updates
                foreach (var item in response.Data)
                {
                    preferredPathsList.Add(new PreferredPaths
                    {
                        OrganizationID = item.OrganizationID,
                        ProjectID = item.ProjectID,
                        ActivityID = item.ActivityID,
                        TaskID = ((item.TaskID.HasValue) ? item.TaskID : -1)
                        ,
                        IsDefault = item.IsDefault
                    });
                }

                DeleteAllPreferredPaths();
                UpdatePreferredPaths(preferredPathsList);
                success = response.IsSuccessful;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }




            return success;
        }

        /// <summary>
        /// Saves local favorites settings in server through WCF service
        /// </summary>
        /// <returns></returns>
        internal static bool SavePreferredPathsInServer()
        {
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfArrayOfPreferredPathLJ8bkyxQ rPrefPaths = new WS.RequestMessageOfArrayOfPreferredPathLJ8bkyxQ();
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            //rPrefPaths.LanguageID = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
            //at first get local favorite settings
            Entity.PreferredPathsList ppList = GetAllPreferredPathsList();
            List<WS.PreferredPath> wsppList = new List<WS.PreferredPath>();

            //convert it to suitable format for WCF conversation
            foreach (var item in ppList)
            {
                wsppList.Add(new TSR.Core.UserAgentService.PreferredPath
                {
                    ActivityID = item.ActivityID,
                    OrganizationID = item.OrganizationID,
                    IsDefault = item.IsDefault,
                    ProjectID = item.ProjectID,
                    ContactID = ((item.ContactID.HasValue) ? item.ContactID : -1)
                    ,
                    TaskID = ((item.TaskID.HasValue) ? item.TaskID.Value : -1)
                });
            }
            rPrefPaths.Data = wsppList.ToArray();

            //conversion done. now, call the service
            WS.ResponseMessageOfboolean response = service.SavePreferredPathsInServer(userName, pass, rPrefPaths);

            if (!response.Data)
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return response.Data;
        }
        /// <summary>
        /// Retrieves User settings from server through WCF service
        /// </summary>
        /// <returns>Type UserSettingsList</returns>
        public static UserSettingsList GetUserSettingsList()
        {
            UserSettingsList userSettingList = new UserSettingsList();
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfboolean requestIsDefault = new TSR.Core.UserAgentService.RequestMessageOfboolean();
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();
            WS.ResponseMessageOfArrayOfUserSettingLJ8bkyxQ response = service.GetUserSettingsFromServer(userName, pass, requestIsDefault);
            if (response.Data != null)
            {
                foreach (var item in response.Data)
                {
                    UserSettings objUserSetting = new UserSettings();
                    objUserSetting.ID = item.ID;
                    objUserSetting.Key = item.SettingsName;
                    objUserSetting.Value = item.SettingsValue;
                    userSettingList.Add(objUserSetting);
                }
            }
            return userSettingList;
        }
        /// <summary>
        /// Saves local User settings in server through WCF service
        /// </summary>
        /// <returns></returns>
        internal static bool SaveUserSettingsInServer()
        {
            //Type objType = typeof(ResourceHelper);
            try
            {
                WS.RequestMessageOfboolean requestIsDefault = new TSR.Core.UserAgentService.RequestMessageOfboolean();
                WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
                WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
                userName.Data = GetNONADUserName();
                pass.Data = GetNONADPassword();
                //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
                WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

                WS.RequestMessageOfArrayOfUserSettingLJ8bkyxQ reqUserSettingsList = new WS.RequestMessageOfArrayOfUserSettingLJ8bkyxQ();
                //reqUserSettingsList.LanguageID = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;

                ////userSetList.Data
                List<WS.UserSetting> localUserSettingsList = new List<TSR.Core.UserAgentService.UserSetting>();

                //tsrdev
                bool isValid = (SettingsHelper.TSRAutoSyncPeriod == 0 && SettingsHelper.TSRAutoSyncIndex < SettingsHelper.TSRAUTO_SYNC_INDEX_MINIMUM) ||
                    (SettingsHelper.TSRAutoSyncPeriod == 1 && SettingsHelper.TSRAutoSyncIndex < 1);
                if (isValid)
                {
                    SettingsHelper.TSRAutoSyncIndex = SettingsHelper.TSRAUTO_SYNC_INDEX_MINIMUM;
                    SettingsHelper.TSRAutoSyncPeriod = 0;
                }

                SettingsHelper sh = new SettingsHelper();
                foreach (PropertyInfo item in sh.GetType().GetProperties(BindingFlags.Public | BindingFlags.Static))
                {
                    if (((item.PropertyType == typeof(System.String))
                        || (item.PropertyType == typeof(System.Int32))
                        || (item.PropertyType == typeof(System.Boolean))
                        )
                        && ((item.Name != SettingsHelper.TSRPASSWORD_SETTING)
                        && (item.Name != SettingsHelper.TSRSERVERADDRESS_SETTING)
                        && (item.Name != SettingsHelper.TSRUSERNAME_SETTING)
                        && (item.Name != SettingsHelper.TSRWEBINTERFACE_SETTING)
                        && (item.Name != SettingsHelper._TSRDontShowAgain)
                        && (item.Name != SettingsHelper.TSRDO_NOT_RETRIEVE_SETTING_SERVER)
                        && (item.Name != SettingsHelper.PROXY_CONNECTION_TIMEOUT)
                        && (!item.Name.ToUpper().StartsWith("PROXY")) //not save proxy setting to server
                        ))
                    {
                        //if (!string.IsNullOrEmpty(item.GetValue(null,null).ToString()) && !string.IsNullOrEmpty(item.Name))
                        localUserSettingsList.Add(new WS.UserSetting { SettingsName = item.Name, SettingsValue = item.GetValue(null, null).ToString() });
                    }
                    else if (item.PropertyType == typeof(StringCollection))
                    {
                        StringCollection value = (StringCollection)item.GetValue(null, null);
                        string setValue = value[0].ToString();
                        localUserSettingsList.Add(new WS.UserSetting { SettingsName = item.Name, SettingsValue = setValue.ToString() });
                    }
                }


                reqUserSettingsList.Data = localUserSettingsList.ToArray();

                WS.ResponseMessageOfboolean response = service.SaveUserSettingsInServer(userName, pass, reqUserSettingsList);
                if (!response.Data)
                {
                    if (!string.IsNullOrEmpty(response.ErrorMessage))
                        throw new Exception(response.ErrorMessage);
                }
                if (response.Data)
                {
                    return SaveMachineSpecificSettingsDataIntoServer();
                }
                return false;
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                throw ex;
            }

        }
        internal static string GetPreferredPathAsString(StringCollection sc)
        {
            StringBuilder sb = new StringBuilder();
            //foreach (string st in sc)
            //{
            //    sb.Append(st);
            //    sb.Append("|");
            //}
            for (int i = 0; i < sc.Count - 1; i += 2)
            {
                sb.Append(sc[i]);
                sb.Append(Constants.DEFAULT_SEPERATOR_LANGUAGENAME_LANGUAGEID);
                sb.Append(sc[i + 1]);
                sb.Append(Constants.DEFAULT_SEPERATOR_PREFERREDLANGUAGE);
            }
            return sb.ToString();
        }

        internal static bool SaveMachineSpecificSettingsDataIntoServer()
        {
            TSRDataSet dsMacSettings = new TSRDataSet();
            WS.RequestMessageOfstring reqMachine = GetMachineID();
            WS.RequestMessageOfstring reqMacAppData = new WS.RequestMessageOfstring();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            reqMacAppData.Data = string.Empty;

            dsMacSettings.Tables.Add(DAL.BaseDAL.MyDataSet.Tables["Settings"].Copy());


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());


            //get machinespecific settings data
            WS.RequestMessageOfstring macSpecSettingData = new WS.RequestMessageOfstring();
            macSpecSettingData.Data = dsMacSettings.GetXml();

            WS.ResponseMessageOfboolean response = (GetExchangeMode()) ? service.SaveMachineSpecificDataForEX(userName, pass, reqMachine, macSpecSettingData, reqMacAppData) : service.SaveMachineSpecificData(userName, pass, reqMachine, macSpecSettingData, reqMacAppData);

            return response.Data;
        }

        public static bool UpdateLockPeriodSetting()
        {
            //Lay du lieu tu DB
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfboolean requestIsDefault = new TSR.Core.UserAgentService.RequestMessageOfboolean();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            requestIsDefault.Data = true;
            WS.ResponseMessageOfArrayOfUserSettingLJ8bkyxQ response = service.GetUserSettingsFromServer(userName, pass, requestIsDefault);

            if (response.IsSuccessful)
            {
                var settingsValue = "False";
                var lockPeriod = response.Data.FirstOrDefault(x => x.SettingsName.Equals(SettingsHelper.TSRLOCKPERIOD));
                if (lockPeriod != null)
                {
                    settingsValue = lockPeriod.SettingsValue;
                }

                var settings = new Settings()
                {
                    Key = SettingsHelper.TSRLOCKPERIOD,
                    Value = settingsValue
                };

                DAL.SettingsDAL settingDAL = new DAL.SettingsDAL();

                success = settingDAL.UpdateSettings(settings);
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            
            return success;
        }


        /// <summary>
        /// Retrieves User settings from server through WCF service
        /// </summary>
        /// <returns></returns>
        public static bool GetUserSettingFromServer(bool IsDefault)
        {
            //Lay du lieu tu DB
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfboolean requestIsDefault = new TSR.Core.UserAgentService.RequestMessageOfboolean();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            requestIsDefault.Data = IsDefault;
            WS.ResponseMessageOfArrayOfUserSettingLJ8bkyxQ response = service.GetUserSettingsFromServer(userName, pass, requestIsDefault);

            PropertyInfo propInfo;
            SettingsHelper sh = new SettingsHelper();
            //string[] tempStrings;
            StringCollection spCollection = new StringCollection();
            if (response.IsSuccessful)
            {
                //got response, now convert it to local format, before local updates
                foreach (var item in response.Data)
                {
                    if ((item.SettingsName == SettingsHelper.PROXY_CONNECTION_TIMEOUT)
                       || (item.SettingsName.ToUpper().StartsWith("PROXY")))
                        continue;

                    propInfo = sh.GetType().GetProperty(item.SettingsName, BindingFlags.Public | BindingFlags.Static);
                    if (propInfo != null)
                    {
                        if (propInfo.PropertyType == typeof(System.String))
                        {
                            if (propInfo.CanWrite)
                                propInfo.SetValue(null, item.SettingsValue, null);
                        }
                        else if (propInfo.PropertyType == typeof(System.Int32))
                        {
                            propInfo.SetValue(null, Convert.ToInt32(item.SettingsValue), null);
                        }
                        else if (propInfo.PropertyType == typeof(System.Boolean))
                        {
                            propInfo.SetValue(null, Convert.ToBoolean(item.SettingsValue), null);
                        }
                        //else if (propInfo.PropertyType == typeof(StringCollection))
                        //{
                        //    tempStrings = Regex.Split(item.SettingsValue, "<>");
                        //    foreach (string s in tempStrings)
                        //    {
                        //        spCollection.Add(s);
                        //    }
                        //    propInfo.SetValue(null, spCollection, null);
                        //}
                    }

                    if (item.SettingsName.Equals(SettingsHelper.IsDurationWarningEnable, StringComparison.InvariantCultureIgnoreCase) || item.SettingsName.Equals(SettingsHelper.DurationWarning, StringComparison.InvariantCultureIgnoreCase))
                    {
                        TSR.Core.TSRFacade.SetUserSettingsValueByKey(item.SettingsName, item.SettingsValue);
                    }
                    if (item.SettingsName.Equals(Constants.CONST_ENFORCE, StringComparison.InvariantCultureIgnoreCase) || item.SettingsName.Equals(Constants.CONST_ENFORCE, StringComparison.InvariantCultureIgnoreCase))
                    {
                        TSR.Core.TSRFacade.SetUserSettingsValueByKey(item.SettingsName, item.SettingsValue);
                    }
                }
                //tsrdev
                bool isValid = (SettingsHelper.TSRAutoSyncPeriod == 0 && SettingsHelper.TSRAutoSyncIndex < SettingsHelper.TSRAUTO_SYNC_INDEX_MINIMUM) ||
                    (SettingsHelper.TSRAutoSyncPeriod == 1 && SettingsHelper.TSRAutoSyncIndex < 1);
                if (isValid)
                {
                    SettingsHelper.TSRAutoSyncIndex = SettingsHelper.TSRAUTO_SYNC_INDEX_MINIMUM;
                    SettingsHelper.TSRAutoSyncPeriod = 0;
                }
                success = response.IsSuccessful;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            success = getMachineSpecificSettings();

            return success;
        }

        private static bool getMachineSpecificSettings()
        {
            bool success = true;
            TSRDataSet settingsDataset = GetTSRDataSetWithSettingsDataFromServer();
            DAL.SettingsDAL settingDAL = new DAL.SettingsDAL();
            SettingsList setList = settingDAL.FillSettingses(settingsDataset.Tables["Settings"].Rows);
            foreach (Settings item in setList)
            {
                if (!settingDAL.UpdateSettings(item))
                    success = false;
            }

            return success;
        }

        //Added by tsrdev1
        //Added datetime 08/11/2010
        public static string GetCalendarSettingFromServer()
        {
            string calendarSetting = string.Empty;
            TSRDataSet settingsDataset = GetTSRDataSetWithSettingsDataFromServer();
            DAL.SettingsDAL settingDAL = new DAL.SettingsDAL();
            SettingsList setList = settingDAL.FillSettingses(settingsDataset.Tables["Settings"].Rows);
            foreach (Settings item in setList)
            {
                if (item.Key == "Calendar")
                    calendarSetting = item.Value;
            }

            return calendarSetting;
        }
        /// <summary>
        /// Retrieves preferred languages from server and updates local storage with this data
        /// </summary>
        /// <returns></returns>
        public static bool FetchAndProcessPreferredLanguages()
        {
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfArrayOfanyTypeuHEDJ7Dj response = service.GetLanguages(userName, pass);
            StringCollection collection = new StringCollection();
            if (response.IsSuccessful)
            {
                //foreach (string languageId in response.Data)
                //{
                //    collection.Add(languageId);
                //}
                foreach (string languageName in response.Data)
                {
                    collection.Add(languageName);
                }

                //updating local storage
                TSR.Core.SettingsHelper.TSRPreferredLanguages = collection;
                return true;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return false;
        }

        /// <summary>
        /// retrieves setup data and updates local storage with this data
        /// </summary>
        /// <returns></returns>
        internal static bool FetchAndProcessSetupData_FullUpdate()
        {
            bool success = false;
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            WS.RequestMessageOflong organizationID = new WS.RequestMessageOflong();

            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            #region Force Full Location Synchronization

            WS.ResponseMessageOfLocationListGCtaaEQZ responseGetLocations = service.GetLocationsForCheckData(userName, pass);
            success = responseGetLocations.IsSuccessful;
            if (success)
            {
                var listLcOUA = TSRFacade.GetAllLocations();
                foreach (var lcOUA in listLcOUA)
                {
                    if (!(responseGetLocations.Data.Exists(delegate(WS.Location lc) { return lc.ID == lcOUA.ID; })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByLocationID(lcOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;
                    }
                }

                foreach (WS.Location lc in responseGetLocations.Data)
                {
                    //updates location
                    success = UpdateLocation(lc);
                    if (!success)
                        return false;
                }
            }

            #endregion

            #region Force Full Synchronization
            WS.ResponseMessageOfOrganizationListWM9H3p7p response = service.GetSetupData_Organization(userName, pass);
            success = response.IsSuccessful;
            if (success)
            {
                //Add by tsrdev1
                OrganizationList listOrgOUA = TSRFacade.GetAllOrganizations();
                foreach (Organization orgOUA in listOrgOUA)
                {
                    if (!(response.Data.Exists(delegate(WS.Organization org) { return org.ID == orgOUA.ID; })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByOrganizationID(orgOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        ProjectList listPrjOUA = GetProjectsForOrganization(orgOUA.ID);

                        if (listPrjOUA != null)
                        {
                            foreach (Project prj in listPrjOUA)
                            {
                                success = RemoveProjectFromOrganization(orgOUA.ID, prj.ID);
                                if (!success)
                                    return false;

                                ActivityList listActOUA = GetActivitiesForProject(prj.ID);
                                foreach (Activity actOUA in listActOUA)
                                {
                                    //links between activity and project
                                    success = RemoveActivityFromProject(prj.ID, actOUA.ID);
                                    if (!success)
                                        return false;

                                    actOUA.Visible = false;
                                    success = UpdateActivity(actOUA);
                                    if (!success)
                                        return false;
                                }
                                //updates local storage with project                                
                                prj.Visible = false;
                                success = UpdateProject(prj);
                                if (!success)
                                    return false;
                            }
                        }

                        ContactList listContactOUA = GetContactsByOrganizationID(orgOUA.ID);
                        if (listContactOUA != null)
                        {
                            foreach (Contact cnt in listContactOUA)
                            {
                                success = RemoveContactFromOrganization(orgOUA.ID, cnt.ID);
                                if (!success)
                                    return false;

                                //updates contacts                                
                                cnt.Visible = false;

                                success = UpdateContact(cnt);

                                if (!success)
                                    return false;
                            }
                        }

                        orgOUA.Visible = false;
                        //update local storage with organization
                        success = UpdateOrganization(orgOUA);
                        if (!success)
                            return false;
                    }
                }
                //end

                foreach (WS.Organization org in response.Data)
                {
                    //update local storage with organization
                    success = UpdateOrganization(org);
                    if (!success)
                        return false;

                    //Add by tsrdev1
                    ProjectList listProjOUA = new ProjectList();
                    listProjOUA = TSRFacade.GetProjectsForOrganization(org.ID);

                    organizationID.Data = org.ID;
                    WS.ResponseMessageOfProjectListWM9H3p7p responseProject = service.GetSetupData_Project(userName, pass, organizationID);

                    foreach (Project projOUA in listProjOUA)
                    {
                        if (!(responseProject.Data.Exists(delegate(WS.Project proj) { return proj.ID == projOUA.ID; })))
                        {
                            PreferredPathsList paths = GetPreferredPathsListByProjectID(projOUA.ID);
                            if (paths != null)
                                success = DeletePreferredPathsList(paths);
                            if (!success)
                                return false;

                            success = RemoveProjectFromOrganization(org.ID, projOUA.ID);
                            if (!success)
                                return false;

                            success = RemoveAllActivitiesFromProject(projOUA.ID);
                            if (!success)
                                return false;

                            projOUA.Visible = false;
                            success = UpdateProject(projOUA);
                            if (!success)
                                return false;
                        }
                    }
                    //end

                    foreach (WS.Project prj in responseProject.Data)
                    {
                        //updates local storage with project
                        success = UpdateProject(prj);
                        if (!success)
                            return false;

                        //links between organization and project
                        success = AssignOrganizationToProject(org.ID, prj.ID);

                        if (!success)
                            return false;

                        ActivityList listActOUA = GetActivitiesForProject(prj.ID);

                        foreach (Activity actOUA in listActOUA)
                        {
                            if (!(prj.ActivityList.Exists(delegate(WS.Activity activity) { return activity.ID == actOUA.ID; })))
                            {
                                PreferredPathsList paths = GetPreferredPathsListByActivityID(actOUA.ID);
                                if (paths != null)
                                    success = DeletePreferredPathsList(paths);
                                if (!success)
                                    return false;
                                //links between activity and project
                                success = RemoveActivityFromProject(prj.ID, actOUA.ID);
                                if (!success)
                                    return false;

                                actOUA.Visible = false;
                                success = UpdateActivity(actOUA);
                                if (!success)
                                    return false;
                            }
                        }

                        foreach (WS.Activity act in prj.ActivityList)
                        {
                            //updates activity
                            success = UpdateActivity(act);

                            if (!success)
                                return false;

                            //links between activity and project
                            success = AssignProjectToActivity(prj.ID, act.ID);

                            if (!success)
                                return false;
                        }
                    }

                    ContactList listCntOUA = GetContactsByOrganizationID(org.ID);
                    foreach (Contact cntOUA in listCntOUA)
                    {
                        if (!(org.ContactList.Exists(delegate(WS.Contact cnt) { return cnt.ID == cntOUA.ID; })))
                        {
                            PreferredPathsList paths = GetPreferredPathsListByContactID(cntOUA.ID);
                            if (paths != null)
                                success = DeletePreferredPathsList(paths);
                            if (!success)
                                return false;

                            //links between activity and project
                            success = RemoveContactFromOrganization(org.ID, cntOUA.ID);
                            if (!success)
                                return false;
                            cntOUA.Visible = false;
                            success = UpdateContact(cntOUA);
                            if (!success)
                                return false;
                        }
                    }
                    foreach (WS.Contact cnt in org.ContactList)
                    {
                        //updates contacts
                        success = UpdateContact(cnt);
                        if (!success)
                            return false;
                        //links between organization and contact
                        success = AssignOrganizationToContact(org.ID, cnt.ID);
                        if (!success)
                            return false;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            #endregion

            return success;
        }

        internal static bool FetchAndProcessSetupData_CheckChanges()
        {
            bool success = false;
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            WS.RequestMessageOflong organizationID = new WS.RequestMessageOflong();

            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            #region Fetch and process with checking changes
            WS.ResponseMessageOfOrganizationVersionListWM9H3p7p responseDataRelation = service.GetSetupDataRelation(userName, pass);
            success = responseDataRelation.IsSuccessful;

            if (success)
            {
                #region Get list of changed setup data

                WS.RequestMessageOfArrayOflonguHEDJ7Dj msgOrgChanged = new WS.RequestMessageOfArrayOflonguHEDJ7Dj(),
                    msgProjChanged = new WS.RequestMessageOfArrayOflonguHEDJ7Dj(),
                    msgActChanged = new WS.RequestMessageOfArrayOflonguHEDJ7Dj();

                OrganizationList listLocalOrganizationOUA = TSRFacade.GetAllOrganizations();
                ProjectList listLocalProjectOUA = TSRFacade.GetAllProjects();
                ActivityList listLocalActivityOUA = TSRFacade.GetAllActivities();
               
                Project_ActivityList listLocalProjActOUA = TSRFacade.GetAllProject_Activity();
                Organization_ProjectList listLocalOrgPrjOUA = TSRFacade.GetAllOrganization_Project();

                List<Int64> listOrgChanged = new List<Int64>(),
                    listProjChanged = new List<Int64>(),
                    listActChanged = new List<Int64>();

                ArrayList listOrgChecked = new ArrayList(),
                    listProjChecked = new ArrayList(),
                    listActChecked = new ArrayList();

                ArrayList listPrjActChecked = new ArrayList(),
                    listOrgPrjChecked = new ArrayList();

                Organization orgOUA = null;
                Project projOUA = null;
                Activity actOUA = null;
                Project_Activity prjActOUA = null;
                Organization_Project orgPrjOUA = null;

                #region Get changed list of Organization, Project, Activity

                foreach (WS.OrganizationVersion item in responseDataRelation.Data)
                {
                    if (!listOrgChecked.Contains(item.OrgID))
                    {
                        listOrgChecked.Add(item.OrgID);

                        if (!listOrgChanged.Contains(item.OrgID))
                        {
                            orgOUA = listLocalOrganizationOUA.FindByID(item.OrgID);
                            if ((orgOUA != null
                                    && (String.IsNullOrEmpty(orgOUA.Modified)
                                    || !orgOUA.Modified.Equals(item.OrgReversion)))
                                || (orgOUA == null))
                            {
                                listOrgChanged.Add(item.OrgID);
                            }
                        }
                        if (orgOUA != null)
                            listLocalOrganizationOUA.Remove(orgOUA);
                    }
                    
                    if (!listProjChecked.Contains(item.ProjID))
                    {
                        listProjChecked.Add(item.ProjID);

                        if (!listProjChanged.Contains(item.ProjID))
                        {
                            projOUA = listLocalProjectOUA.FindByID(item.ProjID);

                            if ((projOUA != null
                                    && (String.IsNullOrEmpty(projOUA.Modified)
                                    || !projOUA.Modified.Equals(item.ProjReversion)))
                                || (projOUA == null))
                            {
                                listProjChanged.Add(item.ProjID);
                            }
                        }
                        if (projOUA != null)
                            listLocalProjectOUA.Remove(projOUA);
                    }
                    
                    if (!listActChecked.Contains(item.ActID))
                    {
                        listActChecked.Add(item.ActID);

                        if (!listActChanged.Contains(item.ActID))
                        {
                            actOUA = listLocalActivityOUA.FindByID(item.ActID);

                            if ((actOUA != null
                                    && (String.IsNullOrEmpty(actOUA.Modified)
                                    || !actOUA.Modified.Equals(item.ActReversion)))
                                || (actOUA == null))
                            {
                                listActChanged.Add(item.ActID);
                            }
                        }
                        if (actOUA != null)
                            listLocalActivityOUA.Remove(actOUA);
                    }                    

                    if (!listPrjActChecked.Contains(String.Format("{0}_{1}", item.ProjID, item.ActID)))
                    {
                        prjActOUA = listLocalProjActOUA.FindByID(item.ProjID, item.ActID);
                        if (prjActOUA == null)
                        {
                            AssignProjectToActivity(item.ProjID, item.ActID);
                        }
                        listPrjActChecked.Add(String.Format("{0}_{1}", item.ProjID, item.ActID));
                        if (prjActOUA != null)
                            listLocalProjActOUA.Remove(prjActOUA);
                    }
                    
                    if (!listOrgPrjChecked.Contains(String.Format("{0}_{1}", item.OrgID, item.ProjID)))
                    {
                        orgPrjOUA = listLocalOrgPrjOUA.FindByID(item.OrgID, item.ProjID);
                        if (orgPrjOUA == null)
                        {
                            AssignOrganizationToProject(item.OrgID, item.ProjID);
                        }
                        listOrgPrjChecked.Add(String.Format("{0}_{1}", item.OrgID, item.ProjID));

                        if (orgPrjOUA != null)
                            listLocalOrgPrjOUA.Remove(orgPrjOUA);
                    }                    
                }
                #endregion

                #region Get changed list of contact

                ContactList listLocalContactOUA = TSRFacade.GetAllContacts();
                Organization_ContactList listLocalOrgCntOUA = TSRFacade.GetAllOrganization_Contact();
                WS.RequestMessageOfArrayOflonguHEDJ7Dj msgCntChanged = new WS.RequestMessageOfArrayOflonguHEDJ7Dj();
                List<Int64> listCntChanged = new List<Int64>();

                Contact cntOUA = null;
                Organization_Contact orgCntOUA = null;
                WS.ResponseMessageOfContactVersionListWM9H3p7p responseContactVersionList = service.GetSetupData_Contacts(userName, pass);

                foreach (WS.ContactVersion item in responseContactVersionList.Data)
                {
                    if (!listCntChanged.Contains(item.ContactID))
                    {
                        cntOUA = listLocalContactOUA.FindByID(item.ContactID);

                        if ((cntOUA != null
                                && (String.IsNullOrEmpty(cntOUA.Modified)
                                || !cntOUA.Modified.Equals(item.ContactReversion)))
                            || (cntOUA == null))
                        {
                            listCntChanged.Add(item.ContactID);
                        }
                    }
                    if (cntOUA != null)
                        listLocalContactOUA.Remove(cntOUA);

                    orgCntOUA = listLocalOrgCntOUA.FindByID(item.OrganizationID, item.ContactID);
                    if (orgCntOUA == null)
                    {
                        AssignOrganizationToContact(item.OrganizationID, item.ContactID);
                    }
                    if (orgCntOUA != null)
                        listLocalOrgCntOUA.Remove(orgCntOUA);
                }
                #endregion

                #endregion

                #region Update Organization
                
                foreach (Organization orgLocal in listLocalOrganizationOUA)
                {
                    if (!responseDataRelation.Data.Exists(delegate(WS.OrganizationVersion o) { return o.OrgID == orgLocal.ID; }))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByOrganizationID(orgLocal.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        orgLocal.Visible = false;
                        success = UpdateOrganization(orgLocal);
                        if (!success)
                            return false;
                    }
                }
                if (listOrgChanged.Count > 0)
                {
                    msgOrgChanged.Data = listOrgChanged.ToArray();
                    WS.ResponseMessageOfOrganizationListWM9H3p7p responseChangedOrg = service.GetSetupData_ChangedOrganizations(userName, pass, msgOrgChanged);

                    if (responseChangedOrg.IsSuccessful)
                    {
                        foreach (WS.Organization org in responseChangedOrg.Data)
                        {
                            //update local storage with organization
                            success = UpdateOrganization(org);
                            if (!success)
                                return false;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(responseChangedOrg.ErrorMessage))
                            throw new Exception(responseChangedOrg.ErrorMessage);
                    }
                }
                #endregion

                #region Update Project
                
                foreach (Project prjLocal in listLocalProjectOUA)
                {
                    if (!responseDataRelation.Data.Exists(delegate(WS.OrganizationVersion o) { return o.ProjID == prjLocal.ID; }))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByProjectID(prjLocal.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;
                        prjLocal.Visible = false;
                        success = UpdateProject(prjLocal);
                        if (!success)
                            return false;
                    }
                }

                if (listProjChanged.Count > 0)
                {
                    msgProjChanged.Data = listProjChanged.ToArray();
                    WS.ResponseMessageOfProjectListWM9H3p7p responseChangedProj = service.GetSetupData_ChangedProjects(userName, pass, msgProjChanged);

                    //Update data from server to local
                    if (responseChangedProj.IsSuccessful)
                    {
                        foreach (WS.Project prj in responseChangedProj.Data)
                        {
                            //updates local storage with project
                            success = UpdateProject(prj);
                            if (!success)
                                return false;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(responseChangedProj.ErrorMessage))
                            throw new Exception(responseChangedProj.ErrorMessage);
                    }
                }
                #endregion

                #region Update Activity
                
                foreach (Activity actLocal in listLocalActivityOUA)
                {
                    if (!(responseDataRelation.Data.Exists(delegate(WS.OrganizationVersion o) { return o.ActID == actLocal.ID; })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByActivityID(actLocal.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;
                        actLocal.Visible = false;
                        success = UpdateActivity(actLocal);
                        if (!success)
                            return false;
                    }
                }
                if (listActChanged.Count > 0)
                {
                    msgActChanged.Data = listActChanged.ToArray();
                    WS.ResponseMessageOfActivityListWM9H3p7p responseChangedAct = service.GetSetupData_ChangedActivities(userName, pass, msgActChanged);

                    if (responseChangedAct.IsSuccessful)
                    {
                        foreach (WS.Activity act in responseChangedAct.Data)
                        {
                            success = UpdateActivity(act);
                            if (!success)
                                return false;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(responseChangedAct.ErrorMessage))
                            throw new Exception(responseChangedAct.ErrorMessage);
                    }
                }
                #endregion

                #region Update Contact
                foreach (Contact cntLocalOUA in listLocalContactOUA)
                {
                    if (!(responseContactVersionList.Data.Exists(delegate(WS.ContactVersion o) { return o.ContactID == cntLocalOUA.ID; })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByContactID(cntLocalOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;
                        cntLocalOUA.Visible = false;
                        success = UpdateContact(cntLocalOUA);
                        if (!success)
                            return false;
                    }
                }
                if (listCntChanged.Count > 0)
                {
                    msgCntChanged.Data = listCntChanged.ToArray();
                    WS.ResponseMessageOfContactListWM9H3p7p responseChangedContact = service.GetSetupData_ChangedContact(userName, pass, msgCntChanged);

                    if (responseChangedContact.IsSuccessful)
                    {
                        foreach (WS.Contact contact in responseChangedContact.Data)
                        {
                            success = UpdateContact(contact);
                            if (!success)
                                return false;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(responseChangedContact.ErrorMessage))
                            throw new Exception(responseChangedContact.ErrorMessage);
                    }
                }
                #endregion

                #region Remove un-link of data relation
                foreach (Organization_Contact ocLocal in listLocalOrgCntOUA)
                {
                    if (!(responseContactVersionList.Data.Exists(delegate(WS.ContactVersion orgCnt) { return ocLocal.OrganizationID == orgCnt.OrganizationID && ocLocal.ContactID == orgCnt.ContactID; })))
                    {
                        RemoveContactFromOrganization(ocLocal.OrganizationID, ocLocal.ContactID);
                    }                    
                }

                foreach (Project_Activity paLocal in listLocalProjActOUA)
                {
                    if (!(responseDataRelation.Data.Exists(delegate(WS.OrganizationVersion ov) { return paLocal.ProjectID == ov.ProjID && paLocal.ActivityID == ov.ActID; })))
                    {
                        RemoveActivityFromProject(paLocal.ProjectID, paLocal.ActivityID);
                    }
                }

                foreach (Organization_Project opLocal in listLocalOrgPrjOUA)
                {
                    if (!(responseDataRelation.Data.Exists(delegate(WS.OrganizationVersion ov) { return opLocal.OrganizationID == ov.OrgID && opLocal.ProjectID == ov.ProjID; })))
                    {
                        RemoveProjectFromOrganization(opLocal.OrganizationID, opLocal.ProjectID);
                    }
                }
                #endregion

                #region Update Location

                WS.ResponseMessageOfLocationListGCtaaEQZ responseGetLocations = service.GetLocationsForCheckData(userName, pass);
                success = responseGetLocations.IsSuccessful;
                if (success)
                {
                    var listLcOUA = TSRFacade.GetAllLocations();
                    foreach (var lcOUA in listLcOUA)
                    {
                        if (!(responseGetLocations.Data.Exists(delegate(WS.Location lc) { return lc.ID == lcOUA.ID; })))
                        {
                            PreferredPathsList paths = GetPreferredPathsListByLocationID(lcOUA.ID);
                            if (paths != null)
                                success = DeletePreferredPathsList(paths);
                            if (!success)
                                return false;
                        }
                    }

                    foreach (WS.Location lc in responseGetLocations.Data)
                    {
                        //updates location
                        success = UpdateLocation(lc);
                        if (!success)
                            return false;
                    }
                }

                #endregion
            }
            else
            {
                if (!string.IsNullOrEmpty(responseDataRelation.ErrorMessage))
                    throw new Exception(responseDataRelation.ErrorMessage);
            }
            #endregion

            return success;
        }

        /// <summary>
        /// Get all Organization_Project from dataset
        /// </summary>
        /// <returns></returns>
        private static Organization_ProjectList GetAllOrganization_Project()
        {
            using (DAL.Organization_ProjectDAL dal = new DAL.Organization_ProjectDAL())
            {
                return dal.GetAllOrganization_Project();
            }
        }
        /// <summary>
        /// Get all Project_Activity from dataset
        /// </summary>
        /// <returns></returns>
        private static Project_ActivityList GetAllProject_Activity()
        {
            using (DAL.Project_ActivityDAL dal = new DAL.Project_ActivityDAL())
            {
                return dal.GetAllProject_activity();
            }
        }
        /// <summary>
        /// Get all Organization_Contact from dataset
        /// </summary>
        /// <returns></returns>
        private static Organization_ContactList GetAllOrganization_Contact()
        {
            using (DAL.Organization_ContactDAL dal = new DAL.Organization_ContactDAL())
            {
                return dal.GetAllOrganization_Contact();
            }
        }
        /// <summary>
        /// Check invalid setup data and updates local storage with this data
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        internal static bool CheckInValidSetupData()
        {
            bool success = false;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            // Check contact data
            WS.ResponseMessageOfContactListWM9H3p7p responseContact = service.GetContactsForCheckData(userName, pass);
            success = responseContact.IsSuccessful;
            if (success)
            {
                ContactList listCntOUA = GetAllContacts(), listCntOUAVis = GetAllContacts(false);
                if (listCntOUAVis != null && listCntOUAVis.Count > 0)
                    listCntOUA.AddRange(listCntOUAVis);

                foreach (Contact cntOUA in listCntOUA)
                {
                    if (!(responseContact.Data.Exists(delegate(WS.Contact cnt) { return (cnt.ID == cntOUA.ID); })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByContactID(cntOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        success = RemoveContactFromAllOrganizations(cntOUA.ID);
                        if (!success)
                            return false;

                        cntOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        success = UpdateContact(cntOUA);
                        if (!success)
                            return false;
                    }
                    else
                    {
                        WS.Contact cnt = responseContact.Data.Find(delegate(WS.Contact contact) { return contact.ID == cntOUA.ID; });
                        if (cnt != null)
                            success = UpdateContact(cnt);
                        if (!success)
                            return false;
                    }
                }

            }
            else
            {
                if (!string.IsNullOrEmpty(responseContact.ErrorMessage))
                    throw new Exception(responseContact.ErrorMessage);
            }
            // Check Activity Data
            WS.ResponseMessageOfActivityListWM9H3p7p responseActivity = service.GetAcitiviesForCheckData(userName, pass);
            success = responseActivity.IsSuccessful;
            if (success)
            {
                ActivityList listActOUA = GetAllActivities(), listActOUAVis = GetAllActivities(false);
                if (listActOUAVis != null && listActOUAVis.Count > 0)
                    listActOUA.AddRange(listActOUAVis);
                foreach (Activity actOUA in listActOUA)
                {
                    if (!(responseActivity.Data.Exists(delegate(WS.Activity act) { return (act.ID == actOUA.ID); })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByActivityID(actOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        success = RemoveActivityFromAllProjects(actOUA.ID);
                        if (!success)
                            return false;

                        actOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        success = UpdateActivity(actOUA);
                        if (!success)
                            return false;
                    }
                    else
                    {
                        WS.Activity act = responseActivity.Data.Find(delegate(WS.Activity activity) { return activity.ID == actOUA.ID; });
                        if (act != null)
                            success = UpdateActivity(act);
                        if (!success)
                            return false;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(responseActivity.ErrorMessage))
                    throw new Exception(responseActivity.ErrorMessage);
            }
            // Check Project Data
            WS.ResponseMessageOfProjectListWM9H3p7p responseProject = service.GetProjectsForCheckData(userName, pass);
            success = responseProject.IsSuccessful;
            if (success)
            {
                ProjectList listPrjOUA = GetAllProjects(), listPrjOUAVis = GetAllProjects(false);
                if (listPrjOUAVis != null && listPrjOUAVis.Count > 0)
                    listPrjOUA.AddRange(listPrjOUAVis);
                foreach (Project prjOUA in listPrjOUA)
                {
                    if (!(responseProject.Data.Exists(delegate(WS.Project prj) { return (prj.ID == prjOUA.ID); })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByProjectID(prjOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        success = RemoveAllActivitiesFromProject(prjOUA.ID);
                        if (!success)
                            return false;

                        success = RemoveProjectFromOrganization(prjOUA.ID);
                        if (!success)
                            return false;

                        prjOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        success = UpdateProject(prjOUA);
                        if (!success)
                            return false;
                    }
                    else
                    {
                        WS.Project prj = responseProject.Data.Find(delegate(WS.Project project) { return project.ID == prjOUA.ID; });
                        if (prj != null)
                            success = UpdateProject(prj);
                        if (!success)
                            return false;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(responseProject.ErrorMessage))
                    throw new Exception(responseProject.ErrorMessage);
            }
            // Check Organization Data
            WS.ResponseMessageOfOrganizationListWM9H3p7p responseOrganization = service.GetOrganizationsForCheckData(userName, pass);
            success = responseOrganization.IsSuccessful;
            if (success)
            {
                //Add by tsrdev1
                OrganizationList listOrgOUA = TSRFacade.GetAllOrganizations(), listOrgOUAVis = GetAllOrganizations(false);
                if (listOrgOUAVis != null && listOrgOUAVis.Count > 0)
                    listOrgOUA.AddRange(listOrgOUAVis);
                foreach (Organization orgOUA in listOrgOUA)
                {
                    if (!(responseOrganization.Data.Exists(delegate(WS.Organization org) { return (org.ID == orgOUA.ID); })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByOrganizationID(orgOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        ProjectList listPrjOUA = GetProjectsForOrganization(orgOUA.ID);

                        if (listPrjOUA != null)
                        {
                            foreach (Project prj in listPrjOUA)
                            {
                                success = RemoveProjectFromOrganization(orgOUA.ID, prj.ID);
                                if (!success)
                                    return false;

                                prj.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateProject(prj);
                                if (!success)
                                    return false;

                            }
                        }
                        ContactList listContactOUA = GetContactsByOrganizationID(orgOUA.ID);
                        if (listContactOUA != null)
                            foreach (Contact cnt in listContactOUA)
                            {
                                success = RemoveContactFromOrganization(orgOUA.ID, cnt.ID);
                                if (!success)
                                    return false;

                                cnt.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateContact(cnt);
                                if (!success)
                                    return false;
                            }

                        //update local storage with organization
                        orgOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        success = UpdateOrganization(orgOUA);

                        if (!success)
                            return false;
                    }
                    else
                    {
                        WS.Organization org = responseOrganization.Data.Find(delegate(WS.Organization organization) { return organization.ID == orgOUA.ID; });
                        if (org != null)
                            success = UpdateOrganization(org);
                        if (!success)
                            return false;
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(responseOrganization.ErrorMessage))
                    throw new Exception(responseOrganization.ErrorMessage);
            }

            // Check location data
            WS.ResponseMessageOfLocationListGCtaaEQZ responseLocation = service.GetLocationsForCheckData(userName, pass);
            success = responseLocation.IsSuccessful;
            if (success)
            {
                LocationList listLocationOUA = GetAllLocations(), listLocationOUAVis = GetAllLocations(false);
                if (listLocationOUAVis != null && listLocationOUAVis.Count > 0)
                    listLocationOUA.AddRange(listLocationOUAVis);

                foreach (Location lcOUA in listLocationOUA)
                {
                    if (!(responseLocation.Data.Exists(delegate(WS.Location lc) { return (lc.ID == lcOUA.ID); })))
                    {
                        PreferredPathsList paths = GetPreferredPathsListByContactID(lcOUA.ID);
                        if (paths != null)
                            success = DeletePreferredPathsList(paths);
                        if (!success)
                            return false;

                        success = RemoveContactFromAllOrganizations(lcOUA.ID);
                        if (!success)
                            return false;

                        lcOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        success = UpdateLocation(lcOUA);
                        if (!success)
                            return false;
                    }
                    else
                    {
                        WS.Location cnt = responseLocation.Data.Find(delegate(WS.Location location) { return location.ID == lcOUA.ID; });
                        if (cnt != null)
                            success = UpdateLocation(cnt);
                        if (!success)
                            return false;
                    }
                }

            }
            else
            {
                if (!string.IsNullOrEmpty(responseContact.ErrorMessage))
                    throw new Exception(responseContact.ErrorMessage);
            }

            return success;
        }

        private static WS.TimeEntryList ConvertTimeEntriesToWSStandard(Entity.TimeEntryList list)
        {
            WS.TimeEntryList newList = new WS.TimeEntryList();
            foreach (Entity.TimeEntry te in list)
            {
                WS.TimeEntry obj = ConvertTimeEntryToWSStandard(te);
                if (obj != null)
                    newList.Add(obj);
            }

            return newList;
        }

        //Added by tsrdev1
        //Added datetime 20/10/2010

        private static WS.TimeEntry ConvertTimeEntryToWSStandard(Entity.TimeEntry te)
        {
            WS.TimeEntry obj = new WS.TimeEntry();
            //Commented by mashrur.. due to a problem which is caused when a time entry is submitted
            //te.Status = WS.StatusEnum.Submitted;

            obj.ID = te.ID;
            if (!(string.IsNullOrEmpty(te.Subject)))
                obj.Subject = te.Subject;
            else
                obj.Subject = string.Empty;
            if (!(string.IsNullOrEmpty(te.Body)))
                obj.Body = te.Body;
            else
                obj.Body = string.Empty;
            if (!(string.IsNullOrEmpty(te.Location)))
                obj.Location = te.Location;
            else
                obj.Location = string.Empty;
            obj.StartTimeStamp = te.StartTimeStamp;
            obj.EndTimeStamp = te.EndTimeStamp;
            obj.OrganizationID = te.OrganizationID;
            obj.ProjectID = te.ProjectID;
            obj.ActivityID = te.ActivityID;
            
            if (te.ContactID.HasValue)
                obj.ContactID = te.ContactID;
            if (te.TaskID.HasValue)
                obj.TaskID = te.TaskID;
            obj.Status = te.Status;

            obj.LocationID = te.LocationID;
            obj.IsOutOfOffice = te.IsOutOfOffice;
            obj.IsCreatedViaWeb = te.IsCreatedViaWeb;

            obj.Notes = te.Notes;
            //Added by tsrdev1
            //obj.SubmittedBy = te.SubmittedBy;
            if (te.Revision.HasValue)
                obj.Revision = te.Revision.Value;
            if (!string.IsNullOrEmpty(te.SubmitterName))
                obj.SubmitterName = te.SubmitterName;

            obj.IsRecurring = te.IsRecurring;
            //End                

            if (!string.IsNullOrEmpty(te.Message))
            {
                obj.Message = te.Message;
            }
            //obj will be deleted on server if is false
            obj.IsDeletedOnServer = te.IsDeleted;

            return obj;
        }

        private static void ConvertWSTimeEntriesToLocalStandard(WS.TimeEntry[] list, Entity.TimeEntryList oldList)
        {
            foreach (Entity.TimeEntry entityTe in oldList)
            {
                foreach (WS.TimeEntry wsTe in list)
                {
                    if (wsTe.ID == entityTe.ID)
                    {
                        entityTe.Status = wsTe.Status;
                        break;
                    }
                }
            }
        }

        //added by tsrdev2
        /// <summary>
        /// Convert WS time entry to time entry on local
        /// </summary>
        /// <param name="teWS"></param>
        /// <param name="teLocal"></param>
        public static void ConvertWSTimeEntryToLocalTimeEntry(WS.TimeEntry teWS, Entity.TimeEntry teLocal)
        {
            if (teWS.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                || teWS.Status == TSR.Core.UserAgentService.StatusEnum.Rejected)
            {
                teLocal.Message = teWS.Message;
                //teLocal.SubmitterName = string.Empty;
            }
            else
                teLocal.Message = string.Empty;
            teLocal.ID = teWS.ID;
            if (!(string.IsNullOrEmpty(teWS.Subject)))
                teLocal.Subject = teWS.Subject;
            if (!(string.IsNullOrEmpty(teWS.Body)))
                teLocal.Body = teWS.Body;
            else
                teLocal.Body = string.Empty;
            if (!(string.IsNullOrEmpty(teWS.Location)))
                teLocal.Location = teWS.Location;
            else
                teLocal.Location = string.Empty;
            teLocal.StartTimeStamp = teWS.StartTimeStamp;
            teLocal.EndTimeStamp = teWS.EndTimeStamp;
            teLocal.OrganizationID = teWS.OrganizationID;
            teLocal.ProjectID = teWS.ProjectID;
            teLocal.ActivityID = teWS.ActivityID;

            teLocal.TaskID = teWS.TaskID;
            teLocal.ContactID = teWS.ContactID;

            teLocal.Status = teWS.Status;
            //Added by tsrdev1            
            teLocal.Revision = teWS.Revision;
            teLocal.SubmitterName = teWS.SubmitterName;
            //added by tsrdev2
            teLocal.IsDeletedOnServer = teWS.IsDeletedOnServer;

            //Added by tsrdev1
            teLocal.IsRecurring = teWS.IsRecurring;
            teLocal.IsOutOfOffice = teWS.IsOutOfOffice;
            teLocal.LocationID = teWS.LocationID;
            teLocal.IsCreatedViaWeb = teWS.IsCreatedViaWeb;

            //teLocal.ProjectName = teWS.ProjectName;
            //teLocal.ActivityName = teWS.ActivityName;
            //teLocal.OrganizationName = teWS.OrganizationName;
        }

        //Added by tsrdev1
        //Added datetime 15/10/2010
        /// <summary>
        /// Convert TimeEntry_OutlookAppointment on Server to same object on Local
        /// </summary>
        /// <param name="te_appWS"></param>
        /// <returns></returns>
        public static Entity.TimeEntry_OutlookAppointment ConvertWSTE_APPToLocalTE_APP(WS.TimeEntry_OutlookAppointment te_appWS)
        {
            Entity.TimeEntry_OutlookAppointment te_appLocal = new TimeEntry_OutlookAppointment();
            te_appLocal.OutlookItemID = te_appWS.OutlookItemID;
            te_appLocal.TimeEntryID = te_appWS.TimeEntryID;
            te_appLocal.Revision = te_appWS.Revision;
            te_appLocal.CalendarID = te_appWS.CalendarID;
            return te_appLocal;
        }

        /// <summary>
        /// Convert TimeEntry_OutlookAppointment on Local to same object on Server
        /// </summary>
        /// <param name="te_appLocal"></param>
        /// <returns></returns>
        public static WS.TimeEntry_OutlookAppointment ConvertLocalTE_APPToWSTE_APP(Entity.TimeEntry_OutlookAppointment te_appLocal)
        {
            WS.TimeEntry_OutlookAppointment te_appWS = new WS.TimeEntry_OutlookAppointment();
            te_appWS.OutlookItemID = te_appLocal.OutlookItemID;
            te_appWS.TimeEntryID = te_appLocal.TimeEntryID;
            te_appWS.Revision = te_appLocal.Revision;
            te_appWS.CalendarID = te_appLocal.CalendarID;
            return te_appWS;
        }

        /// <summary>
        /// Submits time entries during synchronization
        /// </summary>
        /// <param name="list">list of time entries needs to be submitted</param>
        /// <param name="error"></param>
        /// <returns></returns>
        //internal static bool SubmitTimeEntries(Entity.TimeEntryList list)
        //{
        //    //Entity.TimeEntryList list = GetTimeEntriesByStatus(Convert.ToInt32(WS.StatusEnum.InSubmissionQueue));
        //    TimeEntryList teListToBeSubmitted = new TimeEntryList();
        //    Entity.TimeEntryList returnedList = new Entity.TimeEntryList();
        //    WS.RequestMessageOfTimeEntryListWM9H3p7p req = new WS.RequestMessageOfTimeEntryListWM9H3p7p();
        //    foreach (Entity.TimeEntry te in list)
        //    {
        //        //if (string.IsNullOrEmpty(te.OutlookItemID))
        //        //    continue;
        //        //if (!OutlookHelper.TimeEntryIsInSelectedFolderForSynchronization(te.OutlookItemID))
        //        //    continue;

        //        if (!String.IsNullOrEmpty(te.Message))
        //        {
        //            //Note note = new Note();
        //            WS.Note note = new TSR.Core.UserAgentService.Note();

        //            //te.Notes[0] = new WS.Note();
        //            note.RowState = WS.BaseBusinessEntity.RowStateEnum.NewRow;
        //            note.Subject = String.Empty;
        //            note.Note = te.Message;
        //            note.Timestamp = te.LastModificationTime;
        //            if (te.Notes == null)
        //                te.Notes = new TSR.Core.UserAgentService.NoteList();
        //            te.Notes.Add(note);
        //        }
        //        teListToBeSubmitted.Add(te);
        //    }

        //    req.Data = ConvertTimeEntriesToWSStandard(teListToBeSubmitted);
        //    WS.ResponseMessageOfboolean response;

        //    //Get user name and password
        //    WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
        //    WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
        //    userName.Data = GetNONADUserName();
        //    pass.Data = GetNONADPassword();


        //    using (WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode()))
        //    {
        //        response = service.SubmitTimeEntries(userName,pass,req);
        //    }

        //    if (!response.IsSuccessful)
        //    {
        //        if (!string.IsNullOrEmpty(response.ErrorMessage))
        //            throw new Exception(response.ErrorMessage);
        //    }

        //    return response.IsSuccessful;
        //}

        /// <summary>
        /// Submits time entries during synchronization with detail error messages
        /// </summary>
        /// <param name="list">list of time entries needs to be submitted</param>
        /// <param name="error"></param>
        /// <returns></returns>
        internal static Dictionary<Guid, string> SubmitTimeEntriesWithErrorMessage(Entity.TimeEntryList list, out bool success)
        {
            //Entity.TimeEntryList list = GetTimeEntriesByStatus(Convert.ToInt32(WS.StatusEnum.InSubmissionQueue));
            TimeEntryList teListToBeSubmitted = new TimeEntryList();
            Entity.TimeEntryList returnedList = new Entity.TimeEntryList();
            WS.RequestMessageOfTimeEntryListWM9H3p7p req = new WS.RequestMessageOfTimeEntryListWM9H3p7p();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj response = new TSR.Core.UserAgentService.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj();
            success = false;
            foreach (Entity.TimeEntry te in list)
            {
                if (!te.IsChangeAllowed() && !String.IsNullOrEmpty(te.Message))
                {
                    WS.Note note = new TSR.Core.UserAgentService.Note();
                    note.RowState = WS.BaseBusinessEntity.RowStateEnum.NewRow;
                    note.Subject = String.Empty;
                    note.Note = te.Message;
                    note.Timestamp = te.LastModificationTime;
                    if (te.Notes == null)
                        te.Notes = new TSR.Core.UserAgentService.NoteList();
                    te.Notes.Add(note);
                }
                teListToBeSubmitted.Add(te);
            }

            req.Data = ConvertTimeEntriesToWSStandard(teListToBeSubmitted);
            using (WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode()))
            {
                response = service.SubmitTimeEntriesWithErrorMessage(userName, pass, req);
                success = response.IsSuccessful;
            }

            if (!response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return response.Data;
        }

        /// <summary>
        /// within a time range, gets the list of time entries from server and updates the local storage with
        /// changed information in server. For example, status of time entry or any notes/messages sent by apporvers
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>

        internal static Entity.TimeEntryList ProcessTimeEntryResponse(DateTime start, DateTime end, bool retrieveCompleted, IMemoryBox memBox)
        {
            WS.RequestMessageOfdateTime startReq = new WS.RequestMessageOfdateTime();
            startReq.Data = start;
            WS.RequestMessageOfdateTime endReq = new WS.RequestMessageOfdateTime();
            endReq.Data = end;
            WS.RequestMessageOfboolean retrCompleted = new WS.RequestMessageOfboolean();
            retrCompleted.Data = retrieveCompleted;

            WS.RequestMessageOfArrayOfguiduHEDJ7Dj reqApprovedTimeEntryIDs = new WS.RequestMessageOfArrayOfguiduHEDJ7Dj();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            List<Guid> lsTimeEntryIDs = new List<Guid>();

            if (!retrieveCompleted)
            {
                TimeEntryList teApprovedList = GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.Approved), string.Empty, false);
                foreach (TimeEntry item in teApprovedList)
                {
                    lsTimeEntryIDs.Add(item.ID);
                }
            }

            reqApprovedTimeEntryIDs.Data = lsTimeEntryIDs.ToArray();

            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfTimeEntryListWM9H3p7p response = service.GetTimeEntryResponse(userName, pass, startReq, endReq, retrCompleted, reqApprovedTimeEntryIDs);

            Entity.TimeEntryList list = new Entity.TimeEntryList();
            Entity.TimeEntryList listTest = new Entity.TimeEntryList();
            if (response.IsSuccessful)
            {
                MemoryBoxResult result = MemoryBoxResult.No;
                DataSet ds = DAL.BaseDAL.MyDataSet;
                DataTable dtTimeEntry = ds.Tables["TimeEntry"];

                //listTest = 
                foreach (WS.TimeEntry te in response.Data)
                {
                    Entity.TimeEntry obj = GetTimeEntryByTSRItemID(te.ID, true, false);
                    if (obj != null && (obj.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission))
                    {
                        continue;
                    }
                    if (obj == null)
                    {
                        if (result == MemoryBoxResult.NoToAll)
                            continue;

                        if (result == MemoryBoxResult.No || result == MemoryBoxResult.Yes)
                        {
                            string TimeEntryRecreationQuestion = ResourceManager.GetResourceString("TimeEntryRecreationQuestion", "A time entry was deleted, which can be recreated from synchronized data. Do you want to create this?");
                            string strReturn = string.Empty;

                            string TSRSynchronization = ResourceManager.GetResourceString("ProductName", "TSR") + " " + ResourceManager.GetResourceString("Synchronization", "Synchronization");
                            foreach (DataRow row in dtTimeEntry.Rows)
                            {
                                if (!(string.IsNullOrEmpty(te.Subject)))
                                    if (te.Subject.ToString() != row["Subject"].ToString())
                                    {
                                        strReturn = row["Subject"].ToString();
                                    }
                            }
                            result = memBox.ShowMemoryDialog(TimeEntryRecreationQuestion + " [" + strReturn + "]", TSRSynchronization);
                            // result = memBox.ShowMemoryDialog(TimeEntryRecreationQuestion , TSRSynchronization);
                        }
                        //Got time entry from server, but it does not exist locally!
                        //TO DO: User should know this! get the decision from user whether to recreate it or not..
                        //DialogResult dg = MessageBox.Show("A TSR entry was deleted, which can be recreated from synchronized data. Do you want to create this? [" + te.Subject + "]", "TSR Synchronization", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        //if (dg == DialogResult.No)
                        //    continue;
                        if (result == MemoryBoxResult.No)
                            continue;

                        obj = new Entity.TimeEntry(te.ID, Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID);
                    }
                    else
                    {
                        if (obj.IsDeleted) //if it was deleted locally, do not get it back
                            continue;
                        if (!OutlookHelper.TimeEntryIsInSelectedFolderForSynchronization(obj.OutlookItemID))
                        {
                            //if time entry was not in sync appointment, 
                            obj.SetAppointmentIDForNonExistingAppointment();
                        }
                    }

                    if (!String.IsNullOrEmpty(obj.Message))
                    {
                        obj.Message = string.Empty;
                    }
                    obj.ID = te.ID;
                    if (!(string.IsNullOrEmpty(te.Subject)))
                        obj.Subject = te.Subject;
                    else
                        obj.Subject = string.Empty;
                    if (!(string.IsNullOrEmpty(te.Body)))
                        obj.Body = te.Body;
                    else
                        obj.Body = string.Empty;
                    if (!(string.IsNullOrEmpty(te.Location)))
                        obj.Location = te.Location;
                    else
                        obj.Location = string.Empty;
                    obj.StartTimeStamp = te.StartTimeStamp;
                    obj.EndTimeStamp = te.EndTimeStamp;
                    obj.OrganizationID = te.OrganizationID;
                    obj.ProjectID = te.ProjectID;
                    obj.ActivityID = te.ActivityID;
                    if (te.TaskID.HasValue)
                        obj.TaskID = te.TaskID.Value;
                    if (te.ContactID.HasValue)
                        obj.ContactID = te.ContactID.Value;

                    //Added by tsrdev1
                    if (te.Revision.HasValue)
                        obj.Revision = te.Revision.Value;
                    if (!string.IsNullOrEmpty(te.SubmitterName))
                        obj.SubmitterName = te.SubmitterName;
                    //End
                    obj.Status = te.Status;
                    list.Add(obj);

                    UpdateTimeEntry(obj);


                    if (te.Notes != null)
                    {
                        foreach (WS.Note note in te.Notes)
                        {
                            UpdateNote(note, te.ID);
                        }
                    }

                }

            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return list;
        }
        /// <summary>
        /// Add by tsrdev1
        /// within a time range, gets the list of time entries from server and updates the local storage with
        /// changed information in server. For example, status of time entry or any notes/messages sent by apporvers
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>

        internal static Entity.TimeEntryList ProcessTimeEntryResponse1(DateTime start, DateTime end, bool retrieveCompleted, bool retrieveTECreatedViaWeb, IMemoryBox memBox, out Entity.TimeEntryList createdNewTEList, out List<Guid> listNeverRecreatedTimeEntryIDs)
        {
            //string log = "TSRFacade.ProcessTimeEntryResponse1: " + MiscHelper.GetCurrentDateTimeToString();
            createdNewTEList = new TimeEntryList();

            listNeverRecreatedTimeEntryIDs = new List<Guid>();

            WS.RequestMessageOfdateTime startReq = new WS.RequestMessageOfdateTime();
            startReq.Data = start;
            WS.RequestMessageOfdateTime endReq = new WS.RequestMessageOfdateTime();
            endReq.Data = end;
            WS.RequestMessageOfboolean retrCompleted = new WS.RequestMessageOfboolean();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            TimeEntryList listSyncedTimeEntry = new TimeEntryList();

            retrCompleted.Data = retrieveCompleted;

            WS.RequestMessageOfArrayOfguiduHEDJ7Dj reqApprovedTimeEntryIDs = new WS.RequestMessageOfArrayOfguiduHEDJ7Dj();

            List<Guid> lsTimeEntryIDs = new List<Guid>();

            if (!retrieveCompleted)
            {
                TimeEntryList teApprovedList = GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.Approved), string.Empty, false);
                foreach (TimeEntry item in teApprovedList)
                {
                    lsTimeEntryIDs.Add(item.ID);
                }
            }
            reqApprovedTimeEntryIDs.Data = lsTimeEntryIDs.ToArray();

            //log += ";service.GetTimeEntryResponse: " + MiscHelper.GetCurrentDateTimeToString();

            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfTimeEntryListWM9H3p7p response = service.GetTimeEntryResponse(userName, pass, startReq, endReq, retrCompleted, reqApprovedTimeEntryIDs);

            //log += "-->" + MiscHelper.GetCurrentDateTimeToString();

            Entity.TimeEntryList list = new Entity.TimeEntryList();
            if (response.IsSuccessful)
            {
                //MemoryBoxResult result = MemoryBoxResult.No;
                DataSet ds = DAL.BaseDAL.MyDataSet;

                //log += ";ProcessReceatedTime: " + MiscHelper.GetCurrentDateTimeToString();

                //added by pdhuy
                #region Gets list timeentries will be recreated
                TimeEntryList timeEntryList = new TimeEntryList();

                if (response.Data == null)
                    return list;

                foreach (WS.TimeEntry te in response.Data)
                {
                    if (!te.IsDeletedOnServer)
                    {
                        Entity.TimeEntry obj = GetTimeEntryByTSRItemID(te.ID, false, true);
                        if (obj != null && obj.IsDeleted) // time entry tren server co, duoi local ko co
                        {
                            obj = new TimeEntry(te.ID);
                            //fill the data from server time to local time
                            ConvertWSTimeEntryToLocalTimeEntry(te, obj);
                            TSRFacade.FillChilds(obj);
                            timeEntryList.Add(obj);
                        }
                    }
                }

                TSR.Core.ListTimeEntryQuestions listQuestions = new ListTimeEntryQuestions();
                if (_chekListTimeEntry != null && timeEntryList.Count > 0)
                {
                    listQuestions = _chekListTimeEntry.ShowCheckListTimeEntry(timeEntryList);
                }
                //end of pdhuy
                #endregion

                //log += "-->" + MiscHelper.GetCurrentDateTimeToString();
                //log += ";ProcessTimeOnLocal: " + MiscHelper.GetCurrentDateTimeToString();

                //string strLog = "TSRFacade.ProcessTimeEntryResponse1.ProcessOnLocal(count=" + response.Data.Count.ToString() + "): " + MiscHelper.GetCurrentDateTimeToString();
                foreach (WS.TimeEntry te in response.Data)
                {
                    bool isNewTE = false;
                    bool isSyncedTE = false;
                    //edited by tsrdev2
                    //feature 31
                    //gets all time entry (include deleted time entry)                    
                    Entity.TimeEntry obj = GetTimeEntryByTSRItemID(te.ID, false, true);

                    #region Time entry has been deleted on server
                    if (te.IsDeletedOnServer)
                    {
                        if (obj == null)
                            continue;
                        if (obj != null && obj.IsDeleted)
                        {
                            if (!obj.IsDeletedOnServer.HasValue || (obj.IsDeletedOnServer.HasValue && !obj.IsDeletedOnServer.Value))
                            {
                                obj.IsDeletedOnServer = te.IsDeletedOnServer;
                                UpdateTimeEntry(obj);
                            }
                            continue;
                        }
                    }
                    if (te.IsDeletedOnServer && obj != null && !obj.IsDeleted)
                    {
                        //if (Core.TimeEntryHelper.IsDifferentTimeEntries(te, obj))
                        //{
                        //    //fill the data from server time to local time
                        //    ConvertWSTimeEntryToLocalTimeEntry(te, obj);                            
                        //}
                        obj.IsDeletedOnServer = te.IsDeletedOnServer;
                        //update value of DeletedOnServer = true
                        UpdateTimeEntry(obj);
                        //update value of Deleted = true;
                        DeleteTimeEntry(obj);

                        obj.IsDeleted = true;

                        //Fill Childs
                        FillChilds(obj);
                        list.Add(obj);
                        continue;
                    }
                    #endregion


                    if (obj == null) //this time entry not exist on local
                    {
                        if(retrieveTECreatedViaWeb)
                        {
                            obj = new Entity.TimeEntry(te.ID, Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID);
                            isSyncedTE = true;
                            isNewTE = true;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (obj.IsDeleted)
                        {
                            #region recreating removed time entry
                            TimeEntryQuestions timeEntryQuestions = listQuestions.FindByID(te.ID);
                            if (timeEntryQuestions == null)
                            {
                                continue;
                            }
                            else
                            {
                                if (timeEntryQuestions.QuestionsStatus == TimeEntryQuestionsStatus.Yes)
                                {
                                    obj = new Entity.TimeEntry(te.ID, Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID);
                                    isSyncedTE = true;
                                }
                                else if (timeEntryQuestions.QuestionsStatus == TimeEntryQuestionsStatus.No)
                                {
                                    listNeverRecreatedTimeEntryIDs.Add(te.ID);
                                    continue;
                                }
                                else
                                {
                                    continue;
                                }
                            }
                            //end
                            #endregion
                        }

                        //strLog += ";CheckSelectedFolder: " + MiscHelper.GetCurrentDateTimeToString();

                        //if ((string.IsNullOrEmpty(obj.OutlookItemID)) 
                        //      ||((!string.IsNullOrEmpty(obj.OutlookItemID)) 
                        //            && (!OutlookHelper.TimeEntryIsInSelectedFolderForSynchronization(obj.OutlookItemID)))
                        //    )
                        //{
                        //    //if time entry was not in sync appointment, 
                        //    obj.SetAppointmentIDForNonExistingAppointment();
                        //}

                        //strLog += "-->" + MiscHelper.GetCurrentDateTimeToString();

                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = obj.OLAppointmentItem;
                        }
                        catch //(Exception exp)
                        {
                            //Core.Logging.LoggingHandler.LogError(exp);
                        }

                        if (appItem == null)
                            obj.SetAppointmentIDForNonExistingAppointment();

                        int startDiffFromNow = TSR.Core.SettingsHelper.TSRMiscPastIndex * -1;
                        int endDiffFromNow = TSR.Core.SettingsHelper.TSRMiscFutureIndex;
                        DateTime startDate = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRMiscPastPeriod);
                        DateTime endDate = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRMiscFuturePeriod);
                        if (
                              (appItem == null)
                              && (TSR.Core.SettingsHelper.TSRMiscSyncRemovedData)
                              && ((te.StartTimeStamp >= startDate) && (te.EndTimeStamp <= endDate))
                           )
                        {
                            isSyncedTE = true;
                            obj.IsCreatedAppointment = true;
                        }

                        if ((appItem != null)
                              && TSR.Core.OutlookHelper.IsChangedAppointment(appItem, te))
                        {
                            obj.IsChangedAppointment = true;
                            isSyncedTE = true;
                        }
                        if (!isSyncedTE)
                        {
                            if (Core.TimeEntryHelper.IsDifferentTimeEntries(te, obj))
                            {
                                isSyncedTE = true;
                            }
                        }
                    }
                    //fill the data from server time to local time
                    ConvertWSTimeEntryToLocalTimeEntry(te, obj);

                    UpdateTimeEntry(obj);

                    if (te.Notes != null)
                    {
                        foreach (WS.Note note in te.Notes)
                        {
                            UpdateNote(note, te.ID);
                        }
                    }
                    if (isSyncedTE)
                    {
                        TSRFacade.FillChilds(obj);
                        list.Add(obj);
                        if (isNewTE)
                            createdNewTEList.Add(obj);
                    }
                }
                //strLog += ";END: " + MiscHelper.GetCurrentDateTimeToString();
                //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = strLog });

            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            //log += ";END ProcessTimeOnLocal: " + MiscHelper.GetCurrentDateTimeToString();
            //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = log });

            return list;
        }

        //Added by tsrdev1
        //Added datetime 13/10/2010
        /// <summary>
        /// Retrieve time entries from TSR Server on Exchange environment
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="retrieveCompleted"></param>
        /// <param name="memBox"></param>
        /// <param name="createdNewTEList"></param>
        /// <returns></returns>
        internal static Entity.TimeEntryList ProcessTimeEntryResponseForEX(DateTime start, DateTime end, bool retrieveCompleted, bool retrieveTECreatedViaWeb, IMemoryBox memBox, out Entity.TimeEntryList createdNewTEList, out List<Guid> listNeverRecreatedTimeEntryIDs, out TimeEntry_OutlookAppointmentList listUpdatedLinks)
        {
            //string log = "TSRFacade.ProcessTimeEntryResponse(Exchange): " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;

            createdNewTEList = new TimeEntryList();
            listNeverRecreatedTimeEntryIDs = new List<Guid>();
            listUpdatedLinks = new TimeEntry_OutlookAppointmentList();

            WS.RequestMessageOfdateTime startReq = new WS.RequestMessageOfdateTime();
            startReq.Data = start;
            WS.RequestMessageOfdateTime endReq = new WS.RequestMessageOfdateTime();
            endReq.Data = end;
            WS.RequestMessageOfboolean retrCompleted = new WS.RequestMessageOfboolean();

            WS.RequestMessageOfstring reCalendarID = new WS.RequestMessageOfstring();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            TimeEntryList listSyncedTimeEntry = new TimeEntryList();

            retrCompleted.Data = retrieveCompleted;

            WS.RequestMessageOfArrayOfguiduHEDJ7Dj reqApprovedTimeEntryIDs = new WS.RequestMessageOfArrayOfguiduHEDJ7Dj();

            List<Guid> lsTimeEntryIDs = new List<Guid>();

            if (!retrieveCompleted)
            {
                TimeEntryList teApprovedList = GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, Convert.ToInt32(WS.StatusEnum.Approved), string.Empty, false);
                foreach (TimeEntry item in teApprovedList)
                {
                    lsTimeEntryIDs.Add(item.ID);
                }
            }
            reqApprovedTimeEntryIDs.Data = lsTimeEntryIDs.ToArray();

            //log += ";service.GetTimeEntryResponse: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;

            reCalendarID.Data = OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID;

            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfArrayOfKeyValueOfTimeEntryTimeEntry_OutlookAppointmentcTeK0n31uHEDJ7Dj response = service.GetTimeEntryResponseForEX(userName, pass, startReq, endReq, retrCompleted, reqApprovedTimeEntryIDs, reCalendarID);

            //log += "-->" + MiscHelper.GetCurrentDateTimeToString();

            Entity.TimeEntryList list = new Entity.TimeEntryList();

            if (response.Data == null)
                return list;

            System.Collections.IDictionaryEnumerator iDic = response.Data.GetEnumerator();

            if (response.IsSuccessful)
            {
                //MemoryBoxResult result = MemoryBoxResult.No;
                DataSet ds = DAL.BaseDAL.MyDataSet;
                //--------------------------------------------------
                TimeEntryList timeEntryList = new TimeEntryList();

                //log += ";GetListRecreatedTE: " + MiscHelper.GetCurrentDateTimeToString();
                while (iDic.MoveNext())
                {
                    WS.TimeEntry te = iDic.Key as WS.TimeEntry;
                    if (!te.IsDeletedOnServer)
                    {
                        Entity.TimeEntry obj = GetTimeEntryByTSRItemID(te.ID, false, true);

                        if (obj != null && obj.IsDeleted) // time entry tren server co, duoi local ko co
                        {
                            WS.TimeEntry_OutlookAppointment te_app = (iDic.Value == null) ? null : iDic.Value as WS.TimeEntry_OutlookAppointment;

                            Microsoft.Office.Interop.Outlook.AppointmentItem appItemServer = null;
                            bool isBlankAppointmentOnServer = false;
                            if (te_app != null)
                            {
                                if (!string.IsNullOrEmpty(te_app.OutlookItemID) && (te_app.OutlookItemID == Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID))
                                    isBlankAppointmentOnServer = true;
                                try
                                {
                                    appItemServer = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryIDAndDatetime(te_app.OutlookItemID, te.StartTimeStamp);
                                }
                                catch //(Exception exp)
                                {
                                    //Core.Logging.LoggingHandler.LogError(exp);
                                }
                            }
                            if ((appItemServer == null && (te_app == null || (isBlankAppointmentOnServer) ||
                                        (te_app != null && (!string.IsNullOrEmpty(obj.OutlookItemID) &&
                                        (obj.OutlookItemID == te_app.OutlookItemID))))) || (appItemServer != null))
                            {
                                obj = new TimeEntry(te.ID);
                                //fill the data from server time to local time
                                ConvertWSTimeEntryToLocalTimeEntry(te, obj);
                                TSRFacade.FillChilds(obj);
                                timeEntryList.Add(obj);
                            }
                        }
                    }
                }

                //log += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;

                TSR.Core.ListTimeEntryQuestions listQuestions = new ListTimeEntryQuestions();
                if (_chekListTimeEntry != null && timeEntryList.Count > 0)
                {
                    listQuestions = _chekListTimeEntry.ShowCheckListTimeEntry(timeEntryList);
                }
                iDic = response.Data.GetEnumerator();
                //--------------------------------------------------
                //foreach (WS.TimeEntry te in response.Data)

                //log += ";ProcessTimeEntriesOnLocal: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;

                //string strlog = "TSRFacade.ProcessTimeEntryResponse(Exchange).ProcessOnLocal(count=" + response.Data.Count.ToString() + "): " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
                while (iDic.MoveNext())
                {
                    //strlog += ";begin:" + MiscHelper.GetCurrentDateTimeToString();
                    bool isNewTE = false;

                    WS.TimeEntry te = iDic.Key as WS.TimeEntry;
                    WS.TimeEntry_OutlookAppointment te_app = (iDic.Value == null) ? null : iDic.Value as WS.TimeEntry_OutlookAppointment;


                    Microsoft.Office.Interop.Outlook.AppointmentItem appItemServer = null;
                    bool isBlankAppointmentOnServer = false;
                    if (te_app != null)
                    {
                        if (!string.IsNullOrEmpty(te_app.OutlookItemID) && (te_app.OutlookItemID == Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID))
                            isBlankAppointmentOnServer = true;
                        try
                        {
                            //strlog += ";getAppCurrForder: " + MiscHelper.GetCurrentDateTimeToString();
                            appItemServer = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryIDAndDatetime(te_app.OutlookItemID, te.StartTimeStamp);
                            //strlog += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
                        }
                        catch //(Exception exp)
                        {
                            //Core.Logging.LoggingHandler.LogError(exp);
                        }
                    }
                    bool isSyncedTE = false;

                    //edited by tsrdev2
                    //feature 31
                    //gets all time entry (include deleted time entry)                    
                    Entity.TimeEntry obj = GetTimeEntryByTSRItemID(te.ID, false, true);
                    if (te.IsDeletedOnServer)
                    {
                        if (obj == null)
                        {
                            //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                            continue;
                        }
                        if (obj != null && obj.IsDeleted)
                        {
                            if (!obj.IsDeletedOnServer.HasValue || (obj.IsDeletedOnServer.HasValue && !obj.IsDeletedOnServer.Value))
                            {
                                obj.IsDeletedOnServer = te.IsDeletedOnServer;
                                UpdateTimeEntry(obj);
                            }
                            //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                            continue;
                        }
                    }
                    if (te.IsDeletedOnServer && obj != null && !obj.IsDeleted)
                    {
                        //if (Core.TimeEntryHelper.IsDifferentTimeEntries(te, obj))
                        //{
                        //    //fill the data from server time to local time
                        //    ConvertWSTimeEntryToLocalTimeEntry(te, obj);                            
                        //}
                        obj.IsDeletedOnServer = te.IsDeletedOnServer;
                        //update value of DeletedOnServer = true
                        UpdateTimeEntry(obj);
                        //update value of Deleted = true;
                        DeleteTimeEntry(obj);

                        obj.IsDeleted = true;

                        //Fill Childs
                        FillChilds(obj);
                        list.Add(obj);
                        //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                        continue;
                    }

                    if (obj == null) //this time entry not exist on local
                    {
                        if (isBlankAppointmentOnServer || appItemServer != null || te_app == null)
                        {
                            obj = new Entity.TimeEntry(te.ID, Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID);
                            isNewTE = true;
                            isSyncedTE = true;

                            if (appItemServer != null)
                            {
                                obj.OLAppointmentItem = appItemServer;
                                obj.SetOutlookItem(te_app.OutlookItemID);

                                if (TSR.Core.OutlookHelper.IsChangedAppointment(appItemServer, te))
                                    obj.IsChangedAppointment = true;
                            }
                        }
                        else
                        {
                            //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                            continue;
                        }
                    }
                    else
                    {
                        if (obj.IsDeleted)
                        {
                            TimeEntryQuestions timeEntryQuestions = listQuestions.FindByID(te.ID);
                            if (timeEntryQuestions == null)
                            {
                                //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                                continue;
                            }
                            else
                            {
                                if (timeEntryQuestions.QuestionsStatus == TimeEntryQuestionsStatus.Yes)
                                {
                                    string tmpCalendarID = obj.CalendarID;
                                    string tmpOutlookItemID = obj.OutlookItemID;

                                    obj = new Entity.TimeEntry(te.ID, tmpOutlookItemID, tmpCalendarID);
                                    isSyncedTE = true;
                                }
                                else if (timeEntryQuestions.QuestionsStatus == TimeEntryQuestionsStatus.No)
                                {
                                    listNeverRecreatedTimeEntryIDs.Add(te.ID);
                                    //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                                    continue;
                                }
                                else
                                {
                                    //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                                    continue;
                                }
                            }
                        }
                        if (appItemServer != null)
                        {
                            obj.OLAppointmentItem = appItemServer;
                            obj.SetOutlookItem(te_app.OutlookItemID);
                        }

                        Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                        try
                        {
                            appItem = obj.OLAppointmentItem;
                        }
                        catch //(Exception exp)
                        {
                            //Core.Logging.LoggingHandler.LogError(exp);
                        }
                        //if ((string.IsNullOrEmpty(obj.OutlookItemID))
                        //      || ((!string.IsNullOrEmpty(obj.OutlookItemID))
                        //            && (appItem == null))
                        //    )
                        //{
                        //    //if time entry was not in sync appointment, 
                        //    obj.SetAppointmentIDForNonExistingAppointment();                            
                        //}                        

                        int startDiffFromNow = TSR.Core.SettingsHelper.TSRMiscPastIndex * -1;
                        int endDiffFromNow = TSR.Core.SettingsHelper.TSRMiscFutureIndex;
                        DateTime startDate = GetStartEndTime(DateTime.Now, startDiffFromNow, TSR.Core.SettingsHelper.TSRMiscPastPeriod);
                        DateTime endDate = GetStartEndTime(DateTime.Now, endDiffFromNow, TSR.Core.SettingsHelper.TSRMiscFuturePeriod);
                        if (appItem == null && (te_app == null || (isBlankAppointmentOnServer) ||
                           (te_app != null && (!string.IsNullOrEmpty(obj.OutlookItemID) &&
                           (obj.OutlookItemID == te_app.OutlookItemID)))))
                        {
                            if ((TSR.Core.SettingsHelper.TSRMiscSyncRemovedData)
                                    && ((te.StartTimeStamp >= startDate) && (te.EndTimeStamp <= endDate)))
                            {
                                isSyncedTE = true;
                                if (te_app != null)
                                    obj.IsCreatedAppointment = true;
                                else if (retrieveTECreatedViaWeb)
                                    obj.IsCreatedAppointment = true;
                            }
                            else
                            {
                                obj.SetAppointmentIDForNonExistingAppointment();
                                if (!isBlankAppointmentOnServer && te_app != null)
                                {
                                    TimeEntry_OutlookAppointment temp = new TimeEntry_OutlookAppointment();
                                    temp.OutlookItemID = Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID;
                                    temp.CalendarID = te_app.CalendarID;
                                    temp.TimeEntryID = te_app.TimeEntryID;
                                    temp.Revision = te_app.Revision;
                                    listUpdatedLinks.Add(temp);
                                }

                            }
                        }

                        if ((appItem != null)
                              && TSR.Core.OutlookHelper.IsChangedAppointment(appItem, te))
                        {
                            obj.IsChangedAppointment = true;
                            isSyncedTE = true;
                        }

                        if (!isSyncedTE)
                        {
                            if (Core.TimeEntryHelper.IsDifferentTimeEntries(te, obj))
                            {
                                isSyncedTE = true;
                            }
                        }

                    }

                    //fill the data from server time to local time
                    ConvertWSTimeEntryToLocalTimeEntry(te, obj);

                    if ((appItemServer != null) || (isBlankAppointmentOnServer))
                    {
                        Entity.TimeEntry_OutlookAppointment objTe_app = ConvertWSTE_APPToLocalTE_APP(te_app);
                        //log += "Update time entry and link " + MiscHelper.GetCurrentDateTimeToString();
                        UpdateTimeEntry(obj, objTe_app);
                        //log += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
                    }
                    else
                    {
                        //log += "Update time entry " + MiscHelper.GetCurrentDateTimeToString();
                        UpdateTimeEntry(obj);
                        //log += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
                    }
                    ////update linke between time entry and appointment
                    //if (te_app != null)
                    //{
                    //    if (appItemServer != null)
                    //    {
                    //        Entity.TimeEntry_OutlookAppointment objTe_app = ConvertWSTE_APPToLocalTE_APP(te_app);
                    //        UpdateTimeEntry_OutlookAppointment(objTe_app);
                    //    }
                    //}

                    if (te.Notes != null)
                    {
                        foreach (WS.Note note in te.Notes)
                        {
                            UpdateNote(note, te.ID);
                        }
                    }
                    if (isSyncedTE)
                    {
                        //strlog += "Fill Child: " + MiscHelper.GetCurrentDateTimeToString()  + Environment.NewLine;
                        TSRFacade.FillChilds(obj);
                        //log += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
                        list.Add(obj);
                        if (isNewTE && retrieveTECreatedViaWeb)
                            createdNewTEList.Add(obj);
                    }
                    //strlog += ";end:" + MiscHelper.GetCurrentDateTimeToString();
                }
                //strlog += ";END: " + MiscHelper.GetCurrentDateTimeToString();
                //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = strlog });

                //log += "-->" + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;

            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            //log += ";END: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = log});
            return list;
        }

        /// <summary>
        /// Submits time entries during synchronization on Exchange environment
        /// </summary>
        /// <param name="list">list of time entries needs to be submitted</param>        
        /// <param name="needOverwriteTimeEntries"></param>
        /// <param name="noOverwrite"></param>
        /// <param name="success"></param>
        /// <returns></returns>
        internal static Dictionary<Guid, string> SubmitTimeEntriesForEX(Entity.TimeEntryList list, out Entity.TimeEntryList needOverwriteTimeEntries, out List<Guid> noOverwrite, out bool success)
        {
            //string log = "TSRFacade.SubmitTimeEntriesForEX(Exchange): " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            //Entity.TimeEntryList list = GetTimeEntriesByStatus(Convert.ToInt32(WS.StatusEnum.InSubmissionQueue));
            Dictionary<WS.TimeEntry, WS.TimeEntry_OutlookAppointment> teAndte_appListToBeSubmitted = new Dictionary<WS.TimeEntry, WS.TimeEntry_OutlookAppointment>();
            WS.RequestMessageOfArrayOfKeyValueOfTimeEntryTimeEntry_OutlookAppointmentcTeK0n31uHEDJ7Dj req = new WS.RequestMessageOfArrayOfKeyValueOfTimeEntryTimeEntry_OutlookAppointmentcTeK0n31uHEDJ7Dj();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj response = new TSR.Core.UserAgentService.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj();
            WS.ResponseMessageOfArrayOfguiduHEDJ7Dj responseListNoChange = new WS.ResponseMessageOfArrayOfguiduHEDJ7Dj();
            WS.ResponseMessageOfArrayOfKeyValueOfguidguiduHEDJ7Dj responseListOverwrite = new WS.ResponseMessageOfArrayOfKeyValueOfguidguiduHEDJ7Dj();

            success = false;
            Dictionary<Guid, Guid> listOverwriteTE = new Dictionary<Guid, Guid>();
            List<Guid> listNoChange = new List<Guid>();

            Dictionary<Guid, string> listResult = new Dictionary<Guid, string>();

            needOverwriteTimeEntries = new TimeEntryList();
            noOverwrite = new List<Guid>();
            //log += "Start get time entry for submit: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            foreach (Entity.TimeEntry te in list)
            {
                if (!te.IsChangeAllowed() && !String.IsNullOrEmpty(te.Message))
                {
                    WS.Note note = new TSR.Core.UserAgentService.Note();
                    note.RowState = WS.BaseBusinessEntity.RowStateEnum.NewRow;
                    note.Subject = String.Empty;
                    note.Note = te.Message;
                    note.Timestamp = te.LastModificationTime;
                    if (te.Notes == null)
                        te.Notes = new TSR.Core.UserAgentService.NoteList();
                    te.Notes.Add(note);
                }

                WS.TimeEntry teWS = ConvertTimeEntryToWSStandard(te);

                if (teWS != null)
                {
                    Entity.TimeEntry_OutlookAppointment te_app = GetTimeEntry_OutlookAppointmentByTimeEntryID(te.ID);
                    if (te.GetStatusLinkWithAppointment() != StatusLinkWithAppointment.Normal)
                    {
                        if (te_app != null && te_app.Revision == 0)
                            RemoveTimeEntry_OutlookAppointment(te_app);

                        te_app = null;
                    }
                    WS.TimeEntry_OutlookAppointment te_appWS = null;
                    if (te_app != null)
                    {
                        if (string.IsNullOrEmpty(te_app.CalendarID))
                        {
                            try
                            {
                                te_app.CalendarID = OutlookHelper.GetCalendarFolderIDByAppointmentItem(te.OLAppointmentItem);

                                Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(te_app);
                            }
                            catch (Exception ex)
                            {
                                TSR.Core.Logging.LoggingHandler.LogError(ex);
                            }
                        }

                        te_appWS = ConvertLocalTE_APPToWSTE_APP(te_app);
                    }
                    teAndte_appListToBeSubmitted.Add(teWS, te_appWS);
                }
            }

            req.Data = teAndte_appListToBeSubmitted;
            //log += "End get time entry for submit: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            //log += "Start submit: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            using (WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode()))
            {
                response = service.SubmitTimeEntriesForEX(out responseListOverwrite, out responseListNoChange, userName, pass, req);
                success = response.IsSuccessful;
            }
            //log += "End submit: " + MiscHelper.GetCurrentDateTimeToString() + Environment.NewLine;
            if (response.Data != null && response.Data.Count > 0)
            {
                foreach (KeyValuePair<Guid, string> pair in response.Data)
                    listResult.Add(pair.Key, pair.Value);

            }
            listOverwriteTE = responseListOverwrite.Data;
            if (responseListNoChange.Data != null)
                listNoChange = responseListNoChange.Data.ToList<Guid>();

            if (listOverwriteTE != null && listOverwriteTE.Count > 0)
            {
                if (_overwriteTimeEntries != null)
                {
                    System.Collections.IDictionaryEnumerator idic = listOverwriteTE.GetEnumerator();
                    TimeEntryList getTimeEntryList = new TimeEntryList();
                    while (idic.MoveNext())
                    {
                        TimeEntry temp = GetTimeEntryByTSRItemID((Guid)idic.Value);
                        if (temp != null)
                            getTimeEntryList.Add(temp);
                    }
                    if (getTimeEntryList != null && getTimeEntryList.Count > 0)
                    {
                        if (_overwriteTimeEntries != null)
                        {
                            needOverwriteTimeEntries = _overwriteTimeEntries.ShowOverwriteTimeEntries(getTimeEntryList);

                            if (needOverwriteTimeEntries != null && needOverwriteTimeEntries.Count > 0)
                            {
                                //Update new key to time entry before overwrite to TSR Server
                                foreach (TimeEntry obj in needOverwriteTimeEntries)
                                {
                                    KeyValuePair<Guid, Guid> pairID = listOverwriteTE.First(delegate(KeyValuePair<Guid, Guid> pair) { return pair.Value == obj.ID; });
                                    if (!pairID.Equals(null))
                                    {
                                        OverwriteTimeEntry(pairID.Key, pairID.Value);
                                        obj.ID = pairID.Key;

                                        list.RemoveAll(delegate(TimeEntry te) { return te.ID == pairID.Value; });
                                    }
                                }
                            }

                            //Get time entries that no overwrite
                            TimeEntryList temp = needOverwriteTimeEntries;
                            TimeEntryList noNeedOverwriteList = new TimeEntryList(getTimeEntryList.FindAll(delegate(TimeEntry te) { return !temp.Contains(te); }));
                            //Remove no overwrite time entry from local
                            foreach (TimeEntry te in noNeedOverwriteList)
                            {
                                string message = Core.ResourceManager.GetResourceString("DuplicateAppointmentAndNoOverwritten", "The time entry linked to an appointment which linked by another time entry can change but be not overwritten");
                                listResult.Add(te.ID, message);

                                noOverwrite.Add(te.ID);
                            }
                        }
                    }

                }
            }
            if (listNoChange != null && listNoChange.Count > 0)
            {
                foreach (Guid teID in listNoChange)
                {
                    string message = Core.ResourceManager.GetResourceString("DuplicateAppointmentAndCannotChange", "The time entry was linked to an appointment which linked by another time entry cannot change");
                    listResult.Add(teID, message);

                    noOverwrite.Add(teID);
                }
            }
            if (!response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            //log += "---->" + MiscHelper.GetCurrentDateTimeToString();
            //Logging.LoggingHandler.LogInfo(new Logging.Log() { MessageDetail = log});
            return listResult;
        }

        //Added by tsrdev1
        //Added datetime 22/10/2010
        /// <summary>
        /// Overwrite time entries to server
        /// </summary>
        /// <param name="list"></param>
        /// <param name="success"></param>
        /// <returns></returns>
        internal static Dictionary<Guid, string> OverwriteTimeEntriesToServer(Entity.TimeEntryList list, out bool success)
        {
            //Entity.TimeEntryList list = GetTimeEntriesByStatus(Convert.ToInt32(WS.StatusEnum.InSubmissionQueue));            
            WS.RequestMessageOfTimeEntryListWM9H3p7p req = new WS.RequestMessageOfTimeEntryListWM9H3p7p();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj response = new TSR.Core.UserAgentService.ResponseMessageOfArrayOfKeyValueOfguidstringuHEDJ7Dj();
            success = false;

            req.Data = ConvertTimeEntriesToWSStandard(list);
            using (WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode()))
            {
                response = service.OverwriteTimeEntriesForEX(userName, pass, req);
                success = response.IsSuccessful;
            }

            if (!response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return response.Data;
        }
        /// <summary>
        /// Update newest links between time entry and appointment to TSR Server
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        internal static bool UpdateTimeEntry_OutlookAppointmentLinksToServer(Entity.TimeEntry_OutlookAppointmentList list)
        {
            WS.RequestMessageOfTimeEntry_OutlookAppointmentListWM9H3p7p reListLinks = new WS.RequestMessageOfTimeEntry_OutlookAppointmentListWM9H3p7p();

            WS.TimeEntry_OutlookAppointmentList listRequest = new WS.TimeEntry_OutlookAppointmentList();

            foreach (TimeEntry_OutlookAppointment obj in list)
            {
                listRequest.Add(ConvertLocalTE_APPToWSTE_APP(obj));
            }
            reListLinks.Data = listRequest;
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.ResponseMessageOfArrayOfguiduHEDJ7Dj response = service.SaveTimeEntry_OutlookAppointmentLinks(userName, pass, reListLinks);
            if (response.IsSuccessful && response.Data.Count() > 0)
            {
                for (int i = 0; i < response.Data.Count(); i++)
                {
                    TimeEntry_OutlookAppointment te_app = list.First(delegate(TimeEntry_OutlookAppointment pr) { return pr.TimeEntryID == response.Data[i]; });
                    if (te_app != null)
                    {
                        te_app.Revision += 1;
                        UpdateTimeEntry_OutlookAppointment(te_app);
                    }
                }
            }
            return response.IsSuccessful;
        }

        /// <summary>
        /// Update newest links between time entry and appointment to TSR Server
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public static bool UpdateTimeEntry_OutlookAppointmentLinkToServer(Entity.TimeEntry_OutlookAppointment link)
        {
            WS.RequestMessageOfTimeEntry_OutlookAppointmentWM9H3p7p req = new WS.RequestMessageOfTimeEntry_OutlookAppointmentWM9H3p7p();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            req.Data = ConvertLocalTE_APPToWSTE_APP(link);
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfboolean response = service.SaveTimeEntry_OutlookAppointmentLink(userName, pass, req);
            return response.Data;
        }
        //End

        //Added by tsrdev1
        //Added datetime 14/10/2010        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        internal static bool SubmitRecurringMasters(List<RecurringMaster> list)
        {
            return false;
        }
        internal static bool ProcessRecurringMasters(DateTime start, DateTime end, bool retrieveCompleted, IMemoryBox memBox)
        {
            return false;
        }
        //End

        //Added by tsrdev1
        //Added datetime 18/10/2010
        public static Entity.TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentLinkFromServer(Guid teID)
        {
            WS.RequestMessageOfguid timeEntryID = new WS.RequestMessageOfguid();
            timeEntryID.Data = teID;


            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfTimeEntry_OutlookAppointmentWM9H3p7p response = service.GetTimeEntry_OutlookAppointmentLinkByTimeEntryID(userName, pass, timeEntryID);
            if (response.IsSuccessful)
            {
                if (response.Data == null)
                    return null;
                else
                    return ConvertWSTE_APPToLocalTE_APP(response.Data);
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            return null;
        }

        public static Entity.TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentLinkFromServer(string outlookItemID)
        {
            WS.RequestMessageOfstring request = new WS.RequestMessageOfstring();
            request.Data = outlookItemID;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfTimeEntry_OutlookAppointmentWM9H3p7p response = service.GetTimeEntry_OutlookAppointmentLinkByOutlookItemID(userName, pass, request);
            if (response.IsSuccessful)
            {
                if (response.Data == null)
                    return null;
                else
                    return ConvertWSTE_APPToLocalTE_APP(response.Data);
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            return null;
        }

        public static Entity.TimeEntry_OutlookAppointmentList GetAllTimeEntry_OutlookAppointmentLinksFromServer()
        {
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            WS.ResponseMessageOfTimeEntry_OutlookAppointmentListWM9H3p7p response = service.GetAllTimeEntry_OutlookAppointmentLinks(userName, pass);
            if (response.IsSuccessful)
            {
                if (response.Data == null)
                    return null;
                else
                {
                    Entity.TimeEntry_OutlookAppointmentList listResult = new TimeEntry_OutlookAppointmentList();
                    foreach (WS.TimeEntry_OutlookAppointment obj in response.Data)
                    {
                        listResult.Add(ConvertWSTE_APPToLocalTE_APP(obj));
                    }
                    return listResult;
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            return null;
        }

        //Added by tsrdev1
        //Added datetime 19/11/2010
        /// <summary>
        /// Delete time entries that be never recreated on OUA client
        /// </summary>
        /// <param name="listTimeEntryIDs"></param>
        /// <returns></returns>
        internal static bool DeleteTimeEntriesOnServer(List<Guid> listTimeEntryIDs)
        {
            if (listTimeEntryIDs == null || (listTimeEntryIDs != null && listTimeEntryIDs.Count == 0))
                return false;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfArrayOfguiduHEDJ7Dj req = new WS.RequestMessageOfArrayOfguiduHEDJ7Dj();
            req.Data = listTimeEntryIDs.ToArray();
            WS.ResponseMessageOfboolean response = service.DeleteTimeEntries(userName, pass, req);
            if (response.IsSuccessful)
            {
                return response.Data;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            return false;
        }

        private static DateTime GetStartEndTime(DateTime currentTime, int difference, string periodType)
        {
            int val;
            if (int.TryParse(periodType, out val))
            {
                TSR.Core.SettingsHelper.AllTimePeriodTypes type = (TSR.Core.SettingsHelper.AllTimePeriodTypes)val;
                switch (type)
                {
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Hour:
                        currentTime = currentTime.AddHours(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Day:
                        currentTime = currentTime.AddDays(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Week:
                        currentTime = currentTime.AddDays(difference * 7);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Month:
                        currentTime = currentTime.AddMonths(difference);
                        break;
                    case TSR.Core.SettingsHelper.AllTimePeriodTypes.Year:
                        currentTime = currentTime.AddYears(difference);
                        break;

                }
            }

            return currentTime;
        }

        /// <summary>
        /// Retrieves preferred paths/ favorites settings from server through WCF service
        /// </summary>
        /// <returns></returns>
        internal static bool GetUserAgentDataFromServer()
        {
            bool success = false;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfstring response = service.GetUserSpecficData(userName, pass);
            WS.RequestMessageOfstring reqMachine = GetMachineID();
            //WS.ResponseMessageOfstring responseMachineSpecific = (!GetExchangeMode()) ? service.GetMachineSpecficAppointmentData(userName,pass,reqMachine) 
            //                                                        : service.GetMachineSpecficAppointmentDataForEX(userName,pass);

            WS.ResponseMessageOfstring responseMachineSpecific = new WS.ResponseMessageOfstring();
            TSRDataSet tsrUserSpecificData_Temp = null;

            if (GetExchangeMode())
            {
                #region For Exchange Mode
                responseMachineSpecific = service.GetMachineSpecficAppointmentDataForEX(userName, pass);
                if (string.IsNullOrEmpty(responseMachineSpecific.Data))
                {
                    responseMachineSpecific = service.GetMachineSpecficAppointmentData(userName, pass, reqMachine);
                }
                else
                {
                    WS.ResponseMessageOfstring responseMachineSpecific_Temp = service.GetMachineSpecficAppointmentData(userName, pass, reqMachine);

                    if (!string.IsNullOrEmpty(responseMachineSpecific_Temp.Data)
                        && string.Compare(responseMachineSpecific.Data, responseMachineSpecific_Temp.Data, true) != 0)
                    {
                        tsrUserSpecificData_Temp = new TSRDataSet();
                        //get machine specific appointment settings into dataset
                        TSRDataSet dsMachineSpecific_Temp = new TSRDataSet();

                        using (System.IO.StringReader machinerdr_Temp = new System.IO.StringReader(responseMachineSpecific_Temp.Data))
                        {
                            try
                            {
                                dsMachineSpecific_Temp.ReadXml(machinerdr_Temp);
                            }
                            catch (System.Xml.XmlException ex)
                            {
                                string strMessga = ResourceManager.GetResourceString("MachineSpecficUserAgentDataFromServerIsNotInRightFormat", "Machine specfic UserAgentData from server is not in right format");
                                TSR.Core.Logging.LoggingHandler.LogError(ex);
                                TSR.Core.Logging.LoggingHandler.LogError(new Exception(strMessga));
                                return false;
                            }
                        }

                        //populate machine specific appointment data into main dataset
                        if (dsMachineSpecific_Temp.Tables["TimeEntry_OutlookAppointment"] != null)
                        {
                            foreach (DataRow item in dsMachineSpecific_Temp.Tables["TimeEntry_OutlookAppointment"].Rows)
                            {
                                tsrUserSpecificData_Temp.Tables["TimeEntry_OutlookAppointment"].ImportRow(item);
                            }
                        }

                        if (dsMachineSpecific_Temp.Tables["RecurringMaster"] != null)
                        {
                            foreach (DataRow item in dsMachineSpecific_Temp.Tables["RecurringMaster"].Rows)
                            {
                                tsrUserSpecificData_Temp.Tables["RecurringMaster"].ImportRow(item);
                            }
                        }
                    }
                }
                #endregion
            }
            else
            {
                responseMachineSpecific = service.GetMachineSpecficAppointmentData(userName, pass, reqMachine);
            }

            DataTable settingsTable = new DataTable();
            DataTable userSettingsTable = new DataTable();
            if (response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.Data))
                {
                    TSRDataSet tsrUserSpecificData = new TSRDataSet();
                    System.IO.StringReader rdr = new System.IO.StringReader(response.Data);
                    try
                    {
                        tsrUserSpecificData.ReadXml(rdr);
                    }
                    catch (System.Xml.XmlException ex)
                    {
                        string strMessga = ResourceManager.GetResourceString("UserspecficUserAgentDataFromServerIsNotInRightFormat", "User specfic UserAgentData from server is not in right format");
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                        TSR.Core.Logging.LoggingHandler.LogError(new Exception(strMessga));
                        return false;
                    }

                    TSRDataSet dsMachineSpecific = null;
                    if (!string.IsNullOrEmpty(responseMachineSpecific.Data))
                    {
                        //get machine specific appointment settings into dataset
                        dsMachineSpecific = new TSRDataSet();
                        System.IO.StringReader machinerdr = new System.IO.StringReader(responseMachineSpecific.Data);
                        try
                        {
                            dsMachineSpecific.ReadXml(machinerdr);
                        }
                        catch (System.Xml.XmlException ex)
                        {
                            string strMessga = ResourceManager.GetResourceString("MachineSpecficUserAgentDataFromServerIsNotInRightFormat", "Machine specfic UserAgentData from server is not in right format");
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                            TSR.Core.Logging.LoggingHandler.LogError(new Exception(strMessga));
                            return false;
                        }

                        #region TimeEntry_OutlookAppointment table
                        //populate machine specific appointment data into main dataset
                        if (dsMachineSpecific.Tables["TimeEntry_OutlookAppointment"] != null)
                        {
                            List<string> lstTEIDExisted = new List<string>();
                            foreach (DataRow item in dsMachineSpecific.Tables["TimeEntry_OutlookAppointment"].Rows)
                            {
                                tsrUserSpecificData.Tables["TimeEntry_OutlookAppointment"].ImportRow(item);
                                lstTEIDExisted.Add(item["TimeEntryID"].ToString());
                            }

                            if (tsrUserSpecificData_Temp != null)
                            {
                                foreach (DataRow row in tsrUserSpecificData_Temp.Tables["TimeEntry_OutlookAppointment"].Rows)
                                {
                                    if (lstTEIDExisted.FindIndex(s => s == row["TimeEntryID"].ToString()) < 0)
                                    {
                                        tsrUserSpecificData.Tables["TimeEntry_OutlookAppointment"].ImportRow(row);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region RecurringMaster table
                        if (dsMachineSpecific.Tables["RecurringMaster"] != null)
                        {
                            List<string> lstRECUIDExisted = new List<string>();

                            foreach (DataRow item in dsMachineSpecific.Tables["RecurringMaster"].Rows)
                            {
                                tsrUserSpecificData.Tables["RecurringMaster"].ImportRow(item);
                                lstRECUIDExisted.Add(item["ID"].ToString());
                            }

                            if (tsrUserSpecificData_Temp != null)
                            {
                                foreach (DataRow row in tsrUserSpecificData_Temp.Tables["RecurringMaster"].Rows)
                                {
                                    if (lstRECUIDExisted.FindIndex(s => s == row["ID"].ToString()) < 0)
                                    {
                                        tsrUserSpecificData.Tables["RecurringMaster"].ImportRow(row);
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    //settings table has some rows, so populate it with existing data, not by server data
                    //if user already has some settings data, save it, because this should not be replaced from server
                    if (DAL.BaseDAL.MyDataSet.Settings.Rows.Count > 0)
                        settingsTable = DAL.BaseDAL.MyDataSet.Settings;
                    if (DAL.BaseDAL.MyDataSet.UserSettings.Rows.Count > 0)
                        userSettingsTable = DAL.BaseDAL.MyDataSet.UserSettings;
                    try
                    {
                        #region Settings table
                        if (settingsTable.Rows.Count > 0)
                        {
                            foreach (DataRow item in settingsTable.Rows)
                            {
                                tsrUserSpecificData.Tables["Settings"].ImportRow(item);
                            }
                        }
                        else
                        {
                            TSRDataSet dsMachineSpecificSettings = GetTSRDataSetWithSettingsDataFromServer();

                            //populate machine specific settings data into main dataset
                            if (dsMachineSpecificSettings.Tables["Settings"] != null)
                            {
                                foreach (DataRow item in dsMachineSpecificSettings.Tables["Settings"].Rows)
                                {
                                    if (dsMachineSpecificSettings.Tables["Settings"].Rows.Count == 0)
                                    {
                                        tsrUserSpecificData.Tables["Settings"].ImportRow(item);
                                    }
                                }
                            }
                        }
                        #endregion

                        #region UserSettings table
                        if (userSettingsTable != null && userSettingsTable.Rows.Count > 0)
                        {
                            DataTable userSettingsFromServer = tsrUserSpecificData.Tables["UserSettings"].Copy();

                            tsrUserSpecificData.Tables["UserSettings"].Rows.Clear();

                            foreach (DataRow row in userSettingsTable.Rows)
                            {
                                //if (row["Key"].ToString() == Constants.CONST_CUSTOMERNO_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_EXCHANGEMODE_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_PASSWORD_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_SERVERADDRESS_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_TSRISCHOOSESSL_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_USERNAME_KEY ||
                                //    row["Key"].ToString() == Constants.CONST_WEBINTERFACE_KEY ||
                                //    row["Key"].ToString() == SettingsHelper._TSRDontShowAgain ||
                                //    row["Key"].ToString() == SettingsHelper.TSRDO_NOT_RETRIEVE_SETTING_SERVER ||
                                //    row["Key"].ToString() == "UpdateCategories" ||
                                //    row["Key"].ToString().ToUpper().StartsWith("PROXY"))
                                //{
                                //    tsrUserSpecificData.Tables["UserSettings"].LoadDataRow(new object[3] { row[0], row[1], row[2] }, LoadOption.OverwriteChanges);
                                //}

                                tsrUserSpecificData.Tables["UserSettings"].LoadDataRow(new object[3] { row[0], row[1], row[2] }, LoadOption.OverwriteChanges);
                            }

                            //get proxy informations from user agent data
                            foreach (DataRow row in userSettingsFromServer.Rows)
                            {
                                var rs = from r in tsrUserSpecificData.Tables["UserSettings"].AsEnumerable()
                                         where r.Field<string>("Key") == row["Key"].ToString()
                                         select r;
                                if (rs != null && rs.Count() > 0)
                                {
                                    if (row["Key"].ToString() == SettingsHelper.PROXY_CONNECTION_TIMEOUT
                                        || row["Key"].ToString().ToUpper().StartsWith("PROXY"))
                                    {
                                        DataRow proxyRow = (DataRow)rs.First();
                                        if (proxyRow != null)
                                        {
                                            //tsrUserSpecificData.Tables["UserSettings"].LoadDataRow(new object[3] { proxyRow[0], proxyRow[1], row[2] }, LoadOption.OverwriteChanges);
                                            proxyRow[2] = row[2].ToString();
                                        }
                                    }
                                }
                                else
                                {
                                    try
                                    {
                                        DataRow newRow = tsrUserSpecificData.Tables["UserSettings"].NewRow();
                                        newRow[1] = row[1].ToString();
                                        newRow[2] = row[2].ToString();

                                        tsrUserSpecificData.Tables["UserSettings"].Rows.Add(newRow);
                                    }
                                    catch (Exception ex)
                                    {
                                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                                    }
                                }
                            }
                        }
                        //foreach (DataRow item in userSettingsTable.Rows)
                        //{
                        //    if (!(item["Key"].ToString() == Constants.CONST_CUSTOMERNO_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_EXCHANGEMODE_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_PASSWORD_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_SERVERADDRESS_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_TSRISCHOOSESSL_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_USERNAME_KEY ||
                        //    item["Key"].ToString() == Constants.CONST_WEBINTERFACE_KEY ||
                        //    item["Key"].ToString() == SettingsHelper._TSRDontShowAgain ||
                        //    item["Key"].ToString() == SettingsHelper.TSRDO_NOT_RETRIEVE_SETTING_SERVER ||
                        //    item["Key"].ToString() == "UpdateCategories"))// ||
                        //        //item["Key"].ToString().ToUpper().StartsWith("PROXY")))
                        //        tsrUserSpecificData.Tables["UserSettings"].LoadDataRow(new object[3] { item[0], item[1], item[2] }, LoadOption.OverwriteChanges);
                        //}

                        #endregion
                    }
                    catch (Exception ex)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                    }

                    DAL.BaseDAL.MyDataSet = tsrUserSpecificData;

                    //Core.DAL.DSClass.ForceXMLSave();                    
                }
                success = true;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new Exception(response.ErrorMessage));
                    throw new Exception(response.ErrorMessage);
                }
            }

            return success;
        }

        internal static bool RestoreSetupDataFromServer()
        {
            bool success = false;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.ResponseMessageOfstring response = service.GetUserSpecficData(userName, pass);

            if (response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.Data))
                {
                    TSRDataSet tsrUserSpecificData = new TSRDataSet();
                    System.IO.StringReader rdr = new System.IO.StringReader(response.Data);
                    try
                    {
                        tsrUserSpecificData.ReadXml(rdr);
                    }
                    catch (System.Xml.XmlException ex)
                    {
                        string strMessga = ResourceManager.GetResourceString("UserspecficUserAgentDatafromserverisnotinrightformat", "User specfic UserAgentData from server is not in right format");
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                        TSR.Core.Logging.LoggingHandler.LogError(new Exception(strMessga));
                        return false;
                    }

                    if (tsrUserSpecificData.Organization != null)
                    {
                        List<long> listOrgID = new List<long>();

                        foreach (DataRow item in tsrUserSpecificData.Organization.Rows)
                        {
                            long orgID = -1;
                            if (long.TryParse(item[0].ToString(), out orgID))
                                listOrgID.Add(orgID);

                            //add or update the Organization on server to dataset
                            //column index of the item taken from Dataset
                            object[] objItem = new object[item.ItemArray.Length];
                            for (int i = 0; i < item.ItemArray.Length; i++)
                                objItem[i] = item[i];
                            DAL.BaseDAL.MyDataSet.Organization.LoadDataRow(objItem, LoadOption.OverwriteChanges);
                        }

                        OrganizationList orgList = new OrganizationList();
                        OrganizationList orgListAll = new OrganizationList();
                        orgListAll = GetAllOrganizations();

                        OrganizationList orgListDisableAll = new OrganizationList();
                        orgListDisableAll = GetAllOrganizations(false);

                        if ((orgListAll != null) && (orgListAll.Count > 0))
                            orgList.AddRange(orgListAll);

                        if ((orgListDisableAll != null) && (orgListDisableAll.Count > 0))
                            orgList.AddRange(orgListDisableAll);

                        foreach (Organization orgOUA in orgList)
                        {
                            if (!(listOrgID.Contains(orgOUA.ID)))
                            {
                                PreferredPathsList paths = GetPreferredPathsListByOrganizationID(orgOUA.ID);
                                if (paths != null)
                                {
                                    success = DeletePreferredPathsList(paths);
                                    if (!success)
                                        return false;
                                }

                                ProjectList listPrjOUA = GetProjectsForOrganization(orgOUA.ID);

                                if (listPrjOUA != null)
                                {
                                    foreach (Project prj in listPrjOUA)
                                    {
                                        success = RemoveProjectFromOrganization(orgOUA.ID, prj.ID);
                                        if (!success)
                                            return false;

                                        prj.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                        success = UpdateProject(prj);
                                        if (!success)
                                            return false;

                                    }
                                }
                                ContactList listContactOUA = GetContactsByOrganizationID(orgOUA.ID);
                                if (listContactOUA != null)
                                    foreach (Contact cnt in listContactOUA)
                                    {
                                        success = RemoveContactFromOrganization(orgOUA.ID, cnt.ID);
                                        if (!success)
                                            return false;

                                        cnt.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                        success = UpdateContact(cnt);
                                        if (!success)
                                            return false;
                                    }

                                //update local storage with organization
                                orgOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateOrganization(orgOUA);

                                if (!success)
                                    return false;
                            }
                        }
                    }

                    if (tsrUserSpecificData.Project != null)
                    {
                        List<long> listPrjID = new List<long>();

                        foreach (DataRow item in tsrUserSpecificData.Project.Rows)
                        {
                            long prjID = -1;
                            if (long.TryParse(item[0].ToString(), out prjID))
                                listPrjID.Add(prjID);

                            //add or update the project on server to dataset
                            //column index of the item taken from Dataset
                            object[] objItem = new object[item.ItemArray.Length];
                            for (int i = 0; i < item.ItemArray.Length; i++)
                                objItem[i] = item[i];
                            DAL.BaseDAL.MyDataSet.Project.LoadDataRow(objItem, LoadOption.OverwriteChanges);
                        }
                        
                        ProjectList listPrjOUA = GetAllProjects();
                        ProjectList listPrjOUA_Removed = GetAllProjects(false);

                        if (listPrjOUA_Removed != null && listPrjOUA_Removed.Count > 0)
                            listPrjOUA.AddRange(listPrjOUA_Removed);

                        foreach (Project prjOUA in listPrjOUA)
                        {
                            if (!(listPrjID.Contains(prjOUA.ID)))
                            {
                                PreferredPathsList paths = GetPreferredPathsListByProjectID(prjOUA.ID);
                                if (paths != null)
                                {
                                    success = DeletePreferredPathsList(paths);
                                    if (!success)
                                        return false;
                                }

                                success = RemoveAllActivitiesFromProject(prjOUA.ID);
                                if (!success)
                                    return false;

                                success = RemoveProjectFromOrganization(prjOUA.ID);
                                if (!success)
                                    return false;

                                prjOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateProject(prjOUA);
                                if (!success)
                                    return false;
                            }
                        }
                    }

                    if (tsrUserSpecificData.Activity != null)
                    {
                        List<long> listActID = new List<long>();
                        foreach (DataRow item in tsrUserSpecificData.Activity.Rows)
                        {
                            long actID = -1;
                            if (long.TryParse(item[0].ToString(), out actID))
                                listActID.Add(actID);

                            //add or update the activity on server to dataset
                            //column index of the item taken from Dataset
                            object[] objItem = new object[item.ItemArray.Length];
                            for (int i = 0; i < item.ItemArray.Length; i++)
                                objItem[i] = item[i];
                            DAL.BaseDAL.MyDataSet.Activity.LoadDataRow(objItem, LoadOption.OverwriteChanges);
                        }

                        ActivityList listActOUA = GetAllActivities();
                        ActivityList listActOUA_Disable = GetAllActivities(false);

                        if (listActOUA_Disable != null && listActOUA_Disable.Count > 0)
                            listActOUA.AddRange(listActOUA_Disable);

                        foreach (Activity actOUA in listActOUA)
                        {
                            if (!(listActID.Contains(actOUA.ID)))
                            {
                                PreferredPathsList paths = GetPreferredPathsListByActivityID(actOUA.ID);
                                if (paths != null)
                                {
                                    success = DeletePreferredPathsList(paths);
                                    if (!success)
                                        return false;
                                }
                                success = RemoveActivityFromAllProjects(actOUA.ID);
                                if (!success)
                                    return false;

                                actOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateActivity(actOUA);
                                if (!success)
                                    return false;
                            }
                        }
                    }
                    if (tsrUserSpecificData.Contact != null)
                    {
                        List<long> listCntID = new List<long>();
                        foreach (DataRow item in tsrUserSpecificData.Contact.Rows)
                        {
                            long cntID = -1;
                            if (long.TryParse(item[0].ToString(), out cntID))
                                listCntID.Add(cntID);

                            object[] objItem = new object[item.ItemArray.Length];
                            for (int i = 0; i < item.ItemArray.Length; i++)
                                objItem[i] = item[i];
                            DAL.BaseDAL.MyDataSet.Contact.LoadDataRow(objItem, LoadOption.OverwriteChanges);
                        }
                        ContactList listContact = new ContactList();
                        listContact = GetAllContacts();

                        ContactList listAllDisableContact = GetAllContacts(false);
                        if ((listAllDisableContact != null) && (listAllDisableContact.Count > 0))
                            listContact.AddRange(listAllDisableContact);

                        foreach (Contact cntOUA in listContact)
                        {
                            if (!(listCntID.Contains(cntOUA.ID)))
                            {
                                PreferredPathsList paths = GetPreferredPathsListByContactID(cntOUA.ID);
                                if (paths != null)
                                {
                                    success = DeletePreferredPathsList(paths);
                                    if (!success)
                                        return false;
                                }
                                success = RemoveContactFromAllOrganizations(cntOUA.ID);
                                if (!success)
                                    return false;

                                cntOUA.RowState = TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                success = UpdateContact(cntOUA);
                                if (!success)
                                    return false;
                            }
                        }
                    }
                    //Core.DAL.DSClass.ForceXMLSave();                    
                }
                success = true;
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                {
                    TSR.Core.Logging.LoggingHandler.LogError(new Exception(response.ErrorMessage));
                    throw new Exception(response.ErrorMessage);
                }
            }

            return success;
        }
        private static TSRDataSet GetTSRDataSetWithSettingsDataFromServer()
        {

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            WS.RequestMessageOfstring reqMachine = GetMachineID();

            WS.ResponseMessageOfstring responseMachSpecSettings = (!GetExchangeMode()) ? service.GetMachineSpecficSettingsData(userName, pass, reqMachine) : service.GetMachineSpecficSettingsDataForEX(userName, pass);
            if (responseMachSpecSettings.Data == "")
            {
                responseMachSpecSettings.Data = "<TSRDataSet xmlns=\"http://tempuri.org/TSRDataSet.xsd\">\r\n  <Settings>\r\n    <ID>1</ID>\r\n    <Key>Calendar</Key>\r\n    <Value>0000000029CF18B7FDF3A54997D6CFA7D0D240E722810000###Calendar</Value>\r\n </Settings>\r\n</TSRDataSet>";
            }
            //get machine specific settings data into dataset
            TSRDataSet dsMachineSpecificSettings = new TSRDataSet();
            System.IO.StringReader machineSpecSettingsrdr = new System.IO.StringReader(responseMachSpecSettings.Data);
            dsMachineSpecificSettings.ReadXml(machineSpecSettingsrdr);

            return dsMachineSpecificSettings;
        }

        private static WS.RequestMessageOfstring GetMachineID()
        {
            WS.RequestMessageOfstring reqMachine = new TSR.Core.UserAgentService.RequestMessageOfstring();
            reqMachine.Data = Environment.MachineName;
            return reqMachine;
        }
        /// <summary>
        /// Method for User Agent Data in to Server
        /// </summary>
        /// <returns></returns>
        internal static bool SaveUserAgentDataIntoServer()
        {
            TSRDataSet ds = new TSRDataSet();
            TSRDataSet dsMac = new TSRDataSet();
            TSRDataSet dsMacSettings = new TSRDataSet();

            //get the data from local dataset [xml] into separate datasets
            //because it will be saved separately in server
            for (int i = 0; i < DAL.BaseDAL.MyDataSet.Tables.Count; i++)
            {
                if ((DAL.BaseDAL.MyDataSet.Tables[i].TableName == "TimeEntry_OutlookAppointment") ||
                    (DAL.BaseDAL.MyDataSet.Tables[i].TableName == "RecurringMaster"))
                {
                    dsMac.Tables.Add(DAL.BaseDAL.MyDataSet.Tables[i].Copy());
                }
                else if (DAL.BaseDAL.MyDataSet.Tables[i].TableName == "Settings")
                {
                    dsMacSettings.Tables.Add(DAL.BaseDAL.MyDataSet.Tables[i].Copy());
                }
                else
                {
                    if (DAL.BaseDAL.MyDataSet.Tables[i].TableName == "UserSettings")
                    {
                        DataTable dt = DAL.BaseDAL.MyDataSet.Tables[i].Copy();
                        dt.Rows.Clear();

                        foreach (DataRow row in DAL.BaseDAL.MyDataSet.Tables[i].Rows)
                        {
                            if (!(row["Key"].ToString() == Constants.CONST_CUSTOMERNO_KEY ||
                                row["Key"].ToString() == Constants.CONST_EXCHANGEMODE_KEY ||
                                row["Key"].ToString() == Constants.CONST_PASSWORD_KEY ||
                                row["Key"].ToString() == Constants.CONST_SERVERADDRESS_KEY ||
                                row["Key"].ToString() == Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY ||
                                row["Key"].ToString() == Constants.CONST_TSRISCHOOSESSL_KEY ||
                                row["Key"].ToString() == Constants.CONST_USERNAME_KEY ||
                                row["Key"].ToString() == Constants.CONST_WEBINTERFACE_KEY ||
                                row["Key"].ToString() == SettingsHelper._TSRDontShowAgain ||
                                row["Key"].ToString() == SettingsHelper.TSRDO_NOT_RETRIEVE_SETTING_SERVER ||
                                row["Key"].ToString() == "UpdateCategories"))// ||
                            //row["Key"].ToString().ToUpper().StartsWith("PROXY")))
                            {
                                dt.Rows.Add(new object[3] { row[0], row[1], row[2] });
                            }
                        }
                        ds.Tables.Add(dt);
                    }
                    else
                    {
                        ds.Tables.Add(DAL.BaseDAL.MyDataSet.Tables[i].Copy());
                    }
                }
            }

            DAL.AppConfigDAL dal = new DAL.AppConfigDAL();
            dal.UpdateAppConfig(_AppConfig);
            _AppConfig = null;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            //get user specific data [time entry, setup data]
            WS.RequestMessageOfstring reqMachine = new WS.RequestMessageOfstring();
            reqMachine.Data = Environment.MachineName;
            WS.RequestMessageOfstring userSpecData = new WS.RequestMessageOfstring();
            userSpecData.Data = ds.GetXml();

            //get machinespecific appointment data
            WS.RequestMessageOfstring macSpecData = new WS.RequestMessageOfstring();
            macSpecData.Data = dsMac.GetXml();

            //get machinespecific appointment data
            WS.RequestMessageOfstring macSpecSettingData = new WS.RequestMessageOfstring();
            macSpecSettingData.Data = dsMacSettings.GetXml();

            WS.ResponseMessageOfboolean response = (GetExchangeMode()) ? service.SaveUserAgentDataForEX(userName, pass, reqMachine, userSpecData, macSpecData, macSpecSettingData) : service.SaveUserAgentData(userName, pass, reqMachine, userSpecData, macSpecData, macSpecSettingData);

            return response.Data;
        }

        //Added by tsrdev1
        //Added datetime 17/11/2010
        /// <summary>
        /// Log in user to server
        /// </summary>
        /// <returns></returns>
        internal static WS.ResponseMessageOfboolean LogInUserToServer()
        {
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            WS.ResponseMessageOfboolean response = new WS.ResponseMessageOfboolean();
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            var request = new WS.RequestMessageOfLogOUALoginWM9H3p7p();
            var ouaLogLogin = new WS.LogOUALogin();
            ouaLogLogin.UserName = userName.Data;
            ouaLogLogin.CustomerNo = TSRFacade.GetOUAAccountNumber();
            ouaLogLogin.OUAVersion = TSRFacade.GetOUAVersion();
            if (ouaLogLogin.OUAVersion.EndsWith(".")) ouaLogLogin.OUAVersion.Remove(ouaLogLogin.OUAVersion.Length - 1);
            ouaLogLogin.Timestamp = DateTime.Now;
            ouaLogLogin.OutlookVersion = OutlookHelper.CurrentApplication.Version;
            request.Data = ouaLogLogin;
            response = service.LogInUserWithLogDB(userName, pass, request);

            return response;
        }

        /// <summary>
        /// Login to server by user and pass in settings values
        /// Only failed when user/password is wrong (not in case the user is locked)
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool LogInToServer()
        {
            bool isAuthenticated = false;

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            WS.ResponseMessageOfboolean response = new WS.ResponseMessageOfboolean();
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            
            var request = new WS.RequestMessageOfLogOUALoginWM9H3p7p();
            try
            {
                var ouaLogLogin = new WS.LogOUALogin();
                ouaLogLogin.UserName = userName.Data;
                ouaLogLogin.CustomerNo = TSRFacade.GetOUAAccountNumber();
                ouaLogLogin.OUAVersion = TSRFacade.GetOUAVersion();
                if (ouaLogLogin.OUAVersion.EndsWith(".")) ouaLogLogin.OUAVersion.Remove(ouaLogLogin.OUAVersion.Length - 1);
                ouaLogLogin.Timestamp = DateTime.Now;
                ouaLogLogin.OutlookVersion = OutlookHelper.CurrentApplication.Version;
                request.Data = ouaLogLogin;
                response = service.LogInUserWithLogDB(userName, pass, request);

                if (!response.Data)
                {
                    if (!string.IsNullOrEmpty(response.ErrorMessage))
                    {
                        int intType = 4; //UnknownUser
                        if (int.TryParse(response.ErrorMessage, out intType))
                        {
                            WS.TypeOfEventEnum1 type = (WS.TypeOfEventEnum1)intType;
                            switch (type)
                            {
                                case WS.TypeOfEventEnum1.AccountLocked:
                                    isAuthenticated = true;
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            { }
            return response.Data || isAuthenticated;
        }        

        #endregion

        private static AppConfig _AppConfig = null;

        /// <summary>
        /// Method for retrieving license information for server
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        internal static WS.ApplicationLicense FetchAndProcessLicenseInformation(ref string error)
        {

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();


            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());

            try
            {
                WS.ResponseMessageOfApplicationLicenseIOX2hSuW response = service.GetLicense63(userName, pass);

                WS.ApplicationLicense license;
                if (response.IsSuccessful)
                {
                    license = response.Data;
                    try
                    {
                        AppConfig licenseConfig = new AppConfig();
                        licenseConfig.Key = Constants.LICENSE_CONFIG_KEY;
                        licenseConfig.Value = MiscHelper.SerializeBase64(license);
                        DAL.AppConfigDAL dal = new DAL.AppConfigDAL();
                        dal.UpdateAppConfig(licenseConfig);
                        _AppConfig = licenseConfig;
                    }
                    catch (Exception ex)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                        error = ResourceManager.GetResourceString("ErrorSavingLicenseInformation", "Error saving license information");
                    }
                }
                return response.Data;
            }
            catch (TimeoutException timeoutEx)
            {
                error = ResourceManager.GetResourceString("ServerTimeoutException",
                    "TimeSheet Reporter Outlook User Agent could not connect to server. Please restart Outlook when convenient. If the problem persists, please contact your system administrator.");
                error += Environment.NewLine + ResourceManager.GetResourceString("PressOKToContinue", "Press OK to continue");
                Core.Logging.LoggingHandler.LogError(timeoutEx);
                return null;
            }
        }

        /// <summary>
        /// Method for retrieving main License text
        /// </summary>
        /// <returns></returns>
        public static string GetLicenseText()
        {
            return GetLicenseInfo().LicenseText;
        }

        /// <summary>
        /// Method for retrieving License information from local storage
        /// </summary>
        /// <returns></returns>
        private static Core.UserAgentService.ApplicationLicense GetLicense()
        {
            string licenseString = GetAppConfigValueByKey(Constants.LICENSE_CONFIG_KEY);
            WS.ApplicationLicense license = new WS.ApplicationLicense();

            if (!string.IsNullOrEmpty(licenseString))
                license = (WS.ApplicationLicense)MiscHelper.DeserializeBase64(licenseString);
            else
                license = null;
            return license;
        }

        /// <summary>
        /// Method for retrieving Default Calendar folder [entry id + separator + name] settings from local storage
        /// [outlook specific, so this is machine specific and
        /// storage mechanism is different than other settings data]
        /// </summary>
        /// <returns></returns>
        public static string GetDefaultCalendarForTSRSync()
        {
            string value = GetSettingsValueByKey(Constants.TSR_DEFAULT_CALENDAR_KEY_FOR_SYNC);
            return value;
        }

        /// <summary>
        /// Method for saving default caledar folder into local storage [outlook specific, so this is machine specific and
        /// storage mechanism is different than other settings data]
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool SetDefaultCalendarForTSRSync(string value)
        {
            return SetSettingsValueByKey(Constants.TSR_DEFAULT_CALENDAR_KEY_FOR_SYNC, value);
        }

        /// <summary>
        /// Retrieving License Information class which holds basic license information to be shown in About Screen, etc.
        /// </summary>
        /// <returns></returns>
        public static LicenseInfo GetLicenseInfo()
        {
            LicenseInfo licenseInfo = new LicenseInfo();

            string licenseText = string.Empty;
            string version = string.Empty;
            string company = string.Empty;

            WS.ApplicationLicense license = GetLicense();

            if (license != null)
            {
                version = license.Version;
                company = license.OrganizationName;
                string tsrdemo = ResourceManager.GetResourceString("ProductName", "TSR") + "-" + ResourceManager.GetResourceString("Demo", "Demo");

                if (license.LicenseType == WS.LicenseTypes.Demo)
                    licenseText = tsrdemo;
                else
                    licenseText = ResourceManager.GetResourceString("ProductName", "TSR");

                foreach (WS.ModuleLicense item in license.Modules)
                {
                    if(item.Key.Contains("TSR-EXP"))
                        continue;

                    if (item.FunctionalExpiryDate.HasValue)
                    {
                        licenseInfo.ExpiryDate = item.FunctionalExpiryDate.Value;

                        if (item.FunctionalExpiryDate < DateTime.Today)
                        {
                            if (licenseText == tsrdemo)
                                licenseText = ResourceManager.GetResourceString("ProductName", "TSR") + "-" + ResourceManager.GetResourceString("Unlicensed", "Unlicensed");
                            else
                                licenseText = ResourceManager.GetResourceString("ProductName", "TSR") + "-" + ResourceManager.GetResourceString("LicenseExpired", "License Expired");
                            break;
                        }
                    }
                }
            }
            else
            {
                licenseText = ResourceManager.GetResourceString("ProductName", "TSR") + "-" + ResourceManager.GetResourceString("LicenseUnknown", "License Unknown");
            }

            licenseInfo.LicenseText = licenseText;
            licenseInfo.Version = version;
            licenseInfo.CompanyName = company;

            return licenseInfo;
        }

        public static void UpdateCategories()
        {
            TimeEntryList timeEntryList = GetAllTimeEntries();

            if (timeEntryList == null || timeEntryList.Count == 0) return;

            //TSR.Core.OutlookHelper.CreateCategoriesForTSREntry();
            foreach (TimeEntry te in timeEntryList)
            {
                Microsoft.Office.Interop.Outlook.AppointmentItem appItem = null;
                try
                {
                    appItem = te.OLAppointmentItem;
                }
                catch //(Exception exp)
                {
                    //Core.Logging.LoggingHandler.LogError(exp);
                }

                if (appItem != null && !appItem.IsRecurring)
                {
                    appItem.Categories = OutlookHelper.SetTSRCategory(appItem.Categories, te.Status);
                    appItem.Save();
                }
            }

        }

        #region Mic
        public static bool IsValidUserAccount()
        {
            string userName = string.Empty;
            string password = string.Empty;
            userName = GetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY);
            password = GetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY);
            if (string.IsNullOrEmpty(userName) || (string.IsNullOrEmpty(password)))
                return false;
            return true;
        }

        public static bool GetTSRSSLMode()
        {
            bool IsSSLMode = true;
            try
            {
                string strSSLMode = GetUserSettingsValueByKey(Constants.CONST_TSRISCHOOSESSL_KEY);
                if (!string.IsNullOrEmpty(strSSLMode))
                    IsSSLMode = bool.Parse(GetUserSettingsValueByKey(Constants.CONST_TSRISCHOOSESSL_KEY));
            }
            catch
            {
            }
            return IsSSLMode;
        }

        public static void SetTSRSSLMode(string value)
        {
            SetUserSettingsValueByKey(Constants.CONST_TSRISCHOOSESSL_KEY, value);
        }
        /// <summary>
        /// Get non ad user name
        /// </summary>
        /// <returns></returns>
        public static string GetNONADUserName()
        {
            return GetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY);
        }
        /// <summary>
        /// Set non ad user name
        /// </summary>
        /// <param name="userName"></param>
        public static void SetNONADUserName(string userName)
        {
            SetUserSettingsValueByKey(Constants.CONST_USERNAME_KEY, userName);
        }
        /// <summary>
        /// Get non ad user's password
        /// </summary>
        /// <returns></returns>
        public static string GetNONADPassword()
        {
            return GetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY);
        }
        /// <summary>
        /// Set non ad user's password
        /// </summary>
        /// <param name="pass"></param>
        public static void SetNONADPassword(string pass)
        {
            SetUserSettingsValueByKey(Constants.CONST_PASSWORD_KEY, pass);
        }

        public static bool GetExchangeMode()
        {
            //string strExchangeMode = string.Empty;
            //strExchangeMode = GetUserSettingsValueByKey(Constants.CONST_EXCHANGEMODE_KEY);
            //if (string.IsNullOrEmpty(strExchangeMode))
            //    return false;
            //else
            //{
            //    if (strExchangeMode.ToUpper() == ExchangeMode.Yes.ToString().ToUpper())
            //        return true;
            //    else
            //        return false;
            //}


            string strExchangeMode = string.Empty;
            strExchangeMode = GetUserSettingsValueByKey(Constants.CONST_EXCHANGEMODE_KEY);
            if (string.IsNullOrEmpty(strExchangeMode)
                || strExchangeMode.ToUpper() != ExchangeMode.Yes.ToString().ToUpper())
                SetUserSettingsValueByKey(Constants.CONST_EXCHANGEMODE_KEY, "Yes");

            return true;

        }

        #endregion

        #region OUALog Information
        public static string GetOUAAccountNumber()
        {
            return GetUserSettingsValueByKey(Constants.CONST_CUSTOMERNO_KEY);
        }
        private static string GetOUAVersion()
        {
            var assembly =Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            return fvi.FileVersion;
        }
        #endregion

        #region LockPeriod Synchronization

        public static bool SyncLockPeriod()
        {
            bool success = false;
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            WS.RequestMessageOflong organizationID = new WS.RequestMessageOflong();

            userName.Data = GetNONADUserName();
            pass.Data = GetNONADPassword();

            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(GetTSRSSLMode());
            var responseGetLockPeriods = service.GetLockPeriods(userName, pass);
            success = responseGetLockPeriods.IsSuccessful;
            if (success)
            {
                //Remove all lock period
                success = RemoveAllLockPeriod();
                if (!success)
                    return false;

                foreach (WS.LockPeriod lp in responseGetLockPeriods.Data)
                {
                    success = UpdateLockPeriod(lp);
                    if (!success)
                        return false;
                }
            }

            return success;
        }
        #endregion


        #region LockPeriod
  
        public static bool UpdateLockPeriod(Entity.LockPeriod obj)
        {
            using (var dal = new DAL.LockPeriodDAL())
            {
                return dal.UpdateLockPeriod(obj);
            }
        }

        /// <summary>
        /// method to update lockperiod
        /// </summary>
        /// <param name="obj">lockperiod object to be updated</param>
        /// <returns></returns>        
        public static bool UpdateLockPeriod(WS.LockPeriod obj)
        {
            var locObj = new Entity.LockPeriod();
            locObj.UserID = obj.UserID;
            locObj.LockDate = obj.LockDate;
            locObj.IsLocked = obj.IsLocked;
            
            return UpdateLockPeriod(locObj);
        }

        public static bool RemoveAllLockPeriod()
        {
            using (var dal = new DAL.LockPeriodDAL())
            {
                return dal.RemoveAllLockPeriod();
            }
        }

        #endregion

        #region Location

        /// <summary>
        /// method to update location
        /// </summary>
        /// <param name="obj">location object to be updated</param>
        /// <returns></returns>
        public static bool UpdateLocation(Entity.Location obj)
        {
            using (var dal = new DAL.LocationDAL())
            {
                return dal.UpdateLocation(obj);
            }
        }

        /// <summary>
        /// method to update location
        /// </summary>
        /// <param name="obj">location object to be updated</param>
        /// <returns></returns>        
        public static bool UpdateLocation(WS.Location obj)
        {
            var locObj = new Entity.Location();
            locObj.ID = obj.ID;
            locObj.Name = obj.Name;
            locObj.Description = obj.Description;
            locObj.IsActivate = obj.IsActivate;
            locObj.ForeignKey = obj.ForeignKey;

            return UpdateLocation(locObj);
        }

        /// <summary>
        /// method to retrieve location by location id
        /// </summary>
        /// <param name="locationID">location id</param>
        /// <returns></returns>
        public static Entity.Location GetLocationByID(Int64 locationID)
        {
            using (var dal = new DAL.LocationDAL())
            {
                return dal.GetLocationByID(locationID);
            }
        }

        /// <summary>
        /// method to retrieve location by location id
        /// </summary>
        /// <param name="location">location id</param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.Location GetLocationByID(Int64 locationID, bool visible)
        {
            using (var dal = new DAL.LocationDAL())
            {
                return dal.GetLocationByID(locationID, visible);
            }
        }
        /// <summary>
        /// method to retrieve all locations
        /// </summary>
        /// <returns></returns>
        public static Entity.LocationList GetAllLocations()
        {
            using (var dal = new DAL.LocationDAL())
            {
                return dal.GetAllLocations();
            }
        }
        /// <summary>
        /// method to retrieve all locations
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public static Entity.LocationList GetAllLocations(bool visible)
        {
            using (var dal = new DAL.LocationDAL())
            {
                return dal.GetAllLocations(visible);
            }
        }

        #endregion


        public static CultureInfo GetCurrentCulture()
        {
            string languageId = TSRFacade.GetLanguageIDByLanguageName(ResourceManager.GetCurrentLanguageName());
            if (languageId.Length == 2)
            {
                List<CultureInfo> culs = GetSpecificCultures();
                foreach (CultureInfo cul in culs)
                {
                    if (cul.TwoLetterISOLanguageName.Equals(languageId, StringComparison.OrdinalIgnoreCase))
                    {
                        return cul;
                    }
                }
            }

            return new CultureInfo(languageId);
        }

        private static List<CultureInfo> GetSpecificCultures()
        {
            CultureInfo[] cultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            List<CultureInfo> cList = new List<CultureInfo>();
            foreach (CultureInfo c in cultures)
            {
                cList.Add(c);
            }

            return cList;
        }
    }
}