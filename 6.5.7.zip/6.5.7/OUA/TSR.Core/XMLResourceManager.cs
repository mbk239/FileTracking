using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Globalization;
using System.Resources;

namespace TSR.Core
{
    /// <summary>
    /// Class
    /// Name: XMLResourceManager
    /// Description: This class is a custom ResourceManager 
    /// who handles ResourceManager related properties & functions.
    /// </summary>
    public class XMLResourceManager : System.Resources.ResourceManager
    {
        #region Constructors

        public XMLResourceManager()
        {
            ResourceSets = new Hashtable();
        }

        #endregion
        
        /// <summary>
        /// Retrieves resource set, with some optional parameters for culture, etc
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="createIfNotExists"></param>
        /// <param name="tryParents"></param>
        /// <returns></returns>
        protected override ResourceSet InternalGetResourceSet(
              CultureInfo culture, bool createIfNotExists, bool tryParents)
        {
            XMLResourceSet rs = null;

            if (ResourceSets.Contains(culture.Name))
            {
                rs = ResourceSets[culture.Name] as XMLResourceSet;
            }
            else
            {
                rs = new XMLResourceSet(culture);
                ResourceSets.Add(culture.Name, rs);
            }
            return rs;
        }

        /// <summary>
        /// retrieves resource set
        /// </summary>
        /// <param name="culture"></param>
        /// <param name="createIfNotExists"></param>
        /// <param name="tryParents"></param>
        /// <returns></returns>
        public override ResourceSet GetResourceSet(CultureInfo culture, bool createIfNotExists, bool tryParents)
        {
            return base.GetResourceSet(culture, createIfNotExists, tryParents);
        }
    }
}
