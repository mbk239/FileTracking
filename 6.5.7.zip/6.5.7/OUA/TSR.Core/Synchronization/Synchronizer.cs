﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TSR.Core.Synchronization
{
    /// <summary>
    /// this is for synchronization process
    /// </summary>
    public abstract class Synchronizer : IDisposable
    {
        private static Core.SyncEngine syncEngine;
        public static Timer timer;
        private static IMemoryBox _memBox;

        public static ISyncEngineCheckListTimeEntry checkListTiemEntry;
                

        /// <summary>
        /// Synchronize process for backgroundworker
        /// </summary>
        public static void Synchronize(IMemoryBox membox)
        {
            Synchronize(true, membox);
        }

        public static Timer GetTimerInstance()
        {
            if (timer == null)
                timer = new Timer();
            return timer;
        }

        /// <summary>
        /// Synchronize process
        /// </summary>
        /// <param name="inBackground"></param>
        public static void Synchronize(bool inBackground, IMemoryBox memBox)
        {
            syncEngine = Core.SyncEngine.GetInstance();
            if (syncEngine == null) // it must be already in another synchronization process
            {
                return;
            }
            syncEngine.DoAsBackGroundWorker = inBackground;
            if (checkListTiemEntry != null)
                syncEngine._checkListTimeEntry = checkListTiemEntry;

            //bool isWrongUserPass = !TSRFacade.LogInToServer();
            //{
            //    if (isWrongUserPass && !TSRFacade.TSRLoginDismiss)
            //    {
            //        frmTSRLoginRequired frmLogin = frmTSRLoginRequired.GetInstance(true);
            //        frmLogin.ShowDialog();
            //    }
            //}

            syncEngine.StartSynchornization(memBox);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (TSR.Core.SettingsHelper.TSRAutoSyncOption)
                {
                    if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
                    {
                        Synchronize(false, _memBox);
                    }
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        /// <summary>
        /// synchonization with timer
        /// </summary>
        public static void SynchronizeByTimer(IMemoryBox MemoryBox)
        {
            if (TSR.Core.SettingsHelper.TSRAutoSyncOption == false)
            {
                if (timer != null)
                {
                    timer.Stop();
                    timer = null;
                }
            }
            else
            {
                _memBox = MemoryBox;
                if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
                {
                    int numberOfintervals  = (Core.SettingsHelper.TSRAutoSyncIndex > -1 ? Core.SettingsHelper.TSRAutoSyncIndex : 1);
                    int intervalInMillSec = 0;

                    //assumption - if the interval is not in hours, it must be in minutes
                    int intervalInSeconds = 60;
                    if (Core.SettingsHelper.TSRAutoSyncPeriod == (int)TSR.Core.SettingsHelper.PeriodType.Hour)
                        intervalInSeconds = 3600;

                    intervalInMillSec = numberOfintervals * intervalInSeconds * 1000;
                    Timer timer = GetTimerInstance();
                    timer.Interval = intervalInMillSec;
                    if (TSRFacade.bCheckTimer)
                    {
                        timer.Tick += new EventHandler(timer_Tick);
                    }
                    timer.Start();
                }
                else
                {
                    if (timer != null)
                    {
                        timer.Stop();
                        timer = null;
                    }
                }
            }
            
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (syncEngine != null)
                syncEngine = null;
            if (timer != null)
                timer = null;
        }

        #endregion
    }
}
