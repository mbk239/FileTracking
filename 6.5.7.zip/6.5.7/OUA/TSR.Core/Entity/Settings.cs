﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class Settings
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Key = "Key";
        public static readonly string Property_Value = "Value";

        #endregion

        #region Properties

        public Int64 ID { get; set; }

        public string Key { get; set; }

        public string Value { get; set; }

        #endregion        
    }

    public class SettingsList : List<Settings>
    {
        #region constructors

        public SettingsList() { }

        #endregion


        /// <summary>
        /// finds Settings from list of Settings by id of a Settings
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Settings FindByID(Int64 id)
        {
            return this.Find(delegate(Settings sts) { return sts.ID == id; });
        }

        /// <summary>
        /// finds Settings from list of Settings by key of a Settings
        /// </summary>
        /// <param name="AppConfigID"></param>
        /// <returns></returns>
        public Settings FindByAppConfigKey(string SettingsID)
        {
            return this.Find(delegate(Settings sts) { return sts.Key == SettingsID; });
        }
    }
}
