﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class Language
    {
        #region Constants
        public static readonly string Property_ID = "ID";
        public static readonly string Property_LanguageID = "LanguageID";
        public static readonly string Property_LanguageName = "LanguageName";        

        #endregion

        public Int64 ID { get; set; }

        public string LanguageID { get; set; }

        public string LanguageName { get; set; }
    }
}
