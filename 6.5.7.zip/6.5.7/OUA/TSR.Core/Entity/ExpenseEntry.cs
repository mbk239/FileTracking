using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Outlook = Microsoft.Office.Interop.Outlook;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Time Entry object, inherits from service proxy generated object from server entity
    /// </summary>
    public class ExpenseEntry : WS.ExpenseEntry
    {
        #region constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_IDServer = "IDServer";
        public static readonly string Property_IsDeleted = "IsDeleted";
        public static readonly string Property_IsDeletedOnServer = "IsDeletedOnServer";
        public static readonly string Property_Revision = "Revision";
        public static readonly string Property_ExpenseSheetID = "ExpenseSheetID";
        public static readonly string Property_TimeEntryID = "TimeEntryID";
        public static readonly string Property_ExpenseTypeID = "ExpenseTypeID";
        public static readonly string Property_Description = "Description";
        public static readonly string Property_Quantity = "Quantity";
        public static readonly string Property_Value = "Value";
        public static readonly string Property_Total = "Total";

        #endregion

        #region priavte variables

        private Int64? _Revision;

        //private string _ExpenseTypeName;

        private Boolean? _IsDeleted;

        private Guid? _timeEntryID;

        private Int64? _IDServer;               

        #endregion

        #region Properties

        /// <summary>
        /// The last time that time entry is modified on TSR Server
        /// </summary>
        public Int64? Revision
        {
            get
            {
                return _Revision;
            }
            set
            {
                if (value.HasValue)
                    _Revision = value.Value;
            }
        }

        //public string ExpenseTypeName
        //{
        //    get { return _ExpenseTypeName; }
        //    set { _ExpenseTypeName = value; }
        //}

        public Boolean? IsDeleted
        {
            get
            {
                if (_IsDeleted == null)
                {
                    _IsDeleted = false;
                }
                return _IsDeleted;
            }
            set
            {
                if (value.HasValue)
                {
                    _IsDeleted = value.Value;
                }
            }
        }

        public Guid? TimeEntryID
        {
            get { return _timeEntryID; }
            set { _timeEntryID = value; }
        }

        public Int64? IDServer
        {
            get { return _IDServer; }
            set { _IDServer = value; }
        }

        public void PopulateFromServer(WS.ExpenseEntry expServer)
        {
            this.IDServer = expServer.ID;
            this.ExpenseSheetID = expServer.ExpenseSheetID;
            this.ExpenseTypeID = expServer.ExpenseTypeID;
            this.ExpenseTypeName = expServer.ExpenseTypeName;
            this.Description = expServer.Description;
            this.Quantity = expServer.Quantity;
            this.Value = expServer.Value;
            this.Total = expServer.Total;
            this.Revision = expServer.Revision;
            this.IsDeleted = expServer.IsDeletedOnServer;
            this.TimeEntryID = expServer.TimeEntryID;
            this.LocationID = expServer.LocationID;
            this.LocationName = expServer.LocationName;
        }

        public WS.ExpenseEntry ConvertToServer()
        {
            WS.ExpenseEntry expServer = new WS.ExpenseEntry();
            expServer.ID = this.IDServer.HasValue ? this.IDServer.Value : -1;
            expServer.ExpenseSheetID = this.ExpenseSheetID;
            expServer.ExpenseTypeID = this.ExpenseTypeID;
            expServer.ExpenseTypeName = this.ExpenseTypeName;
            expServer.Description = this.Description;
            expServer.Quantity = this.Quantity;
            expServer.Value = this.Value;
            expServer.Total = this.Total;
            expServer.Revision = this.Revision;
            expServer.IsDeletedOnServer = this.IsDeleted.Value;
            expServer.TimeEntryID = this.TimeEntryID;
            expServer.LocationID = this.LocationID;
            expServer.LocationName = this.LocationName;
            return expServer;
        }

        #endregion

        #region Constructors

        /// <summary>
        /// no param constructor, initializes some necessary items
        /// </summary>
        public ExpenseEntry()
        {
        }

        #endregion
    }

    /// <summary>
    /// list object of time entry obje`cts
    /// </summary>
    public class ExpenseEntryList : List<ExpenseEntry>
    {
        public ExpenseEntryList() : base() { }
        public ExpenseEntryList(List<ExpenseEntry> list) : base(list) { }
        Queue<ExpenseEntry> queueExpenseEntry = new Queue<ExpenseEntry>();

        public ExpenseEntry PopExpenseEntry()
        {
            lock (this)
            {
                return queueExpenseEntry.Dequeue();
            }
        }

        public ExpenseEntryList PopAllExpenseEntry()
        {
            lock (this)
            {
                //return all time entry element in queue
                ExpenseEntryList list = new ExpenseEntryList();

                if (queueExpenseEntry != null)
                {
                    while (QueueHasData())
                    {
                        //dequeue each element
                        list.Add(queueExpenseEntry.Dequeue());
                    }
                }
                return list;
            }
        }

        public void PushExpenseEntry(ExpenseEntry timeEntry)
        {
            lock (this)
            {
                queueExpenseEntry.Enqueue(timeEntry);
            }
        }

        public void PushExpenseEntry(List<ExpenseEntry> listExpenseEntry)
        {
            lock (this)
            {
                if (listExpenseEntry != null && listExpenseEntry.Count > 0)
                {
                    foreach (ExpenseEntry te in listExpenseEntry)
                        queueExpenseEntry.Enqueue(te);
                }
            }

        }

        public bool QueueHasData()
        {
            lock (this)
            {
                if (queueExpenseEntry.Count != 0)
                    return true;
                else return false;
            }
        }

        /// <summary>
        /// find TSR Entry by TSR Item ID
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public ExpenseEntry FindByID(long exID)
        {
            return this.Find(delegate(ExpenseEntry ex) { return ex.ID == exID; });
        }
    }
}