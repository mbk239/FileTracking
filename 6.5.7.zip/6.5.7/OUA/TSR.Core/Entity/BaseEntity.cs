using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core.Entity
{
    /// <summary>
    /// this class was supposed to be inherited by all local entities.. so far only common property is ID
    /// and after consuming services.. this class is almost deprecated.. its only task that inherits it.. it will soon become deprecated
    /// </summary>
    [Serializable]
    public class BaseEntity
    {
        public static readonly string COL_ID = "ID";

        private Int64 _ID;

        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
    }
}
