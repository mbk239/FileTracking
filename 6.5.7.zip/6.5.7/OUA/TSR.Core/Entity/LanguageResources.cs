using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Runtime.Serialization;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// Name: ResourceDetail
    /// Description:
    /// </summary>
    //Basic Entity class of LanguageResources.

    [Serializable]
    public class LanguageResources : WS.LanguageResources
    {
        #region constants

        public const string Property_ID = "ID";
        public const string Property_LanguageID = "LanguageID";
        public const string Property_LanguageName = "LanguageName";
        public const string Property_ResourceKey = "ResourceKey";
        public const string Property_ResourceValue = "ResourceValue";

        #endregion

        #region constructors
        public LanguageResources() { }
        public LanguageResources(string languageID, string languageName, string resourceKey, string resourceValue)
        {
            LanguageID = languageID;
            LanguageName = languageName;
            ResourceKey = resourceKey;
            ResourceValue = resourceValue;
        }
        #endregion

        // Cloning Base Objects
        public LanguageResources Clone()
        {
            LanguageResources newObj = new LanguageResources();
            newObj.ID = this.ID;
            newObj.LanguageID = this.LanguageID;
            newObj.LanguageName = this.LanguageName;
            newObj.ResourceKey = this.ResourceKey;
            newObj.ResourceValue = this.ResourceValue;

            return newObj;
        }

        //// Getting object by adding value of that properties  
        //public override void GetObjectData(SerializationInfo info, StreamingContext context)
        //{
        //    info.AddValue(LanguageResources.Property_ID, ID);
        //    info.AddValue(LanguageResources.Property_LanguageID, LanguageID);
        //    info.AddValue(LanguageResources.Property_ResourceKey, ResourceKey);
        //    info.AddValue(LanguageResources.Property_ResourceValue, ResourceValue);
        //}
    }
}
