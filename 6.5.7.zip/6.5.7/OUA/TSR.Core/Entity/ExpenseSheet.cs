using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Outlook = Microsoft.Office.Interop.Outlook;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Time Entry object, inherits from service proxy generated object from server entity
    /// </summary>
    public class ExpenseSheet : WS.ExpenseSheet
    {
        #region constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_IsDeleted = "IsDeleted";
        public static readonly string Property_Status = "Status";
        public static readonly string Property_TimeEntryID = "TimeEntryID";

        #endregion

        #region priavte variables

        private bool _isDeleted;       

        private ExpenseEntryList _ExpenseEntryListLocal;
        
        #endregion

        #region Properties

        public bool IsDeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }
        }

        public ExpenseEntryList ExpenseEntryListLocal
        {
            get { return _ExpenseEntryListLocal; }
            set { _ExpenseEntryListLocal = value; }
        }

        public bool IsChangeAllowed()
        {
            if (((Status == UserAgentService.StatusEnum.PendingSubmission) ||
                    (Status == UserAgentService.StatusEnum.Rejected)))
            {
                return true;
            }
            return false;
        }

        public void ConvertExpenseEntriesToLocal()
        {
            if (this.ExpensesEntryList != null && this.ExpensesEntryList.Count > 0)
            {
                this._ExpenseEntryListLocal = new ExpenseEntryList();
                foreach (WS.ExpenseEntry expServer in this.ExpensesEntryList)
                {
                    ExpenseEntry expLocal = new ExpenseEntry();
                    expLocal.PopulateFromServer(expServer);
                    this._ExpenseEntryListLocal.Add(expLocal);
                }
            }
        }

        public void ConvertExpenseEntriesToLocal(WS.ExpenseEntryList lstEntries)
        {
            if (lstEntries != null && lstEntries.Count > 0)
            {
                this._ExpenseEntryListLocal = new ExpenseEntryList();
                foreach (WS.ExpenseEntry expServer in lstEntries)
                {
                    ExpenseEntry expLocal = new ExpenseEntry();
                    expLocal.PopulateFromServer(expServer);
                    this._ExpenseEntryListLocal.Add(expLocal);
                }
            }
        }

        public void ConvertExpenseEntriesToServer()
        {
            if (this.ExpenseEntryListLocal != null && this.ExpenseEntryListLocal.Count > 0)
            {
                this.ExpensesEntryList = new WS.ExpenseEntryList();
                foreach (ExpenseEntry expLocal in this.ExpenseEntryListLocal)
                {
                    WS.ExpenseEntry expServer = expLocal.ConvertToServer();
                    this.ExpensesEntryList.Add(expServer);
                }
            }
        }

        public WS.ExpenseSheet ConvertToServer()
        {
            WS.ExpenseSheet sv = new WS.ExpenseSheet();
            ConvertExpenseEntriesToServer();
            sv.ExpensesEntryList = this.ExpensesEntryList;
            sv.ID = this.ID;
            sv.Revision = this.Revision.HasValue ? this.Revision.Value :  0;
            sv.Status = this.Status;
            sv.TimeEntryID = this.TimeEntryID;
            sv.IsDeletedOnServer = this.IsDeleted; //flag to check deleted on client
            return sv;
        }

        public void PopulateFromServer(WS.ExpenseSheet sv)
        {
            ConvertExpenseEntriesToLocal(sv.ExpensesEntryList);
            this.ExpensesEntryList = sv.ExpensesEntryList;
            this.ID = sv.ID;
            //this.IsDeleted
            this.Revision = sv.Revision;
            this.Status = sv.Status;
            this.TimeEntryID = sv.TimeEntryID;
            this.ConvertExpenseEntriesToLocal();
        }

        #endregion

        #region Constructors

        /// <summary>
        /// no param constructor, initializes some necessary items
        /// </summary>
        public ExpenseSheet()
        {
        }

        #endregion
    }

    /// <summary>
    /// list object of time entry obje`cts
    /// </summary>
    public class ExpenseSheetList : List<ExpenseSheet>
    {
        public ExpenseSheetList() : base() { }
        public ExpenseSheetList(List<ExpenseSheet> list) : base(list) { }
        Queue<ExpenseSheet> queueExpenseSheet = new Queue<ExpenseSheet>();

        public ExpenseSheet PopExpenseSheet()
        {
            lock (this)
            {
                return queueExpenseSheet.Dequeue();
            }
        }

        public ExpenseSheetList PopAllExpenseSheet()
        {
            lock (this)
            {
                //return all time entry element in queue
                ExpenseSheetList list = new ExpenseSheetList();

                if (queueExpenseSheet != null)
                {
                    while (QueueHasData())
                    {
                        //dequeue each element
                        list.Add(queueExpenseSheet.Dequeue());
                    }
                }
                return list;
            }
        }

        public void PushExpenseSheet(ExpenseSheet timeEntry)
        {
            lock (this)
            {
                queueExpenseSheet.Enqueue(timeEntry);
            }
        }

        public void PushExpenseSheet(List<ExpenseSheet> listExpenseSheet)
        {
            lock (this)
            {
                if (listExpenseSheet != null && listExpenseSheet.Count > 0)
                {
                    foreach (ExpenseSheet te in listExpenseSheet)
                        queueExpenseSheet.Enqueue(te);
                }
            }

        }

        public bool QueueHasData()
        {
            lock (this)
            {
                if (queueExpenseSheet.Count != 0)
                    return true;
                else return false;
            }
        }

        /// <summary>
        /// find TSR Entry by TSR Item ID
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public ExpenseSheet FindByID(long exID)
        {
            return this.Find(delegate(ExpenseSheet ex) { return ex.ID == exID; });
        }
    }
}