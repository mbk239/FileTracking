using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity.List
{
    /// <summary>
    /// List object LanguageResources objects
    /// </summary>
    public class LanguageResourcesList : List<LanguageResources>
    {
        public LanguageResourcesList() : base() { }
        public LanguageResourcesList(LanguageResources[] list) : base(list) { }
        public LanguageResourcesList(List<LanguageResources> list) : base(list) { }

        /// <summary>
        /// finds list of LanguageResources class which has the key passed as parameter
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public LanguageResourcesList FindAllByKey(String key)
        {
            LanguageResourcesList list = new LanguageResourcesList(FindAll(delegate(LanguageResources lr) { return lr.ResourceKey == key; }));
            return list;
        }

        /// <summary>
        /// finds list of LanguageResources objects which has passed languageid as parameter
        /// </summary>
        /// <param name="languageId"></param>
        /// <returns></returns>
        public LanguageResourcesList FindAllByLanguageId(String languageId)
        {
            LanguageResourcesList list = new LanguageResourcesList(FindAll(delegate(LanguageResources lr) { return lr.LanguageID == languageId; }));
            return list;
        }
    }
}
