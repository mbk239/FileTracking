using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core.Entity
{
    /// <summary>
    /// Class was created but not yet available for users.. waiting for business decision
    /// </summary>
    public class Task : BaseEntity,IComparable<Task>
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_Visible = "Visible";

        private const string ID_INITIALIZER_FOR_OUA_RIBBON_TASK = "TSK_";

        #endregion

        #region Private Variables
        private String _Name;
        private bool _Visible;
        #endregion

        #region Properties
        public String TaskID
        {
            get { return ID_INITIALIZER_FOR_OUA_RIBBON_TASK + ID; }
        }

        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }
        #endregion

        #region IComparable<Task> Members

        public int CompareTo(Task other)
        {
            return Name.CompareTo(other.Name);
        }

        #endregion
    }

    /// <summary>
    /// List of task object
    /// </summary>
    public class TaskList : List<Task>
    {
        #region Constructors

        public TaskList() { }

        public TaskList(bool includeDefaultSelectionItem)
            : this()
        {
            InsertSelectionDefaultItem();
        }

        #endregion
        
        /// <summary>
        /// inserts selection item in task list
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            Task tsk = new Task();
            tsk.Name = ResourceHelper.TaskSelectionText;
            tsk.ID = Constants.DEFAULT_SELECTION_VALUE_INT;

            this.Insert(0, tsk);
        }

        /// <summary>
        /// find a task by id [task id]
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task FindByID(Int64 id)
        {
            return this.Find(delegate(Task tsk) { return tsk.ID == id; });
        }

        /// <summary>
        /// find a task by activity id
        /// </summary>
        /// <param name="taskID"></param>
        /// <returns></returns>
        public Task FindByActivityID(string taskID)
        {
            return this.Find(delegate(Task tsk) { return tsk.TaskID == taskID; });
        }
    }
}
