﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class AppConfig
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Key = "Key";
        public static readonly string Property_Value = "Value";

        #endregion

        public Int64 ID { get; set; }

        public string Key { get; set; }

        public string Value { get; set; }
    }

    public class AppConfigList : List<AppConfig>
    {
        #region constructors

        public AppConfigList() { }

        #endregion

        
        /// <summary>
        /// finds AppConfig from list of AppConfigs by id of an AppConfig
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public AppConfig FindByID(Int64 id)
        {
            return this.Find(delegate(AppConfig apc) { return apc.ID == id; });
        }

        /// <summary>
        /// finds AppConfig from list of AppConfigs by key of an AppConfig
        /// </summary>
        /// <param name="AppConfigID"></param>
        /// <returns></returns>
        public AppConfig FindByAppConfigKey(string AppConfigID)
        {
            return this.Find(delegate(AppConfig apc) { return apc.Key == AppConfigID; });
        }
    }
}
