﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class UserSettings
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Key = "Key";
        public static readonly string Property_Value = "Value";

        #endregion

        #region Properties

        public Int64 ID { get; set; }

        public string Key { get; set; }

        public string Value { get; set; }

        #endregion
        
    }

    public class UserSettingsList : List<UserSettings>
    {
        #region constructors

        public UserSettingsList() { }

        #endregion


        /// <summary>
        /// finds UserSettings from list of UserSettings by id of a UserSettings
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserSettings FindByID(Int64 id)
        {
            return this.Find(delegate(UserSettings sts) { return sts.ID == id; });
        }

        /// <summary>
        /// finds UserSettings from list of UserSettings by key of a UserSettings
        /// </summary>
        /// <param name="AppConfigID"></param>
        /// <returns></returns>
        public UserSettings FindByUserSettingsKey(string UserSettingsID)
        {
            return this.Find(delegate(UserSettings sts) { return sts.Key == UserSettingsID; });
        }
    }
}
