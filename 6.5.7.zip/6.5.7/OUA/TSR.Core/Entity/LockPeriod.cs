﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class LockPeriod : UserAgentService.LockPeriod
    {
        #region Constants

        public const string Property_UserID = "UserID";
        public const string Property_LockDate = "LockDate";
        public const string Property_IsLocked = "IsLocked";

        #endregion
    }

    /// <summary>
    /// List of Location
    /// </summary>
    public class LockPeriodList : List<LockPeriod>
    {
        
    }
}
