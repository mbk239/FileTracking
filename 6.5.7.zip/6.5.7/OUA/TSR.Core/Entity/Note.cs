using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Note info of Time Entry, inherits from service proxy generated object from server entity
    /// </summary>
    public class Note : WS.Note
    {
        #region constants

        public const string Property_ID = "ID";
        public const string Property_TimeEntryID = "TimeEntryID";
        public const string Property_Username = "Username";
        public const string Property_FullName = "FullName";
        public const string Property_Subject = "Subject";
        public const string Property_Note = "Note";
        public const string Property_Timestamp = "Timestamp";

        #endregion

        #region Private Variables
        private Guid _TimeEntryID;
        private string _Username;
        //private string _FullName;
        #endregion

        #region Properties
        public Guid TimeEntryID
        {
            get { return _TimeEntryID; }
            set { _TimeEntryID = value; }
        }

        public string Username
        {
            get { return _Username; }
            set { _Username = value; }
        }
                
        #endregion

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(ResourceManager.GetResourceString("Username","Username") + ": " + Username);
            sb.AppendLine(ResourceManager.GetResourceString("FullName", "Full Name") + ": " + FullName);
            sb.AppendLine(ResourceManager.GetResourceString("CommentOn","Comment On") + ": " + Timestamp.ToString());            
            sb.AppendLine(ResourceManager.GetResourceString("Message","Message") + ":");
            sb.Append(Note);

            return sb.ToString();
        }
    }

    public class NoteList : List<Note>
    {
        //public NoteList() : base() { }

        //public NoteList(int capacity) : base(capacity) { }

        //public NoteList(IEnumerable<Note> collection) : base(collection) { }

        //public Note FindByID(Int64 id)
        //{
        //    return this.Find(delegate(Note blg) { return blg.ID == id; });
        //}

        //public NoteList FindByTimeEntryID(Guid timeEntryID)
        //{
        //    List<Note> lst = this.FindAll(delegate(Note blg) { return blg.TimeEntryID == timeEntryID; });

        //    return new NoteList(lst);
        //}

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            if (this.Count > 0)
                sb.AppendLine(this[0].ToString());

            for (int i = 1; i < this.Count; i++)
            {
                sb.AppendLine();
                sb.AppendLine(this[i].ToString());
            }

            return sb.ToString();
        }
    }
}
