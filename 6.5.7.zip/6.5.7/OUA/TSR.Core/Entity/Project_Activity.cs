﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    public class Project_Activity
    {
        public static readonly string Property_ProjectID = "ProjectID";
        public static readonly string Property_ActivityID = "ActivityID";
        public static readonly string Property_Modified = "Modified";

        private string _Reversion;
        private long _ProjectID;
        private long _ActivityID;

        public long ProjectID
        {
            get { return _ProjectID; }
            set { _ProjectID = value; }
        }

        public long ActivityID
        {
            get { return _ActivityID; }
            set { _ActivityID = value; }
        }

        public string Reversion
        {
            get { return _Reversion; }
            set { _Reversion = value; }
        }
    }

    public class Project_ActivityList : List<Project_Activity>
    {
        /// <summary>
        /// finds link Project_Activity by projectID and activityID from this list of Project_Activity
        /// </summary>
        /// <param name="prjID">ProjectID</param>
        /// <param name="actID">ActivityID</param>
        /// <returns></returns>
        public Project_Activity FindByID(Int64 prjID, Int64 actID)
        {
            return this.Find(delegate(Project_Activity pa) { return pa.ProjectID == prjID && pa.ActivityID == actID; });
        }
    }
}
