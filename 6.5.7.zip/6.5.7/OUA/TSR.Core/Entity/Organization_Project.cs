﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class Organization_Project
    {
        public const string Property_OrganizationID = "OrganizationID";
        public const string Property_ProjectID = "ProjectID";

        //private
        private long _OrganizationID;
        private long _ProjectID;

        //properties
        public long OrganizationID
        {
            get { return _OrganizationID; }
            set
            {
                _OrganizationID = value;
            }
        }
        public long ProjectID
        {
            get { return _ProjectID; }
            set
            {
                _ProjectID = value;
            }
        }
    }

    public class Organization_ProjectList : List<Organization_Project>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="prjID"></param>
        /// <returns></returns>
        public Organization_Project FindByID(Int64 orgID, Int64 prjID)
        {
            return this.Find(delegate(Organization_Project op) { return op.OrganizationID==orgID && op.ProjectID == prjID; });
        }
    }
}
