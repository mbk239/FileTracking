﻿using System;
using System.Collections.Generic;
using System.Text;

using Outlook = Microsoft.Office.Interop.Outlook;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    public class TimeEntry_OutlookAppointment:WS.TimeEntry_OutlookAppointment
    {
        #region constants
        public static readonly string Property_ID = "ID";
        public static readonly string Property_OutlookItemID = "OutlookItemID";
        public static readonly string Property_TimeEntryID = "TimeEntryID";
        public static readonly string Property_Revision = "Revision";        
        #endregion        
    }
    public class TimeEntry_OutlookAppointmentList : List<TimeEntry_OutlookAppointment>
    {
    }
}
