using System;
using System.Collections.Generic;
using System.Text;
using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds preferred path info [Favorites], inherits from service proxy generated object from server entity
    /// </summary>
    public class PreferredPaths : WS.PreferredPath
    {

        #region Constant Variables
        
        public static readonly string Property_ID = "ID";
        public static readonly string Property_OrganizationID = "OrganizationID";
        public static readonly string Property_ProjectID = "ProjectID";
        public static readonly string Property_ActivityID = "ActivityID";
        public static readonly string Property_TaskID = "TaskID";
        public static readonly string Property_ContactID = "ContactID";
        public static readonly string Property_OrganizationName = "OrganizationName";
        public static readonly string Property_ProjectName = "ProjectName";
        public static readonly string Property_ActivityName = "ActivityName";
        public static readonly string Property_TaskName = "TaskName";
        public static readonly string Property_ContactName = "ContactName";

        public static readonly string Property_LocationID = "LocationID";
        public static readonly string Property_LocationName = "LocationName";
        #endregion

        #region Private variables
        //private Int64 _ID;
        //private Int64 _OrganizationID;
        //private Int64 _ProjectID;
        //private Int64 _ActivityID;
        //private Int64 _TaskID;
        //private Int64 _ContactID;
        //private bool _isDefault;        
        private Organization _Organization;
        private Project _Project;
        private Activity _Activity;
        private Task _Task;
        private Contact _Contact;

        #endregion

        #region Constructors
        public PreferredPaths()
        {
            OrganizationID = ProjectID = ActivityID = -1;

        }

        public PreferredPaths(Int64 preferredPathID)
            : this()
        {
            ID = preferredPathID;
        }
        #endregion

        #region Properties
        //public Int64 ID
        //{
        //    get { return _ID; }
        //    set { _ID = value; }
        //}

        //public Int64 OrganizationID
        //{
        //    get { return _OrganizationID; }
        //    set { _OrganizationID = value; }
        //}

        //public Int64 ProjectID
        //{
        //    get { return _ProjectID; }
        //    set { _ProjectID = value; }
        //}

        //public Int64 ActivityID
        //{
        //    get { return _ActivityID; }
        //    set { _ActivityID = value; }
        //}

        //public Int64 TaskID
        //{
        //    get { return _TaskID; }
        //    set { _TaskID = value; }
        //}

        //public Int64 ContactID
        //{
        //    get { return _ContactID; }
        //    set { _ContactID = value; }
        //}

        //public bool IsDefault
        //{
        //    get { return _isDefault; }
        //    set { _isDefault = value; }
        //}

        public Organization Organization
        {
            get { return _Organization; }
            set { _Organization = value; }
        }

        public Project Project
        {
            get { return _Project; }
            set { _Project = value; }
        }

        public Activity Activity
        {
            get { return _Activity; }
            set { _Activity = value; }
        }

        public Task Task
        {
            get { return _Task; }
            set { _Task = value; }
        }

        public Contact Contact
        {
            get { return _Contact; }
            set { _Contact = value; }
        }


        public string OrganizationName
        {
            get { return Organization != null ? Organization.Name : ""; }
        }

        public string ProjectName
        {
            get { return Project != null ? Project.Name : ""; }
        }

        public string ActivityName
        {
            get { return Activity != null ? Activity.Name : ""; }
        }

        public string TaskName
        {
            get { return Task != null ? Task.Name : ""; }
        }

        public string ContactName
        {
            get { return Contact != null ? Contact.Name : ""; }
        }


        #endregion


    }

    public class PreferredPathsList : List<PreferredPaths>
    {
        #region Constructors

        public PreferredPathsList()
            : base()
        { }

        public PreferredPathsList(PreferredPathsList ppList)
            : base(ppList)
        { }

        #endregion
        
        /// <summary>
        /// finds preferred path from this list of preferred paths
        /// </summary>
        /// <param name="preferredPathID"></param>
        /// <returns></returns>
        public PreferredPaths FindByID(Int64 preferredPathID)
        {
            return this.Find(delegate(PreferredPaths preferredPath) { return preferredPath.ID == preferredPathID; });
        }

        /// <summary>
        /// finds preferred path from this list of preferred paths
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public List<PreferredPaths> FindByOrganizationID(Int64 organizationID)
        {
            return this.FindAll(delegate(PreferredPaths preferredPath) { return preferredPath.OrganizationID == organizationID; });
        }
    }
}
