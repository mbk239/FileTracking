using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Project info, inherits from service proxy generated object from server entity
    /// </summary>
    public class Project : WS.Project, IComparable<Project>
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_Visible = "Visible";
        public static readonly string Property_Description = "Description";
        public static readonly string Property_ProjectTypeName = "ProjectTypeName";
        public static readonly string Property_Modified = "Modified";

        #region relational table's column names

        public static readonly string Property_ProjectID = "ProjectID";

        #endregion

        private const string ID_INITIALIZER_FOR_OUA_RIBBON_PROJECT = "PRJ_";

        #endregion
        

        #region Private Variables
        private bool _Visible;
        private string _Modified;
        #endregion

        #region Properties
        public String ProjectID
        {
            get { return ID_INITIALIZER_FOR_OUA_RIBBON_PROJECT + ID; }
        }

        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }

        public string Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
        #endregion

        #region IComparable<Project> Members

        public int CompareTo(Project other)
        {
            return Name.CompareTo(other.Name);
        }

        #endregion
    }

    public class ProjectList : List<Project>
    {
        #region constructors

        public ProjectList() { }

        public ProjectList(bool includeDefaultSelectionItem)
            : this()
        {
            InsertSelectionDefaultItem();
        }

        #endregion
        

        /// <summary>
        /// inserts default item in list of projects. useful for showing it in drop down list
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            Project prj = new Project();
            prj.Name = ResourceHelper.ProjectSelectionText;
            prj.ID = Constants.DEFAULT_SELECTION_VALUE_INT;
            prj.Modified = DateTime.Now.ToString(Constants.DEFAULT_FORMAT_TIMESTAMP);

            this.Insert(0, prj);
        }

        /// <summary>
        /// finds project from this list of projects
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Project FindByID(Int64 id)
        {
            return this.Find(delegate(Project prj) { return prj.ID == id; });
        }

        /// <summary>
        /// finds project from this list of projects
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public Project FindByProjectID(string projectID)
        {
            return this.Find(delegate(Project prj) { return prj.ProjectID == projectID; });
        }

        /// <summary>
        /// finds project by name from this list of organzations
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Project FindByName(string name)
        {
            return this.Find(delegate(Project org) { return org.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase); });
        }
    }
}
