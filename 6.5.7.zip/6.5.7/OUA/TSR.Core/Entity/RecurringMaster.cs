﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace TSR.Core.Entity
{
    public class RecurringMaster
    {
        #region Constants 

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Subject = "Subject";
        public static readonly string Property_Body = "Body";
        public static readonly string Property_Location = "Location";
        public static readonly string Property_Start = "Start";
        public static readonly string Property_End = "End";
        public static readonly string Property_OrganizationID = "OrganizationID";
        public static readonly string Property_ProjectID = "ProjectID";
        public static readonly string Property_ActivityID = "ActivityID";
        public static readonly string Property_Revision = "Revision";

        #endregion


        #region Properties

        public String ID { get; set; }

        public string Subject { get; set; }

        public string Body { get; set; }

        public string Location { get; set; }

        public DateTime Start { get; set; }

        public DateTime End { get; set; }

        public Int64 OrganizationID { get; set; }

        public Int64 ProjectID { get; set; }

        public Int64 ActivityID { get; set; }

        [DefaultValue(0)]
        public long Revision
        {
            get;
            set;
        }

        #endregion
    }
}
