using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds contact info of organizations, inherits from service proxy generated object from server entity
    /// </summary>
    public class Contact : WS.Contact, IComparable<Contact>
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_Visible = "Visible";
        public static readonly string Property_Modified = "Modified";

        #region relational table's column names

        public static readonly string Property_ContactID = "ContactID";

        #endregion

        private const string ID_INITIALIZER_FOR_OUA_RIBBON_CONTACT = "CNT_";

        #endregion
        

        #region Private Variables
        private bool _Visible;
        private string _Name;
        private string _Modified;
        #endregion

        #region Properties
        public String ContactID
        {
            get { return ID_INITIALIZER_FOR_OUA_RIBBON_CONTACT + ID; }
        }

        public string Name
        {
            get
            {
                if (string.IsNullOrEmpty(_Name))
                    return Person.FirstName + Constants.SPACE + Person.LastName;
                else
                    return _Name;
            }
            set { _Name = value; }
        }
        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }
        public string Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
        #endregion

        #region IComparable<Contact> Members

        public int CompareTo(Contact other)
        {
            return Name.CompareTo(other.Name);
        }

        #endregion
    }

    /// <summary>
    /// List object to hold multiple Contatcs
    /// </summary>
    public class ContactList : List<Contact>
    {
        public ContactList() { }

        public ContactList(bool includeDefaultSelectionItem)
            : this()
        {
            InsertSelectionDefaultItem();
        }

        /// <summary>
        /// For showing list of entities, a 'Select a Contact' item is added
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            Contact cnt = new Contact();
            cnt.Name = ResourceHelper.ContactSelectionText;
            cnt.ID = Constants.DEFAULT_SELECTION_VALUE_INT;
            cnt.Modified = DateTime.Now.ToString(Constants.DEFAULT_FORMAT_TIMESTAMP);

            this.Insert(0, cnt);
        }

        public Contact FindByID(Int64 id)
        {
            return this.Find(delegate(Contact cnt) { return cnt.ID == id; });
        }

        public Contact FindByActivityID(string contactID)
        {
            return this.Find(delegate(Contact cnt) { return cnt.ContactID == contactID; });
        }
    }
}
