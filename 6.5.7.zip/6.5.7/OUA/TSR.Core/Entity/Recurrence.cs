using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core.Entity
{
    /// <summary>
    /// Holds recurrence object.. this is not inherited from server object, cause recurrence information is not passed 
    /// to server. Holds recurring pattern information
    /// </summary>
    public class Recurrence
    {

        #region private variables
        
        private System.Guid _ID;
        private DateTime _StartDate;
        private int _EndType;
        private DateTime _EndDate;
        private int _OccurrenceBeforeEnd;
        string _Type1;
        int _Type1Value;
        string _Type2;
        int _Type2Value;
        string _Type3;
        int _Type3Value;
        
        #endregion

        #region Constructors

        public const string RECURRENCETYPE_DAY = "day";
        public const string RECURRENCETYPE_DAYNAME = "dayname";
        public const string RECURRENCETYPE_DAYOFMONTH = "dayofmonth";
        public const string RECURRENCETYPE_WEEK = "week";
        public const string RECURRENCETYPE_MONTH = "month";
        public const string RECURRENCETYPE_MONTHNAME = "monthname";
        public const string RECURRENCETYPE_YEAR = "year";

        #endregion

        /// <summary>
        /// unique id
        /// </summary>
        public System.Guid ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        /// <summary>
        /// start date of the recurrence
        /// </summary>
        public DateTime StartDate
        {
            get { return _StartDate; }
            set { _StartDate = value; }
        }

        /// <summary>
        /// end type could be date or number of times, etc
        /// </summary>
        public int EndType
        {
            get { return _EndType; }
            set { _EndType = value; }
        }

        /// <summary>
        /// end date of recurring
        /// </summary>
        public DateTime EndDate
        {
            get { return _EndDate; }
            set { _EndDate = value; }
        }

        /// <summary>
        /// number of occurrences before finished
        /// </summary>
        public int OccurrenceBeforeEnd
        {
            get { return _OccurrenceBeforeEnd; }
            set { _OccurrenceBeforeEnd = value; }
        }

        /// <summary>
        /// pattern info
        /// </summary>
        public string Type1
        {
            get { return _Type1; }
            set { _Type1 = value; }
        }

        /// <summary>
        /// pattern info, could be date, week, year, etc - value of the item
        /// </summary>
        public int Type1Value
        {
            get { return _Type1Value; }
            set { _Type1Value = value; }
        }

        /// <summary>
        /// pattern info, could be date, week, year, etc
        /// </summary>
        public string Type2
        {
            get { return _Type2; }
            set { _Type2 = value; }
        }

        /// <summary>
        /// pattern info, could be date, week, year, etc - value of the item
        /// </summary>
        public int Type2Value
        {
            get { return _Type2Value; }
            set { _Type2Value = value; }
        }

        /// <summary>
        /// pattern info, could be date, week, year, etc
        /// </summary>
        public string Type3
        {
            get { return _Type3; }
            set { _Type3 = value; }
        }

        /// <summary>
        /// pattern info, could be date, week, year, etc - value of the item
        /// </summary>
        public int Type3Value
        {
            get { return _Type3Value; }
            set { _Type3Value = value; }
        }

    }
}
