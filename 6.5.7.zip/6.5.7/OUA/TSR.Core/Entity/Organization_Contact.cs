﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    public class Organization_Contact
    {
        //Properties name
        public static readonly string Property_OrganizationID = "OrganizationID";
        public static readonly string Property_ContactID = "ContactID";
        public static readonly string Property_Modified = "Modified";

        //private fields
        private long _OrganizationID;
        private long _ContactID;
        private string _Modified;

        //properties
        public long OrganizationID
        {
            get { return _OrganizationID; }
            set { _OrganizationID = value; }
        }

        public long ContactID
        {
            get { return _ContactID; }
            set { _ContactID = value; }
        }

        public string Reversion
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
    }
    public class Organization_ContactList : List<Organization_Contact>
    {
        /// <summary>
        /// Get organization-contact by orgID and cntID
        /// </summary>
        /// <param name="orgID">OrganizationID</param>
        /// <param name="cntID">ContactID</param>
        /// <returns></returns>
        public Organization_Contact FindByID(Int64 orgID, Int64 cntID)
        {
            return this.Find(delegate(Organization_Contact oc) { return oc.OrganizationID == orgID && oc.ContactID == cntID; });
        }
    }
}
