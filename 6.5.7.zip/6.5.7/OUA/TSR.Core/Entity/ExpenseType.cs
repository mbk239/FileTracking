using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// Activity class to hold activity information. Inherited from service activity proxy object, so will also hold
    /// information passed from server
    /// </summary>
    public class ExpenseType : WS.ExpenseType
    {
        private bool _Visible;

        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }
    }

    /// <summary>
    /// List of activities
    /// </summary>
    public class ExpenseTypeList : List<ExpenseType>
    {
    }
}
