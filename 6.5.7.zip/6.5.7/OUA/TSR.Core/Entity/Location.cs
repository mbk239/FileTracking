﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core.Entity
{
    public class Location : UserAgentService.Location
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_IsActivate = "IsActivate";
        public static readonly string Property_Description = "Description";

        #endregion
        private string _Modified;

        public string Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
    }

    /// <summary>
    /// List of Location
    /// </summary>
    public class LocationList : List<Location>
    {
        /// <summary>
        /// inserts selection item in task list
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            var location = new Location();
            location.Name = ResourceHelper.SelectALocation;
            location.ID = Constants.DEFAULT_SELECTION_VALUE_INT;

            this.Insert(0, location);
        }

        /// <summary>
        /// find a Location by id [Location id]
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Location FindByID(Int64 id)
        {
            return this.Find(delegate(Location tsk) { return tsk.ID == id; });
        }
    }
}
