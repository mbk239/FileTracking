using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// Activity class to hold activity information. Inherited from service activity proxy object, so will also hold
    /// information passed from server
    /// </summary>
    public class Activity : WS.Activity,IComparable<Activity>
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_Visible = "Visible";
        public static readonly string Property_ActivityTypeName = "ActivityTypeName";
        public static readonly string Property_Description = "Description";
        public static readonly string Property_Modified = "Modified";
        public static readonly string Property_IsActivate = "IsActivate";

        #region relational table's column names

        public static readonly string Property_ActivityID = "ActivityID";

        #endregion

        private const string ID_INITIALIZER_FOR_OUA_RIBBON_ACTIVITY = "ACT_";

        #endregion

        #region Private Variables
        private bool _Visible;
        private string _Modified;
        #endregion

        #region Properties
        public String ActivityID
        {
            get { return ID_INITIALIZER_FOR_OUA_RIBBON_ACTIVITY + ID; }
        }

        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }
        public string Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
        #endregion

        #region IComparable<Activity> Members

        public int CompareTo(Activity other)
        {
            return Name.CompareTo(other.Name);
        }

        #endregion
    }

    /// <summary>
    /// List of activities
    /// </summary>
    public class ActivityList : List<Activity>
    {
        #region constructors
        
        public ActivityList() { }

        public ActivityList(bool includeDefaultSelectionItem)
            : this()
        {
            InsertSelectionDefaultItem();
        }

        #endregion
        
        /// <summary>
        /// inserts default item in list of activities
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            Activity act = new Activity();
            act.Name = ResourceHelper.ActivitySelectionText;
            act.ID = Constants.DEFAULT_SELECTION_VALUE_INT;
            act.Modified = DateTime.Now.ToString(Constants.DEFAULT_FORMAT_TIMESTAMP);

            this.Insert(0, act);
        }

        /// <summary>
        /// finds activity from list of activities by id of an activity
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Activity FindByID(Int64 id)
        {
            return this.Find(delegate(Activity act) { return act.ID == id; });
        }

        /// <summary>
        /// finds activity from list of activities by id of an activity
        /// </summary>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public Activity FindByActivityID(string activityID)
        {
            return this.Find(delegate(Activity act) { return act.ActivityID == activityID; });
        }

        /// <summary>
        /// finds activity by name from this list of organzations
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Activity FindByName(string name)
        {
            return this.Find(delegate(Activity org) { return org.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase); });
        }
    }
}
