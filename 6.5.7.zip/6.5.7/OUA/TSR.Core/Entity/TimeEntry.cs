using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using Outlook = Microsoft.Office.Interop.Outlook;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Time Entry object, inherits from service proxy generated object from server entity
    /// </summary>
    public class TimeEntry : WS.TimeEntry
    {
        #region constants

        public static readonly string Property_ID = "ID";
        //public static readonly string COL_OUTLOOKITEMID = "OutlookItemID";
        public static readonly string Property_Subject = "Subject";
        public static readonly string Property_Body = "Body";
        public static readonly string Property_StartTime = "StartTime";
        public static readonly string Property_EndTime = "EndTime";
        public static readonly string Property_TimeZone = "TimeZone";
        public static readonly string Property_OrganizationID = "OrganizationID";
        public static readonly string Property_ProjectID = "ProjectID";
        public static readonly string Property_ActivityID = "ActivityID";
        public static readonly string Property_TaskID = "TaskID";
        public static readonly string Property_ContactID = "ContactID";
        public static readonly string Property_Message = "Message";
        public static readonly string Property_OrganizationName = "OrganizationName";
        public static readonly string Property_ProjectName = "ProjectName";
        public static readonly string Property_ActivityName = "ActivityName";
        public static readonly string Property_TaskName = "TaskName";
        public static readonly string Property_ContactName = "ContactName";
        public static readonly string Property_Status = "Status";
        public static readonly string Property_IsRecurring = "IsRecurring";
        public static readonly string Property_IsDeleted = "IsDeleted";
        public static readonly string Property_Location = "Location";
        public static readonly string Property_Revision = "Revision";
        public static readonly string Property_SubmitterName = "SubmitterName";
        public static readonly string Property_IsDeletedOnServer = "IsDeletedOnServer";
        public static readonly string Property_IsOutOfOffice = "IsOutOfOffice";
        public static readonly string Property_LocationID = "LocationID";
        public static readonly string Property_IsCreatedViaWeb = "IsCreatedViaWeb";

        #region relational table's column names

        public static readonly string Property_TimeEntryID = "TimeEntryID";
        public static readonly string Property_OutlookItemID = "OutlookItemID";
        public static readonly string Property_CalendarID = "CalendarID";
        #endregion

        #endregion

        #region priavte variables

        private String _OutlookItemID;
        private String _TimeZone;
        private String _Message;
        private System.Guid? _RecurrenceID = null;
        private string _Star;
        private string _End;
        private Outlook.AppointmentItem _OLAppointmentItem;
        private Organization _Organization;
        private Project _Project;
        private Activity _Activity;
        private Task _Task;
        private Contact _Contact;
        private DateTime _LastModificationTime;
        //Added by tsrdev1
        //Added datetime: 06/10/2010
        private string _SubmitterName;
        //Added by tsrdev1
        //Added datetime: 05/10/2010
        private Int64? _Revision;
        //private NoteList _NoteList;        
        
        //added by tsrdev2
        private Boolean? _IsDeletedOnServer;
        private ExpenseSheet _ExpenseSheet;
        private Location _Location;
        #endregion

        #region Properties        
        /// <summary>
        /// outlook entry id, which is associated with the TSR entry
        /// </summary>
        public string OutlookItemID
        {
            get
            {
                if (String.IsNullOrEmpty(_OutlookItemID))
                {
                    if (_OLAppointmentItem != null)
                        _OutlookItemID = _OLAppointmentItem.EntryID;

                    if (String.IsNullOrEmpty(_OutlookItemID))
                        Core.Logging.LoggingHandler.LogError(new Core.Exceptions.OutlookAppointmentInvalidReference());
                    //    throw new Core.Exceptions.OutlookAppointmentInvalidReference();
                }

                return _OutlookItemID;
            }            
        }

        public string CalendarID
        {
            get;
            set;           
        }
        public void SetAppointmentIDForNonExistingAppointment()
        {
            _OutlookItemID = Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID;
        }

        //Added by tsrdev1
        //Added datetime 26/10/2010
        public StatusLinkWithAppointment GetStatusLinkWithAppointment()
        {
            if (this.OLAppointmentItem != null)
                return StatusLinkWithAppointment.Normal;
            else
            {
                if (string.IsNullOrEmpty(this._OutlookItemID) || this._OutlookItemID == Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID)
                    return StatusLinkWithAppointment.NoLink;
                else
                    return StatusLinkWithAppointment.HasLinkButAppointmentIsNull;
            }
        }

        [DefaultValue(false)]
        public bool IsCreatedAppointment
        {
            get;
            set;
        }

        [DefaultValue(false)]
        public bool IsChangedAppointment
        {
            get;
            set;
        }
        /// <summary>
        /// outlook appointment associated with TSR Entry
        /// </summary>
        public Outlook.AppointmentItem OLAppointmentItem
        {
            get
            {                
                if (_OLAppointmentItem == null)
                {
                    if (!String.IsNullOrEmpty(_OutlookItemID) && (_OutlookItemID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID)) //Retrieves outlook appointment object from outlook entry id                    
                    {
                        try
                        {
                            //_OLAppointmentItem = OutlookHelper.GetAppointmentItemByEntryID(_OutlookItemID);
                            _OLAppointmentItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(_OutlookItemID);                            

                        }
                        catch //(System.Runtime.InteropServices.COMException ex)
                        {
                            //Logging.LoggingHandler.LogUnhandledException(ex);
                            _OLAppointmentItem = null;
                            //System.Diagnostics.Debug.WriteLine(ex.Message);
                        }
                        /////Catch Added for Handling Automatic Synchronization before Closing Outlook
                        //catch (Exception exp)
                        //{
                        //    //Logging.LoggingHandler.LogUnhandledException(exp);
                        //    _OLAppointmentItem = null;
                        //    //System.Diagnostics.Debug.WriteLine(exp.Message);
                        //}
                    }                   
                }
                if (_OLAppointmentItem != null && _OLAppointmentItem.IsRecurring && _OLAppointmentItem.RecurrenceState == Outlook.OlRecurrenceState.olApptMaster)
                {
                    //Microsoft.Office.Interop.Outlook.AppointmentItem tmpItem = null;
                    //if (!String.IsNullOrEmpty(_OutlookItemID) && (_OutlookItemID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID)) //Retrieves outlook appointment object from outlook entry id
                    //{
                    //    try
                    //    {
                    //        //_OLAppointmentItem = OutlookHelper.GetAppointmentItemByEntryID(_OutlookItemID);
                    //        tmpItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(_OutlookItemID);                            

                    //    }
                    //    catch (System.Runtime.InteropServices.COMException ex)
                    //    {
                    //        //Logging.LoggingHandler.LogUnhandledException(ex);
                    //        tmpItem = null;
                    //        //System.Diagnostics.Debug.WriteLine(ex.Message);
                    //    }
                    //    ///Catch Added for Handling Automatic Synchronization before Closing Outlook
                    //    catch (Exception exp)
                    //    {
                    //        //Logging.LoggingHandler.LogUnhandledException(exp);
                    //        tmpItem = null;
                    //        //System.Diagnostics.Debug.WriteLine(exp.Message);
                    //    }
                    //}
                    //else
                    //    tmpItem = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(_OLAppointmentItem.EntryID);

                    DateTime start;
                    if (StartTimeStamp.Equals(DateTime.MinValue))
                        start = _OLAppointmentItem.Start;
                    else
                        start = this.StartTimeStamp;

                    //if (tmpItem != null && tmpItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    //{
                        try
                        {
                            Microsoft.Office.Interop.Outlook.RecurrencePattern pattern = null;
                            pattern = _OLAppointmentItem.GetRecurrencePattern();
                            if (pattern != null)
                            {
                                Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence;
                                try
                                {
                                    appointmentOccurrence = pattern.GetOccurrence(start);
                                }
                                catch
                                {
                                    appointmentOccurrence = null;
                                }
                                if (appointmentOccurrence != null)
                                    return appointmentOccurrence;
                                if (pattern.Exceptions != null)
                                {
                                    foreach (Microsoft.Office.Interop.Outlook.Exception exceptionRecurr in pattern.Exceptions)
                                    {
                                        try
                                        {
                                            if (exceptionRecurr.AppointmentItem.Start.Date.Equals(start.Date))
                                            {
                                                return exceptionRecurr.AppointmentItem;
                                            }
                                        }
                                        catch //(System.Exception ex)
                                        {
                                            //TSR.Core.Logging.LoggingHandler.LogError(ex);
                                        }
                                    }
                                }
                            }
                        }
                        catch //(System.Exception ex)
                        {                         
                            //TSR.Core.Logging.LoggingHandler.LogError(ex);
                        }
                        return null;
                    //}
                    //else
                    //    _OLAppointmentItem = null;
                }

                return _OLAppointmentItem;
            }
            set
            {
                _OLAppointmentItem = value;
                _OutlookItemID = _OLAppointmentItem.EntryID;
            }
        }

        /// <summary>
        /// recurrence id associated with TSR Entry
        /// </summary>
        public System.Guid? RecurrenceID
        {
            get
            {
                return _RecurrenceID;
            }
            set
            {
                if (value.HasValue)
                    _RecurrenceID = value.Value;
            }
        }

        public DateTime LastModificationTime
        {
            get
            {
                return _LastModificationTime;
            }
            set
            {                
                _LastModificationTime = value;
            }
        }

        //Added by tsrdev1
        //Added datetime 05/10/2010
        /// <summary>
        /// The last time that time entry is modified on TSR Server
        /// </summary>
        public Int64? Revision
        {
            get
            {
                return _Revision;
            }
            set
            {
                if (value.HasValue)
                    _Revision = value.Value;
            }
        }

        //Added by tsrdev1
        //Added datetime 05/10/2010
        /// <summary>
        /// Submitted user name
        /// </summary>
        public string SubmitterName
        {
            get
            {
                if (!string.IsNullOrEmpty(_SubmitterName))
                    return _SubmitterName;
                else
                {
                    if (this.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                    {
                        return string.Empty;
                    }                    
                    //return Core.MiscHelper.GetCurrentUsername();

                    DAL.UserSettingsDAL dal = new DAL.UserSettingsDAL();
                    UserSettings userSettings = dal.GetUserSettingsByKey(Constants.CONST_USERNAME_KEY);
                    if (userSettings != null)
                        return userSettings.Value;
                    return string.Empty;
                }
            }
            set
            {
                _SubmitterName = value;
            }
        }

        public string Star
        {
            get 
            {
                _Star=StartTimeStamp.ToLongDateString();
                return _Star;
            }
            set 
            {
                _Star = StartTimeStamp.ToLongDateString();
                _Star = value;
            }
        }
        public string End
        {
            get {
                End = EndTimeStamp.ToLongDateString();
                return _End; }
            set { _End = value; }
        }
        public bool IsDeleted { get; set; }//added by tsrdev2

        public bool IsOutOfOffice { get; set; }

        /// <summary>
        /// this time entry has been deleted on server
        /// </summary>
        public Boolean? IsDeletedOnServer {
            get
            {
                if (_IsDeletedOnServer == null)
                {
                    _IsDeletedOnServer = false;
                }
                return _IsDeletedOnServer;
            }
            set
            {
                if (value.HasValue)
                {
                    _IsDeletedOnServer = value.Value;
                }
            }
        }

        public ExpenseSheet ExpenseSheet
        {
            get { return _ExpenseSheet; }
            set { _ExpenseSheet = value; }
        }

        /// <summary>
        /// time zone
        /// </summary>
        public string TimeZone
        {
            get { return _TimeZone; }
            set { _TimeZone = value; }
        }

        /// <summary>
        /// single message [note in server].. this is the message user entered but not synchronized yet
        /// </summary>
        public String Message
        {
            get { return _Message; }
            set { _Message = value; }
        }

        /// <summary>
        /// organization object associated with TSR Entry
        /// </summary>
        public Organization Organization
        {
            get { return _Organization; }
            set { _Organization = value; }
        }

        /// <summary>
        /// Project object associated with TSR Entry
        /// </summary>
        public Project Project
        {
            get { return _Project; }
            set { _Project = value; }
        }

        /// <summary>
        /// Activity object associated with TSR Entry
        /// </summary>
        public Activity Activity
        {
            get { return _Activity; }
            set { _Activity = value; }
        }

        /// <summary>
        /// Task object asscoaited with TSR Entry
        /// </summary>
        public Task Task
        {
            get { return _Task; }
            set { _Task = value; }
        }

        /// <summary>
        /// Contact object associated with TSR entry
        /// </summary>
        public Contact Contact
        {
            get { return _Contact; }
            set { _Contact = value; }
        }

        //public NoteList NoteList
        //{
        //    get { return _NoteList; }
        //    set { _NoteList = value; }
        //}

        /// <summary>
        /// organization name
        /// </summary>
        public string OrganizationName
        {
            get
            {
                if (Organization == null)
                    return string.Empty;
                return Organization.Name;
            }
        }


        public string ProjectName
        {
            get
            {
                if (Project == null)
                    return string.Empty;
                return Project.Name;
            }
        }

        public string ActivityName
        {
            get
            {
                if (Activity == null)
                    return string.Empty;
                return Activity.Name;
            }
        }

        public string TaskName
        {
            get
            {
                if (Task == null)
                    return string.Empty;
                return Task.Name;
            }
        }

        public string ContactName
        {
            get
            {
                if (Contact == null)
                    return string.Empty;
                return Contact.Name;
            }
        }

        public Location Locaition
        {
            get { return _Location; }
            set { _Location = value; }
        }
        #endregion

        #region Constructors

        /// <summary>
        /// no param constructor, initializes some necessary items
        /// </summary>
        private TimeEntry()
        {
            _OutlookItemID = null;
            _OLAppointmentItem = null;
            OrganizationID = ProjectID = ActivityID = -1;
            TaskID = ContactID = null;
            _TimeZone = String.Empty;
            Status = WS.StatusEnum.PendingSubmission;
        }

        /// <summary>
        /// initializes with tsrItem id as extra
        /// CONSTRUCTOR MADE PUBLIC on 11 sept 6:11 bdt by Mashrur - reason: when we retrieve a updated time entry from
        /// server during synchronization - and find out that this entry is not in local storage - we
        /// have to recreate the time entry.. and this time we dont know the appointment id - thats when we need this constructor
        /// this might be handled differently near future, but for now - I am doing this..
        /// </summary>
        /// <param name="tsrItemID"></param>
        public TimeEntry(Guid tsrItemID)
            : this()
        {
            ID = tsrItemID;
        }

        /// <summary>
        /// initializes with TSR Item Id and Outlook Appointment object
        /// </summary>
        /// <param name="tsrItemID"></param>
        /// <param name="olAppointmentItem"></param>
        public TimeEntry(Guid tsrItemID, Outlook.AppointmentItem olAppointmentItem)
            : this(tsrItemID)
        {
            if (olAppointmentItem == null)
                throw new Core.Exceptions.OutlookAppointmentInvalidReference();

            _OLAppointmentItem = olAppointmentItem;
        }

        /// <summary>
        /// initializes with TSR Item ID and Outlook Entry Id [known as OutlookItemID in this class]
        /// </summary>
        /// <param name="tsrItemID"></param>
        /// <param name="outlookItemID"></param>
        public TimeEntry(Guid tsrItemID, string outlookItemID)
            : this(tsrItemID)
        {
            if (String.IsNullOrEmpty(outlookItemID))
                throw new Core.Exceptions.OutlookAppointmentInvalidReference();

            _OutlookItemID = outlookItemID;
        }

        //Added by tsrdev1
        //Added datetime 29/10/2010
        /// <summary>
        /// initializes with TSR Item ID and Outlook Entry Id [known as OutlookItemID in this class] and calendar id
        /// </summary>
        /// <param name="tsrItemID"></param>
        /// <param name="outlookItemID"></param>
        /// <param name="calendarId"></param>
        public TimeEntry(Guid tsrItemID, string outlookItemID,string calendarID)
            : this(tsrItemID)
        {
            if (String.IsNullOrEmpty(outlookItemID))
                _OutlookItemID = Core.Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID;
            else
                _OutlookItemID = outlookItemID;

            CalendarID = calendarID;
        }

        #endregion

        /// <summary>
        /// checks some status, if the status is in any of the thrree statuses
        /// change is allowed. Target is, if the entry is in server in an active manner, it is not changeable.
        /// If the item is rejected, it means though it has been in server, it can be resubmitted again, so
        /// change should be allowed
        /// </summary>
        /// <returns></returns>
        public bool IsChangeAllowed()
        {
            if (((Status == UserAgentService.StatusEnum.PendingSubmission) ||
                //(Status == UserAgentService.StatusEnum.InSubmissionQueue) ||
                    (Status == UserAgentService.StatusEnum.Rejected)))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// checks some status, if the status is in any of the thrree statuses
        /// change is allowed. Target is, if the entry is in server in an active manner, it is not changeable.
        /// If the item is rejected, it means though it has been in server, it can be resubmitted again, so
        /// change should be allowed
        /// </summary>
        /// <returns></returns>
        public bool IsChangeAllowedView()
        {
            if (((Status == UserAgentService.StatusEnum.PendingSubmission) ||
               (Status == UserAgentService.StatusEnum.InSubmissionQueue) ||
                    (Status == UserAgentService.StatusEnum.Rejected)))
            {
                return true;
            }
            return false;
        }

        //Added by tsrdev1
        //Added datetime 25/10/2010
        public void SetOutlookItem(string outlookItemID)
        {
            _OutlookItemID = outlookItemID;
        }
    }

    /// <summary>
    /// list object of time entry obje`cts
    /// </summary>
    public class TimeEntryList : List<TimeEntry>
    {
        public TimeEntryList() : base() { }
        public TimeEntryList(List<TimeEntry> list) : base(list) { }
        Queue<TimeEntry> queueTimeEntry = new Queue<TimeEntry>();
        
        public TimeEntry PopTimeEntry()
        {
            lock (this)
            {
                return queueTimeEntry.Dequeue();
            }
        }

        public TimeEntryList PopAllTimeEntry()
        {
            lock (this)
            {
                //return all time entry element in queue
                TimeEntryList list = new TimeEntryList();

                if (queueTimeEntry != null)
                {
                    while (QueueHasData())
                    {
                        //dequeue each element
                        list.Add(queueTimeEntry.Dequeue());
                    }
                }
                //Logging.LoggingHandler.LogInfo(
                //  new Logging.Log()
                //  {
                //      MessageSummary = "Count pop: " + list.Count.ToString() + "--Queue Size: " + queueTimeEntry.Count.ToString(),
                //      MessageDetail = string.Empty,
                //      UserID = 1,
                //      CreatedTimeStamp = DateTime.Now,
                //      CreatorID = 1,
                //      LoggingTime = DateTime.Now,
                //      Priority = 1
                //  });                
                return list;
            }
        }
     
        public void PushTimeEntry(TimeEntry timeEntry)
        {
            lock (this)
            {
                queueTimeEntry.Enqueue(timeEntry);
            }            
        }

        public void PushTimeEntry(List<TimeEntry> listTimeEntry)
        {
            lock (this)
            {
                if (listTimeEntry != null && listTimeEntry.Count > 0)
                {
                    foreach (TimeEntry te in listTimeEntry)
                        queueTimeEntry.Enqueue(te);
                }
                //Logging.LoggingHandler.LogInfo(
                //    new Logging.Log()
                //    {
                //        MessageSummary = "Count push: " + listTimeEntry.Count.ToString()+"--Queue Size: "+queueTimeEntry.Count.ToString(),                        
                //        MessageDetail = string.Empty,                        
                //        UserID = 1,
                //        CreatedTimeStamp = DateTime.Now,
                //        CreatorID = 1,
                //        LoggingTime = DateTime.Now,                        
                //        Priority = 1
                //    });
            }
                   
        }

        public bool QueueHasData()
        {
            lock (this)
            {
                if (queueTimeEntry.Count != 0)
                    return true;
                else return false;
            }
        }

        /// <summary>
        /// find TSR Entry by TSR Item ID
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public TimeEntry FindByID(Guid timeEntryID)
        {
            return this.Find(delegate(TimeEntry timeEntry) { return timeEntry.ID == timeEntryID; });
        }

        /// <summary>
        /// find TSR Entry by outlook item id [outlook entry id]
        /// </summary>
        /// <param name="olItemID"></param>
        /// <returns></returns>
        public TimeEntry FindByOLItemID(string olItemID)
        {
            return this.Find(delegate(TimeEntry timeEntry) { return timeEntry.OutlookItemID == olItemID; });
        }
    }

    //Added by tsrdev1
    //Added datetime 26/10/2010
    public enum StatusLinkWithAppointment
    {
        Normal = 0,
        NoLink = 1,
        HasLinkButAppointmentIsNull = 2
    }

}
