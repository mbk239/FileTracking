using System;
using System.Collections.Generic;
using System.Text;

using WS = TSR.Core.UserAgentService;

namespace TSR.Core.Entity
{
    /// <summary>
    /// holds Organization object, inherits from service proxy generated object from server entity
    /// </summary>
    public class Organization : WS.Organization, IComparable<Organization>
    {
        #region Constants

        public static readonly string Property_ID = "ID";
        public static readonly string Property_Name = "Name";
        public static readonly string Property_Visible = "Visible";
        public static readonly string Property_Description = "Description";
        public static readonly string Property_Modified = "Modified";

        #region relational table's column names

        public static readonly string Property_OrganizationID = "OrganizationID";

        #endregion

        private const string ID_INITIALIZER_FOR_OUA_RIBBON_ORGANIZATION = "ORG_";

        #endregion
        

        #region Private Variables
        private bool _Visible;
        private string _Modified;
        #endregion

        #region Properties
        public String OrganizationID
        {
            get { return ID_INITIALIZER_FOR_OUA_RIBBON_ORGANIZATION + ID; }
        }

        public bool Visible
        {
            get { return _Visible; }
            set { _Visible = value; }
        }
        public string Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
        #endregion

        #region IComparable<Organization> Members

        public int CompareTo(Organization other)
        {
            return Name.CompareTo(other.Name);
        }

        #endregion
    }

    public class OrganizationList : List<Organization>
    {
        #region Constructor

        public OrganizationList() { }

        public OrganizationList(bool includeDefaultSelectionItem)
            : this()
        {
            InsertSelectionDefaultItem();
        }

        #endregion
        
        /// <summary>
        /// inserts selection item in list of organization
        /// </summary>
        public void InsertSelectionDefaultItem()
        {
            Organization org = new Organization();
            org.Name = ResourceHelper.OrganizationSelectionText;
            org.ID = Constants.DEFAULT_SELECTION_VALUE_INT;
            org.Modified = DateTime.Now.ToString(Constants.DEFAULT_FORMAT_TIMESTAMP);

            this.Insert(0, org);
        }

        /// <summary>
        /// finds organization by id from this list of organzations
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Organization FindByID(Int64 id)
        {
            return this.Find(delegate(Organization org) { return org.ID == id; });
        }

        /// <summary>
        /// finds organization by id from this list of organzations
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public Organization FindByOrganizationID(string organizationID)
        {
            return this.Find(delegate(Organization org) { return org.OrganizationID == organizationID; });
        }

        /// <summary>
        /// finds organization by name from this list of organzations
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public Organization FindByName(string name)
        {
            return this.Find(delegate(Organization org) { return org.Name.Equals(name, StringComparison.CurrentCultureIgnoreCase); });
        }
    }
}
