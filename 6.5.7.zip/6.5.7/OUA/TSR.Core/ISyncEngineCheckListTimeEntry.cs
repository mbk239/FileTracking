﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.Core
{
    

    public enum TimeEntryQuestionsStatus
    { 
        Yes,
        No,
        Cancel
    }

    public class TimeEntryQuestions
    {
        public Guid TimeEntryID
        { get; set; }

        public TimeEntryQuestionsStatus QuestionsStatus
        {
            get;
            set;
        }
    }

    public interface ISyncEngineCheckListTimeEntry
    {
        TSR.Core.ListTimeEntryQuestions ShowCheckListTimeEntry(TSR.Core.Entity.TimeEntryList timeEntryList);        
    }

    //Added by tsrdev1
    //Added datetime 21/10/2010
    public interface ISyncEngineOverwriteTimeEntry
    {
        TSR.Core.Entity.TimeEntryList ShowOverwriteTimeEntries(TSR.Core.Entity.TimeEntryList listSource);
    }

    public class ListTimeEntryQuestions : List<TimeEntryQuestions>
    {
        public TimeEntryQuestions FindByID(Guid timeEntryID)
        {
            return this.Find(delegate(TimeEntryQuestions timeEntryQuestions) { return timeEntryQuestions.TimeEntryID == timeEntryID; });
        }
    }
}
