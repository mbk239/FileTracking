using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using WS = TSR.Core.UserAgentService;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// data access class for ExpenseSheet, local storage
    /// </summary>
    internal class ExpenseDAL : BaseDAL
    {
        #region ExpenseSheet

        private DataRow GetExpenseSheetRowByID(long id, bool includeDeleted)
        {
            if (MyDataSet.ExpenseSheet.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                                             where dr[ExpenseSheet.Property_ID].ToString() == id.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                             where dr[ExpenseSheet.Property_ID].ToString() == id.ToString() && dr[ExpenseSheet.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows[0] : null);
        }

        private DataRow GetExpenseSheetRowByTimeEntryID(Guid timeID, bool includeDeleted)
        {
            if (MyDataSet.ExpenseSheet.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                                             where dr[ExpenseSheet.Property_TimeEntryID].ToString() == timeID.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                             where dr[ExpenseSheet.Property_TimeEntryID].ToString() == timeID.ToString() && dr[ExpenseSheet.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows[0] : null);
        }

        private DataRow[] GetAllExpenseSheetRows()
        {
            var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                         where dr[ExpenseSheet.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return rows;
        }

        private DataRow[] GetAllExpenseSheetRows(bool includeDeleted)
        {
            DataRow[] rows = new DataRow[] { };
            if (includeDeleted)
            {
                var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                             select dr;
                rows = dtrows.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                             where (dr[ExpenseSheet.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS)
                             select dr;
                rows = dtrows.ToArray();
            }

            return rows;
        }

        //public ExpenseSheet GetExpenseSheetByID(long id, bool fillExpenseEntries, bool includeDeleted)
        //{
        //    DataRow row = GetExpenseSheetRowByID(id, includeDeleted);
        //    if (row != null)
        //    {
        //        return FillExpenseSheet(row, fillExpenseEntries);
        //    }

        //    return null;
        //}

        public ExpenseSheet GetExpenseSheetByTimeEntryID(Guid timeID, bool fillExpenseEntries, bool includeDeleted)
        {
            DataRow row = GetExpenseSheetRowByTimeEntryID(timeID, includeDeleted);
            if (row != null)
            {
                return FillExpenseSheet(row, fillExpenseEntries);
            }
            return null;
        }

        public ExpenseSheetList GetAllExpenseSheets(bool fillExpenseEntries, bool includeDeleted)
        {
            DataRow[] rows = GetAllExpenseSheetRows(includeDeleted);
            return FillExpenseSheets(rows, fillExpenseEntries);
        }

        public bool UpdateExpenseSheet(ExpenseSheet obj, bool includeExpenseEntry)
        {
            bool success = false;
            success = UpdateExpenseSheet(obj);

            if (success && includeExpenseEntry)
            {
                ExpenseSheet sheet = null;
                     
                //if (obj.ID < 1)
                {
                    sheet = GetExpenseSheetByTimeEntryID(obj.TimeEntryID, false, false);
                }
               
                if (obj.ExpenseEntryListLocal != null && (sheet != null || obj.IsDeleted == true))
                {
                    if (sheet != null)
                    {
                        foreach (ExpenseEntry exp in obj.ExpenseEntryListLocal)
                        {
                            exp.ExpenseSheetID = sheet.ID;
                            exp.TimeEntryID = sheet.TimeEntryID;
                        }
                    }

                    success = UpdateExpenseEntries(obj.ExpenseEntryListLocal);
                }
            }
            return success;
        }

        public bool UpdateExpenseSheetFromServer(ExpenseSheet obj, bool includeExpenseEntry)
        {
            bool success = false;
            success = UpdateExpenseSheet(obj);
            if (success && obj.IsDeleted == true)
            {
                ExpenseEntryList deletedEntries = GetExpenseEntriesByTimeEntryID(obj.TimeEntryID,false);
                foreach (var del in deletedEntries)
                {
                    del.IsDeleted = true;
                    del.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                    UpdateExpenseEntry(del);
                }

                obj.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                success = UpdateExpenseSheet(obj);
                return success;
            }

            if (success && includeExpenseEntry)
            {
                ExpenseSheet sheet = null;
                ExpenseEntryList lstEntriesCurrent = new ExpenseEntryList();

                //if (obj.ID < 1)
                {
                    sheet = GetExpenseSheetByTimeEntryID(obj.TimeEntryID, true, false);
                }

                //remove all entries before update from server.
                if (sheet != null && sheet.ExpenseEntryListLocal != null && sheet.ExpenseEntryListLocal.Count > 0)
                {
                    foreach (var clientEntries in sheet.ExpenseEntryListLocal)
                    {
                        clientEntries.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                        UpdateExpenseEntry(clientEntries);
                    }
                }

                if (obj.ExpenseEntryListLocal != null && sheet != null)
                {
                    foreach (ExpenseEntry exp in obj.ExpenseEntryListLocal)
                    {
                        exp.ExpenseSheetID = sheet.ID;
                        exp.TimeEntryID = sheet.TimeEntryID;
                    }
                    success = UpdateExpenseEntriesFromServer(obj.ExpenseEntryListLocal);
                }

                //if (obj.ID < 1)
                {
                    sheet = GetExpenseSheetByTimeEntryID(obj.TimeEntryID, true, false);
                }
                if (sheet != null)
                {
                    lstEntriesCurrent = sheet.ExpenseEntryListLocal;
                    if (lstEntriesCurrent != null && lstEntriesCurrent.Count > 0)
                    {
                        foreach (ExpenseEntry delExp in lstEntriesCurrent)
                        {
                            if (delExp.IDServer < 1)
                            {
                                delExp.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                                UpdateExpenseEntry(delExp);
                            }
                        }
                    }
                }

            }
            return success;
        }

        public bool UpdateExpenseSheet(ExpenseSheet obj)
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.ExpenseSheet.Rows.Count > 0)
            {
                var dtrows = from dr in MyDataSet.ExpenseSheet.AsEnumerable()
                             where dr[ExpenseSheet.Property_TimeEntryID].ToString().ToLower() == obj.TimeEntryID.ToString().ToLower()
                             //&& dr[ExpenseSheet.Property_IsDeleted].ToString().ToLower() == obj.IsDeleted.ToString().ToLower()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.ExpenseSheetRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ExpenseSheetRow;
            else
                row = MyDataSet.ExpenseSheet.NewExpenseSheetRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                //row.ID = obj.ID;
                row.Status = Convert.ToInt32(obj.Status);
                row.TimeEntryID = obj.TimeEntryID;
                row.IsDeleted = obj.IsDeleted;
                row.Revision = obj.Revision.HasValue ? obj.Revision.Value : 0;
                if (rows.Length <= 0)
                    MyDataSet.ExpenseSheet.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                {
                    MyDataSet.ExpenseSheet.Rows.Remove(row);
                }
            }

            return true;
        }

        public bool UpdateExpenseSheets(ExpenseSheetList lst, bool includeExpenseEntry)
        {
            if (lst != null && lst.Count > 0)
            {
                foreach (ExpenseSheet sheet in lst)
                {
                    UpdateExpenseSheet(sheet, includeExpenseEntry);
                }
            }
            return true;
        }

        public bool UpdateExpenseSheetsFromServer(ExpenseSheetList lst, bool includeExpenseEntry)
        {
            if (lst != null && lst.Count > 0)
            {
                foreach (ExpenseSheet sheet in lst)
                {
                    UpdateExpenseSheetFromServer(sheet, includeExpenseEntry);
                }
            }
            return true;
        }

        public bool DeleteExpenseSheet(System.Guid timeEntryID)
        {
            ExpenseSheet es = GetExpenseSheetByTimeEntryID(timeEntryID, false, false);
            if (es != null)
            {
                es.IsDeleted = true;
                return UpdateExpenseSheet(es);
            }

            return true;
        }

        public ExpenseSheetList FillExpenseSheets(IEnumerable rows, bool fillExpenseEntries)
        {
            ExpenseSheetList list = new ExpenseSheetList();

            foreach (DataRow row in rows)
            {
                ExpenseSheet te = FillExpenseSheet(row, fillExpenseEntries);
                if (te != null)
                    list.Add(te);
            }

            return list;
        }

        private ExpenseSheet FillExpenseSheet(DataRow expenseSheetRow, bool fillExpenseEntries)
        {
            TSRDataSet.ExpenseSheetRow esRow = expenseSheetRow as TSRDataSet.ExpenseSheetRow;
            if (esRow != null)
            {
                ExpenseSheet obj = new ExpenseSheet();
                obj.ID = esRow.ID;
                obj.Status = (WS.StatusEnum)esRow.Status;
                obj.TimeEntryID = esRow.TimeEntryID;
                obj.IsDeleted = esRow.IsDeleted;
                obj.Revision = esRow.Revision;

                if (fillExpenseEntries)
                    obj.ExpenseEntryListLocal = GetExpenseEntriesByTimeEntryID(obj.TimeEntryID, false);

                return obj;
            }
            return null;
        } 

        #endregion

        #region ExpenseEntry

        private DataRow GetExpenseEntryRowByID(long id, bool includeDeleted)
        {
            if (MyDataSet.ExpenseEntry.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                                             where dr[ExpenseEntry.Property_ID].ToString() == id.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where dr[ExpenseEntry.Property_ID].ToString() == id.ToString() && dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows[0] : null);
        }

        private DataRow GetExpenseEntryRowByIDServer(long id, bool includeDeleted)
        {
            if (MyDataSet.ExpenseEntry.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                                             where dr[ExpenseEntry.Property_IDServer].ToString() == id.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where dr[ExpenseEntry.Property_IDServer].ToString() == id.ToString() && dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows[0] : null);
        }

        private DataRow[] GetExpenseEntryRowBySheetID(long sheetID, bool includeDeleted)
        {
            if (MyDataSet.ExpenseEntry.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                                             where dr[ExpenseEntry.Property_ExpenseSheetID].ToString() == sheetID.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where dr[ExpenseEntry.Property_ExpenseSheetID].ToString() == sheetID.ToString() && dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows : null);
        }

        private DataRow[] GetExpenseEntryRowByTimeEntryID(Guid timeEntryID, bool includeDeleted)
        {
            if (MyDataSet.ExpenseEntry.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                                             where dr[ExpenseEntry.Property_TimeEntryID].ToString().ToLower() == timeEntryID.ToString().ToLower()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where dr[ExpenseEntry.Property_TimeEntryID].ToString().ToLower() == timeEntryID.ToString().ToLower() 
                             && dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length > 0 ? rows : null);
        }

        private static DataRow[] GetAllExpenseEntryRows()
        {
            var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                         where dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return rows;
        }

        private static DataRow[] GetAllExpenseEntryRows(bool includeDeleted)
        {
            DataRow[] rows = new DataRow[] { };
            if (includeDeleted)
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             select dr;
                rows = dtrows.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where (dr[ExpenseEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS)
                             select dr;
                rows = dtrows.ToArray();
            }

            return rows;
        }

        public ExpenseEntry GetExpenseEntryByID(long id, bool includeDeleted)
        {
            DataRow row = GetExpenseEntryRowByID(id, includeDeleted);
            if (row != null)
            {
                return FillExpenseEntry(row);
            }

            return null;
        }

        public ExpenseEntry GetExpenseEntryByIDServer(long id, bool includeDeleted)
        {
            DataRow row = GetExpenseEntryRowByIDServer(id, includeDeleted);
            if (row != null)
            {
                return FillExpenseEntry(row);
            }

            return null;
        }

        public ExpenseEntryList GetExpenseEntriesBySheetID(long sheetID, bool includeDeleted)
        {
            DataRow[] rows = GetExpenseEntryRowBySheetID(sheetID, includeDeleted);
            if (rows != null)
            {
                return FillExpenseEntries(rows);
            }
            return null;
        }

        public ExpenseEntryList GetExpenseEntriesByTimeEntryID(Guid timeEntryID, bool includeDeleted)
        {
            DataRow[] rows = GetExpenseEntryRowByTimeEntryID(timeEntryID, includeDeleted);
            if (rows != null)
            {
                return FillExpenseEntries(rows);
            }
            return null;
        }

        public ExpenseEntryList GetAllExpenseEntries()
        {
            DataRow[] rows = GetAllExpenseEntryRows();
            return FillExpenseEntries(rows);
        }

        public bool UpdateExpenseEntryFromServer(ExpenseEntry obj)
        {
            return UpdateExpenseEntry(obj, true);
        }

        public bool UpdateExpenseEntry(ExpenseEntry obj)
        {
            return UpdateExpenseEntry(obj, false);
        }

        public bool UpdateExpenseEntry(ExpenseEntry obj, bool fromServer)
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.ExpenseEntry.Rows.Count > 0)
            {                 
                if (obj.ID > 0)
                {
                    var dtrows = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                                 where dr[ExpenseEntry.Property_ID].ToString() == obj.ID.ToString()
                                 && dr[ExpenseEntry.Property_TimeEntryID].ToString().ToLower() == obj.TimeEntryID.ToString().ToLower()
                                 select dr;
                    rows = dtrows.ToArray();
                }
                
                if ((fromServer || rows.Length == 0) && obj.IDServer.HasValue && obj.IDServer.Value > 0)
                {
                    var dtrows2 = from dr in MyDataSet.ExpenseEntry.AsEnumerable()
                             where dr[ExpenseEntry.Property_IDServer].ToString() == obj.IDServer.ToString()
                              && dr[ExpenseEntry.Property_TimeEntryID].ToString().ToLower() == obj.TimeEntryID.ToString().ToLower()
                             select dr;
                    rows = dtrows2.ToArray();
                }
            }

            TSRDataSet.ExpenseEntryRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ExpenseEntryRow;
            else
                row = MyDataSet.ExpenseEntry.NewExpenseEntryRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                //row.ID = obj.ID;
                row.IDServer = obj.IDServer.HasValue ? obj.IDServer.Value : -1;
                row.Description = obj.Description;
                row.ExpenseSheetID = obj.ExpenseSheetID;
                row.ExpenseTypeID = obj.ExpenseTypeID;
                row.IsDeleted = obj.IsDeleted.HasValue ? obj.IsDeleted.Value : false;
                row.IsDeletedOnServer = obj.IsDeletedOnServer;
                row.Quantity = obj.Quantity;
                row.Revision = obj.Revision.HasValue ? obj.Revision.Value : 0;
                row.Value = obj.Value;
                row.Total = obj.Total;
                row.TimeEntryID = obj.TimeEntryID.HasValue ? obj.TimeEntryID.Value : Guid.Empty;
                if (obj.LocationID != null)
                    row.LocationID = (long)obj.LocationID;
                else
                    row.SetLocationIDNull();

                if (rows.Length <= 0)
                    MyDataSet.ExpenseEntry.Rows.Add(row);

                //Update ID for Obj in order to flag this is inserted
                obj.ID = row.ID;
            }
            else
            {
                if (rows.Length > 0)
                {
                    MyDataSet.ExpenseEntry.Rows.Remove(row);
                }
            }
            return true;
        }

        public bool UpdateExpenseEntries(ExpenseEntryList lst)
        {
            if (lst != null && lst.Count > 0)
            {
                foreach (ExpenseEntry exp in lst)
                {
                    UpdateExpenseEntry(exp);
                }
            }
            return true;
        }

        public bool UpdateExpenseEntriesFromServer(ExpenseEntryList lst)
        {
            if (lst != null && lst.Count > 0)
            {
                foreach (ExpenseEntry exp in lst)
                {
                    UpdateExpenseEntryFromServer(exp);
                }
            }
            return true;
        }

        public ExpenseEntryList FillExpenseEntries(IEnumerable rows)
        {
            ExpenseEntryList list = new ExpenseEntryList();

            foreach (DataRow row in rows)
            {
                ExpenseEntry te = FillExpenseEntry(row);
                if (te != null)
                    list.Add(te);
            }

            return list;
        }

        private ExpenseEntry FillExpenseEntry(DataRow expensEntryRow)
        {
            TSRDataSet.ExpenseEntryRow esRow = expensEntryRow as TSRDataSet.ExpenseEntryRow;
            if (esRow != null)
            {
                ExpenseEntry obj = new ExpenseEntry();
                obj.ID = esRow.ID;
                obj.IDServer = esRow.IDServer;
                obj.Description = esRow.Description;
                obj.ExpenseSheetID = esRow.ExpenseSheetID;
                obj.ExpenseTypeID = esRow.ExpenseTypeID;

                using (ExpenseTypeDAL typeDal = new ExpenseTypeDAL())
                {
                    ExpenseType type = typeDal.GetExpenseTypeByID(obj.ExpenseTypeID);
                    if (type != null)
                        obj.ExpenseTypeName = type.Name;
                }

                obj.IsDeleted = esRow.IsDeleted;
                obj.IsDeletedOnServer = esRow.IsDeletedOnServer;
                obj.Quantity = esRow.Quantity;
                obj.Revision = esRow.Revision;
                obj.Value = esRow.Value;
                obj.Total = esRow.Total;
                obj.TimeEntryID = esRow.TimeEntryID;

                if (!esRow.IsLocationIDNull() && esRow.LocationID > 0)
                {
                    obj.LocationID = esRow.LocationID;

                    using (LocationDAL lDal = new LocationDAL())
                    {
                        Location location = lDal.GetLocationByID((long)obj.LocationID);
                        if (location != null)
                            obj.LocationName = location.Name;
                    }
                }
                    
                return obj;
            }
            return null;
        }
        #endregion
    }
}
