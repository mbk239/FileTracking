using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// data access class for Note, local storage
    /// </summary>
    internal class NoteDAL : BaseDAL
    {
        private DataRow GetNoteRowByID(Int64 id)
        {
            //string query = String.Format(Note.Property_ID + " = {0}", id.ToString());
            //DataRow[] rows = MyDataSet.Note.Select(query);

            //edit by tsrdev2 - 21 Jun 2011            
            var dtrows = from dr in MyDataSet.Note.AsEnumerable()
                         where dr[Note.Property_ID].ToString() == id.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves Note object from Note ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Note GetNoteByID(Int64 id)
        {
            DataRow row = GetNoteRowByID(id);
            if (row != null)
            {
                return FillNote(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all Notes
        /// </summary>
        /// <returns></returns>
        public NoteList GetAllNotes()
        {
            return FillNotes(MyDataSet.Note.Rows);
        }

        /// <summary>
        /// retrieves list of Notes for a project
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public NoteList GetNotesByTimeEntryID(Guid timeEntryID)
        {
            //string query = String.Format("TimeEntryID = {0}", timeEntryID.ToString());
            //DataRow[] rows = MyDataSet.Note.Select(query);

            if (MyDataSet.Note.Rows.Count < 1)
                return null;
            
            var dtrows = from dr in MyDataSet.Note.AsEnumerable()
                         where dr[Note.Property_TimeEntryID].ToString() == timeEntryID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            

            if (rows.Count() > 0)
            {
                return FillNotes(rows);
            }

            return new NoteList();
        }

        /// <summary>
        /// updates Note Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateNote(Note obj)
        {
            //string query = String.Format(Note.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Note.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Note.Rows.Count > 0)
            {
                //rows = MyDataSet.Note.Select(query);
             
                //edit by tsrdev2 - 21 Jun 2011            
                var dtrows = from dr in MyDataSet.Note.AsEnumerable()
                             where dr[Note.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }
            TSRDataSet.NoteRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.NoteRow;
            else
                row = MyDataSet.Note.NewNoteRow();
            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.TimeEntryID = obj.TimeEntryID;
                row.Subject = obj.Subject;
                row.Note = obj.Note;
                row.FullName = obj.FullName;
                row.Username = obj.Username;
                row.Timestamp = obj.Timestamp;

                if (rows.Length <= 0)
                    MyDataSet.Note.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.Note.Rows.Remove(row);
            }
            return true;
        }

        /// <summary>
        /// fills list of Note objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private NoteList FillNotes(IEnumerable rows)
        {
            NoteList list = new NoteList();

            foreach (DataRow row in rows)
            {
                list.Add(FillNote(row));
            }

            return list;
        }

        /// <summary>
        /// fills a single Note object from DataRowView object , data retrieved from local storage is
        /// being filled in Note object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Note FillNote(DataRow row)
        {
            TSRDataSet.NoteRow noteRow = row as TSRDataSet.NoteRow;

            if (noteRow != null)
            {
                Note obj = new Note();

                obj.ID = noteRow.ID;
                if (noteRow.IsSubjectNull())
                    obj.Subject = null;
                else
                    obj.Subject = noteRow.Subject;
                obj.Note = noteRow.Note;
                obj.FullName = noteRow.FullName;
                obj.TimeEntryID = noteRow.TimeEntryID;
                obj.Timestamp = noteRow.Timestamp;
                obj.Username = noteRow.Username;

                return obj; 
            }

            return null;
        }
    }
}
