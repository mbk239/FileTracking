using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using System.IO.IsolatedStorage;
using System.Diagnostics;
using System.IO;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    public static class DSClass
    {
        private const string CONST_XMLFILEPATH = "UserData.xml";
        private const string CONST_FOLDER_SEPERATOR = "/";
        private const string CONST_RESOURCEXMLFILEPATH = "ResourceKeys.xml";

        private static TSRDataSet _TSRDataSet;
        private static ResourceKeys _ResourceKeysDs;

        private static void CheckFirstRun()
        {
            System.Security.Principal.WindowsIdentity winID = System.Security.Principal.WindowsIdentity.GetCurrent();
            string userName = winID.Name;

            userName = userName.Replace("\\", "_");

            string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\" + Constants.CONST_APPDATA_FOLDER;            
            string filePath = folderPath + "\\" + userName + ".ini";

            if (!File.Exists(filePath))
            {
                try
                {                    
                    string appDataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                                        + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
                    //Modified by tsrdev1
                    //Check whether directory appDataFolder is existed
                    if (Directory.Exists(appDataFolder))
                        Directory.Delete(appDataFolder, true);
                }
                catch (Exception ex)
                {
                    Logging.LoggingHandler.LogError(ex);
                }

                //Modified by tsrdev1
                //Check whether directory folderPath is existed
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                StreamWriter w = File.CreateText(filePath);
                w.Close();
                w.Dispose();

            }

        }

        /// <summary>
        /// this is the dataset where local storage is retrieved and filled
        /// </summary>
        internal static TSRDataSet MyDS
        {
            get
            {             
                try
                {
                    CheckFirstRun();
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                }

                if (_TSRDataSet == null)
                {
                    _TSRDataSet = new TSRDataSet();

                    //isolated storage, for local storage in xml file
                    //IsolatedStorageFile storage = IsolatedStorageFile.GetStore(IsolatedStorageScope.User | IsolatedStorageScope.Assembly,
                    //    (Type)null, (Type)null);
                    FileStream localAppData = null;
                    string userDataFile = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) 
                                            + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER 
                                            + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_XMLFILEPATH;
                    try
                    {
                        if (File.Exists(userDataFile))
                        {
                            localAppData = new FileStream(userDataFile, FileMode.OpenOrCreate);
                        }
                        else
                        {
                            UserDataHelper.CreateUserLocalData();
                            localAppData = new FileStream(userDataFile, FileMode.OpenOrCreate);
                        }
                    }
                    catch (DirectoryNotFoundException dnfe)
                    {
                        //isFirstRun = true;
                        UserDataHelper.CreateUserLocalData();
                        localAppData = new FileStream(userDataFile, FileMode.OpenOrCreate);
                        TSR.Core.Logging.LoggingHandler.LogError(dnfe);
                    }
                    catch (FileNotFoundException fnfe)
                    {
                        //isFirstRun = true;
                        UserDataHelper.CreateUserLocalData();
                        localAppData = new FileStream(userDataFile, FileMode.OpenOrCreate);
                        TSR.Core.Logging.LoggingHandler.LogError(fnfe);
                    }
                    catch (Exception e)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(e);
                    }

                    //localAppData = new FileStream(userDataFile, FileMode.OpenOrCreate);

                    //using (IsolatedStorageFileStream fs = new IsolatedStorageFileStream(CONST_XMLFILEPATH,
                    //    System.IO.FileMode.OpenOrCreate, storage))
                    //{
                    try
                    {
                        _TSRDataSet.ReadXml(localAppData);                        
                    }
                    catch (System.Xml.XmlException ex)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                        _TSRDataSet = new TSRDataSet();
                    }
                    finally
                    {
                        if (localAppData != null)
                            localAppData.Close();
                    }
                    //}
                }
                //if (_TSRDataSet == null)
                //    _TSRDataSet = new TSRDataSet();

                //if (isFirstRun)
                //    TSR.Core.UserDataHelper.CreateUserLocalDataWithoutCreatingFile(_TSRDataSet);
                return _TSRDataSet;
            }
            set
            {
                _TSRDataSet = value;
            }
        }

        internal static ResourceKeys ResourceKeysDs
        {
            get
            {

                if (true)//(_ResourceKeysDs == null)
                {
                    _ResourceKeysDs = new ResourceKeys();

                    //FileStream localAppData = null;
                    System.IO.StringReader reader = new StringReader(Properties.Resources.ResourceKeys);                   
                    try
                    {
                        // _ResourceKeysDs.ReadXml(localAppData);
                        _ResourceKeysDs.ReadXml(reader);
                    }
                    catch (System.Xml.XmlException ex)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                        _ResourceKeysDs = new ResourceKeys();
                    }
                }

                return _ResourceKeysDs;
            }
        }


        /// <summary>
        /// saves local xml storage force fully
        /// </summary>
        public static void ForceXMLSave()
        {
            if (MyDS.HasChanges())
            {
                FileStream localAppData = null;                
                try
                {
                    using (FileStream stream = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                       + CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_XMLFILEPATH, FileMode.Create))
                    using (TextWriter writer = new StreamWriter(stream))
                    {
                        writer.WriteLine("");
                    }
                    
                    localAppData = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                        + CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_XMLFILEPATH, FileMode.OpenOrCreate);
                }
                catch (DirectoryNotFoundException ex)
                {

                    System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER);
                    localAppData = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) +
                        CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_XMLFILEPATH, FileMode.OpenOrCreate);
                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                }
                if (localAppData == null)
                    return;               

                try
                {
                    MyDS.WriteXml(localAppData);
                }
                catch (System.Xml.XmlException ex)
                {

                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                }

//#if(DEBUG)
                if (ResourceKeysDs.HasChanges())
                {
                    FileStream englocalAppData = null;

                    try
                    {
                        using (FileStream stream = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + CONST_FOLDER_SEPERATOR
                            + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_RESOURCEXMLFILEPATH, FileMode.Create))
                        using (TextWriter writer = new StreamWriter(stream))
                        {
                            writer.WriteLine("");
                        }

                        englocalAppData = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + CONST_FOLDER_SEPERATOR
                            + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_RESOURCEXMLFILEPATH, FileMode.OpenOrCreate);
                    }
                    catch (DirectoryNotFoundException ex)
                    {

                        System.IO.Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER);
                        englocalAppData = new FileStream(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) +
                            CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER + CONST_FOLDER_SEPERATOR + CONST_RESOURCEXMLFILEPATH, FileMode.OpenOrCreate);
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                    }
                    try
                    {
                        ResourceKeysDs.WriteXml(englocalAppData);
                    }
                    catch (System.Xml.XmlException ex)
                    {

                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                    }
                }
//#endif
                //IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForAssembly();
                //using (IsolatedStorageFileStream fs = new IsolatedStorageFileStream(CONST_XMLFILEPATH,
                //    System.IO.FileMode.OpenOrCreate, storage))
                //{
                //    MyDS.WriteXml(fs);
                //}
            }
        }
    }

    public class BaseDAL : IDisposable
    {
        public static TSRDataSet MyDataSet
        {
            get
            {
                return DSClass.MyDS;
            }
            set
            {
                DSClass.MyDS = value;
            }
        }

        public static ResourceKeys ResourceDataSet
        {
            get
            {
                return DSClass.ResourceKeysDs;
            }
        }

        //private static readonly string COL_ID = "ID";

        #region IDisposable Members

        public void Dispose()
        {
            //ForceXMLSave();
        }

        #endregion
    }
}
