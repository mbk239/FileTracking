﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    public class LocationDAL : BaseDAL
    {
        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Location GetLocationByID(Int64 id)
        {
            return GetLocationByID(id, true);
        }
        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Location GetLocationByID(Int64 id, bool isActivate)
        {
            DataRow row = GetLocationRowByID(id, isActivate);
            if (row != null)
            {
                return FillLocation(row, isActivate);
            }

            return null;
        }

        /// <summary>
        /// retrieves all organizations
        /// </summary>
        /// <returns></returns>
        public LocationList GetAllLocations()
        {
            return GetAllLocations(true);
        }

        /// <summary>
        /// retrieves all organizations
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public LocationList GetAllLocations(bool isActivate)
        {
            return FillLocations(MyDataSet.Location.Rows, isActivate);
        }

        /// <summary>
        /// Updates Location Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateLocation(Location obj)
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Location.Rows.Count > 0)
            {                     
                var dtrows = from dr in MyDataSet.Location.AsEnumerable()
                             where dr[Location.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }
            TSRDataSet.LocationRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.LocationRow;
            else
                row = MyDataSet.Location.NewLocationRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Modified = obj.Modified;
                row.IsActivate = obj.IsActivate;

                if (!string.IsNullOrEmpty(obj.Description))
                    row.Description = obj.Description;
                else
                    row.Description = "";

                if (rows.Length <= 0)
                    MyDataSet.Location.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                {
                    MyDataSet.Location.Rows.Remove(row);
                }
            }
            return true;
        }

        #region Private Method
        /// <summary>
        /// fills list of location objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private LocationList FillLocations(IEnumerable rows, bool isActivate)
        {
            var list = new LocationList();
            list.AddRange(from DataRow row in rows where FillLocation(row, isActivate) != null select FillLocation(row, isActivate));

            return list;
        }

        private DataRow GetLocationRowByID(Int64 id, bool isActivate)
        {
            string strIsActivate = isActivate ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in Enumerable.AsEnumerable(MyDataSet.Location)
                         where dr[Location.Property_ID].ToString() == id.ToString() && dr[Location.Property_IsActivate].ToString().ToLower() == strIsActivate
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// fills ExpenseType object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private Location FillLocation(DataRow row, bool isActivate)
        {
            var objRow = row as TSRDataSet.LocationRow;

            if ((objRow != null) && (objRow.IsActivate == isActivate))
            {
                var obj = new Location();

                obj.ID = objRow.ID;
                obj.Name = objRow.Name;
                obj.Description = objRow.Description;
                obj.IsActivate = objRow.IsActivate;

                return obj;
            }
            return null;
        }

        #endregion
    }
}
