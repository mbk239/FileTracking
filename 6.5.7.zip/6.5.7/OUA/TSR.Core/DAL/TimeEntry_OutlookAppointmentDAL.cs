﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for TimeEntry_OutlookAppointment object
    /// </summary>
    internal class TimeEntry_OutlookAppointmentDAL:BaseDAL
    {
        /// <summary>
        /// get row of link between time entry and appointment by id
        /// </summary>
        /// <param name="id"></param>        
        /// <returns></returns>
        private DataRow GetTimeEntry_OutlookAppointmentRowByID(Int64 id)
        {
            //string query = String.Format(TimeEntry_OutlookAppointment.Property_ID + " = {0}", id.ToString());
            //DataRow[] rows = MyDataSet.TimeEntry_OutlookAppointment.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                             
            var dtrows = from dr in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                         where dr[TimeEntry_OutlookAppointment.Property_ID].ToString() == id.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// get row of link between time entry and appointment by outlookItemID
        /// </summary>
        /// <param name="outlookItemID"></param>        
        /// <returns></returns>
        private DataRow GetTimeEntry_OutlookAppointmentRowByOutlookItemID(string outlookItemID)
        {
            //string query = String.Format(TimeEntry_OutlookAppointment.Property_OutlookItemID + " = '{0}'", outlookItemID);
            //DataRow[] rows = MyDataSet.TimeEntry_OutlookAppointment.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                             
            var dtrows = from dr in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                         where dr[TimeEntry_OutlookAppointment.Property_OutlookItemID].ToString() == outlookItemID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// get row of link between time entry and appointment by time entry id
        /// </summary>
        /// <param name="timeEntryID"></param>        
        /// <returns></returns>
        private DataRow GetTimeEntry_OutlookAppointmentRowByTimeEntryID(Guid timeEntryID)
        {
            //string query = String.Format(TimeEntry_OutlookAppointment.Property_TimeEntryID + " = '{0}'", timeEntryID.ToString());
            //DataRow[] rows = MyDataSet.TimeEntry_OutlookAppointment.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                             
            var dtrows = from dr in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                         where dr[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() == timeEntryID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }       

        /// <summary>
        /// retrieves link between time entry and appointment by id
        /// </summary>
        /// <param name="id"></param>        
        /// <returns></returns>
        public TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByID(Int64 id)
        {
            DataRow row = GetTimeEntry_OutlookAppointmentRowByID(id);
            if (row != null)
            {
                return FillTimeEntry_OutlookAppointment(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves link between time entry and appointment by outlook appointment id
        /// </summary>
        /// <param name="outlookItemID"></param>        
        /// <returns></returns>
        public TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByOutlookItemID(string outlookItemID)
        {
            DataRow row = GetTimeEntry_OutlookAppointmentRowByOutlookItemID(outlookItemID);
            if (row != null)
            {
                return FillTimeEntry_OutlookAppointment(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves link between time entry and appointment by time entry id
        /// </summary>
        /// <param name="timeEntryID"></param>        
        /// <returns></returns>
        public TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByTimeEntryID(Guid timeEntryID)
        {
            DataRow row = GetTimeEntry_OutlookAppointmentRowByTimeEntryID(timeEntryID);
            if (row != null)
            {
                return FillTimeEntry_OutlookAppointment(row);
            }

            return null;
        }       
        /// <summary>
        /// retrieves all links between time entry and appointment
        /// </summary>        
        /// <returns></returns>
        public TimeEntry_OutlookAppointmentList GetAllTimeEntry_OutlookAppointment()
        {
            return FillAllTimeEntry_OutlookAppointment(MyDataSet.TimeEntry_OutlookAppointment.Rows);
        }

        /// <summary>
        /// updates link between time entry and appointment
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateTimeEntry_OutlookAppointment(TimeEntry_OutlookAppointment obj)
        {
            //string query = String.Format(TimeEntry_OutlookAppointment.Property_TimeEntryID + " = '{0}'", obj.TimeEntryID);
            //DataRow[] rows = MyDataSet.Activity.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.TimeEntry_OutlookAppointment.Rows.Count > 0)
            {
                //rows = MyDataSet.TimeEntry_OutlookAppointment.Select(query);

                //edit by tsrdev2 - 21 Jun 2011                             
                var dtrows = from dr in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                             where dr[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() == obj.TimeEntryID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.TimeEntry_OutlookAppointmentRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.TimeEntry_OutlookAppointmentRow;
            else
                row = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {                
                row.OutlookItemID = obj.OutlookItemID;
                row.TimeEntryID = obj.TimeEntryID;
                row.Revision = obj.Revision;
                if (string.IsNullOrEmpty(obj.CalendarID))
                    row.SetCalendarIDNull();
                else
                    row.CalendarID = obj.CalendarID;
                if (rows.Length <= 0)
                    MyDataSet.TimeEntry_OutlookAppointment.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.TimeEntry_OutlookAppointment.Rows.Remove(row);
            }
            return true;            
        }
        

        /// <summary>
        /// fills TimeEntry_OutlookAppointment objects from enumerable rows
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private TimeEntry_OutlookAppointmentList FillAllTimeEntry_OutlookAppointment(IEnumerable rows)
        {
            TimeEntry_OutlookAppointmentList list = new TimeEntry_OutlookAppointmentList();

            foreach (DataRow row in rows)
            {
                if (FillTimeEntry_OutlookAppointment(row) != null)
                    list.Add(FillTimeEntry_OutlookAppointment(row));
            }

            return list;
        }
        
        /// <summary>
        /// fills TimeEntry_OutlookAppointment object from data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private TimeEntry_OutlookAppointment FillTimeEntry_OutlookAppointment(DataRow row)
        {
            TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow = row as TSRDataSet.TimeEntry_OutlookAppointmentRow;

            if (te_appRow != null)
            {
                TimeEntry_OutlookAppointment obj = new TimeEntry_OutlookAppointment();
                
                obj.TimeEntryID = te_appRow.TimeEntryID;
                obj.OutlookItemID = te_appRow.OutlookItemID;
                obj.Revision = te_appRow.Revision;
                if (!te_appRow.IsCalendarIDNull())
                    obj.CalendarID = te_appRow.CalendarID;
                return obj;
            }

            return null;
        }
    }
}
