﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace TSR.Core.DAL
{
    public class Organization_ProjectDAL : BaseDAL
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        internal Entity.Organization_ProjectList GetAllOrganization_Project()
        {
            return FillOrganization_Project(MyDataSet.Organization_Project.Rows);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private Entity.Organization_ProjectList FillOrganization_Project(System.Data.DataRowCollection rows)
        {
            Entity.Organization_ProjectList list = new Entity.Organization_ProjectList();

            foreach (DataRow row in rows)
            {
                Entity.Organization_Project orgProject = FillOrganizationProject(row);
                if (orgProject != null)
                    list.Add(orgProject);
            }
            return list;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Entity.Organization_Project FillOrganizationProject(DataRow row)
        {
            TSRDataSet.Organization_ProjectRow cntRow = row as TSRDataSet.Organization_ProjectRow;

            if (cntRow != null)
            {
                Entity.Organization_Project obj = new Entity.Organization_Project();
                obj.OrganizationID = cntRow.OrganizationID;
                obj.ProjectID = cntRow.ProjectID;

                return obj;
            }
            return null;
        }
    }
}
