using System;
using System.Collections.Generic;
using System.Text;

using TSR.Core.Entity;
using System.Data;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data Access Class for Recurrence
    /// </summary>
    class RecurrenceDAL : BaseDAL
    {
        private DataRow GetRecurrenceRowByID(System.Guid id)
        {
            string query = String.Format("ID = {0}", id.ToString());
            DataRow[] rows = MyDataSet.Recurrence.Select(query);
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// gets single recurrence from recurrence ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Recurrence GetRecurrenceByID(System.Guid id)
        {
            DataRow row = GetRecurrenceRowByID(id);
            if (row != null)
            {
                return FillRecurrence(row);
            }

            return null;
        }

        /// <summary>
        /// updates a recurrence locally
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool Update(Recurrence obj)
        {
            string query = String.Format("ID = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Recurrence.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Recurrence.Rows.Count > 0)
                rows = MyDataSet.Recurrence.Select(query);

            TSRDataSet.RecurrenceRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.RecurrenceRow;
            else
                row = MyDataSet.Recurrence.NewRecurrenceRow();

            row.ID = obj.ID;
            row.StartDate = obj.StartDate;
            row.EndType = obj.EndType;
            row.EndDate = obj.EndDate;
            row.OccurrenceBeforeEnd = obj.OccurrenceBeforeEnd;
            row.Type1 = obj.Type1;
            row.Type1Value = obj.Type1Value;
            row.Type2 = obj.Type2;
            row.Type2Value = obj.Type2Value;
            row.Type3 = obj.Type3;
            row.Type3Value = obj.Type3Value;

            if (rows.Length <= 0)
                MyDataSet.Recurrence.Rows.Add(row);

            return true;
        }

        /// <summary>
        /// fills a recurrence object from local storage [row]
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Recurrence FillRecurrence(DataRow row)
        {
            TSRDataSet.RecurrenceRow rcrRow = row as TSRDataSet.RecurrenceRow;

            if (rcrRow != null)
            {
                Recurrence obj = new Recurrence();

                obj.ID = rcrRow.ID;
                obj.StartDate = rcrRow.StartDate;
                obj.EndType = rcrRow.EndType;
                obj.EndDate = rcrRow.EndDate;
                obj.OccurrenceBeforeEnd = rcrRow.OccurrenceBeforeEnd;
                obj.Type1 = rcrRow.Type1;
                obj.Type1Value = rcrRow.Type1Value;

                if (!rcrRow.IsType2Null())
                {
                    obj.Type2 = rcrRow.Type2;
                    obj.Type2Value = rcrRow.Type2Value;
                }
                if (!rcrRow.IsType3Null())
                {
                    obj.Type3 = rcrRow.Type3;
                    obj.Type3Value = rcrRow.Type3Value;
                }

                return obj;
            }

            return null;
        }
    }
}
