using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using WS = TSR.Core.UserAgentService;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// data access class for TimeEntry, local storage
    /// </summary>
    internal class TimeEntryDAL : BaseDAL
    {
        private static bool GetExchangeMode()
        {
            string strExchangeMode = string.Empty;

            if (MyDataSet.UserSettings.Rows.Count < 1)
                return false;
            DataRow[] rows = new DataRow[] { };

            var dtrows = from dr in MyDataSet.UserSettings.AsEnumerable()
                         where dr[UserSettings.Property_Key].ToString() == Constants.CONST_EXCHANGEMODE_KEY
                         select dr;
            rows = dtrows.ToArray();

            if (rows == null)
                return false;

            strExchangeMode = (rows.Length == 1 ? (rows[0] as TSRDataSet.UserSettingsRow).Value : string.Empty);            

            if (string.IsNullOrEmpty(strExchangeMode))
                return false;
            else
            {
                if (strExchangeMode.ToUpper() == ExchangeMode.Yes.ToString().ToUpper())
                    return true;
                else
                    return false;

            }
        }

        private DataRow GetTimeEntryRowByID(Guid id, bool includeDeleted)
        {
            //string query = String.Format("ID = {0}", id.ToString());
            if (MyDataSet.TimeEntry.Rows.Count < 1)
                return null;
            //DataRow[] rows = MyDataSet.TimeEntry.Select(query);
            DataRow[] rows = new DataRow[] { };

            if (includeDeleted)
            {
                var dtrowsIncludingDeleted = from dr in MyDataSet.TimeEntry.AsEnumerable()
                                             where dr[TimeEntry.Property_ID].ToString() == id.ToString()
                                             select dr;
                rows = dtrowsIncludingDeleted.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                             where dr[TimeEntry.Property_ID].ToString() == id.ToString() && dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                             select dr;
                rows = dtrows.ToArray();
            }
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves TimeEntry object from TimeEntry ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public TimeEntry GetTimeEntryByID(Guid id, bool includeDeleted)
        {
            DataRow row = GetTimeEntryRowByID(id, includeDeleted);
            if (row != null)
            {
                return FillTimeEntry(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all TimeEntrys
        /// </summary>
        /// <returns></returns>
        public TimeEntryList GetAllTimeEntries()
        {
            DataRow[] rows = GetAllTimeEntryRows();
            return FillTimeEntries(rows);
            //return FillTimeEntrys(MyDataSet.TimeEntry.Rows);
        }

        private static DataRow[] GetAllTimeEntryRows()
        {
            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         where dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return rows;
        }

        //added by tsrdev2
        private static DataRow[] GetAllTimeEntryRows(bool includeDeleted)
        {
            DataRow[] rows =  new DataRow[] {};
            if (includeDeleted)
            {
                var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()                             
                             select dr;
                rows = dtrows.ToArray();
            }
            else
            {
                var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                             where (dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS)
                             select dr;
                rows = dtrows.ToArray(); 
            }
            
            return rows;
        }

        /// <summary>
        /// Retrieves TimeEntry for a given Outlook appointment
        /// </summary>
        /// <param name="olItemID">Outlook appointment entry id</param>
        /// <returns></returns>
        public TimeEntry GetTimeEntryByOutlookItemID(string olItemID)
        {
            //string query = String.Format("OutlookItemID = {0}", olItemID);
            //DataRow[] rows = MyDataSet.TimeEntry.Select(query);

            var dtrows = (from dr in MyDataSet.TimeEntry.AsEnumerable()
                          join
                          drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                          on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
                          where drApp[TimeEntry.Property_OutlookItemID].ToString() == olItemID && dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                          //select new { dr, drApp }).SingleOrDefault();
                          select new { dr, drApp }).FirstOrDefault();//Modified by tsrdev1
            //DataRow[] rows = dtrows.SingleOrDefault().dr

            //return (rows.Length == 1 ? FillTimeEntry(rows[0]) : null);
            return (dtrows == null) ? null : FillTimeEntry(dtrows.dr);            
        }

        /// <summary>
        /// Retrieves TimeEntries for a given recurring Outlook appointment
        /// </summary>
        /// <param name="olItemID">Outlook appointment entry id</param>
        /// <returns></returns>
        public TimeEntryList GetTimeEntriesByRecurringOutlookItemID(string olItemID)
        {
            //string query = String.Format("OutlookItemID = {0}", olItemID);
            //DataRow[] rows = MyDataSet.TimeEntry.Select(query);

            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         join
                         drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                         on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
                         where drApp[TimeEntry.Property_OutlookItemID].ToString() == olItemID
                         && dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS
                         && dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.TRUE_IN_LOWER_CHARS
                         select dr;
            DataRow[] rows = dtrows.ToArray();

            return (rows.Length > 0 ? FillTimeEntries(rows) : new TimeEntryList());
        }

        /// <summary>
        /// Retrieves TimeEntry for a recurring Outlook appointment occurrence
        /// </summary>
        /// <param name="olItemID">Outlook appointment entry id</param>
        /// <returns></returns>
        public TimeEntry GetTimeEntryForRecurringAppointment(string olItemID, DateTime start, DateTime end, bool includeDeleted)
        {
            //string query = String.Format("OutlookItemID = {0}", olItemID);
            //DataRow[] rows = MyDataSet.TimeEntry.Select(query);
            DataRow[] rows = new DataRow[] { };
            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         join
                         drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                         on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
                         where drApp[TimeEntry.Property_OutlookItemID].ToString() == olItemID &&
                         Convert.ToDateTime(dr[TimeEntry.Property_StartTime]) == start &&
                         Convert.ToDateTime(dr[TimeEntry.Property_EndTime]) == end &&
                         dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.TRUE_IN_LOWER_CHARS &&
                         (includeDeleted || dr[TimeEntry.Property_IsDeleted].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS)
                         select dr;
            rows = dtrows.ToArray();

            //if (includeDeleted)
            //{
            //    var dtrowsIncludingDeleted = from dr in MyDataSet.TimeEntry.AsEnumerable()
            //                                 where dr["OutlookItemID"].ToString() == olItemID &&
            //                                 Convert.ToDateTime(dr["StartTime"]) == start &&
            //                                 Convert.ToDateTime(dr["EndTime"]) == end &&
            //                                 dr["IsRecurring"].ToString().ToLower() == "true"
            //                                 select dr;
            //    rows = dtrowsIncludingDeleted.ToArray();
            //}
            //else
            //{
            //    var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
            //                 where dr["OutlookItemID"].ToString() == olItemID &&
            //                 Convert.ToDateTime(dr["StartTime"]) == start &&
            //                 Convert.ToDateTime(dr["EndTime"]) == end &&
            //                 dr["IsRecurring"].ToString().ToLower() == "true" &&
            //                 dr["IsDeleted"].ToString().ToLower() == "false"
            //                 select dr;
            //    rows = dtrows.ToArray();
            //}

            return (rows.Length == 1 ? FillTimeEntry(rows[0]) : null);
        }

        /// <summary>
        /// retrieves time entry list by Organization ID, project ID, activity ID, task ID, contact ID, status, subject
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <param name="taskID"></param>
        /// <param name="contactID"></param>
        /// <param name="status"></param>
        /// <param name="subject"></param>
        /// <returns></returns>
        public TimeEntryList GetDataByAllParams(Int64 organizationID, Int64 projectID, Int64 activityID,
    Int64 taskID, Int64 contactID, Int32 status, string subject)
        {
            List<DataRow> ldr = new List<DataRow>();
            bool add = false;
            DataRow[] rows = GetAllTimeEntryRows();
            foreach (DataRow item in rows)
            {
                add = (((organizationID != -1) && (item[TimeEntry.Property_OrganizationID].ToString() == organizationID.ToString())) || (organizationID == -1));
                add = add && (((projectID != -1) && (item[TimeEntry.Property_ProjectID].ToString() == projectID.ToString())) || (projectID == -1));
                add = add && (((activityID != -1) && (item[TimeEntry.Property_ActivityID].ToString() == activityID.ToString())) || (activityID == -1));
                add = add && (((taskID != -1) && (item[TimeEntry.Property_TaskID].ToString() == taskID.ToString())) || (taskID == -1));
                add = add && (((contactID != -1) && (item[TimeEntry.Property_ContactID].ToString() == contactID.ToString())) || (contactID == -1));
                add = add && (((status != -1) && (item[TimeEntry.Property_Status].ToString() == status.ToString())) || (status == -1));
                add = add && (((!string.IsNullOrEmpty(subject)) && (item[TimeEntry.Property_Subject].ToString().Contains(subject))) || (string.IsNullOrEmpty(subject)));

                if (add)
                    ldr.Add(item);
            }
            return FillTimeEntries(ldr.ToArray());
        }

        /// <summary>
        /// retrieves time entry list by Organization ID, project ID, activity ID, task ID, contact ID, status, subject
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <param name="taskID"></param>
        /// <param name="contactID"></param>
        /// <param name="status"></param>
        /// <param name="subject"></param>
        /// <param name="includeDeleted"></param>
        /// <returns></returns>
        public TimeEntryList GetDataByAllParams(Int64 organizationID, Int64 projectID, Int64 activityID,
    Int64 taskID, Int64 contactID, Int32 status, string subject, bool includeDeleted)
        {
            List<DataRow> ldr = new List<DataRow>();
            bool add = false;
            DataRow[] rows = GetAllTimeEntryRows(includeDeleted);            
            foreach (DataRow item in rows)
            {
                add = (((organizationID != -1) && (item[TimeEntry.Property_OrganizationID].ToString() == organizationID.ToString())) || (organizationID == -1));
                add = add && (((projectID != -1) && (item[TimeEntry.Property_ProjectID].ToString() == projectID.ToString())) || (projectID == -1));
                add = add && (((activityID != -1) && (item[TimeEntry.Property_ActivityID].ToString() == activityID.ToString())) || (activityID == -1));
                add = add && (((taskID != -1) && (item[TimeEntry.Property_TaskID].ToString() == taskID.ToString())) || (taskID == -1));
                add = add && (((contactID != -1) && (item[TimeEntry.Property_ContactID].ToString() == contactID.ToString())) || (contactID == -1));
                add = add && (((status != -1) && (item[TimeEntry.Property_Status].ToString() == status.ToString())) || (status == -1));
                add = add && (((!string.IsNullOrEmpty(subject)) && (item[TimeEntry.Property_Subject].ToString().Contains(subject))) || (string.IsNullOrEmpty(subject)));

                if (add)
                    ldr.Add(item);
            }
            return FillTimeEntries(ldr.ToArray());
        }

        /// <summary>
        /// retrieves Time entry list
        /// </summary>
        /// <param name="lstOrganizationID"></param>
        /// <param name="lstProjectID"></param>
        /// <param name="lstActivityID"></param>
        /// <param name="lstTaskID"></param>
        /// <param name="lstContactID"></param>
        /// <param name="lstStatus"></param>
        /// <param name="subject"></param>
        /// <returns></returns>
        public TimeEntryList GetDataByAllParams(List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
    List<Int64> lstTaskID, List<Int64> lstContactID, List<Int32> lstStatus, string subject)
        {
            List<DataRow> ldr = new List<DataRow>();
            bool add = true;
            long orgId, projId, actId, taskId, contactId;
            int status;
            string subFromUser = string.Empty;
            string subInStorage = string.Empty;

            DataRow[] rows = GetAllTimeEntryRows();
            foreach (DataRow item in rows)
            {
                if (Int64.TryParse(item[TimeEntry.Property_OrganizationID].ToString(), out orgId))
                    add = (((lstOrganizationID.Count > 0) && (lstOrganizationID.Contains(orgId))) || (lstOrganizationID.Count == 0));
                if (Int64.TryParse(item[TimeEntry.Property_ProjectID].ToString(), out projId))
                    add = add && (((lstProjectID.Count > 0) && (lstProjectID.Contains(projId))) || (lstProjectID.Count == 0));
                if (Int64.TryParse(item[TimeEntry.Property_ActivityID].ToString(), out actId))
                    add = add && (((lstActivityID.Count > 0) && (lstActivityID.Contains(actId))) || (lstActivityID.Count == 0));
                if (Int64.TryParse(item[TimeEntry.Property_TaskID].ToString(), out taskId))
                    add = add && (((lstTaskID.Count > 0) && (lstTaskID.Contains(taskId))) || (lstTaskID.Count == 0));
                if (Int64.TryParse(item[TimeEntry.Property_ContactID].ToString(), out contactId))
                    add = add && (((lstContactID.Count > 0) && (lstContactID.Contains(contactId))) || (lstContactID.Count == 0));
                if (Int32.TryParse(item[TimeEntry.Property_Status].ToString(), out status))
                    add = add && (((lstStatus.Count > 0) && (lstStatus.Contains(status))) || (lstStatus.Count == 0));
                subFromUser = subject.Trim().ToLower().Replace(Constants.SPACE, string.Empty);
                subInStorage = item[TimeEntry.Property_Subject].ToString().Trim().ToLower().Replace(Constants.SPACE, string.Empty);
                add = add && (((!string.IsNullOrEmpty(subject)) && (subInStorage.Contains(subFromUser))) || (string.IsNullOrEmpty(subject)));

                if (item[TimeEntry.Property_IsOutOfOffice] == DBNull.Value)
                    item[TimeEntry.Property_IsOutOfOffice] = false;

                if (add)
                    ldr.Add(item);
            }
            return FillTimeEntries(ldr.ToArray());
            //return FillTimeEntrys(rows);
        }

        //Comment by tsrdev1

        ///// <summary>
        ///// updates TimeEntry Object
        ///// </summary>
        ///// <param name="obj"></param>
        ///// <returns></returns>
        //public bool UpdateTimeEntry(TimeEntry obj)
        //{
        //    string query = String.Format(TimeEntry.Property_ID + " = {0}", obj.ID.ToString());
        //    //DataRow[] rows = new DataRow[] { };
        //    List<DataRow> te_app_rows = new List<DataRow>();
        //    if (MyDataSet.TimeEntry.Rows.Count < 1)
        //    {
        //        //return false;
        //    }

        //    var dtrows = (from dr in MyDataSet.TimeEntry.AsEnumerable()
        //                  join
        //                      drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
        //                      on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
        //                  where dr[TimeEntry.Property_ID].ToString() == obj.ID.ToString()
        //                  select new { dr, drApp }).SingleOrDefault();
        //    //rows = dtrows.ToArray();

        //    TSRDataSet.TimeEntryRow row;
        //    TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow;

        //    if (dtrows != null)
        //    {
        //        row = dtrows.dr as TSRDataSet.TimeEntryRow;
        //        te_appRow = dtrows.drApp as TSRDataSet.TimeEntry_OutlookAppointmentRow;
        //    }
        //    else
        //    {
        //        row = MyDataSet.TimeEntry.NewTimeEntryRow();               
        //        te_appRow = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
        //    }

        //    if ((dtrows == null) || (row != null && obj.IsDeleted))
        //    {
        //        var temp_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
        //                           where drApp[TimeEntry.Property_TimeEntryID].ToString() == obj.ID.ToString()
        //                           select drApp;
        //        if (temp_appRows != null && temp_appRows.Count() > 0)
        //        {
        //            foreach (TSRDataSet.TimeEntry_OutlookAppointmentRow temp_row in temp_appRows)
        //            {
        //                TSRDataSet.TimeEntry_OutlookAppointmentRow temp_appRow = temp_row as TSRDataSet.TimeEntry_OutlookAppointmentRow;
        //                if (temp_appRow != null)
        //                {
        //                    te_app_rows.Add(temp_appRow);
        //                }
        //            }
        //            foreach (DataRow te in te_app_rows)
        //            {
        //                MyDataSet.Tables["TimeEntry_OutlookAppointment"].Rows.Remove(te);
        //            }
        //        }
        //    }

        //    //te_appRow

        //    row.ID = obj.ID;
        //    //row.OutlookItemID = obj.OutlookItemID;
        //    if (!(obj.IsDeleted))
        //    {
        //        te_appRow.TimeEntryID = obj.ID;
        //        te_appRow.OutlookItemID = obj.OutlookItemID;
        //    }
        //    row.StartTime = obj.StartTimeStamp;
        //    row.EndTime = obj.EndTimeStamp;
        //    row.TimeZone = obj.TimeZone;
        //    row.OrganizationID = obj.OrganizationID;
        //    row.ProjectID = obj.ProjectID;
        //    row.ActivityID = obj.ActivityID;
        //    row.IsRecurring = obj.IsRecurring;
        //    if (obj.RecurrenceID.HasValue)
        //        row.RecurrenceID = obj.RecurrenceID.Value;
        //    else
        //        row.SetRecurrenceIDNull();

        //    if (String.IsNullOrEmpty(obj.Subject))
        //        row.SetSubjectNull();
        //    else
        //        row.Subject = obj.Subject;
        //    if (String.IsNullOrEmpty(obj.Body))
        //        row.SetBodyNull();
        //    else
        //        row.Body = obj.Body;
        //    if (String.IsNullOrEmpty(obj.Location))
        //        row.SetLocationNull();
        //    else
        //        row.Location = obj.Location;
        //    if ((obj.LastModificationTime != null)&&(obj.LastModificationTime != DateTime.MinValue))
        //        row.LastModificationTime = obj.LastModificationTime;

        //    if (obj.TaskID.HasValue)
        //        row.TaskID = obj.TaskID.Value;
        //    else
        //        row.SetTaskIDNull();
        //    if (obj.ContactID.HasValue)
        //        row.ContactID = obj.ContactID.Value;
        //    else
        //        row.SetContactIDNull();
        //    if (String.IsNullOrEmpty(obj.Message))
        //        row.SetMessageNull();
        //    else
        //        row.Message = obj.Message;

        //    row.Status = Convert.ToInt32(obj.Status);
        //    row.IsDeleted = obj.IsDeleted;

        //    if (dtrows == null)
        //    {
        //        try
        //        {
        //            MyDataSet.TimeEntry.Rows.Add(row);
        //            //if (te_app_rows.Length <= 0)
        //            MyDataSet.TimeEntry_OutlookAppointment.Rows.Add(te_appRow);
        //        }
        //        catch (Exception ex)
        //        {
        //            TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
        //            System.Diagnostics.Debug.WriteLine(ex.Message);
        //        }
        //    }

        //    //rows = MyDataSet.TimeEntry.Select(query);

        //    return true;
        //}

        /// <summary>
        /// added by tsrdev1
        /// updates TimeEntry Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateTimeEntry(TimeEntry obj)
        {
            string query = String.Format(TimeEntry.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = new DataRow[] { };
            List<DataRow> te_app_rows = new List<DataRow>();
            bool isTEAdded = false;
            bool isTE_OUAAdded = false;
            if (MyDataSet.TimeEntry.Rows.Count < 1)
            {
                //return false;
            }

            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()                          
                          where dr[TimeEntry.Property_ID].ToString() == obj.ID.ToString()
                          select dr;

            var temp_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                               where drApp[TimeEntry.Property_TimeEntryID].ToString() == obj.ID.ToString()
                               select drApp;
            //rows = dtrows.ToArray();

            TSRDataSet.TimeEntryRow row ;
            TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow;

            if ((dtrows != null) && (dtrows.Count() > 0))
            {
                row = dtrows.First() as TSRDataSet.TimeEntryRow;
                if (temp_appRows != null && temp_appRows.Count() > 0)
                    te_appRow = temp_appRows.First() as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                else
                {
                    te_appRow = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
                    isTE_OUAAdded = true;
                }
            }
            else
            {
                row = MyDataSet.TimeEntry.NewTimeEntryRow();
                isTEAdded = true;

                te_appRow = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
                isTE_OUAAdded = true;
            }

            if ((isTEAdded) || (!isTEAdded && obj.IsDeleted))
            {                
                if (temp_appRows != null && temp_appRows.Count() > 0)
                {
                    foreach (TSRDataSet.TimeEntry_OutlookAppointmentRow temp_row in temp_appRows)
                    {
                        TSRDataSet.TimeEntry_OutlookAppointmentRow temp_appRow = temp_row as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                        if (temp_appRow != null)
                        {
                            te_app_rows.Add(temp_appRow);
                        }
                    }
                    //Deleting link between time entry and appointment and deleting appointment item
                    foreach (DataRow te in te_app_rows)
                    {                        
                        try
                        {
                            Microsoft.Office.Interop.Outlook.AppointmentItem item = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(te["OutlookItemID"].ToString());
                            if (item != null)
                                item.Delete();
                        }
                        catch //(Exception ex)
                        {
                            //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                        if (isTEAdded)
                            MyDataSet.Tables["TimeEntry_OutlookAppointment"].Rows.Remove(te);
                    }
                }
            }

            if (GetExchangeMode())
            {
                if (!string.IsNullOrEmpty(obj.OutlookItemID) && (obj.OutlookItemID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID))
                {
                    //Delete other TimeEntry_OutlookAppointments that also link same appointment
                    //var duplicatehApp__te_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                    //                                where drApp[TimeEntry.Property_OutlookItemID].ToString() == obj.OutlookItemID && 
                    //                                drApp[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() != obj.ID.ToString()
                    //                                select drApp;

                    var duplicatehApp__te_appRows = (from dr in MyDataSet.TimeEntry.AsEnumerable()
                                                     join
                                                     drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                                                     on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
                                                     where drApp[TimeEntry.Property_OutlookItemID].ToString() == obj.OutlookItemID &&
                                                           drApp[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() != obj.ID.ToString() &&
                                                           ((dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS) ||
                                                           ((dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.TRUE_IN_LOWER_CHARS) && (Convert.ToDateTime(dr[TimeEntry.Property_StartTime]).Date == obj.StartTimeStamp.Date)))
                                                     select new { dr, drApp });//Modified by tsrdev1
                    if (duplicatehApp__te_appRows != null && duplicatehApp__te_appRows.Count() > 0)
                    {
                        List<Guid> listTeIDs = new List<Guid>();
                        Microsoft.Office.Interop.Outlook.AppointmentItem item = null;
                        try
                        {
                            item = obj.OLAppointmentItem;
                        }
                        catch //(Exception ex)
                        {
                            //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                        if (item != null)
                        {
                            for (int i = 0; i < duplicatehApp__te_appRows.Count(); i++)
                            {
                                TSRDataSet.TimeEntry_OutlookAppointmentRow temp_row = duplicatehApp__te_appRows.ElementAt(i).drApp as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                                TSRDataSet.TimeEntryRow teRow = duplicatehApp__te_appRows.ElementAt(i).dr as TSRDataSet.TimeEntryRow;

                                if (te_appRow != null && teRow != null)
                                    listTeIDs.Add(temp_row.TimeEntryID);
                            }
                            foreach (Guid teID in listTeIDs)
                            {
                                //Deleting link between time entry and appointment and deleting time entry
                                RemoveTimeEntry(teID);
                            }
                        }
                    }

                }

            }
            //te_appRow

            row.ID = obj.ID;
            //row.OutlookItemID = obj.OutlookItemID;
            if (!(obj.IsDeleted))
            {
                te_appRow.TimeEntryID = obj.ID;
                te_appRow.OutlookItemID = obj.OutlookItemID;
                if (string.IsNullOrEmpty(obj.CalendarID))
                    te_appRow.SetCalendarIDNull();
                else
                    te_appRow.CalendarID = obj.CalendarID;
            }
            row.StartTime = obj.StartTimeStamp;
            row.EndTime = obj.EndTimeStamp;
            row.TimeZone = obj.TimeZone;
            row.OrganizationID = obj.OrganizationID;
            row.ProjectID = obj.ProjectID;
            row.ActivityID = obj.ActivityID;
            row.IsRecurring = obj.IsRecurring;
            if (obj.RecurrenceID.HasValue)
                row.RecurrenceID = obj.RecurrenceID.Value;
            else
                row.SetRecurrenceIDNull();

            if (String.IsNullOrEmpty(obj.Subject))
                row.SetSubjectNull();
            else
                row.Subject = obj.Subject;
            if (String.IsNullOrEmpty(obj.Body))
                row.SetBodyNull();
            else
                row.Body = obj.Body;
            if (String.IsNullOrEmpty(obj.Location))
                row.SetLocationNull();
            else
                row.Location = obj.Location;
            if ((obj.LastModificationTime != null) && (obj.LastModificationTime != DateTime.MinValue))
                row.LastModificationTime = obj.LastModificationTime;

            if (obj.TaskID.HasValue)
                row.TaskID = obj.TaskID.Value;
            else
                row.SetTaskIDNull();
            if (obj.ContactID.HasValue)
                row.ContactID = obj.ContactID.Value;
            else
                row.SetContactIDNull();
            if (String.IsNullOrEmpty(obj.Message))
                row.SetMessageNull();
            else
                row.Message = obj.Message;

            //Added by tsrdev1
            //Added datetime 06/10/2010
            if (obj.Revision.HasValue)
                row.Revision = obj.Revision.Value;
            else
                row.SetRevisionNull();
            if (!string.IsNullOrEmpty(obj.SubmitterName))
                row.SubmitterName = obj.SubmitterName;
            else
                row.SetSubmitterNameNull();
            //End
            row.Status = Convert.ToInt32(obj.Status);
            row.IsDeleted = obj.IsDeleted;
            row.IsOutOfOffice = obj.IsOutOfOffice;
            if (obj.LocationID > 0)
                row.LocationID = obj.LocationID;
            else
                row.SetLocationIDNull();

            //added by tsrdev2
            if (obj.IsDeletedOnServer.HasValue)
            {
                row.IsDeletedOnServer = obj.IsDeletedOnServer.Value;
            }
            else
                row.SetIsDeletedOnServerNull();

            bool notSyncTECreatedViaWeb = (TSR.Core.SettingsHelper.TSRMiscNotSyncTECreatedViaWeb);
            if (notSyncTECreatedViaWeb && isTEAdded)
                row.IsCreatedViaWeb = obj.IsCreatedViaWeb; //This field will be update only when user check on Do Not Sync TE created via Web 

            //Added by tsrdev1
            //Added datetime 27/10/2010
            row.IsRecurring = obj.IsRecurring;

            try
            {
                if (isTEAdded)
                    MyDataSet.TimeEntry.Rows.Add(row);
                //if (te_app_rows.Length <= 0)
                if(isTE_OUAAdded)
                    MyDataSet.TimeEntry_OutlookAppointment.Rows.Add(te_appRow);
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

            //rows = MyDataSet.TimeEntry.Select(query);

            return true;
        }

        // added by tsrdev1
        //Added datetime 25/10/2010
        /// <summary>        
        /// updates TimeEntry Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateTimeEntry(TimeEntry obj,TimeEntry_OutlookAppointment te_app)
        {
            string query = String.Format(TimeEntry.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = new DataRow[] { };
            List<DataRow> te_app_rows = new List<DataRow>();
            bool isTEAdded = false;
            bool isTE_OUAAdded = false;
            if (MyDataSet.TimeEntry.Rows.Count < 1)
            {
                //return false;
            }

            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         where dr[TimeEntry.Property_ID].ToString() == obj.ID.ToString()
                         select dr;

            var temp_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                               where drApp[TimeEntry.Property_TimeEntryID].ToString() == obj.ID.ToString()
                               select drApp;
            //rows = dtrows.ToArray();

            TSRDataSet.TimeEntryRow row;
            TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow;

            if ((dtrows != null) && (dtrows.Count() > 0))
            {
                row = dtrows.First() as TSRDataSet.TimeEntryRow;
                if (temp_appRows != null && temp_appRows.Count() > 0)
                    te_appRow = temp_appRows.First() as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                else
                {
                    te_appRow = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
                    isTE_OUAAdded = true;
                }
            }
            else
            {
                row = MyDataSet.TimeEntry.NewTimeEntryRow();
                isTEAdded = true;

                te_appRow = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
                isTE_OUAAdded = true;
            }

            if ((isTEAdded) || (!isTEAdded && obj.IsDeleted))
            {
                if (temp_appRows != null && temp_appRows.Count() > 0)
                {
                    foreach (TSRDataSet.TimeEntry_OutlookAppointmentRow temp_row in temp_appRows)
                    {
                        TSRDataSet.TimeEntry_OutlookAppointmentRow temp_appRow = temp_row as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                        if (temp_appRow != null)
                        {
                            te_app_rows.Add(temp_appRow);
                        }
                    }
                    //Deleting link between time entry and appointment and deleting appointment item
                    foreach (DataRow te in te_app_rows)
                    {
                        try
                        {
                            Microsoft.Office.Interop.Outlook.AppointmentItem item = OutlookHelper.GetAppointmentItemInCurrentFolderByEntryID(te["OutlookItemID"].ToString());
                            if (item != null)
                                item.Delete();
                        }
                        catch //(Exception ex)
                        {
                            //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                        if (isTEAdded)
                            MyDataSet.Tables["TimeEntry_OutlookAppointment"].Rows.Remove(te);
                    }
                }
            }

            if (GetExchangeMode())
            {
                if (!string.IsNullOrEmpty(obj.OutlookItemID) && (obj.OutlookItemID != Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID))
                {
                    //Delete other TimeEntry_OutlookAppointments that also link same appointment
                    //var duplicatehApp__te_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                    //                                where drApp[TimeEntry.Property_OutlookItemID].ToString() == obj.OutlookItemID && 
                    //                                drApp[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() != obj.ID.ToString()
                    //                                select drApp;

                    var duplicatehApp__te_appRows = (from dr in MyDataSet.TimeEntry.AsEnumerable()
                          join
                          drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                          on dr[TimeEntry.Property_ID].ToString() equals drApp[TimeEntry.Property_TimeEntryID].ToString()
                                  where drApp[TimeEntry.Property_OutlookItemID].ToString() == obj.OutlookItemID && 
                                        drApp[TimeEntry_OutlookAppointment.Property_TimeEntryID].ToString() != obj.ID.ToString() &&
                                        ((dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.FALSE_IN_LOWER_CHARS) ||
                                        ((dr[TimeEntry.Property_IsRecurring].ToString().ToLower() == Constants.TRUE_IN_LOWER_CHARS) && (Convert.ToDateTime(dr[TimeEntry.Property_StartTime]).Date == obj.StartTimeStamp.Date)))                          
                          select new { dr, drApp });//Modified by tsrdev1
                    if (duplicatehApp__te_appRows != null && duplicatehApp__te_appRows.Count() > 0)
                    {
                        List<Guid> listTeIDs = new List<Guid>();
                        Microsoft.Office.Interop.Outlook.AppointmentItem item = null;
                        try
                        {
                            item = obj.OLAppointmentItem;
                        }
                        catch //(Exception ex)
                        {
                            //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }                        
                        if (item != null)
                        {
                            for (int i = 0; i < duplicatehApp__te_appRows.Count(); i++)
                            {
                                TSRDataSet.TimeEntry_OutlookAppointmentRow temp_row = duplicatehApp__te_appRows.ElementAt(i).drApp as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                                TSRDataSet.TimeEntryRow teRow = duplicatehApp__te_appRows.ElementAt(i).dr as TSRDataSet.TimeEntryRow;

                                if (te_appRow != null && teRow != null)
                                    listTeIDs.Add(temp_row.TimeEntryID);
                            }
                            foreach (Guid teID in listTeIDs)
                            {
                                //Deleting link between time entry and appointment and deleting time entry
                                RemoveTimeEntry(teID);
                            }
                        }
                    }

                }

            }
            //te_appRow

            row.ID = obj.ID;
            //row.OutlookItemID = obj.OutlookItemID;
            if (!(obj.IsDeleted))
            {
                te_appRow.TimeEntryID = te_app.TimeEntryID;
                te_appRow.OutlookItemID = te_app.OutlookItemID;
                te_appRow.Revision = te_app.Revision;
                if (string.IsNullOrEmpty(te_app.CalendarID))
                    te_appRow.SetCalendarIDNull();
                else
                    te_appRow.CalendarID = te_app.CalendarID;
            }
            row.StartTime = obj.StartTimeStamp;
            row.EndTime = obj.EndTimeStamp;
            row.TimeZone = obj.TimeZone;
            row.OrganizationID = obj.OrganizationID;
            row.ProjectID = obj.ProjectID;
            row.ActivityID = obj.ActivityID;
            row.IsRecurring = obj.IsRecurring;
            if (obj.RecurrenceID.HasValue)
                row.RecurrenceID = obj.RecurrenceID.Value;
            else
                row.SetRecurrenceIDNull();

            if (String.IsNullOrEmpty(obj.Subject))
                row.SetSubjectNull();
            else
                row.Subject = obj.Subject;
            if (String.IsNullOrEmpty(obj.Body))
                row.SetBodyNull();
            else
                row.Body = obj.Body;
            if (String.IsNullOrEmpty(obj.Location))
                row.SetLocationNull();
            else
                row.Location = obj.Location;
            if ((obj.LastModificationTime != null) && (obj.LastModificationTime != DateTime.MinValue))
                row.LastModificationTime = obj.LastModificationTime;

            if (obj.TaskID.HasValue)
                row.TaskID = obj.TaskID.Value;
            else
                row.SetTaskIDNull();
            if (obj.ContactID.HasValue)
                row.ContactID = obj.ContactID.Value;
            else
                row.SetContactIDNull();
            if (String.IsNullOrEmpty(obj.Message))
                row.SetMessageNull();
            else
                row.Message = obj.Message;

            //Added by tsrdev1
            //Added datetime 06/10/2010
            if (obj.Revision.HasValue)
                row.Revision = obj.Revision.Value;
            else
                row.SetRevisionNull();
            if (!string.IsNullOrEmpty(obj.SubmitterName))
                row.SubmitterName = obj.SubmitterName;
            else
                row.SetSubmitterNameNull();
            //End
            row.Status = Convert.ToInt32(obj.Status);
            row.IsDeleted = obj.IsDeleted;
            row.IsOutOfOffice = obj.IsOutOfOffice;
            bool notSyncTECreatedViaWeb = (TSR.Core.SettingsHelper.TSRMiscNotSyncTECreatedViaWeb);
            if (notSyncTECreatedViaWeb && isTEAdded)
                row.IsCreatedViaWeb = obj.IsCreatedViaWeb; //This field will be update only when user check on Do Not Sync TE created via Web 

            if (obj.LocationID > 0)
                row.LocationID = obj.LocationID;
            else
                row.SetLocationIDNull();

            //added by tsrdev2
            if (obj.IsDeletedOnServer.HasValue)
            {
                row.IsDeletedOnServer = obj.IsDeletedOnServer.Value;
            }
            else
                row.SetIsDeletedOnServerNull();

            try
            {
                if (isTEAdded)
                    MyDataSet.TimeEntry.Rows.Add(row);
                //if (te_app_rows.Length <= 0)
                if (isTE_OUAAdded)
                    MyDataSet.TimeEntry_OutlookAppointment.Rows.Add(te_appRow);
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }

            //rows = MyDataSet.TimeEntry.Select(query);

            return true;
        }

        public bool OverwriteTimeEntry(Guid newID, Guid oldID)
        {
            string query = String.Format(TimeEntry.Property_ID + " = {0}", oldID.ToString());            
            if (MyDataSet.TimeEntry.Rows.Count < 1)
            {
                return false;
            }

            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         where dr[TimeEntry.Property_ID].ToString() == oldID.ToString()
                         select dr;

            var temp_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                               where drApp[TimeEntry.Property_TimeEntryID].ToString() == oldID.ToString()
                               select drApp;
            //rows = dtrows.ToArray();

            //Remove time entry that its id equals newID before overwritting
            RemoveTimeEntry(newID);

            TSRDataSet.TimeEntryRow row;
            TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow;

            if ((dtrows != null) && (dtrows.Count() > 0))
            {                
                row = dtrows.First() as TSRDataSet.TimeEntryRow;
                row.ID = newID;
                if (temp_appRows != null && temp_appRows.Count() > 0)
                {
                    te_appRow = temp_appRows.First() as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                    te_appRow.TimeEntryID = newID;
                }                
            }                        
            
            return true;
        }

        public bool RemoveTimeEntry(Guid teID)
        {
            string query = String.Format(TimeEntry.Property_ID + " = {0}", teID.ToString());                        
            if (MyDataSet.TimeEntry.Rows.Count < 1)
            {
                return false;
            }

            var dtrows = from dr in MyDataSet.TimeEntry.AsEnumerable()
                         where dr[TimeEntry.Property_ID].ToString() == teID.ToString()
                         select dr;

            var temp_appRows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                               where drApp[TimeEntry.Property_TimeEntryID].ToString() == teID.ToString()
                               select drApp;
            //rows = dtrows.ToArray();

            TSRDataSet.TimeEntryRow row;
            TSRDataSet.TimeEntry_OutlookAppointmentRow te_appRow;

            if ((dtrows != null) && (dtrows.Count() > 0))
            {
                row = dtrows.First() as TSRDataSet.TimeEntryRow;                                
                if (temp_appRows != null && temp_appRows.Count() > 0)
                {
                    te_appRow = temp_appRows.First() as TSRDataSet.TimeEntry_OutlookAppointmentRow;
                    MyDataSet.TimeEntry_OutlookAppointment.RemoveTimeEntry_OutlookAppointmentRow(te_appRow);
                }
                MyDataSet.TimeEntry.RemoveTimeEntryRow(row);
            }

            return true;
        }
        public bool DeleteTimeEntry(System.Guid id)
        {
            TimeEntry te = GetTimeEntryByID(id, false);
            if (te != null)
            {
                te.IsDeleted = true;
                return UpdateTimeEntry(te);
            }

            //DataRow teRow = GetTimeEntryRowByID(id);
            //if (teRow != null)
            //{
            //    MyDataSet.TimeEntry.Rows.Remove(teRow);
            //}

            return true;
        }
        public bool DeleteTimeEntryForRecurring(System.Guid id)
        {
            TimeEntry te = GetTimeEntryByID(id, false);
            if (te != null)
            {
                te.IsDeleted = true;
                te.Status = WS.StatusEnum.PendingSubmission;
                return UpdateTimeEntry(te);
            }

            //DataRow teRow = GetTimeEntryRowByID(id);
            //if (teRow != null)
            //{
            //    MyDataSet.TimeEntry.Rows.Remove(teRow);
            //}

            return true;
        }

        /// <summary>
        /// fills list of TimeEntry objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        public TimeEntryList FillTimeEntries(IEnumerable rows)
        {
            TimeEntryList list = new TimeEntryList();

            foreach (DataRow row in rows)
            {                
                TimeEntry te = FillTimeEntry(row);
                if (te != null)
                    list.Add(te);                             
            }

            return list;
        }

        /// <summary>
        /// Overloaded FillTimeEntry method, if Outlook Item ID is not available, use this
        /// </summary>
        /// <param name="timeEntryRow"></param>
        /// <returns></returns>
        private TimeEntry FillTimeEntry(DataRow timeEntryRow)
        {
            TSRDataSet.TimeEntryRow teRow = timeEntryRow as TSRDataSet.TimeEntryRow;
                          
            if (teRow != null)
            {
                //var dtrows = (from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                //              where drApp[TimeEntry.Property_TimeEntryID].ToString() == teRow.ID.ToString()
                //              select drApp).SingleOrDefault();
                TSRDataSet.TimeEntry_OutlookAppointmentRow row;
                var dtrows = from drApp in MyDataSet.TimeEntry_OutlookAppointment.AsEnumerable()
                              where drApp[TimeEntry.Property_TimeEntryID].ToString() == teRow.ID.ToString()
                              select drApp;
                if ((dtrows == null) || (dtrows != null && (dtrows.Count() < 1)))
                {
                    row = MyDataSet.TimeEntry_OutlookAppointment.NewTimeEntry_OutlookAppointmentRow();
                    row.TimeEntryID = teRow.ID;
                    row.OutlookItemID = Constants.NONEXISTING_OUTLOOK_APPOINTMENT_ID;
                }
                else
                {
                    List<DataRow> listRows = new List<DataRow>();                    
                    row = dtrows.First();

                    for (int i = 1; i < dtrows.Count(); i++)
                        listRows.Add(dtrows.ElementAt(i));

                    foreach (TSRDataSet.TimeEntry_OutlookAppointmentRow temp in listRows)
                        MyDataSet.TimeEntry_OutlookAppointment.RemoveTimeEntry_OutlookAppointmentRow(temp);
                }
                return FillTimeEntry(timeEntryRow, row);
            }            
            return null;
        }

        /// <summary>
        /// fills a single TimeEntry object from DataRowView object , data retrieved from local storage is
        /// being filled in TimeEntry object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private TimeEntry FillTimeEntry(DataRow timeEntryRow, DataRow te_AppRow)
        {
            TSRDataSet.TimeEntryRow teRow = timeEntryRow as TSRDataSet.TimeEntryRow;
            TSRDataSet.TimeEntry_OutlookAppointmentRow teAppRow = te_AppRow as TSRDataSet.TimeEntry_OutlookAppointmentRow;

            if ((teRow != null) && (teAppRow != null))
            {
                TimeEntry obj;
                string outlookItemID = string.Empty;
                try
                {
                    outlookItemID = teAppRow.OutlookItemID;
                }
                catch(Exception exp)
                {
                    Core.Logging.LoggingHandler.LogError(exp);
                    outlookItemID = string.Empty;
                }   
                if (string.IsNullOrEmpty(outlookItemID))
                    obj = new TimeEntry(teRow.ID);                
                else
                    obj = new TimeEntry(teRow.ID,outlookItemID);

                //Added by tsrdev1
                if (!teAppRow.IsCalendarIDNull())
                    obj.CalendarID = teAppRow.CalendarID;

                obj.StartTimeStamp = teRow.StartTime;
                obj.EndTimeStamp = teRow.EndTime;
                obj.TimeZone = teRow.TimeZone;
                obj.OrganizationID = teRow.OrganizationID;
                obj.ProjectID = teRow.ProjectID;
                obj.ActivityID = teRow.ActivityID;
                if (!teRow.IsLocationIDNull() && teRow.LocationID > 0)
                    obj.LocationID = teRow.LocationID;

                if (!teRow.IsIsOutOfOfficeNull())
                    obj.IsOutOfOffice = teRow.IsOutOfOffice;
                else
                    obj.IsOutOfOffice = false;

                if (!teRow.IsIsCreatedViaWebNull())
                    obj.IsCreatedViaWeb = teRow.IsCreatedViaWeb;
                else
                    obj.IsCreatedViaWeb = false;
                //obj.SubmittedBy will be set on service                

                if (!teRow.IsIsRecurringNull())
                    obj.IsRecurring = teRow.IsRecurring;
                else
                    obj.IsRecurring = false;

                if (!teRow.IsSubjectNull())
                    obj.Subject = teRow.Subject;
                if (!teRow.IsBodyNull())
                    obj.Body = teRow.Body;
                if (!teRow.IsLocationNull())
                    obj.Location = teRow.Location;
                if (!teRow.IsTaskIDNull())
                    obj.TaskID = teRow.TaskID;
                if (!teRow.IsContactIDNull())
                    obj.ContactID = teRow.ContactID;
                if (!teRow.IsMessageNull())
                    obj.Message = teRow.Message;
                if (!teRow.IsRecurrenceIDNull())
                    obj.RecurrenceID = teRow.RecurrenceID;
                if(!teRow.IsLastModificationTimeNull())
                    obj.LastModificationTime = teRow.LastModificationTime;
                obj.Status = (WS.StatusEnum)teRow.Status;                
                obj.IsDeleted = teRow.IsDeleted;

                //Added by tsrdev1
                //Added datetime 05/10/2010
                if (!teRow.IsRevisionNull())
                    obj.Revision = teRow.Revision;
                //Added by tsrdev1
                //Added datetime 06/10/2010
                if (!teRow.IsSubmitterNameNull())
                    obj.SubmitterName = teRow.SubmitterName;
                //added by tsrdev2
                if (!teRow.IsIsDeletedOnServerNull())
                {
                    obj.IsDeletedOnServer = teRow.IsDeletedOnServer;
                }

                //Added by tsrdev1
                //Added datetime 27/10/2010
                if (!teRow.IsIsRecurringNull())
                    obj.IsRecurring = teRow.IsRecurring;
                return obj;
            }

            return null;
        }
    }
}
