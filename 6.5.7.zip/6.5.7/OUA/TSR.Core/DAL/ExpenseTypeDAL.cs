using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for ExpenseType
    /// </summary>
    internal class ExpenseTypeDAL : BaseDAL
    {
        private DataRow GetExpenseTypeRowByID(Int64 id)
        {
            return GetExpenseTypeRowByID(id, true);
        }

        private DataRow GetExpenseTypeRowByID(Int64 id,bool visible)
        {
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in MyDataSet.ExpenseType.AsEnumerable()
                         where dr["ID"].ToString() == id.ToString() && dr["Visible"].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ExpenseType GetExpenseTypeByID(Int64 id)
        {
            return GetExpenseTypeByID(id, true);
        }
        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ExpenseType GetExpenseTypeByID(Int64 id, bool visible)
        {
            DataRow row = GetExpenseTypeRowByID(id, visible);
            if (row != null)
            {
                return FillExpenseType(row,visible);
            }

            return null;
        }


        /// <summary>
        /// retrieves all projects
        /// </summary>
        /// <returns></returns>
        public ExpenseTypeList GetAllExpenseTypes()
        {
            return GetAllExpenseTypes(true);
        }

        /// <summary>
        /// retrieves all projects
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ExpenseTypeList GetAllExpenseTypes(bool visible)
        {
            return FillExpenseTypeList(MyDataSet.ExpenseType.Rows, visible);
        }

        /// <summary>
        /// updates a project
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateExpenseType(ExpenseType obj)
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.ExpenseType.Rows.Count > 0)
            {
                var dtrows = from dr in MyDataSet.ExpenseType.AsEnumerable()
                             where dr["ID"].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.ExpenseTypeRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ExpenseTypeRow;
            else
                row = MyDataSet.ExpenseType.NewExpenseTypeRow();
            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Visible = obj.Visible;

                if (obj.DefaultValue.HasValue)
                    row.DefaultValue = obj.DefaultValue.Value;
                else
                    row.DefaultValue = 0;
                if (!string.IsNullOrEmpty(obj.ForeignKey))
                    row.ForeignKey = obj.ForeignKey;
                else
                    row.ForeignKey = "";
                row.IsActive = obj.IsActive;
                row.IsLockedValue = obj.IsLockedValue;

                if (rows.Length <= 0)
                {
                    try
                    {
                        MyDataSet.ExpenseType.Rows.Add(row);
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogUnhandledException(new Logging.Log()
                        {
                            MessageDetail = ex.ToString(),
                            MessageSummary = string.Format("ExpenseType ID: {0}, Name: {1}", row.ID, row.Name)
                        });
                    }
                    finally {
                    }
                }
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.ExpenseType.Rows.Remove(row);
            }
            return true;
        }

        /// <summary>
        /// fills list of projects from local storage data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private ExpenseTypeList FillExpenseTypeList(IEnumerable rows)
        {
            return FillExpenseTypeList(rows, true);
        }

        /// <summary>
        /// fills list of projects from local storage data, utility method
        /// </summary>
        /// <param name="rows"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private ExpenseTypeList FillExpenseTypeList(IEnumerable rows, bool visible)
        {
            ExpenseTypeList list = new ExpenseTypeList();

            foreach (DataRow row in rows)
            {
                ExpenseType obj = FillExpenseType(row, visible);
                if (obj != null)
                    list.Add(obj);
            }

            return list;
        }

        /// <summary>
        /// fills ExpenseType object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private ExpenseType FillExpenseType(DataRow row)
        {
            return FillExpenseType(row, true);
        }

        /// <summary>
        /// fills ExpenseType object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private ExpenseType FillExpenseType(DataRow row, bool visible)
        {
            TSRDataSet.ExpenseTypeRow objRow = row as TSRDataSet.ExpenseTypeRow;

            if ((objRow != null) && (objRow.Visible == visible))
            {
                ExpenseType obj = new ExpenseType();

                obj.ID = objRow.ID;
                obj.Name = objRow.Name;
                obj.Visible = objRow.Visible;
                if(!objRow.IsDefaultValueNull())
                    obj.DefaultValue = objRow.DefaultValue;
                if (!objRow.IsForeignKeyNull())
                    obj.ForeignKey = objRow.ForeignKey;
                obj.IsActive = objRow.IsActive;
                obj.IsLockedValue = objRow.IsLockedValue;

                return obj;
            }
            return null;
        }
    }
}
