﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    internal class Organization_ContactDAL : BaseDAL
    {
        internal Entity.Organization_ContactList GetAllOrganization_Contact()
        {
            return FillOrganization_Contact(MyDataSet.Organization_Contact.Rows);
        }

        private Entity.Organization_ContactList FillOrganization_Contact(System.Data.DataRowCollection rows)
        {
            Entity.Organization_ContactList list = new Entity.Organization_ContactList();

            foreach (DataRow row in rows)
            {
                Entity.Organization_Contact orgContact = FillOrganizationContact(row);
                if (orgContact != null)
                    list.Add(orgContact);
            }

            return list;
        }

        private Entity.Organization_Contact FillOrganizationContact(DataRow row)
        {
            TSRDataSet.Organization_ContactRow cntRow = row as TSRDataSet.Organization_ContactRow;

            if (cntRow != null)
            {
                Entity.Organization_Contact obj = new Entity.Organization_Contact();

                obj.ContactID = cntRow.ContactID;
                obj.OrganizationID = cntRow.OrganizationID;
                if (!cntRow.IsModifiedNull())
                    obj.Reversion = cntRow.Modified;

                return obj;
            }
            return null;
        }

        internal bool RemoveOrganizationContactRelation(long orgID, long cntID)
        {
            DataRow teRow = GetOrganizationContactRowByID(orgID, cntID);
            if (teRow != null)
            {
                MyDataSet.Organization_Contact.Rows.Remove(teRow);
            }
            return true;
        }

        private DataRow GetOrganizationContactRowByID(long orgID, long cntID)
        {
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Organization_Contact.Property_OrganizationID].ToString() == orgID.ToString() && dr[Organization_Contact.Property_ContactID].ToString() == cntID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        internal bool AddOrganizationContactRelation(long orgID, long cntID)
        {
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Organization_Contact.Property_OrganizationID].ToString() == orgID.ToString() && dr[Organization_Contact.Property_ContactID].ToString() == cntID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length <= 0)
            {
                TSRDataSet.Organization_ContactRow row = MyDataSet.Organization_Contact.NewOrganization_ContactRow();
                row.OrganizationID = orgID;
                row.ContactID = cntID;
                MyDataSet.Organization_Contact.Rows.Add(row);
            }
            return true;
        }
    }
}
