using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using TSR.Core.Entity.List;
using TSR.Core.Entity;
using System.Xml;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using WS = TSR.Core.UserAgentService;
using System.Collections;
using System.Data;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Name: ResourceDetailDAL
    /// Description: Data Access Class for LanguageResources class
    /// </summary>
    internal class LanguageResourcesDAL : BaseDAL
    {
        /// <summary>
        /// fills languageresources objects from enumerable rows
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private LanguageResourcesList FillLanguageResources(IEnumerable rows)
        {
            LanguageResourcesList list = new LanguageResourcesList();

            foreach (DataRow row in rows)
            {
                list.Add(FillLanguageResources(row));
            }

            return list;
        }

        /// <summary>
        /// fills languageresources objects from enumerable rows for english
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private LanguageResourcesList FillLanguageResourcesForEnglish(IEnumerable rows)
        {
            LanguageResourcesList list = new LanguageResourcesList();

            foreach (DataRow row in rows)
            {
                list.Add(FillLanguageResourcesForEnglish(row));
            }

            return list;
        }

        /// <summary>
        /// fills languageresources object from data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private LanguageResources FillLanguageResources(DataRow row)
        {
            TSRDataSet.LanguageResourcesRow lanResRow = row as TSRDataSet.LanguageResourcesRow;

            if (lanResRow != null)
            {
                LanguageResources obj = new LanguageResources();

                obj.ID = lanResRow.ID;
                obj.LanguageID = lanResRow.LanguageID;
                obj.LanguageName = lanResRow.LanguageName;
                obj.ResourceKey = lanResRow.ResourceKey;
                obj.ResourceValue = lanResRow.ResourceValue;
                return obj;
            }

            return null;
        }

        /// <summary>
        /// fills languageresources object from data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private LanguageResources FillLanguageResourcesForEnglish(DataRow row)
        {
            ResourceKeys.LanguageResourcesRow lanResRow = row as ResourceKeys.LanguageResourcesRow;

            if (lanResRow != null)
            {
                LanguageResources obj = new LanguageResources();

                obj.ID = lanResRow.ID;
                obj.LanguageID = lanResRow.LanguageID;
                obj.LanguageName = lanResRow.LanguageName;
                obj.ResourceKey = lanResRow.ResourceKey;
                obj.ResourceValue = lanResRow.ResourceValue;
                return obj;
            }

            return null;
        }

        /// <summary>
        /// updates language resources
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateLanguageResources(LanguageResources obj)
        {
            DataRow[] rows = new DataRow[] { };
            DataRow[] engRows = new DataRow[] { };
            try
            {
                if (MyDataSet.LanguageResources.Rows.Count > 0)
                {
                    var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                                 where langs[LanguageResources.Property_LanguageID].ToString() == obj.LanguageID && langs[LanguageResources.Property_ResourceKey].ToString() == obj.ResourceKey
                                 && langs[LanguageResources.Property_LanguageName].ToString() == obj.LanguageName
                                 select langs;
                    if (lanRes != null)
                        rows = lanRes.ToArray();
                }
//#if(DEBUG)
//                if (ResourceDataSet.LanguageResources.Rows.Count > 0)
//                {
//                    var emglanRes = from langs in ResourceDataSet.LanguageResources.AsEnumerable()
//                                    where langs[LanguageResources.Property_LanguageID].ToString() == Constants.DEFAULT_CULTURE_LCID && langs[LanguageResources.Property_ResourceKey].ToString() == obj.ResourceKey
//                                    && langs[LanguageResources.Property_LanguageName].ToString() == Constants.DEFAULT_LANGUAGE_NAME
//                                    select langs;
//                    if (emglanRes != null)
//                        engRows = emglanRes.ToArray();
//                }
//#endif

            }
            catch (Exception exp)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(exp);
                System.Console.WriteLine(exp.Message);
            }
            TSRDataSet.LanguageResourcesRow row;
//#if(DEBUG)
//            ResourceKeys.LanguageResourcesRow resourceRow = ResourceDataSet.LanguageResources.NewLanguageResourcesRow();
//#endif
            if (rows.Length > 0 && (obj.ID != 0))
            {
                row = rows[0] as TSRDataSet.LanguageResourcesRow;
                row.ID = obj.ID;
            }
            else
                row = MyDataSet.LanguageResources.NewLanguageResourcesRow();
            
            row.LanguageID = obj.LanguageID;
            row.LanguageName = obj.LanguageName;
            row.ResourceKey = obj.ResourceKey;
            row.ResourceValue = obj.ResourceValue;
//#if(DEBUG)
//            resourceRow.LanguageID = Constants.DEFAULT_CULTURE_LCID;
//            resourceRow.LanguageName = Constants.DEFAULT_LANGUAGE_NAME;
//            resourceRow.ResourceKey = obj.ResourceKey;
//            resourceRow.ResourceValue = obj.ResourceValue;
//#endif

            if (rows.Length <= 0)
                MyDataSet.LanguageResources.Rows.Add(row);
//#if(DEBUG)
//            if (engRows.Length == 0)
//                ResourceDataSet.LanguageResources.Rows.Add(resourceRow);
//#endif
            return true;
        }

        /// <summary>
        /// retrieves all LanguageResources objects by Language Id
        /// </summary>
        /// <param name="languageID"></param>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResourcesByLanguageId(String languageID)
        {
            var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageID].Equals(languageID)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return FillLanguageResources(lanRes);
            }

            return new LanguageResourcesList();
        }

        /// <summary>
        /// retrieves all LanguageResources objects by Language Name
        /// added by tsrdev2
        /// </summary>
        /// <param name="languageName"></param>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResourcesByLanguageName(String languageName)
        {
            var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageName].Equals(languageName)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return FillLanguageResources(lanRes);
            }

            return new LanguageResourcesList();
        }

        /// <summary>
        /// retrieves Language ID by Language Name
        /// added by tsrdev2
        /// </summary>
        /// <param name="languageName"></param>
        /// <returns></returns>
        public String GetLanguageIDByLanguageName(String languageName)
        {
            var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageName].Equals(languageName)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return lanRes.First().LanguageID;
            }
            return String.Empty;
        }

        /// <summary>
        /// retrieves all LanguageResources objects by for english
        /// </summary>
        /// <param name="languageID"></param>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResourcesForEnglish()
        {
            var lanRes = from langs in ResourceDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageName].Equals(Constants.DEFAULT_LANGUAGE_NAME)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return FillLanguageResourcesForEnglish(lanRes);
            }

            return new LanguageResourcesList();
        }

        /// <summary>
        /// retrieves LanguageResource object by Language Id and Resource Key
        /// </summary>
        /// <param name="languageID"></param>
        /// <param name="resourceKey"></param>
        /// <returns></returns>
        public LanguageResources GetLanguageResourcesByLanguageIDAndResourceKey(String languageID, String resourceKey)
        {
            var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageID].Equals(languageID) && langs[LanguageResources.Property_ResourceKey].Equals(resourceKey)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return FillLanguageResources(lanRes)[0];
            }
            return new LanguageResources();
        }

        /// <summary>
        /// retrieves LanguageResource object by Language Id and Resource Key
        /// </summary>
        /// <param name="languageID"></param>
        /// <param name="resourceKey"></param>
        /// <returns></returns>
        public LanguageResources GetLanguageResourcesByLanguageNameAndResourceKey(String languageName, String resourceKey)
        {
            var lanRes = from langs in MyDataSet.LanguageResources.AsEnumerable()
                         where langs[LanguageResources.Property_LanguageName].Equals(languageName) && langs[LanguageResources.Property_ResourceKey].Equals(resourceKey)
                         select langs;

            if (lanRes.Count() > 0)
            {
                return FillLanguageResources(lanRes)[0];
            }
            return new LanguageResources();
        }

        /// <summary>
        /// retrieves All LanguageResources objects
        /// </summary>
        /// <returns></returns>
        public LanguageResourcesList GetAllLanguageResources()
        {
            return FillLanguageResources(MyDataSet.LanguageResources.Rows);
        }

        /// <summary>
        /// retrieves LaguageResouces object by current culture
        /// </summary>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResourcesByCurrentCulture()
        {
            String languageID = System.Threading.Thread.CurrentThread.CurrentUICulture.Name;
            LanguageResourcesList list = GetLanguageResourcesByLanguageId(languageID);
            if (!System.Threading.Thread.CurrentThread.CurrentUICulture.IsNeutralCulture && list.Count == 0)
            {
                languageID = System.Threading.Thread.CurrentThread.CurrentUICulture.TwoLetterISOLanguageName;
                list = GetLanguageResourcesByLanguageId(languageID);
            }
            return list;
        }
    }
}
