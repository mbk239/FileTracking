using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for Activity object
    /// </summary>
    internal class ActivityDAL : BaseDAL
    {

        private DataRow GetActivityRowByID(Int64 id)
        {
            return (GetActivityRowByID(id,true));
        }       

        private DataRow GetActivityRowByID(Int64 id, bool visible)
        {
            //string query = String.Format(Activity.Property_ID + " = {0} and " + Activity.Property_Visible + "= {1}", id.ToString(), visible);
            //DataRow[] rows = MyDataSet.Activity.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;

            var dtrows = from dr in MyDataSet.Activity.AsEnumerable()
                         where dr[Activity.Property_ID].ToString() == id.ToString() && dr[Activity.Property_Visible].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves activity by activity id
        /// </summary>
        /// <param name="id"></param>        
        /// <returns></returns>
        public Activity GetActivityByID(Int64 id)
        {
            return GetActivityByID(id, true);
        }

        /// <summary>
        /// retrieves activity by activity id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Activity GetActivityByID(Int64 id,bool visible)
        {
            DataRow row = GetActivityRowByID(id,visible);
            if (row != null)
            {
                return FillActivity(row,visible);
            }

            return null;
        }

        /// <summary>
        /// retrieves all activities
        /// </summary>        
        /// <returns></returns>
        public ActivityList GetAllActivities()
        {
            return GetAllActivities(true);
        }

        /// <summary>
        /// retrieves all activities
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ActivityList GetAllActivities(bool visible)
        {
            return FillActivities(MyDataSet.Activity.Rows,visible);
        }

        /// <summary>
        /// retrieves activties for Project
        /// </summary>
        /// <param name="projectID"></param>        
        /// <returns></returns>
        public ActivityList GetActivitiesForProject(Int64 projectID)
        {
            return GetActivitiesForProject(projectID, true);
        }

        /// <summary>
        /// retrieves activties for Project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ActivityList GetActivitiesForProject(Int64 projectID,bool visible)
        {
            var activities = from prjs in MyDataSet.Project.AsEnumerable()
                             join prj_act in MyDataSet.Project_Activity.AsEnumerable()
                             on (long)prjs[Project.Property_ID] equals (long)prj_act[Project.Property_ProjectID]
                             join acts in MyDataSet.Activity.AsEnumerable()
                             on (long)prj_act[Activity.Property_ActivityID] equals (long)acts[Activity.Property_ID]
                             where (long)prjs[Project.Property_ID] == projectID && (bool)acts[Activity.Property_IsActivate] 
                             select acts;

            if (activities.Count() > 0)
            {
                return FillActivities(activities,visible);
            }

            return new ActivityList();
        }

         /// <summary>
        /// retrieves activities for multiple projects
        /// </summary>
        /// <param name="projectIDs"></param>        
        /// <returns></returns>
        public ActivityList GetActivitiesForMultipleProjects(List<Int64> projectIDs)
        {
            return GetActivitiesForMultipleProjects(projectIDs, true);
        }
        /// <summary>
        /// retrieves activities for multiple projects
        /// </summary>
        /// <param name="projectIDs"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ActivityList GetActivitiesForMultipleProjects(List<Int64> projectIDs,bool visible)
        {
            var activities = (from prjs in MyDataSet.Project.AsEnumerable()
                             join prj_act in MyDataSet.Project_Activity.AsEnumerable()
                             on (long)prjs[Project.Property_ID] equals (long)prj_act[Project.Property_ProjectID]
                             join acts in MyDataSet.Activity.AsEnumerable()
                             on (long)prj_act[Activity.Property_ActivityID] equals (long)acts[Activity.Property_ID]
                             where projectIDs.Contains((long)prjs[Project.Property_ID]) && (bool)acts[Activity.Property_IsActivate]
                             select acts).Distinct();
            
            if (activities.Count() > 0)
            {
                return FillActivities(activities,visible);
            }

            return new ActivityList();
        }

        /// <summary>
        /// assign activity to project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public bool AssignProject(long projectID, long activityID)
        {
            //string query = String.Format(Project.Property_ProjectID + " = {0} And " + Activity.Property_ActivityID + " = {1}",
            //    projectID.ToString(), activityID.ToString());
            //DataRow[] rows = MyDataSet.Project_Activity.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Project.Property_ProjectID].ToString() == projectID.ToString() && dr[Activity.Property_ActivityID].ToString() == activityID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length <= 0)
            {
                TSRDataSet.Project_ActivityRow row = MyDataSet.Project_Activity.NewProject_ActivityRow();
                row.ProjectID = projectID;
                row.ActivityID = activityID;
                MyDataSet.Project_Activity.Rows.Add(row);
                //MyDataSet.AcceptChanges();
            }

            return true;
        }

        /// <summary>
        /// Remove activity from project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public bool RemoveProject(long projectID, long activityID)
        {
            //string query = String.Format(Project.Property_ProjectID + " = {0} And " + Activity.Property_ActivityID + " = {1}",
            //    projectID.ToString(), activityID.ToString());
            //DataRow[] rows = MyDataSet.Project_Activity.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Project.Property_ProjectID].ToString() == projectID.ToString() && dr[Activity.Property_ActivityID].ToString() == activityID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Project_ActivityRow row;
                    row = dtRow as TSRDataSet.Project_ActivityRow;
                    MyDataSet.Project_Activity.Rows.Remove(row);
                }                                
                //MyDataSet.AcceptChanges();
            }

            return true;
        }

        /// <summary>
        /// Remove all activity from a project
        /// </summary>
        /// <param name="projectID"></param>        
        /// <returns></returns>
        public bool RemoveAllActitvitiesFromProject(long projectID)
        {
            //string query = String.Format(Project.Property_ProjectID + " = {0}",
            //    projectID.ToString());
            //DataRow[] rows = MyDataSet.Project_Activity.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Project.Property_ProjectID].ToString() == projectID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Project_ActivityRow row;
                    row = dtRow as TSRDataSet.Project_ActivityRow;
                    MyDataSet.Project_Activity.Rows.Remove(row);
                }
                //MyDataSet.AcceptChanges();
            }

            return true;
        }
        /// <summary>
        /// Remove activity from all project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <returns></returns>
        public bool RemoveActivityFromAllProjects(long activityID)
        {
            //string query = String.Format(Activity.Property_ActivityID + " = {0}",
            //  activityID.ToString());
            //DataRow[] rows = MyDataSet.Project_Activity.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Activity.Property_ActivityID].ToString() == activityID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Project_ActivityRow row;
                    row = dtRow as TSRDataSet.Project_ActivityRow;
                    MyDataSet.Project_Activity.Rows.Remove(row);
                }
                //MyDataSet.AcceptChanges();
            }

            return true;
        }


        /// <summary>
        /// updates activity
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateActivity(Activity obj)
        {
            //string query = String.Format(Activity.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Activity.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Activity.Rows.Count > 0)
            {
                //rows = MyDataSet.Activity.Select(query);
                //edit by tsrdev2 - 21 Jun 2011
                var dtrows = from dr in MyDataSet.Activity.AsEnumerable()
                             where dr[Activity.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.ActivityRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ActivityRow;
            else
                row = MyDataSet.Activity.NewActivityRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Visible = obj.Visible;
                row.Modified = obj.Modified;
                row.IsActivate = obj.IsActivate;

                if (!string.IsNullOrEmpty(obj.ActivityTypeName))
                    row.ActivityTypeName = obj.ActivityTypeName;
                else
                    row.ActivityTypeName = "";
                if (!string.IsNullOrEmpty(obj.Description))
                    row.Description = obj.Description;
                else
                    row.Description = "";

                if (rows.Length <= 0)
                    MyDataSet.Activity.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.Activity.Rows.Remove(row);
            }
            return true;
        }

        /// <summary>
        /// fills activity objects from enumerable rows
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private ActivityList FillActivities(IEnumerable rows)
        {
            return FillActivities(rows, true);
        }

        /// <summary>
        /// fills activity objects from enumerable rows
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private ActivityList FillActivities(IEnumerable rows,bool visible)
        {
            ActivityList list = new ActivityList();

            foreach (DataRow row in rows)
            {
                Activity act = FillActivity(row,visible);
                if (act != null)
                    list.Add(act);
            }

            return list;
        }

        /// <summary>
        /// fills activity object from data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Activity FillActivity(DataRow row)
        {
            return FillActivity(row, true);
        }

        /// <summary>
        /// fills activity object from data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Activity FillActivity(DataRow row,bool visible)
        {
            TSRDataSet.ActivityRow actRow = row as TSRDataSet.ActivityRow;

            if ((actRow != null) &&(actRow.Visible == visible))
            {
                Activity obj = new Activity();

                obj.ID = actRow.ID;
                obj.Name = actRow.Name;
                obj.Visible = actRow.Visible;
                obj.IsActivate = actRow.IsActivate;

                if (!actRow.IsModifiedNull())
                    obj.Modified = actRow.Modified;
                if(!actRow.IsActivityTypeNameNull())
                    obj.ActivityTypeName = actRow.ActivityTypeName;
                if (!actRow.IsDescriptionNull())
                    obj.Description = actRow.Description;

                return obj;
            }

            return null;
        }
    }
}
