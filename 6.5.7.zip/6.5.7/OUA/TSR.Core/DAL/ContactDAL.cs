using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for Contact object
    /// </summary>
    internal class ContactDAL : BaseDAL
    {
        private DataRow GetContactRowByID(Int64 id)
        {
            return GetContactRowByID(id, true);
        }

        private DataRow GetContactRowByID(Int64 id,bool visible)
        {
            //string query = String.Format(Contact.Property_ID + " = {0} and "+Contact.Property_Visible+"={1}", id.ToString(),visible);
            //DataRow[] rows = MyDataSet.Contact.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in MyDataSet.Contact.AsEnumerable()
                         where dr[Contact.Property_ID].ToString() == id.ToString() && dr[Contact.Property_Visible].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }
        /// <summary>
        /// gets contact object by contact id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Contact GetContactByID(Int64 id)
        {
            return GetContactByID(id, true);
        }

        /// <summary>
        /// gets contact object by contact id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Contact GetContactByID(Int64 id,bool visible)
        {
            DataRow row = GetContactRowByID(id,visible);
            if (row != null)
            {
                return FillContact(row,visible);
            }

            return null;
        }

        /// <summary>
        /// retrieves all contacts
        /// </summary>
        /// <returns></returns>
        public ContactList GetAllContacts()
        {
            return GetAllContacts(true);
        }

        /// <summary>
        /// retrieves all contacts
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ContactList GetAllContacts(bool visible)
        {
            return FillContacts(MyDataSet.Contact.Rows,visible);
        }

        /// <summary>
        /// retrieves contacts for an organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public ContactList GetContactsForOrganization(Int64 organizationID)
        {
            return GetContactsForOrganization(organizationID, true);
        }
        /// <summary>
        /// retrieves contacts for an organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ContactList GetContactsForOrganization(Int64 organizationID,bool visible)
        {
            var contacts = from orgs in MyDataSet.Organization.AsEnumerable()
                           join org_cnt in MyDataSet.Organization_Contact.AsEnumerable()
                           on (long)orgs[Organization.Property_ID] equals (long)org_cnt[Organization.Property_OrganizationID]
                           join cnts in MyDataSet.Contact.AsEnumerable()
                           on (long)org_cnt[Contact.Property_ContactID] equals (long)cnts[Contact.Property_ID]
                           where (long)orgs[Organization.Property_ID] == organizationID
                           select cnts;

            if (contacts.Count() > 0)
            {
                return FillContacts(contacts,visible);
            }

            return new ContactList();
        }
        /// <summary>
        /// links contact with an organization [relational table update]
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="contactID"></param>
        /// <returns></returns>
        public bool AssignOrganization(long organizationID, long contactID)
        {
            //string query = String.Format(Organization.Property_OrganizationID + " = {0} And " + Contact.Property_ContactID + " = {1}",
            //    organizationID.ToString(), contactID.ToString());
            //DataRow[] rows = MyDataSet.Organization_Contact.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Organization.Property_OrganizationID].ToString() == organizationID.ToString() && dr[Contact.Property_ContactID].ToString() == contactID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();

            if (rows.Length <= 0)
            {
                TSRDataSet.Organization_ContactRow row = MyDataSet.Organization_Contact.NewOrganization_ContactRow();
                row.OrganizationID = organizationID;
                row.ContactID = contactID;
                MyDataSet.Organization_Contact.Rows.Add(row);
            }

            return true;
        }
        /// <summary>
        /// remove link contact with an organization [relational table update]
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="contactID"></param>
        /// <returns></returns>
        public bool RemoveOrganization(long organizationID, long contactID)
        {
            //string query = String.Format(Organization.Property_OrganizationID + " = {0} And " + Contact.Property_ContactID + " = {1}",
            //    organizationID.ToString(), contactID.ToString());
            //DataRow[] rows = MyDataSet.Organization_Contact.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Organization.Property_OrganizationID].ToString() == organizationID.ToString() && dr[Contact.Property_ContactID].ToString() == contactID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                TSRDataSet.Organization_ContactRow row;
                row = rows[0] as TSRDataSet.Organization_ContactRow;                
                MyDataSet.Organization_Contact.Rows.Remove(row);
            }

            return true;
        }
        /// <summary>
        /// remove link contact with all organizations [relational table update]
        /// </summary>        
        /// <param name="contactID"></param>
        /// <returns></returns>
        public bool RemoveContactFromAllOrganizations(long contactID)
        {
            //string query = String.Format(Contact.Property_ContactID + " = {0}",
            //    contactID.ToString());
            //DataRow[] rows = MyDataSet.Organization_Contact.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Contact.Property_ContactID].ToString() == contactID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();

            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Organization_ContactRow row;
                    row = dtRow as TSRDataSet.Organization_ContactRow;
                    MyDataSet.Organization_Contact.Rows.Remove(row);
                }                
            }

            return true;
        }
        /// <summary>
        /// remove link all contact with an organizations [relational table update]
        /// </summary>        
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public bool RemoveAllContactFromOrganization(long organizationID)
        {
            //string query = String.Format(Organization.Property_OrganizationID + " = {0}",
            //    organizationID.ToString());
            //DataRow[] rows = MyDataSet.Organization_Contact.Select(query);

            //edit by tsrdev2 - 21 Jun 2011
            var dtrows = from dr in MyDataSet.Organization_Contact.AsEnumerable()
                         where dr[Organization.Property_OrganizationID].ToString() == organizationID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Organization_ContactRow row;
                    row = dtRow as TSRDataSet.Organization_ContactRow;
                    MyDataSet.Organization_Contact.Rows.Remove(row);
                }
            }

            return true;
        }
        /// <summary>
        /// updates contact object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateContact(Contact obj)
        {
            //string query = String.Format(Contact.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Contact.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Contact.Rows.Count > 0)
            {
                //rows = MyDataSet.Contact.Select(query);

                //edit by tsrdev2 - 21 Jun 2011
                var dtrows = from dr in MyDataSet.Contact.AsEnumerable()
                             where dr[Contact.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.ContactRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ContactRow;
            else
                row = MyDataSet.Contact.NewContactRow();
            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Visible = obj.Visible;

                if (rows.Length <= 0)
                    MyDataSet.Contact.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.Contact.Rows.Remove(row);
            }
            return true;
        }

        /// <summary>
        /// fills contactlist from dataview [like table]
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private ContactList FillContacts(IEnumerable rows)
        {
            return FillContacts(rows, true);
        }
        /// <summary>
        /// fills contactlist from dataview [like table]
        /// </summary>
        /// <param name="view"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private ContactList FillContacts(IEnumerable rows,bool visible)
        {
            ContactList list = new ContactList();

            foreach (DataRow row in rows)
            {
                if (FillContact(row,visible ) != null)
                list.Add(FillContact(row,visible));
            }

            return list;
        }

        /// <summary>
        /// fills contact object from a data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Contact FillContact(DataRow row)
        {
            return FillContact(row, true);
        }

        /// <summary>
        /// fills contact object from a data row
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private Contact FillContact(DataRow row,bool visible)
        {
            TSRDataSet.ContactRow cntRow = row as TSRDataSet.ContactRow;

            if ((cntRow != null) && (cntRow.Visible == visible))
            {
                Contact obj = new Contact();

                obj.ID = cntRow.ID;
                obj.Name = cntRow.Name;
                obj.Visible = cntRow.Visible;

                if(!cntRow.IsModifiedNull())
                    obj.Modified = cntRow.Modified;

                return obj;
            }

            return null;
        }
    }
}
