﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TSR.Core.Entity;
using System.Collections;

namespace TSR.Core.DAL
{
    internal class RecurringMasterDAL : BaseDAL
    {               

        /// <summary>
        /// retrieves recurring master by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private DataRow GetRecurringMasterRowByID(string id)
        {
            if (MyDataSet.RecurringMaster.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            var dtrows = from dr in MyDataSet.RecurringMaster.AsEnumerable()
                                          where dr[RecurringMaster.Property_ID].ToString() == id.ToString()
                                          select dr;
            rows = dtrows.ToArray();
            if (rows.Length > 0)
                return rows[0];
            return null;
        }

        /// <summary>
        /// retrieves RecurringMaster object from RecurringMaster [outlook recurring appointment's master appointment] ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public RecurringMaster GetRecurringMasterByID(string id)
        {
            DataRow row = GetRecurringMasterRowByID(id);
            if (row != null)
            {
                return FillRecurringMaster(row);
            }

            return null;
        }

        /// <summary>
        /// Get recurring series information filtering with subject, list of organizations, list of projects,
        /// list of activities, start time and end time
        /// </summary>
        /// <param name="subject"></param>
        /// <param name="lstOrganizationID"></param>
        /// <param name="lstProjectID"></param>
        /// <param name="lstActivityID"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        public List<RecurringMaster> GetDataByAllParams(string subject, List<Int64> lstOrganizationID, List<Int64> lstProjectID, List<Int64> lstActivityID,
     DateTime start, DateTime end)
        {
            List<RecurringMaster> lrm = new List<RecurringMaster>();
            bool add = true;
            long orgId, projId, actId;
            string subFromUser = string.Empty;
            string subInStorage = string.Empty;

            List<RecurringMaster> recMasters = GetRecurringMastersWithInTimeRange(start, end);
            foreach (RecurringMaster item in recMasters)
            {
                if (Int64.TryParse(item.OrganizationID.ToString(), out orgId))
                    add = (((lstOrganizationID.Count > 0) && (lstOrganizationID.Contains(orgId))) || (lstOrganizationID.Count == 0));
                if (Int64.TryParse(item.ProjectID.ToString(), out projId))
                    add = add && (((lstProjectID.Count > 0) && (lstProjectID.Contains(projId))) || (lstProjectID.Count == 0));
                if (Int64.TryParse(item.ActivityID.ToString(), out actId))
                    add = add && (((lstActivityID.Count > 0) && (lstActivityID.Contains(actId))) || (lstActivityID.Count == 0));
                
                subFromUser = subject.Trim().ToLower().Replace(Constants.SPACE, string.Empty);
                
                if (string.IsNullOrEmpty(item.Subject))
                    subInStorage = string.Empty;
                else
                    subInStorage = item.Subject.ToString().Trim().ToLower().Replace(Constants.SPACE, string.Empty);

                add = add && (((!string.IsNullOrEmpty(subject)) && (subInStorage.Contains(subFromUser))) || (string.IsNullOrEmpty(subject)));

                if (add)
                    lrm.Add(item);
            }
            return lrm;
        }

        

        public List<RecurringMaster> GetRecurringMastersWithInTimeRange(DateTime start, DateTime end)
        {
            var dtrows = from dr in MyDataSet.RecurringMaster.AsEnumerable()
                                         where 
                                         Convert.ToDateTime(dr[RecurringMaster.Property_Start]) < end &&
                                         Convert.ToDateTime(dr[RecurringMaster.Property_End]) >= start 
                                         select dr;
            DataRow[] rows = dtrows.ToArray();
            
            return FillRecurringMasters(rows);
        }

        
        /// <summary>
        /// updates RecurringMaster Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateRecurringMaster(RecurringMaster obj)
        {
            //string query = String.Format("ID = {0}", obj.ID.ToString());
            
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.RecurringMaster.Rows.Count > 0)
            {
                var dtrows = from dr in MyDataSet.RecurringMaster.AsEnumerable()
                             where dr[RecurringMaster.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();

            }
            //rows = MyDataSet.TimeEntry.Select(query);

            TSRDataSet.RecurringMasterRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.RecurringMasterRow;
            else
                row = MyDataSet.RecurringMaster.NewRecurringMasterRow();

            row.ID = obj.ID;
            row.Subject = obj.Subject;
            row.Body = obj.Body;
            row.Location = obj.Location;
            row.Start = obj.Start;
            row.End = obj.End;
            row.OrganizationID = obj.OrganizationID;
            row.ProjectID = obj.ProjectID;
            row.ActivityID = obj.ActivityID;
            row.Revision = obj.Revision;
            try
            {
                if (rows.Length <= 0)
                    MyDataSet.RecurringMaster.Rows.Add(row);
            }
            catch (Exception ex)
            {
                Logging.LoggingHandler.LogUnknownException(ex);
                return false;
            }

            return true;
        }

        public bool DeleteRecurringMaster(string id)
        {
            DataRow row = GetRecurringMasterRowByID(id);
            if (row != null)
            {
                try
                {
                    MyDataSet.RecurringMaster.Rows.Remove(row);
                }
                catch (Exception ex)
                {
                    Logging.LoggingHandler.LogUnknownException(ex);
                    return false;
                }
                return true;
            }
            return false;
        }

        /// <summary>
        /// fills list of RecurringMaster objects from dataview data, utility method
        /// </summary>
        /// <param name="rows"></param>
        /// <returns></returns>
        private List<RecurringMaster> FillRecurringMasters(IEnumerable rows)
        {
            List<RecurringMaster> list = new List<RecurringMaster>();

            foreach (DataRow row in rows)
            {
                list.Add(FillRecurringMaster(row));
            }

            return list;
        }

        /// <summary>
        /// fills a single RecurringMaster object from DataRowView object , data retrieved from local storage is
        /// being filled in RecurringMaster object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private RecurringMaster FillRecurringMaster(DataRow row)
        {
            TSRDataSet.RecurringMasterRow teRow = row as TSRDataSet.RecurringMasterRow;

            if (teRow != null)
            {
                RecurringMaster obj = new RecurringMaster();

                obj.ID = teRow.ID;
                if(!teRow.IsSubjectNull())
                    obj.Subject = teRow.Subject;
                if(!teRow.IsBodyNull())
                    obj.Body = teRow.Body;
                if (!teRow.IsLocationNull())
                    obj.Location = teRow.Location;
                obj.Start = teRow.Start;
                obj.End = teRow.End;
                obj.OrganizationID = teRow.OrganizationID;
                obj.ProjectID = teRow.ProjectID;
                obj.ActivityID = teRow.ActivityID;
                if (!teRow.IsRevisionNull())
                {
                    obj.Revision = teRow.Revision;
                }
                else
                    obj.Revision = 0;
                return obj;
            }

            return null;
        }

    }
}
