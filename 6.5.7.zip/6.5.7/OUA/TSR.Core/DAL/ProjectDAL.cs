using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for Project
    /// </summary>
    internal class ProjectDAL : BaseDAL
    {
        private DataRow GetProjectRowByID(Int64 id)
        {
            return GetProjectRowByID(id, true);
        }

        private DataRow GetProjectRowByID(Int64 id,bool visible)
        {
            //string query = String.Format(Project.Property_ID + " = {0} and " + Project.Property_Visible + " = {1}", id.ToString(), visible);
            //DataRow[] rows = MyDataSet.Project.Select(query);

            //edit by tsrdev2 - 21 Jun 2011     
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in MyDataSet.Project.AsEnumerable()
                         where dr[Project.Property_ID].ToString() == id.ToString() && dr[Project.Property_Visible].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Project GetProjectByID(Int64 id)
        {
            return GetProjectByID(id, true);
        }
        /// <summary>
        /// retrieves a project by project id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Project GetProjectByID(Int64 id, bool visible)
        {
            DataRow row = GetProjectRowByID(id,visible);
            if (row != null)
            {
                return FillProject(row,visible);
            }

            return null;
        }


        /// <summary>
        /// retrieves all projects
        /// </summary>
        /// <returns></returns>
        public ProjectList GetAllProjects()
        {
            return GetAllProjects(true);
        }

        /// <summary>
        /// retrieves all projects
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ProjectList GetAllProjects(bool visible)
        {
            return FillProjects(MyDataSet.Project.Rows,visible);
        }


        /// <summary>
        /// Retrieves projects for a single organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public ProjectList GetProjectsForOrganization(Int64 organizationID)
        {
            return GetProjectsForOrganization(organizationID, true);
        }

        /// <summary>
        /// Retrieves projects for a single organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ProjectList GetProjectsForOrganization(Int64 organizationID,bool visible)
        {
            var projects = from orgs in MyDataSet.Organization.AsEnumerable()
                           join org_prj in MyDataSet.Organization_Project.AsEnumerable()
                           on (long)orgs[Organization.Property_ID] equals (long)org_prj[Organization.Property_OrganizationID]
                           join prjs in MyDataSet.Project.AsEnumerable()
                           on (long)org_prj[Project.Property_ProjectID] equals (long)prjs[Project.Property_ID]
                           where (long)orgs[Organization.Property_ID] == organizationID
                           select prjs;

            if (projects.Count() > 0)
            {
                return FillProjects(projects,visible);
            }

            return new ProjectList();
        }

        /// <summary>
        /// retrieves projects for multiple organizations
        /// </summary>
        /// <param name="organizationIDs"></param>
        /// <returns></returns>
        public ProjectList GetProjectsForMultipleOrganizations(List<Int64> organizationIDs)
        {
            return GetProjectsForMultipleOrganizations(organizationIDs, true);
        }

        /// <summary>
        /// retrieves projects for multiple organizations
        /// </summary>
        /// <param name="organizationIDs"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public ProjectList GetProjectsForMultipleOrganizations(List<Int64> organizationIDs,bool visible)
        {
            var projects = from orgs in MyDataSet.Organization.AsEnumerable()
                           join org_prj in MyDataSet.Organization_Project.AsEnumerable()
                           on (long)orgs[Organization.Property_ID] equals (long)org_prj[Organization.Property_OrganizationID]
                           join prjs in MyDataSet.Project.AsEnumerable()
                           on (long)org_prj[Project.Property_ProjectID] equals (long)prjs[Project.Property_ID]
                           where organizationIDs.Contains((long)orgs[Organization.Property_ID])
                           select prjs;

            if (projects.Count() > 0)
            {
                return FillProjects(projects,visible);
            }

            return new ProjectList();
        }

        /// <summary>
        /// assign a project to a organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public bool AssignOrganization(long organizationID, long projectID)
        {
            //string query = String.Format(Organization.Property_OrganizationID + " = {0} And " + Project.Property_ProjectID + " = {1}",
            //    organizationID.ToString(), projectID.ToString());            
            //DataRow[] rows = MyDataSet.Organization_Project.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                 
            var dtrows = from dr in MyDataSet.Organization_Project.AsEnumerable()
                         where dr[Organization.Property_OrganizationID].ToString() == organizationID.ToString() && dr[Project.Property_ProjectID].ToString() == projectID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length <= 0)
            {
                TSRDataSet.Organization_ProjectRow row = MyDataSet.Organization_Project.NewOrganization_ProjectRow();
                row.OrganizationID = organizationID;
                row.ProjectID = projectID;
                MyDataSet.Organization_Project.Rows.Add(row);
            }           
            return true;
        }

        /// <summary>
        /// Remove a project from a organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public bool RemoveOrganization(long organizationID, long projectID)
        {
            //string query = String.Format(Organization.Property_OrganizationID + " = {0} And " + Project.Property_ProjectID + " = {1}",
            //    organizationID.ToString(), projectID.ToString());            
            //DataRow[] rows = MyDataSet.Organization_Project.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                 
            var dtrows = from dr in MyDataSet.Organization_Project.AsEnumerable()
                         where dr[Organization.Property_OrganizationID].ToString() == organizationID.ToString() && dr[Project.Property_ProjectID].ToString() == projectID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Organization_ProjectRow row = dtRow as TSRDataSet.Organization_ProjectRow;
                    MyDataSet.Organization_Project.Rows.Remove(row);
                }
            }            
            return true;
        }
        /// <summary>
        /// Remove a project from a organization
        /// </summary>        
        /// <param name="projectID"></param>
        /// <returns></returns>
        public bool RemoveOrganization(long projectID)
        {
            //string query = String.Format(Project.Property_ProjectID + " = {0}",
            //    projectID.ToString());
            //DataRow[] rows = MyDataSet.Organization_Project.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                 
            var dtrows = from dr in MyDataSet.Organization_Project.AsEnumerable()
                         where dr[Project.Property_ProjectID].ToString() == projectID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length > 0)
            {
                foreach (DataRow dtRow in rows)
                {
                    TSRDataSet.Organization_ProjectRow row = dtRow as TSRDataSet.Organization_ProjectRow;
                    MyDataSet.Organization_Project.Rows.Remove(row);
                }
            }
            return true;
        }

        /// <summary>
        /// updates a project
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateProject(Project obj)
        {
            //string query = String.Format(Project.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Project.Select(query);
            DataRow[] rows = new DataRow[]{};
            if (MyDataSet.Project.Rows.Count > 0)
            {
                //rows = MyDataSet.Project.Select(query);

                //edit by tsrdev2 - 21 Jun 2011                 
                var dtrows = from dr in MyDataSet.Project.AsEnumerable()
                             where dr[Project.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.ProjectRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.ProjectRow;
            else
                row = MyDataSet.Project.NewProjectRow();
            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Visible = obj.Visible;
                row.Modified = obj.Modified;

                if (!string.IsNullOrEmpty(obj.ProjectTypeName))
                    row.ProjectTypeName = obj.ProjectTypeName;
                else
                    row.ProjectTypeName = "";
                if (!string.IsNullOrEmpty(obj.Description))
                    row.Description = obj.Description;
                else
                    row.Description = "";
                if (rows.Length <= 0)
                {
                    try
                    {
                        MyDataSet.Project.Rows.Add(row);
                    }
                    catch (Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogUnhandledException(new Logging.Log()
                        {
                            MessageDetail = ex.ToString(),
                            MessageSummary = string.Format("Project ID: {0}, Name: {1}", row.ID, row.Name)
                        });
                    }
                    finally {
                    }
                }
            }
            else
            {
                if (rows.Length > 0)
                    MyDataSet.Project.Rows.Remove(row);
            }
            return true;
        }

        /// <summary>
        /// fills list of projects from local storage data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private ProjectList FillProjects(IEnumerable rows)
        {
            return FillProjects(rows, true);
        }

        /// <summary>
        /// fills list of projects from local storage data, utility method
        /// </summary>
        /// <param name="rows"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private ProjectList FillProjects(IEnumerable rows,bool visible)
        {
            ProjectList list = new ProjectList();

            foreach (DataRow row in rows)
            {
                Project proj = FillProject(row, visible);
                if (proj != null)
                    list.Add(proj);
            }

            return list;
        }

        /// <summary>
        /// fills Project object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Project FillProject(DataRow row)
        {
            return FillProject(row, true);
        }

        /// <summary>
        /// fills Project object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private Project FillProject(DataRow row,bool visible)
        {
            TSRDataSet.ProjectRow prjRow = row as TSRDataSet.ProjectRow;

            if ((prjRow != null) && (prjRow.Visible == visible))
            {
                Project obj = new Project();

                obj.ID = prjRow.ID;
                obj.Name = prjRow.Name;
                obj.Visible = prjRow.Visible;

                if (!prjRow.IsModifiedNull())
                    obj.Modified = prjRow.Modified;
                if(!prjRow.IsProjectTypeNameNull())
                    obj.ProjectTypeName = prjRow.ProjectTypeName;
                if(!prjRow.IsDescriptionNull())
                    obj.Description = prjRow.Description;
                return obj;
            }

            return null;
        }
    }
}
