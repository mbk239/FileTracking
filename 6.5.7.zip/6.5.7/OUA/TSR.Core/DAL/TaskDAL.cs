using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// Data access class for Task
    /// </summary>
    internal class TaskDAL : BaseDAL
    {
        private DataRow GetTaskRowByID(Int64 id)
        {
            return GetTaskRowByID(id, true);
        }

        private DataRow GetTaskRowByID(Int64 id,bool visible)
        {
            //string query = String.Format(Task.Property_ID + " = {0} and "+Task.Property_Visible+" ={1}", id.ToString(),visible);
            //DataRow[] rows = MyDataSet.Task.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                 
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in MyDataSet.Task.AsEnumerable()
                         where dr[Task.Property_ID].ToString() == id.ToString() && dr[Task.Property_Visible].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves task object from task id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task GetTaskByID(Int64 id)
        {
            return GetTaskByID(id, true);
        }

        /// <summary>
        /// retrieves task object from task id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Task GetTaskByID(Int64 id, bool visible)
        {
            DataRow row = GetTaskRowByID(id,visible);
            if (row != null)
            {
                return FillTask(row,visible);
            }

            return null;
        }
        /// <summary>
        /// retrieves all tasks
        /// </summary>
        /// <returns></returns>
        public TaskList GetAllTasks()
        {
            return GetAllTasks(true);
        }

        /// <summary>
        /// retrieves all tasks
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public TaskList GetAllTasks(bool visible)
        {
            return FillTasks(MyDataSet.Task.Rows,visible);
        }

        /// <summary>
        /// fills TaskList object [list of task objects] from local storage [DataView, after populated from local storage]
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private TaskList FillTasks(IEnumerable rows)
        {
            return FillTasks(rows, true);
        }

        /// <summary>
        /// fills TaskList object [list of task objects] from local storage [DataView, after populated from local storage]
        /// </summary>
        /// <param name="view"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private TaskList FillTasks(IEnumerable rows, bool visible)
        {
            TaskList list = new TaskList();

            foreach (DataRow row in rows)
            {
                if (FillTask(row, visible) != null)
                    list.Add(FillTask(row,visible));
            }

            return list;
        }
        /// <summary>
        /// retreives a single Task object from a row, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Task FillTask(DataRow row)
        {
            return FillTask(row, true);
        }
        /// <summary>
        /// retreives a single Task object from a row, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private Task FillTask(DataRow row, bool visible)
        {
            TSRDataSet.TaskRow tskRow = row as TSRDataSet.TaskRow;

            if ((tskRow != null) && (tskRow.Visible == visible))
            {
                Task obj = new Task();

                obj.ID = tskRow.ID;
                obj.Name = tskRow.Name;
                obj.Visible = tskRow.Visible;

                return obj;
            }

            return null;
        }
    }
}
