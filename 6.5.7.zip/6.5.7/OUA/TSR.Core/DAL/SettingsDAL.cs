﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Core.Entity;
using System.Data;
using System.Collections;

namespace TSR.Core.DAL
{
    internal class SettingsDAL : BaseDAL
    {
        private DataRow GetSettingsRowByKey(string Key)
        {
            //string query = String.Format("Key = {0}", Key);
            //DataRow[] rows = MyDataSet.AppConfig.Select(query);
            //return (rows.Length == 1 ? rows[0] : null);

            DataRow[] rows = GetSettingsRowsByKey(Key);
            if (rows == null)
                return null;

            return (rows.Length == 1 ? rows[0] : null);
        }

        private DataRow[] GetSettingsRowsByKey(string Key)
        {
            if (MyDataSet.Settings.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            var dtrows = from dr in MyDataSet.Settings.AsEnumerable()
                         where dr[Settings.Property_Key].ToString() == Key.ToString()
                         select dr;
            rows = dtrows.ToArray();
            return rows;
        }

        /// <summary>
        /// gets Settings object by Settings id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Settings GetSettingsByKey(string Key)
        {
            DataRow row = GetSettingsRowByKey(Key);
            if (row != null)
            {
                return FillSettings(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all contacts
        /// </summary>
        /// <returns></returns>
        public SettingsList GetAllAppConfigs()
        {
            return FillSettingses(MyDataSet.Settings.Rows);
        }




        /// <summary>
        /// updates Settings object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateSettings(Settings obj)
        {
            //string query = String.Format("Key = {0}", obj.Key.ToString());
            ////DataRow[] rows = MyDataSet.Contact.Select(query);
            //DataRow[] rows = new DataRow[] { };
            //if (MyDataSet.AppConfig.Rows.Count > 0)
            //    rows = MyDataSet.AppConfig.Select(query);
            DataRow[] rows = GetSettingsRowsByKey(obj.Key);
            if (rows == null)
                rows = new DataRow[] { };

            TSRDataSet.SettingsRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.SettingsRow;
            else
                row = MyDataSet.Settings.NewSettingsRow();

            row.Key = obj.Key;
            row.Value = obj.Value;

            if (rows.Length <= 0)
                MyDataSet.Settings.Rows.Add(row);

            return true;
        }

        /// <summary>
        /// fills Settingslist from dataview [like table]
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        public SettingsList FillSettingses(IEnumerable rows)
        {
            SettingsList list = new SettingsList();

            foreach (DataRow row in rows)
            {
                list.Add(FillSettings(row));
            }

            return list;
        }

        /// <summary>
        /// fills Settings object from a data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Settings FillSettings(DataRow row)
        {
            TSRDataSet.SettingsRow cntRow = row as TSRDataSet.SettingsRow;

            if (cntRow != null)
            {
                Settings obj = new Settings();

                obj.ID = cntRow.ID;
                obj.Key = cntRow.Key;
                obj.Value = cntRow.Value;

                return obj;
            }

            return null;
        }
    }
}
