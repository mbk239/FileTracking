﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    internal class Project_ActivityDAL : BaseDAL
    {
        /// <summary>
        /// Get all Project_Activity from dataset
        /// </summary>
        /// <returns></returns>
        internal Entity.Project_ActivityList GetAllProject_activity()
        {
            return FillProject_Activity(MyDataSet.Project_Activity.Rows);
        }
        /// <summary>
        /// Get more Project_Activity object from collection
        /// </summary>
        /// <param name="rows">DataRowCollection</param>
        /// <returns></returns>
        private Entity.Project_ActivityList FillProject_Activity(System.Data.DataRowCollection rows)
        {
            Entity.Project_ActivityList list = new Entity.Project_ActivityList();

            foreach (DataRow row in rows)
            {
                Entity.Project_Activity projActivity = FillProjectActivity(row);
                if (projActivity != null)
                    list.Add(projActivity);
            }

            return list;
        }

        /// <summary>
        /// Get a object from data row
        /// </summary>
        /// <param name="row">DataRow</param>
        /// <returns></returns>
        private Entity.Project_Activity FillProjectActivity(DataRow row)
        {
            TSRDataSet.Project_ActivityRow cntRow = row as TSRDataSet.Project_ActivityRow;

            if (cntRow != null)
            {
                Entity.Project_Activity obj = new Entity.Project_Activity();

                obj.ProjectID = cntRow.ProjectID;
                obj.ActivityID = cntRow.ActivityID;
                if (!cntRow.IsModifiedNull())
                    obj.Reversion = cntRow.Modified;

                return obj;
            }
            return null;
        }

        /// <summary>
        /// Add a new row to table Project_Activity in dataset
        /// </summary>
        /// <param name="prjID">Project ID</param>
        /// <param name="actID">Activity ID</param>
        /// <returns></returns>
        internal bool AddProjectActivityRelation(long prjID, long actID)
        {
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Project_Activity.Property_ProjectID].ToString() == prjID.ToString() && dr[Project_Activity.Property_ActivityID].ToString() == actID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            if (rows.Length <= 0)
            {
                TSRDataSet.Project_ActivityRow row = MyDataSet.Project_Activity.NewProject_ActivityRow();
                row.ProjectID = prjID;
                row.ActivityID = actID;
                MyDataSet.Project_Activity.Rows.Add(row);
            }
            return true;
        }
        /// <summary>
        /// Delete a row in table Project_Activity in dataset
        /// </summary>
        /// <param name="prjID">Project ID</param>
        /// <param name="actID">Activity ID</param>
        /// <returns></returns>
        internal bool DeleteProjectActivityRelation(long prjID, long actID)
        {
            DataRow teRow = GetProjectActivityRowByID(prjID, actID);
            if (teRow != null)
            {
                MyDataSet.Project_Activity.Rows.Remove(teRow);
            }
            return true;
        }
        /// <summary>
        /// Get a data row in table Project_Activity in dataset
        /// </summary>
        /// <param name="prjID">Project ID</param>
        /// <param name="actID">Activity ID</param>
        /// <returns></returns>
        private DataRow GetProjectActivityRowByID(long prjID, long actID)
        {
            var dtrows = from dr in MyDataSet.Project_Activity.AsEnumerable()
                         where dr[Project_Activity.Property_ProjectID].ToString() == prjID.ToString() && dr[Project_Activity.Property_ActivityID].ToString() == actID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }
    }
}
