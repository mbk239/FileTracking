﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Core.Entity;
using System.Data;
using System.Collections;

namespace TSR.Core.DAL
{
    internal class UserSettingsDAL : BaseDAL
    {
        private DataRow GetUserSettingsRowByKey(string Key)
        {
            //string query = String.Format("Key = {0}", Key);
            //DataRow[] rows = MyDataSet.AppConfig.Select(query);
            //return (rows.Length == 1 ? rows[0] : null);

            DataRow[] rows = GetUserSettingsRowsByKey(Key);
            if (rows == null)
                return null;

            return (rows.Length == 1 ? rows[0] : null);
        }

        private DataRow[] GetUserSettingsRowsByKey(string Key)
        {
            if (MyDataSet.UserSettings.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            var dtrows = from dr in MyDataSet.UserSettings.AsEnumerable()
                         where dr[UserSettings.Property_Key].ToString() == Key.ToString()
                         select dr;
            rows = dtrows.ToArray();
            return rows;
        }

        /// <summary>
        /// gets UserSettings object by Settings id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public UserSettings GetUserSettingsByKey(string Key)
        {
            DataRow row = GetUserSettingsRowByKey(Key);
            if (row != null)
            {
                return FillUserSettings(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all usersettings
        /// </summary>
        /// <returns></returns>
        public UserSettingsList GetAllUserSettings()
        {
            return FillUserSettingses(MyDataSet.UserSettings.Rows);
        }

        /// <summary>
        /// updates Settings object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateUserSettings(UserSettings obj)
        {
            DataRow[] rows = GetUserSettingsRowsByKey(obj.Key);
            if (rows == null)
                rows = new DataRow[] { };

            TSRDataSet.UserSettingsRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.UserSettingsRow;
            else
                row = MyDataSet.UserSettings.NewUserSettingsRow();

            row.Key = obj.Key;
            row.Value = obj.Value;

            if (rows.Length <= 0)
                MyDataSet.UserSettings.Rows.Add(row);

            return true;
        }

        /// <summary>
        /// fills UserSettingslist from dataview [like table]
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        public UserSettingsList FillUserSettingses(IEnumerable rows)
        {
            UserSettingsList list = new UserSettingsList();

            foreach (DataRow row in rows)
            {
                list.Add(FillUserSettings(row));
            }

            return list;
        }

        /// <summary>
        /// fills UserSettings object from a data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private UserSettings FillUserSettings(DataRow row)
        {
            TSRDataSet.UserSettingsRow cntRow = row as TSRDataSet.UserSettingsRow;

            if (cntRow != null)
            {
                UserSettings obj = new UserSettings();

                obj.ID = cntRow.ID;
                obj.Key = cntRow.Key;
                obj.Value = cntRow.Value;

                return obj;
            }

            return null;
        }
    }
}
