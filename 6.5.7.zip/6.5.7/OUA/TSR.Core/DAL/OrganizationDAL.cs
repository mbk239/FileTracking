using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// data access class for organization, local storage
    /// </summary>
    internal class OrganizationDAL : BaseDAL
    {
        private DataRow GetOrganizationRowByID(Int64 id)
        {
            //string query = String.Format(Organization.Property_ID + " = {0}", id.ToString());
            //DataRow[] rows = MyDataSet.Organization.Select(query);

            //edit by tsrdev2 - 21 Jun 2011            
            var dtrows = from dr in MyDataSet.Organization.AsEnumerable()
                         where dr[Organization.Property_ID].ToString() == id.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        private DataRow GetOrganizationRowByID(Int64 id,bool visible)
        {
            //string query = String.Format(Organization.Property_ID + " = {0} and " + Organization.Property_Visible + "= {1}", id.ToString(), visible);
            //DataRow[] rows = MyDataSet.Organization.Select(query);

            //edit by tsrdev2 - 21 Jun 2011            
            string strVisible = visible ? Constants.TRUE_IN_LOWER_CHARS : Constants.FALSE_IN_LOWER_CHARS;
            var dtrows = from dr in MyDataSet.Organization.AsEnumerable()
                         where dr[Organization.Property_ID].ToString() == id.ToString() && dr[Organization.Property_Visible].ToString().ToLower() == strVisible
                         select dr;
            DataRow[] rows = dtrows.ToArray();            
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves Organization object from Organization ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Organization GetOrganizationByID(Int64 id)
        {
            return GetOrganizationByID(id, true);
        }

        /// <summary>
        /// retrieves Organization object from Organization ID
        /// </summary>
        /// <param name="id"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public Organization GetOrganizationByID(Int64 id,bool visible)
        {
            DataRow row = GetOrganizationRowByID(id,visible);
            if (row != null)
            {
                return FillOrganization(row,visible);
            }

            return null;
        }

        /// <summary>
        /// retrieves all organizations
        /// </summary>
        /// <returns></returns>
        public OrganizationList GetAllOrganizations()
        {
            return GetAllOrganizations(true);
        }

        /// <summary>
        /// retrieves all organizations
        /// </summary>
        /// <param name="visible"></param>
        /// <returns></returns>
        public OrganizationList GetAllOrganizations(bool visible)
        {
            return FillOrganizations(MyDataSet.Organization.Rows,visible);
        }

        /// <summary>
        /// retrieves list of Organizations for a project
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public OrganizationList GetOrganizationsByProjectID(long projectId)
        {
            return GetOrganizationsByProjectID(projectId, true);
        }

        /// <summary>
        /// retrieves list of Organizations for a project
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        public OrganizationList GetOrganizationsByProjectID(long projectId,bool visible)
        {
            var organizations = from orgs in MyDataSet.Organization.AsEnumerable()
                                join org_prj in MyDataSet.Organization_Project.AsEnumerable()
                                on (long)orgs[Organization.Property_ID] equals (long)org_prj[Organization.Property_OrganizationID]
                                join prjs in MyDataSet.Project.AsEnumerable()
                                on (long)org_prj[Project.Property_ProjectID] equals (long)prjs[Project.Property_ID]
                                where (long)orgs[Organization.Property_ID] == projectId
                                select orgs;

            if (organizations.Count() > 0)
            {
                return FillOrganizations(organizations,visible);
            }

            return new OrganizationList();
        }
        /// <summary>
        /// updates Organization Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateOrganization(Organization obj)
        {
            //string query = String.Format(Organization.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.Organization.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.Organization.Rows.Count > 0)
            {
                //rows = MyDataSet.Organization.Select(query);

                //edit by tsrdev2 - 21 Jun 2011                            
                var dtrows = from dr in MyDataSet.Organization.AsEnumerable()
                             where dr[Organization.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }
            TSRDataSet.OrganizationRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.OrganizationRow;
            else
                row = MyDataSet.Organization.NewOrganizationRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.ID = obj.ID;
                row.Name = obj.Name;
                row.Visible = obj.Visible;
                row.Modified = obj.Modified;

                if (!string.IsNullOrEmpty(obj.Description))
                    row.Description = obj.Description;
                else
                    row.Description = "";

                if (rows.Length <= 0)
                    MyDataSet.Organization.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                {
                    MyDataSet.Organization.Rows.Remove(row);
                }
            }
            return true;
        }

        /// <summary>
        /// fills list of organization objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private OrganizationList FillOrganizations(IEnumerable rows)
        {
            return FillOrganizations(rows, true);
        }

        /// <summary>
        /// fills list of organization objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private OrganizationList FillOrganizations(IEnumerable rows,bool visible)
        {
            OrganizationList list = new OrganizationList();

            foreach (DataRow row in rows)
            {
                if (FillOrganization(row,visible) != null)
                    list.Add(FillOrganization(row,visible));
            }

            return list;
        }

        /// <summary>
        /// fills a single Organization object from DataRowView object , data retrieved from local storage is
        /// being filled in Organization object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private Organization FillOrganization(DataRow row)
        {
            return FillOrganization(row, true);
        }

        /// <summary>
        /// fills a single Organization object from DataRowView object , data retrieved from local storage is
        /// being filled in Organization object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <param name="visible"></param>
        /// <returns></returns>
        private Organization FillOrganization(DataRow row, bool visible)
        {
            TSRDataSet.OrganizationRow orgRow = row as TSRDataSet.OrganizationRow;

            if ((orgRow != null) && (orgRow.Visible == visible))
            {
                Organization obj = new Organization();

                obj.ID = orgRow.ID;
                obj.Name = orgRow.Name;
                obj.Visible = orgRow.Visible;

                if (!orgRow.IsModifiedNull())
                    obj.Modified = orgRow.Modified;                

                if(!orgRow.IsDescriptionNull())
                    obj.Description = orgRow.Description;

                return obj;
            }

            return null;
        }
    }
}
