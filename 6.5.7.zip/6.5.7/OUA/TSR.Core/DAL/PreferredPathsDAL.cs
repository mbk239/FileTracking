using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Diagnostics;

using WS = TSR.Core.UserAgentService;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    /// <summary>
    /// data access class for PreferredPaths, local storage
    /// </summary>
    internal class PreferredPathsDAL : BaseDAL
    {
        private DataRow GetPreferredPathsRowByID(long id)
        {
            //string query = String.Format(PreferredPaths.Property_ID + " = {0}", id.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_ID].ToString() == id.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length == 1 ? rows[0] : null);
        }

        /// <summary>
        /// retrieves PreferredPaths object from PreferredPaths ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public PreferredPaths GetPreferredPathsByID(long id)
        {
            DataRow row = GetPreferredPathsRowByID(id);
            if (row != null)
            {
                return FillPreferredPath(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all PreferredPathss
        /// </summary>
        /// <returns></returns>
        public PreferredPathsList GetAllPreferredPaths()
        {
            return FillPreferredPaths(MyDataSet.PreferredPaths.Rows);
        }

        /// <summary>
        /// retrieves list of PreferredPathss for a project
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        //public PreferredPaths GetPreferredPathsByOutlookItemID(string olItemID)
        //{
        //    string query = String.Format("OutlookItemID = {0}", olItemID);
        //    DataRow[] rows = MyDataSet.PreferredPaths.Select(query);
        //    return (rows.Length == 1 ? FillPreferredPath(rows[0]) : null);
        //}

        /// <summary>
        /// updates PreferredPaths Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdatePreferredPaths(PreferredPaths obj)
        {
            //string query = String.Format(PreferredPaths.Property_ID + " = {0}", obj.ID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.PreferredPaths.Rows.Count > 0)
            {
                //rows = MyDataSet.PreferredPaths.Select(query);

                //edit by tsrdev2 - 21 Jun 2011                        
                var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                             where dr[PreferredPaths.Property_ID].ToString() == obj.ID.ToString()
                             select dr;
                rows = dtrows.ToArray();
            }

            TSRDataSet.PreferredPathsRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.PreferredPathsRow;
            else
                row = MyDataSet.PreferredPaths.NewPreferredPathsRow();

            row.OrganizationID = obj.OrganizationID;
            row.ProjectID = obj.ProjectID;
            row.ActivityID = obj.ActivityID;

            if ((obj.TaskID.HasValue == false) || (obj.TaskID == -1))
                row.SetTaskIDNull();
            else
                row.TaskID = obj.TaskID.Value;
            if ((obj.ContactID.HasValue == false) || (obj.ContactID == -1))
                row.SetContactIDNull();
            else
                row.ContactID = obj.ContactID.Value;

            row.IsDefault = obj.IsDefault; 

            if (rows.Length <= 0)
                MyDataSet.PreferredPaths.Rows.Add(row);

            return true;
        }
        /// <summary>
        /// remove preferred path by PreferredPaths ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeletePreferredPaths(long id)
        {
            DataRow teRow = GetPreferredPathsRowByID(id);
            if (teRow != null)
            {
                MyDataSet.PreferredPaths.Rows.Remove(teRow);
            }

            return true;
        }

        /// <summary>
        /// remove preferred path by PreferredPaths ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool DeletePreferredPathsList(PreferredPathsList listPaths)
        {
            foreach (PreferredPaths path in listPaths)
            {
                DataRow teRow = GetPreferredPathsRowByID(path.ID);
                if (teRow != null)
                {
                    MyDataSet.PreferredPaths.Rows.Remove(teRow);
                }
            }
            return true;
        }

        /// <summary>
        /// fills list of PreferredPaths objects from dataview data, utility method
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private PreferredPathsList FillPreferredPaths(IEnumerable rows)
        {
            PreferredPathsList list = new PreferredPathsList();

            foreach (DataRow row in rows)
            {
                var ppRow = row as TSRDataSet.PreferredPathsRow;
                if (ppRow != null && ppRow.ActivityRow != null && ppRow.ActivityRow.IsActivate)
                    list.Add(FillPreferredPath(row));
            }

            return list;
        }

        /// <summary>
        /// fills a single PreferredPaths object from DataRowView object , data retrieved from local storage is
        /// being filled in PreferredPaths object, utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private PreferredPaths FillPreferredPath(DataRow row)
        {
            TSRDataSet.PreferredPathsRow ppRow = row as TSRDataSet.PreferredPathsRow;

            if (ppRow != null)
            {
                PreferredPaths obj = new PreferredPaths(ppRow.ID);
                obj.OrganizationID = ppRow.OrganizationID;
                obj.ProjectID = ppRow.ProjectID;
                obj.ActivityID = ppRow.ActivityID;

                if (!ppRow.IsTaskIDNull())
                    obj.TaskID = ppRow.TaskID;
                if (!ppRow.IsContactIDNull())
                    obj.ContactID = ppRow.ContactID;

                obj.IsDefault = ppRow.IsDefault;

                return obj;
            }

            return null;
        }

        internal bool DeleteAll()
        {
            MyDataSet.PreferredPaths.Rows.Clear();
            return true;
        }

        internal PreferredPaths GetPreferredPathsByOrganizationID(long organizationID)
        {
            //string query = String.Format(PreferredPaths.Property_OrganizationID + " = {0}", organizationID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_OrganizationID].ToString() == organizationID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();

            if (rows.Length > 1)
            {
                var isDefault = FillPreferredPaths(rows).SingleOrDefault(x => x.IsDefault);
                if (isDefault != null)
                    return isDefault;
            }

            return (rows.Length >= 1 ? FillPreferredPath(rows[0]) : null);
        }
        internal PreferredPathsList GetPreferredPathsListByOrganizationID(long organizationID)
        {
            //string query = String.Format(PreferredPaths.Property_OrganizationID + " = {0}", organizationID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_OrganizationID].ToString() == organizationID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length > 0 ? FillPreferredPaths(rows) : null);
        }
        internal PreferredPathsList GetPreferredPathsListByProjectID(long projectID)
        {
            //string query = String.Format(PreferredPaths.Property_ProjectID + " = {0}", projectID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_ProjectID].ToString() == projectID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length > 0 ? FillPreferredPaths(rows) : null);
        }

        internal PreferredPathsList GetPreferredPathsListByActivityID(long activityID)
        {
            //string query = String.Format(PreferredPaths.Property_ActivityID + " = {0}", activityID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_ActivityID].ToString() == activityID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length > 0 ? FillPreferredPaths(rows) : null);
        }
        internal PreferredPathsList GetPreferredPathsListByContactID(long contactID)
        {
            //string query = String.Format(PreferredPaths.Property_ContactID + " = {0}", contactID.ToString());
            //DataRow[] rows = MyDataSet.PreferredPaths.Select(query);

            //edit by tsrdev2 - 21 Jun 2011                        
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_ContactID].ToString() == contactID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length > 0 ? FillPreferredPaths(rows) : null);
        }

        internal PreferredPathsList GetPreferredPathsListByLocationID(long locationID)
        {                   
            var dtrows = from dr in MyDataSet.PreferredPaths.AsEnumerable()
                         where dr[PreferredPaths.Property_LocationID].ToString() == locationID.ToString()
                         select dr;
            DataRow[] rows = dtrows.ToArray();
            return (rows.Length > 0 ? FillPreferredPaths(rows) : null);
        }
    }
}
