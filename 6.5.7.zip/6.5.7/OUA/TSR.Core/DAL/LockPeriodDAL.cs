﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TSR.Core.Entity;

namespace TSR.Core.DAL
{
    public class LockPeriodDAL : BaseDAL
    {
        public bool IsUserInLockPeriod(DateTime date)
        {
            var list = GetLockPeriodRows();

            return list.Count(x => x.IsLocked && x.LockDate.Date.Equals(date.Date)) > 0;

        }
        /// <summary>
        /// retrieves lock period by userId
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public LockPeriodList GetLockPeriods()
        {
            return GetLockPeriodRows();
        }

        public bool RemoveAllLockPeriod()
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.LockPeriod.Rows.Count > 0)
            {
                MyDataSet.LockPeriod.Rows.Clear();
            }

            return true;
        }

        /// <summary>
        /// Updates LockPeriod Object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateLockPeriod(LockPeriod obj)
        {
            DataRow[] rows = new DataRow[] { };
            if (MyDataSet.LockPeriod.Rows.Count > 0)
            {
                var dtrows = from dr in Enumerable.AsEnumerable(MyDataSet.LockPeriod)
                    where
                        dr[LockPeriod.Property_UserID].ToString() == obj.UserID.ToString() &&
                        DateTime.Parse(dr[LockPeriod.Property_LockDate].ToString()) == obj.LockDate
                    select dr;

                rows = dtrows.ToArray();
            }
            TSRDataSet.LockPeriodRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.LockPeriodRow;
            else
                row = MyDataSet.LockPeriod.NewLockPeriodRow();

            if (obj.RowState != TSR.Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                row.UserID = obj.UserID;
                row.LockDate = obj.LockDate;
                row.IsLocked = obj.IsLocked;
                
                if (rows.Length <= 0)
                    MyDataSet.LockPeriod.Rows.Add(row);
            }
            else
            {
                if (rows.Length > 0)
                {
                    MyDataSet.LockPeriod.Rows.Remove(row);
                }
            }
            return true;
        }

        #region Private Method
        /// <summary>
        /// fills list of lock period objects from dataview data, utility method
        /// </summary>
        /// <returns></returns>
        private LockPeriodList FillLockPeriods(IEnumerable rows)
        {
            var list = new LockPeriodList();
            list.AddRange(from DataRow row in rows where FillLockPeriod(row) != null select FillLockPeriod(row));

            return list;
        }

        private LockPeriodList GetLockPeriodRows()
        {
            var rows = from dr in Enumerable.AsEnumerable(MyDataSet.LockPeriod)
                         select dr;

            var list = new LockPeriodList();
            list.AddRange(from DataRow row in rows where FillLockPeriod(row) != null select FillLockPeriod(row));

            return list;
        }

        /// <summary>
        /// fills lock period object from local storage [data row], utility method
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private LockPeriod FillLockPeriod(DataRow row)
        {
            var objRow = row as TSRDataSet.LockPeriodRow;

            if (objRow != null)
            {
                var obj = new LockPeriod();

                obj.UserID = objRow.UserID;
                obj.LockDate = objRow.LockDate;
                obj.IsLocked = objRow.IsLocked;

                return obj;
            }
            return null;
        }

        #endregion
    }
}
