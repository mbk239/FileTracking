﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Core.Entity;
using System.Data;
using System.Collections;

namespace TSR.Core.DAL
{
    internal class AppConfigDAL : BaseDAL
    {
        private DataRow GetAppConfigRowByKey(string Key)
        {
            //string query = String.Format("Key = {0}", Key);
            //DataRow[] rows = MyDataSet.AppConfig.Select(query);
            //return (rows.Length == 1 ? rows[0] : null);

            DataRow[] rows = GetAppConfigRowsByKey(Key);
            if (rows == null)
                return null;

            return (rows.Length == 1 ? rows[0] : null);
        }

        private DataRow[] GetAppConfigRowsByKey(string Key)
        {
            if (MyDataSet.AppConfig.Rows.Count < 1)
                return null;
            DataRow[] rows = new DataRow[] { };

            var dtrows = from dr in MyDataSet.AppConfig.AsEnumerable()
                         where dr[AppConfig.Property_Key].ToString() == Key.ToString()
                         select dr;
            rows = dtrows.ToArray();
            return rows;
        }

        /// <summary>
        /// gets contact object by contact id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public AppConfig GetAppConfigByKey(string Key)
        {
            DataRow row = GetAppConfigRowByKey(Key);
            if (row != null)
            {
                return FillAppConfig(row);
            }

            return null;
        }

        /// <summary>
        /// retrieves all contacts
        /// </summary>
        /// <returns></returns>
        public AppConfigList GetAllAppConfigs()
        {
            return FillAppConfigs(MyDataSet.AppConfig.Rows);
        }

        
        

        /// <summary>
        /// updates AppConfig object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool UpdateAppConfig(AppConfig obj)
        {
            //string query = String.Format("Key = {0}", obj.Key.ToString());
            ////DataRow[] rows = MyDataSet.Contact.Select(query);
            //DataRow[] rows = new DataRow[] { };
            //if (MyDataSet.AppConfig.Rows.Count > 0)
            //    rows = MyDataSet.AppConfig.Select(query);
            DataRow[] rows = GetAppConfigRowsByKey(obj.Key);
            if (rows == null)
                rows = new DataRow[] { };

            TSRDataSet.AppConfigRow row;
            if (rows.Length > 0)
                row = rows[0] as TSRDataSet.AppConfigRow;
            else
                row = MyDataSet.AppConfig.NewAppConfigRow();

            row.Key = obj.Key;
            row.Value = obj.Value;

            if (rows.Length <= 0)
                MyDataSet.AppConfig.Rows.Add(row);

            return true;
        }

        /// <summary>
        /// fills AppConfiglist from dataview [like table]
        /// </summary>
        /// <param name="view"></param>
        /// <returns></returns>
        private AppConfigList FillAppConfigs(IEnumerable rows)
        {
            AppConfigList list = new AppConfigList();

            foreach (DataRow row in rows)
            {
                list.Add(FillAppConfig(row));
            }

            return list;
        }

        /// <summary>
        /// fills AppConfig object from a data row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private AppConfig FillAppConfig(DataRow row)
        {
            TSRDataSet.AppConfigRow cntRow = row as TSRDataSet.AppConfigRow;

            if (cntRow != null)
            {
                AppConfig obj = new AppConfig();

                obj.ID = cntRow.ID;
                obj.Key = cntRow.Key;
                obj.Value = cntRow.Value;

                return obj;
            }

            return null;
        }
    }
}
