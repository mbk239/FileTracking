using System;
using System.Collections.Generic;
using System.Text;

using DAL = TSR.Core.DAL;
using TSR.Core.Entity;
using WS = TSR.Core.UserAgentService;
//using AUTH = TSR.Core.AuthenticationService;
using TSR.Core.Entity.List;
//using TSR.Core.UserAgentService;
using System.Collections.Specialized;
using System.Security.Principal;
using System.DirectoryServices;
using System.Windows.Forms;
using TSR.Core.Logging;

using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Data;
using System.Collections;


namespace TSR.Core
{
    public static class TSRExpenseFacade
    {
        public static bool UserInExpenseLicense()
        {
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = TSRFacade.GetNONADUserName();
            pass.Data = TSRFacade.GetNONADPassword();
            try
            {
                if (!TSRFacade.ServerAddressFound())
                    return false;

                //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
                WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(TSRFacade.GetTSRSSLMode());

                //get user specific data [time entry, setup data]
                WS.ResponseMessageOfboolean response = new TSR.Core.UserAgentService.ResponseMessageOfboolean();
                response = service.UserInExpenseLicense(userName, pass);
                return response.Data;
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
                return true;
            }
        }

        /// <summary>
        /// method to retrieve all organizations
        /// </summary>
        /// <returns></returns>
        public static Entity.ExpenseTypeList GetAllExpenseTypes()
        {
            using (DAL.ExpenseTypeDAL dal = new DAL.ExpenseTypeDAL())
            {
                return dal.GetAllExpenseTypes();
            }
        }

        public static bool UpdateExpenseType(Entity.ExpenseType obj)
        {
            using (DAL.ExpenseTypeDAL dal = new DAL.ExpenseTypeDAL())
            {
                return dal.UpdateExpenseType(obj);
            }
        }

        public static bool UpdateExpenseSheet(Entity.ExpenseSheet obj)
        {
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                return dal.UpdateExpenseSheet(obj);
            }
        }

        public static bool UpdateExpenseSheet(Entity.ExpenseSheet obj, bool includeExpenseEntry)
        {
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                return dal.UpdateExpenseSheet(obj, includeExpenseEntry);
            }
        }

        public static bool UpdateExpenseEntry(Entity.ExpenseEntry obj)
        {
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                return dal.UpdateExpenseEntry(obj);
            }
        }

        public static bool SubmitExpenses(Entity.ExpenseSheet obj)
        {
            bool success = false;
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                if (obj.Status == Core.UserAgentService.StatusEnum.PendingSubmission ||
                    obj.Status == Core.UserAgentService.StatusEnum.Rejected)
                {
                    obj.Status = Core.UserAgentService.StatusEnum.InSubmissionQueue;

                    success = dal.UpdateExpenseSheet(obj);
                }
            }
            return success;
        }

        /// <summary>
        /// method to update organization
        /// </summary>
        /// <param name="obj">organization object to be updated</param>
        /// <returns></returns>        
        public static bool UpdateExpenseType(WS.ExpenseType obj)
        {
            Entity.ExpenseType locObj = new Entity.ExpenseType();
            locObj.ID = obj.ID;
            locObj.Name = obj.Name;
            locObj.Visible = true;
            locObj.DefaultValue = obj.DefaultValue;
            locObj.ForeignKey = obj.ForeignKey;
            locObj.IsActive = obj.IsActive;
            locObj.IsLockedValue = obj.IsLockedValue;

            return UpdateExpenseType(locObj);
        }

        internal static bool FetchAndProcessExpenseType()
        {
            bool success = false;
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();

            userName.Data = TSRFacade.GetNONADUserName();
            pass.Data = TSRFacade.GetNONADPassword();

            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(TSRFacade.GetTSRSSLMode());

            WS.ResponseMessageOfExpenseTypeListWM9H3p7p response = service.GetAllExpenseTypes(userName, pass);
            success = response.IsSuccessful;
            if (success)
            {
                ExpenseTypeList listExpOUA = GetAllExpenseTypes();
                foreach (ExpenseType expOUA in listExpOUA)
                {
                    if (!(response.Data.Exists(delegate(WS.ExpenseType exp) { return exp.ID == expOUA.ID; })))
                    {
                        expOUA.Visible = false;
                        success = UpdateExpenseType(expOUA);
                        if (!success)
                            return false;
                    }
                }
                foreach (WS.ExpenseType expType in response.Data)
                {
                    //update local storage with organization
                    success = UpdateExpenseType(expType);
                    if (!success)
                        return false;
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            return success;
        }

        internal static WS.ResponseMessageOfboolean CheckingAndProcessExpenseMode()
        {
            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = TSRFacade.GetNONADUserName();
            pass.Data = TSRFacade.GetNONADPassword();

            WS.ResponseMessageOfboolean response = new WS.ResponseMessageOfboolean();
            //WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService();
            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(TSRFacade.GetTSRSSLMode());
            response = service.UserInExpenseLicense(userName, pass);

            return response;
        }

        public static ExpenseSheetList GetExpenseSheetsInCurrentCalendarForSync(DateTime start, DateTime end)
        {
            ExpenseSheetList lstExpSheets = new ExpenseSheetList();
            ExpenseSheetList lstExpSheetsToSync = new ExpenseSheetList();
            ExpenseSheetList lstExpSheetsToSyncDeleted = new ExpenseSheetList();

            TimeEntryList lstTimeEntries = new TimeEntryList();
            using (DAL.TimeEntryDAL timeDAL = new DAL.TimeEntryDAL())
            {
                TimeEntryList lstAllTimeEntries = TSRFacade.GetTimeEntriesByAllParams(-1, -1, -1, -1, -1, -1, string.Empty, start, end, false);

                string currentCalendarID = (OutlookHelper.UserSelectedAppointmentFolderForSync != null) 
                    ? OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID : string.Empty;

                //do not synchronize time entry of OLD Database
                foreach (TimeEntry te in lstAllTimeEntries)
                {
                    if (string.IsNullOrEmpty(te.CalendarID) || te.CalendarID.Equals(currentCalendarID))
                    {
                        lstTimeEntries.Add(te);
                    }
                }
            }
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                lstExpSheets = dal.GetAllExpenseSheets(true,true);

                foreach (ExpenseSheet es in lstExpSheets)
                {
                    TimeEntry te = lstTimeEntries.FirstOrDefault(x => x.ID == es.TimeEntryID);
                    if(te != null && te.StartTimeStamp >= start && te.EndTimeStamp < end)
                    {
                        if (es.IsDeleted == true)
                            lstExpSheetsToSyncDeleted.Add(es);
                        else
                            lstExpSheetsToSync.Add(es);
                    }
                }
            }

            foreach(var es in lstExpSheetsToSyncDeleted)
            {
                if(!lstExpSheetsToSync.Any(x=>x.TimeEntryID == es.TimeEntryID))
                {
                    lstExpSheetsToSync.Add(es);
                }
            }

            return lstExpSheetsToSync;
        }

        public static ExpenseSheet GetExpenseSheetByTimeEntryID(Guid teID)
        {
            using (DAL.ExpenseDAL dal = new DAL.ExpenseDAL())
            {
                return dal.GetExpenseSheetByTimeEntryID(teID, true, false);
            }
        }

        internal static Dictionary<long, string> SubmitExpenses(ExpenseSheetList lstExpenseSheets, out bool success)
        {
            WS.RequestMessageOfExpenseSheetListWM9H3p7p req = new WS.RequestMessageOfExpenseSheetListWM9H3p7p();

            //Get user name and password
            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = TSRFacade.GetNONADUserName();
            pass.Data = TSRFacade.GetNONADPassword();

            WS.ResponseMessageOfArrayOfKeyValueOflongstringuHEDJ7Dj response = new TSR.Core.UserAgentService.ResponseMessageOfArrayOfKeyValueOflongstringuHEDJ7Dj();

            success = false;

            WS.ExpenseSheetList lst = new WS.ExpenseSheetList();
            foreach (ExpenseSheet esLocal in lstExpenseSheets)
            {
                WS.ExpenseSheet esServer = esLocal.ConvertToServer();
                lst.Add(esServer);
            }
            req.Data = lst;
            using (WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(TSRFacade.GetTSRSSLMode()))
            {
                response = service.SubmitExpenses(userName, pass, req);
                success = response.IsSuccessful;
                if (success != true && !string.IsNullOrEmpty(response.ErrorMessage))// delete all deleted Expense
                {
                    //fail
                }
                else
                {
                    foreach (var item in lstExpenseSheets)
                    {
                        if (item.IsDeleted == true)
                        {
                            //really delete this item after sync it to server
                            item.IsDeleted = false;
                            item.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                            UpdateExpenseSheet(item);
                        }
                    }
                }
            }
           
            if (!response.IsSuccessful)
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }
            return response.Data;
        }

        internal static ExpenseSheetList ProcessExpenses(DateTime start, DateTime end)
        {
            WS.RequestMessageOfdateTime startReq = new WS.RequestMessageOfdateTime();
            startReq.Data = start;
            WS.RequestMessageOfdateTime endReq = new WS.RequestMessageOfdateTime();
            endReq.Data = end;
            WS.RequestMessageOfstring reCalendarID = new WS.RequestMessageOfstring();

            WS.RequestMessageOfstring userName = new WS.RequestMessageOfstring();
            WS.RequestMessageOfstring pass = new WS.RequestMessageOfstring();
            userName.Data = TSRFacade.GetNONADUserName();
            pass.Data = TSRFacade.GetNONADPassword();

            TimeEntryList listSyncedTimeEntry = new TimeEntryList();

            reCalendarID.Data = OutlookHelper.UserSelectedAppointmentFolderForSync.EntryID;

            WS.UserAgentServiceClient service = ServiceProvider.GetUserAgentService(TSRFacade.GetTSRSSLMode());
            WS.ResponseMessageOfExpenseSheetListWM9H3p7p response = service.GetExpensesResponse(userName, pass, startReq, endReq, reCalendarID);

            ExpenseSheetList list = new ExpenseSheetList();

            if (response.Data == null)
                return list;

            if (response.IsSuccessful)
            {
                DataSet ds = DAL.BaseDAL.MyDataSet;

                foreach (WS.ExpenseSheet sheet in response.Data)
                {
                    ExpenseSheet sheetLocal = new ExpenseSheet();
                    TimeEntry te = null;

                    if (te != null && te.IsDeleted && te.IsDeletedOnServer.Value) // time entry tren server co, duoi local ko co
                    {

                    }

                    sheetLocal.PopulateFromServer(sheet);
                    if (sheet.IsDeletedOnServer)
                    {
                        ExpenseSheet sheetTest = GetExpenseSheetByTimeEntryID(sheet.TimeEntryID);
                        if (sheetTest != null && sheetTest.Revision > 0) //Exist an sheet for the time entry but this sheet is deleted on server
                        {
                            sheetLocal.IsDeleted = true;
                            //sheetLocal.RowState = WS.BaseBusinessEntity.RowStateEnum.DeletedRow;
                            list.Add(sheetLocal);
                        }
                    }
                    else
                    {
                        list.Add(sheetLocal);
                    }
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(response.ErrorMessage))
                    throw new Exception(response.ErrorMessage);
            }

            using (DAL.ExpenseDAL expDal = new DAL.ExpenseDAL())
            {
                expDal.UpdateExpenseSheetsFromServer(list, true);
            }

            return list;
        }
    }
}