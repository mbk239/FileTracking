using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.Core
{
    /// <summary>
    /// Classs
    /// Name: ResourceHelper
    /// This class handles all properties related to resources
    /// and localization
    /// </summary>
    public class ResourceHelper
    {
        public static System.Drawing.Icon TSRIcon
        {
            get
            {
                return Properties.Resources.TSRIcon;
            }
        }

        public static System.Drawing.Bitmap TSRIcon_BMP
        {
            get
            {
                System.Drawing.Icon icon = new System.Drawing.Icon(TSRIcon, 32, 32);
                return icon.ToBitmap();
            }
            //get { return Properties.Resources.TSRIcon_32; }
        }

        public static string Organization
        {
            get { return ResourceManager.GetResourceString("Organization", Properties.Resources.Organization); }
        }
        public static string DonnotShowAgainMsgLabelText
        {
            get { return ResourceManager.GetResourceString("DonnotShowAgainWhenSubmittingTimeEntryMsg", "Do not show warning when submitting an entry"); }
        }
        public static string DoNotRetrieveSettingsText
        {
            get { return ResourceManager.GetResourceString("DoNotRetrieveSettingsFromServer", "Do not retrieve settings from server automatically"); }
        }
        public static string ShowMessgaBoxYes
        {
            get { return ResourceManager.GetResourceString("Yes", "Yes"); }
        }
        public static string ShowMessgaBoxFormText
        {
            get { return ResourceManager.GetResourceString("ShowMessgaBoxForm", "Message box"); }
        }
        public static string ShowMessgaBoxNo
        {
            get { return ResourceManager.GetResourceString("No", "No"); }
        }
        public static string Favorite
        {
            get { return ResourceManager.GetResourceString("Favorite", "Favorite"); }
        }

        public static string SaveSettingsToServer
        {
            get { return ResourceManager.GetResourceString("SaveSettingsToServer", "Save settings to Server"); }
        }

        public static string RetriveSettingsFromServer
        {
            get { return ResourceManager.GetResourceString("RetriveSettingsFromServer", "Retrive settings from server"); }
        }

        public static string RetriveDefaultSettings
        {
            get { return ResourceManager.GetResourceString("RetriveDefaultSettings", "Retrive default settings"); }
        }

        public static string Show
        {
            get { return ResourceManager.GetResourceString("Show", "Show"); }
        }

        public static string Details
        {
            get { return ResourceManager.GetResourceString("Details", "Details"); }
        }

        public static string RetriveFavoriteFromServer
        {
            get { return ResourceManager.GetResourceString("RetriveFavoriteFromServer", "Retrive favorites from server"); }
        }

        public static string SaveFavoritesToServer
        {
            get { return ResourceManager.GetResourceString("SaveFavoritesToServer", "Save favorites to server"); }
        }

        public static string Project
        {
            get { return ResourceManager.GetResourceString("Project", Properties.Resources.Project); }
        }

        public static string Activity
        {
            get { return ResourceManager.GetResourceString("Activity", Properties.Resources.Activity); }
        }

        public static string Task
        {
            get { return ResourceManager.GetResourceString("Task", Properties.Resources.Task); }
        }

        public static string Contact
        {
            get { return ResourceManager.GetResourceString("Contact", Properties.Resources.Contact); }
        }

        public static string Subject
        {
            get { return ResourceManager.GetResourceString("Subject", Properties.Resources.Subject); }
        }

        public static string StartTime
        {
            get { return ResourceManager.GetResourceString("StartTime", Properties.Resources.StartTime); }
        }

        public static string EndTime
        {
            get { return ResourceManager.GetResourceString("EndTime", Properties.Resources.EndTime); }
        }

        public static string Status
        {
            get { return ResourceManager.GetResourceString("Status", Properties.Resources.Status); }
        }

        //Added by tsrdev1
        //Added datetime 06/10/2010 
        public static string SubmittedBy
        {
            get { return ResourceManager.GetResourceString("Submitted By", "Submitted By"); }
        }
        public static string Ribbon_AdvancedButton
        {
            get { return ResourceManager.GetResourceString("Ribbon_AdvancedButton", Properties.Resources.Ribbon_AdvancedButton); }
        }

        public static string Ribbon_SubmitButton
        {
            get { return ResourceManager.GetResourceString("Ribbon_SubmitButton", Properties.Resources.Ribbon_SubmitButton); }
        }

        public static string Ribbon_TSRSetupGroup
        {
            get { return ResourceManager.GetResourceString("Ribbon_TSRSetupGroup", Properties.Resources.Ribbon_TSRSetupGroup); }
        }

        public static string RibbonTip_SubmitButton
        {
            get { return ResourceManager.GetResourceString("RibbonTip_SubmitButton", Properties.Resources.RibbonTip_SubmitButton); }
        }

        public static string Search
        {
            get { return ResourceManager.GetResourceString("Search", Properties.Resources.Search); }
        }

        public static string DeleteButtonText
        {
            get { return ResourceManager.GetResourceString("Delete", "Delete"); }
        }
        
        public static string Submit
        {
            get { return ResourceManager.GetResourceString("Submit", Properties.Resources.Submit); }
        }

        public static string Save
        {
            get { return ResourceManager.GetResourceString("Save", Properties.Resources.Save); }
        }
        
        public static string Cancel
        {
            get { return ResourceManager.GetResourceString("Cancel", Properties.Resources.Cancel); }
        }

        public static string SelectAll
        {
            get { return ResourceManager.GetResourceString("SelectAll", Properties.Resources.SelectAll); }
        }

        public static string SearchItems
        {
            get { return ResourceManager.GetResourceString("SearchItems", Properties.Resources.SearchItems); }
        }

        public static string OtherInformation
        {
            get { return ResourceManager.GetResourceString("OtherInformation", Properties.Resources.OtherInformation); }
        }

        public static string Response
        {
            get { return ResourceManager.GetResourceString("Response", Properties.Resources.Response); }
        }

        public static string ItemsFormHeadingText
        {
            get { return ResourceManager.GetResourceString("ItemsFormHeadingText", Properties.Resources.ItemsFormHeadingText); }
        }

        public static string TimeEntryAdvancedFormHeadingText
        {
            get { return ResourceManager.GetResourceString("TimeEntryAdvancedFormHeadingText", Properties.Resources.TimeEntryAdvancedFormHeadingText); }
        }
        
        public static string OrganizationSelectionText
        {
            get { return ResourceManager.GetResourceString("OrganizationSelectionText", Properties.Resources.OrganizationSelectionText); }
        }

        public static string ProjectSelectionText
        {
            get { return ResourceManager.GetResourceString("ProjectSelectionText", Properties.Resources.ProjectSelectionText); }
        }

        public static string ActivitySelectionText
        {
            get { return ResourceManager.GetResourceString("ActivitySelectionText", Properties.Resources.ActivitySelectionText); }
        }

        public static string TaskSelectionText
        {
            get { return ResourceManager.GetResourceString("TaskSelectionText", Properties.Resources.TaskSelectionText); }
        }

        public static string ContactSelectionText
        {
            get { return ResourceManager.GetResourceString("ContactSelectionText", Properties.Resources.ContactSelectionText); }
        }

        public static string UserAccountText
        {
            get { return ResourceManager.GetResourceString("UserAccount", Properties.Resources.UserAccount); }
        }
        public static string WhatToSyncText
        {
            get { return ResourceManager.GetResourceString("WhatToSync", Properties.Resources.WhatToSync); }
        }

        public static string SyncRangeText
        {
            get { return ResourceManager.GetResourceString("SyncRange", Properties.Resources.SyncRange); }
        }

        public static string AutoSyncText
        {
            get { return ResourceManager.GetResourceString("AutoSync", Properties.Resources.AutoSync); }
        }
        public static string MiscText
        {
            get { return ResourceManager.GetResourceString("Miscellaneous", Properties.Resources.Miscellaneous); }
        }
        public static string PreferencesText
        {
            get { return ResourceManager.GetResourceString("Preferences", Properties.Resources.Preferences); }
        }

        public static string PasswordLebelText
        {
            get { return ResourceManager.GetResourceString("Passwd_LebelText", Properties.Resources.Passwd_LebelText); }
        }
        public static string UserNameLebelText
        {
            get { return ResourceManager.GetResourceString("UserName_LebelText", Properties.Resources.UserName_LebelText); }
        }
        public static string ServerAddressLebelText
        {
            get { return ResourceManager.GetResourceString("ServerAddress_LebelText", Properties.Resources.ServerAddress_LebelText); }
        }
        //public static string TestUserCredentialLebelText
        //{
        //    get { return ResourceManager.GetResourceString("TestUserCredential_LebelText", Properties.Resources.TestUserCredential_LebelText); }
        //}

        public static string UserAccountInfoMsgLebelText
        {
            get { return ResourceManager.GetResourceString("UserAccountInfoMsg_LebelText", Properties.Resources.UserAccountInfoMsg_LebelText); }
        }

        public static string OutlookFolderLebelText
        {
            get { return ResourceManager.GetResourceString("OutlookFloder_LebelText", Properties.Resources.OutlookFloder_LebelText); }
        }
        public static string SetupDataCheckBoxText
        {
            get { return ResourceManager.GetResourceString("SetupData_CheckBoxText", Properties.Resources.SetupData_CheckBoxText); }
        }

        public static string TSRItemsCheckBoxText
        {
            get { return ResourceManager.GetResourceString("TSRItems_CheckBoxText", Properties.Resources.TSRItems_CheckBoxText); }
        }

        public static string WhatToSyncInfoMsgLebelText
        {
            get { return ResourceManager.GetResourceString("WhatToSyncInfoMsg_LebelText", Properties.Resources.WhatToSyncInfoMsg_LebelText); }
        }

        public static string SyncRangeInfoMsgLebelText
        {
            get { return ResourceManager.GetResourceString("SyncRangeInfoMsg_LebelText", Properties.Resources.SyncRangeInfoMsg_LebelText); }
        }

        //public static string TooltipOptionText
        //{
        //    get { return ResourceManager.GetResourceString("TooltipOptionText", Properties.Resources.TooltipOptionText); }
        //}

        //public static string TooltipOptionWarning
        //{
        //    get { return ResourceManager.GetResourceString("TurnOnTooltipWarning", Properties.Resources.TurnOnTooltipWarning); }
        //}

        public static string FromLebelText
        {
            get { return ResourceManager.GetResourceString("From_LebelText", Properties.Resources.From_LebelText); }
        }

        public static string ToLebelText
        {
            get { return ResourceManager.GetResourceString("To_LebelText", Properties.Resources.To_LebelText); }
        }

        public static string InThePastLebelText
        {
            get { return ResourceManager.GetResourceString("InThePast_LebelText", Properties.Resources.InThePast_LebelText); }
        }

        public static string InTheFutureLabelText
        {
            get { return ResourceManager.GetResourceString("InTheFutureLabelText", "in the future"); }
        }

        public static string PreferredLanguageLabelText
        {
            get { return ResourceManager.GetResourceString("PreferredLanguageLabelText", "Preferred Language"); }
        }
        
        public static string AutoSyncInfoMsgLebelText
        {
            get { return ResourceManager.GetResourceString("AutoSyncInfoMsg_LebelText", Properties.Resources.AutoSyncInfoMsg_LebelText); }
        }

        public static string DotNotAutoSyncRadioButtonText
        {
            get { return ResourceManager.GetResourceString("NotAutosync_RadioButtonText", Properties.Resources.NotAutosync_RadioButtonText); }
        }

        public static string AutomaticallySyncRadioButtonText
        {
            get { return ResourceManager.GetResourceString("AutomaticallySyncRadioButtonText", "Automatically Synchronize"); }
        }
        
        public static string AutoSyncEveryTimeRadioButtonText
        {
            get { return ResourceManager.GetResourceString("AutoSyncEveryTime_RadioButtonText", Properties.Resources.AutoSyncEveryTime_RadioButtonText); }
        }

        public static string AutoSyncOnCloseRadioButtonText
        {
            get { return ResourceManager.GetResourceString("AutoSyncOnCloseRadioButtonText", "Synchronize on Outlook shutdown"); }
        }
        
        public static string AutoSyncPeriodRadioButtonText
        {
            get { return ResourceManager.GetResourceString("AutoSyncPeriod_RadioButtonText", Properties.Resources.AutoSyncPeriod_RadioButtonText); }
        }

        public static string PeriodLebelText
        {
            get { return ResourceManager.GetResourceString("Period_LebelText", Properties.Resources.Period_LebelText); }
        }

        public static string LaunchTSRCheckBoxText
        {
            get { return ResourceManager.GetResourceString("MiscLaunch_CheckBoxText", Properties.Resources.MiscLaunch_CheckBoxText); }
        }

        public static string DoNotSyncCompletedDataCheckBoxText
        {
            get { return ResourceManager.GetResourceString("MiscNotSyncCompletedData_CheckBoxText", Properties.Resources.MiscNotSyncCompletedData_CheckBoxText); }
        }

        public static string DoNotSyncTECreatedViaWebCheckBoxText
        {
            get { return ResourceManager.GetResourceString("DoNotSynTECreatedViaWeb", Properties.Resources.DoNotSynTECreatedViaWeb); }
        }

        public static string RecreateRemovedTSRAppointmentCheckBoxText
        {
            get { return ResourceManager.GetResourceString("MiscRecreateRemovedTSRAppointment_CheckBoxText", Properties.Resources.MiscRecreateRemovedTSRAppointmentData_CheckBoxText); }
        }

        public static string Settings
        {
            get { return ResourceManager.GetResourceString("Settings", Properties.Resources.Settings); }
        }

        public static string For
        {
            get { return ResourceManager.GetResourceString("For", "For"); }
        }

        public static string Current
        {
            get { return ResourceManager.GetResourceString("Current", "Current"); }
        }

        public static string Synchronization
        {
            get { return ResourceManager.GetResourceString("Synchronization", "Synchronization"); }
        }

        public static string OK
        {
            get { return ResourceManager.GetResourceString("OK", Properties.Resources.OK); }
        }

        public static string Help
        {
            get { return ResourceManager.GetResourceString("Help", Properties.Resources.Help); }
        }

        public static string Add
        {
            get { return ResourceManager.GetResourceString("Add", Properties.Resources.Add); }
        }
        public static string Remove
        {
            get { return ResourceManager.GetResourceString("Remove", Properties.Resources.Remove); }
        }

        public static string StatusSelectionText
        {
            get { return ResourceManager.GetResourceString("StatusSelectionText", Properties.Resources.StatusSelectionText); }
        }

        public static string MessageHistory
        {
            get { return ResourceManager.GetResourceString("MessageHistory", Properties.Resources.MessageHistory); }
        }

        public static string OrgNotAvailableMsg
        {
            get { return ResourceManager.GetResourceString("OrgNotAvailableMsg", Properties.Resources.OrgNotAvailableMsg); }
        }

        public static string ProjectNotAvailableMsg
        {
            get { return ResourceManager.GetResourceString("ProjectNotAvailableMsg", Properties.Resources.ProjectNotAvailableMsg); }
        }

        public static string ActivityNotAvailableMsg
        {
            get { return ResourceManager.GetResourceString("ActivityNotAvailableMsg", Properties.Resources.ActivityNotAvailableMsg); }
        }

        public static string InfomationAlreadyExistInGridMsg
        {
            get { return ResourceManager.GetResourceString("InfomationAlreadyExistInGridMsg", Properties.Resources.InfomationAlreadyExistInGridMsg); }
        }

        public static string TestServerAddressUpButtonText
        {
            get { return ResourceManager.GetResourceString("TestServerAddressUp_ButtonText", Properties.Resources.TestServerAddressUp_ButtonText); }
        }

        public static string Reset
        {
            get { return ResourceManager.GetResourceString("Reset", Properties.Resources.Reset); }
        }

        public static string DefaultGridColumnHeaderText
        {
            get { return ResourceManager.GetResourceString("Default_GridColumnHeaderText", Properties.Resources.Default_GridColumnHeaderText); }
        }

        public static string ServerUpSuccessMsg
        {
            get { return ResourceManager.GetResourceString("ServerUpSuccessMsg", Properties.Resources.ServerUpSuccessMsg); }
        }

        public static string ServerUpFailureMsg
        {
            get { return ResourceManager.GetResourceString("ServerUpFailureMsg", Properties.Resources.ServerUpFailureMsg); }
        }

        public static string ServerSettingWarningMessage
        {
            get { return ResourceManager.GetResourceString("ServerSettingWarningMessage", Properties.Resources.ServerSettingWarningMessage); }
        }

        public static string ServerSettingWarningMessageCaption
        {
            get { return ResourceManager.GetResourceString("ServerSettingWarningMessageCaption", Properties.Resources.ServerSettingWarningMessageCaption); }
        }

        //button text on synchronize screen
        public static string StartSynchronization
        {
            get { return ResourceManager.GetResourceString("StartSynchronization", "Start synchronization"); }
        }
        
        //button text on synchronize screen
        public static string ViewSynchronizedTimeEntries
        {
            get { return ResourceManager.GetResourceString("ViewSynchronizedTimeEntries", "View synchronized Time entries"); }
        }

        public static string Untitled
        {
            get { return ResourceManager.GetResourceString("Untitled", Properties.Resources.Untitled); }
        }

        public static string CheckingServerAddress
        {
            get { return ResourceManager.GetResourceString("CheckingServerAddress", Properties.Resources.CheckingServerAddress); }
        }

        public static string ServerAddressFound
        {
            get { return ResourceManager.GetResourceString("ServerAddressFound", Properties.Resources.ServerAddressFound); }
        }

        public static string LicenseRetrievalInOUASuccessful
        {
            get { return ResourceManager.GetResourceString("LicenseRetrievalInOUASuccessful", Properties.Resources.LicenseRetrievalInOUASuccessful); }
        }

        public static string RestoreSetupDataSuccessful
        {
            get { return ResourceManager.GetResourceString("RestoreSetupDataSuccessful", Properties.Resources.RestoreSetupDataSuccessful); }
        }

        public static string CheckingSetupDataSuccessful
        {
            get { return ResourceManager.GetResourceString("CheckingSetupDataSuccessful", Properties.Resources.CheckingSetupDataSuccessful); }
        }

        public static string RecreatingRemovedAppointments
        {
            get { return ResourceManager.GetResourceString("RecreatingRemovedAppointments", Properties.Resources.RecreatingRemovedAppointments); }
        }

        public static string NoRecreatedAppointment
        {
            get { return ResourceManager.GetResourceString("NoRecreatedAppointment", Properties.Resources.NoRecreatedAppointment); }
        }

        public static string OfflinePreferredLanguageDataUpdateSuccessful
        {
            get { return ResourceManager.GetResourceString("OfflinePreferredLanguageDataUpdateSuccessful", Properties.Resources.OfflinePreferredLanguageDataUpdateSuccessful); }
        }
        
        public static string LicenseHasBeenExpired
        {
            get { return ResourceManager.GetResourceString("LicenseHasBeenExpired", Properties.Resources.LicenseHasBeenExpired); }
        }
        
        public static string LicenseRetrievalInOUAFailed
        {
            get { return ResourceManager.GetResourceString("LicenseRetrievalInOUAFailed", Properties.Resources.LicenseRetrievalInOUAFailed); }
        }

        public static string PleaseContactYourAdministrator
        {
            get { return ResourceManager.GetResourceString("PleaseContactYourAdministrator", Properties.Resources.PleaseContactYourAdministrator); }
        }
        
        public static string ErrorRetrievingLicenseInfoInOUA
        {
            get { return ResourceManager.GetResourceString("ErrorRetrievingLicenseInfoInOUA", Properties.Resources.ErrorRetrievingLicenseInfoInOUA); }
        }
        
        public static string RetrievingUserAgentDataSuccessful
        {
            get { return ResourceManager.GetResourceString("RetrievingUserAgentDataSuccessful", Properties.Resources.RetrievingUserAgentDataSuccessful); }
        }

        public static string RetrievingUserAgentDataFailed
        {
            get { return ResourceManager.GetResourceString("RetrievingUserAgentDataFailed", Properties.Resources.RetrievingUserAgentDataFailed); }
        }
        
        public static string ErrorRetrievingUserAgentData
        {
            get { return ResourceManager.GetResourceString("ErrorRetrievingUserAgentData", Properties.Resources.ErrorRetrievingUserAgentData); }
        }
        
        public static string CheckingSetupDataFailed
        {
            get { return ResourceManager.GetResourceString("CheckingSetupDataFailed", Properties.Resources.CheckingSetupDataFailed); }
        }
        
        public static string ErrorCheckingSetupData
        {
            get { return ResourceManager.GetResourceString("ErrorCheckingSetupData", Properties.Resources.ErrorCheckingSetupData); }
        }
        
        public static string RestoreSetupDataFailed
        {
            get { return ResourceManager.GetResourceString("RestoreSetupDataFailed", Properties.Resources.RestoreSetupDataFailed); }
        }

        public static string ErrorRestoringSetupData
        {
            get { return ResourceManager.GetResourceString("ErrorRestoringSetupData", Properties.Resources.ErrorRestoringSetupData); }
        }

        public static string SavingUserAgentDataIntoServerSuccess
        {
            get { return ResourceManager.GetResourceString("SavingUserAgentDataIntoServerSuccess", Properties.Resources.SavingUserAgentDataIntoServerSuccess); }
        }
        
        public static string SavingUserAgentDataIntoServerFailure
        {
            get { return ResourceManager.GetResourceString("SavingUserAgentDataIntoServerFailure", Properties.Resources.SavingUserAgentDataIntoServerFailure); }
        }

        public static string ErrorSavingUserAgentDataIntoServer
        {
            get { return ResourceManager.GetResourceString("ErrorSavingUserAgentDataIntoServer", Properties.Resources.ErrorSavingUserAgentDataIntoServer); }
        }

        public static string ProblemWithRemoteService
        {
            get { return ResourceManager.GetResourceString("ProblemWithRemoteService", Properties.Resources.ProblemWithRemoteService); }
        }

        public static string ServerAddressNotFound
        {
            get { return ResourceManager.GetResourceString("ServerAddressNotFound", Properties.Resources.ServerAddressNotFound); }
        }

        public static string PleaseSaveRightServerAddressInSettings
        {
            get { return ResourceManager.GetResourceString("PleaseSaveRightServerAddressInSettings", Properties.Resources.PleaseSaveRightServerAddressInSettings); }
        }

        public static string SavingFavouritesInServerSuccessful
        {
            get { return ResourceManager.GetResourceString("SavingFavouritesInServerSuccessful", Properties.Resources.SavingFavouritesInServerSuccessful); }
        }

        public static string SavingFavouritesInServerFailed
        {
            get { return ResourceManager.GetResourceString("SavingFavouritesInServerFailed", Properties.Resources.SavingFavouritesInServerFailed); }
        }

        public static string ErrorSavingFavoritesInServer
        {
            get { return ResourceManager.GetResourceString("ErrorSavingFavoritesInServer", Properties.Resources.ErrorSavingFavoritesInServer); }
        }

        public static string RetrievingFavoritesFromServerSuccessful
        {
            get { return ResourceManager.GetResourceString("RetrievingFavoritesFromServerSuccessful", Properties.Resources.RetrievingFavoritesFromServerSuccessful); }
        }

        public static string RetrievingFavoritesFromServerFailed
        {
            get { return ResourceManager.GetResourceString("RetrievingFavoritesFromServerFailed", Properties.Resources.RetrievingFavoritesFromServerFailed); }
        }

        public static string ErrorRetrievingFavoritesFromServer
        {
            get { return ResourceManager.GetResourceString("ErrorRetrievingFavoritesFromServer", Properties.Resources.ErrorRetrievingFavoritesFromServer); }
        }

        public static string SavingSettingsInServerSuccessful
        {
            get { return ResourceManager.GetResourceString("SavingSettingsInServerSuccessful", Properties.Resources.SavingSettingsInServerSuccessful); }
        }

        public static string SavingSettingsInServerFailed
        {
            get { return ResourceManager.GetResourceString("SavingSettingsInServerFailed", Properties.Resources.SavingSettingsInServerFailed); }
        }

        public static string ErrorSavingSettingsInServer
        {
            get { return ResourceManager.GetResourceString("ErrorSavingSettingsInServer", Properties.Resources.ErrorSavingSettingsInServer); }
        }

        public static string RetrievingSettingsfromServerSuccessful
        {
            get { return ResourceManager.GetResourceString("RetrievingSettingsfromServerSuccessful", Properties.Resources.RetrievingSettingsfromServerSuccessful); }
        }

        public static string ShowOnlyFavoritesText
        {
            get { return ResourceManager.GetResourceString("ShowOnlyFavoritesText", Properties.Resources.ShowOnlyFavoritesText); }
        }

        public static string Favorites
        {
            get { return ResourceManager.GetResourceString("Favorites", Properties.Resources.Favorites); }
        }

        public static string Location
        {
            get { return ResourceManager.GetResourceString("Location", Properties.Resources.Location); }
        }

        public static string SelectAFavotite
        {
            get { return ResourceManager.GetResourceString("SelectAFavotite", Properties.Resources.SelectAFavotite); }
        }

        public static string Duration
        {
            get { return ResourceManager.GetResourceString("Duration", Properties.Resources.Duration); }
        }

        public static string lblTotalDurationSelectedText
        {
            get { return ResourceManager.GetResourceString("lblTotalDurationSelectedText", Properties.Resources.lblTotalDurationSelectedText); }
        }

        public static string lblTotalDurationText
        {
            get { return ResourceManager.GetResourceString("lblTotalDurationText", Properties.Resources.lblTotalDurationText); }
        }

        public static string Next7Days
        {
            get { return ResourceManager.GetResourceString("Next7Days", Properties.Resources.Next7Days); }
        }

        public static string Previous7Days
        {
            get { return ResourceManager.GetResourceString("Previous7Days", Properties.Resources.Previous7Days); }
        }

        public static string ListTimeEntriesOUA
        {
            get { return ResourceManager.GetResourceString("ListTimeEntriesOUA", "List time entries - Outlook User Agent"); }
        }

        public static string SelectALocation
        {
            get { return ResourceManager.GetResourceString("SelectALocation", Properties.Resources.SelectALocation); }
        }

        public static string PleaseEnterAppropriateOUA
        {
            get { return ResourceManager.GetResourceString("PleaseEnterAppropriateOUA", Properties.Resources.PleaseEnterAppropriateOUA); }
        }

        //Item originates from web
        public static string IsCreatedViaWeb
        {
            get { return ResourceManager.GetResourceString("IsCreatedViaWeb", Properties.Resources.IsCreatedViaWeb); }
        }

        public static string ShowAllItems
        {
            get { return ResourceManager.GetResourceString("ShowAllItems", Properties.Resources.ShowAllItem); }
        }
 
        //public static string ErrorRestoringSetupData
        //{
        //    get { return ResourceManager.GetResourceString("ErrorRestoringSetupData", Properties.Resources.ErrorRestoringSetupData); }
        //}

        //public static string ErrorRestoringSetupData
        //{
        //    get { return ResourceManager.GetResourceString("ErrorRestoringSetupData", Properties.Resources.ErrorRestoringSetupData); }
        //}

        public static string LockedPeriodMessage
        {
            get { return ReverseToHTMLCode(ResourceManager.GetResourceString("LockedPeriodMessage", Properties.Resources.LockedPeriodMessage)); }
        }

        public static string ReverseToHTMLCode(object objCheck)
        {
            Object value = objCheck;
            if (objCheck != null && objCheck is string)
            {
                value = value.ToString().Replace("&lt;", "<").Replace("&gt;", ">").Replace("&#47;", "/");
            }
            if (value == null)
                value = string.Empty;
            return value.ToString();
        }
    }
}
