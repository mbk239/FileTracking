﻿namespace TSR.Core {
    
    
    public partial class TSRDataSet {
        partial class LocationDataTable
        {
        }
    
        partial class ExpenseEntryDataTable
        {
        }
    
        partial class ExpenseSheetDataTable
        {
        }
    
        partial class ExpenseTypeDataTable
        {
        }
    
        partial class ActivityTypeDataTable
        {
        }
    
        partial class Project_ProjectTypeDataTable
        {
        }
    
        partial class OrganizationDataTable
        {
        }
    
        partial class TimeEntry_OutlookAppointmentDataTable
        {
        }
    
        partial class LanguageResourcesDataTable
        {
        }
    
        partial class TimeEntryDataTable
        {
        }
    
        partial class AppConfigDataTable
        {
        }
    }
}
namespace TSR.Core.TSRDataSetTableAdapters
{
    
    
    public partial class TSRDataSet {
    }
}
