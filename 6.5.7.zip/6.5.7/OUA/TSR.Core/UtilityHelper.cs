﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Windows.Forms;
using TSR.Core.Logging;

namespace TSR.Core
{
    public enum ValidationMode
    {
        AD,
        NONAD
    }
    public enum ExchangeMode
    {
        No = 0,
        Yes = 1

    }
    public class RegistryHelpers
    {
        public static RegistryKey GetRegistryKey()
        {
            return null;
        }

        public static RegistryKey GetRegistryKey(RegistryHive regLocation, string keyPath, bool writeable)
        {
            RegistryKey localMachineRegistry
                = RegistryKey.OpenBaseKey(regLocation,
                                          Environment.Is64BitOperatingSystem
                                              ? RegistryView.Registry64
                                              : RegistryView.Registry32);

            return string.IsNullOrEmpty(keyPath)
                ? localMachineRegistry
                : localMachineRegistry.OpenSubKey(keyPath, writeable);
        }

        public static object GetRegistryValue(RegistryHive regLocation, string keyPath, string keyName)
        {
            RegistryKey registry = GetRegistryKey(regLocation, keyPath, false);
            return registry.GetValue(keyName);
        }
    }

    public class UtilityHelper
    {
        #region Variable
        [DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int GetPrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpDefault,
            string lpReturnString,
            int nSize,
            string lpFilename);

        [DllImport("KERNEL32.DLL", EntryPoint = "WritePrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int WritePrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpString,
            string lpFilename);
        #endregion Variable
        private const string addinLocation = @"Software\Microsoft\Office\Outlook\Addins";
        private const string TSRINIFilePathKey_Name = @"TSRINIFilePath";
        private const string USER_SID = "USERSID";

        public static bool CheckValidConfigurationFile(string filePath)
        {
            string strValidationMode = GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE);
            ValidationMode mode;
            if (!string.IsNullOrEmpty(strValidationMode) && (strValidationMode.ToUpper() == ValidationMode.AD.ToString() ||
                strValidationMode.ToUpper() == ValidationMode.NONAD.ToString()))
                mode = (strValidationMode.ToUpper() == ValidationMode.AD.ToString()) ? ValidationMode.AD : ValidationMode.NONAD;
            else
                return false;
            if (mode == ValidationMode.NONAD)
                if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO)))
                    return false;
            if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES)))
                return false;
            if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRWEBADMIN)))
                return false;
            //if (mode == ValidationMode.AD)
            //{
            string strExchangeMode = GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_EXCHANGEMODE);
            if (!(!string.IsNullOrEmpty(strExchangeMode) && (strExchangeMode.ToUpper() == ExchangeMode.Yes.ToString().ToUpper() ||
                strExchangeMode.ToUpper() == ExchangeMode.No.ToString().ToUpper())))
                return false;
            //}
            return true;
        }
        public static bool IsExistedFile(string filePath)
        {
            return File.Exists(filePath);

        }

        /// <summary>
        /// Store ini file path into registry
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static bool StorteINIFilePath(string filePath)
        {
            RegistryKey userSettingsKey = null;
            RegistryKey TSRINIFilePathKey = null;
            try
            {
                userSettingsKey = Registry.LocalMachine.OpenSubKey(addinLocation, true);

                if (userSettingsKey == null)
                    return false;
                TSRINIFilePathKey = userSettingsKey.OpenSubKey(TSRINIFilePathKey_Name, true);

                if (TSRINIFilePathKey == null)
                {
                    TSRINIFilePathKey = userSettingsKey.CreateSubKey(TSRINIFilePathKey_Name);
                }

                TSRINIFilePathKey.SetValue(TSRINIFilePathKey_Name, filePath);
            }
            catch //(Exception ex)
            {
                return false;
            }
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return true;
        }

        /// <summary>
        /// Read ini file path from registry
        /// </summary>
        /// <returns></returns>
        public static string GetINIFilePath()
        {
            string path = string.Empty;

            //RegistryKey userSettingsKey = null;
            //RegistryKey TSRINIFilePathKey = null;
            try
            {
                path = (string)RegistryHelpers.GetRegistryValue(RegistryHive.LocalMachine, addinLocation + "\\" + TSRINIFilePathKey_Name, TSRINIFilePathKey_Name);

                //userSettingsKey = Registry.LocalMachine.OpenSubKey(addinLocation, false);
                //if (userSettingsKey != null)
                //{
                //    TSRINIFilePathKey = userSettingsKey.OpenSubKey(TSRINIFilePathKey_Name, false);

                //    if (TSRINIFilePathKey != null)
                //    {
                //        path = TSRINIFilePathKey.GetValue(TSRINIFilePathKey_Name, string.Empty).ToString();
                //    }
                //}
            }
            catch
            {
            }
            //finally
            //{
            //    if (TSRINIFilePathKey != null)
            //        TSRINIFilePathKey.Close();
            //    if (userSettingsKey != null)
            //        userSettingsKey.Close();
            //}
            return path;
        }

        public static string GetCurrentUserSID()
        {
            string sid = string.Empty;
            try
            {
                sid = (string)RegistryHelpers.GetRegistryValue(RegistryHive.LocalMachine, addinLocation + "\\" + TSRINIFilePathKey_Name, USER_SID);
            }
            catch (Exception ex)
            {
                Log regPathLog = new Log();
                regPathLog.Category = "GetCurrentUserSID";
                regPathLog.MessageDetail = "TSR.Core.UtilityHelper method GetCurrentUserSID: " + ex.Message;
                regPathLog.LoggingTime = DateTime.Now;
                TSR.Core.Logging.LoggingHandler.LogWarning(regPathLog);
            }
            //finally
            //{
            //    if (TSRINIFilePathKey != null)
            //        TSRINIFilePathKey.Close();
            //    if (userSettingsKey != null)
            //        userSettingsKey.Close();
            //}
            return sid;
        }

        /// <summary>
        /// Remove ini file path key from registry
        /// </summary>
        /// <returns></returns>
        public static bool DeleteINIFilePath()
        {
            RegistryKey userSettingsKey = null;
            try
            {
                userSettingsKey = Registry.LocalMachine.OpenSubKey(addinLocation, true);
                if (userSettingsKey != null)
                {
                    userSettingsKey.DeleteSubKey(TSRINIFilePathKey_Name);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return true;
        }
        /// <summary>
        /// Get value of key in ini file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="cate"></param>
        /// <param name="strKey"></param>
        /// <returns></returns>
        public static string GetValue(string path, string cate, string strKey)
        {
            string defaultValue = "???";
            string iniFile = path;
            string value = string.Empty;
            try
            {
                List<string> categories = GetCategories(iniFile);
                foreach (string category in categories)
                {
                    if (category == cate)
                    {
                        List<string> keys = GetKeys(iniFile, category);
                        foreach (string key in keys)
                        {
                            if (key == strKey)
                            {
                                value = GetIniFileString(iniFile, category, key, defaultValue);
                            }
                        }
                    }
                }
            }
            catch
            {
            }
            if (!string.IsNullOrEmpty(value) && value.ToLower() == Constants.BLANK_IN_LOWER_CHARS.ToLower())
                value = string.Empty;

            return value;
        }

        public static bool SetValue(string path, string cate, string strKey, string strValue)
        {
            string iniFile = path;
            string value = string.Empty;
            try
            {
                List<string> categories = GetCategories(iniFile);
                if (categories.Contains(cate))
                    return SetIniFileString(iniFile, cate, strKey, strValue) > 0;
            }
            catch
            {
            }
            return false;
        }

        /// <summary>
        /// Gets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static string GetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            string returnString = new string(' ', 1024);
            GetPrivateProfileString(category, key, defaultValue, returnString, 1024, iniFile);
            return returnString.Split('\0')[0];
        }

        /// <summary>
        /// Sets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static int SetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            return WritePrivateProfileString(category, key, defaultValue, iniFile);
        }

        /// <summary>
        /// Gets the keys.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        private static List<string> GetKeys(string iniFile, string category)
        {
            string returnString = new string(' ', 32768);
            GetPrivateProfileString(category, null, null, returnString, 32768, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <returns></returns>
        private static List<string> GetCategories(string iniFile)
        {
            string returnString = new string(' ', 65536);
            GetPrivateProfileString(null, null, null, returnString, 65536, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }

        /// <summary>
        /// Encrypts the sourceString, returns this result as an Aes encrypted, BASE64 encoded string
        /// </summary>
        /// <param name="plainSourceStringToEncrypt">a plain, Framework string (ASCII, null terminated)</param>
        /// <param name="key"></param>
        /// <returns>
        /// returns an Aes encrypted, BASE64 encoded string
        /// </returns>

        public static string EncryptString(string plainSourceStringToEncrypt)
        {
            MD5CryptoServiceProvider mdcsp = new MD5CryptoServiceProvider();
            byte[] b = System.Text.Encoding.UTF8.GetBytes(plainSourceStringToEncrypt);
            b = mdcsp.ComputeHash(b);
            //Convert encoded bytes back to a 'readable' string
            return BitConverter.ToString(b);
        }

        public static string GetRegOpenMode()
        {
            string value = string.Empty;

            RegistryKey timesheetReporterKey = null;
            try
            {
                timesheetReporterKey = Registry.CurrentUser.OpenSubKey(Constants.timesheetReporterLocation, false);
                if (timesheetReporterKey != null)
                {
                    value = timesheetReporterKey.GetValue(Constants.CONST_OPTION_OPENMODE, Constants.CONST_OPTION_OPENMODE_VALUE_DEFAULT).ToString();
                }
            }
            catch
            {
            }
            finally
            {
                if (timesheetReporterKey != null)
                    timesheetReporterKey.Close();
            }

            return value;
        }

        public static void SetRegOpenMode(string value)
        {
            RegistryKey timesheetReporterKey = null;
            try
            {
                timesheetReporterKey = Registry.CurrentUser.OpenSubKey(Constants.timesheetReporterLocation, true);
                if (timesheetReporterKey != null)
                {
                    timesheetReporterKey.SetValue(Constants.CONST_OPTION_OPENMODE, value);
                }
            }
            catch
            {

            }
            finally
            {
                if (timesheetReporterKey != null)
                    timesheetReporterKey.Close();
            }
        }

        public static bool OUANotBeStarted()
        {
            RegistryKey softwareKeyHKCU = null;
            RegistryKey tsrOptionKeyHKCU = null;
            try
            {
                softwareKeyHKCU = Registry.CurrentUser.OpenSubKey(Constants.OUAOptionsLocationRoot, true); //to get username and password
                if (softwareKeyHKCU != null)
                {
                    tsrOptionKeyHKCU = softwareKeyHKCU.OpenSubKey(Constants.OUAOptionsLocation, true);
                    if (tsrOptionKeyHKCU != null)
                    {
                        object value = tsrOptionKeyHKCU.GetValue(Constants.CONST_REGISTRYKEY_START_TSR_OUA);
                        if (value != null
                            && (value.ToString().Trim().Equals(Constants.FALSE_IN_LOWER_CHARS, StringComparison.OrdinalIgnoreCase)
                            || value.ToString().Trim().Equals("0")))
                            return true;
                    }
                }
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                if (tsrOptionKeyHKCU != null) tsrOptionKeyHKCU.Close();
                if (softwareKeyHKCU != null) softwareKeyHKCU.Close();
            }

            return false;
        }
    }
}
