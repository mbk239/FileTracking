using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using Microsoft.Win32;
using System.Security.Principal;
using System.DirectoryServices;

using TSR.Core.Logging;

namespace TSR.Core
{
    /// <summary>
    /// constant collection
    /// </summary>
    public static class Constants
    {
        public static readonly int DEFAULT_SELECTION_VALUE_INT = -1;
        public static readonly string DEFAULT_RESOURCEKEYS_PATH = "\\Resources\\ResourceKeys.xml";
        public static readonly string DEFAULT_RESOURCEKEYS_TAG_NAME = "Resource";
        public static readonly string DEFAULT_RESOURCE_LANGUAGEID_ATTRIBUTE = "languageid";
        public static readonly string DEFAULT_RESOURCE_KEY_ATTRIBUTE = "key";
        public static readonly string DEFAULT_RESOURCE_NAMESPACE = "http://tsr.outlook.agent/oua_resourcekeys";
        public static readonly string DEFAULT_RESOURCE_NAMESPACE_TAG = "oua_resourcekeys";
        public static readonly string DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR = "###";
        public static readonly char DEFAULT_SEPERATOR_PREFERREDLANGUAGE = '|';
        public static readonly char DEFAULT_SEPERATOR_LANGUAGENAME_LANGUAGEID = '#';
        public static readonly string LICENSE_CONFIG_KEY = "License";
        public static readonly string TSR_DEFAULT_CALENDAR_KEY_FOR_SYNC = "Calendar";
        public static readonly string NONEXISTING_OUTLOOK_APPOINTMENT_ID = "blank";
        //public static readonly string NON_OUTLOOK_APPOINTMENT_ID = "non";
        public static readonly string DEFAULT_CULTURE_LCID = "en";
        public static readonly string DEFAULT_LANGUAGE_NAME = "US English";
        public static readonly string DEFAULT_CULTURE_INFO_NAME = "en-US";
        public static readonly string SPACE = " ";
        public static readonly string TRUE_IN_LOWER_CHARS = "true";
        public static readonly string FALSE_IN_LOWER_CHARS = "false";
        
        public static readonly string DEFAULT_FORMAT_TIMESTAMP = "yyyyMMddhhmmss";

        /// <summary>
        /// Constant for creating user local data
        /// </summary>
        public static readonly string CONST_XMLFILEPATH = "UserData.xml";

        //Added by tsrdev1
        //Added datetime 10/03/2011
        public static readonly string CONST_INIFILEPATH = "TSROUAOptions.ini";
        public static readonly string CONST_FOLDER_SEPERATOR = "/";
        public static string CONST_APPDATA_FOLDER = "TSR_DATA";

        public static string timesheetReporterLocation = @"Software\Timesheet Reporter";
        public static string OUAOptionsLocation = "Timesheet Reporter";
        public static string OUAOptionsLocationRoot = @"Software";

        public static readonly string CONST_USERSETTINGS_ELEMENT = "UserSettings";
        public static readonly string CONST_USERSETTINGS_ID = "ID";
        public static readonly string CONST_USERSETTINGS_KEY = "Key";
        public static readonly string CONST_USERSETTINGS_VALLUE = "Value";
        public static readonly string CONST_SERVERADDRESS_ID = "8";
        public static readonly string CONST_SERVERADDRESS_KEY = "TSRServerAddress";
        public static readonly string CONST_REGISTRYKEY_SERVERADDRESS = "ServerAddr";
        public static readonly string CONST_WEBINTERFACE_ID = "9";
        public static readonly string CONST_WEBINTERFACE_KEY = "TSRWebinterface";
        public static readonly string CONST_REGISTRYKEY_WEBINTERFACE = "WebInterface";
        public static readonly string CONST_WEBINTERFACE_HELP = "http://www.timesheetreporter.com/support"; //"www.timesheetreporter.com/manual";
        public static readonly string TIMEENTRY_NOTCHANGED = "TIMEENTRY_NOTCHANGED";
        public static readonly string TIMEENTRY_USER_CHANGED = "TimeEntry_User_Changed";

        public const string OUAChangeTimeEntryInLockPeriod = "OUAChangeTimeEntryInLockPeriod";
        public const string OUADeleteTimeEntryInLockPeriod = "OUADeleteTimeEntryInLockPeriod";
        public const string OUASubmitTimeEntryInLockPeriod = "OUASubmitTimeEntryInLockPeriod";

        //Added by tsrdev1
        //Added datetime 25/02/2011
        public static readonly string CONST_CUSTOMERNO_ID = "10";
        public static readonly string CONST_CUSTOMERNO_KEY = "TSRCustomerNo";

        public static readonly string CONST_USERNAME_ID = "11";
        public static readonly string CONST_USERNAME_KEY = "TSRUserName";

        public static readonly string CONST_PASSWORD_ID = "12";
        public static readonly string CONST_PASSWORD_KEY = "TSRPassword";

        public static readonly string CONST_EXCHANGEMODE_ID = "13";
        public static readonly string CONST_EXCHANGEMODE_KEY = "TSRExchangeMode";

        public static readonly string CONST_TSRDONOTASKSETTINGAGAIN_KEY = "TSRDonotAskSettingAgain";
        //End

        //Added by tsrdev1
        //Added datetime 13/10/2010
        public static readonly string CONST_REGISTRYKEY_EXCHANGEMODE = "ExchangeMode";
        //End
        //Added by tsrdev1
        //Added datetime 13/10/2010
        public static readonly string CONST_REGISTRYKEY_INSTALLATIONMODE = "InstallationMode";
        public static readonly string CONST_REGISTRYKEY_CUSTOMERNO = "CustomerNo";
        public static readonly string CONST_REGISTRYKEY_USERNAME = "UserName";
        public static readonly string CONST_REGISTRYKEY_PASSWORD = "Password";
        //End
        #region Outlook Category Constants
        public static readonly string CATEGORY = "Category";
        public static readonly string APPROVED_CATEGORY = "Approved Category";
        public static readonly string  INPROGESS_CATEGORY = "InProgress Category";
        public static readonly string REJECTED_CATEGORY = "Rejected Category";
        public static readonly string ACTIVE_CATEGORY = "Active Category";
        public static readonly string ALLMINUSREJECTED_CATEGORY = "AllMinusRejected Category";
        public static readonly string CANCELLED_CATEGORY = "Cancelled Category";
        public static readonly string ERROR_CATEGORY = "Error Category";
        public static readonly string INACTIVE_CATEGORY = "Inactive Category";
        public static readonly string INSUBMISSIONQUEUE_CATEGORY = "InSubmissionQueue Category";
        public static readonly string PENDINGSUBMISSION_CATEGORY = "PendingSubmission Category";
        public static readonly string SUBMITTED_CATEGORY = "Submitted Category";

        //default category separator, it must be used to separate each category in the set of category.
        //don't care about what's the List separator of the local machine.
        //this is a my discover.
        public static readonly string CATEGORIES_SEPARATOR_DEFAULT = ", ";
       
        #endregion

        //Added by tsrdev1
        //Added datetime 23/02/2011
        #region OUA Installation Constant
        public static readonly string Y_IN_LOWER_CHARS = "y";
        public static readonly string YES_IN_LOWER_CHARS = "yes";
        public static readonly string BLANK_IN_LOWER_CHARS = "blank";
        public static readonly string CONST_OPTION_VERBOSE = "Verbose";
        public static readonly string CONST_OPTION_INSTALLATIONMODE = "InstallationMode";
        public static readonly string CONST_OPTION_CUSTOMERNO = "CustomerNo";
        public static readonly string CONST_OPTION_TSRSERVICES = "TSRServices";
        public static readonly string CONST_OPTION_TSRWEBADMIN = "TSRWebAdmin";
        public static readonly string CONST_OPTION_USERNAME = "UserName";
        public static readonly string CONST_OPTION_PASSWORD = "Password";

        public static readonly string CONST_OPTION_EXCHANGEMODE = "ExchangeMode";
        public static readonly string ROOTCATERGORY = "TSROUAOPTIONS";
        public static readonly string CUSTOMERNO_VARIABLENAME = "%OrgId%";
        //End
        public static readonly string CONST_TSRISCHOOSESSL_KEY = "TSRIsChooseSSL";

        public static readonly string CONST_OPTION_OPENMODE = "OpenMode";
        public static readonly string CONST_OPTION_OPENMODE_VALUE_DEFAULT = "0";
        public static readonly string CONST_OPTION_OPENMODE_VALUE_SETTINGSWINDOW = "1";

        public static readonly string CONST_OPTION_SILENTINSTALL = "SilentInstall";
        public static readonly string CONST_OPTION_USEAUTOPROXY = "UseAutoProxy";

        //public static readonly string CONST_USERINEXPENSELICENSE_KEY = "UserInExpenseLicense";
        #endregion


        public static bool ISLOCKEDUSERSETTING = false;
        public static bool ISSERVERFOUND = false;

        public static bool USERINEXPENSELICENSE = false;
        //public static readonly string DEFAULT_SELECTION_VALUE_STRING = "ValueInv";

        //public static readonly string VERSION = "5.1";
        public static readonly string CONST_CONNECTION_TIMEOUT_ID = "14";
        public static readonly string CONST_CONNECTION_TIMEOUT_VALUE = "ConnectionTimeOutValue";
        //public static readonly string CONST_REGISTRYKEY_CONNECTION_TIMEOUT_VALUE = "ConnectionTimeOutValue";

        public static readonly string CONST_USE_AUTO_PROXY_ID = "15";
        public static readonly string CONST_USE_AUTO_PROXY_VALUE = "UseAutoProxy";
        //public static readonly string CONST_REGISTRYKEY_USE_AUTO_PROXY_VALUE = "UseAutoProxy";

        public static readonly string CONST_KEEP_EXISTING_VALUE = "KeepExistingValue";
        public static readonly string CONST_REGISTRYKEY_START_TSR_OUA = "START_TSR_OUA";

        public static readonly string CONST_FAVORITE_ID_SEPERATOR = "-";
        public static readonly string CONST_FAVORITE_NAME_SEPERATOR = ",";

        public static readonly string CONST_IS_DURATION_WARNING_ENABLE = "IsDurationWarningEnable";
        public static readonly string CONST_DURATION_WARNING = "DurationWarning";
        public static readonly string CONST_ENFORCE = "Enforce";

        public static string Version
        {
            get 
            {                
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;                
                string strVersion = v.ToString();
                string[] arrSubVersion = strVersion.Split('.');
                if (arrSubVersion.Length == 1)
                {
                    strVersion = strVersion + ".0";
                }
                else if (arrSubVersion.Length == 2)
                {

                }
                else if (arrSubVersion.Length > 2)
                {
                    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                }
                return strVersion;
            }
        }

        public static bool SetAppDataFolder(string folderPath)
        {
            CONST_APPDATA_FOLDER = folderPath;
            return true;
        }

        public static bool SetTimeSheetReporterLocation(string location)
        {
            timesheetReporterLocation = location;
            return true;
        }

        public static string Version3
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;

                //      Major Version
//      Minor Version 
//      Build Number
//      Revision
                string strVersion = v.Major.ToString() + "." + v.Minor.ToString() + "." + v.Build.ToString();
                return strVersion;
            }
        }

        public static string VersionRevision
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;

                //      Major Version
                //      Minor Version 
                //      Build Number
                //      Revision
                string strVersion = v.Revision.ToString();
                return strVersion;
            }
        }

        public static string VersionFull
        {
            get
            {
                System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
                System.Reflection.AssemblyName an = a.GetName();
                Version v = an.Version;

                string strVersion = v.ToString();
                //string[] arrSubVersion = strVersion.Split('.');
                //if (arrSubVersion.Length == 1)
                //{
                //    strVersion = strVersion + ".0";
                //}
                //else if (arrSubVersion.Length == 2)
                //{

                //}
                //else if (arrSubVersion.Length > 2)
                //{
                //    strVersion = arrSubVersion[0] + "." + arrSubVersion[1];
                //}
                return strVersion;
            }
        }

    //    //Added by tsrdev1
    //    //Added datetime 13/10/2010
    //    public static bool IsExchangeMode
    //    {
    //        get
    //        {
    //            try
    //            {
    //                RegistryKey timesheetReporterKey = null;
    //                timesheetReporterKey = Registry.LocalMachine.OpenSubKey(Constants.timesheetReporterLocation, false);
    //                if (timesheetReporterKey == null)
    //                    return false;
    //                try
    //                {
    //                    return Convert.ToBoolean(Convert.ToByte(timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_EXCHANGEMODE)));
    //                }
    //                catch
    //                {
    //                    return false;
    //                }
                    
    //            }
    //            catch
    //            {
    //                return false;
    //            }                
    //        }
    //    }
    }

    /// <summary>
    /// class with list of utility methods for Enumeration
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// removes hiphen in enum to get a nicer string
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string ProcessEnumString(string text)
        {
            string processedString = text.Replace('_', ' ');
            processedString = ResourceManager.GetResourceString(text, processedString);
            return processedString;
        }

        public static IList GetListFromEnum(Type enumType, string defaultSelectionText)
        {
            List<EnumListItem> list = new List<EnumListItem>();

            if (!String.IsNullOrEmpty(defaultSelectionText))
                list.Add(new EnumListItem { ID = "-1", Name = defaultSelectionText });

            foreach (object value in Enum.GetValues(enumType))
            {
                list.Add(new EnumListItem { ID = ((int)value).ToString(), Name = ProcessEnumString(value.ToString()) });
            }

            return list;
        }
    }

    public class EnumListItem
    {
        public static string COL_ID = "ID";
        public static string COL_NAME = "Name";

        public string ID { get; set; }
        public string Name { get; set; }

    }

    public class NameValueObject
    {
        public string Name;
        public int Value;

        public NameValueObject(string name, int value)
        {
            Name = name;
            Value = value;
        }
        public override string ToString()
        {
            return Name;
        }
    }


    public class MiscHelper
    {

        public static String[] ParseStringBySeperator(String _obj, String _parseKey)
        {
            String[] list = _obj.Split(new string[] { _parseKey }, StringSplitOptions.RemoveEmptyEntries);
            return list;
        }

        #region Base64 Serialization of Objects

        public static string SerializeBase64(object o)
        {// Serialize to a base 64 string
            byte[] bytes;
            long length = 0;
            MemoryStream ws = new MemoryStream();
            BinaryFormatter sf = new BinaryFormatter();
            sf.Serialize(ws, o);
            length = ws.Length;
            bytes = ws.GetBuffer();
            string encodedData = bytes.Length + ":" + Convert.ToBase64String(bytes, 0, bytes.Length, Base64FormattingOptions.None);
            return encodedData;
        }

        public static object DeserializeBase64(string s)
        {
            // We need to know the exact length of the string - Base64 can sometimes pad us by a byte or two
            int p = s.IndexOf(':');
            int length = Convert.ToInt32(s.Substring(0, p));
            // Extract data from the base 64 string!
            byte[] memorydata = Convert.FromBase64String(s.Substring(p + 1));
            MemoryStream rs = new MemoryStream(memorydata, 0, length);
            BinaryFormatter sf = new BinaryFormatter();
            object o = sf.Deserialize(rs);
            return o;
        }

        #endregion

        public static string GetCurrentUsername()
        {            
            string username = string.Empty;
            try
            {
                WindowsIdentity wi = WindowsIdentity.GetCurrent();

                if (wi.IsAuthenticated)
                {
                    username = wi.Name.Substring(wi.Name.LastIndexOf('\\') + 1);
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
            return username;
        }      
         
        public static string GetCurrentDateTimeToString()
        {            
            string result = DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString()
                            + ":" + DateTime.Now.Millisecond.ToString();
            return result;
        }


    }

    public class UserDataHelper
    {
        private static string strStart = ResourceManager.GetResourceString("StartCreating", "Start creating ");
        /// <summary>
        /// Create UserData.xml with server address information
        /// Not throw any exception
        /// Logged all exception
        /// </summary>
        public static void CreateUserLocalData()
        {
            FileStream fs = null;
            string appDataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                                    + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string userDataFile = appDataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_XMLFILEPATH;

            string commomDataFolder = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string iniDataFile = commomDataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_INIFILEPATH;
                 
            try
            {
                
                LoggingHandler.LogInfo(new Log()
                {
                    MessageSummary = strStart + userDataFile
                });

                if (!Directory.Exists(appDataFolder))
                {
                    Directory.CreateDirectory(appDataFolder);
                }

                fs = new FileStream(userDataFile, FileMode.Create);

            }
            catch (Exception e)
            {
                //do nothing as we don't want the file to exist.
                //Rather we want it to be empty if we find it
                string strFirst = ResourceManager.GetResourceString("FirstTryToCreate","First try to create ");
                LoggingHandler.LogInfo(new Log()
                {
                    MessageSummary = strFirst + userDataFile
                });
                //We should know the reason of error
                TSR.Core.Logging.LoggingHandler.LogError(e);
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }

                //here, UserData.xml should have been created
                RegistryKey timesheetReporterKey = null;
                try
                {                    
                    timesheetReporterKey = Registry.CurrentUser.OpenSubKey(Constants.timesheetReporterLocation, false);
                    if (File.Exists(iniDataFile))
                    {
                        fs = new FileStream(userDataFile, FileMode.Create);
                        XmlWriterSettings settings = new XmlWriterSettings();
                        settings.Indent = true;
                        settings.OmitXmlDeclaration = true;
                        settings.NewLineOnAttributes = true;

                        XmlWriter w = XmlWriter.Create(fs, settings);

                        w.WriteStartElement("TSRDataSet", "http://tempuri.org/TSRDataSet.xsd");

                        // Write user setting TSRServerAddress
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_SERVERADDRESS_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_SERVERADDRESS_KEY);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES));
                        //end of element TSRServerAddress
                        w.WriteEndElement();

                        //w.WriteStartElement("TSRDataSet", "http://tempuri.org/TSRDataSet.xsd");

                        // Write user setting TSRWebInterface
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_WEBINTERFACE_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_WEBINTERFACE_KEY);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRWEBADMIN));
                        //end of element TSRWebInterface
                        w.WriteEndElement();

                        if (timesheetReporterKey != null)
                        {
                            // Write user setting TSRUserName
                            w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_USERNAME_ID);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_USERNAME_KEY);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_USERNAME));
                            //end of element TSRUserName
                            w.WriteEndElement();

                            // Write user setting TSRPassword
                            w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_PASSWORD_ID);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_PASSWORD_KEY);
                            w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_PASSWORD));
                            //end of element TSRPassword
                            w.WriteEndElement();
                        }

                        // Write user setting TSRCustomerNo
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_CUSTOMERNO_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_CUSTOMERNO_KEY);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_REGISTRYKEY_CUSTOMERNO));
                        //end of element TSRCustomerNo
                        w.WriteEndElement();

                        // Write user setting TSRExchangeMode
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_EXCHANGEMODE_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_EXCHANGEMODE_KEY);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_OPTION_EXCHANGEMODE));
                        //end of element TSRCustomerNo
                        w.WriteEndElement();

                        // Write user setting ConnectionTimeOutValue
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_CONNECTION_TIMEOUT_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_CONNECTION_TIMEOUT_VALUE);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_CONNECTION_TIMEOUT_VALUE));
                        //end of element ConnectionTimeOutValue
                        w.WriteEndElement();

                        // Write user setting UseAutoProxy
                        w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_USE_AUTO_PROXY_ID);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_USE_AUTO_PROXY_VALUE);
                        w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)UtilityHelper.GetValue(iniDataFile, Constants.ROOTCATERGORY, Constants.CONST_USE_AUTO_PROXY_VALUE));
                        //end of element UseAutoProxy
                        w.WriteEndElement();

                        //end of element TSRDataSet
                        w.WriteEndElement();

                        w.Flush();
                        fs.Close();

                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = ResourceManager.GetResourceString("CreateSuccessfully", "Create successfully") + userDataFile
                        });
                    }
                }
                catch (Exception e)
                {
                    //We need log the reason of error for debuging
                    TSR.Core.Logging.LoggingHandler.LogError(e);                    
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                    if (timesheetReporterKey != null)
                    {
                        timesheetReporterKey.Close();
                        ////Registry.CurrentUser.DeleteSubKey(Constants.timesheetReporterLocation);
                        //try
                        //{
                        //    timesheetReporterKey = Registry.CurrentUser.OpenSubKey(Constants.timesheetReporterLocation, true);
                        //    //will not deleted account information from regestry, caused using for next re-install.
                        //    //timesheetReporterKey.DeleteValue(Constants.CONST_REGISTRYKEY_USERNAME);
                        //    //timesheetReporterKey.DeleteValue(Constants.CONST_REGISTRYKEY_PASSWORD);
                        //}
                        //catch (Exception ex)
                        //{
                        //    TSR.Core.Logging.LoggingHandler.LogError(ex);
                        //}
                        //finally
                        //{
                        //    if (timesheetReporterKey != null)
                        //    {
                        //        timesheetReporterKey.Close();
                        //    }
                        //}
                    }
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fs"></param>
        private static void CreateUserDataWithServerAddressSetting(FileStream fs)
        {
            RegistryKey timesheetReporterKey = null;
            //timesheetReporterKey = Registry.LocalMachine.OpenSubKey(Constants.timesheetReporterLocation, false);
            timesheetReporterKey = Registry.CurrentUser.OpenSubKey(Constants.timesheetReporterLocation, false);
            if (timesheetReporterKey != null)
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;
                settings.NewLineOnAttributes = true;

                XmlWriter w = XmlWriter.Create(fs, settings);

                w.WriteStartElement("TSRDataSet", "http://tempuri.org/TSRDataSet.xsd");

                // Write user setting TSRServerAddress
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_SERVERADDRESS_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_SERVERADDRESS_KEY);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_SERVERADDRESS));
                //end of element TSRServerAddress
                w.WriteEndElement();

                // Write user setting TSRWebInterface
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_WEBINTERFACE_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_WEBINTERFACE_KEY);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_WEBINTERFACE));
                //end of element TSRWebInterface
                w.WriteEndElement();

                // Write user setting TSRUserName
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_USERNAME_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_USERNAME_KEY);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_USERNAME));
                //end of element TSRUserName
                w.WriteEndElement();

                // Write user setting TSRPassword
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_PASSWORD_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_PASSWORD_KEY);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_PASSWORD));
                //end of element TSRPassword
                w.WriteEndElement();

                // Write user setting TSRCustomerNo
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_CUSTOMERNO_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_CUSTOMERNO_KEY);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_REGISTRYKEY_CUSTOMERNO));
                //end of element TSRCustomerNo
                w.WriteEndElement();

                // Write user setting ConnectionTimeOutValue
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_CONNECTION_TIMEOUT_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_CONNECTION_TIMEOUT_VALUE);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_CONNECTION_TIMEOUT_VALUE));
                //end of element ConnectionTimeOutValue
                w.WriteEndElement();

                // Write user setting UseAutoProxy
                w.WriteStartElement(Constants.CONST_USERSETTINGS_ELEMENT);
                w.WriteElementString(Constants.CONST_USERSETTINGS_ID, Constants.CONST_USE_AUTO_PROXY_ID);
                w.WriteElementString(Constants.CONST_USERSETTINGS_KEY, Constants.CONST_USE_AUTO_PROXY_VALUE);
                w.WriteElementString(Constants.CONST_USERSETTINGS_VALLUE, (string)timesheetReporterKey.GetValue(Constants.CONST_USE_AUTO_PROXY_VALUE));
                //end of element UseAutoProxy
                w.WriteEndElement();

                //end of element TSRDataSet
                w.WriteEndElement();

                w.Flush();
            }
        }

        /// <summary>
        /// Load UserData.xml, 
        /// If user data does not exist => create user data with server address information
        /// Not throw any exception
        /// Logged all exception
        /// Return a file stream or null (in case unknown exception)
        /// </summary>
        public static FileStream ReadUserLocalDataStream()
        {
            FileStream fs = null;
            string appDataFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
                                    + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_APPDATA_FOLDER;
            string userDataFile = appDataFolder + Constants.CONST_FOLDER_SEPERATOR + Constants.CONST_XMLFILEPATH;
            try
            {
                LoggingHandler.LogInfo(new Log()
                {
                    MessageSummary = strStart + userDataFile
                });

                fs = new FileStream(userDataFile, FileMode.OpenOrCreate);
            }
            catch (DirectoryNotFoundException dnfe)
            {
                Directory.CreateDirectory(appDataFolder);
                fs = new FileStream(userDataFile, FileMode.OpenOrCreate);
                CreateUserDataWithServerAddressSetting(fs);
                TSR.Core.Logging.LoggingHandler.LogError(dnfe);
            }
            catch (FileNotFoundException fnfe)
            {
                fs = new FileStream(userDataFile, FileMode.OpenOrCreate);
                CreateUserDataWithServerAddressSetting(fs);
                TSR.Core.Logging.LoggingHandler.LogError(fnfe);
            }
            catch (Exception e)
            {
                //do nothing as we don't want the file to exist.
                //Rather we want it to be empty if we find it
                fs = null;
                //We should know the reason of error
                TSR.Core.Logging.LoggingHandler.LogError(e);
            }

            return fs;
        }
    }
}
