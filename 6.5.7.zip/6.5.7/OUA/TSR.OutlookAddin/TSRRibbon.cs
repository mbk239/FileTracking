using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Office = Microsoft.Office.Core;
using Outlook = Microsoft.Office.Interop.Outlook;
using Core = TSR.Core;
using Shell = TSR.Shell;
using TSR.Core.Entity;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Data;
using Microsoft.Win32;	// For RegKey
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Microsoft.Office.Tools.Ribbon;
namespace TSR.OutlookAddin
{
    // This override passes a trusted Outlook.Application object
    // to the constructor for OutlookRibbonXCS class.
    public partial class ThisAddIn
    {
        private TSRRibbon ribbon;
        protected override object RequestService(Guid serviceGuid)
        {
            if (serviceGuid == typeof(Office.IRibbonExtensibility).GUID)
            {
                if (ribbon == null)
                    ribbon = new TSRRibbon(Application);

                return ribbon;
            }
            return base.RequestService(serviceGuid);
        }        
    }

    [ComVisible(true)]
    public class TSRRibbon : Office.IRibbonExtensibility
    {
        #region Constants

        public const string TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID = "OrganizationDDL";
        public const string TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID = "ProjectDDL";
        public const string TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID = "ActivityDDL";

        public const string TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID = "recOrganizationDDL";
        public const string TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID = "recProjectDDL";
        public const string TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID = "recActivityDDL";
        
        #endregion

        private string tooltipResource_Name;
        private string tooltipResource_Description;
        private string tooltipResource_Type;
        private bool tooltipResource_IsLoaded = false;

        private Outlook.Application Application;

        public TSRRibbon(Outlook.Application outlookApplication)
        {
            Application = outlookApplication;            
        }

        #region IRibbonExtensibility Members

        public string GetCustomUI(string ribbonID)
        {
            //ribbonID indicates type of Inspector that is about to be displayed
            //Valid ribbonID values are as follows:
            //Microsoft.Outlook.Mail.Read
            //Microsoft.Outlook.Mail.Compose
            //Microsoft.Outlook.MeetingRequest.Read
            //Microsoft.Outlook.MeetingRequest.Send
            //Microsoft.Outlook.Appointment
            //Microsoft.Outlook.Contact
            //Microsoft.Outlook.Journal
             //Microsoft.Outlook.Task
            //Microsoft.Outlook.DistributionList
            //Microsoft.Outlook.Report
            //Microsoft.Outlook.Resend
            //Microsoft.Outlook.Response.Read
            //Microsoft.Outlook.Response.Compose
            //Microsoft.Outlook.Response.CounterPropose
            //Microsoft.Outlook.RSS
            //Microsoft.Outlook.Post.Read
            //Microsoft.Outlook.Post.Compose
            //Microsoft.Outlook.Sharing.Read
            //Microsoft.Outlook.Sharing.Compose
            if (ribbonID == "Microsoft.Outlook.Explorer")
            {
                return GetResourceText("TSR.OutlookAddin.TSRRibbonOnCalendarTools.xml");
            }
            else if (ribbonID == "Microsoft.Outlook.Appointment")
            {
                return GetResourceText("TSR.OutlookAddin.TSRRibbon.xml");
            }
            else
            {
                return string.Empty;
            }
        }

        #endregion

        #region Ribbon Callbacks

        /// <summary>
        /// TSR ribbon loads
        /// </summary>
        /// <param name="ribbon"></param>
        public void Ribbon_OnLoad(Office.IRibbonUI ribbon)
        {           
            //Debug.WriteLine("Ribbon_OnLoad");
            ThisAddIn.m_Ribbon = ribbon;            
        }

        /// <summary>
        /// ribbon has become visible
        /// </summary>
        /// <param name="control"></param>
        /// <returns></returns>
        public bool TSRSetupGroup_GetVisible(Office.IRibbonControl control)
        {            
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);

            if (window != null)
            {
                if (!Core.OutlookHelper.IsAppointmentInGivenFolder_temp(window.CurrentItem, Core.OutlookHelper.UserSelectedAppointmentFolderForSync))
                //if (!Core.OutlookHelper.IsAppointmentInGivenFolder(window.CurrentItem))
                    return false;

                switch (control.Id)
                {
                    case "recTSRSetupGroup":
                    case "TSRSetupGroup":
                        return !(window.IsTSRItem);
                    case "TSRSetupGroup_Detail":
                    case "recTSRSetupGroup_Detail":
                        return (window.IsTSRItem);
                }
                return true;
            }
            return false;
        }

        public stdole.IPictureDisp TSRRibbon_GetImage(Office.IRibbonControl control)
        {
            return Shell.ImageHelper.Convert(Core.ResourceHelper.TSRIcon_BMP);
        }

        public string TSRRibbon_Item_GetLabel(Office.IRibbonControl control)
        {
            switch (control.Id)
            {
                case "recTSRSetupGroup_Detail":
                case "TSRSetupGroup_Detail":
                    OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
                    if (window != null)
                    {
                        return window.LicenseText;
                    }
                    return Core.ResourceHelper.Ribbon_TSRSetupGroup;
                //return Core.ResourceHelper.Ribbon_TSRSetupGroup;
                case "TSRSetupGroup":
                case "TSRItemButton":
                case "recTSRSetupGroup":
                case "recTSRItemButton":
                case "recTSRItemButton_Detail":
                    //return "TSRItemButton"; // Core.ResourceHelper.Ribbon_TSRSetupGroup;
                case "TSRItemButton_Detail":
                    return Core.ResourceHelper.Ribbon_TSRSetupGroup;

                case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                    return Core.ResourceHelper.Organization + ": ";

                case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                    return Core.ResourceHelper.Project + ": ";

                case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                    return Core.ResourceHelper.Activity + ": ";

                case "AdvancedButton":
                case "recAdvancedButton":
                    return Core.ResourceHelper.Ribbon_AdvancedButton;

                case "SubmitButton":
                case "recSubmitButton":
                    return Core.ResourceHelper.Ribbon_SubmitButton;

                case "SaveButton":
                case "recSaveButton":
                    return Core.ResourceHelper.Save;
            }
            return String.Empty;
        }

        public bool TSRItemButton_GetPressed(Office.IRibbonControl control)
        {
           //Debug.WriteLine("TSRItemButton_GetPressed");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                return window.IsTSRItem;
            }

            return false;
        }

        public void TSRItemButton_Click(Office.IRibbonControl control, bool pressed)
        {
            //Debug.WriteLine("TSRItemButton_Click");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                //added by tsrdev2
                //30 Dec 2011
                bool isRecurrenceOccurrence = false;

                if (pressed && window.CurrentItem != null && window.CurrentItem.IsRecurring)
                {
                    string strWarning = string.Empty;
                    string message = string.Empty;
                    string caption = string.Empty;

                    if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    {
                        strWarning = "Are you sure you want to enter TSR information on a recurring appointment? " +
                            "If you do, all instances of the appointment up to 12 months in the past up to 12 months from " +
                            " now will be split into separate individual appointments and the recurring function from Outlook will be removed from the appointment."; 
                        message = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message_Feature306", strWarning);
                        caption = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning when enter TSR info on a recurring appointment");
                    }
                    else if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptOccurrence
                        || window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptException)
                    {
                        isRecurrenceOccurrence = true;

                        strWarning = "Are you sure you want to enter TSR information on a single item out of a series? If you do, this occurrence from the series will be removed and created an individual appointment";
                        message = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Message", strWarning);
                        caption = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Caption", "Warning when enter TSR info on a single item out of a series");
                    }

                    DialogResult dr = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
                    if (dr == DialogResult.Yes)
                    {
                        window.IsAllowTSRInfo = true;
                    }
                    else
                    {
                        pressed = false;
                    }
                }
                window.IsTSRItem = pressed;
                if ((pressed) && (window.TSREntry != null && window.TSREntry.IsChangeAllowed()))
                {
                    if (!isRecurrenceOccurrence)
                    {
                        try
                        {
                            window.CurrentItem.Categories = Core.OutlookHelper.SetTSRCategory(window.CurrentItem.Categories, window.TSREntry.Status);
                        }
                        catch (Exception ex)
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                        }
                    }
                    if (window.IsInspector)
                    {
                        window.ForceItemChange();
                    }
                }

                if (!pressed && window.IsNewTSREntry)
                {
                    if (!isRecurrenceOccurrence)
                    {
                        try
                        {
                            window.CurrentItem.Categories = Core.OutlookHelper.RemoveTSRCategory(window.CurrentItem.Categories, window.TSREntry.Status);
                        }
                        catch (Exception ex)
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                        }
                    }
                }
                ThisAddIn.m_Ribbon.Invalidate();                
            }
        }

        public int DDL_GetItemCount(Office.IRibbonControl control)
        {

            //Debug.WriteLine("DDL_GetItemCount");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
           
            if (window != null)
            {
                try
                {
                    switch (control.Id)
                    {
                        case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                            {
                                //if ((string.IsNullOrEmpty(window.OrganizationID)) && (window.TSREntry.Organization != null)
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))                                    
                                //    return 1;
                                //else
                                    return window.Organizations.Count;
                            }
                        case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //    && (string.IsNullOrEmpty(window.ProjectID))) && (window.TSREntry.Project != null)
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))                                                                        
                                //    return 1;
                                //else
                                    return window.Projects.Count;
                            }
                        case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //     && (string.IsNullOrEmpty(window.ProjectID))
                                //     && (string.IsNullOrEmpty(window.ActivityID))) && (window.TSREntry.Activity != null)
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))                                    
                                //    return 1;
                                //else
                                    return window.Activities.Count;
                            }
                    }
                }
                catch(Exception ex) 
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }

            return 0;
        }

        public string DDL_GetItemLabel(Office.IRibbonControl control, int index)
        {
            //Debug.WriteLine("DDL_GetItemLabel");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                try
                {
                    switch (control.Id)
                    {
                        case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                            {
                                //if (string.IsNullOrEmpty(window.OrganizationID)
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Organization != null)
                                //        return window.TSREntry.Organization.Name;
                                //    else
                                //        return window.Organizations[0].Name;
                                //else
                                CheckOrganizationShowOnlyFavorites(window);

                                return window.Organizations[index].Name;
                            }
                        case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //    && (string.IsNullOrEmpty(window.ProjectID)))
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Project != null)
                                //        return window.TSREntry.Project.Name;
                                //    else
                                //        return window.Projects[0].Name;
                                //else
                                CheckProjectShowOnlyFavorites(window);

                                return window.Projects[index].Name;
                            }
                        case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //     && (string.IsNullOrEmpty(window.ProjectID))
                                //     && (string.IsNullOrEmpty(window.ActivityID)))
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Activity != null)
                                //        return window.TSREntry.Activity.Name;
                                //    else
                                //        return window.Activities[0].Name;
                                //else

                                CheckActivityShowOnlyFavorites(window);

                                return window.Activities[index].Name;
                            }
                    }
                }
                catch(Exception ex) 
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }

            return String.Empty;
        }

        public string DDL_GetItemID(Office.IRibbonControl control, int index)
        {
            //Debug.WriteLine("DDL_GetItemLabel");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                try
                {
                    switch (control.Id)
                    {
                        case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                            {
                                //if (string.IsNullOrEmpty(window.OrganizationID)
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Organization != null)
                                //        return window.TSREntry.Organization.OrganizationID;
                                //    else
                                //        return window.Organizations[0].OrganizationID;
                                //else
                                    return window.Organizations[index].OrganizationID;
                            }
                        case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //    && (string.IsNullOrEmpty(window.ProjectID)))
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //    && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Project != null)
                                //        return window.TSREntry.Project.ProjectID;
                                //    else
                                //        return window.Projects[0].ProjectID;
                                //else
                                    return window.Projects[index].ProjectID;
                            }
                        case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                            {
                                //if (((string.IsNullOrEmpty(window.OrganizationID))
                                //     && (string.IsNullOrEmpty(window.ProjectID))
                                //     && (string.IsNullOrEmpty(window.ActivityID)))
                                //    && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                                //     && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                                //     && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                                //    if (window.TSREntry.Activity != null)
                                //        return window.TSREntry.Activity.ActivityID;
                                //    else
                                //        return window.Activities[0].ActivityID;
                                //else
                                    return window.Activities[index].ActivityID;
                            }
                    }
                }
                catch(Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }

            //return Core.Constants.DEFAULT_SELECTION_VALUE_STRING;
            return String.Empty;
        }

        public string DDL_GetSelectedID(Office.IRibbonControl control)
        {            
            //Debug.WriteLine("DDL_GetSelectedID");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);            
            if (window != null)
            {
                switch (control.Id)
                {
                    case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                        {
                            //if (string.IsNullOrEmpty(window.OrganizationID)
                            //        && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                            //        && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                            //        && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                            //    if (window.TSREntry.Organization != null)
                            //        return window.TSREntry.Organization.OrganizationID;
                            //    else
                            //        return window.Organizations[0].OrganizationID;
                            //else
                                return window.OrganizationID;
                        }
                    case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                        {
                            //if (((string.IsNullOrEmpty(window.OrganizationID))
                            //       && (string.IsNullOrEmpty(window.ProjectID)))
                            //       && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                            //       && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                            //       && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                            //    if (window.TSREntry.Project != null)
                            //        return window.TSREntry.Project.ProjectID;
                            //    else
                            //        return window.Projects[0].ProjectID;
                            //else
                                return window.ProjectID;
                        }
                    case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                        {
                            //if (((string.IsNullOrEmpty(window.OrganizationID))
                            //         && (string.IsNullOrEmpty(window.ProjectID))
                            //         && (string.IsNullOrEmpty(window.ActivityID)))
                            //        && (window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.Rejected
                            //         && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.PendingSubmission
                            //         && window.TSREntry.Status != TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue))
                            //    if (window.TSREntry.Activity != null)
                            //        return window.TSREntry.Activity.ActivityID;
                            //    else
                            //        return window.Activities[0].ActivityID;
                            //else
                                return window.ActivityID;
                        }
                }
            }

            //return Core.Constants.DEFAULT_SELECTION_VALUE_STRING;
            return String.Empty;
        }

        public bool DDL_GetEnabled(Office.IRibbonControl control)
        {
            //Debug.WriteLine("DDL_GetSelectedID");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                if ((control.Id == TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID)
                    ||(control.Id == TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID)
                    ||(control.Id == TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID)
                    || (control.Id == TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID)
                    || (control.Id == TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID)
                    || (control.Id == TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID))
                {
                    if (!window.TSREntry.IsChangeAllowed() 
                        || (window.TSRExpenseSheet != null && !window.TSRExpenseSheet.IsChangeAllowed()))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            //return Core.Constants.DEFAULT_SELECTION_VALUE_STRING;
            return true;
        }
        /// <summary>
        /// When a drop down list is clicked, this event fires
        /// </summary>
        /// <param name="control"></param>
        /// <param name="selectedId"></param>
        /// <param name="selectedIndex"></param>
        public void DDL_OnAction(Office.IRibbonControl control, string selectedId, int selectedIndex)
        {
            try
            {
                OutlookInspector window =
                    ThisAddIn.FindOutlookInspector(control.Context);
                TSR.Core.Entity.ActivityList activities;
                Activity act;

                long id = -1;
                string[] idSplit = selectedId.Split('_');
                if (idSplit.Length == 2)
                {
                    if (!Int64.TryParse(idSplit[1], out id))
                        id = -1;
                }

                if (window != null)
                {
                    //Manipulation of list of organization, projects and activities so that they will have linked entries
                    switch (control.Id)
                    {
                        case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                            window.OrganizationID = selectedId;

                            long defaultProjectId = -1, defaultActivityId = -1;
                            ProjectList lstProj = Core.TSRFacade.GetProjectsForOrganization(id);
                            if (lstProj.Count == 1)
                            {
                                defaultProjectId = lstProj[0].ID;
                                ActivityList lstAct = Core.TSRFacade.GetActivitiesForProject(defaultProjectId);
                                if (lstAct.Count == 1)
                                {
                                    defaultActivityId = lstAct[0].ID;
                                }
                            }
                            else
                            {
                                PreferredPaths pp = Core.TSRFacade.GetPreferredPathsByOrganizationID(window.TSREntry.OrganizationID);
                                if (pp != null)
                                {
                                    defaultProjectId = pp.ProjectID;
                                    defaultActivityId = pp.ActivityID;
                                }
                            }
                            //AdjustForOrganization(selectedId, window, id);

                            window.SetDefaultSelection(id, defaultProjectId, defaultActivityId);

                            break;
                        case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                            window.ProjectID = selectedId;

                            if (id == -1)
                                activities = new ActivityList();
                            else
                                activities = Core.TSRFacade.GetActivitiesForProject(id);

                            if (activities.Count == 1)
                            {
                                window.TSREntry.ActivityID = activities[0].ID;
                            }

                            activities.InsertSelectionDefaultItem();
                            window.Activities = activities;
                            act = activities.FindByID(window.TSREntry.ActivityID);
                            if (act == null)
                                window.TSREntry.ActivityID = -1;

                            break;

                        case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                            window.ActivityID = selectedId;
                            break;
                    }

                    //DDL_GetSupertip(control);

                    ThisAddIn.m_Ribbon.Invalidate();
                    if(window.IsInspector)
                        ItemChanged(control);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        //private static void AdjustForOrganization(string selectedId, OutlookInspector window, long id)
        //{
        //    TSR.Core.Entity.ActivityList activities;
        //    //Activity act;
        //    window.OrganizationID = selectedId;
        //    TSR.Core.Entity.ProjectList projects;
        //    if (id == -1)
        //        projects = new ProjectList();
        //    else
        //        projects = Core.TSRFacade.GetProjectsForOrganization(id);

        //    projects.InsertSelectionDefaultItem();
        //    window.Projects = projects;
        //    //Project proj = projects.FindByID(window.TSREntry.ProjectID);
        //    //if (proj == null)
        //    //    window.TSREntry.ProjectID = -1;

        //    //if ((window.TSREntry.ProjectID == -1) || (window.TSREntry.ActivityID == -1))
        //    //{
        //        PreferredPaths pp = Core.TSRFacade.GetPreferredPathsByOrganizationID(window.TSREntry.OrganizationID);
        //        if (pp != null)
        //        {
        //            //if (window.TSREntry.ProjectID == -1)
        //            //{
        //                window.TSREntry.ProjectID = pp.ProjectID;
        //                activities = Core.TSRFacade.GetActivitiesForProject(pp.ProjectID);

        //                //act = activities.FindByID(window.TSREntry.ActivityID);
        //                //if (act == null)
        //                window.TSREntry.ActivityID = pp.ActivityID;

        //                activities.InsertSelectionDefaultItem();
        //                window.Activities = activities;
        //            //}
        //        //}
        //    }
        //}

        public string DDL_GetSupertip(Office.IRibbonControl control)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
            {
                return string.Empty;
            }

            this.tooltipResource_IsLoaded = false;

            OutlookInspector window =
                    ThisAddIn.FindOutlookInspector(control.Context);

            string name, des, type;
            name = des = type = string.Empty;
            string tip = string.Empty;

            switch (control.Id)
            {
                case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                    Organization org = null;
                    if (window.TSREntry != null)
                    {
                        org = TSR.Core.TSRFacade.GetOrganizationByID(window.TSREntry.OrganizationID, true);
                    }
                    if (org != null)
                    {
                        name = org.Name;
                        type = "";
                        des = org.Description;
                    }
                    //tip = string.Format("Name: {0} \nDescription: {1}", name, des);

                    tip = tooltipResource_Name + ": " + name + "\n";
                    tip += tooltipResource_Description + ": " + des;

                    break;
                case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                    Project proj = null;
                    if (window.TSREntry != null)
                    {
                        proj = TSR.Core.TSRFacade.GetProjectByID(window.TSREntry.ProjectID, true);
                    }
                    if (proj != null)
                    {
                        name = proj.Name;
                        type = proj.ProjectTypeName;
                        des = proj.Description;
                    }
                    //tip = string.Format("Name: {0} \nType: {1} \nDescription: {2}", name, type, des);
                    tip = tooltipResource_Name + ": " + name + "\n";
                    tip += tooltipResource_Type + ": " + type + "\n";
                    tip += tooltipResource_Description + ": " + des;

                    break;

                case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                    Activity act = null;
                    if (window.TSREntry != null)
                    {
                        act = TSR.Core.TSRFacade.GetActivityByID(window.TSREntry.ActivityID, true);
                    }
                    if (act != null)
                    {
                        name = act.Name;
                        type = act.ActivityTypeName;
                        des = act.Description;
                    }
                    //tip = string.Format("Name: {0} \nType: {1} \nDescription: {2}", name, type, des);
                    tip = tooltipResource_Name + ": " + name + "\n";
                    tip += tooltipResource_Type + ": " + type + "\n";
                    tip += tooltipResource_Description + ": " + des;

                    break;
            }
            if (tip.Length > 990)
            {
                tip = tip.Remove(989);
                tip = tip + "...";
            }
            return tip;
        }

        public string DDL_GetItemSupertip(Office.IRibbonControl control, int index)
        {
            if (!TSR.Core.SettingsHelper.TSRDisplayTooltip)
            {
                return string.Empty;
            }

            if (!this.tooltipResource_IsLoaded)
            {
                tooltipResource_Name = Core.ResourceManager.GetResourceString("Name", "Name");
                tooltipResource_Description = Core.ResourceManager.GetResourceString("Description", "Description");
                tooltipResource_Type = Core.ResourceManager.GetResourceString("Type", "Type");
                
                this.tooltipResource_IsLoaded = true;
            }

            OutlookInspector window = ThisAddIn.FindOutlookInspector(control.Context);                       

            string des, type, tip;
            des = type = tip = string.Empty;            

            switch (control.Id)
            {
                case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                    Organization org = null;
                    if (index > 0)
                    {                        
                        org = TSR.Core.TSRFacade.GetOrganizationByID(GetLongID(window.Organizations[index].OrganizationID), true);

                        if (org != null)
                        {
                            des = org.Description;
                        }
                        tip = tooltipResource_Description + ": " + des;
                    }
                    break;
                case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                    Project proj = null;
                    if (index > 0)
                    {
                        proj = TSR.Core.TSRFacade.GetProjectByID(GetLongID(window.Projects[index].ProjectID), true);

                        if (proj != null)
                        {                            
                            type = proj.ProjectTypeName;
                            des = proj.Description;
                        }
                        tip = tooltipResource_Type + ": " + type + "\n";
                        tip += tooltipResource_Description + ": " + des;
                    }

                    break;

                case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                    Activity act = null;
                    if (index > 0)
                    {
                        act = TSR.Core.TSRFacade.GetActivityByID(GetLongID(window.Activities[index].ActivityID), true);
                        if (act != null)
                        {
                            type = act.ActivityTypeName;
                            des = act.Description;
                        }
                        tip = tooltipResource_Type + ": " + type + "\n";
                        tip += tooltipResource_Description + ": " + des;
                    }
                    break;
            }
            if (tip.Length > 990)
            {
                tip = tip.Remove(989);
                tip = tip + "...";
            }
            return tip;
        }

        private long GetLongID(string window_ID)
        {
            long id = -1;
            string[] idSplit = window_ID.Split('_');
            if (idSplit.Length == 2)
            {
                if (!Int64.TryParse(idSplit[1], out id))
                    id = -1;
            }
            return id;
        }

        public string SubmitButton_GetSupertip(Office.IRibbonControl control)
        {
            return Core.ResourceHelper.RibbonTip_SubmitButton;
        }

        /// <summary>
        /// onAction callback method specified in Ribbon1.xml
        /// Submit button in Ribbon is clicked
        /// </summary>
        public void SubmitButton_Click(Office.IRibbonControl control)
        {
            //Debug.WriteLine("SubmitButton_Action");
            OutlookInspector window = null;
            try
            {
                window = ThisAddIn.FindOutlookInspector(control.Context);//gets outlook appointment object
            }
            catch (Exception e)
            {
                Core.Logging.LoggingHandler.LogError(e);
            }

            //Feature 340
            if (window != null)
            {
                bool inLockPeriod = window.IsNewTSREntry && Core.TSRFacade.IsLockPeriod(window.CurrentItem.StartInStartTimeZone);
                if (!inLockPeriod)
                {
                    if (!window.IsNewTSREntry && (Core.TSRFacade.IsLockPeriod(window.CurrentItem.StartInStartTimeZone) || Core.TSRFacade.IsLockPeriod(window.TSREntry.StartTimeStamp)))
                        inLockPeriod = true;
                }
                if (inLockPeriod)
                {
                    string msg = Core.ResourceHelper.LockedPeriodMessage;
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = msg,
                        Priority = 0
                    });
                    MessageBox.Show(msg);

                    return;
                }
            }

            if (window != null)
            {
                var duration = (window.CurrentItem.End - window.CurrentItem.Start).TotalMinutes;
                if (Core.TSRFacade.IsDurationWarning(duration))
                {
                    var enforce = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_ENFORCE);                                     
                    var setting = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_DURATION_WARNING);

                    var messageenforce = String.Format(Core.ResourceManager.GetResourceString("DurationEnforceMessage", "This time entry exceeds {0}, and cannot be saved/submitted."), setting);
                    var messageDuration = String.Format(Core.ResourceManager.GetResourceString("DurationWarningMessage", "This appointment is longer than {0}. Do you want to continue?"), setting);
                    if (enforce.ToLower() == "true")
                    {
                        MessageBox.Show(messageenforce, "TSR", MessageBoxButtons.OK);
                        return;
                    }
                    else
                    {
                        if (MessageBox.Show(messageDuration, "TSR", MessageBoxButtons.YesNo) == DialogResult.No)
                            return;
                    }
                }
            }

            
            //added by tsrdev2
            //feature 123
            if (window != null && !window.IsAllowTSRInfo)
            {                
                if (window.TSREntry.IsChangeAllowed() && window.CurrentItem.IsRecurring)
                {
                    string strWarning = string.Empty;
                    string messageTSRInfo = string.Empty;
                    string captionTSRInfo = string.Empty;

                    if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    {
                        strWarning = "Are you sure you want to enter TSR information on a recurring " +
                                "appointment? If you do, all future instances of the appoinment up to 12 " +
                                "months from now will be split into separate individual appointments and " +
                                "the recurring function from outlook will be removed";
                        messageTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message", strWarning);
                        captionTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning when enter TSR info on a recurring appointment");
                    }
                    else if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptOccurrence
                        || window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptException)
                    {
                        strWarning = "Are you sure you want to enter TSR information on a single item out of a series? If you do, this occurrence from the series will be removed and created an individual appointment";
                        messageTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Message", strWarning);
                        captionTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Caption", "Warning when enter TSR info on a single item out of a series");
                    }

                    DialogResult drTSRInfo = MessageBox.Show(messageTSRInfo, captionTSRInfo, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                    if (drTSRInfo == DialogResult.Yes)
                    {
                        window.IsAllowTSRInfo = true;
                    }
                    else
                    {
                        TSRItemButton_Click(control, false);
                        return;
                    }
                }
            }

            MsgBoxCheck.MessageBox dlg = new MsgBoxCheck.MessageBox();
            string message = Core.ResourceManager.GetResourceString("ButtonConfirm_SubmitTimeEntry_Message","Are you sure that you want to submit this entry?");
            string caption = Core.ResourceManager.GetResourceString("ButtonConfirm_SubmitTimeEntry_Caption", "Warning when submitting an entry");
            string checkMsg = Core.ResourceManager.GetResourceString("ButtonConfirm_SubmitTimeEntry_Check", "Don't show this warning again");
            //check time entry with expense
            ExpenseSheet sheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(window.TSREntry.ID);
            if (sheet != null || 
               (window.TSREntry.ExpenseSheet != null && window.TSREntry.ExpenseSheet.ExpenseEntryListLocal != null && window.TSREntry.ExpenseSheet.ExpenseEntryListLocal.Count > 0))
            {
                message = Core.ResourceManager.GetResourceString("ConfirmSubmitTimeEntryExpenseMessage", "You are about to submit your expense sheet as well. Do you want to continue?");
            }

            DialogResult dr =
                    dlg.Show("Areyousuretosubmit",
                    "DontShowAgain", DialogResult.Yes,
                    checkMsg,
                    message,
                    caption,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);            
             
            if (dr == DialogResult.Yes)
            {
                try
                {
                    if (window != null)
                    {
                        TimeEntry teTemp = Core.TSRFacade.GetTimeEntryByTSRItemID(window.TSREntry.ID);
                        if (teTemp != null && teTemp.LastModificationTime > window.TSREntry.LastModificationTime)
                        {
                            MessageBox.Show(Core.ResourceManager.GetResourceString("TimeEntryIntegrityException", "The time entry cannot be saved because it was modified in another window"));
                            return;
                        }

                        //check whether TSR Entry is valid [minimum information has been entered/selected.
                        if (!window.IsTSREntryValid())
                        {
                            string invalidTimeEntryErrorMsg = Core.ResourceManager.GetResourceString("InvalidTimeEntryErrorMsg", "Invalid Time Entry");
                            MessageBox.Show(invalidTimeEntryErrorMsg);
                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                MessageSummary = invalidTimeEntryErrorMsg,
                                Priority = 0
                            });

                        }
                        else
                        {
                            //TSR Entry's change is allowed or not
                            if (window.TSREntry.IsChangeAllowed())
                            {
                                //if change is allowed, change the status to be in submission queue [well, user have clicked submit button]                                
                                //window.TSREntry.SubmitterName = Core.MiscHelper.GetCurrentUsername();
                                window.TSREntry.SubmitterName = Core.TSRFacade.GetNONADUserName();
                                if ((window.CurrentItem.IsRecurring) 
                                    && (string.IsNullOrEmpty(window.CurrentItem.EntryID) || window.CurrentItem.RecurrenceState == Outlook.OlRecurrenceState.olApptMaster))
                                {
                                    window.ForceItemChange();//make sure user save it himself                         
                                    //fix bug can not get occurrent when recurring for existed time entry and click submit
                                    //window.IsSubmitRecurringAppointments = true;
                                    //window.CurrentItem.Save(); //save the outlook appointment
                                }
                                else
                                    window.CurrentItem.Save(); //save the outlook appointment

                                //string outlookAppointmentSubmittedInfoMsg = Core.ResourceManager.GetResourceString("EffectAfterSubmittingTSRFromOutlookAppMsg", "TSR Entry has been put in submission queue.");
                                //string msg = string.Empty;
                                //msg = outlookAppointmentSubmittedInfoMsg;

                                if (window.CurrentItem.IsRecurring)
                                {
                                    window.SaveTimeEntry(TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue);//save the TSR time entry information in local storage
                                    window.IsNewTSREntry = false;
                                }
                                else if (!string.IsNullOrEmpty(window.TSREntry.OutlookItemID))
                                {
                                    window.SaveTimeEntry(TSR.Core.UserAgentService.StatusEnum.InSubmissionQueue);//save the TSR time entry information in local storage
                                    window.IsNewTSREntry = false;
                                }
                                //else
                                //{
                                //    string effectAfterSavingOutlookAppMsg = Core.ResourceManager.GetResourceString("EffectAfterSubmittingTSRFromNewOutlookAppMsg", "Change will be in effect after you save the new appointment.");
                                //    msg = msg + " " + effectAfterSavingOutlookAppMsg;
                                //    window.ForceItemChange();
                                //}

                                //update expense after submit
                                window.TSREntry.ExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(window.TSREntry.ID);

                                //MessageBox.Show(msg);
                                ThisAddIn.m_Ribbon.Invalidate();
                            }
                            else
                            {
                                string timeEntryNotChangeableWarningMsg = Core.ResourceManager.GetResourceString("TimeEntryNotChangeableWarningMsg", "TSR Entry cannot be changed at this status");
                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    MessageSummary = timeEntryNotChangeableWarningMsg,
                                    Priority = 0
                                });
                                MessageBox.Show(timeEntryNotChangeableWarningMsg);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    Core.Logging.LoggingHandler.LogError(ex);
                }
            }
            else if (dr == DialogResult.No)
            {
                // No, stop
            }        
        }

        public bool SubmitButton_getEnable(Office.IRibbonControl control)
        {
            //Debug.WriteLine("SubmitButton_getEnable");
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);

            //if (window.CurrentItem.IsRecurring && window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
            //return false;
            //    return true;

            if (window != null)
            {
                return window.TSREntry.IsChangeAllowed();
            }
            
            return false;
        }

        public string SaveButton_GetSupertip(Office.IRibbonControl control)
        {
            return Core.ResourceHelper.Save;
        }

        /// <summary>
        /// onAction callback method specified in TSRRibbonOnCalendarTools.xml
        /// Save button in Ribbon is clicked
        /// </summary>
        public void SaveButton_Click(Office.IRibbonControl control)
        {
            
            OutlookInspector window = null;
            try
            {
                window = ThisAddIn.FindOutlookInspector(control.Context);//gets outlook appointment object
            }
            catch (Exception e)
            {
                Core.Logging.LoggingHandler.LogError(e);
            }

            //Feature 340
            if (window != null)
            {
                bool inLockPeriod = window.IsNewTSREntry && Core.TSRFacade.IsLockPeriod(window.CurrentItem.StartInStartTimeZone);
                if (!inLockPeriod)
                {
                    if (!window.IsNewTSREntry && (Core.TSRFacade.IsLockPeriod(window.CurrentItem.StartInStartTimeZone) || Core.TSRFacade.IsLockPeriod(window.TSREntry.StartTimeStamp)))
                        inLockPeriod = true;
                }
                if (inLockPeriod)
                {
                    string msg = Core.ResourceHelper.LockedPeriodMessage;
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = msg,
                        Priority = 0
                    });
                    MessageBox.Show(msg);

                    return;
                }
            }

            //added by tsrdev2
            //feature 123
            if (window != null && !window.IsAllowTSRInfo)
            {
                if (window.TSREntry.IsChangeAllowed() && window.CurrentItem.IsRecurring)                    
                {
                    string strWarning = string.Empty;
                    string messageTSRInfo = string.Empty;
                    string captionTSRInfo = string.Empty;

                    if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    {
                        strWarning = "Are you sure you want to enter TSR information on a recurring " +
                                "appointment? If you do, all future instances of the appoinment up to 12 " +
                                "months from now will be split into separate individual appointments and " +
                                "the recurring function from outlook will be removed";
                        messageTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message", strWarning);
                        captionTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning when enter TSR info on a recurring appointment");
                    }
                    else if (window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptOccurrence
                        || window.CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptException)
                    {
                        strWarning = "Are you sure you want to enter TSR information on a single item out of a series? If you do, this occurrence from the series will be removed and created an individual appointment";
                        messageTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Message", strWarning);
                        captionTSRInfo = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringOccurrence_Caption", "Warning when enter TSR info on a single item out of a series");
                    }

                    DialogResult drTSRInfo = MessageBox.Show(messageTSRInfo, captionTSRInfo, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                    if (drTSRInfo == DialogResult.Yes)
                    {
                        window.IsAllowTSRInfo = true;
                    }
                    else
                    {
                        TSRItemButton_Click(control, false);
                        return;
                    }
                }
            }
            
            //MsgBoxCheck.MessageBox dlg = new MsgBoxCheck.MessageBox();
            //string message = Core.ResourceManager.GetResourceString("ButtonConfirm_SaveTimeEntry_Message","Are you sure that you want to save this entry") + "?";
            //string caption = Core.ResourceManager.GetResourceString("ButtonConfirm_SaveTimeEntry_Caption", "Warning when saving entries");
            //string checkMsg = Core.ResourceManager.GetResourceString("ButtonConfirm_SubmitTimeEntry_Check", "Don't show this warning again");
            //DialogResult dr =
            //        dlg.Show("Areyousuretosave",
            //        "DontShowAgain", DialogResult.Yes,
            //        checkMsg,
            //        message,
            //        caption,
            //        MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            //if (dr == DialogResult.Yes)
            {
                try
                {
                    if (window != null)
                    {
                        TimeEntry teTemp = Core.TSRFacade.GetTimeEntryByTSRItemID(window.TSREntry.ID);
                        if (teTemp != null && teTemp.LastModificationTime > window.TSREntry.LastModificationTime)
                        {
                            MessageBox.Show(Core.ResourceManager.GetResourceString("TimeEntryIntegrityException", "The time entry cannot be saved because it was modified in another window"));
                            return;
                        }

                        //check whether TSR Entry is valid [minimum information has been entered/selected.
                        if (!window.IsTSREntryValid())
                        {
                            string invalidTimeEntryErrorMsg = Core.ResourceManager.GetResourceString("InvalidTimeEntryErrorMsg", "Invalid Time Entry");
                            MessageBox.Show(invalidTimeEntryErrorMsg);
                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                MessageSummary = invalidTimeEntryErrorMsg,
                                Priority = 0
                            });

                        }
                        else
                        {
                            //TSR Entry's change is allowed or not
                            if (window.TSREntry.IsChangeAllowed())
                            {
                                //if change is allowed, change the status to be in submission queue [well, user have clicked submit button]                                
                                if ((window.CurrentItem.IsRecurring)
                                        && (string.IsNullOrEmpty(window.CurrentItem.EntryID) || window.CurrentItem.RecurrenceState == Outlook.OlRecurrenceState.olApptMaster))
                                    window.ForceItemChange();//make sure user save it himself                         
                                else
                                    window.CurrentItem.Save(); //save the outlook appointment

                                if (window.CurrentItem.IsRecurring || !string.IsNullOrEmpty(window.TSREntry.OutlookItemID))
                                {
                                    window.SaveTimeEntry(window.TSREntry.Status);//save the TSR time entry information in local storage
                                    window.IsNewTSREntry = false;
                                }                                 
                                ThisAddIn.m_Ribbon.Invalidate();
                                MessageBox.Show(Core.ResourceManager.GetResourceString("TSRInfomationSaveSuccess", "TSR Information have been saved"));
                            }
                            else
                            {
                                string timeEntryNotChangeableWarningMsg = Core.ResourceManager.GetResourceString("TimeEntryNotChangeableWarningMsg", "TSR Entry cannot be changed at this status");
                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    MessageSummary = timeEntryNotChangeableWarningMsg,
                                    Priority = 0
                                });
                                MessageBox.Show(timeEntryNotChangeableWarningMsg);
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    Core.Logging.LoggingHandler.LogError(ex);
                    //MessageBox.Show(ex.Message);
                }
            }
        }

        public bool SaveButton_getEnable(Office.IRibbonControl control)
        {
            OutlookInspector window = ThisAddIn.FindOutlookInspector(control.Context);
            
            if (window != null)
            {
                return window.TSREntry.IsChangeAllowed();
            }
            return false;
        }

        public void AdvancedButton_Click(Office.IRibbonControl control)
        {
            try
            {
                //Debug.WriteLine("AdvancedButton_Click");
                OutlookInspector window =
                    ThisAddIn.FindOutlookInspector(control.Context);
                if (window != null)
                {
                    Shell.TimeEntryAdvanced frm = new Shell.TimeEntryAdvanced(window.TSREntry);
                    DialogResult dr = frm.ShowDialog();

                    if (dr == DialogResult.OK)
                    {
                        window.TSREntry.ExpenseSheet = frm.GetExpenseData();
                        ThisAddIn.m_Ribbon.Invalidate();
                        window.SetDefaultSelection(window.TSREntry.OrganizationID, window.TSREntry.ProjectID, window.TSREntry.ActivityID);
                        ItemChanged(control);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        #endregion

        #region Helpers

        private static void ItemChanged(Office.IRibbonControl control)
        {
            try
            {
                OutlookInspector window =
                    ThisAddIn.FindOutlookInspector(control.Context);

                if (window != null)
                {
                    window.ForceItemChange();
                    //ForceItemChange(window);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        //private static void ForceItemChange(OutlookInspector window)
        //{
        //    Outlook.UserProperty prop = window.CurrentItem.UserProperties["TSR_DUMMY_PROP"];
        //    if (prop == null)
        //        prop = window.CurrentItem.UserProperties.Add("test", Outlook.OlUserPropertyType.olText,
        //            false, System.Reflection.Missing.Value);
        //    prop.Value = "Something";
        //    prop.Delete();
        //}

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            System.Diagnostics.Debug.WriteLine("TSRRibbon xml file was not embedded");
            string _MessageSummary = Core.ResourceManager.GetResourceString("TSRRibbonXmlFileWasNotEmbedded","TSRRibbon xml file was not embedded");
            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
            {
                LoggingTime = DateTime.Now,
                CreatedTimeStamp = DateTime.Now,
                SessionID = string.Empty,
                MessageSummary = _MessageSummary,
                Priority = 0
            });
            return null;
        }

        private bool GetShowOnlyFavorites()
        {
            return TSR.Core.SettingsHelper.ShowOnlyFavorites;
        }

        private void CheckOrganizationShowOnlyFavorites(OutlookInspector window)
        {
            if (GetShowOnlyFavorites())
            {
                var entry = window.TSREntry;
                if (entry.Organization != null)
                    window.Organizations.Add(window.AllOrganizations.Where(x => (entry.Organization.ID == x.ID)).FirstOrDefault());
                //    var entry = window.TSREntry;
                //    var favoriteIDs = RetrievePreferredPaths().Select(x => x.OrganizationID).ToList().Distinct().ToList();
                //    if (entry.Organization != null)
                //        favoriteIDs.Add(entry.Organization.ID);

                //    var listDisplay = window.Organizations.Where(x => favoriteIDs.Contains(x.ID)).ToList();

                //    window.Organizations.Clear();
                //    foreach (var item in listDisplay)
                //    {
                //        window.Organizations.Add(item);
                //        //if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                //        //    window.Organizations.Remove(item);
                //    }
                //    window.CheckedOrgShowOnlyFavorites = true;
            }
        }

        private void CheckProjectShowOnlyFavorites(OutlookInspector window)
        {


            if (GetShowOnlyFavorites())
            {
                var entry = window.TSREntry;
                if (entry.Project != null)
                    window.Projects.Add(window.AllProjects.Where(x => (entry.Project.ID == x.ID)).FirstOrDefault());
                //    var entry = window.TSREntry;
                //    var favoriteIDs = RetrievePreferredPaths().Select(x => x.ProjectID).ToList().Distinct().ToList();
                //    if (entry.Project != null)
                //        favoriteIDs.Add(entry.Project.ID);

                //    var listDisplay = window.Projects.Where(x => favoriteIDs.Contains(x.ID)).ToList();
                //    foreach (var item in listDisplay)
                //    {
                //        window.Projects.Add(item);
                //        //if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                //        //    window.Projects.Remove(item);
                //    }                
            }
        }

        private ActivityList CheckActivityShowOnlyFavorites(OutlookInspector window)
        {
            if (GetShowOnlyFavorites())
            {
                var entry = window.TSREntry;
                if (entry.Project != null)
                    window.Activities.Add(window.AllActivities.Where(x => (entry.Activity.ID == x.ID)).FirstOrDefault());

                //var entry = window.TSREntry;
                //var favoriteIDs = RetrievePreferredPaths().Where(x => x.ProjectName.Equals(window.Projects.FindByProjectID(window.ProjectID).Name)).Select(x => x.ActivityID).ToList().Distinct().ToList();
                //if (entry.Activity != null)
                //    favoriteIDs.Add(entry.Activity.ID);

                //var listDisplay = window.Activities.Where(x => favoriteIDs.Contains(x.ID)).ToList();
                //foreach (var item in listDisplay)
                //{
                //    window.Activities.Add(item);
                //    //if (item.ID != Core.Constants.DEFAULT_SELECTION_VALUE_INT)
                //    //    window.Activities.Remove(item);
                //}
            }

            return window.Activities;
        }

        private IEnumerable<PreferredPaths> RetrievePreferredPaths()
        {
            return TSR.Core.TSRFacade.GetAllPreferredPathsList();
        }
        #endregion

        #region Callback Combobox

        public string Cbx_GetText(Office.IRibbonControl control)
        {
            OutlookInspector window =
                ThisAddIn.FindOutlookInspector(control.Context);
            if (window != null)
            {
                switch (control.Id)
                {
                    case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                        {
                            return window.Organizations.FindByOrganizationID(window.OrganizationID).Name;
                        }
                    case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                        {
                            return window.Projects.FindByProjectID(window.ProjectID).Name; 
                        }
                    case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                    case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                        {
                            return window.Activities.FindByActivityID(window.ActivityID).Name; 
                        }
                }
            }

            return String.Empty;
        }

        public void Cbx_OnChange(Office.IRibbonControl control, string selectedText)
        {
            try
            {
                OutlookInspector window =
                    ThisAddIn.FindOutlookInspector(control.Context);

                TSR.Core.Entity.ActivityList activities;
                Activity act;

                
                if (window != null)
                {
                    switch (control.Id)
                    {
                        case TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ORGANIZATION_DROPDOWN_ID:
                            var OrgObj = window.Organizations.FindByName(selectedText);
                            if (OrgObj == null)
                            {
                                window.SetDefaultSelection(-1, -1, -1, selectedText);
                                
                                ThisAddIn.m_Ribbon.InvalidateControl(TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID);
                                ThisAddIn.m_Ribbon.InvalidateControl(TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID);

                                return;
                            }
                            var organizationID = OrgObj.OrganizationID;
                            if (organizationID != window.OrganizationID)
                            {
                                //if user change Organization, should reset ContactID because it in dependence
                                window.TSREntry.ContactID = null;
                            }
                            window.OrganizationID = organizationID;

                            long defaultProjectId = -1, defaultActivityId = -1;
                            ProjectList lstProj = Core.TSRFacade.GetProjectsForOrganization(GetLongID(organizationID));
                            if (lstProj.Count == 1)
                            {
                                defaultProjectId = lstProj[0].ID;
                                ActivityList lstAct = Core.TSRFacade.GetActivitiesForProject(defaultProjectId);
                                if (lstAct.Count == 1)
                                {
                                    defaultActivityId = lstAct[0].ID;
                                }
                                else if(lstAct.Count > 1)
                                {
                                    var defaultAct = Core.TSRFacade.GetPreferredPathsListByProjectID(defaultProjectId);
                                    if (defaultAct != null)
                                        defaultActivityId = defaultAct.First().ActivityID;
                                    else
                                        defaultActivityId = lstAct.First().ID;
                                }
                            }
                            else
                            {
                                PreferredPaths pp = Core.TSRFacade.GetPreferredPathsByOrganizationID(window.TSREntry.OrganizationID);
                                if (pp != null)
                                {
                                    defaultProjectId = pp.ProjectID;
                                    defaultActivityId = pp.ActivityID;
                                }
                            }

                            window.SetDefaultSelection(GetLongID(organizationID), defaultProjectId, defaultActivityId, selectedText);

                            ThisAddIn.m_Ribbon.Invalidate();
                            if (window.IsInspector)
                                ItemChanged(control);

                            break;
                        case TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_PROJECT_DROPDOWN_ID:
                            var ProjObj = window.Projects.FindByName(selectedText);
                            if (ProjObj == null)
                            {
                                window.TSREntry.ProjectID = -1;
                                window.TSREntry.ActivityID = -1;

                                FillProjects(window, GetLongID(window.OrganizationID), selectedText);
                                FillActivities(window, GetLongID(window.ProjectID), string.Empty);
                                ThisAddIn.m_Ribbon.InvalidateControl(TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID);

                                return;
                            }
                            var projectID = window.Projects.FindByName(selectedText).ProjectID;
                            window.ProjectID = projectID;

                            if (GetLongID(projectID) == -1)
                                activities = new ActivityList();
                            else
                            {
                                activities = Core.TSRFacade.GetActivitiesForProject(GetLongID(projectID));
                            }

                            if (GetShowOnlyFavorites())
                            {
                                var favoriteAct = new ActivityList();
                                var favoriteIDs = RetrievePreferredPaths().Where(x => x.ProjectName.Equals(window.Projects.FindByProjectID(window.ProjectID).Name)).Select(x => x.ActivityID).ToList();
                                favoriteAct.AddRange(activities.Where(activity => favoriteIDs.Contains(activity.ID)));

                                activities = favoriteAct;
                            }

                            if (activities.Count == 1)
                            {
                                window.TSREntry.ActivityID = activities[0].ID;
                            }
                            else if (activities.Count > 1)
                            {
                                var defaultAct = Core.TSRFacade.GetPreferredPathsListByProjectID(ProjObj.ID);
                                if (defaultAct != null)
                                    window.TSREntry.ActivityID = defaultAct.First().ActivityID;
                                else
                                    window.TSREntry.ActivityID = activities.First().ID;
                            }

                            //Sort
                            activities.Sort();
                            window.Activities.Sort();

                            activities.InsertSelectionDefaultItem();
                            window.Activities = activities;
                            act = activities.FindByID(window.TSREntry.ActivityID);
                            if (act == null)
                                window.TSREntry.ActivityID = -1;

                            FillProjects(window, GetLongID(window.OrganizationID), selectedText);

                            ThisAddIn.m_Ribbon.Invalidate();
                            if (window.IsInspector)
                                ItemChanged(control);

                            break;

                        case TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID:
                        case TSRRIBBON_ITEM_REC_ACTIVITY_DROPDOWN_ID:
                            var ActObj = window.Activities.FindByName(selectedText);

                            if(ActObj == null)
                            {
                                window.TSREntry.ActivityID = -1;

                                FillActivities(window, GetLongID(window.ProjectID), selectedText);

                                return;
                            }
                            window.ActivityID = ActObj.ActivityID;;

                            FillActivities(window, GetLongID(window.ProjectID), selectedText);

                            ThisAddIn.m_Ribbon.Invalidate();
                            if (window.IsInspector)
                                ItemChanged(control);

                            break;
                    }

                    //ThisAddIn.m_Ribbon.Invalidate();
                    //if (window.IsInspector)
                    //    ItemChanged(control);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        #endregion

        #region Search 
        
        private void FillProjects(OutlookInspector window, long selectedOrganizationId, string keyword)
        {
            bool search = false;
            window.Projects = new ProjectList();
            if ((!keyword.Equals(Core.ResourceHelper.ProjectSelectionText)) && (!keyword.Equals(Core.ResourceHelper.ShowAllItems)) && !string.IsNullOrEmpty(keyword))
            {
                var all = Core.TSRFacade.GetProjectsForOrganization(selectedOrganizationId);
                if (all.Any())
                {
                    window.Projects.AddRange(all.Where(item => item.Name.ToLower().Contains(keyword.ToLower().Trim())));
                    window.Projects.Sort();
                }
                search = true;
            }
            else
            {
                window.Projects = Core.TSRFacade.GetProjectsForOrganization(selectedOrganizationId);
                window.Projects.Sort();
            }
            if (search)
            {
                InsertProjectAllItem(window);
            }
            else if (!search)
            {
                window.Projects.InsertSelectionDefaultItem();
            }
        }

        private void FillActivities(OutlookInspector window, long selectedProjectId, string keyword)
        {
            bool search = false;
            window.Activities = new ActivityList();
            if ((!keyword.Equals(Core.ResourceHelper.ActivitySelectionText)) && (!keyword.Equals(Core.ResourceHelper.ShowAllItems)) && !string.IsNullOrEmpty(keyword))
            {
                var all = Core.TSRFacade.GetActivitiesForProject(selectedProjectId);
                if (all.Any())
                {
                    window.Activities.AddRange(all.Where(item => item.Name.ToLower().Contains(keyword.ToLower().Trim())));
                    window.Activities.Sort();
                }
                search = true;
            }
            else
            {
                window.Activities = Core.TSRFacade.GetActivitiesForProject(selectedProjectId);
                window.Activities.Sort();
            }
            if (search)
            {
                InsertActivityAllItem(window);
            }
            else if (!search)
            {
                window.Activities.InsertSelectionDefaultItem();
                window.TSREntry.ActivityID = -1;
            }
        }

        private void InsertProjectAllItem(OutlookInspector window)
        {
            var project = new Project();
            project.Name = Core.ResourceHelper.ShowAllItems;
            project.ID = -1;
            project.Modified = DateTime.Now.ToString(Core.Constants.DEFAULT_FORMAT_TIMESTAMP);

            window.Projects.Insert(0, project);
        }

        private void InsertActivityAllItem(OutlookInspector window)
        {
            var act = new Activity();
            act.Name = Core.ResourceHelper.ShowAllItems;
            act.ID = -1;
            act.Modified = DateTime.Now.ToString(Core.Constants.DEFAULT_FORMAT_TIMESTAMP);

            window.Activities.Insert(0, act);
        }
        #endregion
    }
}
