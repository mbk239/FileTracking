﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Security;
using System.Security.Policy;


namespace TSR.Outlook
{
    [RunInstaller(true)]    
    public partial class ImplementCAS : System.Configuration.Install.Installer
    {
        private readonly string installPolicyLevel = "Machine";
        private readonly string namedPermissionSet = "FullTrust";
        private readonly string codeGroupDescription = "VSTO Permissions for TSR Plugin";
        private readonly string productName = "Contest TSRConnector";
        private readonly bool debugBreakOnInstall = false;

        private string codeGroupName = "";

        /// <summary>
        /// Gets a CodeGroup name based on the productname and URL evidence
        /// </summary>
        private string CodeGroupName
        {
            get
            {
                if (codeGroupName.Length == 0)
                {
                    codeGroupName = "[" + productName + "] " + InstallDirectory;
                }

                return codeGroupName;
            }
        }

        /// <summary>
        /// Gets the installdirectory with a wildcard suffix for use with URL evidence
        /// </summary>
        private string InstallDirectory
        {
            get
            {
                // Get the install directory of the current installer
                string assemblyPath = this.Context.Parameters["assemblypath"];
                string installDirectory = assemblyPath.Substring(0, assemblyPath.LastIndexOf("\\"));

                if (!installDirectory.EndsWith(@"\"))
                    installDirectory += @"\";
                installDirectory += "*";

                return installDirectory;
            }
        }

        public ImplementCAS()
        {
            InitializeComponent();
        }

        public override void Install(System.Collections.IDictionary stateSaver)
        {

            System.Windows.Forms.MessageBox.Show("Start install CAS");

            base.Install(stateSaver);

            try
            {
                ConfigureCodeAccessSecurity();

                // Method not able to persist configuration to config file:
                // SetPortalUrlFromInstallerParameter();
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                System.Windows.Forms.MessageBox.Show(ex.ToString());
                this.Rollback(stateSaver);
            }
        }

        /// <summary>
        /// Configures FullTrust for the entire installdirectory
        /// </summary>
        private void ConfigureCodeAccessSecurity()
        {
            System.Windows.Forms.MessageBox.Show("Get Policy level");
            PolicyLevel machinePolicyLevel = GetPolicyLevel();
            System.Windows.Forms.MessageBox.Show("Get code group");
            if (null == GetCodeGroup(machinePolicyLevel))
            {
                System.Windows.Forms.MessageBox.Show("Code group equals to null");
                // Create a new FullTrust permission set
                PermissionSet permissionSet = new NamedPermissionSet(this.namedPermissionSet);
                IMembershipCondition membershipCondition = new UrlMembershipCondition(InstallDirectory);

                // Create the code group
                PolicyStatement policyStatement = new PolicyStatement(permissionSet);
                System.Windows.Forms.MessageBox.Show("Create new UnionCodeGroup");
                CodeGroup codeGroup = new UnionCodeGroup(membershipCondition, policyStatement);
                System.Windows.Forms.MessageBox.Show("Sucessfully");
                codeGroup.Description = this.codeGroupDescription;
                codeGroup.Name = this.codeGroupName;

                // Add the code group
                machinePolicyLevel.RootCodeGroup.AddChild(codeGroup);

                // Save changes                
                SecurityManager.SavePolicy();
            }
        }

        /// <summary>
        /// Gets the currently defined policylevel
        /// </summary>
        /// <returns></returns>
        private PolicyLevel GetPolicyLevel()
        {
            // Find the machine policy level
            PolicyLevel machinePolicyLevel = null;
            System.Collections.IEnumerator policyHierarchy = SecurityManager.PolicyHierarchy();

            while (policyHierarchy.MoveNext())
            {
                PolicyLevel level = (PolicyLevel)policyHierarchy.Current;
                if (level.Label.CompareTo(installPolicyLevel) == 0)
                {
                    machinePolicyLevel = level;
                    break;
                }
            }

            if (machinePolicyLevel == null)
            {
                TSR.Core.Logging.LoggingHandler.LogError(new ApplicationException(
                    "Could not find Machine Policy level. Code Access Security " +
                    "is not configured for this application."
                    ));
                throw new ApplicationException(
                    "Could not find Machine Policy level. Code Access Security " +
                    "is not configured for this application."
                    );

            }

            return machinePolicyLevel;
        }

        /// <summary>
        /// Gets current codegroup based on CodeGroupName at the given policylevel
        /// </summary>
        /// <param name="policyLevel"></param>
        /// <returns>null if not found</returns>
        private CodeGroup GetCodeGroup(PolicyLevel policyLevel)
        {
            foreach (CodeGroup codeGroup in policyLevel.RootCodeGroup.Children)
            {
                if (codeGroup.Name.CompareTo(CodeGroupName) == 0)
                {
                    return codeGroup;
                }
            }

            return null;
        }

        public override void Uninstall(System.Collections.IDictionary savedState)
        {
            if (debugBreakOnInstall)
                System.Diagnostics.Debugger.Break();

            base.Uninstall(savedState);

            try
            {
                this.UninstallCodeAccessSecurity();
            }

            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogError(ex);
                string message = TSR.Core.ResourceManager.GetResourceString("UnableToUnInstallCodeAccessSecurity", "Unable to uninstall code access security");
                System.Windows.Forms.MessageBox.Show(message + ":\n\n" + ex.ToString());
            }
        }

        private void UninstallCodeAccessSecurity()
        {
            PolicyLevel machinePolicyLevel = GetPolicyLevel();

            CodeGroup codeGroup = GetCodeGroup(machinePolicyLevel);

            if (codeGroup != null)
            {
                machinePolicyLevel.RootCodeGroup.RemoveChild(codeGroup);

                // Save changes
                SecurityManager.SavePolicy();
            }
        }
    }
}
