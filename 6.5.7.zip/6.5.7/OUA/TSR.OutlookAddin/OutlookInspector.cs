﻿using System.Linq;

namespace TSR.OutlookAddin
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using Outlook = Microsoft.Office.Interop.Outlook;
    using Core = TSR.Core;
    using TSR.Core.Entity;
    using System.Runtime.CompilerServices;
    using Microsoft.Office.Interop.Outlook;
    using Entity = TSR.Core.Entity;
    //using TSR.Core.Entity;
    /// <summary>
    /// This class tracks the state of an Outlook inspector window for the 
    /// add-in and ensures that Ribbon and item state is handled correctly.
    /// </summary>
    [ComImport(), Guid("000C03A7-0000-0000-C000-000000000046"), TypeLibType((short)0X1040)]
    public interface IRibbonUI
    {
        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType =
        MethodCodeType.Runtime), DispId(1)]
        void Invalidate();

        [MethodImpl(MethodImplOptions.InternalCall, MethodCodeType =
        MethodCodeType.Runtime), DispId(2)]
        void InvalidateControl([In(), MarshalAs(UnmanagedType.BStr)] string
        ControlID);
    }
    public class OutlookInspector
    {
        #region Constants
        private const string OUTLOOK_PROPERTYNAME_ISRECURRING = "IsRecurring";
        private const string OUTLOOK_PROPERTYNAME_CATEGORIES = "Categories";
        private const string DUMMY_PROP_INDEX = "TSR_DUMMY_PROP";
        private const string DUMMY_PROP_NAME = "test";
        private const string DUMMY_PROP_VALUE = "Something";

        private const string TSR_RECURRING_PROP_NAME = "TSRRecurringProp";
        private const string TSR_RECURRING_PROP_VALUE = "TSRIsRecurringValue";

        #endregion

        #region Instance Variables

        private Outlook.Inspector m_Window;                         // wrapped window object
        private Outlook.AppointmentItem m_Appointment;              // wrapped AppointmentItem
        private Entity.TimeEntry m_TSREntry;
        private Entity.ExpenseSheet m_TSRExpenseSheet;

        private bool m_IsTSRItem;
        private Entity.OrganizationList m_Organizations;
        private Entity.ProjectList m_Projects;
        private Entity.ActivityList m_Activities;

        private Entity.OrganizationList m_AllOrganizations;
        private Entity.ProjectList m_AllProjects;
        private Entity.ActivityList m_AllActivities;

        private bool m_IsDayEvent;

        //added by tsrdev
        //feature 123
        private bool m_IsAllowTSRInfo;

        //private bool m_IsNew;

        public bool AppointmentSaved;

        public bool m_IsClickYesDurationWarning = false;
        private bool m_IsClickNoDurationWarning = true;

        //added by tsrdev2
        //temp variabe to fixbug
        private bool m_IsSubmitRecurringAppointments;

        private Outlook.Selection m_Selection;
        private bool m_IsInspector;
        private bool m_IsSelection;

        //apply for case OutlookInspector is a Selection
        private bool m_IsConvertToRecurring;
        private DateTime? m_StartTimeRecurring;
        private DateTime? m_EndTimeRecurring;

        private bool m_IsNewTSREntry = false;

        private bool m_IsNewAppointmentFromRecurringInstance = false;
        private static List<Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler> lstWrite = new List<Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler>();

        private IEnumerable<PreferredPaths> RetrievePreferredPaths()
        {
            return TSR.Core.TSRFacade.GetAllPreferredPathsList();
        }

        #endregion

        #region Events

        public event EventHandler Close;
        public event EventHandler<InvalidateEventArgs> InvalidateControl;

        #endregion

        #region Constructor

        /// <summary>
        /// Create a new instance of the tracking class for an inspector 
        /// </summary>
        /// <param name="inspector">The new inspector window to monitor</param>
        ///<remarks></remarks>
        public OutlookInspector(Outlook.Inspector inspector)
        {
            m_IsSubmitRecurringAppointments = false;
            //outlook appointment is just opened so, appointment is definitely not saved yet
            AppointmentSaved = false;
            m_Window = inspector;
            m_Appointment = inspector.CurrentItem as Outlook.AppointmentItem;
            // Hookup events, Outlook Appointment close event
            ((Outlook.InspectorEvents_Event)inspector).Close += new Microsoft.Office.Interop.Outlook.InspectorEvents_CloseEventHandler(OutlookWindow_Close);

            IsTSRItem = false;
            IsAllowTSRInfo = false;
            this.IsNewTSREntry = false;

            if (m_Appointment != null)
            {
                m_IsDayEvent = m_Appointment.AllDayEvent;
                SetTSRItem();
                //hooking up events property changed and write events of outlook appointment events
                m_Appointment.PropertyChange += new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);
                //m_Appointment.Write += new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
                Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler writehandle = new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
                m_Appointment.Write += writehandle;
                lstWrite.Clear();
                lstWrite.Add(writehandle);
                m_Appointment.BeforeDelete += new ItemEvents_10_BeforeDeleteEventHandler(m_Appointment_BeforeDelete);

                SetLicenseText();
            }

            m_IsInspector = true;
            m_IsSelection = false;

            m_StartTimeRecurring = null;
            m_EndTimeRecurring = null;
        }

        public OutlookInspector(Outlook.Selection selection)
        {
            m_IsSubmitRecurringAppointments = false;
            //outlook appointment is just opened so, appointment is definitely not saved yet
            AppointmentSaved = false;
            m_Selection = selection;
            if (selection != null && selection.Count > 0)
            {
                Outlook.AppointmentItem appItemTemp = selection[1] as Outlook.AppointmentItem;

                if (appItemTemp.IsRecurring && appItemTemp.RecurrenceState == Outlook.OlRecurrenceState.olApptOccurrence)
                {
                    Outlook.AppointmentItem appMaster = appItemTemp.Parent as Outlook.AppointmentItem;
                    if (appMaster != null)
                    {
                        m_Appointment = appMaster;
                    }
                }
                else
                    m_Appointment = selection[1] as Outlook.AppointmentItem;
            }
            // Hookup events, Outlook Appointment close event
            //((Outlook.InspectorEvents_Event)inspector).Close += new Microsoft.Office.Interop.Outlook.InspectorEvents_CloseEventHandler(OutlookWindow_Close);

            IsTSRItem = false;
            IsAllowTSRInfo = false;
            IsConvertToRecurring = false;
            this.IsNewTSREntry = false;

            if (m_Appointment != null)
            {
                bool bModifyAppointment = false;
                TimeEntry te = Core.TSRFacade.GetTimeEntryByOutlookItemID(m_Appointment.EntryID);

                if (te != null)
                {
                    bModifyAppointment = true;
                }

                m_IsDayEvent = m_Appointment.AllDayEvent;
                SetTSRItem();
                //hooking up events property changed and write events of outlook appointment events
                m_Appointment.PropertyChange += new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);

                if (bModifyAppointment == true && lstWrite.Count > 0)
                {
                    //lstWrite.Clear();
                    //disable m_Appointment.Write for this inspector because there is modal inspector are displaying
                }
                else
                {
                    m_Appointment.Write += new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
                }

                SetLicenseText();
            }
            m_IsInspector = false;
            m_IsSelection = true;

            m_StartTimeRecurring = null;
            m_EndTimeRecurring = null;
        }

        public OutlookInspector(Outlook.Selection selection, bool isTSREntry, long orgID, long projID, long actID)
        {
            m_IsSubmitRecurringAppointments = false;
            //outlook appointment is just opened so, appointment is definitely not saved yet
            AppointmentSaved = false;
            m_Selection = selection;
            if (selection != null && selection.Count > 0)
            {
                Outlook.AppointmentItem appItemTemp = selection[1] as Outlook.AppointmentItem;

                if (appItemTemp.IsRecurring && appItemTemp.RecurrenceState == Outlook.OlRecurrenceState.olApptOccurrence)
                {
                    Outlook.AppointmentItem appMaster = appItemTemp.Parent as Outlook.AppointmentItem;
                    if (appMaster != null)
                    {
                        m_Appointment = appMaster;
                    }
                }
                else
                    m_Appointment = selection[1] as Outlook.AppointmentItem;
            }
            // Hookup events, Outlook Appointment close event
            //((Outlook.InspectorEvents_Event)inspector).Close += new Microsoft.Office.Interop.Outlook.InspectorEvents_CloseEventHandler(OutlookWindow_Close);

            IsTSRItem = isTSREntry;
            IsAllowTSRInfo = false;
            IsConvertToRecurring = false;
            this.IsNewTSREntry = false;

            if (m_Appointment != null)
            {
                m_IsDayEvent = m_Appointment.AllDayEvent;
                SetTSRItem(orgID, projID, actID);
                //hooking up events property changed and write events of outlook appointment events
                m_Appointment.PropertyChange += new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);
                m_Appointment.Write += new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);

                SetLicenseText();
            }
            m_IsInspector = false;
            m_IsSelection = true;

            m_StartTimeRecurring = null;
            m_EndTimeRecurring = null;
        }

        private void SetTSRItem()
        {
            if (CurrentItem.EntryID != null)
            {
                //appointment is recurring
                if (CurrentItem.IsRecurring)
                {
                    SetRecurringTimeEntryForExistingAppointment();
                }
                else
                {
                    m_TSREntry = Core.TSRFacade.GetTimeEntryByOutlookItemID(CurrentItem.EntryID);
                }
            }
            if (TSREntry == null)
            {
                //m_IsNew = true;
                m_TSREntry = new Entity.TimeEntry(Guid.NewGuid(), CurrentItem);
                this.IsNewTSREntry = true;

                //If preferred path is saved, then load default settings, if available..
                bool defaultSettings = false;
                long defaultOrganizationId = -1;
                long defaultProjectId = -1;
                long defaultActivityId = -1;
                GetDefaultIDs(ref defaultSettings, ref defaultOrganizationId, ref defaultProjectId, ref defaultActivityId);
                //Now we know what are the default ids..
                SetDefaultSelection(defaultSettings, defaultOrganizationId, defaultProjectId, defaultActivityId);
            }
            else
            {
                PrepareRibbonCombos();
                //m_IsNew = false;
                IsTSRItem = true;
                this.IsNewTSREntry = false;
            }
        }

        private void SetTSRItem(long orgID, long projID, long actID)
        {
            if (CurrentItem.EntryID != null)
            {
                //appointment is recurring
                if (CurrentItem.IsRecurring)
                {
                    SetRecurringTimeEntryForExistingAppointment();
                }
                else
                {
                    m_TSREntry = Core.TSRFacade.GetTimeEntryByOutlookItemID(CurrentItem.EntryID);
                }
            }
            if (TSREntry == null)
            {
                //m_IsNew = true;
                m_TSREntry = new Entity.TimeEntry(Guid.NewGuid(), CurrentItem);
                this.IsNewTSREntry = true;

                //Now we know what are the default ids..
                SetDefaultSelection(true, orgID, projID, actID);
            }
            else
            {
                PrepareRibbonCombos();
                //m_IsNew = false;
                IsTSRItem = true;
                this.IsNewTSREntry = false;
            }
        }

        private void PrepareRibbonCombos()
        {
            if (Core.TimeEntryHelper.GetTimeEntryType(m_TSREntry) == TSR.Core.TimeEntryType.Valid)
            {
                Organizations = Core.TSRFacade.GetAllOrganizations();
                CalculateSelectableOrg();
                Organizations.Sort();//list of organization - sorted
                Organizations.InsertSelectionDefaultItem();
                AllOrganizations = Core.TSRFacade.GetAllOrganizations();

                Projects = Core.TSRFacade.GetProjectsForOrganization(TSREntry.OrganizationID);
                CalculateSelectableProject();
                Projects.Sort();//list of sorted projects
                Projects.InsertSelectionDefaultItem();
                AllProjects = Core.TSRFacade.GetProjectsForOrganization(TSREntry.OrganizationID);

                Activities = Core.TSRFacade.GetActivitiesForProject(TSREntry.ProjectID);
                CalculateSelectableActivity();
                Activities.Sort();//list of sorted activities
                Activities.InsertSelectionDefaultItem();
                AllActivities = Core.TSRFacade.GetActivitiesForProject(TSREntry.ProjectID); 
            }
            else
            {
                if (!m_TSREntry.IsChangeAllowed())
                {
                    if (Core.TimeEntryHelper.GetTimeEntryType(m_TSREntry) == TSR.Core.TimeEntryType.MissingCurrentDB)
                    {
                        Organizations = new OrganizationList();
                        Organizations.Add(m_TSREntry.Organization);

                        Projects = new ProjectList();
                        Projects.Add(m_TSREntry.Project);

                        Activities = new ActivityList();
                        Activities.Add(m_TSREntry.Activity);
                    }
                    else
                    {
                        if (m_TSREntry.Organization == null)
                        {
                            Organizations = new OrganizationList();
                            Organizations.InsertSelectionDefaultItem();

                            Projects = new ProjectList();
                            Projects.InsertSelectionDefaultItem();

                            Activities = new ActivityList();
                            Activities.InsertSelectionDefaultItem();
                        }
                        else
                        {
                            if (m_TSREntry.Project == null)
                            {
                                Organizations = new OrganizationList();
                                Organizations.Add(m_TSREntry.Organization);

                                Projects = new ProjectList();
                                Projects.InsertSelectionDefaultItem();

                                Activities = new ActivityList();
                                Activities.InsertSelectionDefaultItem();
                            }
                            else
                            {
                                if (m_TSREntry.Activity == null)
                                {
                                    Organizations = new OrganizationList();
                                    Organizations.Add(m_TSREntry.Organization);

                                    Projects = new ProjectList();
                                    Projects.Add(m_TSREntry.Project);

                                    Activities = new ActivityList();
                                    Activities.InsertSelectionDefaultItem();
                                }
                            }
                        }
                    }
                }
                else
                {
                    Organizations = Core.TSRFacade.GetAllOrganizations();
                    CalculateSelectableOrg();
                    Organizations.Sort();//list of organization - sorted                    
                    Organizations.InsertSelectionDefaultItem();
                    AllOrganizations = Core.TSRFacade.GetAllOrganizations();

                    Projects = Core.TSRFacade.GetProjectsForOrganization(TSREntry.OrganizationID);
                    CalculateSelectableProject();
                    Projects.Sort();//list of sorted projects
                    Projects.InsertSelectionDefaultItem();
                    if (OrganizationID == Organizations[0].OrganizationID)
                        ProjectID = Projects[0].ProjectID;
                    AllProjects = Core.TSRFacade.GetProjectsForOrganization(TSREntry.OrganizationID);

                    Activities = Core.TSRFacade.GetActivitiesForProject(TSREntry.ProjectID);
                    CalculateSelectableActivity();
                    Activities.Sort();//list of sorted activities
                    Activities.InsertSelectionDefaultItem();
                    if (ProjectID == Projects[0].ProjectID)
                        ActivityID = Activities[0].ActivityID;
                    AllActivities = Core.TSRFacade.GetActivitiesForProject(TSREntry.ProjectID);
                }
            }
        }

        private void SetRecurringTimeEntryForExistingAppointment()
        {
            if (string.IsNullOrEmpty(CurrentItem.EntryID))
                return;

            switch (CurrentItem.RecurrenceState)
            {
                //if series is opened
                case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster:
                    TimeEntry teFromMaster = getTimeEntryFromRecurringMaster(CurrentItem.EntryID);//fill the time entry from recurring master table
                    if (teFromMaster != null)
                        m_TSREntry = teFromMaster;

                    break;
                //if specific occurrence is opened
                case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptOccurrence:
                case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptException:
                    //at first try to get it from time entry table, if it does not exist there, get one following recurring master table [will be necessary
                    //when a specific occurrence was opened for first time
                    TimeEntry te = Core.TSRFacade.GetTimeEntryForRecurringAppointment(CurrentItem.EntryID, CurrentItem.Start, CurrentItem.End, true, true);
                    if ((te != null) && (te.IsDeleted))
                    {
                        //Specific TSR entry was deleted, but Outlook recurring occurrence still exists
                        //make sure, it opens as non TSR Item
                        m_TSREntry = null;
                    }
                    else
                    {
                        m_TSREntry = te;
                        if (m_TSREntry == null)
                            m_TSREntry = getTimeEntryFromRecurringMaster(CurrentItem.EntryID);
                    }
                    break;
            }
        }

        private void SetLicenseText()
        {
            LicenseText = Core.TSRFacade.GetLicenseText();
        }

        private Core.Entity.TimeEntry getTimeEntryFromRecurringMaster(string outlookItemID)
        {
            RecurringMaster rm = Core.TSRFacade.GetRecurringMasterByOutlookEntryID(outlookItemID);
            if (rm != null)
            {
                TimeEntry tSREntry = new TimeEntry(Guid.NewGuid(), CurrentItem);
                tSREntry.OrganizationID = rm.OrganizationID;
                tSREntry.ProjectID = rm.ProjectID;
                tSREntry.ActivityID = rm.ActivityID;
                tSREntry.IsRecurring = true;
                return tSREntry;
            }
            return null;
        }

        /// <summary>
        /// retrieves default ids as saved as preferred paths in Favorites
        /// </summary>
        /// <param name="defaultSettings"></param>
        /// <param name="defaultOrganizationId"></param>
        /// <param name="defaultProjectId"></param>
        /// <param name="defaultActivityId"></param>
        private static void GetDefaultIDs(ref bool defaultSettings, ref long defaultOrganizationId, ref long defaultProjectId, ref long defaultActivityId)
        {
            Core.Entity.PreferredPathsList ppList = Core.TSRFacade.GetAllPreferredPathsList();
            foreach (Entity.PreferredPaths pp in ppList)
            {
                defaultSettings = pp.IsDefault;
                if (defaultSettings)
                {
                    defaultOrganizationId = pp.OrganizationID;
                    defaultProjectId = pp.ProjectID;
                    defaultActivityId = pp.ActivityID;
                    break;
                }
            }
        }

        /// <summary>
        /// Sets default selection as saved in preferred paths
        /// </summary>
        /// <param name="defaultOrganizationId"></param>
        /// <param name="defaultProjectId"></param>
        /// <param name="defaultActivityId"></param>
        public void SetDefaultSelection(long defaultOrganizationId, long defaultProjectId, long defaultActivityId)
        {
            SetDefaultSelection(true, defaultOrganizationId, defaultProjectId, defaultActivityId);
        }

        /// <summary>
        /// Overloaded method to set default selections
        /// </summary>
        /// <param name="defaultSettings"></param>
        /// <param name="defaultOrganizationId"></param>
        /// <param name="defaultProjectId"></param>
        /// <param name="defaultActivityId"></param>
        private void SetDefaultSelection(bool defaultSettings, long defaultOrganizationId, long defaultProjectId, long defaultActivityId)
        {
            AllOrganizations = Core.TSRFacade.GetAllOrganizations();
            Organizations = Core.TSRFacade.GetAllOrganizations();
            CalculateSelectableOrg();

            Organizations.Sort();
            Organizations.InsertSelectionDefaultItem();

            AllProjects = Core.TSRFacade.GetProjectsForOrganization(defaultOrganizationId);
            Projects = (defaultSettings) ? Core.TSRFacade.GetProjectsForOrganization(defaultOrganizationId) : new ProjectList();//Core.TSRFacade.GetAllProjects();
            CalculateSelectableProject();
            Projects.Sort();
            Projects.InsertSelectionDefaultItem();

            AllActivities = Core.TSRFacade.GetActivitiesForProject(defaultProjectId);
            Activities = (defaultSettings) ? Core.TSRFacade.GetActivitiesForProject(defaultProjectId) : new ActivityList();//Core.TSRFacade.GetAllActivities();
            CalculateSelectableActivity();
            Activities.Sort();
            Activities.InsertSelectionDefaultItem();
            if (defaultSettings)
            {
                m_TSREntry.OrganizationID = defaultOrganizationId;
                m_TSREntry.ProjectID = defaultProjectId;
                m_TSREntry.ActivityID = defaultActivityId;
            }
        }

        private void CalculateSelectableOrg()
        {
            if (TSR.Core.SettingsHelper.ShowOnlyFavorites && TSREntry.IsChangeAllowed())
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.OrganizationID).ToList().Distinct().ToList();
                var listDisplay = Organizations.Where(x => favoriteIDs.Contains(x.ID)).ToList();
                Organizations.Clear();
                foreach (var item in listDisplay)
                {
                    Organizations.Add(item);
                }
            }
        }

        private void CalculateSelectableProject()
        {
            if (TSR.Core.SettingsHelper.ShowOnlyFavorites && TSREntry.IsChangeAllowed())
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.ProjectID).ToList().Distinct().ToList();
                var listDisplay = Projects.Where(x => favoriteIDs.Contains(x.ID)).ToList();
                Projects.Clear();
                foreach (var item in listDisplay)
                {
                    Projects.Add(item);
                }
            }
        }

        private void CalculateSelectableActivity()
        {
            if (TSR.Core.SettingsHelper.ShowOnlyFavorites && TSREntry.IsChangeAllowed())
            {
                var favoriteIDs = RetrievePreferredPaths().Select(x => x.ActivityID).ToList().Distinct().ToList();
                var listDisplay = Activities.Where(x => favoriteIDs.Contains(x.ID)).ToList();
                Activities.Clear();
                foreach (var item in listDisplay)
                {
                    Activities.Add(item);
                }
            }
        }

        public void SetDefaultSelection(long defaultOrganizationId, long defaultProjectId, long defaultActivityId, string selectedOrgText)
        {
            bool search = false;
            Organizations = Core.TSRFacade.GetAllOrganizations();
            CalculateSelectableOrg();

            if ((!selectedOrgText.Equals(Core.ResourceHelper.OrganizationSelectionText)) && (!selectedOrgText.Equals(Core.ResourceHelper.ShowAllItems)) && !string.IsNullOrEmpty(selectedOrgText))
            {
                var temp = new OrganizationList();                
                if (Organizations.Any())
                {
                    foreach (var item in Organizations)
                    {
                        if (item.Name.ToLower().Contains(selectedOrgText.ToLower().Trim()))
                            temp.Add(item);
                    }
                }
                Organizations = temp;
                search = true;
            }

            Organizations.Sort();
            m_TSREntry.OrganizationID = defaultOrganizationId;

            if (search)
            {
                InsertOrganizationAllItem();
            }
            else if (!search)
            {
                Organizations.InsertSelectionDefaultItem();
            }

            Projects = Core.TSRFacade.GetProjectsForOrganization(defaultOrganizationId);
            CalculateSelectableProject();
            Projects.Sort();
            Projects.InsertSelectionDefaultItem();

            Activities = Core.TSRFacade.GetActivitiesForProject(defaultProjectId);
            CalculateSelectableActivity();
            Activities.Sort();
            Activities.InsertSelectionDefaultItem();

            m_TSREntry.ProjectID = defaultProjectId;
            m_TSREntry.ActivityID = defaultActivityId;
        }

        private void InsertOrganizationAllItem()
        {
            var org = new Organization();
            org.Name = Core.ResourceHelper.ShowAllItems;
            org.ID = -1;
            org.Modified = DateTime.Now.ToString(Core.Constants.DEFAULT_FORMAT_TIMESTAMP);

            Organizations.Insert(0, org);
        }

        /// <summary>
        /// Overloaded method to set default selections
        /// </summary>
        /// <param name="defaultSettings"></param>
        /// <param name="defaultOrganizationId"></param>
        /// <param name="defaultProjectId"></param>
        /// <param name="defaultActivityId"></param>

        #endregion

        #region Item-level Events

        // This event procedure listens for Address changes on the item
        // If all addresses are empty, then set visible state of cbWidgets to false.
        // Also calls RaiseInvalidateControl to invalidate ColorWidgetsGroup.
        // Invalidataing a control causes RibbonX callbacks to fire again for the specific control.
        // To improve performance, RibbonX best practice is to call InvalidateControl 
        // rather than Invalidate which invalidates all controls on all Ribbons.
        // ColorWidgetsGroup_GetVisible handles visibility of TSRSetupGroup
        private void m_Appointment_PropertyChange(string Name)
        {
            if (!IsTSRItem)
            {
                if ((Name.Equals(OUTLOOK_PROPERTYNAME_CATEGORIES) && !this.IsNewTSREntry) == false)
                    return;
            }
            string message = string.Empty;
            switch (Name)
            {
                //if the user choose TSR category for TSR entry, the action will be failed with the warning message
                case OUTLOOK_PROPERTYNAME_CATEGORIES:
                    try
                    {
                        if (Core.OutlookHelper.CheckInvalidTSRCategory(CurrentItem.Categories))
                        {
                            CurrentItem.Categories = Core.OutlookHelper.SetTSRCategory(CurrentItem.Categories, TSREntry.Status);

                            string msg = Core.ResourceManager.GetResourceString("CanNotAddTSRCategory", "Cannot change TSR category");
                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                MessageSummary = msg,
                                Priority = 0
                            });
                            MessageBox.Show(msg);
                        }
                    }
                    catch (System.Exception ex)
                    {
                        TSR.Core.Logging.LoggingHandler.LogError(ex);
                    }

                    break;

                //If appointment is changed to recurring make sure, 
                //'SubmitButton' is refreshed to make sure, for series recurring it remains disabled                    
                case OUTLOOK_PROPERTYNAME_ISRECURRING:
                    //if (m_Appointment.IsRecurring)
                    //{
                    //This will enforce SubmitButton_getEnable(Office.IRibbonControl control) event to fire in ribbon.cs file
                    if ((TSREntry.IsRecurring) && (!CurrentItem.IsRecurring))
                    {
                        TimeEntry te = null;
                        try
                        {
                            te = Core.TSRFacade.GetTimeEntryForRecurringAppointment(CurrentItem.EntryID, CurrentItem.Start, CurrentItem.End, true, false);
                        }
                        catch (System.Exception ex)
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                            message = TSR.Core.ResourceManager.GetResourceString("ErrorGettingTimeEntryForRecurringAppointment", "Error getting time entry for Recurring Appointment");
                            MessageBox.Show(message, TSR.Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (te != null)
                        {
                            m_TSREntry = te;
                        }
                        TSREntry.IsRecurring = false;
                        PrepareRibbonCombos();
                    }
                    else if ((!TSREntry.IsRecurring) && (CurrentItem.IsRecurring))
                    {
                        SetTSRItem();
                        IsConvertToRecurring = true;
                    }

                    RaiseInvalidateControl(TSRRibbon.TSRRIBBON_ITEM_ORGANIZATION_DROPDOWN_ID);
                    RaiseInvalidateControl(TSRRibbon.TSRRIBBON_ITEM_PROJECT_DROPDOWN_ID);
                    RaiseInvalidateControl(TSRRibbon.TSRRIBBON_ITEM_ACTIVITY_DROPDOWN_ID);

                    RaiseInvalidateControl("SubmitButton");

                    break;
            }
        }

        /// <summary>
        /// Outlook appointment is saved, only then this event is raised and called
        /// </summary>
        /// <param name="Cancel"></param>
        void m_Appointment_Write(ref bool Cancel)
        {
            if (TSREntry == null)
                return;

            if (!TSREntry.IsChangeAllowed() && IsChangedAppointment())
            {
                if (!this.m_IsSubmitRecurringAppointments)
                {
                    string msg = Core.ResourceManager.GetResourceString("ImpossibleChangingTimeEntryMessage", "This Time Entry is impossible to change.");
                    msg += Environment.NewLine + Core.ResourceManager.GetResourceString("CauseOfTimeEntryIsImpossibleToChange", "Because its status is ") + TSREntry.Status.ToString();
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = msg,
                        Priority = 0
                    });
                    MessageBox.Show(msg);
                    Cancel = false;

                    if (m_Appointment.IsRecurring && !TSREntry.IsRecurring)
                        m_Appointment.ClearRecurrencePattern(); //convert to old appointment by removing recurring values

                    m_Appointment.Location = TSREntry.Location;
                    m_Appointment.AllDayEvent = false;
                    m_Appointment.StartInStartTimeZone = TSREntry.StartTimeStamp;
                    m_Appointment.EndInEndTimeZone = TSREntry.EndTimeStamp;
                    m_Appointment.Subject = TSREntry.Subject;
                    m_Appointment.Body = TSREntry.Body;
                    m_Appointment.AllDayEvent = m_IsDayEvent;
                    m_Appointment.Save();
                }
                else
                {
                    this.m_IsSubmitRecurringAppointments = false;
                    StartTimeRecurring = m_Appointment.StartInStartTimeZone;
                    EndTimeRecurring = m_Appointment.EndInEndTimeZone;
                }
                return;
            }
            //check whther it is a TSR appointment
            if (IsTSRItem)
            {
                //checks whther TSR Entry is valid. If not, either user will disable TSR or will not be able to save the appointment
                //or will make sure TSR entries are all valid
                if (!IsTSREntryValid() && !IsConvertToRecurring)
                {
                    string msg = Core.ResourceManager.GetResourceString("NeedToSelectTimeEntryDetailInformation", "Need to select Time Entry Detail information.");
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = msg,
                        Priority = 0
                    });

                    if (!Cancel)
                        MessageBox.Show(msg);

                    Cancel = true;
                    return;
                }

                //Check create TimeEntry in Lock Period
                bool inLockPeriod = false;
                if (CurrentItem.IsRecurring)
                {
                    if (Core.TSRFacade.IsLockPeriod(TSREntry.StartTimeStamp))
                        inLockPeriod = true;

                    if (!inLockPeriod)
                        inLockPeriod = IsListOfRecurringAppointmentsInLockPeriod();
                }

                if (!CurrentItem.IsRecurring)
                {
                    if (m_IsNewTSREntry && Core.TSRFacade.IsLockPeriod(m_Appointment.StartInStartTimeZone))
                        inLockPeriod = true;

                    if (!m_IsNewTSREntry && (Core.TSRFacade.IsLockPeriod(m_Appointment.StartInStartTimeZone) || Core.TSRFacade.IsLockPeriod(TSREntry.StartTimeStamp)))
                        inLockPeriod = true;
                }
                if (inLockPeriod)
                {
                    string msg = Core.ResourceHelper.LockedPeriodMessage;
                    TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        MessageSummary = msg,
                        Priority = 0
                    });

                    if (!Cancel)
                        MessageBox.Show(msg);

                    Cancel = true;

                    return;
                }

                var duration = (CurrentItem.End - CurrentItem.Start).TotalMinutes;
                if (!m_IsClickYesDurationWarning && IsDurationWarning(duration))
                {
                    var enforce = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_ENFORCE);
                    var setting = TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_DURATION_WARNING);
                    var message = String.Format(Core.ResourceManager.GetResourceString("DurationWarningMessage", "This appointment is longer than {0}. Do you want to continue?"), setting);
                    var messageenforce = String.Format(Core.ResourceManager.GetResourceString("DurationEnforceMessage", "This time entry exceeds {0}, and cannot be saved/submitted."), setting);
                    
                    if (m_IsClickNoDurationWarning)
                    {
                        if (enforce.ToLower() == "true")
                        {
                            MessageBox.Show(messageenforce, "TSR", MessageBoxButtons.OK);
                            m_IsClickNoDurationWarning = true;
                            m_IsClickYesDurationWarning = false;
                            Cancel = true;
                            return;
                        }
                        else
                        {
                            var result = MessageBox.Show(message, "TSR", MessageBoxButtons.YesNo);
                            if (result == DialogResult.No)
                            {
                                m_IsClickNoDurationWarning = true;
                                m_IsClickYesDurationWarning = false;
                                Cancel = true;
                                return;
                            }
                            else
                            {
                                m_IsClickNoDurationWarning = false;
                                m_IsClickYesDurationWarning = true;
                            }
                        }
                    }
                }

                TimeEntry teAsSaved = Core.TSRFacade.GetTimeEntryByTSRItemID(TSREntry.ID);
                if (teAsSaved != null)
                {
                    if ((teAsSaved.IsRecurring) && (!CurrentItem.IsRecurring))
                    {
                        string recurringRemovedWarning = Core.ResourceManager.GetResourceString("RecurringRemovedWarningMessage", "As recurring is removed from the appointment, all TSR entries that were not saved/submitted will be lost. Do you still want to save?");
                        string recurringRemovedWarningMsgCaption = Core.ResourceManager.GetResourceString("RecurringRemovedWarningMsgCaption", "Recurring removed");
                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = recurringRemovedWarningMsgCaption,
                            MessageDetail = recurringRemovedWarning,
                            Priority = 0
                        });
                        DialogResult dr = MessageBox.Show(recurringRemovedWarning, recurringRemovedWarningMsgCaption, MessageBoxButtons.YesNo);
                        if (dr == DialogResult.No)
                        {
                            Cancel = true;
                            return;
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(CurrentItem.EntryID))
                            {
                                try
                                {
                                    Core.TSRFacade.UpdateExistingTimeEntriesForRemovedRecurringAppointment(CurrentItem.EntryID, CurrentItem.Start, CurrentItem.End);
                                }
                                catch (System.Exception ex)
                                {
                                    TSR.Core.Logging.LoggingHandler.LogError(ex);
                                    string message =
                                        Core.ResourceManager.GetResourceString(
                                        "ErrorUpdatingExistingTimeEntriesForRemovedRecurringAppointment",
                                        "Error updating existing Time Entries for removed Recurring Appointment"
                                        );
                                    MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }

                            }
                            Core.TSRFacade.DeleteRecurringMasterByID(TSREntry.OutlookItemID);
                        }
                    }
                    else if ((!teAsSaved.IsRecurring) && (CurrentItem.IsRecurring))
                    {
                        if (m_IsSelection)
                        {
                            bool isSave = true;
                            if (!this.IsAllowTSRInfo)
                            {
                                if (m_TSREntry.IsChangeAllowed() && CurrentItem.IsRecurring &&
                                    CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                                {
                                    string strWarning = "Are you sure you want to enter TSR information on a recurring " +
                                                    "appointment? If you do, all future instances of the appoinment up to 12 " +
                                                    "months from now will be split into separate individual appointments and " +
                                                    "the recurring function from outlook will be removed";
                                    string message = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message", strWarning);
                                    string caption = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning when enter TSR info on a recurring appointment");

                                    DialogResult dr = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                                    if (dr == DialogResult.Yes)
                                    {
                                        isSave = this.IsAllowTSRInfo = true;
                                    }
                                    else
                                    {
                                        isSave = this.IsAllowTSRInfo = false;
                                        Cancel = true;
                                        return;
                                    }
                                }
                            }
                            if (isSave)
                            {
                                TimeEntry teTemp = Core.TSRFacade.GetTimeEntryByTSRItemID(m_TSREntry.ID);
                                if (teTemp != null && teTemp.LastModificationTime > m_TSREntry.LastModificationTime)
                                {
                                    MessageBox.Show(Core.ResourceManager.GetResourceString("TimeEntryIntegrityException", "The time entry cannot be saved because it was modified in another window"));
                                    return;
                                }

                                if (m_TSREntry.IsChangeAllowed() ||
                                        ((CurrentItem.IsRecurring) &&
                                        (CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)))
                                {
                                    if (!Core.OutlookHelper.IsAppointmentInGivenFolder_temp(CurrentItem, Core.OutlookHelper.UserSelectedAppointmentFolderForSync))
                                    //if (!Core.OutlookHelper.IsAppointmentInGivenFolder(CurrentItem))
                                    {
                                        string AppointmentInNotSelectedFolderForSyncMsg = Core.ResourceManager.GetResourceString("AppointmentInNotSelectedFolderForSyncMsg", "Appointment is not in selected folder for synchronization. Please change the appointment folder in Settings before synchronizing this Time Entry");
                                        string AppointmentInNotSelectedFolderForSyncMsgCaption = Core.ResourceManager.GetResourceString("AppointmentInNotSelectedFolderForSyncMsgCaption", "TSR Time Entry Appointment Folder");
                                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                        {
                                            LoggingTime = DateTime.Now,
                                            CreatedTimeStamp = DateTime.Now,
                                            SessionID = string.Empty,
                                            MessageSummary = AppointmentInNotSelectedFolderForSyncMsgCaption,
                                            MessageDetail = AppointmentInNotSelectedFolderForSyncMsg,
                                            Priority = 0
                                        });
                                        MessageBox.Show(AppointmentInNotSelectedFolderForSyncMsg, AppointmentInNotSelectedFolderForSyncMsgCaption);
                                    }
                                    SaveTimeEntry(m_TSREntry.Status);
                                }
                                else
                                {
                                    //added by tsrdev2 - 25 Nov 2012
                                    //fixbug: meeting appointment (CurrentItem) auto changed EntryID
                                    //when the Accept button is clicked.
                                    if (!TSREntry.OutlookItemID.Equals(CurrentItem.EntryID, StringComparison.OrdinalIgnoreCase))
                                    {
                                        TSREntry.SetOutlookItem(CurrentItem.EntryID);
                                        Core.TSRFacade.UpdateTimeEntry(TSREntry);

                                        if (TSR.Core.TSRFacade.GetExchangeMode())
                                        {
                                            TimeEntry_OutlookAppointment tmp = new TimeEntry_OutlookAppointment();
                                            tmp.TimeEntryID = TSREntry.ID;
                                            tmp.OutlookItemID = CurrentItem.EntryID;

                                            tmp.CalendarID = Core.OutlookHelper.GetCalendarFolderIDByAppointmentItem(CurrentItem);

                                            Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(tmp);
                                        }
                                    }
                                }
                            }
                            // Unhook events from the window
                            m_Appointment.Write -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
                            m_Appointment.PropertyChange -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);
                            m_Appointment.BeforeDelete -= new ItemEvents_10_BeforeDeleteEventHandler(m_Appointment_BeforeDelete);
                        }
                    }
                }
                //global var for this class - later on, just to be sure that Appointment was saved
                AppointmentSaved = true;
                //IsConvertToRecurring = false;
            }
            else if (TSREntry != null)
            {
                /// Need to delete TSR Information in the system
                /// Scenario it was a TSR Entry earlier and hence we have a TSR Entry for this appointment
                /// this entry will cause problem while loading next time.
            }
        }

        //added by tsrdev2
        //Feature 233: Deletion of un-submitted entries via Outlook
        //Des: Time entry will be deleted when opening appointment and click on Delete ribbon
        void m_Appointment_BeforeDelete(object Item, ref bool Cancel)
        {
            AppointmentItem appToBeDeleted = Item as AppointmentItem;
            if (appToBeDeleted == null)
                return;
            TimeEntry teTemp = Core.TSRFacade.GetTimeEntryByOutlookItemID(appToBeDeleted.EntryID);
            if (teTemp == null)
                return;


            TimeEntry teAsSaved = Core.TSRFacade.GetTimeEntryByTSRItemID(TSREntry.ID);
            if (teAsSaved != null)
            {
                //Only confirm when the time entry is allow change.
                if (teAsSaved.IsChangeAllowed())
                {
                    if (MessageBox.Show(Core.ResourceManager.GetResourceString("DeletionUnSubmittedEntryMessageConfirm", "Do you want to delete this entry") + "?",
                              Core.ResourceManager.GetResourceString("DeletionUnSubmittedEntry_Caption", "Delete un-submitted entry"), MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        ExpenseSheet sheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(teAsSaved.ID);
                        if (sheet != null)
                        {
                            //can not delete a time entry with expenses on
                            MessageBox.Show(Core.ResourceManager.GetResourceString("TimeSheetDeleteFailureMessageBecauseExpenses", "Time entries  with expenses cannot be deleted"), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Cancel = true;
                            return;
                        }
                        try
                        {
                            //Delete the time entry and appointment
                            bool b = Core.TSRFacade.DeleteTimeEntry(TSREntry);

                            if (b) Cancel = true;
                        }
                        catch (System.Exception ex)
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                            MessageBox.Show(ex.Message, TSR.Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Cancel = true;
                        }
                    }
                    else
                    {
                        //time entry and appointment will NOT be deleted
                        Cancel = true;
                        return;
                    }
                }
                else
                {
                    //This appointment will be deleted as normal, but the time entry will NOT
                }
            }
        }

        /// <summary>
        /// Method to check whther TSR entry was valid or not. At least basic information must be entered
        /// </summary>
        /// <param name="te"></param>
        /// <returns></returns>
        public bool IsTSREntryValid()
        {
            if (Organizations.FindByOrganizationID(OrganizationID).ID == Core.Constants.DEFAULT_SELECTION_VALUE_INT ||
                Projects.FindByProjectID(ProjectID).ID == Core.Constants.DEFAULT_SELECTION_VALUE_INT ||
                Activities.FindByActivityID(ActivityID).ID == Core.Constants.DEFAULT_SELECTION_VALUE_INT)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Method where time entry is saved
        /// </summary>
        public void SaveTimeEntry()
        {
            if (CurrentItem.IsRecurring)
            {
                switch (CurrentItem.RecurrenceState)
                {
                    case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster: //series update
                        RecurringMaster rm;
                        try
                        {
                            rm = Core.TSRFacade.GetRecurringMasterByOutlookEntryID(CurrentItem.EntryID);
                        }
                        catch (System.Exception ex)
                        {
                            TSR.Core.Logging.LoggingHandler.LogError(ex);
                            string message = Core.ResourceManager.GetResourceString("ErrorGettingRecurringMaster",
                                "Error getting Recurring Master");

                            MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (rm == null)
                        {
                            rm = new RecurringMaster();
                            rm.ID = CurrentItem.EntryID;
                            try
                            {
                                //it is possible that a normal tsr
                                if (Core.TSRFacade.GetTimeEntryByTSRItemID(TSREntry.ID) != null)
                                {
                                    if (CurrentItem.GetRecurrencePattern() != null)
                                    {
                                        if (CurrentItem.GetRecurrencePattern().GetOccurrence(TSREntry.StartTimeStamp) != null)
                                        {
                                            TSREntry.IsRecurring = true;
                                            Core.TSRFacade.UpdateTimeEntry(TSREntry);
                                        }
                                        else
                                        {
                                            Core.OutlookHelper.CreateNewTimeEntryAppointment(TSREntry);
                                        }
                                    }
                                }
                            }
                            catch (System.Exception ex)
                            {
                                TSR.Core.Logging.LoggingHandler.LogError(ex);
                                MessageBox.Show(ex.Message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                        //When a recurring appointment's series is opened and subject/body was changed
                        // then rule is it updates exception appointments' subject/body, if it did not change these itself. 
                        //This method [UpdateExistingRecrruingTSREntriesForSeriesUpdate] handles this issue
                        if ((rm.Subject != CurrentItem.Subject) || (rm.Body != CurrentItem.Body) || (rm.Location != CurrentItem.Location))
                        {
                            try
                            {
                                Core.TSRFacade.UpdateExistingRecrruingTSREntriesForSeriesUpdate(CurrentItem.EntryID, rm.Subject, rm.Body, rm.Location, CurrentItem.Subject, CurrentItem.Body, CurrentItem.Location);
                            }
                            catch (System.Exception ex)
                            {
                                TSR.Core.Logging.LoggingHandler.LogError(ex);
                                string message = Core.ResourceManager.GetResourceString("ErrorUpdatingRecurringTSREntries",
                                    "Error updating Recurring TSREntries");
                                MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        rm.Subject = CurrentItem.Subject;
                        rm.Body = CurrentItem.Body;
                        rm.Location = CurrentItem.Location;
                        if ((rm.Start != CurrentItem.GetRecurrencePattern().PatternStartDate)
                            || (rm.End != CurrentItem.GetRecurrencePattern().PatternEndDate))
                        {
                            try
                            {
                                Core.TSRFacade.SetExistingRecrruingTSREntriesIntoOrphans(CurrentItem.EntryID);
                            }
                            catch (System.Exception ex)
                            {
                                TSR.Core.Logging.LoggingHandler.LogError(ex);
                                string message = Core.ResourceManager.GetResourceString("ErrorUpdatingRecurringTSREntriesIntoOrphans",
                                  "Error setting existing Recurring TSREntries into Orphans");
                                MessageBox.Show(message, Core.ResourceManager.GetResourceString("Error", "Error"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        rm.Start = CurrentItem.GetRecurrencePattern().PatternStartDate; // CurrentItem.Start;
                        rm.End = CurrentItem.GetRecurrencePattern().PatternEndDate;//CurrentItem.End;
                        rm.OrganizationID = TSREntry.OrganizationID;
                        rm.ProjectID = TSREntry.ProjectID;
                        rm.ActivityID = TSREntry.ActivityID;
                        Core.TSRFacade.UpdateRecurringMaster(rm);
                        NotifyAppointmentObservers();
                        return;

                    case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptOccurrence:
                    case Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptException:
                        //if (TSREntry.Status == TSR.Core.UserAgentService.StatusEnum.PendingSubmission)
                        //{
                        //    if ((rm.Subject == TSREntry.Subject) && (rm.Body == TSREntry.Body)
                        //        && (rm.OrganizationID == TSREntry.OrganizationID)
                        //        && (rm.ProjectID == TSREntry.ProjectID)
                        //        && (rm.ActivityID == TSREntry.ActivityID)
                        //        && (rm.Start == TSREntry.StartTimeStamp)
                        //        && (rm.End == TSREntry.EndTimeStamp)
                        //        && (string.IsNullOrEmpty(TSREntry.Message)))
                        //        return;
                        //}
                        TSREntry.IsRecurring = true;
                        break;
                }
            }
            else
                TSREntry.IsRecurring = false;

            //control CurrentItem.Location in outlook in C#
            //gets subject, body, start and end time from current outlook appointment
            TSREntry.Subject = CurrentItem.Subject;
            TSREntry.Body = CurrentItem.Body;
            TSREntry.Location = CurrentItem.Location;
            TSREntry.StartTimeStamp = CurrentItem.Start;
            TSREntry.EndTimeStamp = CurrentItem.End;
            TSREntry.LastModificationTime = CurrentItem.LastModificationTime;

            //update time entry
            Core.TSRFacade.UpdateTimeEntry(TSREntry);

            if (TSREntry.OLAppointmentItem != null && !TSREntry.OLAppointmentItem.IsRecurring)
            {
                TSREntry.OLAppointmentItem.Categories = Core.OutlookHelper.SetTSRCategory(TSREntry.OLAppointmentItem.Categories, TSREntry.Status);
                TSREntry.OLAppointmentItem.Save();
            }

            NotifyAppointmentObservers();
        }

        /// <summary>
        /// Method where time entry is saved
        /// </summary>
        public void SaveTimeEntry(Core.UserAgentService.StatusEnum status)
        {
            if (CurrentItem.IsRecurring)
            {
                switch (CurrentItem.RecurrenceState)
                {
                    case OlRecurrenceState.olApptMaster:
                        SaveTimeEntryOfRecurringAppointmentSeries(status);
                        return;
                    case OlRecurrenceState.olApptOccurrence:
                    case OlRecurrenceState.olApptException:
                        if (IsInspector)
                        {
                            ThisAddIn.recurringSeriesEntryID = CurrentItem.EntryID;
                            ThisAddIn.occurrenceStartTime = CurrentItem.Start;
                        }
                        break;
                }
            }
            TSREntry.IsRecurring = false;

            //control CurrentItem.Location in outlook in C#
            //gets subject, body, start and end time from current outlook appointment
            TSREntry.Subject = CurrentItem.Subject;
            TSREntry.Body = CurrentItem.Body;
            TSREntry.Location = CurrentItem.Location;
            TSREntry.StartTimeStamp = CurrentItem.Start;
            TSREntry.EndTimeStamp = CurrentItem.End;
            TSREntry.LastModificationTime = CurrentItem.LastModificationTime;
            TSREntry.Status = status;

            if (CurrentItem.RecurrenceState == OlRecurrenceState.olApptOccurrence || CurrentItem.RecurrenceState == OlRecurrenceState.olApptException)
            {
                Core.OutlookHelper.CreateNewTimeEntryAppointment(TSREntry);
                this.IsNewAppointmentFromRecurringInstance = true;
            }
            else
            {
                //added by tsrdev - 24 Nov 2012            
                //fixbug: meeting appointment (CurrentItem) auto changed EntryID
                //when the Accept button is clicked.
                if (!TSREntry.OutlookItemID.Equals(CurrentItem.EntryID, StringComparison.OrdinalIgnoreCase))
                {
                    TSREntry.SetOutlookItem(CurrentItem.EntryID);
                }
            }

            if (TSREntry.OLAppointmentItem != null && !TSREntry.OLAppointmentItem.IsRecurring)
            {
                TSREntry.OLAppointmentItem.Categories = Core.OutlookHelper.SetTSRCategory(TSREntry.OLAppointmentItem.Categories, status);
                TSREntry.OLAppointmentItem.Save();
            }

            Core.TSRFacade.UpdateTimeEntry(TSREntry);

            if (TSR.Core.TSRFacade.GetExchangeMode())
            {
                TimeEntry_OutlookAppointment tmp = new TimeEntry_OutlookAppointment();
                tmp.TimeEntryID = TSREntry.ID;
                //tmp.OutlookItemID = CurrentItem.EntryID;

                if (TSREntry.OLAppointmentItem != null)
                {
                    tmp.OutlookItemID = TSREntry.OLAppointmentItem.EntryID;

                    tmp.CalendarID = Core.OutlookHelper.GetCalendarFolderIDByAppointmentItem(TSREntry.OLAppointmentItem);
                    Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(tmp);
                }
                else
                {
                    //error wtf 
                }
            }

            if (m_IsSelection &&
                (CurrentItem.RecurrenceState == OlRecurrenceState.olApptOccurrence || CurrentItem.RecurrenceState == OlRecurrenceState.olApptException))
            {
                CurrentItem.Delete();
            }

            NotifyAppointmentObservers();
        }

        private bool IsDurationWarning(double duration)
        {
            return Core.TSRFacade.IsDurationWarning(duration);
        }

        private bool IsListOfRecurringAppointmentsInLockPeriod()
        {
            DateTime startTime, endTime, limitDateStart, limitDateEnd;
            bool bPatternIsNoEndDate = false;
            RecurrencePattern recurrPattern = null;
            try
            {
                recurrPattern = CurrentItem.GetRecurrencePattern();
            }
            catch
            {
                return false;
            }
            if (recurrPattern == null)
                return false;

            startTime = recurrPattern.PatternStartDate;
            bPatternIsNoEndDate = recurrPattern.NoEndDate;
            endTime = recurrPattern.PatternEndDate;

            const int limitMonthInPast = 12;
            const int limitMonthInFuture = 12;
            limitDateStart = DateTime.Now.AddMonths(-limitMonthInPast); //after before (s) months
            limitDateEnd = DateTime.Now.AddMonths(limitMonthInFuture); //after now (s) months

            if (startTime.Date > limitDateEnd.Date || endTime.Date < limitDateStart.Date)
                return false;

            if (startTime.Date < limitDateStart.Date)
            {
                //if recurring appointment has instances in the past they will not be touched 
                //but instead have a new end-date corresponding to the last before todays date                    
                AppointmentItem pastApp = CurrentItem.Copy() as Outlook.AppointmentItem;
                Outlook.RecurrencePattern pastRecurrPattern = pastApp.GetRecurrencePattern();

                if (pastRecurrPattern != null)
                {
                    pastRecurrPattern.PatternEndDate = limitDateStart.AddDays(-1);
                }
                //final operation
                startTime = limitDateStart.Date;
            }

            if (bPatternIsNoEndDate || (endTime.Date > limitDateEnd.Date))
            {
                //Instances 12 months+1 day and ahead will be generated as a new
                //recurring appointment starting the first day after the last individually
                //created appointment and have the enddate from the original recurrence.
                //AppointmentItem futureApp = CurrentItem.Copy() as Outlook.AppointmentItem;
                //Outlook.RecurrencePattern futureRecurrPattern = futureApp.GetRecurrencePattern();
                //if (futureRecurrPattern != null)
                //{
                //    futureRecurrPattern.PatternStartDate = limitDateEnd.Date.AddDays(1);
                //    if (bPatternIsNoEndDate) //no end date
                //        futureRecurrPattern.NoEndDate = true;
                //    else futureRecurrPattern.PatternEndDate = endTime;
                //}

                //final operation
                endTime = limitDateEnd.Date;
                //recurrPattern.PatternEndDate = limitTime.Date;
                //CurrentItem.Save();
            }

            endTime = endTime.AddDays(1);
            DateTime date = startTime;

            //AppointmentItem copyAppointmentItem = CurrentItem.Copy() as Outlook.AppointmentItem;
            //copyAppointmentItem.Save();

            AppointmentItem copyAppointmentItem = CurrentItem as Outlook.AppointmentItem;
            var recurrPattern2 = copyAppointmentItem.GetRecurrencePattern();

            var result = false;
            while (date < endTime) // this huge loop can be changed by retrieving information from recurrence pattern
            {
                #region Create time entry from the Occurrence
                date = new DateTime(date.Year, date.Month, date.Day, CurrentItem.Start.Hour, CurrentItem.Start.Minute, CurrentItem.Start.Second);
                Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence = null;

                try //don't remove this try-catch statement, it's very importance
                {
                    bool isException = false;
                    if (recurrPattern != null)
                    {
                        if (recurrPattern.Exceptions != null)
                        {
                            foreach (Microsoft.Office.Interop.Outlook.Exception exceptionRecurrence in recurrPattern.Exceptions)
                            {
                                try
                                {
                                    if (!exceptionRecurrence.Deleted && exceptionRecurrence.AppointmentItem.Start.Date.Equals(date.Date))
                                    {
                                        isException = true;
                                        appointmentOccurrence = exceptionRecurrence.AppointmentItem;
                                        break;
                                    }
                                }
                                catch //(Exception ex)
                                {
                                    //TSR.Core.Logging.LoggingHandler.LogError(ex);
                                    continue;
                                }
                            }
                        }
                        if (!isException)
                        {
                            appointmentOccurrence = recurrPattern2.GetOccurrence(date);
                        }
                    }
                    if (appointmentOccurrence != null)
                    {
                        if (Core.TSRFacade.IsLockPeriod(appointmentOccurrence.Start))
                        {
                            result = true;
                        }
                        //appointmentOccurrence.Delete();
                    }
                }
                catch (System.Exception ex)
                {
                    //if not gets occurence for the date
                }
                finally
                {
                    date = date.AddDays(1);
                }

                #endregion

            }

            //update time entry
            //var timeEntry = Core.TSRFacade.GetTimeEntryByOutlookItemID(CurrentItem.EntryID);
            //Core.OutlookHelper.CreateNewTimeEntryAppointmentForRecurring(timeEntry);

            return result;
        }

        private void SaveTimeEntryOfRecurringAppointmentSeries(Core.UserAgentService.StatusEnum status)
        {
            Guid currentTimeEntryID = TSREntry.ID;

            //get expense of current time entry for recurring
            if (TSREntry.ExpenseSheet == null)
                TSREntry.ExpenseSheet = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(TSREntry.ID);

            DateTime startTime, endTime, limitDateStart, limitDateEnd;
            bool bPatternIsNoEndDate = false;
            Microsoft.Office.Interop.Outlook.RecurrencePattern recurrPattern = null;
            try
            {
                recurrPattern = CurrentItem.GetRecurrencePattern();
            }
            catch //(Exception ex)
            {
                return;
            }
            if (recurrPattern == null)
                return;

            startTime = recurrPattern.PatternStartDate;
            bPatternIsNoEndDate = recurrPattern.NoEndDate;
            endTime = recurrPattern.PatternEndDate;

            const int limitMonthInPast = 12;
            const int limitMonthInFuture = 12;
            limitDateStart = DateTime.Now.AddMonths(-limitMonthInPast); //after before (s) months
            limitDateEnd = DateTime.Now.AddMonths(limitMonthInFuture); //after now (s) months

            if (startTime.Date > limitDateEnd.Date || endTime.Date < limitDateStart.Date)
            {
                //Message: Can not enter TSR info in a recurring appointment because more than 12 months from now
                //then nothing to do
                return;
            }

            List<Outlook.Exception> lstExeption = new List<Outlook.Exception>();
            List<Outlook.AppointmentItem> lstAppOfExeption = new List<Outlook.AppointmentItem>();

            if (startTime.Date < limitDateStart.Date)
            {
                //if recurring appointment has instances in the past they will not be touched 
                //but instead have a new end-date corresponding to the last before todays date                    
                AppointmentItem pastApp = CurrentItem.Copy() as Outlook.AppointmentItem;
                Outlook.RecurrencePattern pastRecurrPattern = pastApp.GetRecurrencePattern();

                if (pastRecurrPattern != null)
                {
                    try
                    {
                        if (pastRecurrPattern.Exceptions != null && pastRecurrPattern.Exceptions.Count > 0)
                        {
                            foreach (Outlook.Exception oldException in pastRecurrPattern.Exceptions)
                            {
                                if (oldException.OriginalDate >= limitDateStart.Date)
                                    continue;
                                lstExeption.Add(oldException);
                                if (!oldException.Deleted) lstAppOfExeption.Add(oldException.AppointmentItem);
                                else lstAppOfExeption.Add(null);
                            }
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogUnhandledException(ex);
                    }
                    //pastRecurrPattern.PatternStartDate = startTime;
                    pastRecurrPattern.PatternEndDate = limitDateStart.AddDays(-1);
                }

                if (status != Core.UserAgentService.StatusEnum.PendingSubmission)
                    pastApp.Categories = Core.OutlookHelper.RemoveTSRCategory(pastApp.Categories, Core.UserAgentService.StatusEnum.PendingSubmission);
                pastApp.Categories = Core.OutlookHelper.RemoveTSRCategory(pastApp.Categories, status);
                pastApp.Save();

                //MessageBox.Show(pastApp.GetRecurrencePattern().Exceptions.Count.ToString());

                //release object
                pastRecurrPattern = null;

                if (lstExeption != null && lstExeption.Count > 0)
                {
                    for (int i = 0; i < lstExeption.Count; i++)
                    {
                        try
                        {
                            Outlook.RecurrencePattern newPattern = pastApp.GetRecurrencePattern();

                            DateTime exStart = lstExeption[i].OriginalDate;
                            if (lstExeption[i].Deleted)
                            {
                                exStart = new DateTime(exStart.Year, exStart.Month, exStart.Day,
                                    newPattern.StartTime.Hour, newPattern.StartTime.Minute, newPattern.StartTime.Second);
                            }
                            Outlook.AppointmentItem exInstance = newPattern.GetOccurrence(exStart) as Outlook.AppointmentItem;
                            if (exInstance != null)
                            {
                                if (lstExeption[i].Deleted)
                                {
                                    exInstance.Delete();
                                }
                                else
                                {
                                    exInstance.Start = lstAppOfExeption[i].Start;
                                    exInstance.End = lstAppOfExeption[i].End;
                                    exInstance.Subject = lstAppOfExeption[i].Subject;
                                    exInstance.Location = lstAppOfExeption[i].Location;
                                    exInstance.Body = lstAppOfExeption[i].Body;
                                    exInstance.Importance = lstAppOfExeption[i].Importance;
                                    exInstance.Save();
                                }
                            }
                            exInstance = null;
                            newPattern = null;
                        }
                        catch (System.Exception ex)
                        {
                            Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                    }
                }

                //release pastApp
                pastApp = null;
                //MessageBox.Show("Final: " + pastApp.GetRecurrencePattern().Exceptions.Count.ToString());

                //final operation
                startTime = limitDateStart.Date;
                //recurrPattern.PatternStartDate = DateTime.Now.Date;
                //CurrentItem.Save();
            }

            if (bPatternIsNoEndDate || (endTime.Date > limitDateEnd.Date))
            {
                //Instances 12 months+1 day and ahead will be generated as a new
                //recurring appointment starting the first day after the last individually
                //created appointment and have the enddate from the original recurrence.
                AppointmentItem futureApp = CurrentItem.Copy() as Outlook.AppointmentItem;
                Outlook.RecurrencePattern futureRecurrPattern = futureApp.GetRecurrencePattern();
                if (futureRecurrPattern != null)
                {
                    try
                    {
                        lstExeption.Clear();
                        lstAppOfExeption.Clear();
                        if (futureRecurrPattern.Exceptions != null && futureRecurrPattern.Exceptions.Count > 0)
                        {
                            foreach (Outlook.Exception oldException in futureRecurrPattern.Exceptions)
                            {
                                if (oldException.OriginalDate <= limitDateEnd.Date)
                                    continue;
                                lstExeption.Add(oldException);
                                if (!oldException.Deleted) lstAppOfExeption.Add(oldException.AppointmentItem);
                                else lstAppOfExeption.Add(null);
                            }
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Core.Logging.LoggingHandler.LogUnhandledException(ex);
                    }

                    futureRecurrPattern.PatternStartDate = limitDateEnd.Date.AddDays(1);
                    if (bPatternIsNoEndDate) //no end date
                        futureRecurrPattern.NoEndDate = true;
                    else futureRecurrPattern.PatternEndDate = endTime;
                }

                if (status != Core.UserAgentService.StatusEnum.PendingSubmission)
                    futureApp.Categories = Core.OutlookHelper.RemoveTSRCategory(futureApp.Categories, Core.UserAgentService.StatusEnum.PendingSubmission);
                futureApp.Categories = Core.OutlookHelper.RemoveTSRCategory(futureApp.Categories, status);
                futureApp.Save();

                futureRecurrPattern = null;
                if (lstExeption != null && lstExeption.Count > 0)
                {
                    for (int i = 0; i < lstExeption.Count; i++)
                    {
                        try
                        {
                            Outlook.RecurrencePattern newPattern = futureApp.GetRecurrencePattern();

                            DateTime exStart = lstExeption[i].OriginalDate;
                            if (lstExeption[i].Deleted)
                            {
                                exStart = new DateTime(exStart.Year, exStart.Month, exStart.Day,
                                    newPattern.StartTime.Hour, newPattern.StartTime.Minute, newPattern.StartTime.Second);
                            }
                            Outlook.AppointmentItem exInstance = newPattern.GetOccurrence(exStart) as Outlook.AppointmentItem;
                            if (exInstance != null)
                            {
                                if (lstExeption[i].Deleted)
                                {
                                    exInstance.Delete();
                                }
                                else
                                {
                                    exInstance.Start = lstAppOfExeption[i].Start;
                                    exInstance.End = lstAppOfExeption[i].End;
                                    exInstance.Subject = lstAppOfExeption[i].Subject;
                                    exInstance.Location = lstAppOfExeption[i].Location;
                                    exInstance.Body = lstAppOfExeption[i].Body;
                                    exInstance.Importance = lstAppOfExeption[i].Importance;
                                    exInstance.Save();
                                }
                            }
                            exInstance = null;
                            newPattern = null;
                        }
                        catch (System.Exception ex)
                        {
                            Core.Logging.LoggingHandler.LogUnhandledException(ex);
                        }
                    }
                }
                futureApp = null;
                //final operation
                endTime = limitDateEnd.Date;
                //recurrPattern.PatternEndDate = limitTime.Date;
                //CurrentItem.Save();
            }

            endTime = endTime.AddDays(1);
            DateTime date = startTime;

            //if(m_IsSelection)
            CurrentItem.Save();

            while (date < endTime) // this huge loop can be changed by retrieving information from recurrence pattern
            {
                #region Create time entry from the Occurrence
                date = new DateTime(date.Year, date.Month, date.Day, CurrentItem.Start.Hour, CurrentItem.Start.Minute, CurrentItem.Start.Second);
                Microsoft.Office.Interop.Outlook.AppointmentItem appointmentOccurrence = null;

                try //don't remove this try-catch statement, it's very importance
                {
                    bool isException = false;
                    if (recurrPattern != null)
                    {
                        if (recurrPattern.Exceptions != null)
                        {
                            foreach (Microsoft.Office.Interop.Outlook.Exception exceptionRecurrence in recurrPattern.Exceptions)
                            {
                                try
                                {
                                    if (!exceptionRecurrence.Deleted && exceptionRecurrence.AppointmentItem.Start.Date.Equals(date.Date))
                                    {
                                        isException = true;
                                        appointmentOccurrence = exceptionRecurrence.AppointmentItem;
                                        break;
                                    }
                                }
                                catch //(Exception ex)
                                {
                                    //TSR.Core.Logging.LoggingHandler.LogError(ex);
                                    continue;
                                }
                            }
                        }
                        if (!isException)
                        {
                            appointmentOccurrence = recurrPattern.GetOccurrence(date);
                        }
                    }
                    if (appointmentOccurrence != null)
                    {
                        TSREntry.ID = Guid.NewGuid();
                        //variable to check modified  starttime and endtime of recurring
                        if (StartTimeRecurring == null)
                            StartTimeRecurring = m_Appointment.StartInStartTimeZone;
                        if (EndTimeRecurring == null)
                            EndTimeRecurring = m_Appointment.EndInEndTimeZone;

                        //control CurrentItem.Location in outlook in C#
                        //gets subject, body, start and end time from current outlook appointment
                        if (appointmentOccurrence.Subject == null)
                            TSREntry.Subject = CurrentItem.Subject;
                        else
                            TSREntry.Subject = appointmentOccurrence.Subject;

                        if (appointmentOccurrence.Location == null)
                            TSREntry.Location = CurrentItem.Location;
                        else
                            TSREntry.Location = appointmentOccurrence.Location;

                        if (appointmentOccurrence.Body == null)
                            TSREntry.Body = CurrentItem.Body;
                        else
                            TSREntry.Body = appointmentOccurrence.Body;

                        //TSREntry.Body = appointmentOccurrence.Body;
                        //TSREntry.Location = appointmentOccurrence.Location;
                        TSREntry.StartTimeStamp = appointmentOccurrence.Start;
                        TSREntry.EndTimeStamp = appointmentOccurrence.End;
                        TSREntry.LastModificationTime = appointmentOccurrence.LastModificationTime;

                        status = TSR.Core.UserAgentService.StatusEnum.PendingSubmission;//Alway is pending submission
                        TSREntry.Status = status;

                        //create new appointment of time entry
                        Core.OutlookHelper.CreateNewTimeEntryAppointmentForRecurring(TSREntry);

                        this.IsNewAppointmentFromRecurringInstance = true;

                        if (TSREntry.OLAppointmentItem != null)
                        {
                            TSREntry.OLAppointmentItem.Categories = Core.OutlookHelper.SetTSRCategory(TSREntry.OLAppointmentItem.Categories, status);
                            TSREntry.OLAppointmentItem.Save();
                        }

                        //update time entry
                        Core.TSRFacade.UpdateTimeEntryForRecurring(TSREntry);

                        if (TSR.Core.TSRFacade.GetExchangeMode())
                        {
                            TimeEntry_OutlookAppointment tmp = new TimeEntry_OutlookAppointment();
                            tmp.TimeEntryID = TSREntry.ID;
                            tmp.OutlookItemID = TSREntry.OLAppointmentItem.EntryID;

                            tmp.CalendarID = Core.OutlookHelper.GetCalendarFolderIDByAppointmentItem(CurrentItem);

                            Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(tmp);
                        }
                        //release appointment object
                        appointmentOccurrence = null;

                        NotifyAppointmentObservers();
                    }
                }
                catch (System.Exception ex)
                {
                    //if not gets occurence for the date
                }
                finally
                {
                    date = date.AddDays(1);
                }
                #endregion
            }
            //delete expense before delete current time entry
            ExpenseSheet expenseOfCurrentTimeEntry = Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(currentTimeEntryID);
            if (expenseOfCurrentTimeEntry != null)
            {
                expenseOfCurrentTimeEntry.IsDeleted = true;
                if (expenseOfCurrentTimeEntry.ExpenseEntryListLocal != null && expenseOfCurrentTimeEntry.ExpenseEntryListLocal.Count > 0)
                {
                    foreach (var entry in expenseOfCurrentTimeEntry.ExpenseEntryListLocal)
                    {
                        entry.RowState = Core.UserAgentService.BaseBusinessEntity.RowStateEnum.DeletedRow;
                    }
                }
                //delete expense
                Core.TSRExpenseFacade.UpdateExpenseSheet(expenseOfCurrentTimeEntry);
            }

            //final handle: save current recurring appointment with no instance    
            if (m_IsInspector)
            {
                //DateTime deleteDateTime = new DateTime(recurrPattern.PatternStartDate.Year, recurrPattern.PatternStartDate.Month, recurrPattern.PatternStartDate.Day,
                //                               CurrentItem.Start.Hour, CurrentItem.Start.Minute, CurrentItem.Start.Second);
                //recurrPattern.PatternEndDate = recurrPattern.PatternStartDate;


                //Save current recurring appoitment with End date the same start date
                //need only apply to OUA 2010
                //m_Appointment.Write -= new ItemEvents_10_WriteEventHandler(m_Appointment_Write);
                this.m_IsSubmitRecurringAppointments = true;
                CurrentItem.ClearRecurrencePattern();
                if (IsInspector) CurrentItem.Categories = Core.OutlookHelper.SetTSRCategory(CurrentItem.Categories, status);
                this.m_IsSubmitRecurringAppointments = true;
                CurrentItem.Save();

                ThisAddIn.recurringSeriesEntryID = CurrentItem.EntryID;
            }
            if (m_IsSelection)
            {
                try
                {
                    this.m_IsSubmitRecurringAppointments = true;
                    CurrentItem.ClearRecurrencePattern();
                    this.m_IsSubmitRecurringAppointments = true;
                    CurrentItem.Delete();
                }
                catch (System.Exception ex)
                {
                    //TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }

            //delete current time entry
            Core.TSRFacade.DeleteTimeEntryForRecurring(currentTimeEntryID);
        }

        private static void NotifyAppointmentObservers()
        {
            //time entry is changed, so inform other screens who might need this info to update their views.
            Core.AppointmentInformer appInformer = Core.AppointmentInformer.GetInstance();
            appInformer.NotifyAppointmentObservers(null);
        }

        private bool IsChangedAppointment()
        {
            //string str = "appointment :";
            //str += string.IsNullOrEmpty(m_Appointment.Location) ? "empty" : m_Appointment.Location;
            //str += string.IsNullOrEmpty(m_Appointment.Subject) ? "empty" : m_Appointment.Subject;
            //str += string.IsNullOrEmpty(m_Appointment.Body) ? "empty" : m_Appointment.Body;
            //str += m_Appointment.StartInStartTimeZone.ToString();
            //str += m_Appointment.EndInEndTimeZone.ToString();
            //str += m_Appointment.IsRecurring.ToString();

            //str += "\n TSR :";
            //str += string.IsNullOrEmpty(TSREntry.Location) ? "empty" : TSREntry.Location;
            //str += string.IsNullOrEmpty(TSREntry.Subject) ? "empty" : TSREntry.Subject;
            //str += string.IsNullOrEmpty(TSREntry.Body) ? "empty" : TSREntry.Body;
            //str += StartTimeRecurring.ToString();
            //str += EndTimeRecurring.ToString();
            //str += TSREntry.IsRecurring.ToString();

            //MessageBox.Show(str);

            if (StartTimeRecurring.HasValue && EndTimeRecurring.HasValue) //This case is recurrings submited
            {
                if (m_Appointment.Location == TSREntry.Location &&
                    m_Appointment.StartInStartTimeZone == StartTimeRecurring &&
                    m_Appointment.EndInEndTimeZone == EndTimeRecurring &&
                    m_Appointment.Subject == TSREntry.Subject &&
                    m_Appointment.Body == TSREntry.Body &&
                    m_Appointment.IsRecurring == TSREntry.IsRecurring)
                    return false;
                else
                    return true;
            }
            else
            {
                if (m_Appointment.Location == TSREntry.Location &&
                    m_Appointment.StartInStartTimeZone == TSREntry.StartTimeStamp &&
                    m_Appointment.EndInEndTimeZone == TSREntry.EndTimeStamp &&
                    m_Appointment.Subject == TSREntry.Subject &&
                    m_Appointment.Body == TSREntry.Body &&
                    m_Appointment.IsRecurring == TSREntry.IsRecurring)
                    return false;
                else
                    return true;
            }
        }
        #endregion


        #region Event Handlers

        /// <summary>
        /// Event Handler for the inspector close event.
        /// </summary>
        private void OutlookWindow_Close()
        {
            bool isSave = true;
            if (AppointmentSaved)
            {
                if (!this.IsAllowTSRInfo)
                {
                    if (m_TSREntry.IsChangeAllowed() && CurrentItem.IsRecurring &&
                        CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)
                    {
                        string strWarning = "Are you sure you want to enter TSR information on a recurring " +
                                        "appointment? If you do, all future instances of the appoinment up to 12 " +
                                        "months from now will be split into separate individual appointments and " +
                                        "the recurring function from outlook will be removed";
                        string message = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Message", strWarning);
                        string caption = Core.ResourceManager.GetResourceString("ButtonConfirm_TSRInfOnRecurringAppointment_Caption", "Warning when enter TSR info on a recurring appointment");

                        DialogResult dr = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);

                        if (dr == DialogResult.Yes)
                        {
                            isSave = this.IsAllowTSRInfo = true;
                        }
                        else
                            isSave = this.IsAllowTSRInfo = false;
                    }
                }
                if (isSave)
                {
                    //Feature 340
                    bool inLockPeriod = m_IsNewTSREntry && Core.TSRFacade.IsLockPeriod(m_Appointment.StartInStartTimeZone);
                    if (!inLockPeriod)
                    {
                        if (!m_IsNewTSREntry && (Core.TSRFacade.IsLockPeriod(m_Appointment.StartInStartTimeZone) || Core.TSRFacade.IsLockPeriod(TSREntry.StartTimeStamp)))
                            inLockPeriod = true;
                    }

                    if (inLockPeriod)
                    {
                        string msg = Core.ResourceHelper.LockedPeriodMessage;
                        TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                        {
                            LoggingTime = DateTime.Now,
                            CreatedTimeStamp = DateTime.Now,
                            SessionID = string.Empty,
                            MessageSummary = msg,
                            Priority = 0
                        });
                        MessageBox.Show(msg);

                        return;
                    }

                    TimeEntry teTemp = Core.TSRFacade.GetTimeEntryByTSRItemID(m_TSREntry.ID);
                    if (teTemp != null && teTemp.LastModificationTime > m_TSREntry.LastModificationTime)
                    {
                        MessageBox.Show(Core.ResourceManager.GetResourceString("TimeEntryIntegrityException", "The time entry cannot be saved because it was modified in another window"));
                        return;
                    }

                    if (m_TSREntry.IsChangeAllowed() ||
                            ((CurrentItem.IsRecurring) &&
                            (CurrentItem.RecurrenceState == Microsoft.Office.Interop.Outlook.OlRecurrenceState.olApptMaster)))
                    {
                        if (!Core.OutlookHelper.IsAppointmentInGivenFolder_temp(CurrentItem, Core.OutlookHelper.UserSelectedAppointmentFolderForSync))
                        //if (!Core.OutlookHelper.IsAppointmentInGivenFolder(CurrentItem))
                        {
                            string AppointmentInNotSelectedFolderForSyncMsg = Core.ResourceManager.GetResourceString("AppointmentInNotSelectedFolderForSyncMsg", "Appointment is not in selected folder for synchronization. Please change the appointment folder in Settings before synchronizing this Time Entry");
                            string AppointmentInNotSelectedFolderForSyncMsgCaption = Core.ResourceManager.GetResourceString("AppointmentInNotSelectedFolderForSyncMsgCaption", "TSR Time Entry Appointment Folder");
                            TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                            {
                                LoggingTime = DateTime.Now,
                                CreatedTimeStamp = DateTime.Now,
                                SessionID = string.Empty,
                                MessageSummary = AppointmentInNotSelectedFolderForSyncMsgCaption,
                                MessageDetail = AppointmentInNotSelectedFolderForSyncMsg,
                                Priority = 0
                            });
                            MessageBox.Show(AppointmentInNotSelectedFolderForSyncMsg, AppointmentInNotSelectedFolderForSyncMsgCaption);
                        }
                        SaveTimeEntry(m_TSREntry.Status);
                    }
                    else
                    {
                        //added by tsrdev2 - 25 Nov 2012
                        //fixbug: meeting appointment (CurrentItem) auto changed EntryID
                        //when the Accept button is clicked.
                        if (!this.IsNewAppointmentFromRecurringInstance && !TSREntry.OutlookItemID.Equals(CurrentItem.EntryID, StringComparison.OrdinalIgnoreCase))
                        {
                            TSREntry.SetOutlookItem(CurrentItem.EntryID);
                            Core.TSRFacade.UpdateTimeEntry(TSREntry);

                            if (TSR.Core.TSRFacade.GetExchangeMode())
                            {
                                TimeEntry_OutlookAppointment tmp = new TimeEntry_OutlookAppointment();
                                tmp.TimeEntryID = TSREntry.ID;
                                tmp.OutlookItemID = CurrentItem.EntryID;

                                tmp.CalendarID = Core.OutlookHelper.GetCalendarFolderIDByAppointmentItem(CurrentItem);

                                Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(tmp);
                            }
                        }
                    }
                }
            }
            if (!isSave)
            {
                m_TSREntry = null;
            }

            // Unhook events from the window
            m_Appointment.Write -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
            m_Appointment.PropertyChange -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);
            m_Appointment.BeforeDelete -= new ItemEvents_10_BeforeDeleteEventHandler(m_Appointment_BeforeDelete);

            ((Outlook.InspectorEvents_Event)m_Window).Close -= new Microsoft.Office.Interop.Outlook.InspectorEvents_CloseEventHandler(OutlookWindow_Close);


            // Raise the OutlookInspector close event
            if (Close != null)
            {
                Close(this, EventArgs.Empty);
            }

            if (m_Organizations != null) m_Organizations.Clear(); m_Organizations = null;
            if (m_Projects != null) m_Projects.Clear(); m_Projects = null;
            if (m_Activities != null) m_Activities.Clear(); m_Activities = null;

            m_TSREntry = null;
            m_Window = null;
            m_Appointment = null;
            lstWrite.Clear();

            // Calling GC.Collect in the Close() method does not release the item.
            GC.Collect();
            GC.WaitForPendingFinalizers();
            // A second call to GC.Collect() is required
            GC.Collect();
        }

        /// <summary>
        /// Apply for Selection, when selection is changed.
        /// </summary>
        public void LostForus()
        {
            // Unhook events from the window
            m_Appointment.Write -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_WriteEventHandler(m_Appointment_Write);
            m_Appointment.PropertyChange -= new Microsoft.Office.Interop.Outlook.ItemEvents_10_PropertyChangeEventHandler(m_Appointment_PropertyChange);

            m_TSREntry = null;
            m_Selection = null;
            m_Appointment = null;
            m_IsSelection = false;
            IsConvertToRecurring = false;

            if (m_Organizations != null) m_Organizations.Clear(); m_Organizations = null;
            if (m_Projects != null) m_Projects.Clear(); m_Projects = null;
            if (m_Activities != null) m_Activities.Clear(); m_Activities = null;

            // Calling GC.Collect in the Close() method does not release the item.
            GC.Collect();
            GC.WaitForPendingFinalizers();
            // A second call to GC.Collect() is required
            GC.Collect();
        }

        #endregion

        #region Methods
        private void RaiseInvalidateControl(string controlID)
        {
            if (InvalidateControl != null)
                InvalidateControl(this, new InvalidateEventArgs(controlID));

        }

        /// <summary>
        /// method to force outlook appointment so that it thinks 
        /// there has been a change and before closing the appointment, 
        /// it needs to be saved. and so, if this method is called whenever 
        /// user tries to close the appointment without saving it pops to 
        /// ask user to save the changes. It is useful when something is changed only in tsr entry, 
        /// but user also need to save the appointment
        /// </summary>
        public void ForceItemChange()
        {
            Outlook.UserProperty prop = CurrentItem.UserProperties[DUMMY_PROP_INDEX];
            if (prop == null)
                prop = CurrentItem.UserProperties.Add(DUMMY_PROP_NAME, Outlook.OlUserPropertyType.olText,
                    false, System.Reflection.Missing.Value);
            prop.Value = DUMMY_PROP_VALUE;
            prop.Delete();
        }

        public void SetUserRecurringProperty()
        {
            Outlook.UserProperty prop = CurrentItem.UserProperties[TSR_RECURRING_PROP_NAME];
            if (prop == null)
                prop = CurrentItem.UserProperties.Add(TSR_RECURRING_PROP_NAME, Outlook.OlUserPropertyType.olText,
                    false, System.Reflection.Missing.Value);
            prop.Value = TSR_RECURRING_PROP_VALUE;
        }
        public string GetUserRecurringProperty()
        {
            string result = string.Empty;
            Outlook.UserProperty prop = CurrentItem.UserProperties[TSR_RECURRING_PROP_NAME];
            if (prop != null)
            {
                result = prop.Value;
            }
            return result;
        }

        #endregion

        #region Properties

        /// <summary>
        /// The actual Outlook inspector window wrapped by this instance
        /// </summary>
        internal Outlook.Inspector Window
        {
            get { return m_Window; }
        }

        internal Outlook.Selection Selection
        {
            get { return m_Selection; }
        }

        /// <summary>
        /// The actual TSR Entry wrapped by this instance
        /// </summary>
        internal Entity.TimeEntry TSREntry
        {
            get { return m_TSREntry; }
        }

        internal Entity.ExpenseSheet TSRExpenseSheet
        {
            get
            {
                if (m_TSREntry == null) m_TSRExpenseSheet = null;
                else
                {
                    if (m_TSRExpenseSheet == null || !m_TSRExpenseSheet.TimeEntryID.Equals(m_TSREntry.ID))
                    {
                        m_TSRExpenseSheet = TSR.Core.TSRExpenseFacade.GetExpenseSheetByTimeEntryID(m_TSREntry.ID);
                    }
                }
                return m_TSRExpenseSheet;
            }
        }

        /// <summary>
        /// The OrganizationID for this inspector window.
        /// </summary>
        internal string OrganizationID
        {
            get
            {
                try
                {
                    return Organizations.FindByID(TSREntry.OrganizationID).OrganizationID;
                }
                catch
                {
                    return Organizations[0].OrganizationID;
                }
            }
            set
            {
                TSREntry.OrganizationID = Organizations.FindByOrganizationID(value).ID;
            }
        }

        /// <summary>
        /// The ProjectID for this inspector window.
        /// </summary>
        internal string ProjectID
        {
            get
            {
                try
                {
                    return Projects.FindByID(TSREntry.ProjectID).ProjectID;
                }
                catch
                {
                    return Projects[0].ProjectID;
                }
            }
            set
            {
                TSREntry.ProjectID = Projects.FindByProjectID(value).ID;
            }
        }

        /// <summary>
        /// The ActivityID for this inspector window.
        /// </summary>
        internal string ActivityID
        {
            get
            {
                try
                {
                    return Activities.FindByID(TSREntry.ActivityID).ActivityID;
                }
                catch
                {
                    return Activities[0].ActivityID;
                }
            }
            set
            {
                TSREntry.ActivityID = Activities.FindByActivityID(value).ID;
            }
        }

        /// <summary>
        /// The TSRItem for this inspector window.
        /// </summary>
        internal bool IsTSRItem
        {
            get { return m_IsTSRItem; }
            set { m_IsTSRItem = value; }
        }

        /// <summary>
        /// The CurrentItem for this inspector window.
        /// </summary>
        internal Outlook.AppointmentItem CurrentItem
        {
            get
            {
                return m_Appointment;
            }
        }

        internal Entity.OrganizationList AllOrganizations
        {
            get { return m_AllOrganizations; }
            set { m_AllOrganizations = value; }
        }

        internal Entity.OrganizationList Organizations
        {
            get { return m_Organizations; }
            set { m_Organizations = value; }
        }

        internal Entity.ProjectList AllProjects
        {
            get { return m_AllProjects; }
            set { m_AllProjects = value; }
        }

        internal Entity.ProjectList Projects
        {
            get { return m_Projects; }
            set { m_Projects = value; }
        }

        internal Entity.ActivityList AllActivities
        {
            get { return m_AllActivities; }
            set { m_AllActivities = value; }
        }

        internal Entity.ActivityList Activities
        {
            get { return m_Activities; }
            set { m_Activities = value; }
        }

        internal string LicenseText { get; set; }

        /// <summary>
        /// The TSRItem for this inspector window.
        /// </summary>
        internal bool IsAllowTSRInfo
        {
            get { return m_IsAllowTSRInfo; }
            set { m_IsAllowTSRInfo = value; }
        }

        internal bool IsInspector
        {
            get { return m_IsInspector; }
        }

        internal bool IsSelection
        {
            get { return m_IsSelection; }
        }

        internal bool IsConvertToRecurring
        {
            get { return m_IsConvertToRecurring; }
            set { m_IsConvertToRecurring = value; }
        }

        internal DateTime? StartTimeRecurring
        {
            get { return m_StartTimeRecurring; }
            set { m_StartTimeRecurring = value; }
        }

        internal DateTime? EndTimeRecurring
        {
            get { return m_EndTimeRecurring; }
            set { m_EndTimeRecurring = value; }
        }

        internal bool IsSubmitRecurringAppointments
        {
            get { return m_IsSubmitRecurringAppointments; }
            set { m_IsSubmitRecurringAppointments = value; }
        }

        public bool IsNewTSREntry
        {
            get { return m_IsNewTSREntry; }
            set { m_IsNewTSREntry = value; }
        }

        public bool IsNewAppointmentFromRecurringInstance
        {
            get { return m_IsNewAppointmentFromRecurringInstance; }
            set { m_IsNewAppointmentFromRecurringInstance = value; }
        }
        #endregion

        #region Helper Class
        public class InvalidateEventArgs : EventArgs
        {
            private string m_ControlID;

            public InvalidateEventArgs(string controlID)
            {
                m_ControlID = controlID;
            }

            public string ControlID
            {
                get { return m_ControlID; }
            }
        }
        #endregion
    }
}
