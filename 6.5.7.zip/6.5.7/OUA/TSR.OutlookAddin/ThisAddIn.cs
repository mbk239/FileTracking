﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using Shell = TSR.Shell;
using Core = TSR.Core;
using System.ComponentModel;
using System.Globalization;
using Microsoft.VisualStudio.Tools.Applications.Runtime;
using TSR.Shell;
using TSR.Core;
using TSR.Core.Entity;
using System.Threading;

namespace TSR.OutlookAddin
{        
    public partial class ThisAddIn
    {
        #region Instance Variables
        //private bool isSetAppDataFolder = TSR.Core.Constants.SetAppDataFolder("TSR_DATA_2010");
        private bool isSetAppDataFolder = true;
        private bool isSetTimesheetReporterLocation = TSR.Core.Constants.SetTimeSheetReporterLocation(@"Software\Timesheet Reporter");
              
        private Outlook.Inspectors m_Inspectors;                // Outlook inspectors collection
        internal static List<OutlookInspector> m_Windows;       // List of tracked inspector windows
        internal static Office.IRibbonUI m_Ribbon;              // Ribbon UI reference                
        private Outlook.Application m_Application;
        private Outlook.Explorer m_Explorer;
        //added by tsrdev2
        //feature 162
        //private Outlook.MAPIFolder m_CurrentFolder;
        private Outlook.Items m_CalendarItemsCollection;

        private bool isDragging;
        //Feature 122: Copy appointment function
        //Added by tsrdev2 - 25 Sep 2012
        private bool isCopying;

        //private Outlook.Folders m_OLFolders;
 
        private readonly string _toolbarName = Core.ResourceManager.GetResourceString("TSRToolbar", "TSR Toolbar");
        private readonly string _toolbarNameKey = "TSRToolbar";

        private readonly string _TSRName = Core.ResourceManager.GetResourceString("ProductName", "TSR");
        //private readonly string _listTimeEntryText = "List Time Entries";
        //private readonly string _synchronizeText = "Synchronize";
        //private readonly string _settingsText = "Settings";
        //private readonly string _preferenceText = "Favorites";
        //private readonly string _aboutText = "About";
        private readonly string _TSRTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _listTimeEntryTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _synchronizeTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _settingsTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _preferenceTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _aboutTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _webinterfaceTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
            + Core.ResourceManager.GetResourceString("Details", "Details");
        private readonly string _helpTooltip = Core.ResourceManager.GetResourceString("ProductName", "TSR") + " "
           + Core.ResourceManager.GetResourceString("Details", "Details");
        private Office.CommandBar _rcbar;
        private Office.CommandBarPopup _TSR;
        private Office.CommandBarButton _listTimeEntry;
        private Office.CommandBarButton _synchronize;
        private Office.CommandBarButton _settings;
        private Office.CommandBarButton _preference;
        private Office.CommandBarButton _about;
        private Office.CommandBarButton _webinterface;
        private Office.CommandBarButton _help;


        Core.SyncEngine syncEngine;        
        public static string _Sync = "";

        //Feature 122: Copy appointment function
        //Added by tsrdev2 - 25 Sep 2012
        TimeEntryList _TSREntryListCopied = null;

        public enum SyncStartStatus
        {
            START_OK = 0,
            ALREADY_IN_ANOTHER_SYNC_PROCESS,
            START_FAIL
        }

        #endregion

        #region VSTO Startup and Shutdown methods

        /// <summary>
        /// addin start up event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            SyncEngine._IsFirstSyncOfOutlookSession = true;
            //Catch validating certificate
            TSR.Core.AcceptInvalidCertificate.SetPolicy();
            
            //Feature 277
            //In order to control start up of OUA in a multi user environment, OUA should look for the key START_TSR_OUA in the "HKEY_CURRENT_USER\Software\Timesheet Reporter" path.
            //If the key is True or do not exist, the agent will start normally with Outlook as today, but if the key is False, OUA should not be started                         
            if (UtilityHelper.OUANotBeStarted())
                return;


            bool isNeverAskSettingAgain = false;
            bool showedSettings = false;
            //make sure appointment is dragging is true when addin is start-up
            this.isDragging = true;
            this.isCopying = false;

            bool.TryParse(TSR.Core.TSRFacade.GetUserSettingsValueByKey(TSR.Core.Constants.CONST_TSRDONOTASKSETTINGAGAIN_KEY), out isNeverAskSettingAgain);
            if (!TSR.Core.TSRFacade.IsValidUserAccount())
            {
                if (!isNeverAskSettingAgain)
                {
                    TSR.Shell.Settings setting = TSR.Shell.Settings.GetInstance(true);
                    setting.ShowDialog();

                    showedSettings = true;
                }
                if (!TSR.Core.TSRFacade.IsValidUserAccount())
                {
                    TSR.Shell.DisableAddin disableAddinFrm = new DisableAddin();
                    disableAddinFrm.ShowDialog();
                    return;
                }
            }           

            TSR.Core.Constants.ISLOCKEDUSERSETTING = TSRFacade.IsLockedUserSetitng();
            TSR.Core.Constants.ISSERVERFOUND = TSRFacade.ServerAddressFound();

            TSR.Core.Constants.USERINEXPENSELICENSE = TSRExpenseFacade.UserInExpenseLicense();  

            OutlookHelper.GetCul();            
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            System.Windows.Forms.Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);

            m_Application = this.Application;

            ((Outlook.ApplicationEvents_Event)m_Application).Quit += new Microsoft.Office.Interop.Outlook.ApplicationEvents_QuitEventHandler(mApplication_Quit);            

            m_Explorer = this.Application.ActiveExplorer() as Outlook.Explorer;
            
            //m_Explorer.ExplorerEvents_Event_Close += new Microsoft.Office.Interop.Outlook.ExplorerEvents_CloseEventHandler(m_Explorer_ExplorerEvents_Event_Close);
            //Core.SettingsHelper.UpdateCurrentCulture();
            //if (!String.IsNullOrEmpty(TSR.Core.SettingsHelper.TSRLanguageId))
            //{
            //    CultureInfo culture = new CultureInfo(TSR.Core.SettingsHelper.TSRLanguageId);
            //    if (culture.IsNeutralCulture)
            //    {
            //        culture = CultureInfo.CreateSpecificCulture(TSR.Core.SettingsHelper.TSRLanguageId);
            //    }
            //    System.Threading.Thread.CurrentThread.CurrentCulture = culture; //new System.Globalization.CultureInfo(cmbPreferredLanguage.SelectedItem.ToString());
            //    System.Threading.Thread.CurrentThread.CurrentUICulture = culture; //new System.Globalization.CultureInfo(cmbPreferredLanguage.SelectedItem.ToString());

            //}            
            Init();
            //Get user setting from server local
            try
            {
                if (Core.SettingsHelper.TSRDoNotRetrieveSettingsServer == false)
                {
                    if ((Core.SettingsHelper.TSRServerAddress != "") && (Core.SettingsHelper.TSRServerAddress != "http://"))
                    {
                        if (TSRFacade.IsServiceUp(Core.SettingsHelper.TSRServerAddress))
                        {
                            bool isAuthenticated = true;
                            bool isWrongUserPass = !TSRFacade.LogInToServer();
                            {
                                if (isWrongUserPass && !TSRFacade.TSRLoginDismiss)
                                {
                                    frmTSRLoginRequired frmLogin = frmTSRLoginRequired.GetInstance(true);
                                    isAuthenticated = (frmLogin.ShowDialog() == DialogResult.OK);
                                }
                            }
                            if (isAuthenticated)
                            {
                                TSRFacade.FetchAndProcessPreferredLanguages();
                                TSRFacade.GetUserSettingFromServer(false);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            // Initialize variables
            m_Inspectors = this.Application.Inspectors;
            m_Windows = new List<OutlookInspector>();

            // Wire up event handlers
            m_Inspectors.NewInspector +=
                new Outlook.InspectorsEvents_NewInspectorEventHandler(
                Inspectors_NewInspector);

            //if(m_Explorer.CurrentFolder.DefaultItemType == Microsoft.Office.Interop.Outlook.OlItemType.olAppointmentItem)
            //    m_CalendarItemsCollection = m_Explorer.CurrentFolder.Items;
            
            m_Explorer.FolderSwitch += new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_FolderSwitchEventHandler(m_Explorer_FolderSwitch);            

			if (TSR.Core.TSRFacade.IsValidUserAccount() && !showedSettings)
            {
                string openMode = UtilityHelper.GetRegOpenMode();
                if (openMode == Constants.CONST_OPTION_OPENMODE_VALUE_SETTINGSWINDOW)
                {
                    if (Shell.Settings.HasInstance)
                    {
                        Shell.Settings _fSettings = Shell.Settings.GetInstance();
                        _fSettings.Activate();
                    }
                    else
                    {
                        Shell.Settings _fSettings = Shell.Settings.GetInstance();
                        _fSettings.ShowDialog();
                    }
                    UtilityHelper.SetRegOpenMode(Constants.CONST_OPTION_OPENMODE_VALUE_DEFAULT);
                }
            }
     
            if (TSR.Core.SettingsHelper.TSRMiscLaunch)
            {
                Shell.Synchronize frm = TSR.Shell.Synchronize.GetInstance();
                frm.Show();
            }

            //if (!_handlerGetKeyUpdateCategories)
            {
                string s = string.Empty;
                try
                {
                    //_handlerGetKeyUpdateCategories = true;
                    s = TSR.Core.TSRFacade.GetUserSettingsValueByKey("UpdateCategories");
                }
                catch{
                }
                if (s.Length == 0)
                {
                    TSR.Core.TSRFacade.SetUserSettingsValueByKey("UpdateCategories", "true");

                    TSR.Core.TSRFacade.UpdateCategories();
                }
            }
            StartAutoSyncProc();
        }

        private void m_Explorer_SelectionChange()
        {
            bool isTSREntry = false;
            string appointmentID = string.Empty;
            long selectedOrgId = -1, selectedProjId = -1, selectedActId = -1;
            
            if (m_Windows != null)
            {
                int count = m_Windows.Count;
                int countRemoved = 0;
                for (int i = 0; i < count; i++)
                {
                    OutlookInspector inspector = m_Windows[i - countRemoved];

                    if (inspector.IsSelection)
                    {
                        if (inspector.IsConvertToRecurring)
                        {
                            try
                            {
                                isTSREntry = inspector.IsTSRItem;
                                if (isTSREntry)
                                {
                                    appointmentID = inspector.CurrentItem.EntryID;
                                    selectedOrgId = inspector.TSREntry.OrganizationID;
                                    selectedProjId = inspector.TSREntry.ProjectID;
                                    selectedActId = inspector.TSREntry.ActivityID;
                                }
                            }
                            catch
                            {
                            }
                        }
                        inspector.LostForus();
                        m_Windows.Remove(inspector);
                        countRemoved++;
                    }
                }
            }
            try
            {
                if (m_Explorer.Selection.Count == 1)
                {
                    Outlook.AppointmentItem item = m_Explorer.Selection[1] as Outlook.AppointmentItem;
                    
                    if (item != null)
                    {
                        //OutlookInspector existingWindow = FindOutlookInspector(m_Explorer);
                        //if (existingWindow == null)
                        {        
                            OutlookInspector window;
                            if(isTSREntry && item.EntryID.Equals(appointmentID))
                                window = new OutlookInspector(m_Explorer.Selection, isTSREntry, selectedOrgId, selectedProjId, selectedActId);
                            else
                                window = new OutlookInspector(m_Explorer.Selection); 

                            //window.Close += new EventHandler(WrappedWindow_Close);
                            window.InvalidateControl += new EventHandler<OutlookInspector.InvalidateEventArgs>(WrappedWindow_InvalidateControl);
                            m_Windows.Add(window);

                            //reload all controls of the ribbon.
                            m_Ribbon.Invalidate(); //very importance
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        //Feature 122: Copy appointment function
        //Added by tsrdev2 - 25 Sep 2012
        private void m_CalendarItemsCollection_ItemAdd(object Item)
        {
            this.isCopying = true;
            this.isDragging = false;

            if (this.isCopying)
            {
                Outlook.AppointmentItem appItem = Item as Outlook.AppointmentItem;

                if (appItem != null && _TSREntryListCopied != null && _TSREntryListCopied.Count > 0)
                {                    
                    TimeEntry tePasted = new TimeEntry(Guid.NewGuid(), appItem);

                    tePasted.OrganizationID = _TSREntryListCopied[0].OrganizationID;
                    tePasted.ProjectID = _TSREntryListCopied[0].ProjectID;
                    tePasted.ActivityID = _TSREntryListCopied[0].ActivityID;

                    tePasted.Subject = _TSREntryListCopied[0].Subject;
                    tePasted.Body = _TSREntryListCopied[0].Body;
                    tePasted.Location = _TSREntryListCopied[0].Location;
                    tePasted.ContactID = _TSREntryListCopied[0].ContactID;
                    tePasted.Comment = _TSREntryListCopied[0].Comment;
                    tePasted.Message = _TSREntryListCopied[0].Message;
                    tePasted.Notes = _TSREntryListCopied[0].Notes;                   
                    

                    tePasted.StartTimeStamp = appItem.Start;
                    tePasted.EndTimeStamp = appItem.End;

                    tePasted.LastModificationTime = DateTime.Now;
                    tePasted.Status = TSR.Core.UserAgentService.StatusEnum.PendingSubmission;

                    if (tePasted.OLAppointmentItem != null)
                    {
                        tePasted.OLAppointmentItem.Categories = Core.OutlookHelper.SetTSRCategory(tePasted.OLAppointmentItem.Categories, TSR.Core.UserAgentService.StatusEnum.PendingSubmission);
                        tePasted.OLAppointmentItem.Save();
                    }
                    //update time entry
                    Core.TSRFacade.UpdateTimeEntry(tePasted);

                    if (TSR.Core.TSRFacade.GetExchangeMode())                        
                    {
                        TimeEntry_OutlookAppointment tmp = new TimeEntry_OutlookAppointment();
                        tmp.TimeEntryID = tePasted.ID;
                        tmp.OutlookItemID = tePasted.OLAppointmentItem.EntryID;

                        tmp.CalendarID = Core.OutlookHelper.GetCalendarFolderIDByAppointmentItem(appItem);

                        Core.TSRFacade.UpdateTimeEntry_OutlookAppointment(tmp);
                    }            
           
                    //NotifyAppointmentObservers();

                    _TSREntryListCopied.RemoveAt(0);
                }
            }           
        }

        //Feature 122: Copy appointment function
        //Added by tsrdev2 - 25 Sep 2012
        //apply for case: using Ctrl + Mouse
        private void m_Explorer_BeforeItemPaste(ref object ClipboardContent, Microsoft.Office.Interop.Outlook.MAPIFolder Target, ref bool Cancel)
        {
            //if (m_Explorer.Selection != null && m_Explorer.Selection.Count > 0)
            //{
            //    _TSREntryListCopied = new TimeEntryList();

            //    foreach (var item in m_Explorer.Selection)
            //    {
            //        Outlook.AppointmentItem appItem = item as Outlook.AppointmentItem;
            //        if (appItem != null)
            //        {
            //            TimeEntry te = Core.TSRFacade.GetTimeEntryByOutlookItemID(appItem.EntryID);
            //            if (te != null)
            //            {
            //                _TSREntryListCopied.Add(te);
            //            }
            //        }
            //    }
            //}

            Outlook.Selection localClipBoardContent = ClipboardContent as Outlook.Selection;

            // If it is not a Selection object, then you can try casting to something else.
            // Otherwise, continue processing.
            if (localClipBoardContent != null)
            {
                if (localClipBoardContent.Count > 0)
                {
                    _TSREntryListCopied = new TimeEntryList();

                    foreach (System.Object thisItem in localClipBoardContent)
                    {
                        Outlook.AppointmentItem appItem = thisItem as Outlook.AppointmentItem;
                        if (appItem != null)
                        {
                            TimeEntry te = Core.TSRFacade.GetTimeEntryByOutlookItemID(appItem.EntryID);
                            if (te != null)
                            {
                                _TSREntryListCopied.Add(te);
                            }
                        }
                    }
                }
            }

            this.isCopying = false;
            return;
        }

        //Feature 122: Copy appointment function
        //Added by tsrdev2 - 25 Sep 2012
        //apply for case: using Ctrl + C / Ctrl + V
        private void m_Explorer_BeforeItemCopy(ref bool Cancel)
        {
            //if (m_Explorer.Selection != null && m_Explorer.Selection.Count > 0)
            //{
            //    _TSREntryListCopied = new TimeEntryList();

            //    foreach (var item in m_Explorer.Selection)
            //    {
            //        Outlook.AppointmentItem appItem = item as Outlook.AppointmentItem;
            //        if (appItem != null)
            //        {
            //            TimeEntry te = Core.TSRFacade.GetTimeEntryByOutlookItemID(appItem.EntryID);
            //            if (te != null)
            //            {
            //                _TSREntryListCopied.Add(te);
            //            }
            //        }
            //    }
            //}
            //this.isCopying = false;
            //return;
        }   
        
        private void m_Explorer_FolderSwitch()
        {
            //if (m_CalendarItemsCollection != null)
            //{
            //    m_CalendarItemsCollection.ItemChange -= new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemChangeEventHandler(Items_ItemChange);
                
            //    m_CalendarItemsCollection.ItemAdd -= new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemAddEventHandler(m_CalendarItemsCollection_ItemAdd);
            //}            
            if (m_Explorer.CurrentFolder.DefaultItemType == Microsoft.Office.Interop.Outlook.OlItemType.olAppointmentItem)
            {
                //Feature 122: Copy appointment function
                //Added by tsrdev2 - 25 Sep 2012
                m_Explorer.BeforeItemPaste += new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_BeforeItemPasteEventHandler(m_Explorer_BeforeItemPaste);

                //m_Explorer.BeforeItemCopy += new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_BeforeItemCopyEventHandler(m_Explorer_BeforeItemCopy);

                m_Explorer.SelectionChange += new Outlook.ExplorerEvents_10_SelectionChangeEventHandler(m_Explorer_SelectionChange);


                this.m_CalendarItemsCollection = this.m_Explorer.CurrentFolder.Items;

                //Feature 122: Copy appointment function
                //Added by tsrdev2 - 25 Sep 2012
                if (m_CalendarItemsCollection != null)
                {
                    m_CalendarItemsCollection.ItemAdd += new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemAddEventHandler(m_CalendarItemsCollection_ItemAdd);

                    m_CalendarItemsCollection.ItemChange += new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemChangeEventHandler(Items_ItemChange);
                }
            }
            else
            {
                m_Explorer.BeforeItemPaste -= new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_BeforeItemPasteEventHandler(m_Explorer_BeforeItemPaste);

                //m_Explorer.BeforeItemCopy += new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_BeforeItemCopyEventHandler(m_Explorer_BeforeItemCopy);

                m_Explorer.SelectionChange -= new Outlook.ExplorerEvents_10_SelectionChangeEventHandler(m_Explorer_SelectionChange);

                //Feature 122: Copy appointment function
                //Added by tsrdev2 - 25 Sep 2012
                if (m_CalendarItemsCollection != null)
                {
                    m_CalendarItemsCollection.ItemAdd -= new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemAddEventHandler(m_CalendarItemsCollection_ItemAdd);

                    m_CalendarItemsCollection.ItemChange -= new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemChangeEventHandler(Items_ItemChange);
                }
            }

        }

        private void Items_ItemChange(object Item)
        {
            if (this.isCopying)
            {
                this.isCopying = false;
                this.isDragging = true;
                return;
            }
            else
            {
                if (_TSREntryListCopied != null && _TSREntryListCopied.Count > 0)
                {
                    _TSREntryListCopied.Clear();
                    _TSREntryListCopied = null;
                }
            }

            if (!this.isDragging)
            {
                this.isDragging = true;
                return;
            }
            try
            {
                // Make sure this is an appointment item
                Outlook.AppointmentItem appItem = Item as Outlook.AppointmentItem;                
                
                if (appItem != null)
                {   
                    if (m_Windows != null && m_Windows.Count > 0)
                    {
                        foreach (OutlookInspector inspector in m_Windows)
                        {
                            Outlook.AppointmentItem appCurrentItem = inspector.CurrentItem as Outlook.AppointmentItem;
                            if (appCurrentItem != null && appCurrentItem.EntryID == appItem.EntryID)
                            {
                                return;
                            }
                        }
                    }                    

                    TSR.Core.Entity.TimeEntry TSREntry = Core.TSRFacade.GetTimeEntryByOutlookItemID(appItem.EntryID);
                    if (TSREntry != null)
                    {
                        if (!TSREntry.IsChangeAllowed())
                        {
                            string msg = Core.ResourceManager.GetResourceString("ImpossibleChangingAppointmentMessage", "This Time Entry is impossible to change.");
                            msg += Environment.NewLine + Core.ResourceManager.GetResourceString("CauseOfTimeEntryIsImpossibleToChange", "Because its status is ") + TSREntry.Status.ToString();
                            
                            if (string.Compare(appItem.Subject, TSREntry.Subject, false) != 0 ||
                                DateTime.Compare(appItem.Start,TSREntry.StartTimeStamp) != 0 ||
                                DateTime.Compare(appItem.End,TSREntry.EndTimeStamp) != 0)                                
                            {
                                appItem.Subject = TSREntry.Subject;
                                appItem.Start = TSREntry.StartTimeStamp;
                                appItem.End = TSREntry.EndTimeStamp;
                                appItem.Save();
                                MessageBox.Show(msg);

                                TSR.Core.Logging.LoggingHandler.LogError(new TSR.Core.Logging.Log
                                {
                                    LoggingTime = DateTime.Now,
                                    CreatedTimeStamp = DateTime.Now,
                                    SessionID = string.Empty,
                                    MessageDetail = msg,
                                    MessageSummary = "Items_ItemChange Method",
                                    Priority = 0
                                });
                            }
                        }
                        else
                        {
                            if (string.Compare(appItem.Subject, TSREntry.Subject, false) != 0 ||
                                DateTime.Compare(appItem.Start, TSREntry.StartTimeStamp) != 0 ||
                                DateTime.Compare(appItem.End, TSREntry.EndTimeStamp) != 0)
                            {
                                TSREntry.StartTimeStamp = appItem.Start;
                                TSREntry.EndTimeStamp = appItem.End;
                                TSREntry.Subject = appItem.Subject;
                                TSREntry.LastModificationTime = appItem.LastModificationTime;
                                Core.TSRFacade.UpdateTimeEntry(TSREntry);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }             
        /// <summary>
        /// explorer close event
        /// </summary>
        void m_Explorer_ExplorerEvents_Event_Close()
        {
            try
            {
                if (TSRFacade.bCheckSetting)                
                {
                    if ((Core.SettingsHelper.TSRServerAddress != "") && (Core.SettingsHelper.TSRServerAddress != "http://"))
                    {
                        DialogResult result;
                        Shell.ShowBox frmShowBox = new TSR.Shell.ShowBox();                        
                         result=frmShowBox.ShowDialog();
                        if (result == DialogResult.Yes)
                        {
                            syncEngine = Core.SyncEngine.GetInstance();
                            syncEngine.SaveUserSettingsInServer();
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
                return;
            }
            try
            {
                if (Core.Synchronization.Synchronizer.timer != null)
                    Core.Synchronization.Synchronizer.timer.Stop();

            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
                return;
            }

            try
            {
                if (Core.SettingsHelper.TSRAutoSyncOption && Core.SettingsHelper.TSRAutoSyncWhenOutlookClose)
                {
                    _Sync = "running";
                    Waiting frm = new Waiting();
                    frm.Show();
                    frm.ResumeLayout();
                    frm.PerformLayout();
                    frm.Refresh();
                    Synchronize(false);
                    _Sync = "";
                }
            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
            }
        }
        /// <summary>
        /// application close event
        /// </summary>
        void mApplication_Quit()
        {
            bool needSaveSetting = false;
            bool waitFormDisplayed = false;
            try
            {
                if (TSRFacade.bCheckSetting)
                {
                    if ((Core.SettingsHelper.TSRServerAddress != "") && (Core.SettingsHelper.TSRServerAddress != "http://"))
                    {
                        DialogResult result;
                        Shell.ShowBox frmShowBox = new TSR.Shell.ShowBox();
                        result = frmShowBox.ShowDialog();
                        if (result == DialogResult.Yes)
                        {
                            syncEngine = Core.SyncEngine.GetInstance();
                            if (syncEngine != null)
                            {
                                syncEngine.SaveUserSettingsInServer();
                                syncEngine.Dispose();
                            }
                            else
                            {
                                needSaveSetting = true;
                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
                return;
            }
            try
            {
                if (Core.Synchronization.Synchronizer.timer != null)
                    Core.Synchronization.Synchronizer.timer.Stop();

            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
                return;
            }

            Waiting frm = new Waiting();
            syncEngine = Core.SyncEngine.GetInstance();
            if (syncEngine == null)
            {
                frm.Show();
                frm.ResumeLayout();
                frm.PerformLayout();
                frm.Refresh();

                waitFormDisplayed = true;
                Core.SyncEngine._resetEvent.WaitOne();
            }

            if (needSaveSetting == true)
            {
                syncEngine = Core.SyncEngine.GetInstance();
                syncEngine.SaveUserSettingsInServer();
                syncEngine.Dispose();
            }

            try
            {
                if (Core.SettingsHelper.TSRAutoSyncOption && Core.SettingsHelper.TSRAutoSyncWhenOutlookClose)
                {
                    _Sync = "running";
                    if (waitFormDisplayed == false)
                    {
                        frm.Show();
                        frm.ResumeLayout();
                        frm.PerformLayout();
                        frm.Refresh();
                    }

                    Synchronize(false);
                    _Sync = "";
                }
            }
            catch (Exception exp)
            {
                Core.Logging.LoggingHandler.LogError(exp);
            }

            syncEngine = null;

            Core.DAL.DSClass.ForceXMLSave();
            //Automatic Synchronization - anyone set it to sync before closing outlook?
            // Unhook event handlers
            m_Inspectors.NewInspector -= new Microsoft.Office.Interop.Outlook.InspectorsEvents_NewInspectorEventHandler(Inspectors_NewInspector);
			
			//added by tsrdev2
			//feature 162
			if(m_CalendarItemsCollection != null)			
                m_CalendarItemsCollection.ItemChange -=new Microsoft.Office.Interop.Outlook.ItemsEvents_ItemChangeEventHandler(Items_ItemChange);            

            if (m_Explorer != null)
            {
                m_Explorer.FolderSwitch -= new Microsoft.Office.Interop.Outlook.ExplorerEvents_10_FolderSwitchEventHandler(m_Explorer_FolderSwitch);
                m_Explorer.BeforeItemPaste -= new Outlook.ExplorerEvents_10_BeforeItemPasteEventHandler(m_Explorer_BeforeItemPaste);
                //m_Explorer.BeforeItemCopy -= new Outlook.ExplorerEvents_10_BeforeItemCopyEventHandler(m_Explorer_BeforeItemCopy);
                m_Explorer.SelectionChange -=new Outlook.ExplorerEvents_10_SelectionChangeEventHandler(m_Explorer_SelectionChange);
            }
            _listTimeEntry.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(ListItem_Click);
            _synchronize.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Synchronize_Click);
            _settings.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Settings_Click);
            _about.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Button_Click);
            _webinterface.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Webinterface_Click);
            _help.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(help_Click);
            
            // Dereference objects
            if(_TSREntryListCopied != null) _TSREntryListCopied.Clear();
            _TSREntryListCopied = null;
            _listTimeEntry = _synchronize = _settings = _about = null;
            _TSR = null;
            _rcbar = null;

            syncEngine = null;
            m_Inspectors = null;
            m_Windows.Clear();
            m_Windows = null;

            m_Ribbon = null;
            m_CalendarItemsCollection = null;
            m_Explorer = null;
            m_Application = null;

            //clean up resources and do a GC.Collect();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        #region Auto Synchronization Service

        /// <summary>
        /// method for starting auto synchronization process
        /// </summary>
        private void StartAutoSyncProc()
        {            
            Core.IMemoryBox memBox = new Shell.MemoryBox();
            //TSR.Core.Synchronization.Synchronizer.SynchronizeByTimer(memBox);
            TSR.Shell.Synchronizer.SynchronizeByTimer(memBox);
            //if (TSR.Core.Synchronization.Synchronizer.timer != null)
            if (TSR.Shell.Synchronizer.timer != null)
            {
                //TSR.Core.Synchronization.Synchronizer.timer.Tick += new EventHandler(timer_Tick);
                TSR.Shell.Synchronizer.timer.Tick += new EventHandler(timer_Tick);
            }
            if (!Core.SettingsHelper.TSRAutoSyncOption)
                return;
            if (Core.SettingsHelper.TSRAutoSyncWhenOutlookOpen)
                Synchronize();
            if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
            {               
            }
        }
        void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (TSR.Core.SettingsHelper.TSRAutoSyncOption)
                {
                    if (Core.SettingsHelper.TSRAutoSyncPeriodOption)
                    {                     
                        Synchronize();                     
                    }
                }                
            }
            catch (Exception ex)
            {
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        /// <summary>
        /// Synchronize process for backgroundworker
        /// </summary>
        private void Synchronize()
        {
            Synchronize(true);
        }

        /// <summary>
        /// Synchronize process
        /// </summary>
        /// <param name="inBackground"></param>
        private SyncStartStatus Synchronize(bool inBackground)
        {
            syncEngine = Core.SyncEngine.GetInstance();
            if (syncEngine == null) // it must be already in another synchronization process
            {
                return SyncStartStatus.ALREADY_IN_ANOTHER_SYNC_PROCESS;
            }
            syncEngine.DoAsBackGroundWorker = inBackground;
            Core.IMemoryBox memBox = new Shell.MemoryBox();
            syncEngine._checkListTimeEntry = new TSR.Shell.CheckListTimeEntry();
            syncEngine._overwriteTimeEntries = new TSR.Shell.OverwriteTimeEntries();

            if (TSRFacade.IsServiceUp(Core.SettingsHelper.TSRServerAddress))
            {
                bool isWrongUserPass = !TSRFacade.LogInToServer();
                {
                    if (isWrongUserPass && !TSRFacade.TSRLoginDismiss)
                    {
                        frmTSRLoginRequired frmLogin = frmTSRLoginRequired.GetInstance(true);
                        frmLogin.ShowDialog();
                    }
                }
            }
            syncEngine.StartSynchornization(memBox);
            
            return SyncStartStatus.START_OK;
        }

        #endregion

        /// <summary>
        /// method for application [outlook] level [thread exception] error handling event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            if (e.Exception != null)
            {
                Core.Logging.LoggingHandler.LogError(e.Exception);
                MessageBox.Show(e.Exception.Message);
            }
        }
        /// <summary>
        /// UnhandledException process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            if (ex != null)
            {
                Core.Logging.LoggingHandler.LogError(ex);
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// method for addin's shutdown event, basically outlook's shutdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            //Core.DAL.DSClass.ForceXMLSave();
            ////Automatic Synchronization - anyone set it to sync before closing outlook?
            //// Unhook event handlers
            //m_Inspectors.NewInspector -= new Microsoft.Office.Interop.Outlook.InspectorsEvents_NewInspectorEventHandler(Inspectors_NewInspector);
            //_listTimeEntry.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(ListItem_Click);
            //_synchronize.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Synchronize_Click);
            //_settings.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Settings_Click);
            //_about.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Button_Click);
            //_webinterface.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(Webinterface_Click);
            //_help.Click -= new Office._CommandBarButtonEvents_ClickEventHandler(help_Click);
            //// Dereference objects
            //_listTimeEntry = _synchronize = _settings = _about = null;
            //_TSR = null;
            //_rcbar = null;
            //m_Inspectors = null;
            //m_Windows.Clear();
            //m_Windows = null;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Looks up the window wrapper for a given window object
        /// </summary>
        /// <param name="window">An outlook inspector window</param>
        /// <returns></returns>
        internal static OutlookInspector FindOutlookInspector(object window)
        {
            bool isSelection = false;
            if (window.GetType().Name == "ExplorerClass")
                isSelection = true;

            foreach (OutlookInspector inspector in m_Windows)
            {
                if (!isSelection) // is inspector
                {
                    if (inspector.IsInspector && inspector.Window == window)
                        return inspector;
                }
                else if (inspector.IsSelection) //always only existing one selection in same time
                {
                    //Outlook.Explorer explorer = window as Outlook.Explorer;
                    //if (explorer != null && explorer.Selection.Count > 0)
                    //{
                    //    Outlook.AppointmentItem appItem = explorer.Selection[1] as Outlook.AppointmentItem;
                    //    if (appItem != null)
                    //    {
                    //        try
                    //        {
                    //            if (appItem.RecurrenceState == Outlook.OlRecurrenceState.olApptOccurrence)
                    //            {
                    //                Outlook.AppointmentItem appMaster = appItem.Parent as Outlook.AppointmentItem;
                    //                if (appMaster != null)
                    //                {
                    //                }
                    //            }
                    //            if (inspector.CurrentItem.EntryID.Equals(appItem.EntryID))
                    //                return inspector;
                    //        }
                    //        catch (Exception)
                    //        {
                    //        }
                    //    }                        
                    //}
                    return inspector;
                }
            }
            return null;
        }
        /// <summary>
        /// initialization process
        /// </summary>
        private void Init()
        {
            TSR.Core.OutlookHelper.CurrentApplication = Application;
            TSR.Core.OutlookHelper.CreateCategoriesForTSREntry();
            InitCommandBar();
        }

        /// <summary>
        /// TSR menu items initialization method
        /// </summary>
        private void InitCommandBar()
        {
            //Core.SettingsHelper.UpdateCurrentCulture();
            Office.CommandBars commandBars = this.Application.ActiveExplorer().CommandBars;
            try
            {
                Office.CommandBar tmpBar = commandBars[TSR.Core.TSRFacade.GetUserSettingsValueByKey(_toolbarNameKey)];
                if (tmpBar != null)
                {
                    tmpBar.Delete();
                    tmpBar = null;
                }
            }
            catch //(Exception ex)
            {
                //TSR.Core.Logging.LoggingHandler.LogError(ex);
            }
            try
            {
                _rcbar = commandBars[_toolbarName];
            }
            catch
            {
                _rcbar = commandBars.Add(_toolbarName, Office.MsoBarPosition.msoBarTop, false, false);
            }

            _rcbar.Protection = Microsoft.Office.Core.MsoBarProtection.msoBarNoCustomize;

            _rcbar.Visible = false;

            _rcbar.NameLocal = _toolbarName;
            _TSR = (Office.CommandBarPopup)_rcbar.Controls.Add(Office.MsoControlType.msoControlPopup,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    true); /* temporary, delete on shutdown useful with localization */
            _TSR.Caption = _TSRName;
            _TSR.Visible = true;
            _TSR.TooltipText = _TSRTooltip;

            _listTimeEntry = AssignButton(Core.ResourceManager.GetResourceString("_listTimeEntryText", "List Time Entries"), 1987, _listTimeEntryTooltip, ListItem_Click);
            _synchronize = AssignButton(Core.ResourceManager.GetResourceString("_synchronizeText", "Synchronize"), 2934, _synchronizeTooltip, Synchronize_Click);
            _settings = AssignButton(Core.ResourceHelper.Settings, 2946, _settingsTooltip, Settings_Click);
            _settings.BeginGroup = true;

            _preference = AssignButton(Core.ResourceManager.GetResourceString("_preferenceText", "Favorites"), 0630, _preferenceTooltip, Preference_Click);
            _preference.BeginGroup = true;

            _about = AssignButton(Core.ResourceManager.GetResourceString("_aboutText", "About"), -1, _aboutTooltip, Button_Click);
            _about.BeginGroup = true;

            _webinterface = AssignButton(Core.ResourceManager.GetResourceString("_webInterface","Web Interface"), -1, _webinterfaceTooltip, Webinterface_Click);
           _webinterface.BeginGroup = true;
           _help = AssignButton(Core.ResourceManager.GetResourceString("_help", "Help"), -1, _helpTooltip, help_Click);
           _help.BeginGroup = true;

            _rcbar.Visible = true;

            TSR.Core.TSRFacade.SetUserSettingsValueByKey(_toolbarNameKey, _toolbarName);
        }

        private Office.CommandBarButton AssignButton(string Caption, int iconFaceID, string toolTip, Office._CommandBarButtonEvents_ClickEventHandler eventHandler)
        {
            Office.CommandBarButton button = (Office.CommandBarButton)_TSR.Controls.Add(Office.MsoControlType.msoControlButton,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    System.Reflection.Missing.Value,
                    true); /* temporary, delete on shutdown useful with localization */
            button.Click += new Office._CommandBarButtonEvents_ClickEventHandler(eventHandler);
            if (iconFaceID == -1)
                button.Style = Office.MsoButtonStyle.msoButtonCaption;
            else
            {
                button.Style = Office.MsoButtonStyle.msoButtonIconAndCaption;
                button.FaceId = iconFaceID;
            }
            button.Caption = Caption;
            button.Visible = true;
            button.TooltipText = toolTip;

            return button;
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// The NewInspector event fires whenever a new inspector is displayed.  We use
        /// this event to add our custom button to appointment item inspectors.
        /// </summary>
        /// <param name="Inspector"></param>
        private void Inspectors_NewInspector(Outlook.Inspector Inspector)
        {
            try
            {
                // Debug.WriteLine("Inspectors_NewInspector");
                // OutlookItem olItem = new OutlookItem(Inspector.CurrentItem);
                // Make sure this is an appointment item
                Outlook.AppointmentItem item = Inspector.CurrentItem as Outlook.AppointmentItem;
                //if (olItem.Class == Outlook.OlObjectClass.olAppointment)
                if (item != null)
                {                   
                    // Check to see if this is a new window 
                    // we don't already track
                    OutlookInspector existingWindow =
                        FindOutlookInspector(Inspector);
                    // If the m_Windows collection does not 
                    // have a window for this Inspector,
                    // we should add it to m_Windows
                    if (existingWindow == null)
                    {
                        OutlookInspector window = new OutlookInspector(Inspector);
                        window.Close += new EventHandler(WrappedWindow_Close);
                        window.InvalidateControl += new EventHandler<
                            OutlookInspector.InvalidateEventArgs>(
                            WrappedWindow_InvalidateControl);
                        m_Windows.Add(window);
                    }

                    //remove all seclection
                    if (m_Windows != null)
                    {
                        int count = m_Windows.Count;
                        int countRemoved = 0;
                        for (int i = 0; i < count; i++)
                        {
                            OutlookInspector inspector = m_Windows[i - countRemoved];
                        
                            if (inspector.IsSelection)
                            {
                                inspector.LostForus();
                                m_Windows.Remove(inspector);
                                countRemoved++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Core.Logging.LoggingHandler.LogError(ex);
            }
        }

        void WrappedWindow_InvalidateControl(object sender,
            OutlookInspector.InvalidateEventArgs e)
        {
            if (m_Ribbon != null)
            {
                m_Ribbon.InvalidateControl(e.ControlID);
            }
        }

        public static string recurringSeriesEntryID = "";
        public static DateTime occurrenceStartTime = DateTime.MinValue;

        void WrappedWindow_Close(object sender, EventArgs e)
        {
            OutlookInspector window = (OutlookInspector)sender;
            //added by tsrdev2
            //feature 162
            if (window.AppointmentSaved)
            {
                if (window.IsTSRItem && window.TSREntry.IsChangeAllowed())
                {
                    this.isDragging = false;
                }
                this.isCopying = false;
            }

            window.Close -= new EventHandler(WrappedWindow_Close);

            m_Windows.Remove(window);

            if (!string.IsNullOrEmpty(recurringSeriesEntryID) && window.IsTSRItem)
            {
                System.Threading.Timer timer = new System.Threading.Timer(new System.Threading.TimerCallback(TimerProc));
                timer.Change(100, 0);
            }
        }


        private void TimerProc(object state)
        {
            try
            {
                if (!string.IsNullOrEmpty(recurringSeriesEntryID))
                {
                    Stopwatch watch = new Stopwatch();
                    Outlook.AppointmentItem app = null;
                    try
                    {
                        watch.Start();
                        int stop = 0;
                        while (true)
                        {
                            bool b = checkExistedOfOutlookInspectorByEntryID(recurringSeriesEntryID);
                            if (!b)
                            {
                                app = OutlookHelper.GetAppointmentItemByEntryID(recurringSeriesEntryID);
                                if (app != null)
                                {
                                    if (occurrenceStartTime != DateTime.MinValue) //delete an instance of recurring series (occurrence or exception)
                                    {
                                        Outlook.RecurrencePattern rp = null;
                                        try
                                        {
                                            rp = app.GetRecurrencePattern();
                                        }
                                        catch (Exception ex)
                                        {
                                            Core.Logging.LoggingHandler.LogUnhandledException(ex);                                            
                                        }
                                        if (rp != null)
                                        {
                                            Outlook.AppointmentItem instanceApp = rp.GetOccurrence(occurrenceStartTime);
                                            if (instanceApp != null)
                                            {
                                                instanceApp.Delete();
                                                System.Threading.Thread.Sleep(200);
                                            }
                                            instanceApp = null;
                                            rp = null;
                                        }
                                    }
                                    else //delete the recurring series
                                    {
                                        app.Delete();
                                        System.Threading.Thread.Sleep(50);
                                    }
                                }
                                stop++;

                                if(stop > 1)
                                    break;
                            }

                            if (watch.Elapsed.TotalSeconds >= 5)
                            {
                                TSR.Core.Logging.LoggingHandler.LogInfo(new Core.Logging.Log()
                                {
                                    MessageSummary = "TimeProc Method",
                                    MessageDetail = "Can not delete this appointment; checkExistedOfOutlookInspectorByEntryID is " + b.ToString() + "; AppointmentItem is " + (app == null ? "Null" : "Not NULL")
                                });
                                break;
                            }
                        }
                    }
                    catch(Exception ex) {
                        Core.Logging.LoggingHandler.LogUnhandledException(ex);
                    }
                    finally
                    {
                        app = null;
                        watch.Stop();       
                    }
                }
            }
            catch (Exception e)
            {
                Core.Logging.LoggingHandler.LogUnhandledException(e);
            }
            finally
            {
                recurringSeriesEntryID = "";
                occurrenceStartTime = DateTime.MinValue;

                // The state object is the Timer object.
                System.Threading.Timer t = (System.Threading.Timer)state;
                t.Dispose();
            }
        }

        private bool checkExistedOfOutlookInspectorByEntryID(string entryID)
        {
            if (m_Windows != null && m_Windows.Count > 0)
            {
                foreach (var window in m_Windows)
                {
                    if (window.IsInspector && window.CurrentItem != null)
                    {
                        if(window.CurrentItem.EntryID.Equals(entryID))
                            return true;
                    }
                }
            }
            return false;
        }

        void Button_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {            
            Shell.About about = new Shell.About();
            about.ShowDialog();
        }

        void ListItem_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {          
            if (Shell.ItemList.HasInstance)
            {
                Shell.ItemList frm = Shell.ItemList.GetInstance();
                frm.Activate();
            }
            else
            {
                Shell.ItemList frm = Shell.ItemList.GetInstance();
                frm.Show();
            }
        }

        void Synchronize_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {         
            if (Shell.Synchronize.HasInstance)
            {
                Shell.Synchronize frm = TSR.Shell.Synchronize.GetInstance();
                frm.Activate();
            }
            else
            {
                Shell.Synchronize frm = TSR.Shell.Synchronize.GetInstance();
                frm.Show();
            }

        }

        void Settings_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {            
            if (Shell.Settings.HasInstance)
            {
                Shell.Settings _fSettings = Shell.Settings.GetInstance();
                _fSettings.Activate();

            }
            else
            {
                Shell.Settings _fSettings = Shell.Settings.GetInstance();
                _fSettings.ShowDialog();
            }
        }

        void Webinterface_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {
            string strLinl = TSR.Core.SettingsHelper.TSRWebinterface;
            Process.Start(strLinl);
        }
        void help_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {
            string strLinl = Constants.CONST_WEBINTERFACE_HELP;
            Process.Start(strLinl);
            strLinl = "";
        }


        void Preference_Click(Microsoft.Office.Core.CommandBarButton Ctrl, ref bool CancelDefault)
        {            
            if (TSR.Shell.Preferences.HasInstance)
            {
                TSR.Shell.Preferences _fPreferences = TSR.Shell.Preferences.GetInstance();
                _fPreferences.Activate();
            }
            else
            {
                TSR.Shell.Preferences _fPreferences = TSR.Shell.Preferences.GetInstance();
                _fPreferences.ShowDialog();

            }
        }

        #endregion

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);            
        }

        #endregion
    }
}
