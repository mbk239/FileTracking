﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using Microsoft.Win32;
using TSR.Core.Logging;
using TSR.Core;
using System.Diagnostics;

namespace TSR.Outlook2010.UserAgentSetup
{
    class RegisterOffice
    {
        #region private methods

        public const string OUA2007 = "TSR_OL2007";
        public const string OUA2010 = "TSR_OL2010";
        public const string OUA2010x64 = "TSR_OL2010x64";
        
        private string userSettingsLocationForOUA2007 = @"Software\Microsoft\Office\12.0\User Settings";
        private string userSettingsLocationForOUA2010 = @"Software\Microsoft\Office\15.0\User Settings";
        private string addinLocation = @"Software\Microsoft\Office\Outlook\Addins";
        private string OUAOptionsLocation = "Timesheet Reporter";
        private string OUAOptionsLocationRoot = @"Software";


        public void IncrementCounter(RegistryKey instructionKey)
        {
            int count = 1;
            object value = instructionKey.GetValue("Count");

            if (value != null)
            {
                if ((int)value != Int32.MaxValue)
                    count = (int)value + 1;
            }

            instructionKey.SetValue("Count", count);
        }



        private string GetApplicationPath(string applicationName)
        {
            switch (applicationName.ToLower())
            {
                case "excel":
                    return @"Software\Microsoft\Office\Excel\Addins\";

                case "infopath":
                    return @"Software\Microsoft\Office\InfoPath\Addins\";

                case "outlook":
                    return @"Software\Microsoft\Office\Outlook\Addins\";

                case "powerpoint":
                    return @"Software\Microsoft\Office\PowerPoint\Addins\";

                case "word":
                    return @"Software\Microsoft\Office\Word\Addins\";

                case "visio":
                    return @"Software\Microsoft\Visio\Addins\";

                case "project":
                    return @"Software\Microsoft\Office\MS Project\Addins\";

                default:
                    throw new Exception(applicationName + " is not a supported application", null);
            }
        }

        # endregion

        public bool RegisterAddIn(string addInName)
        {
            //Store TSR OUA Options
            StoreTSROUAOptions(addInName);

            //if Outlook 64bit then stop
            if (addInName.Equals(OUA2010x64))
            {
                return true;
            }

            RegistryKey userSettingsKey = null;
            RegistryKey instructionKey = null;
            try
            {
                //Modified by tsrdev1
                if (addInName.Equals(OUA2010))
                    userSettingsKey = Registry.LocalMachine.OpenSubKey(userSettingsLocationForOUA2010, true);
                else
                    userSettingsKey = Registry.LocalMachine.OpenSubKey(userSettingsLocationForOUA2007, true);
                if (userSettingsKey == null)
                {
                    LoggingHandler.LogInfo(new Log()
                    {
                        MessageSummary = "Internal error: Office User Settings key does not exist"
                    });
                    //throw new Exception("Internal error: Office User Settings key does not exist", null);
                }
                else
                {
                    instructionKey = userSettingsKey.OpenSubKey(addInName, true);
                    if (instructionKey == null)
                    {
                        instructionKey = userSettingsKey.CreateSubKey(addInName);
                    }
                    else
                    {
                        // Remove the Delete instruction
                        try
                        {
                            instructionKey.DeleteSubKeyTree("DELETE");
                        }
                        catch (ArgumentException ae)
                        {
                            LoggingHandler.LogUnhandledException(ae);
                        } // Delete instruction did not exist but that is ok.
                    }
                    try
                    {
                        IncrementCounter(instructionKey);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogUnhandledException(e);
                    }
                }
            }
            finally
            {
                if (instructionKey != null)
                    instructionKey.Close();
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return true;
        }

        public void RegSingleUserAddIn(string applicationName, string addInName, string targetDir)
        {
            RegistryKey olAddinKey = null;
            RegistryKey instructionKey = null;
            try
            {
                LoggingHandler.LogInfo(new Log()
                {
                    MessageSummary = "1.Open Sub Key" + addinLocation
                });
                olAddinKey = Registry.CurrentUser.OpenSubKey(addinLocation, true);
                if (olAddinKey == null)
                {
                    LoggingHandler.LogUnhandledException(new Exception("Internal error: Office Outlook Addin key does not exist", null));
                    throw new Exception("Internal error: Office Outlook Addin key does not exist", null);
                }
                else
                {
                    LoggingHandler.LogInfo(new Log()
                    {
                        MessageSummary = "Done - Open Sub Key" + addinLocation
                    });
                    try
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "1.Open Sub Key" + addinLocation
                        });
                        //Modified by tsrdev1
                        instructionKey = olAddinKey.CreateSubKey(addInName);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "Internal error: Office Outlook Addin key does not exist 1"
                        });
                        LoggingHandler.LogUnhandledException(e);
                        throw new Exception("Internal error: Office Outlook Addin key does not exist 1", null);
                    }
                    try
                    {
                        //Modified by tsrdev1
                        instructionKey.SetValue("FriendlyName", addInName, RegistryValueKind.String);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "Internal error: Office Outlook Addin key does not exist 2"
                        });
                        LoggingHandler.LogUnhandledException(e);
                        throw new Exception("Internal error: Office Outlook Addin key does not exist 2", null);
                    }
                    try
                    {
                        instructionKey.SetValue("LoadBehavior", "00000003", RegistryValueKind.DWord);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "Internal error: Office Outlook Addin key does not exist 3"
                        });
                        LoggingHandler.LogUnhandledException(e);
                        throw new Exception("Internal error: Office Outlook Addin key does not exist 3", null);
                    }
                    try
                    {
                        instructionKey.SetValue("Manifest", targetDir + addInName + "/" + addInName + ".vsto", RegistryValueKind.String);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "Internal error: Office Outlook Addin key does not exist 4"
                        });
                        LoggingHandler.LogUnhandledException(e);
                        throw new Exception("Internal error: Office Outlook Addin key does not exist 4", null);
                    }
                    try
                    {
                        //Modified by tsrdev1
                        if (addInName.Equals(OUA2010))
                            instructionKey.SetValue("Description", "This is an addin built for Outlook 2010", RegistryValueKind.String);
                        else
                            instructionKey.SetValue("Description", "This is an addin built for Outlook 2007", RegistryValueKind.String);
                    }
                    catch (Exception e)
                    {
                        LoggingHandler.LogInfo(new Log()
                        {
                            MessageSummary = "Internal error: Office Outlook Addin key does not exist 5"
                        });
                        LoggingHandler.LogUnhandledException(e);
                        throw new Exception("Internal error: Office Outlook Addin key does not exist 5", null);
                    }
                }
            }
            finally
            {
                if (instructionKey != null)
                {
                    instructionKey.Close();
                }
                if (olAddinKey != null)
                {
                    olAddinKey.Close();
                }
            }
        }

        public void UnRegSingleUserAddIn(string applicationName, string addInName, string targetDir)
        {
            RegistryKey olAddinKey = null;
            RegistryKey instructionKey = null;
            try
            {
                olAddinKey = Registry.CurrentUser.OpenSubKey(addinLocation, true);
                olAddinKey.DeleteSubKeyTree(addInName);
            }
            finally
            {
                if (instructionKey != null)
                {
                    instructionKey.Close();
                }
                if (olAddinKey != null)
                {
                    olAddinKey.Close();
                }
            }
        }

        public void UnRegisterAddIn(string applicationName, string addInName)
        {
            ////Remove TSR OUA Options
            RemoveTSROUAOptions(addInName);
            TSR.Core.UtilityHelper.DeleteINIFilePath();

            //stop here if platform is outlook 64bit
            if (addInName.Equals(OUA2010x64))
            {
                return;
            }

            //Log for Debug information
            LoggingHandler.LogInfo(new Log()
            {
                MessageSummary = "DEBUG INFO: Start UnRegisterAddIn(" + applicationName + "," + addInName + ")"
            });
            RegistryKey userSettingsKey = null;
            RegistryKey instructionKey = null;
            RegistryKey deleteKey = null;
            try
            {
                //Modified by tsrdev1
                if (addInName.Equals(OUA2010))
                    userSettingsKey = Registry.LocalMachine.OpenSubKey(userSettingsLocationForOUA2010, true);
                else
                    userSettingsKey = Registry.LocalMachine.OpenSubKey(userSettingsLocationForOUA2007, true);
                if (userSettingsKey == null)
                {
                    //throw new Exception("Internal error: Office User Settings key does not exist", null);
                }
                else
                {
                    instructionKey = userSettingsKey.OpenSubKey(addInName, true);
                    if (instructionKey == null)
                    {
                        instructionKey = userSettingsKey.CreateSubKey(addInName);
                    }
                    else
                    {
                        // Make sure there is no Create instruction
                        try
                        {
                            instructionKey.DeleteSubKeyTree("CREATE");
                        }
                        catch (ArgumentException) { } // Create instruction did not exist but that is ok.
                    }
                    string instructionString =
                                    @"DELETE\" +
                                    GetApplicationPath(applicationName) +
                                    @"\" +
                                    addInName;
                    deleteKey = instructionKey.CreateSubKey(instructionString);
                    IncrementCounter(instructionKey);
                }
            }
            finally
            {
                if (deleteKey != null)
                    deleteKey.Close();
                if (instructionKey != null)
                    instructionKey.Close();
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            //Log for Debug information
            LoggingHandler.LogInfo(new Log()
            {
                MessageSummary = "DEBUG INFO: End UnRegisterAddIn(" + applicationName + "," + addInName + ")"
            });
        }

        public void StoreTSROUAOptions(string addinName)
        {
            string CURRENTUSER_SID = TSR.Core.UtilityHelper.GetCurrentUserSID();
            if (CURRENTUSER_SID.Length > 0)
            {
                addinLocation = CURRENTUSER_SID + @"\Software\Microsoft\Office\Outlook\Addins";
                //OUAOptionsLocation = CURRENTUSER_SID + @"\Timesheet Reporter";
                OUAOptionsLocationRoot = CURRENTUSER_SID + @"\Software";
            }

            //using for cannot get regitry path
            Log regPathLog = new Log();
            regPathLog.Category = "regPathLog";
            regPathLog.MessageDetail = "addinLocation: " + addinLocation + Environment.NewLine + "OUAOptionsLocationRoot: " + OUAOptionsLocationRoot;
            regPathLog.LoggingTime = DateTime.Now;
            TSR.Core.Logging.LoggingHandler.LogWarning(regPathLog);

            string customerNo = string.Empty;
            string serverAddr = string.Empty;
            string webAddr = string.Empty;
            string verbose = string.Empty;
            string connectionTimeOutValue = string.Empty;
            string silentInstall = string.Empty;
            string strUseAutoProxy = string.Empty;

            //If file INI is valid, and the key "KeepExistingValue" is not "Yes", the informations inside the INI file will be using
            //If file INI is not exist or invalid or "KeepExistingValue" is "Yes", the informantions in the registry will be using
            bool keepExistingValue = true;

            TSR.Core.ExchangeMode exMode = TSR.Core.ExchangeMode.Yes;
            TSR.Core.ValidationMode validationMode = TSR.Core.ValidationMode.NONAD;
            string userName = string.Empty;
            string pass = string.Empty;

            string iniFilePath = TSR.Core.UtilityHelper.GetINIFilePath();

            if (!string.IsNullOrEmpty(iniFilePath))
            {
                silentInstall = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_SILENTINSTALL);
                verbose = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_VERBOSE);
            }

            RegistryKey softwareKeyHKLM = null;
            RegistryKey tsrOptionKeyHKLM = null;

            RegistryKey softwareKeyHKCU = null;
            RegistryKey tsrOptionKeyHKCU = null;

            if (!string.IsNullOrEmpty(iniFilePath) && File.Exists(iniFilePath))
            {
                try
                {
                    string strKeepExistingValue = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_KEEP_EXISTING_VALUE);
                    if (!string.IsNullOrEmpty(strKeepExistingValue)
                        && strKeepExistingValue.ToLower() != Constants.Y_IN_LOWER_CHARS.ToLower()
                        && strKeepExistingValue.ToLower() != Constants.YES_IN_LOWER_CHARS.ToLower())
                    {
                        keepExistingValue = false;
                    }
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }

                //Read tsr option values from ini file
                try
                {
                    //validationMode = (TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE).ToLower()
                    //    == ValidationMode.AD.ToString().ToLower()) ? ValidationMode.AD : ValidationMode.NONAD;

                    customerNo = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO);
                    serverAddr = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES);
                    webAddr = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRWEBADMIN);
                    //exMode = (TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_EXCHANGEMODE).ToLower()
                    //    == ExchangeMode.Yes.ToString().ToLower()) ? ExchangeMode.Yes : ExchangeMode.No;

                    //exMode = ExchangeMode.Yes;
                    connectionTimeOutValue = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_CONNECTION_TIMEOUT_VALUE);
                    strUseAutoProxy = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_USEAUTOPROXY);

                    //template code will be using in the feature, not now
                    userName = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_USERNAME);
                    pass = TSR.Core.UtilityHelper.GetValue(iniFilePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_PASSWORD);
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
            }

            if (keepExistingValue)
            {
                try
                {
                    //softwareKeyHKLM = Registry.LocalMachine.OpenSubKey(OUAOptionsLocationRoot, true); //to get customer, server, exchange settings
                    softwareKeyHKLM = Registry.Users.OpenSubKey(OUAOptionsLocationRoot, true); //to get customer, server, exchange settings
                    if (softwareKeyHKLM != null)
                    {
                        tsrOptionKeyHKLM = softwareKeyHKLM.OpenSubKey(OUAOptionsLocation, true);
                        if (tsrOptionKeyHKLM != null)
                        {
                            //Get registry key for installation mode
                            string regisCustomerNo = (String)tsrOptionKeyHKLM.GetValue(Constants.CONST_REGISTRYKEY_CUSTOMERNO);
                            string regisServerAddr = (String)tsrOptionKeyHKLM.GetValue(Constants.CONST_REGISTRYKEY_SERVERADDRESS);
                            string regisWebAddr = (String)tsrOptionKeyHKLM.GetValue(Constants.CONST_REGISTRYKEY_WEBINTERFACE);

                            if (!string.IsNullOrEmpty(regisCustomerNo))
                                customerNo = regisCustomerNo;
                            if (!string.IsNullOrEmpty(regisServerAddr))
                                serverAddr = regisServerAddr;
                            if (!string.IsNullOrEmpty(regisWebAddr))
                                webAddr = regisWebAddr;
                            //String exchangeMode = (String)tsrOptionKeyHKLM.GetValue(Constants.CONST_REGISTRYKEY_EXCHANGEMODE);
                            //if (exchangeMode.Equals("Yes"))
                            //    exMode = TSR.Core.ExchangeMode.Yes;
                            //else
                            //    exMode = TSR.Core.ExchangeMode.No;

                            //exMode = TSR.Core.ExchangeMode.Yes;
                        }
                    }
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
                finally
                {
                    if (tsrOptionKeyHKLM != null) tsrOptionKeyHKLM.Close();
                    if (softwareKeyHKLM != null) softwareKeyHKLM.Close();
                }
            }

            if (keepExistingValue)
            {
                //get username and password from current user registry
                try
                {
                    softwareKeyHKCU = Registry.Users.OpenSubKey(OUAOptionsLocationRoot, true); //to get username and password
                    if (softwareKeyHKCU != null)
                    {
                        tsrOptionKeyHKCU = softwareKeyHKCU.OpenSubKey(OUAOptionsLocation, true);
                        if (tsrOptionKeyHKCU != null)
                        {
                            string regisUserName = (String)tsrOptionKeyHKCU.GetValue(Constants.CONST_REGISTRYKEY_USERNAME);
                            string regisPass = (String)tsrOptionKeyHKCU.GetValue(Constants.CONST_REGISTRYKEY_PASSWORD);

                            if (!string.IsNullOrEmpty(regisUserName))
                                userName = regisUserName;
                            if (!string.IsNullOrEmpty(regisPass))
                                pass = regisPass;
                        }
                    }
                }
                catch (Exception ex)
                {
                    TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
                }
                finally
                {
                    if (tsrOptionKeyHKCU != null) tsrOptionKeyHKCU.Close();
                    if (softwareKeyHKCU != null) softwareKeyHKCU.Close();
                }
            }

            string title = "TSR User Agent 6.5.4";
            WindowWrapper wrapper = WindowWrapper.GetInstance(title);

            bool bSilentInstallMode = !string.IsNullOrEmpty(silentInstall)
                && (silentInstall.ToLower() == Constants.Y_IN_LOWER_CHARS.ToLower() || silentInstall.ToLower() == Constants.YES_IN_LOWER_CHARS.ToLower()); ;
            bool bVerboseMode = !string.IsNullOrEmpty(verbose) 
                && (verbose.ToLower() == Constants.Y_IN_LOWER_CHARS.ToLower() || verbose.ToLower() == Constants.YES_IN_LOWER_CHARS.ToLower());

            bool bUseAutoProxy = !string.IsNullOrEmpty(strUseAutoProxy)
                && (strUseAutoProxy.ToLower() == Constants.Y_IN_LOWER_CHARS.ToLower() || strUseAutoProxy.ToLower() == Constants.YES_IN_LOWER_CHARS.ToLower());

            if (!bSilentInstallMode && !bVerboseMode)
            {
                try
                {
                    //Show server information form
                    CustomOutlookSetup.ServerInformation serverFrm = new CustomOutlookSetup.ServerInformation(customerNo, serverAddr, webAddr);
                    serverFrm.SetTitle(title);
                    serverFrm.TopMost = true;
                    if (wrapper != null)
                        serverFrm.ShowDialog(wrapper);
                    else
                        serverFrm.ShowDialog();
                    customerNo = serverFrm.CustomerNo;
                    serverAddr = serverFrm.TSRServices;
                    webAddr = serverFrm.TSRWebAdmin;

                    //Show user information
                    CustomOutlookSetup.UserInformation userInfo = new CustomOutlookSetup.UserInformation(userName, pass);
                    userInfo.SetTitle(title);
                    userInfo.TopMost = true;
                    if (wrapper != null)
                        userInfo.ShowDialog(wrapper);
                    else
                        userInfo.ShowDialog();
                    userName = userInfo.UserName;

                    if (!string.IsNullOrEmpty(userInfo.Password) && pass != userInfo.Password) //if the old password have been changed
                    {
                        pass = TSR.Core.UtilityHelper.EncryptString(userInfo.Password);
                    }

                    //Show exchange mode choose
                    //CustomOutlookSetup.ExchangeOption exFrm = new CustomOutlookSetup.ExchangeOption(exMode);
                    //exFrm.SetTitle(title);
                    //exFrm.TopMost = true;
                    //if (wrapper != null)
                    //    exFrm.ShowDialog(wrapper);
                    //else
                    //    exFrm.ShowDialog();
                    //exMode = TSR.Core.ExchangeMode.Yes;
                }
                catch (Exception ex)
                {
                    LoggingHandler.LogUnhandledException(ex);
                }
            }
            else //Verbose mode is not set
            {
                if (!bSilentInstallMode)
                {
                    if (!keepExistingValue)
                    {
                        //Show user information
                        CustomOutlookSetup.UserInformation userInfo = new CustomOutlookSetup.UserInformation();
                        userInfo.SetTitle(title);
                        userInfo.TopMost = true;
                        if (wrapper != null)
                            userInfo.ShowDialog(wrapper);
                        else
                            userInfo.ShowDialog();

                        userName = userInfo.UserName;
                        pass = userInfo.Password;
                        if (!string.IsNullOrEmpty(pass))
                            pass = TSR.Core.UtilityHelper.EncryptString(pass);
                    }
                }
                else //bSilentInstallMode - in silent install mode
                {
                    //nothing to do
                }

                if (string.IsNullOrEmpty(customerNo))
                {
                    throw new System.Configuration.Install.InstallException("Insufficient parameters in the INI-file. Installation aborted");
                }

                if (!string.IsNullOrEmpty(serverAddr) && serverAddr.Contains(Constants.CUSTOMERNO_VARIABLENAME))
                    serverAddr = serverAddr.Replace(Constants.CUSTOMERNO_VARIABLENAME, customerNo);
                if (!string.IsNullOrEmpty(webAddr) && webAddr.Contains(Constants.CUSTOMERNO_VARIABLENAME))
                    webAddr = webAddr.Replace(Constants.CUSTOMERNO_VARIABLENAME, customerNo);
            }
            
            try
            {
                //Store common options
                string s = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);

                string folderPath = s + "\\" + Constants.CONST_APPDATA_FOLDER; 
                if (Directory.Exists(folderPath))
                {
                    string commonIniFilePath = folderPath + "\\" + TSR.Core.Constants.CONST_INIFILEPATH;
                    if (TSR.Core.UtilityHelper.IsExistedFile(commonIniFilePath))
                    {
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_CUSTOMERNO, customerNo);
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_INSTALLATIONMODE, validationMode.ToString());
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_TSRSERVICES, serverAddr);
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_TSRWEBADMIN, webAddr);
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_EXCHANGEMODE, exMode.ToString());
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_CONNECTION_TIMEOUT_VALUE, connectionTimeOutValue);
                        TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_USE_AUTO_PROXY_VALUE, bUseAutoProxy.ToString());                        
                        //TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_USERNAME, userName);
                        //TSR.Core.UtilityHelper.SetValue(commonIniFilePath, TSR.Core.Constants.ROOTCATERGORY, TSR.Core.Constants.CONST_OPTION_PASSWORD, pass);
                    }
                }

                //Store private user name and password
                softwareKeyHKCU = Registry.Users.OpenSubKey(OUAOptionsLocationRoot, true);
                //softwareKeyHKLM = Registry.LocalMachine.OpenSubKey(OUAOptionsLocationRoot, true);

                if (softwareKeyHKCU != null)
                {
                    tsrOptionKeyHKCU = softwareKeyHKCU.OpenSubKey(OUAOptionsLocation, true);
                    //if (tsrOptionKeyHKCU != null)
                    //{
                    //    tsrOptionKeyHKCU.Close();
                    //    softwareKeyHKCU.DeleteSubKey(OUAOptionsLocation);
                    //}
                    if (tsrOptionKeyHKCU == null)
                        tsrOptionKeyHKCU = softwareKeyHKCU.CreateSubKey(OUAOptionsLocation);

                    if (tsrOptionKeyHKCU != null)
                    {
                        //Set registry key installation mode
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_USERNAME, userName);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_PASSWORD, pass);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_OPTION_OPENMODE, Constants.CONST_OPTION_OPENMODE_VALUE_DEFAULT);
                    }
                }
                // Save registry to HKLM
                //if (softwareKeyHKLM != null)
                {
                    //tsrOptionKeyHKCU = softwareKeyHKCU.OpenSubKey(OUAOptionsLocation, true);
                    //if (tsrOptionKeyHKLM != null)
                    //{
                    //    tsrOptionKeyHKLM.Close();
                    //    softwareKeyHKLM.DeleteSubKey(OUAOptionsLocation);
                    //}
                    //tsrOptionKeyHKLM = softwareKeyHKLM.CreateSubKey(OUAOptionsLocation);

                    if (tsrOptionKeyHKCU != null)
                    {
                        //Set registry key installation mode
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_INSTALLATIONMODE, validationMode);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_CUSTOMERNO, customerNo);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_SERVERADDRESS, serverAddr);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_WEBINTERFACE, webAddr);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_REGISTRYKEY_EXCHANGEMODE, exMode);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_OPTION_OPENMODE, Constants.CONST_OPTION_OPENMODE_VALUE_DEFAULT);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_CONNECTION_TIMEOUT_VALUE, connectionTimeOutValue);
                        tsrOptionKeyHKCU.SetValue(Constants.CONST_USE_AUTO_PROXY_VALUE, bUseAutoProxy.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                TSR.Core.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                if (tsrOptionKeyHKCU != null)
                    tsrOptionKeyHKCU.Close();
                if (softwareKeyHKCU != null)
                    softwareKeyHKCU.Close();
            }
        }

        public void RemoveTSROUAOptions(string addinName)
        {
            RegistryKey softwareKey = null;
            try
            {
                //softwareKey = Registry.CurrentUser.OpenSubKey(OUAOptionsLocationRoot, true);
                //if (softwareKey != null)
                //{
                //    if (addinName == OUA2010)
                //    {
                //        softwareKey.DeleteSubKey(OUAOptionsLocation);
                //    }
                //    else if (addinName == OUA2007)
                //    {
                //        softwareKey.DeleteSubKey(OUAOptionsLocation);
                //    }
                //}
            }
            catch (Exception ex)
            {
                LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                if (softwareKey != null)
                    softwareKey.Close();
            }
        }
    }

    class WindowWrapper : System.Windows.Forms.IWin32Window
    {
        public WindowWrapper(IntPtr handle)
        {
            _hwnd = handle;
        }

        public static WindowWrapper GetInstance(string windowTitle)
        {
            IntPtr handle = IntPtr.Zero;
            Process[] procs = Process.GetProcessesByName("msiexec");

            if (null != procs && procs.Length > 0)
            {
                foreach (Process p in procs)
                {
                    if (p.MainWindowTitle.Equals(windowTitle))
                    {
                        handle = p.MainWindowHandle;
                    }
                }
            }
            if (handle != IntPtr.Zero)
                return new WindowWrapper(handle);
            else
                return null;
        }

        public IntPtr Handle
        {
            get { return _hwnd; }
        }

        private IntPtr _hwnd;
    }
}
