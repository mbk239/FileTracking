﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace TSR.Outlook2010.UserAgentSetup
{
    public static class Constants
    {
        public static readonly int DEFAULT_SELECTION_VALUE_INT = -1;
        public static readonly string DEFAULT_RESOURCEKEYS_PATH = "\\Resources\\ResourceKeys.xml";
        public static readonly string DEFAULT_RESOURCEKEYS_TAG_NAME = "Resource";
        public static readonly string DEFAULT_RESOURCE_LANGUAGEID_ATTRIBUTE = "languageid";
        public static readonly string DEFAULT_RESOURCE_KEY_ATTRIBUTE = "key";
        public static readonly string DEFAULT_RESOURCE_NAMESPACE = "http://tsr.outlook.agent/oua_resourcekeys";
        public static readonly string DEFAULT_RESOURCE_NAMESPACE_TAG = "oua_resourcekeys";
        public static readonly string DEFAULT_OUTLOOKFOLDER_SYNC_SEPERATOR = "###";
        public static readonly char DEFAULT_SEPERATOR_PREFERREDLANGUAGE = '|';
        public static readonly char DEFAULT_SEPERATOR_LANGUAGENAME_LANGUAGEID = '#';
        public static readonly string LICENSE_CONFIG_KEY = "License";
        public static readonly string TSR_DEFAULT_CALENDAR_KEY_FOR_SYNC = "Calendar";
        public static readonly string NONEXISTING_OUTLOOK_APPOINTMENT_ID = "blank";
        //public static readonly string NON_OUTLOOK_APPOINTMENT_ID = "non";
        public static readonly string DEFAULT_CULTURE_LCID = "en";
        public static readonly string DEFAULT_LANGUAGE_NAME = "US English";
        public static readonly string DEFAULT_CULTURE_INFO_NAME = "en-US";
        public static readonly string SPACE = " ";
        public static readonly string TRUE_IN_LOWER_CHARS = "true";
        public static readonly string FALSE_IN_LOWER_CHARS = "false";

        /// <summary>
        /// Constant for creating user local data
        /// </summary>
        public static readonly string CONST_XMLFILEPATH = "UserData.xml";

        //Added by tsrdev1
        //Added datetime 10/03/2011
        public static readonly string CONST_INIFILEPATH = "TSROUAOptions.ini";
        public static readonly string CONST_FOLDER_SEPERATOR = "/";

        public static string timesheetReporterLocation = @"Software\Timesheet Reporter";
        public static readonly string CONST_USERSETTINGS_ELEMENT = "UserSettings";
        public static readonly string CONST_USERSETTINGS_ID = "ID";
        public static readonly string CONST_USERSETTINGS_KEY = "Key";
        public static readonly string CONST_USERSETTINGS_VALLUE = "Value";
        public static readonly string CONST_SERVERADDRESS_ID = "8";
        public static readonly string CONST_SERVERADDRESS_KEY = "TSRServerAddress";
        public static readonly string CONST_REGISTRYKEY_SERVERADDRESS = "ServerAddr";
        public static readonly string CONST_WEBINTERFACE_ID = "9";
        public static readonly string CONST_WEBINTERFACE_KEY = "TSRWebinterface";
        public static readonly string CONST_REGISTRYKEY_WEBINTERFACE = "WebInterface";
        public static readonly string CONST_WEBINTERFACE_HELP = "http://www.timesheetreporter.com/support"; //"www.timesheetreporter.com/manual"
        public static readonly string TIMEENTRY_NOTCHANGED = "TIMEENTRY_NOTCHANGED";
        public static readonly string TIMEENTRY_USER_CHANGED = "TimeEntry_User_Changed";
        //Added by tsrdev1
        //Added datetime 25/02/2011
        public static readonly string CONST_CUSTOMERNO_ID = "10";
        public static readonly string CONST_CUSTOMERNO_KEY = "TSRCustomerNo";

        public static readonly string CONST_USERNAME_ID = "11";
        public static readonly string CONST_USERNAME_KEY = "TSRUserName";

        public static readonly string CONST_PASSWORD_ID = "12";
        public static readonly string CONST_PASSWORD_KEY = "TSRPassword";

        public static readonly string CONST_EXCHANGEMODE_ID = "13";
        public static readonly string CONST_EXCHANGEMODE_KEY = "TSRExchangeMode";

        public static readonly string CONST_TSRDONOTASKSETTINGAGAIN_KEY = "TSRDonotAskSettingAgain";

        public static readonly string CONST_CONNECTION_TIMEOUT_VALUE = "ConnectionTimeOutValue";
        public static readonly string CONST_KEEP_EXISTING_VALUE = "KeepExistingValue";

        //Added by tsrdev1
        //Added datetime 13/10/2010
        public static readonly string CONST_REGISTRYKEY_EXCHANGEMODE = "ExchangeMode";
        //End
        //Added by tsrdev1
        //Added datetime 13/10/2010
        public static readonly string CONST_REGISTRYKEY_INSTALLATIONMODE = "InstallationMode";
        public static readonly string CONST_REGISTRYKEY_CUSTOMERNO = "CustomerNo";
        public static readonly string CONST_REGISTRYKEY_USERNAME = "UserName";
        public static readonly string CONST_REGISTRYKEY_PASSWORD = "Password";
        public static readonly string CONST_REGISTRYKEY_CONNECTION_TIMEOUT_VALUE = "ConnectionTimeOutValue";
        //End
        #region Outlook Category Constants
        public static readonly string CATEGORY = "Category";
        public static readonly string APPROVED_CATEGORY = "Approved Category";
        public static readonly string INPROGESS_CATEGORY = "InProgress Category";
        public static readonly string REJECTED_CATEGORY = "Rejected Category";
        public static readonly string ACTIVE_CATEGORY = "Active Category";
        public static readonly string ALLMINUSREJECTED_CATEGORY = "AllMinusRejected Category";
        public static readonly string CANCELLED_CATEGORY = "Cancelled Category";
        public static readonly string ERROR_CATEGORY = "Error Category";
        public static readonly string INACTIVE_CATEGORY = "Inactive Category";
        public static readonly string INSUBMISSIONQUEUE_CATEGORY = "InSubmissionQueue Category";
        public static readonly string PENDINGSUBMISSION_CATEGORY = "PendingSubmission Category";
        public static readonly string SUBMITTED_CATEGORY = "Submitted Category";

        #endregion

        //Added by tsrdev1
        //Added datetime 23/02/2011
        #region OUA Installation Constant
        public static readonly string Y_IN_LOWER_CHARS = "y";
        public static readonly string YES_IN_LOWER_CHARS = "yes";
        public static readonly string BLANK_IN_LOWER_CHARS = "blank";
        public static readonly string CONST_OPTION_VERBOSE = "Verbose";
        public static readonly string CONST_OPTION_INSTALLATIONMODE = "InstallationMode";
        public static readonly string CONST_OPTION_CUSTOMERNO = "CustomerNo";
        public static readonly string CONST_OPTION_TSRSERVICES = "TSRServices";
        public static readonly string CONST_OPTION_TSRWEBADMIN = "TSRWebAdmin";
        public static readonly string CONST_OPTION_EXCHANGEMODE = "ExchangeMode";
        public static readonly string ROOTCATERGORY = "TSROUAOPTIONS";
        public static readonly string CUSTOMERNO_VARIABLENAME = "%OrgId%";
        //End
        public static readonly string CONST_TSRISCHOOSESSL_KEY = "TSRIsChooseSSL";

        public static readonly string CONST_OPTION_OPENMODE = "OpenMode";
        public static readonly string CONST_OPTION_OPENMODE_VALUE_DEFAULT = "0";
        public static readonly string CONST_OPTION_OPENMODE_VALUE_SETTINGSWINDOW = "1";

        public static readonly string CONST_OPTION_SILENTINSTALL = "SilentInstall"; 
        public static readonly string CONST_OPTION_KEEPEXISTINGVALUE = "KeepExistingValue"; 

        #endregion
    }

    public enum ValidationMode
    {
        AD,
        NONAD
    }

    public enum ExchangeMode
    {
        No = 0,
        Yes = 1

    }

    public class UtilityHelper
    {
        #region Variable
        [DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int GetPrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpDefault,
            string lpReturnString,
            int nSize,
            string lpFilename);

        [DllImport("KERNEL32.DLL", EntryPoint = "WritePrivateProfileStringW",
            SetLastError = true,
            CharSet = CharSet.Unicode, ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern int WritePrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpString,
            string lpFilename);
        #endregion Variable
        private const string addinLocation = @"Software\Microsoft\Office\Outlook\Addins";
        private const string TSRINIFilePathKey_Name = "TSRINIFilePath";

        public static bool CheckValidConfigurationFile(string filePath)
        {
            string strValidationMode = GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_INSTALLATIONMODE);
            ValidationMode mode;
            if (!string.IsNullOrEmpty(strValidationMode) && (strValidationMode.ToUpper() == ValidationMode.AD.ToString() ||
                strValidationMode.ToUpper() == ValidationMode.NONAD.ToString()))
                mode = (strValidationMode.ToUpper() == ValidationMode.AD.ToString()) ? ValidationMode.AD : ValidationMode.NONAD;
            else
                return false;
            if (mode == ValidationMode.NONAD)
                if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_CUSTOMERNO)))
                    return false;
            if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRSERVICES)))
                return false;
            if (string.IsNullOrEmpty(GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_TSRWEBADMIN)))
                return false;
            //if (mode == ValidationMode.AD)
            //{
            string strExchangeMode = GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_OPTION_EXCHANGEMODE);
            if (!(!string.IsNullOrEmpty(strExchangeMode) && (strExchangeMode.ToUpper() == ExchangeMode.Yes.ToString().ToUpper() ||
                strExchangeMode.ToUpper() == ExchangeMode.No.ToString().ToUpper())))
                return false;
            //}
            string connectionTimeOutValue = GetValue(filePath, Constants.ROOTCATERGORY, Constants.CONST_CONNECTION_TIMEOUT_VALUE);
            int iTimeoutValue = 0;
            if (!int.TryParse(connectionTimeOutValue, out iTimeoutValue))
                return false;

            return true;
        }
        public static bool IsExistedFile(string filePath)
        {
            return File.Exists(filePath);

        }

        /// <summary>
        /// Store ini file path into registry
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static bool StorteINIFilePath(string filePath)
        {
            RegistryKey userSettingsKey = null;
            RegistryKey TSRINIFilePathKey = null;
            try
            {
                userSettingsKey = Registry.CurrentUser.OpenSubKey(addinLocation, true);
                if (userSettingsKey == null)
                    return false;
                TSRINIFilePathKey = userSettingsKey.OpenSubKey(TSRINIFilePathKey_Name, true);

                if (TSRINIFilePathKey == null)
                {
                    TSRINIFilePathKey = userSettingsKey.CreateSubKey(TSRINIFilePathKey_Name);
                }

                TSRINIFilePathKey.SetValue(TSRINIFilePathKey_Name, filePath);
            }
            catch //(Exception ex)
            {
                return false;
            }
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return true;
        }

        /// <summary>
        /// Read ini file path from registry
        /// </summary>
        /// <returns></returns>
        public static string GetINIFilePath()
        {
            string path = string.Empty;

            RegistryKey userSettingsKey = null;
            RegistryKey TSRINIFilePathKey = null;
            try
            {
                userSettingsKey = Registry.CurrentUser.OpenSubKey(addinLocation, true);
                if (userSettingsKey != null)
                {
                    TSRINIFilePathKey = userSettingsKey.OpenSubKey(TSRINIFilePathKey_Name, true);
                    if (TSRINIFilePathKey != null)
                    {
                        path = TSRINIFilePathKey.GetValue(TSRINIFilePathKey_Name, string.Empty).ToString();
                    }
                }
            }
            catch
            {
            }
            finally
            {
                if (TSRINIFilePathKey != null)
                    TSRINIFilePathKey.Close();
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return path;
        }

        /// <summary>
        /// Remove ini file path key from registry
        /// </summary>
        /// <returns></returns>
        public static bool DeleteINIFilePath()
        {
            RegistryKey userSettingsKey = null;
            try
            {
                userSettingsKey = Registry.CurrentUser.OpenSubKey(addinLocation, true);
                if (userSettingsKey != null)
                {
                    userSettingsKey.DeleteSubKey(TSRINIFilePathKey_Name);
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                if (userSettingsKey != null)
                    userSettingsKey.Close();
            }
            return true;
        }
        /// <summary>
        /// Get value of key in ini file
        /// </summary>
        /// <param name="path"></param>
        /// <param name="cate"></param>
        /// <param name="strKey"></param>
        /// <returns></returns>
        public static string GetValue(string path, string cate, string strKey)
        {
            string defaultValue = "???";
            string iniFile = path;
            string value = string.Empty;
            try
            {
                List<string> categories = GetCategories(iniFile);
                foreach (string category in categories)
                {
                    if (category == cate)
                    {
                        List<string> keys = GetKeys(iniFile, category);
                        foreach (string key in keys)
                        {
                            if (key == strKey)
                            {
                                value = GetIniFileString(iniFile, category, key, defaultValue);
                            }
                        }
                    }
                }
            }
            catch
            {
            }
            if (!string.IsNullOrEmpty(value) && value.ToLower() == Constants.BLANK_IN_LOWER_CHARS.ToLower())
                value = string.Empty;

            return value;
        }

        public static bool SetValue(string path, string cate, string strKey, string strValue)
        {
            string iniFile = path;
            string value = string.Empty;
            try
            {
                List<string> categories = GetCategories(iniFile);
                if (categories.Contains(cate))
                    return SetIniFileString(iniFile, cate, strKey, strValue) > 0;
            }
            catch
            {
            }
            return false;
        }

        /// <summary>
        /// Gets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static string GetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            string returnString = new string(' ', 1024);
            GetPrivateProfileString(category, key, defaultValue, returnString, 1024, iniFile);
            return returnString.Split('\0')[0];
        }

        /// <summary>
        /// Sets the content.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        /// <param name="key">The key.</param>
        /// <param name="defaultValue">The default value.</param>
        /// <returns></returns>
        private static int SetIniFileString(string iniFile, string category, string key, string defaultValue)
        {
            return WritePrivateProfileString(category, key, defaultValue, iniFile);
        }

        /// <summary>
        /// Gets the keys.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <param name="category">The category.</param>
        private static List<string> GetKeys(string iniFile, string category)
        {
            string returnString = new string(' ', 32768);
            GetPrivateProfileString(category, null, null, returnString, 32768, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }

        /// <summary>
        /// Gets the categories.
        /// </summary>
        /// <param name="iniFile">The ini file.</param>
        /// <returns></returns>
        private static List<string> GetCategories(string iniFile)
        {
            string returnString = new string(' ', 65536);
            GetPrivateProfileString(null, null, null, returnString, 65536, iniFile);
            List<string> result = new List<string>(returnString.Split('\0'));
            result.RemoveRange(result.Count - 2, 2);
            return result;
        }

        /// <summary>
        /// Encrypts the sourceString, returns this result as an Aes encrypted, BASE64 encoded string
        /// </summary>
        /// <param name="plainSourceStringToEncrypt">a plain, Framework string (ASCII, null terminated)</param>
        /// <param name="key"></param>
        /// <returns>
        /// returns an Aes encrypted, BASE64 encoded string
        /// </returns>

        public static string EncryptString(string plainSourceStringToEncrypt)
        {
            MD5CryptoServiceProvider mdcsp = new MD5CryptoServiceProvider();
            byte[] b = System.Text.Encoding.UTF8.GetBytes(plainSourceStringToEncrypt);
            b = mdcsp.ComputeHash(b);
            //Convert encoded bytes back to a 'readable' string
            return BitConverter.ToString(b);
        }
    }
}
