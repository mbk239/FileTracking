Product: TSR User Agent 2010
copyright by Contest

Prerequisites:
- Windows XP, Windows Vista, Windows 7
- Microsoft Office Outlook 2010
- .NET Framework 4 Client Profile (Link download http://go.microsoft.com/fwlink/?LinkId=131000)

Run installation: Please click Autorun.bat to install TSR User Agent 2010