﻿cls
# Add Required Type Libraries
Add-Type -Path "C:\Program Files (x86)\WiX Toolset v4.0\bin\WixToolset.Dtf.WindowsInstaller.dll"

$build_configuration = "Release"
#$build_configuration = "Debug"

Function Get-PSScriptRoot
{
    $ScriptRoot = ""

    Try
    {
        $ScriptRoot = Get-Variable -Name PSScriptRoot -ValueOnly -ErrorAction Stop
    }
    Catch
    {
        $ScriptRoot = Split-Path $script:MyInvocation.MyCommand.Path
    }
    return $ScriptRoot 
}

Function Get-CurentVersion
{
    $tempVersion = ""

    Try
    {
        $tempVersion = Get-Variable -Name PSScriptRoot -ValueOnly -ErrorAction Stop
    }
    Catch
    {
        $tempVersion = Split-Path $script:MyInvocation.MyCommand.Path
    }
    return $($tempVersion | Split-Path -Leaf)
}

$base_directory = Get-PSScriptRoot

$curentDate = (Get-Date).ToString('yyyyMMdd')
$curentVersion = Get-CurentVersion

$rootReleaseFolder = "$base_directory\$curentDate $curentVersion"
$releaseFolderName = "$base_directory\$curentDate $curentVersion\Delivery_$curentDate v$curentVersion"
$backupCodeFolder = "$releaseFolderName\Backup_Code\TSR$curentDate" + "_Version $curentVersion"
$installPackageFolder = "$releaseFolderName\Install package"


$oua_solution = "$base_directory\OUA\TSR.OUA.sln"
#$commandline_solution = "$base_directory\CommandLine\TSRDataBridge.sln"
$webadmin_project = "$base_directory\Server\TSR.WebAdmin\website.publishproj"
$webadmin_publishProfile = "TSRWebadminPublish"
$setup_solution = "$base_directory\Setups\TSR.BuildSetupPackage.sln"

$service_project = "$base_directory\Server\TSR.AdvancedServices\website.publishproj"
$service_publishProfile = "TSRServicePublish"
$preBiuldOUAPath = "$base_directory\Setups\TSRUserAgentSetup\TSRUserAgentSetup\PreBuildOUA"
$ouaResourcesPath = "$base_directory\Setups\TSRUserAgentSetup\TSRUserAgentSetup\Resources"
$WebadminSetupBuildPath = "$base_directory\Setups\TSRHosted\TSRHosted\bin\$build_configuration"
$OUASetupBuildPath = "$base_directory\Setups\TSRUserAgentSetup\TSRUserAgentSetup\bin\$build_configuration"
$WebadminPackagePath = "$base_directory\Release Package\TSR SaaS Setup"
$OUAPackagePath = "$base_directory\Release Package\OutlookUserAgent"
$CMDPackagePath = "$base_directory\Release Package\Command Line Setup"

#$solution_file = " $base_directory\$solution_name.sln"
$msBuildPath = "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\MSBuild\15.0\Bin\msbuild.exe"
$devEnvPath = "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\Common7\IDE\devenv.exe”
$aspnetMergePath = "C:\Program Files (x86)\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.6.2 Tools"
$visualStudioVersion = "15.0"

function RebuildSubsystem([string]$solutionPath, [string]$logfileName) 
{   
    $parameters = " /Rebuild ""$build_configuration"" /Out $logfileName ""$solutionPath"""
    write-host "     Start build $solutionPath"
    $process = [System.Diagnostics.Process]::Start( """$devEnvPath""", $parameters )
    $process.WaitForExit()
    write-host "     Build solution $solutionPath done..........."
}

function PublishWebSite([string]$WebsiteProjectPath, [string]$WebsitePublishProfile) 
{
    $parameters = " ""$WebsiteProjectPath"" /flp:logfile=$WebsitePublishProfile.txt;errorsonly /p:DeployOnBuild=true /p:PublishProfile=$WebsitePublishProfile /p:VisualStudioVersion=$visualStudioVersion /p:AspnetMergePath=""$aspnetMergePath"""
    write-host "     Start publish ""$WebsitePublishProfile"""
    $process = [System.Diagnostics.Process]::Start( """$msBuildPath""", $parameters )
    $process.WaitForExit()
    write-host "     Publish $WebsiteProjectPath done..........."
}


$file2010x64 = "2010 Data\x64\TSRUserAgentInstaller.msi"
$file2010x64_silent = "2010 Data\x64\silent\TSRUserAgentInstaller.msi"
$file2010x86 = "2010 Data\x86\TSRUserAgentInstaller.msi"
$file2010x86_silent = "2010 Data\x86\silent\TSRUserAgentInstaller.msi"

$file2013x64 = "2013 Data\x64\TSRUserAgentInstaller.msi"
$file2013x64_silent = "2013 Data\x64\silent\TSRUserAgentInstaller.msi"
$file2013x86 = "2013 Data\x86\TSRUserAgentInstaller.msi"
$file2013x86_silent = "2013 Data\x86\silent\TSRUserAgentInstaller.msi"

$file2010x64_setup = "2010 Data\x64\setup.exe"
$file2010x64_silent_setup = "2010 Data\x64\silent\setup.exe"
$file2010x86_setup = "2010 Data\x86\setup.exe"
$file2010x86_silent_setup = "2010 Data\x86\silent\setup.exe"

$file2013x64_setup = "2013 Data\x64\setup.exe"
$file2013x64_silent_setup = "2013 Data\x64\silent\setup.exe"
$file2013x86_setup = "2013 Data\x86\setup.exe"
$file2013x86_silent_setup = "2013 Data\x86\silent\setup.exe"


function ChangeProductCodeMSI($filePath, $stringProductCode)
{                    
    # Open an MSI Database
    $oDatabase = New-Object WixToolset.Dtf.WindowsInstaller.Database($filePath, [WixToolset.Dtf.WindowsInstaller.DatabaseOpenMode]::Direct);


    #Update AdminUISequence
    $stringUpdate = "Installed<>"""""
    #Create a Select Query against an individual property
    $sSQLQuery = "SELECT * FROM Property WHERE Property= 'ProductCode'"
 
    #Create and Execute a View object
    [WixToolset.Dtf.WindowsInstaller.View]$oView = $oDatabase.OpenView($sSQLQuery)
    $oView.Execute()
 
    #Fetch the Result
    $oRecord = $oView.Fetch()
    $ProductCode = $oRecord.GetString(2)
 
    #Display Retrieved Field
    $temp = "Property = $($ProductCode)"
 
    $oRecord.SetString("Value",$stringProductCode)
    $oView.Modify([WixToolset.Dtf.WindowsInstaller.ViewModifyMode]::Update,$oRecord)
 
    #Close the Database
    $oView.Close();
    $oDatabase.Dispose();
}


function UpdateContentMSI($filePath)
{                    
    # Open an MSI Database
    $oDatabase = New-Object WixToolset.Dtf.WindowsInstaller.Database($filePath, [WixToolset.Dtf.WindowsInstaller.DatabaseOpenMode]::Direct);


    #Update AdminUISequence
    $stringUpdate = "Installed<>"""""
    #Create a Select Query against an individual property
    $sSQLQuery = "SELECT * FROM AdminUISequence WHERE Action= 'AdminFinishedForm'"
 
    #Create and Execute a View object
    [WixToolset.Dtf.WindowsInstaller.View]$oView = $oDatabase.OpenView($sSQLQuery)
    $oView.Execute()
 
    #Fetch the Result
    $oRecord = $oView.Fetch()
    $AdminUISequence = $oRecord.GetString(2)
 
    #Display Retrieved Field
    $temp = "AdminFinishedForm = $($AdminUISequence)"
 
    $oRecord.SetString("Condition",$stringUpdate)
    $oView.Modify([WixToolset.Dtf.WindowsInstaller.ViewModifyMode]::Update,$oRecord)
 
    #Close the Database
    $oView.Close();

    #Update InstallUISequence
    $sSQLQuery = "SELECT * FROM InstallUISequence WHERE Action= 'FinishedForm'"
 
    #Create and Execute a View object
    [WixToolset.Dtf.WindowsInstaller.View]$oView = $oDatabase.OpenView($sSQLQuery)
    $oView.Execute()
 
    #Fetch the Result
    $oRecord = $oView.Fetch()
    $AdminUISequence = $oRecord.GetString(2)
 
    #Display Retrieved Field
    $temp = "FinishedForm = $($AdminUISequence)"
 
    $oRecord.SetString("Condition",$stringUpdate)
    $oView.Modify([WixToolset.Dtf.WindowsInstaller.ViewModifyMode]::Update,$oRecord)
 
    #Close the Database
    $oView.Close();

    $oDatabase.Dispose();
}

function ProcessMSIFiles()
{

    write-host "     Start processing MSI files:"

    xcopy $preBiuldOUAPath\$file2010x64 "$ouaResourcesPath\TSRUserAgentInstaller_x64_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x64_silent "$ouaResourcesPath\Silent_TSRUserAgentInstaller_x64_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x86 "$ouaResourcesPath\TSRUserAgentInstaller_x86_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x86_silent "$ouaResourcesPath\Silent_TSRUserAgentInstaller_x86_2010.*" /Y /Q

    xcopy $preBiuldOUAPath"\"$file2013x64 "$ouaResourcesPath\TSRUserAgentInstaller_x64_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x64_silent "$ouaResourcesPath\Silent_TSRUserAgentInstaller_x64_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x86 "$ouaResourcesPath\TSRUserAgentInstaller_x86_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x86_silent "$ouaResourcesPath\Silent_TSRUserAgentInstaller_x86_2013_2016.*" /Y /Q

    xcopy $preBiuldOUAPath"\"$file2010x64_setup "$ouaResourcesPath\setup_x64_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x64_silent_setup "$ouaResourcesPath\Silent_setup_x64_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x86_setup "$ouaResourcesPath\setup_x86_2010.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2010x86_silent_setup "$ouaResourcesPath\Silent_setup_x86_2010.*" /Y /Q

    xcopy $preBiuldOUAPath"\"$file2013x64_setup "$ouaResourcesPath\setup_x64_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x64_silent_setup "$ouaResourcesPath\Silent_setup_x64_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x86_setup "$ouaResourcesPath\setup_x86_2013_2016.*" /Y /Q
    xcopy $preBiuldOUAPath"\"$file2013x86_silent_setup "$ouaResourcesPath\Silent_setup_x86_2013_2016.*" /Y /Q

    $newProductCode = "{" + [System.Guid]::NewGuid().toString().ToUpper() + "}"

    Get-ChildItem $ouaResourcesPath -Filter *.msi | 
    Foreach-Object {    
        ChangeProductCodeMSI $_.FullName $newProductCode
        UpdateContentMSI($_.FullName)
    }
}

 function RecursiveDelete($theroot) {
  $children = Get-ChildItem -Path $theroot | where-object { $_.Attributes -eq "Directory"} |% {$_.FullName}
  foreach($achild in $children) {
  	if ($achild -ne $null) {
    	    RecursiveDelete $achild
	}
  }
  Remove-Item $theroot -recurse -force 
}

function BackupCode()
{
   #Backup Code     
    svn export --force --quiet "$base_directory" "$backupCodeFolder"
}

function RemoveOldReleaseFolder()
{
   if ((Test-Path $rootReleaseFolder)) { 
       New-Item -Path "$base_directory\EmptyFolder" -ItemType Directory
       robocopy /MIR $base_directory\EmptyFolder $rootReleaseFolder
       Remove-Item "$base_directory\EmptyFolder" -recurse -force        
   }       

   if (!(Test-Path $backupCodeFolder)) { 
    New-Item -Path $backupCodeFolder -ItemType Directory
   }

   if (!(Test-Path $installPackageFolder)) { 
    New-Item -Path $installPackageFolder -ItemType Directory
   }

}

function PackagingRelease()
{
    #Copy Install files
    write-host "     Copy Database Scripts:"
    xcopy "$base_directory\Setups\TSRHosted\TSRHosted\Database\Scripts\*" "$WebadminPackagePath\Database\Scripts" /Y /S /I /Q

    write-host "     Copy Upgrade Database Scripts:"
    xcopy "$base_directory\Setups\TSRHosted\TSRHosted\Upgrade\*" "$WebadminPackagePath\Upgrade" /Y /S /I /Q

    write-host "     Copy TSRHosted INI files:"
    xcopy "$base_directory\Setups\TSRHosted\TSRHosted\*.ini" "$WebadminPackagePath\*.ini" /Y /Q
    #xcopy "$base_directory\Setups\TSRHosted\TSRHosted\datademo.ini" "$WebadminPackagePath\datademo.*" /Y /Q

    write-host "     Copy TSRHosted setup files:"
    xcopy "$WebadminSetupBuildPath\TSR.Framework.dll" "$WebadminPackagePath\TSR.Framework.*" /Y /Q
    xcopy "$WebadminSetupBuildPath\TSRHosted.exe" "$WebadminPackagePath\TSRHosted.*" /Y /Q

    write-host "     Copy OUA setup files:"
    xcopy "$OUASetupBuildPath\TSROUAOptions.ini" "$OUAPackagePath\TSROUAOptions.*" /Y /Q
    xcopy "$OUASetupBuildPath\TSRUserAgentSetup.exe" "$OUAPackagePath\TSRUserAgentSetup.*" /Y /Q

    write-host "     Copy Hosted Setup files:"
    xcopy "$WebadminPackagePath\*" "$installPackageFolder\TSR SaaS Setup" /Y /S /I /Q
    write-host "     Copy Outlook User Agent files:"
    xcopy "$OUAPackagePath\*" "$installPackageFolder\OutlookUserAgent" /Y /S /I  /Q    

    write-host "     Copy Command Line setup files:"
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\Data\*" "$installPackageFolder\Conmmand Line Setup\Data" /Y /S /I /Q
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\Autorun.bat" "$installPackageFolder\Conmmand Line Setup\Autorun.*" /Y /Q
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\CommandLineSetup.exe" "$installPackageFolder\Conmmand Line Setup\CommandLineSetup.*" /Y /Q
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\Readme.txt" "$installPackageFolder\Conmmand Line Setup\Readme.*" /Y /Q
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\DBRRuntimeOptions.ini" "$installPackageFolder\Conmmand Line Setup\DBRRuntimeOptions.*" /Y /Q
    xcopy "$base_directory\Setups\ExternalCommandLineSetup\bin\Release\TSR.CommandLine.Core.dll" "$installPackageFolder\Conmmand Line Setup\TSR.CommandLine.Core.*" /Y /Q

}



    write-host "---------------------------- Remove Old Release Folder"

RemoveOldReleaseFolder

    write-host "---------------------------- End Remove Old Release Folder"
    write-host ""
    write-host "---------------------------- Publish WebAdmin"

PublishWebSite $webadmin_project $webadmin_publishProfile

    write-host "---------------------------- End Publish WebAdmin"
    write-host ""
    write-host "---------------------------- Publish Services"

PublishWebSite $service_project $service_publishProfile

    write-host "---------------------------- End Publish Services"
    write-host ""
    write-host "---------------------------- Build Command Line"

RebuildSubsystem $commandline_solution "CmdBuildLog.txt"

    write-host "---------------------------- End  Command Line"
    write-host ""
    write-host "---------------------------- Build OUA"

RebuildSubsystem $oua_solution "OUABuildLog.txt"

    write-host "---------------------------- End Build OUA"
    write-host ""
    write-host "---------------------------- Change MSI properties"

ProcessMSIFiles

    write-host "---------------------------- End Change MSI properties"
    write-host ""
    write-host "---------------------------- Build OUA Setup"

RebuildSubsystem $setup_solution "SetupBuildLog.txt"

    write-host "---------------------------- End Build OUA Setup"
    write-host ""
    write-host "---------------------------- Package release"

PackagingRelease

    write-host "---------------------------- End Package release"
    write-host ""
    write-host "---------------------------- Backup Code"

BackupCode

    write-host "---------------------------- End Backup Code"

write-host "     New Product Code: " $newProductCode
$psise.CurrentPowerShellTab.ConsolePane.Text | Set-Content -Path ISEOutput.txt

