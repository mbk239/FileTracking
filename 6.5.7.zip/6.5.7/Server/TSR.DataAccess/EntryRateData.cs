﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.DataAccess
{
    public class EntryRateData : BaseDataAccess
    {
        private const string INSERTENTRYRATE = "InsertEntryRate";
        private const string UPDATEENTRYRATE = "UpdateEntryRate";
        private const string DELETEENTRYRATE = "DeleteEntryRate";
        private const string GETALLENTRYRATE = "GetAllEntryRate";
        private static BaseDataAccess LOCK_EntryRate;
        public EntryRateData(UserContext context) : base(context)
        {
            LOCK_EntryRate = this;
        }
        public EntryRateData(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
            LOCK_EntryRate = this;
        }

        #region FillData
        public EntryRateList GetAllEntryRate()
        {
            SqlCommand cmd = GetSPCommand(GETALLENTRYRATE);
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        private EntryRateList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            var list = new EntryRateList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    var entryRateObj = new EntryRate();
                    FillObject(entryRateObj, reader);
                    list.Add(entryRateObj);
                }

                reader.Close();
            }

            return list;
        }
        protected void FillObject(EntryRate entryRateObj, SqlDataReader reader)
        {
            FillObject(entryRateObj, reader, 0);
        }
        protected void FillObject(EntryRate entryRateObj, SqlDataReader reader, int start)
        {
            entryRateObj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            entryRateObj.ID = reader.GetInt64(start + 0);
            entryRateObj.Cost = reader[start + 1] != null ? reader.GetDecimal(start + 1) : 0;
            entryRateObj.Revenue = reader[start + 2] != null ? reader.GetDecimal(start + 2) : 0;
        }
        #endregion

        #region Insert Data
        public long Insert(EntryRate entryRateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTENTRYRATE);

                AddParameter(cmd, pInt64Out(Rate.Property_ID, entryRateObject.ID));
                AddParameter(cmd, pDecimal(Rate.Property_Cost, entryRateObject.Cost));
                AddParameter(cmd, pDecimal(Rate.Property_Revenue, entryRateObject.Revenue));
                AddBaseParametersForInsert(cmd, entryRateObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    entryRateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, Rate.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(entryRateObject, x);
            }
        }
    }
    #endregion
}
