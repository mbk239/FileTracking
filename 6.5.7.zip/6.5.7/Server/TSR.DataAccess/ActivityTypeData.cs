using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ActivityTypeData
	{
        private const string GETACTIVITYTYPEBYACTIVITYTYPENAME = "GetActivityTypeByActivityTypeName";
        private const string GETACTIVITYTYPEFORPAGING = "GetActivityTypeForPaging";

        /// <summary>
        /// Retrieves ActivityType by ActivityType name
        /// </summary>
        /// <param name="ActivityTypeName"></param>
        /// <returns></returns>
        public ActivityType GetActivityTypeByActivityTypeName(string ActivityTypeName)
        {
            using (SqlCommand cmd = GetSPCommand(GETACTIVITYTYPEBYACTIVITYTYPENAME))
            {
                AddParameters(cmd, pNVarChar(ActivityTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ActivityTypeName));
                return GetObject(cmd);
            }
        }

        public ActivityTypeList GetActivityTypePaging(int startOffset, int numberOfItems, string name, out int total)
        {
            ActivityTypeList lst = new ActivityTypeList();
            using (SqlCommand cmd = GetSPCommand(GETACTIVITYTYPEFORPAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);
                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }
    }
}

