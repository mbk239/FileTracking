using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    /// <summary>
    /// Organization data access class.
    /// 
    /// last updated on:
    /// september 4th, 2009
    /// change description:
    /// </summary>
    public partial class OrganizationData
    {
        private const string GETORGANIZATIONBYORGANIZATIONNAME = "GetOrganizationByOrganizationName";
        private const string GETALLORGANIZATIONVIEW = "GetAllOrganizationView";
        private const string GETALLORGANIZATIONFOREXPORT = "GetAllOrganizationForExport";

        /// <summary>
        /// Retrieves Organization by Organization name
        /// </summary>
        /// <param name="OrganizationName"></param>
        /// <returns></returns>
        public Organization GetOrganizationByOrganizationName(string OrganizationName)
        {
            SqlCommand cmd = GetSPCommand(GETORGANIZATIONBYORGANIZATIONNAME);
            AddParameters(cmd, pNVarChar(OrganizationBase.Property_Name, 255, OrganizationName));
            return GetObject(cmd);
        }

        /// <summary>
        /// Retrieves All Organizations View
        /// </summary>        
        /// <returns>OrganizationViewList</returns>
        public OrganizationViewList GetAllOrganizationsView()
        {
            OrganizationViewList list = new OrganizationViewList();           
            using (SqlCommand cmd = GetSPCommand(GETALLORGANIZATIONVIEW))            
            {
                 SqlDataReader reader;
                long result = SelectRecords(cmd, out reader);
                long rows = ALL_AVAILABLE_RECORDS;
                using (reader)
                {
                    while (reader.Read() && rows-- != 0)
                    {
                        int start = 0;
                        OrganizationView orgViewObject = new OrganizationView();
                        orgViewObject.ID = reader.GetInt64(start + 0);
                        if (!reader.IsDBNull(start + 1)) orgViewObject.OrganizationForeignKey = ReverseToHTMLCode(reader.GetString(start + 1));
                        orgViewObject.Name = ReverseToHTMLCode(reader.GetString(start + 2));
                        if (!reader.IsDBNull(start + 3)) orgViewObject.Description = ReverseToHTMLCode(reader.GetString(start + 3));
                        if (!reader.IsDBNull(start + 4)) orgViewObject.AddressID = reader.GetInt64(start + 4);
                        if (!reader.IsDBNull(start + 5)) orgViewObject.AddressTypeID = reader.GetInt64(start + 5);
                        if (!reader.IsDBNull(start + 6)) orgViewObject.AddressTypeName = ReverseToHTMLCode(reader.GetString(start + 6));
                        if (!reader.IsDBNull(start + 7)) orgViewObject.Street1 = ReverseToHTMLCode(reader.GetString(start + 7));
                        if (!reader.IsDBNull(start + 8)) orgViewObject.Street2 = ReverseToHTMLCode(reader.GetString(start + 8));
                        if (!reader.IsDBNull(start + 9)) orgViewObject.City = ReverseToHTMLCode(reader.GetString(start + 9));
                        if (!reader.IsDBNull(start + 10)) orgViewObject.State = ReverseToHTMLCode(reader.GetString(start + 10));
                        if (!reader.IsDBNull(start + 11)) orgViewObject.ZipCode = ReverseToHTMLCode(reader.GetString(start + 11));
                      //  if (!reader.IsDBNull(start + 12)) orgViewObject.CountryID = reader.GetInt64(start + 12);
                      //  if (!reader.IsDBNull(start + 13)) orgViewObject.CountryName = reader.GetString(start + 13);                        
                        if (!reader.IsDBNull(start + 12)) orgViewObject.CountryName = ReverseToHTMLCode(reader.GetString(start + 12));
                        //if (!reader.IsDBNull(start + 18)) orgViewObject.OrganizationTypeID = reader.GetInt64(start + 18);
                        //if (!reader.IsDBNull(start + 19)) orgViewObject.OrganizationTypeName = ReverseToHTMLCode(reader.GetString(start + 19));
                       // orgViewObject.OrganizationTypeID = Int64.Parse(reader["OrganizationTypeID"].ToString());
                       // orgViewObject.OrganizationTypeName = ReverseToHTMLCode(reader["OrganizationTypeName"].ToString());
                        list.Add(orgViewObject);
                    }

                    reader.Close();
                }
            }
            return list;
        }
    }
}

