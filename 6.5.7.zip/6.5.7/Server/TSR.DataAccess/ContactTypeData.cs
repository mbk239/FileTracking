﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Entities;
using System.Data.SqlClient;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
  public partial  class ContactTypeData
    {

      private const string GETCONTACTTYPEBYCONTACTTYPENAME = "GetContactTypeByContactTypeName";

        /// <summary>
        /// Retrieves ContactType by ContactType name
        /// </summary>
        /// <param name="ContactTypeName"></param>
        /// <returns></returns>
        public ContactType GetContactTypeByContactTypeName(string ContactTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETCONTACTTYPEBYCONTACTTYPENAME);
            AddParameters(cmd, pNVarChar(ContactTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ContactTypeName));
            return GetObject(cmd);
        }
    }
}
