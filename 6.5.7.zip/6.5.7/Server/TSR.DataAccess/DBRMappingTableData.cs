using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

using TSR.Entities.Bases;
using TSR.Entities;

namespace TSR.DataAccess
{
    /// <summary>
    /// DBRMappingTableData - Data Access class for DBRMappingTable
    /// </summary>
    public partial class DBRMappingTableData
    {
        private const string GETDBRMAPPINGTABLEBYSOURCEIDAPPLICATIONID = "GetDBRMappingBySourceID_ApplicationID";
        private const string GETDBRMAPPINGTABLEBYSOURCEIDAPPLICATIONIDENTITYTYPEID = "GetDBRMappingBySourceID_ApplicationID_EntityTypeID";
        private const string GETTOP1DBRMAPPINGTABLEBYSOURCEIDAPPLICATIONIDENTITYTYPEID = "GetTop1DBRMappingBySourceID_ApplicationID_EntityTypeID";
        private const string GETDBRMAPPINGBYDESTINATIONIDENTITYTYPEID = "GetDBRMappingByDestinationID_EntityTypeID";

        public DBRMappingTable GetByDestinationIDEntityTypeID(string destinationID, int entityTypeID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDBRMAPPINGBYDESTINATIONIDENTITYTYPEID))
            {
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_DestinationID, 255, destinationID));
                AddParameters(cmd, pInt32(DBRMappingTableBase.Property_EntityTypeID, entityTypeID));
                return GetObject(cmd);
            }
        }
        
        /// <summary>
        /// retrieves source id by application id. useful for checking whether same entity were added from same application
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="applicationID"></param>
        /// <returns></returns>
        public DBRMappingTable GetBySourceIDApplicationID(string sourceID, string applicationID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDBRMAPPINGTABLEBYSOURCEIDAPPLICATIONID))
            {
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_SourceID, 255, sourceID));
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_ApplicationID, 255, applicationID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// added be tsrdev2
        /// gets DBRMappingTable from source id, application id and entity type id
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="applicationID"></param>
        /// <param name="entityTypeID"></param>
        /// <returns></returns>
        public DBRMappingTable GetBySourceIDApplicationIDEntityTypeID(string sourceID, string applicationID, int entityTypeID)
        {
            using (SqlCommand cmd = GetSPCommand(GETTOP1DBRMAPPINGTABLEBYSOURCEIDAPPLICATIONIDENTITYTYPEID))
            {
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_SourceID, 255, sourceID));
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_ApplicationID, 255, applicationID));
                AddParameters(cmd, pInt32(DBRMappingTableBase.Property_EntityTypeID, entityTypeID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// added be tsrdev2
        /// gets DBRMappingTable from source id, application id and entity type id
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="applicationID"></param>
        /// <param name="entityTypeID"></param>
        /// <returns></returns>
        public DBRMappingTableList GetAllBySourceIDApplicationIDEntityTypeID(string sourceID, string applicationID, int entityTypeID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDBRMAPPINGTABLEBYSOURCEIDAPPLICATIONIDENTITYTYPEID))
            {
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_SourceID, 255, sourceID));
                AddParameters(cmd, pNVarChar(DBRMappingTableBase.Property_ApplicationID, 255, applicationID));
                AddParameters(cmd, pInt32(DBRMappingTableBase.Property_EntityTypeID, entityTypeID));

                return GetList(cmd,-1);
            }
        }

        public DBRMappingTableList GetDBRMappingUserForExport()
        {
            using (SqlCommand cmd = GetSPCommand("GetDBRMappingUserForExport"))
            {
                return GetList(cmd, -1);
            }
        }

        public DBRMappingTableList GetDBRMappingContactForExport()
        {
            using (SqlCommand cmd = GetSPCommand("GetDBRMappingContactForExport"))
            {
                return GetList(cmd, -1);
            }
        }

        public DBRMappingTableList GetDBRMappingActivityForExport()
        {
            using (SqlCommand cmd = GetSPCommand("GetDBRMappingActivityForExport"))
            {
                return GetList(cmd, -1);
            }
        }

        public DBRMappingTableList GetDBRMappingProjectForExport()
        {
            using (SqlCommand cmd = GetSPCommand("GetDBRMappingProjectForExport"))
            {
                return GetList(cmd, -1);
            }
        }

        public DBRMappingTableList GetDBRMappingOrganizationForExport()
        {
            using (SqlCommand cmd = GetSPCommand("GetDBRMappingOrganizationForExport"))
            {
                return GetList(cmd, -1);
            }
        }
    }
}
