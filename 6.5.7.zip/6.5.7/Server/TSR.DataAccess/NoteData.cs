using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// NoteData
    /// </summary>
	public partial class NoteData
	{
        private const string GETNOTESBYTIMEENTRYID = "GetNotesByTimeEntryID";

        /// <summary>
        /// retreievs notes by time entry id
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public NoteList GetNotesByTimeEntryID(Guid timeEntryID)
        {
            using (SqlCommand cmd = GetSPCommand(GETNOTESBYTIMEENTRYID))
            {
                AddParameter(cmd, pGuid(TimeEntry_Note.Property_TimeEntryID, timeEntryID));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}

