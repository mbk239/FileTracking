﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Address_CommDetailData
    /// </summary>
    public partial class Address_CommDetailData
    {
        private const string DELETEADDRESSCOMMDETAIL_BY_ADDRESS_COMMDETAIL = "DeleteAddressCommDetailByAddressID_CommDetailID";

        /// <summary>
        /// adds a relation between address and communication details
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Add(long parentID, long childID)
        {
            Address_CommDetailBase obj = new Address_CommDetailBase();
            obj.AddressID = parentID;
            obj.CommDetailID = childID;

            return Insert(obj);
        }

        /// <summary>
        /// removes a relation between address and communication details
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Remove(long parentID, long childID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEADDRESSCOMMDETAIL_BY_ADDRESS_COMMDETAIL);

                AddParameters(cmd, pInt64(Address_CommDetail.Property_AddressID, parentID));
                AddParameters(cmd, pInt64(Address_CommDetail.Property_CommDetailID, childID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Address_CommDetail), parentID, x);
            }

        }
    }
}
