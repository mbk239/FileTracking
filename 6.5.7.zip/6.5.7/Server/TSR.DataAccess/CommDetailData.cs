using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// CommDetailData:
    /// communication details data access.
    /// example communication methods: Email, Phone, Skype, etc.
    /// 
    /// last updated on:
    /// september 4th, 2009
    /// change description:
    /// </summary>
    public partial class CommDetailData
    {
        private const string GETCOMMDETAILSBYPERSONID = "GetCommDetailsByPersonID";
        private const string GETCOMMDETAILSBYADDRESSID = "GetCommDetailsByAddressID";
        /// <summary>
        /// Retrieve communication details for a Person.
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="personID">Person ID</param>
        /// <returns>List of Communication Methods/Details</returns>
        public CommDetailList GetCommDetailsByPersonID(long personID)
        {
            SqlCommand cmd = GetSPCommand(GETCOMMDETAILSBYPERSONID);
            AddParameters(cmd, pInt64(Person_CommDetail.Property_PersonID, personID));
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        /// <summary>
        /// Retrieve communication details for an Address.
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="organizationID">Address ID</param>
        /// <returns>List of communication methods/details for the address</returns>
        public CommDetailList GetCommDetailsByAddressID(long addressID)
        {
            SqlCommand cmd = GetSPCommand(GETCOMMDETAILSBYADDRESSID);
            AddParameters(cmd, pInt64(Address_CommDetail.Property_AddressID, addressID));
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

    }
}

