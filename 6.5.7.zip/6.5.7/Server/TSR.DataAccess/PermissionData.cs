using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// PermissionData:
    /// Used for various data access of Permissions
    /// By Role ID,
    /// By User ID.
    /// 
    /// last updated on:
    /// september 4th, 2009
    /// change description:
    /// </summary>
    public partial class PermissionData
    {
        private const string GETPERMISSIONSBYROLEID = "GetPermissionsByRoleID";
        private const string GETPERMISSIONSBYUSERID = "GetPermissionsByUserID";
        private const string GETCHILDPERMISSIONSBYPERMISSIONKEY = "GetChildPermissionsByPermissionKey";
        private const string GETPERMISSIONBYPERMISSIONKEY = "GetPermissionByPermissionKey";
        private const string GETPERMISSIONSBYINACTIVEROLEID = "GetPermissionsByInactiveRoleID";

        
        /// <summary>
        /// Retrieve all Permissions for a Role.
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="roleID">Role ID</param>
        /// <returns>List of Permissions</returns>
        public PermissionList GetPermissionsByRoleID(long roleID)
        {
            SqlCommand cmd = GetSPCommand(GETPERMISSIONSBYROLEID);

            AddParameters(cmd, pInt64(Role_PermissionBase.Property_RoleID, roleID));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

        //Feature 205 - Active and Inactive Role
        //Added by tsrdev2 - 26 Sep 2012
        /// <summary>
        /// Retrieve all Permissions for a Role.        
        /// </summary>
        /// <param name="roleID">Role ID</param>
        /// <returns>List of Permissions</returns>
        public PermissionList GetPermissionsByInactiveRoleID(long roleID)
        {
            SqlCommand cmd = GetSPCommand(GETPERMISSIONSBYINACTIVEROLEID);

            AddParameters(cmd, pInt64(Role_PermissionBase.Property_RoleID, roleID));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

        /// <summary>
        /// Retrieve all Permissions for a User.
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="userID">User ID</param>
        /// <returns>List of Permissions</returns>
        public PermissionList GetPermissionsByUserID(long userID)
        {
            SqlCommand cmd = GetSPCommand(GETPERMISSIONSBYUSERID);

            AddParameters(cmd, pInt64(User_RoleBase.Property_UserID, userID));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        /// <summary>
        /// Retrieve child Permissions for a Permission (by Permission Key)
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="permissionKey">Permission Key</param>
        /// <returns>List of child Permissions</returns>
        public PermissionList GetChildPermissionsByPermissionKey(string permissionKey)
        {
            SqlCommand cmd = GetSPCommand(GETCHILDPERMISSIONSBYPERMISSIONKEY);

            AddParameter(cmd, pNVarChar(PermissionBase.Property_PermissionKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionKey));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

      
        /// <summary>
        /// Retrieves Permission by Permission key
        /// </summary>
        /// <param name="PermissionName"></param>
        /// <returns></returns>
        public Permission GetPermissionByPermissionKey(string PermissionKey)
        {
            SqlCommand cmd = GetSPCommand(GETPERMISSIONBYPERMISSIONKEY);
            AddParameters(cmd, pNVarChar(PermissionBase.Property_PermissionKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, PermissionKey));
            return GetObject(cmd);
        }
    }
}

