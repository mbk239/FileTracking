using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Organization_ContactData
    /// </summary>
    public partial class Organization_ContactData
    {
        private const string DELETEORGANIZATIONCONTACT_BY_ORGANIZATION_CONTACT = "DeleteOrganizationContactByOrganizationID_ContactID";

        /// <summary>
        /// adds a relation between organization and contact
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Add(long parentID, long childID)
        {
            Organization_ContactBase obj = new Organization_ContactBase();
            obj.OrganizationID = parentID;
            obj.ContactID = childID;

            return Insert(obj);
        }

        /// <summary>
        /// removes a relation between organization and contact
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Remove(long parentID, long childID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEORGANIZATIONCONTACT_BY_ORGANIZATION_CONTACT);

                AddParameters(cmd, pInt64(Organization_Contact.Property_OrganizationID, parentID));
                AddParameters(cmd, pInt64(Organization_Contact.Property_ContactID, childID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Organization_Contact), parentID, x);
            }

        }

        
    }
}

