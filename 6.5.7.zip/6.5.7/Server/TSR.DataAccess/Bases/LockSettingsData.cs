﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public class LockSettingsData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_LockSettings;

        private const string INSERTLOCKUSERSETTINGS = "InsertLockUserSettings";
        private const string UPDATELOCKUSERSETTINGS = "UpdateLockUserSettings";
        private const string DELETELOCKUSERSETTINGS = "DeleteLockUserSettings";
        private const string GETLOCKUSERSETTINGSBYID = "GetLockUserSettingsByID";
        private const string GETLOCKUSERSETTINGSBYUSERID = "GetLockUserSettingsByUserID";

        #region Contructors
        public LockSettingsData(UserContext context) : base(context) { LOCK_LockSettings = this; }
        public LockSettingsData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_LockSettings = this; }
        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="activityObject"></param>
        private void AddCommonParams(SqlCommand cmd, LockUserSettingsBase lockObject)
        {
            AddParameter(cmd, pInt64(LockUserSettingsBase.Property_UserID, lockObject.UserID));
            AddParameter(cmd, pBool(LockUserSettingsBase.Property_IsLocked,lockObject.IsLocked));            
        }

        public LockUserSettings Get(long id)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCKUSERSETTINGSBYID))
            {
                AddParameters(cmd, pInt64(LockUserSettings.Property_ID, id));

                return GetObject(cmd);
            }
        }

        public LockUserSettings GetByUserID(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCKUSERSETTINGSBYUSERID))
            {
                AddParameters(cmd, pInt64(LockUserSettings.Property_UserID, userID));

                return GetObject(cmd);
            }
        }

        public long Insert(LockUserSettingsBase obj)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTLOCKUSERSETTINGS);

                AddParameter(cmd, pInt64Out(LockUserSettingsBase.Property_ID, obj.ID));
                AddCommonParams(cmd, obj);
                AddBaseParametersForInsert(cmd, obj);

                long result = InsertRecord(cmd);
                if (result > 0)
                    obj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, LockUserSettingsBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(obj, x);
            }
        }

        public long Update(LockUserSettingsBase obj)
        {
            lock (LOCK_LockSettings)
            {
                try
                {
                    LockUserSettingsBase dbObject = GetByUserID(obj.UserID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(obj, null);

                    //else if (dbObject.ModifiedTimeStamp.ToString() != obj.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != activityObject.ModifiedTimeStamp)
                    //    throw new Framework.Exceptions.DataIntegrityFailedException(obj, null);

                    dbObject.CloneBase(obj);

                    SqlCommand cmd = GetSPCommand(UPDATELOCKUSERSETTINGS);

                    AddParameter(cmd, pInt64(LockUserSettingsBase.Property_ID, obj.ID));
                    AddCommonParams(cmd, obj);
                    AddBaseParametersForUpdate(cmd, obj);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        obj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(obj, x);
                }
            }            
        }

        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETELOCKUSERSETTINGS);

                AddParameters(cmd, pInt64(LockUserSettings.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(LockUserSettings), ID, x);
            }
        }

        /// <summary>
        /// Retrieves LockUserSettings object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>LockUserSettings object</returns>
        private LockUserSettings GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    LockUserSettings lockObject = new LockUserSettings();
                    FillObject(lockObject, reader);
                    return lockObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Fills LockUserSettings object
        /// </summary>
        /// <param name="activityObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(LockUserSettingsBase lockObject, SqlDataReader reader, int start)
        {
            lockObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            lockObject.ID = reader.GetInt64(start + 0);
            lockObject.UserID = reader.GetInt64(start + 1);
            lockObject.IsLocked = reader.GetBoolean(start + 2);
            
            FillBaseObject(lockObject, reader, (start + 3));
        }

        protected void FillObject(LockUserSettingsBase lockObject, SqlDataReader reader)
        {
            FillObject(lockObject, reader, 0);
        }
    }
}
