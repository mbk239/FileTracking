using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Project_ActivityData : BaseRelationData
	{
		private const string INSERTPROJECT_ACTIVITY = "InsertProject_Activity";
		private const string UPDATEPROJECT_ACTIVITY = "UpdateProject_Activity";
		private const string DELETEPROJECT_ACTIVITY = "DeleteProject_Activity";
		private const string GETPROJECT_ACTIVITYBYID = "GetProject_ActivityByID";
		private const string GETALLPROJECT_ACTIVITY = "GetAllProject_Activity";
        private const string DELETEPROJECT_ACTIVITYBYPROJECTID = "DeleteProject_ActivityByProjectID";

        private const string GETALLPROJECT_ACTIVITYFORUSER = "GetAllProject_ActivityForUser";

        #region Constructors

		public Project_ActivityData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="project_ActivityObject"></param>
		private void AddCommonParams( SqlCommand cmd, Project_ActivityBase project_ActivityObject )
		{
			AddParameter(cmd, pInt64(Project_ActivityBase.Property_ProjectID, project_ActivityObject.ProjectID));
			AddParameter(cmd, pInt64(Project_ActivityBase.Property_ActivityID, project_ActivityObject.ActivityID));
		}

        /// <summary>
        /// Inserts Project_Activity
        /// </summary>
        /// <param name="project_ActivityObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Project_ActivityBase project_ActivityObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPROJECT_ACTIVITY );
	
				AddParameter(cmd, pInt64Out(Project_ActivityBase.Property_ID, project_ActivityObject.ID));
				AddCommonParams( cmd, project_ActivityObject );
				AddBaseParametersForInsert( cmd, project_ActivityObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					project_ActivityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Project_ActivityBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( project_ActivityObject, x );
			}
		}
		
        /// <summary>
        /// Updates Project_Activity 
        /// </summary>
        /// <param name="project_ActivityObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Project_ActivityBase project_ActivityObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEPROJECT_ACTIVITY );

				AddParameter(cmd, pInt64(Project_ActivityBase.Property_ID, project_ActivityObject.ID));
				AddCommonParams( cmd, project_ActivityObject );
				AddBaseParametersForUpdate( cmd, project_ActivityObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					project_ActivityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( project_ActivityObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Project_Activity
        /// </summary>
        /// <param name="ID">ID of the Project_Activity object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECT_ACTIVITY );
	
				AddParameters( cmd, pInt64( Project_Activity.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Project_Activity ), ID, x );
			}
			
		}

        public long DeleteByProjectID(long projectID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEPROJECT_ACTIVITYBYPROJECTID);

                AddParameters(cmd, pInt64(Project_Activity.Property_ProjectID, projectID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Project_Activity), projectID, x);
            }
        }

        /// <summary>
        /// Retrieves Project_Activity object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Project_Activity object to retrieve</param>
        /// <returns>A Project_Activity object, null if not found</returns>
		public Project_Activity Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPROJECT_ACTIVITYBYID) )
			{
				AddParameters( cmd, pInt64( Project_Activity.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Project_Activity objects 
        /// </summary>
        /// <returns>A list of Project_Activity objects</returns>
		public Project_ActivityList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPROJECT_ACTIVITY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Project_Activity object
        /// </summary>
        /// <param name="project_ActivityObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Project_ActivityBase project_ActivityObject, SqlDataReader reader, int start )
		{
			project_ActivityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			project_ActivityObject.ID = reader.GetInt64(start + 0);
			project_ActivityObject.ProjectID = reader.GetInt64(start + 1);
			project_ActivityObject.ActivityID = reader.GetInt64(start + 2);
			FillBaseObject(project_ActivityObject, reader, (start + 3));
		}

		protected void FillObject( Project_ActivityBase project_ActivityObject, SqlDataReader reader )
		{
			FillObject( project_ActivityObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Project_Activity object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Project_Activity object</returns>
		private Project_Activity GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Project_Activity project_ActivityObject= new Project_Activity();
					FillObject( project_ActivityObject, reader );
					return project_ActivityObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Project_Activity objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Project_Activity objects</returns>
		private Project_ActivityList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Project_ActivityList list = new Project_ActivityList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Project_Activity project_ActivityObject = new Project_Activity();
					FillObject( project_ActivityObject, reader );

					list.Add( project_ActivityObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}
        /// <summary>
        /// Get all project activity for user
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Project_ActivityList GetAllForUser(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLPROJECT_ACTIVITYFORUSER))
            {
                AddParameter(cmd, pInt64("UserID", userID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}

