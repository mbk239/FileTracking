using System;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class UserData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_User;
		private const string INSERTUSER = "InsertUser";
		private const string UPDATEUSER = "UpdateUser";
        private const string DELETEUSER = "DeleteUser";        
		private const string GETUSERBYID = "GetUserByID";
		private const string GETALLUSER = "GetAllUser";
        private const string GETALLUSERISACTIVE = "GetAllUserIsActive";
        private const string GETALLSETTING = "GetAllUserSetting";
        private const string GETUSERISDELETEDBYADSID = "GetUserIsDeletedByADSID";
        private const string UNDELETEDUSERBYID = "UnDeletedUserByID";
        private const string GETDELETEDUSERBYUSERID = "GetDeletedUserByUserID";
        private const string GETUSERBYIDNOTFLAGBYACTIVEANDDELETED = "GetUserByIDNotFlagByActiveAndDeleted";
        private const string GETUSERSAPPROVEDORREJECTEDTIMEENTRIESBYTIMESPAN = "GetUsersApprovedOrRejectedTimeEntriesByTimeSpan";
        //feature 229: Permission for project managers
        private const string GETUSERHASPROJECTMANAGERPERMISSION = "GetUserHasProjectManagerPermission";

        //add by tsrdev2 - hosted version
        private const string GETALLSUPPERUSER = "GetAllSupperUser";

        private const string GETALLAPPROVERUSER = "GetAllApproverUser";

        #region Constructors
		public UserData(UserContext context) : base(context) { LOCK_User = this; }
		public UserData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_User = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserBase userObject )
		{
            AddParameter(cmd, pNVarChar(UserBase.Property_Username, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, userObject.Username));
            AddParameter(cmd, pNVarChar(UserBase.Property_Password, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, userObject.Password));
            AddParameter(cmd, pNVarChar(UserBase.Property_Email, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, userObject.Email));
            AddParameter(cmd, pInt64(UserBase.Property_PersonID, userObject.PersonID));
            AddParameter(cmd, pNVarChar(UserBase.Property_ADSID, ConstantCollection.NVARCHAR_FIELD_LENGTH128, userObject.ADSID));
            AddParameter(cmd, pDateTime(UserBase.Property_LastSuccessfullLogin, userObject.LastSuccessfullLogin));
            AddParameter(cmd, pInt64(UserBase.Property_UnsuccessfullAttempts, userObject.UnsuccessfullAttempts));
            AddParameter(cmd, pInt64(UserBase.Property_CalendarID, userObject.CalendarID));
            AddParameter(cmd, pBool(UserBase.Property_IsActive, userObject.IsActive));
            AddParameter(cmd, pBool(UserBase.Property_IsSecretary, userObject.IsSecretary));
            AddParameter(cmd, pInt64(UserBase.Property_RequestedSubmissionUserGroupID, userObject.RequestedSubmissionUserGroupID));
            //field for Expenses feature
            AddParameter(cmd, pInt64(UserBase.Property_ExpenseApproverGroupID, userObject.ExpenseApproverGroupID));
            AddParameter(cmd, pBool(UserBase.Property_UseExpenses, userObject.UseExpenses));
            AddParameter(cmd, pInt64(UserBase.Property_Manager, userObject.Manager));
            //Fields for User Rate
            AddParameter(cmd, pDecimal(UserBase.Property_Cost, userObject.Cost));
            AddParameter(cmd, pDecimal(UserBase.Property_Revenue, userObject.Revenue));            
        }

        /// <summary>
        /// Inserts User
        /// </summary>
        /// <param name="userObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserBase userObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSER );
	
				AddParameter(cmd, pInt64Out(UserBase.Property_ID, userObject.ID));
				AddCommonParams( cmd, userObject );
				AddBaseParametersForInsert( cmd, userObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( userObject, x );
			}
		}
		
        /// <summary>
        /// Updates User 
        /// </summary>
        /// <param name="userObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserBase userObject)
		{
            lock (LOCK_User)
            {
				try
				{
                    UserBase dbObject = Get(userObject.ID);
                    //added by tsrdev2
                    //checking with super user
                    if (dbObject == null)
                        dbObject = GetAllSuperUser().FindByID(userObject.ID);
                    
                    if (dbObject == null)
                    {
                        throw new Framework.Exceptions.ObjectUpdateException(userObject, null);
                    }
                    else if (dbObject.ModifiedTimeStamp.ToString() != userObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != userObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(userObject, null);
                    
                    dbObject.CloneBase(userObject);
                    
                    SqlCommand cmd = GetSPCommand( UPDATEUSER );
				    AddParameter(cmd, pInt64(UserBase.Property_ID, userObject.ID));
					AddCommonParams( cmd, userObject );
					AddBaseParametersForUpdate( cmd, userObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( userObject, x );
				}
			}
		}

        /// <summary>
        /// UnDeleted User 
        /// added by tsrdev2
        /// </summary>
        /// <param name="userObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long UnDeleted(UserBase userObject)
        {
            bool success = false;
            long result = 0;
            lock (LOCK_User)
            {
                //undeleted
                try
                {
                    SqlCommand cmd = GetSPCommand(UNDELETEDUSERBYID);

                    AddParameter(cmd, pInt64(UserBase.Property_ID, userObject.ID));                   

                    result = UpdateRecord(cmd);
                    if (result > 0)
                    {
                        userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                        success = true;
                    }
                    
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(userObject, x);
                }           
                //update from AD user
                if (success)
                {
                    try
                    {

                        SqlCommand cmd = GetSPCommand(UPDATEUSER);

                        AddParameter(cmd, pInt64(UserBase.Property_ID, userObject.ID));
                        AddCommonParams(cmd, userObject);
                        AddBaseParametersForUpdate(cmd, userObject);

                        result = UpdateRecord(cmd);
                        if (result > 0)
                            userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                        return result;
                    }
                    catch (SqlException x)
                    {
                        throw new Framework.Exceptions.ObjectUpdateException(userObject, x);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Deletes User
        /// </summary>
        /// <param name="ID">ID of the User object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSER );
	
				AddParameters( cmd, pInt64( User.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( User ), ID, x );
			}
			
		}        
        
        /// <summary>
        /// Retrieves User object using it's ID
        /// </summary>
        /// <param name="ID">The id of the User object to retrieve</param>
        /// <returns>A User object, null if not found</returns>
		public User Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERBYID) )
			{
				AddParameters( cmd, pInt64( User.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// added by tsrdev2
        /// </summary>
        /// <param name="ADSID"></param>
        /// <returns></returns>
        public User GetDeletedADUser(string ADSID)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSERISDELETEDBYADSID))
            {
                AddParameters(cmd, pNVarChar(User.Property_ADSID,128,ADSID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// gets deleted user by user id
        /// </summary>
        /// added by tsrdev2
        /// <param name="ADSID"></param>
        /// <returns></returns>
        public User GetDeletedUserByUserID(Int64 id)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDUSERBYUSERID))
            {
                AddParameters(cmd, pInt64(User.Property_ID, id));

                return GetObject(cmd);
            }
        }

       /// by tsrdev2
       /// <summary>
       /// Retrieves a User by id not flag by active and deleted
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
        public User GetUserByIDNotFlagByActiveAndDeleted(Int64 id)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSERBYIDNOTFLAGBYACTIVEANDDELETED))
            {
                AddParameters(cmd, pInt64(User.Property_ID, id));
                return GetObject(cmd);
            }
        }
        /// <summary>
        /// Retrieves all User objects (not be deleted)
        /// </summary>
        /// <returns>A list of User objects</returns>
		public UserList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSER ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}
        /// <summary>
        /// Retrieves all User Isactive objects
        /// </summary>
        /// <returns>A list of User objects</returns>
        public UserList GetAllIsActive()
		{
            using (SqlCommand cmd = GetSPCommand(GETALLUSERISACTIVE))
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}           
        
        /// <summary>
        /// Fills User object
        /// </summary>
        /// <param name="userObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject(User userObject, SqlDataReader reader, int start)
		{
            userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            userObject.ID = reader.GetInt64(start + 0);
            userObject.Username = ReverseToHTMLCode(reader.GetString(start + 1));
            userObject.Password = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) userObject.Email = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) userObject.PersonID = reader.GetInt64(start + 4);
            if (!reader.IsDBNull(start + 5)) userObject.ADSID = ReverseToHTMLCode(reader.GetString(start + 5));
            if (!reader.IsDBNull(start + 6)) userObject.LastSuccessfullLogin = reader.GetDateTime(start + 6);
            userObject.UnsuccessfullAttempts = reader.GetInt64(start + 7);
            if (!reader.IsDBNull(start + 8)) userObject.CalendarID = reader.GetInt64(start + 8);            
            FillBaseObject(userObject, reader, (start + 9));
            if (!(userObject.CustomProperties["IsActive"] == System.DBNull.Value))
                userObject.IsActive = bool.Parse(userObject.CustomProperties["IsActive"].ToString());

            //add the field IsSecretary
            if (userObject.CustomProperties["IsSecretary"] != System.DBNull.Value)
            {
                userObject.IsSecretary = bool.Parse(userObject.CustomProperties["IsSecretary"].ToString());
            }
            if (userObject.CustomProperties["RequestedSubmissionUserGroupID"] != System.DBNull.Value)
            {
                userObject.RequestedSubmissionUserGroupID = Int64.Parse(userObject.CustomProperties["RequestedSubmissionUserGroupID"].ToString());
            }            
            if (userObject.CustomProperties["IsSupperUser"] != null && userObject.CustomProperties["IsSupperUser"] != System.DBNull.Value)
            {
                userObject.IsSupperUser = bool.Parse(userObject.CustomProperties["IsSupperUser"].ToString());
            }
            else
                userObject.IsSupperUser = false;

            try
            {
                if (reader.FieldCount > 22)
                {
                    if (!reader.IsDBNull(start + 21)) userObject.Cost = reader.GetDecimal(start + 21);
                    if (!reader.IsDBNull(start + 22)) userObject.Revenue = reader.GetDecimal(start + 22);
                }
            }
            catch
            {
                userObject.Cost = 0;
                userObject.Revenue = 0;
            }
            if (reader.FieldCount > 23)
            {
                userObject.Person = new Person();                
                if (!reader.IsDBNull(start + 23)) userObject.Person.FirstName = ReverseToHTMLCode(reader.GetString(start + 21));
                if (!reader.IsDBNull(start + 24)) userObject.Person.MiddleName += ReverseToHTMLCode(reader.GetString(start + 22));
                if (!reader.IsDBNull(start + 25)) userObject.Person.LastName += ReverseToHTMLCode(reader.GetString(start + 23));
            }

            //expense approvers
            if(userObject.CustomProperties[UserBase.Property_ExpenseApproverGroupID] != null && userObject.CustomProperties[UserBase.Property_ExpenseApproverGroupID] != System.DBNull.Value)
            {
                userObject.ExpenseApproverGroupID = Int64.Parse(userObject.CustomProperties[UserBase.Property_ExpenseApproverGroupID].ToString());
            }
            //use expense 
            if(userObject.CustomProperties[UserBase.Property_UseExpenses] != null && userObject.CustomProperties[UserBase.Property_UseExpenses] != System.DBNull.Value)
            {
                userObject.UseExpenses = bool.Parse(userObject.CustomProperties[UserBase.Property_UseExpenses].ToString());
            }
            //Manager
            if (userObject.CustomProperties[UserBase.Property_Manager] != null && userObject.CustomProperties[UserBase.Property_Manager] != System.DBNull.Value)
            {
                userObject.Manager = Int64.Parse(userObject.CustomProperties[UserBase.Property_Manager].ToString());
            }

            ////use rate 
            //if (userObject.CustomProperties[UserBase.Property_UseRates] != null && userObject.CustomProperties[UserBase.Property_UseRates] != System.DBNull.Value)
            //{
            //    userObject.UseRates = bool.Parse(userObject.CustomProperties[UserBase.Property_UseRates].ToString());
            //}
        }

        protected void FillObject_View(UserBase userObject, SqlDataReader reader)
        {
            userObject.ID = reader.GetInt64(0);
            userObject.Username = ReverseToHTMLCode(reader.GetString(1));
        }

        protected void FillObject_Export(User userObject, SqlDataReader reader)
        {
            userObject.ID = reader.GetInt64(0);
            userObject.Username = ReverseToHTMLCode(reader.GetString(1));
            if (!reader.IsDBNull(2))
            {
                userObject.PersonID = reader.GetInt64(2);
                userObject.Person = new Person();
                userObject.Person.ID = userObject.PersonID.Value;
                if (!reader.IsDBNull(3)) userObject.Person.FirstName = ReverseToHTMLCode(reader.GetString(3));
                if (!reader.IsDBNull(4)) userObject.Person.LastName = ReverseToHTMLCode(reader.GetString(4));
                if (!reader.IsDBNull(5)) userObject.Person.MiddleName = ReverseToHTMLCode(reader.GetString(5));
                if (!reader.IsDBNull(6)) userObject.Person.Email = ReverseToHTMLCode(reader.GetString(6));
                if (!reader.IsDBNull(7)) userObject.Person.Department = ReverseToHTMLCode(reader.GetString(7));
                if (!reader.IsDBNull(8)) userObject.Person.CellPhone = ReverseToHTMLCode(reader.GetString(8));
                if (!reader.IsDBNull(9)) userObject.Person.JobTitle = ReverseToHTMLCode(reader.GetString(9));
                if (!reader.IsDBNull(10)) userObject.Person.DirectPhone = ReverseToHTMLCode(reader.GetString(10));
                if (!reader.IsDBNull(11)) userObject.Person.LocationName = ReverseToHTMLCode(reader.GetString(11));
            }
        }

		protected void FillObject( User userObject, SqlDataReader reader )
		{
			FillObject( userObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves User object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>User object</returns>
		private User GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );
			using( reader )
			{
				if( reader.Read() )
				{
					User userObject= new User();
					FillObject( userObject, reader );
                    if (userObject.IsSupperUser)
                    {
                        //not show SupperUser
                        return null;
                    }
					return userObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of User objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of User objects</returns>
		private UserList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserList list = new UserList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					User userObject = new User();
					FillObject( userObject, reader );
                    if (!userObject.IsSupperUser)
                    {
                        list.Add(userObject);                        
                    }
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private UserList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserList list = new UserList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    User userObject = new User();
                    FillObject_View(userObject, reader);
                    list.Add(userObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        private UserList GetList_Export(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserList list = new UserList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    User userObject = new User();
                    FillObject_Export(userObject, reader);
                    list.Add(userObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        //added by tsrdev2 - hosted version
        /// <summary>
        /// Retrieves all Supper users
        /// </summary>
        /// <returns>A list of Supper User objects</returns>
        public UserList GetAllSuperUser()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLSUPPERUSER))
            {
                return GetListSuperUsers(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        //added by tsrdev2
        /// <summary>
        /// Retrieves list of SupperUser objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of User objects</returns>
        private UserList GetListSuperUsers(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserList list = new UserList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    User userObject = new User();
                    FillObject(userObject, reader);
                    if (userObject.IsSupperUser)
                    {
                        list.Add(userObject);
                    }
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        //added by tsrdev2 - hosted version        
        public UserList GetUsersApprovedOrRejectedTimeEntriesByTimeSpan(DateTime startTimeStamp, DateTime endTimeStamp)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSERSAPPROVEDORREJECTEDTIMEENTRIESBYTIMESPAN))
            {
                AddParameter(cmd, pDateTime(TimeEntryBase.Property_StartTimeStamp, startTimeStamp));
                AddParameter(cmd, pDateTime(TimeEntryBase.Property_EndTimeStamp, endTimeStamp));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Get users can become project manager. 
        /// (add by tsrdev2 - feature 229)
        /// </summary>
        /// <returns></returns>      
        public UserList GetUserHasProjectManagerPermission()
        {
            using (SqlCommand cmd = GetSPCommand(GETUSERHASPROJECTMANAGERPERMISSION))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        public UserList GetAllApproverUser()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLAPPROVERUSER))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}

