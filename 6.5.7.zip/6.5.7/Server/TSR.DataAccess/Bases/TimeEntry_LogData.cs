﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class TimeEntry_LogData : BaseDataAccess
    {
        private const string INSERTTIMEENTRY_LOG = "InsertTimeEntry_Log";
        private const string UPDATETIMEENTRY_LOG = "UpdateTimeEntry_Log";
        private const string DELETETIMEENTRY_LOG = "DeleteTimeEntry_Log";
        private const string GETTIMEENTRY_LOGBYID = "GetTimeEntry_LogByID";
        private const string GETTIMEENTRY_LOGBYTIMEENTRYID = "GetTimeEntry_LogByTimeEntryID";
        private const string GETALLTIMEENTRY_LOG = "GetAllTimeEntry_Log";

        #region Constructors

        public TimeEntry_LogData(UserContext context) : base(context) { }
        public TimeEntry_LogData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="timeEntry_LogObject"></param>
        private void AddCommonParams(SqlCommand cmd, TimeEntry_LogBase timeEntry_LogObject)
        {
            AddParameter(cmd, pGuid(TimeEntry_LogBase.Property_TimeEntryID, timeEntry_LogObject.TimeEntryID));
            AddParameter(cmd, pDateTime(TimeEntry_LogBase.Property_SubmissionTimeStamp, timeEntry_LogObject.SubmissionTimeStamp));
            AddParameter(cmd, pInt64(TimeEntry_LogBase.Property_SubmittedByID, timeEntry_LogObject.SubmittedByID));
            AddParameter(cmd, pDateTime(TimeEntry_LogBase.Property_ApprovalTimeStamp, timeEntry_LogObject.ApprovalTimeStamp));
            AddParameter(cmd, pInt64(TimeEntry_LogBase.Property_ApprovedByID, timeEntry_LogObject.ApprovedByID));
            AddParameter(cmd, pDateTime(TimeEntry_LogBase.Property_RejectedTimeStamp, timeEntry_LogObject.RejectedTimeStamp));
            AddParameter(cmd, pInt64(TimeEntry_LogBase.Property_RejectedByID, timeEntry_LogObject.RejectedByID));
        }

        /// <summary>
        /// Inserts TimeEntry_Log
        /// </summary>
        /// <param name="timeEntry_LogObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(TimeEntry_LogBase timeEntry_LogObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTTIMEENTRY_LOG);

                AddParameter(cmd, pInt64Out(TimeEntry_LogBase.Property_ID, timeEntry_LogObject.ID));
                AddCommonParams(cmd, timeEntry_LogObject);

                long result = InsertRecord(cmd);
              
                return (long)GetOutParameter(cmd, TimeEntry_LogBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw x;
            }
        }

        /// <summary>
        /// Updates TimeEntry_Log 
        /// </summary>
        /// <param name="timeEntry_LogObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(TimeEntry_LogBase timeEntry_LogObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATETIMEENTRY_LOG);

                AddParameter(cmd, pInt64(TimeEntry_LogBase.Property_ID, timeEntry_LogObject.ID));
                AddCommonParams(cmd, timeEntry_LogObject);

                long result = UpdateRecord(cmd);
                return result;
            }
            catch (SqlException x)
            {
                throw x;
            }

        }

        /// <summary>
        /// Deletes TimeEntry_Log
        /// </summary>
        /// <param name="ID">ID of the TimeEntry_Log object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETETIMEENTRY_LOG);

                AddParameters(cmd, pInt64(TimeEntry_Log.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(TimeEntry_Log), ID, x);
            }

        }

        /// <summary>
        /// Retrieves TimeEntry_Log object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeEntry_Log object to retrieve</param>
        /// <returns>A TimeEntry_Log object, null if not found</returns>
        public TimeEntry_Log Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETTIMEENTRY_LOGBYID))
            {
                AddParameters(cmd, pInt64(TimeEntry_Log.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves TimeEntry_Log object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeEntry_Log object to retrieve</param>
        /// <returns>A TimeEntry_Log object, null if not found</returns>
        public TimeEntry_Log GetByTimeEntryID(Guid timeID)
        {
            using (SqlCommand cmd = GetSPCommand(GETTIMEENTRY_LOGBYTIMEENTRYID))
            {
                AddParameters(cmd, pGuid(TimeEntry_Log.Property_TimeEntryID, timeID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all TimeEntry_Log objects 
        /// </summary>
        /// <returns>A list of TimeEntry_Log objects</returns>
        public TimeEntry_LogList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLTIMEENTRY_LOG))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills TimeEntry_Log object
        /// </summary>
        /// <param name="timeEntry_LogObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(TimeEntry_LogBase timeEntry_LogObject, SqlDataReader reader, int start)
        {
            timeEntry_LogObject.ID = reader.GetInt64(start + 0);
            timeEntry_LogObject.TimeEntryID = reader.GetGuid(start + 1);
        }

        protected void FillObject(TimeEntry_LogBase timeEntry_LogObject, SqlDataReader reader)
        {
            FillObject(timeEntry_LogObject, reader, 0);
        }

        /// <summary>
        /// Retrieves TimeEntry_Log object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>TimeEntry_Log object</returns>
        private TimeEntry_Log GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    TimeEntry_Log timeEntry_LogObject = new TimeEntry_Log();
                    FillObject(timeEntry_LogObject, reader);
                    return timeEntry_LogObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of TimeEntry_Log objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of TimeEntry_Log objects</returns>
        private TimeEntry_LogList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            TimeEntry_LogList list = new TimeEntry_LogList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    TimeEntry_Log timeEntry_LogObject = new TimeEntry_Log();
                    FillObject(timeEntry_LogObject, reader);

                    list.Add(timeEntry_LogObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }


        public void Update(TimeEntry timeEntryObject)
        {
            Update(timeEntryObject.ID, timeEntryObject.Status);
        }

        public void Update(Guid timeEntryID, StatusEnum timeStatus)
        {
            if (timeStatus != StatusEnum.InProgress && timeStatus != StatusEnum.Approved && timeStatus != StatusEnum.Rejected)
                return;
            try
            {
                bool isUpdate = true;
                TimeEntry_LogBase dbObject = GetByTimeEntryID(timeEntryID);
                if (dbObject == null)
                {
                    isUpdate = false;
                    dbObject = new TimeEntry_LogBase();
                    dbObject.TimeEntryID = timeEntryID;
                }
                switch (timeStatus)
                {                
                    case StatusEnum.InProgress:
                        dbObject.SubmittedByID = UserContext.UserID;
                        dbObject.SubmissionTimeStamp = DateTime.Now;
                        break;
                    case StatusEnum.Approved:
                        dbObject.ApprovedByID = UserContext.UserID;
                        dbObject.ApprovalTimeStamp = DateTime.Now;
                        break;              
                    case StatusEnum.Rejected:
                        dbObject.RejectedByID = UserContext.UserID;
                        dbObject.RejectedTimeStamp = DateTime.Now;
                        break;                 
                    default:
                        return;
                }

                if (isUpdate)
                    Update(dbObject);
                else
                    Insert(dbObject);
            }
            catch (SqlException x)
            {
                throw x;
            }
        }
    }
}

