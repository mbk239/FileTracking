using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class UserDetailData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_UserDetail;

		private const string INSERTUSERDETAIL = "InsertUserDetail";
		private const string UPDATEUSERDETAIL = "UpdateUserDetail";
		private const string DELETEUSERDETAIL = "DeleteUserDetail";
		private const string GETUSERDETAILBYID = "GetUserDetailByID";
		private const string GETALLUSERDETAIL = "GetAllUserDetail";

        #region Constructors

        public UserDetailData(UserContext context) : base(context) { LOCK_UserDetail = this; }

		public UserDetailData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_UserDetail = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userDetailObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserDetailBase userDetailObject )
		{
			AddParameter(cmd, pInt64(UserDetailBase.Property_PersonID, userDetailObject.PersonID));
			AddParameter(cmd, pInt64(UserDetailBase.Property_UserDetailTypeID, userDetailObject.UserDetailTypeID));
            AddParameter(cmd, pNVarChar(UserDetailBase.Property_UserDetailValue, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, userDetailObject.UserDetailValue));
		}

        /// <summary>
        /// Inserts UserDetail
        /// </summary>
        /// <param name="userDetailObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserDetailBase userDetailObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSERDETAIL );
	
				AddParameter(cmd, pInt64Out(UserDetailBase.Property_ID, userDetailObject.ID));
				AddCommonParams( cmd, userDetailObject );
				AddBaseParametersForInsert( cmd, userDetailObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserDetailBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( userDetailObject, x );
			}
		}
		
        /// <summary>
        /// Updates UserDetail 
        /// </summary>
        /// <param name="userDetailObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserDetailBase userDetailObject)
		{
            lock (LOCK_UserDetail)
            {
                try
                {
                    //UserDetailBase dbObject = Get(userDetailObject.ID);
                    //if (dbObject == null)
                    //    throw new Framework.Exceptions.ObjectUpdateException(userDetailObject, null);
                    //else if (dbObject.ModifiedTimeStamp.ToString() != userDetailObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != UserDetailTypeObject.ModifiedTimeStamp)
                    //    throw new Framework.Exceptions.DataIntegrityFailedException(userDetailObject, null);
                    SqlCommand cmd = GetSPCommand(UPDATEUSERDETAIL);

                    AddParameter(cmd, pInt64(UserDetailBase.Property_ID, userDetailObject.ID));
                    AddCommonParams(cmd, userDetailObject);
                    AddBaseParametersForUpdate(cmd, userDetailObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        userDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(userDetailObject, x);
                }
            }
		}

        /// <summary>
        /// Deletes UserDetail
        /// </summary>
        /// <param name="ID">ID of the UserDetail object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSERDETAIL );
	
				AddParameters( cmd, pInt64( UserDetail.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( UserDetail ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves UserDetail object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserDetail object to retrieve</param>
        /// <returns>A UserDetail object, null if not found</returns>
		public UserDetail Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERDETAILBYID) )
			{
				AddParameters( cmd, pInt64( UserDetail.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all UserDetail objects 
        /// </summary>
        /// <returns>A list of UserDetail objects</returns>
		public UserDetailList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSERDETAIL ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills UserDetail object
        /// </summary>
        /// <param name="userDetailObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( UserDetailBase userDetailObject, SqlDataReader reader, int start )
		{
			userDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			userDetailObject.ID = reader.GetInt64(start + 0);
			userDetailObject.PersonID = reader.GetInt64(start + 1);
			userDetailObject.UserDetailTypeID = reader.GetInt64(start + 2);
            userDetailObject.UserDetailValue = ReverseToHTMLCode(reader.GetString(start + 3));
			FillBaseObject(userDetailObject, reader, (start + 4));
		}

		protected void FillObject( UserDetailBase userDetailObject, SqlDataReader reader )
		{
			FillObject( userDetailObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves UserDetail object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserDetail object</returns>
		private UserDetail GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					UserDetail userDetailObject= new UserDetail();
					FillObject( userDetailObject, reader );
					return userDetailObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of UserDetail objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserDetail objects</returns>
		private UserDetailList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserDetailList list = new UserDetailList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					UserDetail userDetailObject = new UserDetail();
					FillObject( userDetailObject, reader );

					list.Add( userDetailObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}
    }
}

