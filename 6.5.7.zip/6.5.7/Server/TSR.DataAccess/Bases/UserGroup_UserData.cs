using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class UserGroup_UserData : BaseRelationData
	{
		private const string INSERTUSERGROUP_USER = "InsertUserGroup_User";
		private const string UPDATEUSERGROUP_USER = "UpdateUserGroup_User";
		private const string DELETEUSERGROUP_USER = "DeleteUserGroup_User";
		private const string GETUSERGROUP_USERBYID = "GetUserGroup_UserByID";
		private const string GETALLUSERGROUP_USER = "GetAllUserGroup_User";

        #region Constructors

		public UserGroup_UserData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userGroup_UserObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserGroup_UserBase userGroup_UserObject )
		{
			AddParameter(cmd, pInt64(UserGroup_UserBase.Property_UserGroupID, userGroup_UserObject.UserGroupID));
			AddParameter(cmd, pInt64(UserGroup_UserBase.Property_UserID, userGroup_UserObject.UserID));
		}

        /// <summary>
        /// Inserts UserGroup_User
        /// </summary>
        /// <param name="userGroup_UserObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserGroup_UserBase userGroup_UserObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSERGROUP_USER );
	
				AddParameter(cmd, pInt64Out(UserGroup_UserBase.Property_ID, userGroup_UserObject.ID));
				AddCommonParams( cmd, userGroup_UserObject );
				AddBaseParametersForInsert( cmd, userGroup_UserObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userGroup_UserObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserGroup_UserBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( userGroup_UserObject, x );
			}
		}
		
        /// <summary>
        /// Updates UserGroup_User 
        /// </summary>
        /// <param name="userGroup_UserObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserGroup_UserBase userGroup_UserObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEUSERGROUP_USER );

				AddParameter(cmd, pInt64(UserGroup_UserBase.Property_ID, userGroup_UserObject.ID));
				AddCommonParams( cmd, userGroup_UserObject );
				AddBaseParametersForUpdate( cmd, userGroup_UserObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					userGroup_UserObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( userGroup_UserObject, x );
			}
			
		}

        /// <summary>
        /// Deletes UserGroup_User
        /// </summary>
        /// <param name="ID">ID of the UserGroup_User object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSERGROUP_USER );
	
				AddParameters( cmd, pInt64( UserGroup_User.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( UserGroup_User ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves UserGroup_User object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserGroup_User object to retrieve</param>
        /// <returns>A UserGroup_User object, null if not found</returns>
		public UserGroup_User Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERGROUP_USERBYID) )
			{
				AddParameters( cmd, pInt64( UserGroup_User.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all UserGroup_User objects 
        /// </summary>
        /// <returns>A list of UserGroup_User objects</returns>
		public UserGroup_UserList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSERGROUP_USER ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills UserGroup_User object
        /// </summary>
        /// <param name="userGroup_UserObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( UserGroup_UserBase userGroup_UserObject, SqlDataReader reader, int start )
		{
			userGroup_UserObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			userGroup_UserObject.ID = reader.GetInt64(start + 0);
			userGroup_UserObject.UserGroupID = reader.GetInt64(start + 1);
			userGroup_UserObject.UserID = reader.GetInt64(start + 2);
			FillBaseObject(userGroup_UserObject, reader, (start + 3));
		}

		protected void FillObject( UserGroup_UserBase userGroup_UserObject, SqlDataReader reader )
		{
			FillObject( userGroup_UserObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves UserGroup_User object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserGroup_User object</returns>
		private UserGroup_User GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					UserGroup_User userGroup_UserObject= new UserGroup_User();
					FillObject( userGroup_UserObject, reader );
					return userGroup_UserObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of UserGroup_User objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserGroup_User objects</returns>
		private UserGroup_UserList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserGroup_UserList list = new UserGroup_UserList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					UserGroup_User userGroup_UserObject = new UserGroup_User();
					FillObject( userGroup_UserObject, reader );

					list.Add( userGroup_UserObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

