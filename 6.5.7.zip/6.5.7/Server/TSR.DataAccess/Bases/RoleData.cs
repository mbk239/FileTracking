using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class RoleData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Role;

		private const string INSERTROLE = "InsertRole";
		private const string UPDATEROLE = "UpdateRole";
		private const string DELETEROLE = "DeleteRole";
		private const string GETROLEBYID = "GetRoleByID";
		private const string GETALLROLE = "GetAllRole";
        private const string GETALLINACTIVEROLE = "GetAllInactiveRole";        

        #region Constructors

		public RoleData(UserContext context) : base(context) { LOCK_Role = this; }
		public RoleData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Role = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="roleObject"></param>
		private void AddCommonParams( SqlCommand cmd, RoleBase roleObject )
		{
            AddParameter(cmd, pNVarChar(RoleBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, roleObject.Name));
			AddParameter(cmd, pNText(RoleBase.Property_Description, roleObject.Description));
		}

        /// <summary>
        /// Inserts Role
        /// </summary>
        /// <param name="roleObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( RoleBase roleObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTROLE );
	
				AddParameter(cmd, pInt64Out(RoleBase.Property_ID, roleObject.ID));
				AddCommonParams( cmd, roleObject );
				AddBaseParametersForInsert( cmd, roleObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					roleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, RoleBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( roleObject, x );
			}
		}
		
        /// <summary>
        /// Updates Role 
        /// </summary>
        /// <param name="roleObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( RoleBase roleObject)
		{
            lock (LOCK_Role)
            {
				try
				{
                    RoleBase dbObject = Get(roleObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(roleObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != roleObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != roleObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(roleObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEROLE );

				    AddParameter(cmd, pInt64(RoleBase.Property_ID, roleObject.ID));
					AddCommonParams( cmd, roleObject );
					AddBaseParametersForUpdate( cmd, roleObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						roleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( roleObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Role
        /// </summary>
        /// <param name="ID">ID of the Role object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEROLE );
	
				AddParameters( cmd, pInt64( Role.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Role ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Role object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Role object to retrieve</param>
        /// <returns>A Role object, null if not found</returns>
		public Role Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETROLEBYID) )
			{
				AddParameters( cmd, pInt64( Role.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Role objects 
        /// </summary>
        /// <returns>A list of Role objects</returns>
		public RoleList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLROLE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        //Feature 205 - Active and Inactive Role
        //Added by tsrdev2 - 26 Sep 2012
        /// <summary>
        /// Retrieves all Inactive Role objects 
        /// </summary>
        /// <returns>A list of Inactive Role objects</returns>
        public RoleList GetAllInactiveRole()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLINACTIVEROLE))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Role object
        /// </summary>
        /// <param name="roleObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( RoleBase roleObject, SqlDataReader reader, int start )
		{
			roleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			roleObject.ID = reader.GetInt64(start + 0);
			roleObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) roleObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			FillBaseObject(roleObject, reader, (start + 3));
		}

		protected void FillObject( RoleBase roleObject, SqlDataReader reader )
		{
			FillObject( roleObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Role object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Role object</returns>
		private Role GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Role roleObject= new Role();
					FillObject( roleObject, reader );
					return roleObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Role objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Role objects</returns>
		private RoleList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			RoleList list = new RoleList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Role roleObject = new Role();
					FillObject( roleObject, reader );

					list.Add( roleObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

