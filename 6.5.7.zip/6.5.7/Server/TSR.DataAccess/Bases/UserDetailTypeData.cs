using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class UserDetailTypeData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_UserDetailType;

        private const string INSERTUserDetailType = "InsertUserDetailType";
        private const string UPDATEUserDetailType = "UpdateUserDetailType";
        private const string DELETEUserDetailType = "DeleteUserDetailType";
        private const string GETUserDetailTypeBYID = "GetUserDetailTypeByID";
        private const string GETALLUserDetailType = "GetAllUserDetailType";
        private const string GETALLUserDetailTypeIsActive = "GetAllUserDetailTypeIsActive";

        #region Constructors

        public UserDetailTypeData(UserContext context) : base(context) { LOCK_UserDetailType = this; }
        public UserDetailTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_UserDetailType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="UserDetailTypeObject"></param>
        private void AddCommonParams(SqlCommand cmd, UserDetailTypeBase UserDetailTypeObject)
        {
            AddParameter(cmd, pNVarChar(UserDetailTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, UserDetailTypeObject.Name));
            AddParameter(cmd, pNText(UserDetailTypeBase.Property_Description, UserDetailTypeObject.Description));
            AddParameter(cmd, pInt32(UserDetailTypeBase.Property_Format, (int)UserDetailTypeObject.Format));
            AddParameter(cmd, pBool(UserDetailTypeBase.Property_IsActive, UserDetailTypeObject.IsActive));
        }

        /// <summary>
        /// Inserts UserDetailType
        /// </summary>
        /// <param name="UserDetailTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(UserDetailTypeBase UserDetailTypeObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTUserDetailType);

                AddParameter(cmd, pInt64Out(UserDetailTypeBase.Property_ID, UserDetailTypeObject.ID));
                AddCommonParams(cmd, UserDetailTypeObject);
                AddBaseParametersForInsert(cmd, UserDetailTypeObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    UserDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, UserDetailTypeBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(UserDetailTypeObject, x);
            }
        }

        /// <summary>
        /// Updates UserDetailType 
        /// </summary>
        /// <param name="UserDetailTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(UserDetailTypeBase UserDetailTypeObject)
        {
            lock (LOCK_UserDetailType)
            {
                try
                {
                    UserDetailTypeBase dbObject = Get(UserDetailTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(UserDetailTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != UserDetailTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != UserDetailTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(UserDetailTypeObject, null);

                    SqlCommand cmd = GetSPCommand(UPDATEUserDetailType);

                    AddParameter(cmd, pInt64(UserDetailTypeBase.Property_ID, UserDetailTypeObject.ID));
                    AddCommonParams(cmd, UserDetailTypeObject);
                    AddBaseParametersForUpdate(cmd, UserDetailTypeObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        UserDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(UserDetailTypeObject, x);
                }
            }
        }

        /// <summary>
        /// Deletes UserDetailType
        /// </summary>
        /// <param name="ID">ID of the UserDetailType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEUserDetailType);

                AddParameters(cmd, pInt64(UserDetailType.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(UserDetailType), ID, x);
            }

        }

        /// <summary>
        /// Retrieves UserDetailType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserDetailType object to retrieve</param>
        /// <returns>A UserDetailType object, null if not found</returns>
        public UserDetailType Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETUserDetailTypeBYID))
            {
                AddParameters(cmd, pInt64(UserDetailType.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all UserDetailType objects 
        /// </summary>
        /// <returns>A list of UserDetailType objects</returns>
        public UserDetailTypeList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLUserDetailType))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Retrieves all Active UserDetailType objects 
        /// </summary>
        /// <returns>A list of UserDetailType objects</returns>
        public UserDetailTypeList GetAllIsActive()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLUserDetailTypeIsActive))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills UserDetailType object
        /// </summary>
        /// <param name="UserDetailTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(UserDetailTypeBase UserDetailTypeObject, SqlDataReader reader, int start)
        {
            UserDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            UserDetailTypeObject.ID = reader.GetInt64(start + 0);
            UserDetailTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) UserDetailTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) UserDetailTypeObject.Format = (UserDetailFormatEnum)reader.GetInt32(start + 3);
            UserDetailTypeObject.IsActive = reader.GetBoolean(start + 4);
            FillBaseObject(UserDetailTypeObject, reader, (start + 5));
        }

        protected void FillObject(UserDetailTypeBase UserDetailTypeObject, SqlDataReader reader)
        {
            FillObject(UserDetailTypeObject, reader, 0);
        }

        /// <summary>
        /// Retrieves UserDetailType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserDetailType object</returns>
        private UserDetailType GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    UserDetailType UserDetailTypeObject = new UserDetailType();
                    FillObject(UserDetailTypeObject, reader);
                    return UserDetailTypeObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of UserDetailType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserDetailType objects</returns>
        private UserDetailTypeList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserDetailTypeList list = new UserDetailTypeList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    UserDetailType UserDetailTypeObject = new UserDetailType();
                    FillObject(UserDetailTypeObject, reader);

                    list.Add(UserDetailTypeObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}

