﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using TSR.Entities.Bases;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class TemplateMappingTableData : BaseDataAccess
    {
        private const string INSERTTEMPLATEMAPPINGTABLE = "InsertTemplateMappingTable";
        private const string UPDATETEMPLATEMAPPINGTABLE = "UpdateTemplateMappingTable";
        private const string DELETETEMPLATEMAPPINGTABLE = "DeleteTemplateMappingTable";
        private const string GETTEMPLATEMAPPINGTABLEBYID = "GetTemplateMappingTableByID";
        private const string GETALLTEMPLATEMAPPINGTABLE = "GetAllTemplateMappingTable";
        private const string GETALLTEMPLATEMAPPINGTABLEBYTEMPLATENAME = "GetAllTemplateMappingTableByTemplateName";
        private const string DELETETEMPLATEMAPPINGTABLEBYTEMPLATENAME = "DeleteTemplateMappingTableByTemplateName";

        #region Constructors

        public TemplateMappingTableData(UserContext context) : base(context) { }
        public TemplateMappingTableData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="TemplateMappingTableObject"></param>
        private void AddCommonParams(SqlCommand cmd, TemplateMappingTableBase TemplateMappingTableObject)
        {
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_TemplateName, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, TemplateMappingTableObject.TemplateName));
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_ObjectName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, TemplateMappingTableObject.ObjectName));
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_TemplateParameterName, ConstantCollection.NVARCHAR_FIELD_LENGTH_100, TemplateMappingTableObject.TemplateParameterName));
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_ObjectPropertyName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, TemplateMappingTableObject.ObjectPropertyName));
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_DisplayableParameterName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, TemplateMappingTableObject.DisplayableParameterName));
            AddParameter(cmd, pNVarChar(TemplateMappingTableBase.Property_UserViewableParameterName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, TemplateMappingTableObject.UserViewableParameterName));
            AddParameter(cmd, pBit(TemplateMappingTableBase.Property_IsList, TemplateMappingTableObject.IsList));
        }

        /// <summary>
        /// Inserts Template Mapping Table
        /// </summary>
        /// <param name="TemplateMappingTableObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(TemplateMappingTableBase TemplateMappingTableObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTTEMPLATEMAPPINGTABLE);

                AddParameter(cmd, pInt64Out(TemplateMappingTableBase.Property_ID, TemplateMappingTableObject.ID));
                AddCommonParams(cmd, TemplateMappingTableObject);
                AddBaseParametersForInsert(cmd, TemplateMappingTableObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    TemplateMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, TemplateMappingTableBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(TemplateMappingTableObject, x);
            }
        }

        /// <summary>
        /// Updates Template Mapping Table
        /// </summary>
        /// <param name="TemplateMappingTableObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(TemplateMappingTableBase TemplateMappingTableObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATETEMPLATEMAPPINGTABLE);

                AddParameter(cmd, pInt64(TemplateMappingTableBase.Property_ID, TemplateMappingTableObject.ID));
                AddCommonParams(cmd, TemplateMappingTableObject);
                AddBaseParametersForUpdate(cmd, TemplateMappingTableObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    TemplateMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(TemplateMappingTableObject, x);
            }

        }

        /// <summary>
        /// Deletes Template Mapping Table
        /// </summary>
        /// <param name="ID">ID of the Template Mapping Table object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETETEMPLATEMAPPINGTABLE);

                AddParameters(cmd, pInt64(TemplateMappingTableBase.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(TemplateMappingTable), ID, x);
            }

        }
        //Created by tsrdev1
        //Created date: 25/06/2010
        /// <summary>
        /// Deletes Template Mapping Table by template name
        /// </summary>
        /// <param name="templateName">Template name of the Template Mapping Table object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(string templateName)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETETEMPLATEMAPPINGTABLEBYTEMPLATENAME);

                AddParameters(cmd, pNVarChar(TemplateMappingTableBase.Property_TemplateName,TSR.DataAccess.ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, templateName));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(TemplateMappingTable), templateName, x);
            }

        }

        /// <summary>
        /// Retrieves Template Mapping Table object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Template Mapping Table object to retrieve</param>
        /// <returns>A Template Mapping Table object, null if not found</returns>
        public TemplateMappingTable Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETTEMPLATEMAPPINGTABLEBYID))
            {
                AddParameters(cmd, pInt64(TemplateMappingTableBase.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        //Created by tsrdev1
        //Created date 28/06/2010
        /// <summary>
        /// Retrieves Template Mapping Tables object using it's TemplateName
        /// </summary>
        /// <param name="ID">The template name of the Template Mapping Table object to retrieve</param>
        /// <returns>A list of Template Mapping Table objects, null if not found</returns>
        public TemplateMappingTableList GetAllByTemplateName(string templateName)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLTEMPLATEMAPPINGTABLEBYTEMPLATENAME))
            {
                AddParameters(cmd, pNVarChar(TemplateMappingTableBase.Property_TemplateName,ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, templateName));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
        /// <summary>
        /// Retrieves all Template Mapping Table objects 
        /// </summary>
        /// <returns>A list of Template Mapping Table objects</returns>
        public TemplateMappingTableList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLTEMPLATEMAPPINGTABLE))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Template Mapping Table object
        /// </summary>
        /// <param name="TemplateMappingTableObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(TemplateMappingTableBase TemplateMappingTableObject, SqlDataReader reader, int start)
        {
            TemplateMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            TemplateMappingTableObject.ID = reader.GetInt64(start + 0);
            if (!reader.IsDBNull(start + 1)) TemplateMappingTableObject.TemplateName = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) TemplateMappingTableObject.ObjectName = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) TemplateMappingTableObject.TemplateParameterName = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) TemplateMappingTableObject.ObjectPropertyName = ReverseToHTMLCode(reader.GetString(start + 4));
            if (!reader.IsDBNull(start + 5)) TemplateMappingTableObject.DisplayableParameterName = ReverseToHTMLCode(reader.GetString(start + 5));
            if (!reader.IsDBNull(start + 6)) TemplateMappingTableObject.UserViewableParameterName = ReverseToHTMLCode(reader.GetString(start + 6));
            TemplateMappingTableObject.IsList = reader.GetBoolean(start + 7);
            FillBaseObject(TemplateMappingTableObject, reader, (start + 8));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="TemplateMappingTableObject"></param>
        /// <param name="reader"></param>
        protected void FillObject(TemplateMappingTableBase TemplateMappingTableObject, SqlDataReader reader)
        {
            FillObject(TemplateMappingTableObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Template Mapping Table object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Template Mapping Table object</returns>
        private TemplateMappingTable GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    TemplateMappingTable TemplateMappingTableObject = new TemplateMappingTable();
                    FillObject(TemplateMappingTableObject, reader);
                    return TemplateMappingTableObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Template Mapping Table objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Template Mapping Table objects</returns>
        private TemplateMappingTableList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            TemplateMappingTableList list = new TemplateMappingTableList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    TemplateMappingTable TemplateMappingTableObject = new TemplateMappingTable();
                    FillObject(TemplateMappingTableObject, reader);

                    list.Add(TemplateMappingTableObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}
