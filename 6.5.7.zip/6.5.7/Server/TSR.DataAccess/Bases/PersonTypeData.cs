using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PersonTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_PersonType;

		private const string INSERTPERSONTYPE = "InsertPersonType";
		private const string UPDATEPERSONTYPE = "UpdatePersonType";
		private const string DELETEPERSONTYPE = "DeletePersonType";
		private const string GETPERSONTYPEBYID = "GetPersonTypeByID";
		private const string GETALLPERSONTYPE = "GetAllPersonType";

        #region Constructors

		public PersonTypeData(UserContext context) : base(context) { LOCK_PersonType = this; }
		public PersonTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_PersonType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="personTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, PersonTypeBase personTypeObject )
		{
			AddParameter(cmd, pNVarChar(PersonTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, personTypeObject.Name));
			AddParameter(cmd, pNText(PersonTypeBase.Property_Description, personTypeObject.Description));
			AddParameter(cmd, pBool(PersonTypeBase.Property_ReadOnly, personTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts PersonType
        /// </summary>
        /// <param name="personTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( PersonTypeBase personTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPERSONTYPE );
	
				AddParameter(cmd, pInt64Out(PersonTypeBase.Property_ID, personTypeObject.ID));
				AddCommonParams( cmd, personTypeObject );
				AddBaseParametersForInsert( cmd, personTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					personTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, PersonTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( personTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates PersonType 
        /// </summary>
        /// <param name="personTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( PersonTypeBase personTypeObject)
		{
            lock (LOCK_PersonType)
            {
				try
				{
                    PersonTypeBase dbObject = Get(personTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(personTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != personTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != personTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(personTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPERSONTYPE );

				AddParameter(cmd, pInt64(PersonTypeBase.Property_ID, personTypeObject.ID));
					AddCommonParams( cmd, personTypeObject );
					AddBaseParametersForUpdate( cmd, personTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						personTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( personTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes PersonType
        /// </summary>
        /// <param name="ID">ID of the PersonType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPERSONTYPE );
	
				AddParameters( cmd, pInt64( PersonType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( PersonType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves PersonType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the PersonType object to retrieve</param>
        /// <returns>A PersonType object, null if not found</returns>
		public PersonType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPERSONTYPEBYID) )
			{
				AddParameters( cmd, pInt64( PersonType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all PersonType objects 
        /// </summary>
        /// <returns>A list of PersonType objects</returns>
		public PersonTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPERSONTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills PersonType object
        /// </summary>
        /// <param name="personTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( PersonTypeBase personTypeObject, SqlDataReader reader, int start )
		{
			personTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			personTypeObject.ID = reader.GetInt64(start + 0);
			personTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) personTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			personTypeObject.ReadOnly = reader.GetBoolean(start + 3);
			FillBaseObject(personTypeObject, reader, (start + 4));
		}

		protected void FillObject( PersonTypeBase personTypeObject, SqlDataReader reader )
		{
			FillObject( personTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves PersonType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>PersonType object</returns>
		private PersonType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					PersonType personTypeObject= new PersonType();
					FillObject( personTypeObject, reader );
					return personTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of PersonType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of PersonType objects</returns>
		private PersonTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			PersonTypeList list = new PersonTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					PersonType personTypeObject = new PersonType();
					FillObject( personTypeObject, reader );

					list.Add( personTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

