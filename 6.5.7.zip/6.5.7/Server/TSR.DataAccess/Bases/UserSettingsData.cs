﻿using System;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class UserSettingsData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_User;
        private const string GETALLSETTING = "GetAllUserSetting";
        private const string GetUserSettingByID = "GetUserSettingByID";
        #region Constructors
        public UserSettingsData( UserContext context) : base(context) { LOCK_User = this; }
        public UserSettingsData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_User = this; }
        #endregion

        public User_UserSettingsList GetAllSeting()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLSETTING))
            {                
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
        private User_UserSettings GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    User_UserSettings userObject = new User_UserSettings();
                    FillObject(userObject, reader);
                    return userObject;
                }
                else
                {
                    return null;
                }
            }
        }
        public  User_UserSettings Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GetUserSettingByID))
            {
                AddParameters(cmd, pInt64(User_UserSettings.Property_ID, ID));                
                return GetObject(cmd);
            }
        }
       private User_UserSettingsList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
            User_UserSettingsList list = new User_UserSettingsList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
                    User_UserSettings userObject = new User_UserSettings();
					FillObject( userObject, reader );
					list.Add( userObject);
				}				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
       }
       protected void FillObject(User_UserSettingsBase userObject, SqlDataReader reader)
       {
           FillObject(userObject, reader, 0);
       }
       protected void FillObject(User_UserSettingsBase userObject, SqlDataReader reader, int start)
       {
           userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
           userObject.ID = reader.GetInt64(start + 0);
           userObject.Username = ReverseToHTMLCode(reader.GetString(start + 1));
           userObject.SettingStates = ReverseToHTMLCode(reader.GetString(start + 2));
           userObject.LockStatus = ReverseToHTMLCode(reader.GetString(start + 3)); 
       
           //if (!reader.IsDBNull(start + 4))
           //    userObject.CreatorID = reader.GetInt64(start + 4);  
         
           //if (!reader.IsDBNull(start + 5))
           //    userObject.CreatedTimeStamp = reader.GetDateTime(start + 5);

           //userObject.ModifierID = reader.GetInt64(start + 6);  
        
           //if (!reader.IsDBNull(start + 7))
           //    userObject.ModifiedTimeStamp = reader.GetDateTime(start + 7);           
           
           FillBaseObject(userObject, reader, (start + 4));           
       }

    }
}
