using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class ContactTypeData : BaseDataAccess
    {
        private const string INSERTCONTACTTYPE = "InsertContactType";
        private const string UPDATECONTACTTYPE = "UpdateContactType";
        private const string DELETECONTACTTYPE = "DeleteContactType";
        private const string GETCONTACTTYPEBYID = "GetContactTypeByID";
        private const string GETALLCONTACTTYPE = "GetAllContactType";

        #region Constructors

        public ContactTypeData(UserContext context) : base(context) { }
        public ContactTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="ContactTypeObject"></param>
        private void AddCommonParams(SqlCommand cmd, ContactTypeBase ContactTypeObject)
        {
            AddParameter(cmd, pNVarChar(ContactTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ContactTypeObject.Name));
            AddParameter(cmd, pText(ContactTypeBase.Property_Description, ContactTypeObject.Description));
        }

        /// <summary>
        /// Inserts ContactType
        /// </summary>
        /// <param name="ContactTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(ContactTypeBase ContactTypeObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTCONTACTTYPE);

                AddParameter(cmd, pInt64Out(ContactTypeBase.Property_ID, ContactTypeObject.ID));
                AddCommonParams(cmd, ContactTypeObject);
                AddBaseParametersForInsert(cmd, ContactTypeObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    ContactTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ContactTypeBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(ContactTypeObject, x);
            }
        }

        /// <summary>
        /// Updates ContactType 
        /// </summary>
        /// <param name="ContactTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(ContactTypeBase ContactTypeObject)
        {
            try
            {
                ContactTypeBase dbObject = Get(ContactTypeObject.ID);
                if (dbObject == null)
                    throw new Framework.Exceptions.ObjectUpdateException(ContactTypeObject, null);
                else if (dbObject.ModifiedTimeStamp.ToString() != ContactTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != projectTypeObject.ModifiedTimeStamp)
                    throw new Framework.Exceptions.DataIntegrityFailedException(ContactTypeObject, null);
                SqlCommand cmd = GetSPCommand(UPDATECONTACTTYPE);

                AddParameter(cmd, pInt64(ContactTypeBase.Property_ID, ContactTypeObject.ID));
                AddCommonParams(cmd, ContactTypeObject);
                AddBaseParametersForUpdate(cmd, ContactTypeObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    ContactTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(ContactTypeObject, x);
            }

        }

        /// <summary>
        /// Deletes ContactType
        /// </summary>
        /// <param name="ID">ID of the ContactType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETECONTACTTYPE);

                AddParameters(cmd, pInt64(ContactType.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(ContactType), ID, x);
            }

        }

        /// <summary>
        /// Retrieves ContactType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ContactType object to retrieve</param>
        /// <returns>A ContactType object, null if not found</returns>
        public ContactType Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCONTACTTYPEBYID))
            {
                AddParameters(cmd, pInt64(ContactType.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all ContactType objects 
        /// </summary>
        /// <returns>A list of ContactType objects</returns>
        public ContactTypeList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLCONTACTTYPE))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills ContactType object
        /// </summary>
        /// <param name="ContactTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(ContactTypeBase ContactTypeObject, SqlDataReader reader, int start)
        {
            ContactTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            ContactTypeObject.ID = reader.GetInt64(start + 0);
            ContactTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) ContactTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));            
            FillBaseObject(ContactTypeObject, reader, (start + 3));
        }

        protected void FillObject(ContactTypeBase ContactTypeObject, SqlDataReader reader)
        {
            FillObject(ContactTypeObject, reader, 0);
        }

        /// <summary>
        /// Retrieves ContactType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ContactType object</returns>
        private ContactType GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    ContactType ContactTypeObject = new ContactType();
                    FillObject(ContactTypeObject, reader);
                    return ContactTypeObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of ContactType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ContactType objects</returns>
        private ContactTypeList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ContactTypeList list = new ContactTypeList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ContactType ContactTypeObject = new ContactType();
                    FillObject(ContactTypeObject, reader);

                    list.Add(ContactTypeObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}

