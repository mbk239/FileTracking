using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ExpenseSheetData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_ExpenseSheet;

		private const string INSERTEXPENSESHEET = "InsertExpenseSheet";
		private const string UPDATEEXPENSESHEET = "UpdateExpenseSheet";
		private const string DELETEEXPENSESHEET = "DeleteExpenseSheet";
		private const string GETEXPENSESHEETBYID = "GetExpenseSheetByID";
		private const string GETALLEXPENSESHEET = "GetAllExpenseSheet";

        #region Constructors

        public ExpenseSheetData(UserContext context) : base(context) { LOCK_ExpenseSheet = this; }
        public ExpenseSheetData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_ExpenseSheet = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="expenseSheetObject"></param>
		private void AddCommonParams( SqlCommand cmd, ExpenseSheetBase expenseSheetObject )
		{
			AddParameter(cmd, pGuid(ExpenseSheetBase.Property_TimeEntryID, expenseSheetObject.TimeEntryID));
            AddParameter(cmd, pInt32(ExpenseSheetBase.Property_Status, (int)expenseSheetObject.Status));
            AddParameter(cmd, pInt64(ExpenseSheetBase.Property_Revision, (int)expenseSheetObject.Revision));
			//AddParameter(cmd, pDecimal(ExpenseSheetBase.Property_TotalValue, expenseSheetObject.TotalValue));
		}

        /// <summary>
        /// Inserts ExpenseSheet
        /// </summary>
        /// <param name="expenseSheetObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ExpenseSheetBase expenseSheetObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTEXPENSESHEET );
	
				AddParameter(cmd, pInt64Out(ExpenseSheetBase.Property_ID, expenseSheetObject.ID));
				AddCommonParams( cmd, expenseSheetObject );
				AddBaseParametersForInsert( cmd, expenseSheetObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					expenseSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ExpenseSheetBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( expenseSheetObject, x );
			}
		}
		
        /// <summary>
        /// Updates ExpenseSheet 
        /// </summary>
        /// <param name="expenseSheetObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ExpenseSheetBase expenseSheetObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEEXPENSESHEET );

				AddParameter(cmd, pInt64(ExpenseSheetBase.Property_ID, expenseSheetObject.ID));
				AddCommonParams( cmd, expenseSheetObject );
				AddBaseParametersForUpdate( cmd, expenseSheetObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					expenseSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( expenseSheetObject, x );
			}
			
		}

        /// <summary>
        /// Deletes ExpenseSheet
        /// </summary>
        /// <param name="ID">ID of the ExpenseSheet object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEEXPENSESHEET );
	
				AddParameters( cmd, pInt64( ExpenseSheet.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ExpenseSheet ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves ExpenseSheet object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ExpenseSheet object to retrieve</param>
        /// <returns>A ExpenseSheet object, null if not found</returns>
		public ExpenseSheet Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETEXPENSESHEETBYID) )
			{
				AddParameters( cmd, pInt64( ExpenseSheet.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all ExpenseSheet objects 
        /// </summary>
        /// <returns>A list of ExpenseSheet objects</returns>
		public ExpenseSheetList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLEXPENSESHEET ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ExpenseSheet object
        /// </summary>
        /// <param name="ExpenseSheetObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ExpenseSheetBase expenseSheetObject, SqlDataReader reader, int start )
		{
			expenseSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			expenseSheetObject.ID = reader.GetInt64(start + 0);
            expenseSheetObject.TimeEntryID = reader.GetGuid(start + 1);
            expenseSheetObject.Status = (StatusEnum)reader.GetInt32(start + 2);
            expenseSheetObject.Revision = reader.GetInt64(start + 3);
            //expenseSheetObject.TotalValue = reader.GetDecimal(start + 3);
			FillBaseObject(expenseSheetObject, reader, (start + 4));
		}

		protected void FillObject( ExpenseSheetBase expenseSheetObject, SqlDataReader reader )
		{
			FillObject( expenseSheetObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ExpenseSheet object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ExpenseSheet object</returns>
		private ExpenseSheet GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ExpenseSheet expenseSheetObject= new ExpenseSheet();
					FillObject( expenseSheetObject, reader );
					return expenseSheetObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ExpenseSheet objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ExpenseSheet objects</returns>
		private ExpenseSheetList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ExpenseSheetList list = new ExpenseSheetList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					ExpenseSheet expenseSheetObject = new ExpenseSheet();
					FillObject( expenseSheetObject, reader );

					list.Add( expenseSheetObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

