using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class OrganizationTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_OrganizationType;

		private const string INSERTORGANIZATIONTYPE = "InsertOrganizationType";
		private const string UPDATEORGANIZATIONTYPE = "UpdateOrganizationType";
		private const string DELETEORGANIZATIONTYPE = "DeleteOrganizationType";
		private const string GETORGANIZATIONTYPEBYID = "GetOrganizationTypeByID";
		private const string GETALLORGANIZATIONTYPE = "GetAllOrganizationType";

        #region Constructors

		public OrganizationTypeData(UserContext context) : base(context) { LOCK_OrganizationType = this; }
		public OrganizationTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_OrganizationType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organizationTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, OrganizationTypeBase organizationTypeObject )
		{
			AddParameter(cmd, pNVarChar(OrganizationTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, organizationTypeObject.Name));
			AddParameter(cmd, pNText(OrganizationTypeBase.Property_Description, organizationTypeObject.Description));
			AddParameter(cmd, pBool(OrganizationTypeBase.Property_ReadOnly, organizationTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts OrganizationType
        /// </summary>
        /// <param name="organizationTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( OrganizationTypeBase organizationTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTORGANIZATIONTYPE );
	
				AddParameter(cmd, pInt64Out(OrganizationTypeBase.Property_ID, organizationTypeObject.ID));
				AddCommonParams( cmd, organizationTypeObject );
				AddBaseParametersForInsert( cmd, organizationTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					organizationTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, OrganizationTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( organizationTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates OrganizationType 
        /// </summary>
        /// <param name="organizationTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( OrganizationTypeBase organizationTypeObject)
		{
            lock (LOCK_OrganizationType)
            {
				try
				{
                    OrganizationTypeBase dbObject = Get(organizationTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(organizationTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != organizationTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != organizationTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(organizationTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEORGANIZATIONTYPE );

				    AddParameter(cmd, pInt64(OrganizationTypeBase.Property_ID, organizationTypeObject.ID));
					AddCommonParams( cmd, organizationTypeObject );
					AddBaseParametersForUpdate( cmd, organizationTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						organizationTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( organizationTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes OrganizationType
        /// </summary>
        /// <param name="ID">ID of the OrganizationType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEORGANIZATIONTYPE );
	
				AddParameters( cmd, pInt64( OrganizationType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( OrganizationType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves OrganizationType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the OrganizationType object to retrieve</param>
        /// <returns>A OrganizationType object, null if not found</returns>
		public OrganizationType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETORGANIZATIONTYPEBYID) )
			{
				AddParameters( cmd, pInt64( OrganizationType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all OrganizationType objects 
        /// </summary>
        /// <returns>A list of OrganizationType objects</returns>
		public OrganizationTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLORGANIZATIONTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills OrganizationType object
        /// </summary>
        /// <param name="organizationTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( OrganizationTypeBase organizationTypeObject, SqlDataReader reader, int start )
		{
			organizationTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			organizationTypeObject.ID = reader.GetInt64(start + 0);
			organizationTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) organizationTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			organizationTypeObject.ReadOnly = reader.GetBoolean(start + 3);
			FillBaseObject(organizationTypeObject, reader, (start + 4));
		}

		protected void FillObject( OrganizationTypeBase organizationTypeObject, SqlDataReader reader )
		{
			FillObject( organizationTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves OrganizationType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>OrganizationType object</returns>
		private OrganizationType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					OrganizationType organizationTypeObject= new OrganizationType();
					FillObject( organizationTypeObject, reader );
					return organizationTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of OrganizationType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of OrganizationType objects</returns>
		private OrganizationTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			OrganizationTypeList list = new OrganizationTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					OrganizationType organizationTypeObject = new OrganizationType();
					FillObject( organizationTypeObject, reader );

					list.Add( organizationTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

