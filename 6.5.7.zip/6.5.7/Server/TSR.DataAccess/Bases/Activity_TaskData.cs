using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class Activity_TaskData : BaseRelationData
	{
		private const string INSERTACTIVITY_TASK = "InsertActivity_Task";
		private const string UPDATEACTIVITY_TASK = "UpdateActivity_Task";
		private const string DELETEACTIVITY_TASK = "DeleteActivity_Task";
		private const string GETACTIVITY_TASKBYID = "GetActivity_TaskByID";
		private const string GETALLACTIVITY_TASK = "GetAllActivity_Task";

        #region Constructors

		public Activity_TaskData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="activity_TaskObject"></param>
		private void AddCommonParams( SqlCommand cmd, Activity_TaskBase activity_TaskObject )
		{
			AddParameter(cmd, pInt64(Activity_TaskBase.Property_ActivityID, activity_TaskObject.ActivityID));
			AddParameter(cmd, pInt64(Activity_TaskBase.Property_TaskID, activity_TaskObject.TaskID));
		}

        /// <summary>
        /// Inserts Activity_Task
        /// </summary>
        /// <param name="activity_TaskObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Activity_TaskBase activity_TaskObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTACTIVITY_TASK );
	
				AddParameter(cmd, pInt64Out(Activity_TaskBase.Property_ID, activity_TaskObject.ID));
				AddCommonParams( cmd, activity_TaskObject );
				AddBaseParametersForInsert( cmd, activity_TaskObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					activity_TaskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Activity_TaskBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( activity_TaskObject, x );
			}
		}
		
        /// <summary>
        /// Updates Activity_Task 
        /// </summary>
        /// <param name="activity_TaskObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Activity_TaskBase activity_TaskObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEACTIVITY_TASK );

				AddParameter(cmd, pInt64(Activity_TaskBase.Property_ID, activity_TaskObject.ID));
				AddCommonParams( cmd, activity_TaskObject );
				AddBaseParametersForUpdate( cmd, activity_TaskObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					activity_TaskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( activity_TaskObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Activity_Task
        /// </summary>
        /// <param name="ID">ID of the Activity_Task object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEACTIVITY_TASK );
	
				AddParameters( cmd, pInt64( Activity_Task.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Activity_Task ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Activity_Task object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Activity_Task object to retrieve</param>
        /// <returns>A Activity_Task object, null if not found</returns>
		public Activity_Task Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETACTIVITY_TASKBYID) )
			{
				AddParameters( cmd, pInt64( Activity_Task.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Activity_Task objects 
        /// </summary>
        /// <returns>A list of Activity_Task objects</returns>
		public Activity_TaskList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLACTIVITY_TASK ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Activity_Task object
        /// </summary>
        /// <param name="activity_TaskObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Activity_TaskBase activity_TaskObject, SqlDataReader reader, int start )
		{
			activity_TaskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			activity_TaskObject.ID = reader.GetInt64(start + 0);
			activity_TaskObject.ActivityID = reader.GetInt64(start + 1);
			activity_TaskObject.TaskID = reader.GetInt64(start + 2);
			FillBaseObject(activity_TaskObject, reader, (start + 3));
		}

		protected void FillObject( Activity_TaskBase activity_TaskObject, SqlDataReader reader )
		{
			FillObject( activity_TaskObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Activity_Task object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Activity_Task object</returns>
		private Activity_Task GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Activity_Task activity_TaskObject= new Activity_Task();
					FillObject( activity_TaskObject, reader );
					return activity_TaskObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Activity_Task objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Activity_Task objects</returns>
		private Activity_TaskList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Activity_TaskList list = new Activity_TaskList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Activity_Task activity_TaskObject = new Activity_Task();
					FillObject( activity_TaskObject, reader );

					list.Add( activity_TaskObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

