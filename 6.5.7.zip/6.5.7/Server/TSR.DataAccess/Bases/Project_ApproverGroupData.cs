﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Project_ApproverGroupData : BaseRelationData
    {
        private const string INSERTPROJECT_APPROVERGROUP = "InsertProject_ApproverGroup";
        private const string UPDATEPROJECT_APPROVERGROUP = "UpdateProject_ApproverGroup";
        private const string DELETEPROJECT_APPROVERGROUP = "DeleteProject_ApproverGroup";
        private const string GETPROJECT_APPROVERGROUPBYID = "GetProject_ApproverGroupByID";		

        #region Constructors

        public Project_ApproverGroupData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="project_UserGroupObject"></param>
		private void AddCommonParams( SqlCommand cmd, Project_ApproverGroupBase project_ApproverGroupObject )
		{
            AddParameter(cmd, pInt64(Project_ApproverGroupBase.Property_ProjectID, project_ApproverGroupObject.ProjectID));
            AddParameter(cmd, pInt64(Project_ApproverGroupBase.Property_ApproverGroupID, project_ApproverGroupObject.ApproverGroupID));
		}

        /// <summary>
        /// Inserts Project_ApproverGroup
        /// </summary>
        /// <param name="project_ApproverGroupObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(Project_ApproverGroupBase project_ApproverGroupObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand(INSERTPROJECT_APPROVERGROUP);

                AddParameter(cmd, pInt64Out(Project_ApproverGroupBase.Property_ID, project_ApproverGroupObject.ID));
                AddCommonParams(cmd, project_ApproverGroupObject);
                AddBaseParametersForInsert(cmd, project_ApproverGroupObject);

				long result = InsertRecord( cmd );
				if (result > 0)
                    project_ApproverGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, Project_ApproverGroupBase.Property_ID);
			}
			catch( SqlException x )
			{
                throw new Framework.Exceptions.ObjectInsertException(project_ApproverGroupObject, x);
			}
		}
		
        /// <summary>
        /// Updates Project_ApproverGroup 
        /// </summary>
        ///<param name="projectID"></param>
        ///<param name="approverGroupID"></param>
        /// <returns>Number of rows affected</returns>
        public long Update(long projectID, long approverGroupID)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEPROJECT_APPROVERGROUP);

                AddParameter(cmd, pInt64(Project_ApproverGroupBase.Property_ProjectID, projectID));
                AddParameter(cmd, pInt64(Project_ApproverGroupBase.Property_ApproverGroupID, approverGroupID));
	
				long result = UpdateRecord( cmd );				
				return result;
			}
			catch( SqlException x )
			{
                throw new Framework.Exceptions.ObjectUpdateException(typeof(Project_ApproverGroupBase),projectID, x);
			}			
		}

        /// <summary>
        /// Deletes Project_ApproverGroup
        /// </summary>
        /// <param name="ID">ID of the Project_ApproverGroup object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECT_APPROVERGROUP );
	
				AddParameters( cmd, pInt64( Project_ApproverGroup.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Project_ApproverGroup ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Project_ApproverGroup object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Project_ApproverGroup object to retrieve</param>
        /// <returns>A Project_ApproverGroup object, null if not found</returns>
		public Project_ApproverGroup Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPROJECT_APPROVERGROUPBYID))
			{
				AddParameters( cmd, pInt64( Project_ApproverGroup.Property_ID, ID));

				return GetObject(cmd);
			}
		}        

        /// <summary>
        /// Fills Project_ApproverGroup object
        /// </summary>
        /// <param name="project_UserGroupObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(Project_ApproverGroupBase project_ApproverGroupObject, SqlDataReader reader, int start)
		{
            project_ApproverGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            project_ApproverGroupObject.ID = reader.GetInt64(start + 0);
            project_ApproverGroupObject.ProjectID = reader.GetInt64(start + 1);
            project_ApproverGroupObject.ApproverGroupID = reader.GetInt64(start + 2);
            FillBaseObject(project_ApproverGroupObject, reader, (start + 3));
		}

        protected void FillObject(Project_ApproverGroupBase project_ApproverGroupObject, SqlDataReader reader)
		{
            FillObject(project_ApproverGroupObject, reader, 0);
		}

        /// <summary>
        /// Retrieves Project_ApproverGroup object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Project_ApproverGroup object</returns>
		private Project_ApproverGroup GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read())
				{
                    Project_ApproverGroup project_ApproverGroupObject = new Project_ApproverGroup();
                    FillObject(project_ApproverGroupObject, reader);
                    return project_ApproverGroupObject;
				}
				else
				{
					return null;
				}				
			}
		}       
    }
}
