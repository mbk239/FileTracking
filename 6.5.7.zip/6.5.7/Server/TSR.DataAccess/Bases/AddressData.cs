using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class AddressData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Address;

		private const string INSERTADDRESS = "InsertAddress";
		private const string UPDATEADDRESS = "UpdateAddress";
		private const string DELETEADDRESS = "DeleteAddress";
		private const string GETADDRESSBYID = "GetAddressByID";
		private const string GETALLADDRESS = "GetAllAddress";
      
        #region Constructors

		public AddressData(UserContext context) : base(context) { LOCK_Address = this; }
		public AddressData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Address = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="addressObject"></param>
		private void AddCommonParams( SqlCommand cmd, AddressBase addressObject )
		{
			AddParameter(cmd, pInt64(AddressBase.Property_AddressTypeID, addressObject.AddressTypeID));
			AddParameter(cmd, pBool(AddressBase.Property_Preferred, addressObject.Preferred));
            AddParameter(cmd, pNVarChar(AddressBase.Property_Street1, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, addressObject.Street1));
            AddParameter(cmd, pNVarChar(AddressBase.Property_Street2, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, addressObject.Street2));
            AddParameter(cmd, pNVarChar(AddressBase.Property_City, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, addressObject.City));
            AddParameter(cmd, pNVarChar(AddressBase.Property_State, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, addressObject.State));
            AddParameter(cmd, pVarChar(AddressBase.Property_ZipCode, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, addressObject.ZipCode));
			//AddParameter(cmd, pInt64(AddressBase.Property_CountryID, addressObject.CountryID));
            AddParameter(cmd, pVarChar(AddressBase.Property_CountryName,ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH,  addressObject.CountryName));
		}

        /// <summary>
        /// Inserts Address
        /// </summary>
        /// <param name="addressObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( AddressBase addressObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTADDRESS );
	
				AddParameter(cmd, pInt64Out(AddressBase.Property_ID, addressObject.ID));
				AddCommonParams( cmd, addressObject );
				AddBaseParametersForInsert( cmd, addressObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					addressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, AddressBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( addressObject, x );
			}
		}
		
        /// <summary>
        /// Updates Address 
        /// </summary>
        /// <param name="addressObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( AddressBase addressObject)
		{
            lock (LOCK_Address)
            {
				try
				{
                    AddressBase dbObject = Get(addressObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(addressObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != addressObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != addressObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(addressObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEADDRESS );

				AddParameter(cmd, pInt64(AddressBase.Property_ID, addressObject.ID));
					AddCommonParams( cmd, addressObject );
					AddBaseParametersForUpdate( cmd, addressObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						addressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( addressObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Address
        /// </summary>
        /// <param name="ID">ID of the Address object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEADDRESS );
	
				AddParameters( cmd, pInt64( Address.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Address ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Address object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Address object to retrieve</param>
        /// <returns>A Address object, null if not found</returns>
		public Address Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETADDRESSBYID) )
			{
				AddParameters( cmd, pInt64( Address.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Address objects 
        /// </summary>
        /// <returns>A list of Address objects</returns>
		public AddressList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLADDRESS ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Address object
        /// </summary>
        /// <param name="addressObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( AddressBase addressObject, SqlDataReader reader, int start )
		{
			addressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			addressObject.ID = reader.GetInt64(start + 0);
			addressObject.AddressTypeID = reader.GetInt64(start + 1);
			addressObject.Preferred = reader.GetBoolean(start + 2);
			if (!reader.IsDBNull(start + 3)) addressObject.Street1 = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) addressObject.Street2 = ReverseToHTMLCode(reader.GetString(start + 4));
			if (!reader.IsDBNull(start + 5)) addressObject.City = ReverseToHTMLCode(reader.GetString(start + 5));
            if (!reader.IsDBNull(start + 6)) addressObject.State = ReverseToHTMLCode(reader.GetString(start + 6));
			if (!reader.IsDBNull(start + 7)) addressObject.ZipCode = ReverseToHTMLCode(reader.GetString(start + 7));
			//if (!reader.IsDBNull(start + 8)) addressObject.CountryID = reader.GetInt64(start + 8);
            if (!reader.IsDBNull(start + 8)) addressObject.CountryName = ReverseToHTMLCode(reader.GetString(start + 8));
			FillBaseObject(addressObject, reader, (start + 9));
		}

		protected void FillObject( AddressBase addressObject, SqlDataReader reader )
		{
			FillObject( addressObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Address object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Address object</returns>
		private Address GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Address addressObject= new Address();
					FillObject( addressObject, reader );
					return addressObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Address objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Address objects</returns>
		private AddressList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			AddressList list = new AddressList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Address addressObject = new Address();
					FillObject( addressObject, reader );

					list.Add( addressObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

