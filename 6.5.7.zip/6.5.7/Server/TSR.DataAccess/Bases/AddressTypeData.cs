using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class AddressTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_AddressType;

		private const string INSERTADDRESSTYPE = "InsertAddressType";
		private const string UPDATEADDRESSTYPE = "UpdateAddressType";
		private const string DELETEADDRESSTYPE = "DeleteAddressType";
		private const string GETADDRESSTYPEBYID = "GetAddressTypeByID";
		private const string GETALLADDRESSTYPE = "GetAllAddressType";

        #region Constructors

		public AddressTypeData(UserContext context) : base(context) { LOCK_AddressType = this; }
		public AddressTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_AddressType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="addressTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, AddressTypeBase addressTypeObject )
		{
			AddParameter(cmd, pNVarChar(AddressTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, addressTypeObject.Name));
			AddParameter(cmd, pNText(AddressTypeBase.Property_Description, addressTypeObject.Description));
			AddParameter(cmd, pBool(AddressTypeBase.Property_ReadOnly, addressTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts AddressType
        /// </summary>
        /// <param name="addressTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( AddressTypeBase addressTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTADDRESSTYPE );
	
				AddParameter(cmd, pInt64InOut(AddressTypeBase.Property_ID, addressTypeObject.ID));
				AddCommonParams( cmd, addressTypeObject );
				AddBaseParametersForInsert( cmd, addressTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					addressTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, AddressTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( addressTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates AddressType 
        /// </summary>
        /// <param name="addressTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( AddressTypeBase addressTypeObject)
		{
            lock (LOCK_AddressType)
            {
				try
				{
                    AddressTypeBase dbObject = Get(addressTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(addressTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != addressTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != addressTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(addressTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEADDRESSTYPE );

				AddParameter(cmd, pInt64(AddressTypeBase.Property_ID, addressTypeObject.ID));
					AddCommonParams( cmd, addressTypeObject );
					AddBaseParametersForUpdate( cmd, addressTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						addressTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( addressTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes AddressType
        /// </summary>
        /// <param name="ID">ID of the AddressType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEADDRESSTYPE );
	
				AddParameters( cmd, pInt64( AddressType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( AddressType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves AddressType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the AddressType object to retrieve</param>
        /// <returns>A AddressType object, null if not found</returns>
		public AddressType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETADDRESSTYPEBYID) )
			{
				AddParameters( cmd, pInt64( AddressType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all AddressType objects 
        /// </summary>
        /// <returns>A list of AddressType objects</returns>
		public AddressTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLADDRESSTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills AddressType object
        /// </summary>
        /// <param name="addressTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( AddressTypeBase addressTypeObject, SqlDataReader reader, int start )
		{
			addressTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			addressTypeObject.ID = reader.GetInt64(start + 0);
			addressTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) addressTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			addressTypeObject.ReadOnly = reader.GetBoolean(start + 3);
			FillBaseObject(addressTypeObject, reader, (start + 4));
		}

		protected void FillObject( AddressTypeBase addressTypeObject, SqlDataReader reader )
		{
			FillObject( addressTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves AddressType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>AddressType object</returns>
		private AddressType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					AddressType addressTypeObject= new AddressType();
					FillObject( addressTypeObject, reader );
					return addressTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of AddressType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of AddressType objects</returns>
		private AddressTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			AddressTypeList list = new AddressTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					AddressType addressTypeObject = new AddressType();
					FillObject( addressTypeObject, reader );

					list.Add( addressTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

