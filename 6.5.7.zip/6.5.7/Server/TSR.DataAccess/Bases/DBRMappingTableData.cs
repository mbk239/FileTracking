using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class DBRMappingTableData : BaseDataAccess
	{
		private const string INSERTDBRMAPPINGTABLE = "InsertDBRMappingTable";
		private const string UPDATEDBRMAPPINGTABLE = "UpdateDBRMappingTable";
		private const string DELETEDBRMAPPINGTABLE = "DeleteDBRMappingTable";
		private const string GETDBRMAPPINGTABLEBYID = "GetDBRMappingTableByID";
		private const string GETALLDBRMAPPINGTABLE = "GetAllDBRMappingTable";

        #region Constructors

		public DBRMappingTableData(UserContext context) : base(context) { }
		public DBRMappingTableData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="dBRMappingTableObject"></param>
        private void AddCommonParams(SqlCommand cmd, DBRMappingTableBase dBRMappingTableObject)
		{
            AddParameter(cmd, pInt32(DBRMappingTable.Property_EntityTypeID, dBRMappingTableObject.EntityTypeID));
            AddParameter(cmd, pNVarChar(DBRMappingTable.Property_SourceID, 255, dBRMappingTableObject.SourceID));
            AddParameter(cmd, pInt64(DBRMappingTable.Property_DestinationID, dBRMappingTableObject.DestinationID));
            AddParameter(cmd, pNVarChar(DBRMappingTable.Property_ApplicationID, 255, dBRMappingTableObject.ApplicationID));
            AddParameter(cmd, pDateTime(DBRMappingTable.Property_ImportTimeStamp, dBRMappingTableObject.ImportTimeStamp));
		}

        /// <summary>
        /// Inserts DBRMappingTable
        /// </summary>
        /// <param name="dBRMappingTableObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(DBRMappingTableBase dBRMappingTableObject)
		{            
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTDBRMAPPINGTABLE );
	
				AddParameter(cmd, pInt64Out(DBRMappingTableBase.Property_ID, dBRMappingTableObject.ID));
				AddCommonParams( cmd, dBRMappingTableObject );
				AddBaseParametersForInsert( cmd, dBRMappingTableObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					dBRMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, DBRMappingTableBase.Property_ID);
			}
			catch( SqlException x )
			{
                throw x;
                //return 0;
			}
            return 0;
		}
		
        /// <summary>
        /// Updates DBRMappingTable 
        /// </summary>
        /// <param name="dBRMappingTableObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( DBRMappingTableBase dBRMappingTableObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEDBRMAPPINGTABLE );

				AddParameter(cmd, pInt64(DBRMappingTableBase.Property_ID, dBRMappingTableObject.ID));
				AddCommonParams( cmd, dBRMappingTableObject );
				AddBaseParametersForUpdate( cmd, dBRMappingTableObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					dBRMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
                throw x;
                //return 0;
			}
            return 0;
		}

        /// <summary>
        /// Deletes DBRMappingTable
        /// </summary>
        /// <param name="ID">ID of the DBRMappingTable object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEDBRMAPPINGTABLE );
	
				AddParameters( cmd, pInt64( DBRMappingTable.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( DBRMappingTable ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves DBRMappingTable object using it's ID
        /// </summary>
        /// <param name="ID">The id of the DBRMappingTable object to retrieve</param>
        /// <returns>A DBRMappingTable object, null if not found</returns>
		public DBRMappingTable Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETDBRMAPPINGTABLEBYID) )
			{
				AddParameters( cmd, pInt64( DBRMappingTable.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        ///// <summary>
        ///// Retrieves all DBRMappingTable objects 
        ///// </summary>
        ///// <returns>A list of DBRMappingTable objects</returns>
        //public DBRMappingTableList GetAll( )
        //{
        //    using( SqlCommand cmd = GetSPCommand( GETALLDBRMAPPINGTABLE ) )
        //    {
        //        return GetList( cmd, ALL_AVAILABLE_RECORDS );
        //    }
        //}

        /// <summary>
        /// Fills DBRMappingTable object
        /// </summary>
        /// <param name="dBRMappingTableObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( DBRMappingTableBase dBRMappingTableObject, SqlDataReader reader, int start )
		{
			dBRMappingTableObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			dBRMappingTableObject.ID = reader.GetInt64(start + 0);
			dBRMappingTableObject.EntityTypeID = reader.GetInt32(start + 1);
			dBRMappingTableObject.SourceID = ReverseToHTMLCode(reader.GetString(start + 2));
			dBRMappingTableObject.DestinationID = reader.GetInt64(start + 3);
            dBRMappingTableObject.ApplicationID = ReverseToHTMLCode(reader.GetString(start + 4));
			dBRMappingTableObject.ImportTimeStamp = reader.GetDateTime(start + 5);
			FillBaseObject(dBRMappingTableObject, reader, (start + 6));
		}

		protected void FillObject( DBRMappingTableBase dBRMappingTableObject, SqlDataReader reader )
		{
			FillObject( dBRMappingTableObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves DBRMappingTable object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>DBRMappingTable object</returns>
		private DBRMappingTable GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					DBRMappingTable dBRMappingTableObject= new DBRMappingTable();
					FillObject( dBRMappingTableObject, reader );
					return dBRMappingTableObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of DBRMappingTable objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of DBRMappingTable objects</returns>
        private DBRMappingTableList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            DBRMappingTableList list = new  DBRMappingTableList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    DBRMappingTable dBRMappingTableObject = new DBRMappingTable();
                    FillObject(dBRMappingTableObject, reader);

                    list.Add(dBRMappingTableObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }       
    }
}

