﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using TSR.Entities.Bases;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class NotificationFieldData : BaseDataAccess
    {
        private const string INSERTNOTIFICATIONFIELD = "InsertNotificationField";
        private const string UPDATENOTIFICATIONFIELD = "UpdateNotificationField";
        private const string DELETENOTIFICATIONFIELD = "DeleteNotificationField";
        private const string GETNOTIFICATIONFIELDBYID = "GetNotificationFieldByID";
        private const string GETALLNOTIFICATIONFIELD = "GetAllNotificationField";       

        #region Constructors

        public NotificationFieldData(UserContext context) : base(context) { }
        public NotificationFieldData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="NotificationObject"></param>
        private void AddCommonParams(SqlCommand cmd, NotificationFieldBase notificationObject)
        {
            AddParameter(cmd, pInt64(NotificationFieldBase.Property_NotificationID, notificationObject.NotificationID));
            AddParameter(cmd, pDateTime(NotificationFieldBase.Property_NotificationDate, notificationObject.NotificationDate));
            AddParameter(cmd, pDouble(NotificationFieldBase.Property_ApprovedHours, notificationObject.ApprovedHours));
            AddParameter(cmd, pDouble(NotificationFieldBase.Property_WorkingHours, notificationObject.WorkingHours));
            
        }

        /// <summary>
        /// Inserts Notification
        /// </summary>
        /// <param name="NotificationObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(NotificationFieldBase notificationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTNOTIFICATIONFIELD);

                AddParameter(cmd, pInt64Out(NotificationFieldBase.Property_ID, notificationObject.ID));
                AddCommonParams(cmd, notificationObject);
                AddBaseParametersForInsert(cmd, notificationObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    notificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, NotificationFieldBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(notificationObject, x);
            }
        }

        /// <summary>
        /// Updates Notification 
        /// </summary>
        /// <param name="NotificationObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(NotificationFieldBase NotificationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATENOTIFICATIONFIELD);

                AddParameter(cmd, pInt64(NotificationFieldBase.Property_ID, NotificationObject.ID));
                AddCommonParams(cmd, NotificationObject);
                AddBaseParametersForUpdate(cmd, NotificationObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    NotificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(NotificationObject, x);
            }

        }

        /// <summary>
        /// Deletes Notification
        /// </summary>
        /// <param name="ID">ID of the Notification object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETENOTIFICATIONFIELD);

                AddParameters(cmd, pInt64(NotificationFieldBase.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(NotificationField), ID, x);
            }

        }

        /// <summary>
        /// Retrieves Notification object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Notification object to retrieve</param>
        /// <returns>A Notification object, null if not found</returns>
        public NotificationField Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETNOTIFICATIONFIELDBYID))
            {
                AddParameters(cmd, pInt64(NotificationFieldBase.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Notification objects 
        /// </summary>
        /// <returns>A list of Notification objects</returns>
        public NotificationFieldList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLNOTIFICATIONFIELD))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Notification object
        /// </summary>
        /// <param name="NotificationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(NotificationFieldBase notificationObject, SqlDataReader reader, int start)
        {
            notificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            notificationObject.ID = reader.GetInt64(start + 0);
            notificationObject.NotificationID= reader.GetInt64(start + 1);
            notificationObject.ApprovedHours = reader.GetDouble(start + 2);
            notificationObject.WorkingHours = reader.GetDouble(start + 3);
            FillBaseObject(notificationObject, reader, (start + 4));
        }

        protected void FillObject(NotificationFieldBase NotificationObject, SqlDataReader reader)
        {
            FillObject(NotificationObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Notification object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Notification object</returns>
        private NotificationField GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    NotificationField NotificationObject = new NotificationField();
                    FillObject(NotificationObject, reader);
                    return NotificationObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Notification objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Notification objects</returns>
        private NotificationFieldList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            NotificationFieldList list = new NotificationFieldList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    NotificationField NotificationObject = new NotificationField();
                    FillObject(NotificationObject, reader);

                    list.Add(NotificationObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}
