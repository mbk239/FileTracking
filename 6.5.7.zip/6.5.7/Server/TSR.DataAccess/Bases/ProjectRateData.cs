﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.DataAccess.Bases
{
    public class ProjectRateData : BaseDataAccess
    {
         private const string GETPROJECTRATEBYID = "GetProjectRateByID";
        private const string GETPROJECTRATEBYPROJECTID = "GetProjectRateByProjectID";
        private const string INSERTPROJECTRATE = "InsertProjectRate";
        private const string UPDATEPROJECTRATE = "UpdateProjectRate";
        private const string DELETEPROJECTRATE = "DeleteProjectRate";
        private static BaseDataAccess LOCK_Rate;
        public ProjectRateData(UserContext context) : base(context)
        {
            LOCK_Rate = this;
        }

        public ProjectRateData(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
            LOCK_Rate = this;
        }

        #region Fill Data
        public ProjectRateList GetAllRateByProjectID(long projectID)
        {
            SqlCommand cmd = GetSPCommand(GETPROJECTRATEBYPROJECTID);
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        private ProjectRateList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            var list = new ProjectRateList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    var proRateObj = new ProjectRate();
                    FillObject(proRateObj, reader);
                    list.Add(proRateObj);
                }

                reader.Close();
            }

            return list;
        }
        protected void FillObject(ProjectRate proRateObj, SqlDataReader reader)
        {
            FillObject(proRateObj, reader, 0);
        }
        protected void FillObject(ProjectRate proRateObj, SqlDataReader reader, int start)
        {
            proRateObj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            proRateObj.ID = reader.GetInt64(start + 0);
            proRateObj.ProjectID = reader.GetInt64(start + 1);
            proRateObj.RateID = reader.GetInt64(start + 2);
            proRateObj.Cost = reader.GetDecimal(start + 3);
            proRateObj.Revenue = reader.GetDecimal(start + 4);
            proRateObj.CreatorID = reader.GetInt64(start +5);
            proRateObj.CreatedTimeStamp = reader.GetDateTime(start + 6);
            proRateObj.ModifierID = reader.GetInt64(start + 7);
            proRateObj.ModifiedTimeStamp = reader.GetDateTime(start + 8);
            //FillBaseObject(rateObj, reader, (start + 4));
        }
        public ProjectRate Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETPROJECTRATEBYID))
            {
                AddParameters(cmd, pInt64(ProjectRate.Property_RateID, ID));
                return GetObject(cmd);
            }
        }
        private ProjectRate GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    var proRateObj = new ProjectRate();
                    FillObject(proRateObj, reader);
                    return proRateObj;
                }
                return null;
            }
        }
        #endregion

        #region Add Or Update
        private long Insert(ProjectRate proRateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTPROJECTRATE);

                // AddParameter(cmd, pInt64(ActivityRate.Property_ID, activityRateObject.ID));
                AddParameter(cmd, pInt64Out(ProjectRate.Property_ID, proRateObject.ID));
                AddParameter(cmd, pInt64(ProjectRate.Property_ProjectID, proRateObject.ProjectID));
                AddParameter(cmd, pInt64(ProjectRate.Property_RateID, proRateObject.RateID));
                AddParameter(cmd, pDecimal(ProjectRate.Property_Cost, proRateObject.Cost));
                AddParameter(cmd, pDecimal(ProjectRate.Property_Revenue, proRateObject.Revenue));
                //AddCommonParams(cmd, activityRateObject);

                AddBaseParametersForInsert(cmd, proRateObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    proRateObject.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                return (long)GetOutParameter(cmd, ProjectRate.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(proRateObject, x);
            }
        }
        private long Update(ProjectRate proRateObject)
        {
            lock (LOCK_Rate)
            {
                try
                {
                    var dbObject = Get(proRateObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(proRateObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != proRateObject.ModifiedTimeStamp.ToString())
                        throw new Framework.Exceptions.DataIntegrityFailedException(proRateObject, null);

                    dbObject.CloneBase(proRateObject);

                    SqlCommand cmd = GetSPCommand(UPDATEPROJECTRATE);

                    AddParameter(cmd, pInt64(ProjectRate.Property_ID, proRateObject.ID));
                    AddParameter(cmd, pInt64(ProjectRate.Property_ProjectID, proRateObject.ProjectID));
                    AddParameter(cmd, pInt64(ProjectRate.Property_RateID, proRateObject.RateID));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Cost, proRateObject.Cost));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Revenue, proRateObject.Revenue));
                    // AddCommonParams(cmd, proRateObject);
                    AddBaseParametersForUpdate(cmd, proRateObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        proRateObject.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(proRateObject, x);
                }
            }
        }
        public long AddOrUpdate(ProjectRate proRateObject)
        {
            lock (LOCK_Rate)
            {
                try
                {
                    SqlCommand cmd;
                    if (proRateObject.RateID == 0)
                    {
                        cmd = GetSPCommand(INSERTPROJECTRATE);
                       
                    }

                    else
                    {
                        var dbObject = Get(proRateObject.RateID);
                        if (dbObject == null)
                            throw new Framework.Exceptions.ObjectUpdateException(proRateObject, null);
                        else
                        {
                            //if (dbObject.ModifiedTimeStamp.ToString() != proRateObject.ModifiedTimeStamp.ToString())
                            //    throw new Framework.Exceptions.DataIntegrityFailedException(proRateObject, null);
                            cmd = GetSPCommand(UPDATEPROJECTRATE);
                            dbObject.CloneBase(proRateObject);

                          
                        }
                    }

                    AddParameter(cmd, pInt64(ProjectRate.Property_ID, proRateObject.ID));
                    AddParameter(cmd, pInt64(ProjectRate.Property_ProjectID, proRateObject.ProjectID));
                    AddParameter(cmd, pInt64(ProjectRate.Property_RateID, proRateObject.RateID));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Cost, proRateObject.Cost));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Revenue, proRateObject.Revenue));
                    if (proRateObject.ID == 0)
                        AddBaseParametersForInsert(cmd, proRateObject);
                    else
                        AddBaseParametersForUpdate(cmd, proRateObject);

                    // AddCommonParams(cmd, proRateObject);
                    long result = ExecuteCommand(cmd);
                    if (result > 0)
                        proRateObject.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(proRateObject, x);
                }
            }
        }
        #endregion

        #region Delete
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEPROJECTRATE);

                AddParameters(cmd, pInt64(ProjectRate.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(ProjectRate), ID, x);
            }

        }
        #endregion
    }
}
