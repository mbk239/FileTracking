﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities.Bases;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class LocationData : BaseDataAccess
    {
        #region[Constants for StoreProcedure]
        private const string INSERTLOCATION = "InsertLocation";
        private const string UPDATELOCATION = "UpdateLocation";
        private const string DELETELOCATION = "DeleteLocation";
        private const string GETLOCATIONBYID = "GetLocationByID";
        private const string GETLOCATIONBYNAME = "GetLocationByName";
        private const string GETALLLOCATION = "GetAllLocation";
        private const string GETLOCATIONFORPAGING = "GetLocationForPaging";
        #endregion

        //Constructor
        public LocationData(UserContext context) : base(context) { }
        public LocationData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="locationObject"></param>
        private void AddCommonParams(SqlCommand cmd, LocationBase locationObject)
        {
            AddParameter(cmd, pNVarChar(LocationBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, locationObject.Name));
            AddParameter(cmd, pNText(LocationBase.Property_Description, locationObject.Description));
            AddParameter(cmd, pNVarChar(LocationBase.Property_ForeignKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, locationObject.ForeignKey));
            AddParameter(cmd, pBool(LocationBase.Property_IsActivate, locationObject.IsActivate));
        }

        /// <summary>
        /// Inserts Location
        /// </summary>
        /// <param name="activityTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(LocationBase locationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTLOCATION);

                AddParameter(cmd, pInt64Out(LocationBase.Property_ID, locationObject.ID));
                AddCommonParams(cmd, locationObject);
                AddBaseParametersForInsert(cmd, locationObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    locationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, LocationBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(locationObject, x);
            }
        }

        /// <summary>
        /// Updates Location 
        /// </summary>
        /// <param name="expenseTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(LocationBase locationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATELOCATION);

                AddParameter(cmd, pInt64(LocationBase.Property_ID, locationObject.ID));
                AddCommonParams(cmd, locationObject);
                AddBaseParametersForUpdate(cmd, locationObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    locationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(locationObject, x);
            }

        }

        /// <summary>
        /// Deletes Location
        /// </summary>
        /// <param name="ID">ID of the ExpenseType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETELOCATION);

                AddParameters(cmd, pInt64(Location.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Location), ID, x);
            }

        }

        /// <summary>
        /// Fills Location object
        /// </summary>
        /// <param name="locationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(LocationBase locationObject, SqlDataReader reader, int start)
        {
            locationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            locationObject.ID = reader.GetInt64(start + 0);
            locationObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) locationObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) locationObject.ForeignKey = ReverseToHTMLCode(reader.GetString(start + 3));
            locationObject.IsActivate = reader.GetBoolean(start + 4);
            FillBaseObject(locationObject, reader, (start + 5));
        }

        protected void FillObject(LocationBase locationObject, SqlDataReader reader)
        {
            FillObject(locationObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Location object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Location object</returns>
        private Location GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    Location locationObject = new Location();
                    FillObject(locationObject, reader);
                    return locationObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Location objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Location objects</returns>
        private LocationList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            LocationList list = new LocationList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Location locationObject = new Location();
                    FillObject(locationObject, reader);

                    list.Add(locationObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        /// <summary>
        /// Retrieves Location object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Location object to retrieve</param>
        /// <returns>A Location object, null if not found</returns>
        public Location Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCATIONBYID))
            {
                AddParameters(cmd, pInt64(Location.Property_ID, ID));
                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves Location object using it's name
        /// </summary>
        /// <param name="ID">The id of the Location object to retrieve</param>
        /// <returns>A Location object, null if not found</returns>
        public Location GetByName(string Name)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCATIONBYNAME))
            {
                AddParameters(cmd, pNVarChar(Location.Property_Name,ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, Name));
                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Location objects 
        /// </summary>
        /// <returns>A list of Location objects</returns>
        public LocationList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLLOCATION))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        protected void FillObject_View(LocationBase locationObject, SqlDataReader reader)
        {
            locationObject.ID = reader.GetInt64(0);
            locationObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

        private LocationList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            LocationList list = new LocationList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Location locationObject = new Location();
                    FillObject_View(locationObject, reader);

                    list.Add(locationObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        public LocationList GetLocationPaging(int startOffset, int numberOfItems, string name, out int total)
        {
            LocationList lst = new LocationList();
            using (SqlCommand cmd = GetSPCommand(GETLOCATIONFORPAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);
                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }
    }
}
