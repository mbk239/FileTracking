using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Organization_AddressData : BaseRelationData
	{
		private const string INSERTORGANIZATION_ADDRESS = "InsertOrganization_Address";
		private const string UPDATEORGANIZATION_ADDRESS = "UpdateOrganization_Address";
		private const string DELETEORGANIZATION_ADDRESS = "DeleteOrganization_Address";
		private const string GETORGANIZATION_ADDRESSBYID = "GetOrganization_AddressByID";
		private const string GETALLORGANIZATION_ADDRESS = "GetAllOrganization_Address";

        #region Constructors

		public Organization_AddressData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organization_AddressObject"></param>
		private void AddCommonParams( SqlCommand cmd, Organization_AddressBase organization_AddressObject )
		{
			AddParameter(cmd, pInt64(Organization_AddressBase.Property_OrganizationID, organization_AddressObject.OrganizationID));
			AddParameter(cmd, pInt64(Organization_AddressBase.Property_AddressID, organization_AddressObject.AddressID));
		}

        /// <summary>
        /// Inserts Organization_Address
        /// </summary>
        /// <param name="organization_AddressObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Organization_AddressBase organization_AddressObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTORGANIZATION_ADDRESS );
	
				AddParameter(cmd, pInt64Out(Organization_AddressBase.Property_ID, organization_AddressObject.ID));
				AddCommonParams( cmd, organization_AddressObject );
				AddBaseParametersForInsert( cmd, organization_AddressObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					organization_AddressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Organization_AddressBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( organization_AddressObject, x );
			}
		}
		
        /// <summary>
        /// Updates Organization_Address 
        /// </summary>
        /// <param name="organization_AddressObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Organization_AddressBase organization_AddressObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEORGANIZATION_ADDRESS );

				AddParameter(cmd, pInt64(Organization_AddressBase.Property_ID, organization_AddressObject.ID));
				AddCommonParams( cmd, organization_AddressObject );
				AddBaseParametersForUpdate( cmd, organization_AddressObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					organization_AddressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( organization_AddressObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Organization_Address
        /// </summary>
        /// <param name="ID">ID of the Organization_Address object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEORGANIZATION_ADDRESS );
	
				AddParameters( cmd, pInt64( Organization_Address.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Organization_Address ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Organization_Address object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Organization_Address object to retrieve</param>
        /// <returns>A Organization_Address object, null if not found</returns>
		public Organization_Address Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETORGANIZATION_ADDRESSBYID) )
			{
				AddParameters( cmd, pInt64( Organization_Address.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Organization_Address objects 
        /// </summary>
        /// <returns>A list of Organization_Address objects</returns>
		public Organization_AddressList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLORGANIZATION_ADDRESS ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Organization_Address object
        /// </summary>
        /// <param name="organization_AddressObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Organization_AddressBase organization_AddressObject, SqlDataReader reader, int start )
		{
			organization_AddressObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			organization_AddressObject.ID = reader.GetInt64(start + 0);
			organization_AddressObject.OrganizationID = reader.GetInt64(start + 1);
			organization_AddressObject.AddressID = reader.GetInt64(start + 2);
			FillBaseObject(organization_AddressObject, reader, (start + 3));
		}

		protected void FillObject( Organization_AddressBase organization_AddressObject, SqlDataReader reader )
		{
			FillObject( organization_AddressObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Organization_Address object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Organization_Address object</returns>
		private Organization_Address GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Organization_Address organization_AddressObject= new Organization_Address();
					FillObject( organization_AddressObject, reader );
					return organization_AddressObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Organization_Address objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Organization_Address objects</returns>
		private Organization_AddressList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Organization_AddressList list = new Organization_AddressList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Organization_Address organization_AddressObject = new Organization_Address();
					FillObject( organization_AddressObject, reader );

					list.Add( organization_AddressObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

