using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class OrganizationData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Organization;

		private const string INSERTORGANIZATION = "InsertOrganization";
		private const string UPDATEORGANIZATION = "UpdateOrganization";
		private const string DELETEORGANIZATION = "DeleteOrganization";
		private const string GETORGANIZATIONBYID = "GetOrganizationByID";
		private const string GETALLORGANIZATION = "GetAllOrganization";
        private const string GETDELETEDORGANIZATIONBYID = "GetDeletedOrganizationByID";
        private const string GETALLDELETEDORGANIZATION = "GetAllDeletedOrganization";
        private const string GETORGANIZATIONSFORUSERID = "GetOrganizationsForUser";
        private const string GETALLORGANIZATIONSFORUSERID = "GetAllOrgnizationForUser";
        private const string GETORGANIZATIONFORPAGING = "GetOrganizationForPaging";
        private const string GETORGANIZATIONSFORUSERID_PAGING = "GetOrganizationsForUser_Paging";

        #region Constructors

		public OrganizationData(UserContext context) : base(context) { LOCK_Organization = this; }
		public OrganizationData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Organization = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organizationObject"></param>
		private void AddCommonParams( SqlCommand cmd, OrganizationBase organizationObject )
		{
            //if (organizationObject.OrganizationTypeID == 0)
            //{
            //    AddParameter(cmd, pInt64(OrganizationBase.Property_OrganizationTypeID, null));
            //}
            //else
            //{
            //    AddParameter(cmd, pInt64(OrganizationBase.Property_OrganizationTypeID, organizationObject.OrganizationTypeID));
            //}
			AddParameter(cmd, pNVarChar(OrganizationBase.Property_Name, 255, organizationObject.Name));
			AddParameter(cmd, pNText(OrganizationBase.Property_Description, organizationObject.Description));
		}

        /// <summary>
        /// Inserts Organization
        /// </summary>
        /// <param name="organizationObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( OrganizationBase organizationObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTORGANIZATION );
	
				AddParameter(cmd, pInt64Out(OrganizationBase.Property_ID, organizationObject.ID));
				AddCommonParams( cmd, organizationObject );
				AddBaseParametersForInsert( cmd, organizationObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					organizationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, OrganizationBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( organizationObject, x );
			}
		}
		
        /// <summary>
        /// Updates Organization 
        /// </summary>
        /// <param name="organizationObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( OrganizationBase organizationObject)
		{
            lock (LOCK_Organization)
            {
				try
				{
                    OrganizationBase dbObject = Get(organizationObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(organizationObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != organizationObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != organizationObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(organizationObject, null);

                    dbObject.CloneBase(organizationObject);

					SqlCommand cmd = GetSPCommand( UPDATEORGANIZATION );

				    AddParameter(cmd, pInt64(OrganizationBase.Property_ID, organizationObject.ID));
					AddCommonParams( cmd, organizationObject );
					AddBaseParametersForUpdate( cmd, organizationObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						organizationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( organizationObject, x );
				}
			}
		}

        /// <summary>
        /// Updates Organization For DataBridge Import
        /// </summary>
        /// <param name="organizationObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public string UpdateForImport(OrganizationBase organizationObject)
        {
            lock (LOCK_Organization)
            {
                try
                {
                    OrganizationBase dbObject = Get(organizationObject.ID);
                    if (dbObject == null)
                        return "Update failed! Not found record in database";

                    SqlCommand cmd = GetSPCommand(UPDATEORGANIZATION);

                    AddParameter(cmd, pInt64(OrganizationBase.Property_ID, organizationObject.ID));
                    AddCommonParams(cmd, organizationObject);
                    AddBaseParametersForUpdate(cmd, organizationObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        organizationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    else
                        return "No record is updated";

                }
                catch (SqlException x)
                {
                    return x.Message;
                }                
            }
            return string.Empty;
        }

        /// <summary>
        /// Deletes Organization
        /// </summary>
        /// <param name="ID">ID of the Organization object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEORGANIZATION );
	
				AddParameters( cmd, pInt64( Organization.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Organization ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Organization object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Organization object to retrieve</param>
        /// <returns>A Organization object, null if not found</returns>
		public Organization Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETORGANIZATIONBYID) )
			{
				AddParameters( cmd, pInt64( Organization.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves Deleted Organization object using it's ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Organization GetDeleted(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDORGANIZATIONBYID))
            {
                AddParameters(cmd, pInt64(Organization.Property_ID, ID));

                return GetObject(cmd);
            }
        }
        //added by tsrdev2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public OrganizationList GetOrganizationsForUser(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETORGANIZATIONSFORUSERID))
            {
                AddParameters(cmd, pInt64("UserID", userID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Retrieves all Organization objects 
        /// </summary>
        /// <returns>A list of Organization objects</returns>
		public OrganizationList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLORGANIZATION ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}
        /// <summary>
        /// Retrieves all Deleted Organization objects 
        /// </summary>
        /// <returns>A list of Deleted Organization objects</returns>
        public OrganizationList GetAllDeleted()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLDELETEDORGANIZATION))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Organization object
        /// </summary>
        /// <param name="organizationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( OrganizationBase organizationObject, SqlDataReader reader, int start )
		{
			organizationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			organizationObject.ID = reader.GetInt64(start + 0);
			organizationObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) organizationObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            FillBaseObject(organizationObject, reader, (start + 3));
            
            //if (organizationObject.CustomProperties != null
            //        && organizationObject.CustomProperties["OrganizationTypeID"] != null 
            //        && organizationObject.CustomProperties["OrganizationTypeID"] != System.DBNull.Value)
            //{
            //    organizationObject.OrganizationTypeID = Int64.Parse(organizationObject.CustomProperties["OrganizationTypeID"].ToString());
            //} 
			
		}

		protected void FillObject( OrganizationBase organizationObject, SqlDataReader reader )
		{
			FillObject( organizationObject, reader, 0 );
		}

        protected void FillObject_View(OrganizationBase organizationObject, SqlDataReader reader)
        {
            organizationObject.ID = reader.GetInt64(0);
            organizationObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

        /// <summary>
        /// Retrieves Organization object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Organization object</returns>
		private Organization GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Organization organizationObject= new Organization();
					FillObject( organizationObject, reader );
					return organizationObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Organization objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Organization objects</returns>
		private OrganizationList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			OrganizationList list = new OrganizationList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Organization organizationObject = new Organization();
					FillObject( organizationObject, reader );

					list.Add( organizationObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private OrganizationList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            OrganizationList list = new OrganizationList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Organization organizationObject = new Organization();
                    FillObject_View(organizationObject, reader);

                    list.Add(organizationObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }
        //added by tsrdev2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public OrganizationList GetAllOrganizationForUser(long userId)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLORGANIZATIONSFORUSERID))
            {
                AddParameters(cmd, pInt64("UserID", userId));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        public OrganizationList GetOrganizationPaging(int startOffset, int numberOfItems, string name, out int total)
        {
            OrganizationList lst = new OrganizationList();
            using (SqlCommand cmd = GetSPCommand(GETORGANIZATIONFORPAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);
                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }

        public OrganizationList GetOrganizationsForUserPaging(long userID, int startOffset, int numberOfItems, string name, out int total)
        {
            OrganizationList lst = new OrganizationList();
            using (SqlCommand cmd = GetSPCommand(GETORGANIZATIONSFORUSERID_PAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                AddParameters(cmd, pInt64("UserID", userID));
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);
                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }


        public OrganizationList GetAllOrganizationsForExport()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLORGANIZATIONFOREXPORT))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}

