using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class PersonData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_Person;

        private const string INSERTPERSON = "InsertPerson";
        private const string UPDATEPERSON = "UpdatePerson";
        private const string DELETEPERSON = "DeletePerson";
        private const string GETPERSONBYID = "GetPersonByID";
        private const string GETDELETEDPERSONBYID = "GetDeletedPersonByID";
        private const string GETALLPERSON = "GetAllPerson";
        private const string UNDELETEDPERSON = "UnDeletedPersonByID";

        #region Constructors

        public PersonData(UserContext context) : base(context) { LOCK_Person = this; }
        public PersonData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Person = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="personObject"></param>
        private void AddCommonParams(SqlCommand cmd, PersonBase personObject)
        {
            AddParameter(cmd, pInt32(PersonBase.Property_PersonType, (int)personObject.PersonType));
            AddParameter(cmd, pNVarChar(PersonBase.Property_FirstName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.FirstName));
            AddParameter(cmd, pNVarChar(PersonBase.Property_LastName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.LastName));
            AddParameter(cmd, pNVarChar(PersonBase.Property_MiddleName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.MiddleName));
            AddParameter(cmd, pInt32(PersonBase.Property_Sex, personObject.Sex));
            AddParameter(cmd, pDateTime(PersonBase.Property_DateOfBirth, personObject.DateOfBirth));
            AddParameter(cmd, pNVarChar(PersonBase.Property_PassportNo, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.PassportNo));
            AddParameter(cmd, pNVarChar(PersonBase.Property_NationalIDNo, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.NationalIDNo));
            AddParameter(cmd, pNVarChar(PersonBase.Property_DriverLicenseNo, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.DriverLicenseNo));
            AddParameter(cmd, pNVarChar(PersonBase.Property_SocialSecurityNo, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.SocialSecurityNo));
            AddParameter(cmd, pNVarChar(PersonBase.Property_Email, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.Email));
            AddParameter(cmd, pNVarChar(PersonBase.Property_DirectPhone, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.DirectPhone));
            AddParameter(cmd, pNVarChar(PersonBase.Property_CellPhone, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.CellPhone));
            AddParameter(cmd, pNVarChar(PersonBase.Property_JobTitle, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.JobTitle));
            AddParameter(cmd, pNVarChar(PersonBase.Property_Department, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, personObject.Department));
            AddParameter(cmd, pInt64(PersonBase.Property_LocationID, personObject.LocationID));
        }

        /// <summary>
        /// Inserts Person
        /// </summary>
        /// <param name="personObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(PersonBase personObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTPERSON);

                AddParameter(cmd, pInt64Out(PersonBase.Property_ID, personObject.ID));
                AddCommonParams(cmd, personObject);
                AddBaseParametersForInsert(cmd, personObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    personObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, PersonBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(personObject, x);
            }
        }

        /// <summary>
        /// UnDeleted Person
        /// added by tsrdev2
        /// </summary>
        /// <param name="personObject">Object to be undeleted</param>
        /// <returns>Number of rows affected</returns>
        public long UnDeleted(PersonBase personObject)
        {
            long result = 0;
            lock (LOCK_Person)
            {
                try
                {
                    SqlCommand cmd = GetSPCommand(UNDELETEDPERSON);

                    AddParameter(cmd, pInt64(PersonBase.Property_ID, personObject.ID));

                    result = UpdateRecord(cmd);
                    if (result > 0)
                        personObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(personObject, x);
                }

                //update data from AD user
                if (result > 0)
                {
                    try
                    {
                        SqlCommand cmd = GetSPCommand(UPDATEPERSON);

                        AddParameter(cmd, pInt64(PersonBase.Property_ID, personObject.ID));
                        AddCommonParams(cmd, personObject);
                        AddBaseParametersForUpdate(cmd, personObject);

                        result = UpdateRecord(cmd);
                        if (result > 0)
                            personObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    }
                    catch (SqlException x)
                    {
                        throw new Framework.Exceptions.ObjectUpdateException(personObject, x);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Updates Person 
        /// </summary>
        /// <param name="personObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(PersonBase personObject)
        {
            lock (LOCK_Person)
            {
                try
                {
                    PersonBase dbObject = Get(personObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(personObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != personObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != personObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(personObject, null);

                    SqlCommand cmd = GetSPCommand(UPDATEPERSON);

                    AddParameter(cmd, pInt64(PersonBase.Property_ID, personObject.ID));
                    AddCommonParams(cmd, personObject);
                    AddBaseParametersForUpdate(cmd, personObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        personObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(personObject, x);
                }
            }
        }

        /// <summary>
        /// Deletes Person
        /// </summary>
        /// <param name="ID">ID of the Person object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEPERSON);

                AddParameters(cmd, pInt64(Person.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Person), ID, x);
            }

        }

        /// <summary>
        /// Retrieves Person object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Person object to retrieve</param>
        /// <returns>A Person object, null if not found</returns>
        public Person Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETPERSONBYID))
            {
                AddParameters(cmd, pInt64(Person.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves Deleted Person object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Person object to retrieve</param>
        /// <returns>A Person object, null if not found</returns>
        public Person GetDeleted(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDPERSONBYID))
            {
                AddParameters(cmd, pInt64(Person.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Person objects 
        /// </summary>
        /// <returns>A list of Person objects</returns>
        public PersonList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLPERSON))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Person object
        /// </summary>
        /// <param name="personObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(PersonBase personObject, SqlDataReader reader, int start)
        {
            personObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            personObject.ID = reader.GetInt64(start + 0);
            personObject.PersonType = (PersonTypeEnum)reader.GetInt32(start + 1);
            personObject.FirstName = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) personObject.LastName = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) personObject.MiddleName = ReverseToHTMLCode(reader.GetString(start + 4));
            personObject.Sex = reader.GetInt32(start + 5);
            if (!reader.IsDBNull(start + 6)) personObject.DateOfBirth = reader.GetDateTime(start + 6);
            if (!reader.IsDBNull(start + 7)) personObject.PassportNo = ReverseToHTMLCode(reader.GetString(start + 7));
            if (!reader.IsDBNull(start + 8)) personObject.NationalIDNo = ReverseToHTMLCode(reader.GetString(start + 8));
            if (!reader.IsDBNull(start + 9)) personObject.DriverLicenseNo = ReverseToHTMLCode(reader.GetString(start + 9));
            if (!reader.IsDBNull(start + 10)) personObject.SocialSecurityNo = ReverseToHTMLCode(reader.GetString(start + 10));
            //
            if (!reader.IsDBNull(start + 16)) personObject.Email = ReverseToHTMLCode(reader.GetString(start + 16));
            if (!reader.IsDBNull(start + 17)) personObject.DirectPhone = ReverseToHTMLCode(reader.GetString(start + 17));
            if (!reader.IsDBNull(start + 18)) personObject.CellPhone = ReverseToHTMLCode(reader.GetString(start + 18));
            if (!reader.IsDBNull(start + 19)) personObject.JobTitle = ReverseToHTMLCode(reader.GetString(start + 19));
            if (!reader.IsDBNull(start + 20)) personObject.Department = ReverseToHTMLCode(reader.GetString(start + 20));
            //if (!reader.IsDBNull(start + 21)) personObject.Location = ReverseToHTMLCode(reader.GetInt32(start + 21));
            if (!reader.IsDBNull(start + 21)) personObject.LocationID = reader.GetInt64(start + 21);

            FillBaseObject(personObject, reader, (start + 11), (start + 16));
        }

        protected void FillObject(PersonBase personObject, SqlDataReader reader)
        {
            FillObject(personObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Person object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Person object</returns>
        private Person GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    Person personObject = new Person();
                    FillObject(personObject, reader);
                    return personObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Person objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Person objects</returns>
        private PersonList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            PersonList list = new PersonList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Person personObject = new Person();
                    FillObject(personObject, reader);

                    list.Add(personObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}

