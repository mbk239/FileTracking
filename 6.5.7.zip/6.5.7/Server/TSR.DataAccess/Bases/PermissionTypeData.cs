using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PermissionTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_PermissionType;

		private const string INSERTPERMISSIONTYPE = "InsertPermissionType";
		private const string UPDATEPERMISSIONTYPE = "UpdatePermissionType";
		private const string DELETEPERMISSIONTYPE = "DeletePermissionType";
		private const string GETPERMISSIONTYPEBYID = "GetPermissionTypeByID";
		private const string GETALLPERMISSIONTYPE = "GetAllPermissionType";

        #region Constructors

		public PermissionTypeData(UserContext context) : base(context) { LOCK_PermissionType = this; }
		public PermissionTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_PermissionType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="permissionTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, PermissionTypeBase permissionTypeObject )
		{
            AddParameter(cmd, pNVarChar(PermissionTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionTypeObject.Name));
			AddParameter(cmd, pNText(PermissionTypeBase.Property_Description, permissionTypeObject.Description));
		}

        /// <summary>
        /// Inserts PermissionType
        /// </summary>
        /// <param name="permissionTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( PermissionTypeBase permissionTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPERMISSIONTYPE );
	
				AddParameter(cmd, pInt64Out(PermissionTypeBase.Property_ID, permissionTypeObject.ID));
				AddCommonParams( cmd, permissionTypeObject );
				AddBaseParametersForInsert( cmd, permissionTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					permissionTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, PermissionTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( permissionTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates PermissionType 
        /// </summary>
        /// <param name="permissionTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( PermissionTypeBase permissionTypeObject)
		{
            lock (LOCK_PermissionType)
            {
				try
				{
                    PermissionTypeBase dbObject = Get(permissionTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(permissionTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != permissionTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != permissionTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(permissionTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPERMISSIONTYPE );

				    AddParameter(cmd, pInt64(PermissionTypeBase.Property_ID, permissionTypeObject.ID));
					AddCommonParams( cmd, permissionTypeObject );
					AddBaseParametersForUpdate( cmd, permissionTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						permissionTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( permissionTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes PermissionType
        /// </summary>
        /// <param name="ID">ID of the PermissionType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPERMISSIONTYPE );
	
				AddParameters( cmd, pInt64( PermissionType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( PermissionType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves PermissionType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the PermissionType object to retrieve</param>
        /// <returns>A PermissionType object, null if not found</returns>
		public PermissionType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPERMISSIONTYPEBYID) )
			{
				AddParameters( cmd, pInt64( PermissionType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all PermissionType objects 
        /// </summary>
        /// <returns>A list of PermissionType objects</returns>
		public PermissionTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPERMISSIONTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills PermissionType object
        /// </summary>
        /// <param name="permissionTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( PermissionTypeBase permissionTypeObject, SqlDataReader reader, int start )
		{
			permissionTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			permissionTypeObject.ID = reader.GetInt64(start + 0);
			permissionTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) permissionTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			FillBaseObject(permissionTypeObject, reader, (start + 3));
		}

		protected void FillObject( PermissionTypeBase permissionTypeObject, SqlDataReader reader )
		{
			FillObject( permissionTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves PermissionType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>PermissionType object</returns>
		private PermissionType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					PermissionType permissionTypeObject= new PermissionType();
					FillObject( permissionTypeObject, reader );
					return permissionTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of PermissionType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of PermissionType objects</returns>
		private PermissionTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			PermissionTypeList list = new PermissionTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					PermissionType permissionTypeObject = new PermissionType();
					FillObject( permissionTypeObject, reader );

					list.Add( permissionTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

