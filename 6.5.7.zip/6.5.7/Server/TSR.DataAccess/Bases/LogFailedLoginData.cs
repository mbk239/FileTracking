﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// added by tsrdev2
    /// </summary>
	public partial class LogFailedLoginData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_LogFailedLogin;

        //private const string INSERTLOGFAILEDLOGIN = "InsertLogFailedLogin";		
		private const string GETLOGFAILEDLOGINBYID = "GetLogFailedLoginByID";
		private const string GETALLLOGFAILEDLOGIN = "GetAllLogFailedLogin";
        private const string GETLOGFAILEDLOGINBYUSERID = "GetLogFailedLoginByUserID";
        private const string GETLOGFAILEDLOGINBYSEARCHCRITERIA = "GetLogFailedLoginBySearchCriteria";
        private const string GETLOGLOGINBYTIMESPAN = "GetLogLoginByTimeSpan";

        #region Constructors

        public LogFailedLoginData(UserContext context) : base(context) { LOCK_LogFailedLogin = this; }
        public LogFailedLoginData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_LogFailedLogin = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organizationObject"></param>
        //private void AddCommonParams( SqlCommand cmd, LogFailedLoginBase logFailedLoginObject )
        //{
        //    AddParameter(cmd, pNVarChar(OrganizationBase.Property_Name, 255, organizationObject.Name));
        //    AddParameter(cmd, pNText(OrganizationBase.Property_Description, organizationObject.Description));
        //}    

        /// <summary>
        /// Retrieves LogFailedLogin object using it's ID
        /// </summary>
        /// <param name="ID">The id of the LogFailedLogin object to retrieve</param>
        /// <returns>A LogFailedLogin object, null if not found</returns>
		public LogFailedLogin Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETLOGFAILEDLOGINBYID) )
			{
                AddParameters(cmd, pInt64(LogFailedLogin.Property_ID, ID));

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all LogFailedLogin objects 
        /// </summary>
        /// <returns>A list of LogFailedLogin objects</returns>
		public LogFailedLoginList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLLOGFAILEDLOGIN) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}       

        /// <summary>
        /// Fills logFailedLoginObject
        /// </summary>
        /// <param name="organizationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( LogFailedLoginBase logFailedLoginObject, SqlDataReader reader, int start )
		{
            logFailedLoginObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            logFailedLoginObject.ID = reader.GetInt64(start + 0);
            if(!reader.IsDBNull(start + 1)) 
                logFailedLoginObject.UserID = reader.GetInt64(start + 1);
            if (!reader.IsDBNull(start + 2))
                logFailedLoginObject.UserName = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3))
                logFailedLoginObject.LoggingTime = reader.GetDateTime(start + 3);
            if (!reader.IsDBNull(start + 4))
                logFailedLoginObject.Source = (SourceType)reader.GetInt32(start + 4);
            if (!reader.IsDBNull(start + 5))
                logFailedLoginObject.TypeOfEvent = (TypeOfEventEnum)reader.GetInt32(start + 5);
            if (!reader.IsDBNull(start + 6))
                logFailedLoginObject.ClientIP = ReverseToHTMLCode(reader.GetString(start + 6));
            if (!reader.IsDBNull(start + 7))
                logFailedLoginObject.CustomerNo = ReverseToHTMLCode(reader.GetString(start + 7));
			FillBaseObject(logFailedLoginObject, reader, (start + 8));
		}

		protected void FillObject( LogFailedLoginBase logObject, SqlDataReader reader )
		{
            FillObject(logObject, reader, 0);
		}

        /// <summary>
        /// Retrieves LogFailedLogin object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>LogFailedLogin object</returns>
		private LogFailedLogin GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
                    LogFailedLogin logObject = new LogFailedLogin();
                    FillObject(logObject, reader);
                    return logObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of LogFailedLogin objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of LogFailedLogin objects</returns>
        private LogFailedLoginList GetList(SqlCommand cmd, long rows)
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
            LogFailedLoginList list = new LogFailedLoginList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
                    LogFailedLogin logObject = new LogFailedLogin();
                    FillObject(logObject, reader);

                    list.Add(logObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        //added by tsrdev2
        /// <summary>
        /// Gets log failed login (not contain "Success" log)
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="source"></param>
        /// <param name="typeOfEvent"></param>
        /// <returns></returns>
        public LogFailedLoginList GetLogFailedLoginBySearchCriteria(long userID, DateTime startTimeStamp, DateTime endTimeStamp, int source, int typeOfEvent)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOGFAILEDLOGINBYSEARCHCRITERIA))
            {
                AddParameter(cmd, pInt64(LogFailedLoginBase.Property_UserID, userID));
                AddParameter(cmd, pDateTime("StartTimeStamp", startTimeStamp));
                AddParameter(cmd, pDateTime("EndTimeStamp", endTimeStamp));
                AddParameter(cmd, pInt32(LogFailedLoginBase.Property_Source, source));
                AddParameter(cmd, pInt32(LogFailedLoginBase.Property_TypeOfEvent, typeOfEvent));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        //added by tsrdev2
        /// <summary>
        /// Gets log failed login (include "Success" log)
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="source"></param>
        /// <param name="typeOfEvent"></param>
        /// <returns></returns>
        public LogFailedLoginList GetLogLoginByTimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp, int source, int typeOfEvent)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOGLOGINBYTIMESPAN))
            {
                AddParameter(cmd, pInt64(LogFailedLoginBase.Property_UserID, userID));
                AddParameter(cmd, pDateTime("StartTimeStamp", startTimeStamp));
                AddParameter(cmd, pDateTime("EndTimeStamp", endTimeStamp));
                AddParameter(cmd, pInt32(LogFailedLoginBase.Property_Source, source));
                AddParameter(cmd, pInt32(LogFailedLoginBase.Property_TypeOfEvent, typeOfEvent));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
	}
}

