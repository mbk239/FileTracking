using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Project_UserGroup_ActivitiesData : BaseDataAccess
	{
        private const string INSERTPROJECT_USERGROUP_ACTIVITIES = "InsertProject_UserGroup_Activities";
        private const string GETPROJECT_USERGROUP_ACTIVITIES = "GetProject_UserGroup_Activities";
        private const string GETPROJECT_USERGROUP_ACTIVITIES_BYUSERID = "GetProject_UserGroup_Activities_ByUserID";

        private const string DELETEPROJECT_USERGROUP_ACTIVITIES = "DeleteProject_UserGroup_Activities";

		private const string UPDATEPROJECT_USERGROUP_ACTIVITIES = "UpdateProject_UserGroup_Activities";
		
        //private const string DELETEPROJECT_USERGROUP_ACTIVITIES = "DeleteProject_UserGroup_Activities";
        //private const string GETPROJECT_USERGROUP_ACTIVITIESBYID = "GetProject_UserGroup_ActivitiesByID";
        //private const string GETALLPROJECT_USERGROUP_ACTIVITIES = "GetAllProject_UserGroup_Activities";

        #region Constructors

		public Project_UserGroup_ActivitiesData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="project_UserGroupObject"></param>
		private void AddCommonParams( SqlCommand cmd, Project_UserGroup_ActivitiesBase project_UserGroupObject )
		{
			AddParameter(cmd, pInt64(Project_UserGroup_ActivitiesBase.Property_ProjectID, project_UserGroupObject.ProjectID));
			AddParameter(cmd, pInt64(Project_UserGroup_ActivitiesBase.Property_UserGroupID, project_UserGroupObject.UserGroupID));
            AddParameter(cmd, pInt64(Project_UserGroup_ActivitiesBase.Property_ActivityID, project_UserGroupObject.ActivityID));
		}

        /// <summary>
        /// Inserts Project_UserGroup_Activities
        /// </summary>
        /// <param name="project_UserGroupObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Project_UserGroup_ActivitiesBase project_UserGroupObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPROJECT_USERGROUP_ACTIVITIES );
	
				AddParameter(cmd, pInt64Out(Project_UserGroup_ActivitiesBase.Property_ID, project_UserGroupObject.ID));
				AddCommonParams( cmd, project_UserGroupObject );
				AddBaseParametersForInsert( cmd, project_UserGroupObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Project_UserGroup_ActivitiesBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( project_UserGroupObject, x );
			}
		}
		
        /// <summary>
        /// Updates Project_UserGroup_Activities 
        /// </summary>
        /// <param name="project_UserGroupObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Project_UserGroup_ActivitiesBase project_UserGroupObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEPROJECT_USERGROUP_ACTIVITIES );

				AddParameter(cmd, pInt64(Project_UserGroup_ActivitiesBase.Property_ID, project_UserGroupObject.ID));
				AddCommonParams( cmd, project_UserGroupObject );
				AddBaseParametersForUpdate( cmd, project_UserGroupObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( project_UserGroupObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Project_UserGroup_Activities
        /// </summary>
        /// <param name="ID">ID of the Project_UserGroup_Activities object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECT_USERGROUP_ACTIVITIES );
	
				AddParameters( cmd, pInt64( Project_UserGroup_Activities.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Project_UserGroup_Activities ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Project_UserGroup_Activities object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Project_UserGroup_Activities object to retrieve</param>
        /// <returns>A Project_UserGroup_Activities object, null if not found</returns>
        //public Project_UserGroup_Activities Get( long ID )
        //{
        //    using( SqlCommand cmd = GetSPCommand( GETPROJECT_USERGROUP_ACTIVITIES) )
        //    {
        //        AddParameters( cmd, pInt64( Project_UserGroup_Activities.Property_ID, ID ) );

        //        return GetObject(cmd);
        //    }
        //}

        /// <summary>
        /// Retrieves all Project_UserGroup_Activities objects 
        /// </summary>
        /// <returns>A list of Project_UserGroup_Activities objects</returns>
		public Project_UserGroup_ActivitiesList GetAll()
		{
            using (SqlCommand cmd = GetSPCommand(GETPROJECT_USERGROUP_ACTIVITIES))
			{
                AddParameters(cmd, pInt64(Project_UserGroup_Activities.Property_ProjectID, -1));
                AddParameters(cmd, pInt64(Project_UserGroup_Activities.Property_UserGroupID, -1));
                AddParameters(cmd, pInt64(Project_UserGroup_Activities.Property_ActivityID, -1));
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Project_UserGroup_Activities object
        /// </summary>
        /// <param name="project_UserGroupObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Project_UserGroup_ActivitiesBase project_UserGroupObject, SqlDataReader reader, int start )
		{
			project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			project_UserGroupObject.ID = reader.GetInt64(start + 0);
			project_UserGroupObject.ProjectID = reader.GetInt64(start + 1);
			project_UserGroupObject.UserGroupID = reader.GetInt64(start + 2);
            project_UserGroupObject.ActivityID = reader.GetInt64(start + 3);
			FillBaseObject(project_UserGroupObject, reader, (start + 4));
		}

		protected void FillObject( Project_UserGroup_ActivitiesBase project_UserGroupObject, SqlDataReader reader )
		{
			FillObject( project_UserGroupObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Project_UserGroup_Activities object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Project_UserGroup_Activities object</returns>
		private Project_UserGroup_Activities GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Project_UserGroup_Activities project_UserGroupObject= new Project_UserGroup_Activities();
					FillObject( project_UserGroupObject, reader );
					return project_UserGroupObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Project_UserGroup_Activities objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Project_UserGroup_Activities objects</returns>
		private Project_UserGroup_ActivitiesList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Project_UserGroup_ActivitiesList list = new Project_UserGroup_ActivitiesList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Project_UserGroup_Activities project_UserGroupObject = new Project_UserGroup_Activities();
					FillObject( project_UserGroupObject, reader );

					list.Add( project_UserGroupObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}        
    }
}

