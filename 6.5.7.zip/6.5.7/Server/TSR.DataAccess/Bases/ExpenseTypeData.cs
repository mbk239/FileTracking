using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using System.Linq;

namespace TSR.DataAccess
{
	public partial class ExpenseTypeData : BaseDataAccess
	{
		private const string INSERTEXPENSETYPE = "InsertExpenseType";
		private const string UPDATEEXPENSETYPE = "UpdateExpenseType";
		private const string DELETEEXPENSETYPE = "DeleteExpenseType";
		private const string GETEXPENSETYPEBYID = "GetExpenseTypeByID";
        private const string GETALLEXPENSETYPE = "GetAllExpenseType";

        #region Constructors

		public ExpenseTypeData(UserContext context) : base(context) { }
		public ExpenseTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="expenseTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, ExpenseTypeBase expenseTypeObject )
		{
            AddParameter(cmd, pNVarChar(ExpenseTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_LENGTH_200, expenseTypeObject.Name));
            if(expenseTypeObject.DefaultValue.HasValue)
                AddParameter(cmd, pDecimal(ExpenseTypeBase.Property_DefaultValue, expenseTypeObject.DefaultValue.Value));
			AddParameter(cmd, pBool(ExpenseTypeBase.Property_IsLockedValue, expenseTypeObject.IsLockedValue));
            AddParameter(cmd, pBool(ExpenseTypeBase.Property_IsActive, expenseTypeObject.IsActive));
            AddParameter(cmd, pNVarChar(ExpenseTypeBase.Property_ForeignKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, expenseTypeObject.ForeignKey));
		}

        /// <summary>
        /// Inserts ExpenseType
        /// </summary>
        /// <param name="expenseTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ExpenseTypeBase expenseTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTEXPENSETYPE );
	
				AddParameter(cmd, pInt64Out(ExpenseTypeBase.Property_ID, expenseTypeObject.ID));
				AddCommonParams( cmd, expenseTypeObject );
				AddBaseParametersForInsert( cmd, expenseTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					expenseTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ExpenseTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( expenseTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates ExpenseType 
        /// </summary>
        /// <param name="expenseTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ExpenseTypeBase expenseTypeObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEEXPENSETYPE );

				AddParameter(cmd, pInt64(ExpenseTypeBase.Property_ID, expenseTypeObject.ID));
				AddCommonParams( cmd, expenseTypeObject );
				AddBaseParametersForUpdate( cmd, expenseTypeObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					expenseTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( expenseTypeObject, x );
			}
			
		}

        /// <summary>
        /// Deletes ExpenseType
        /// </summary>
        /// <param name="ID">ID of the ExpenseType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEEXPENSETYPE );
	
				AddParameters( cmd, pInt64( ExpenseType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ExpenseType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves ExpenseType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ExpenseType object to retrieve</param>
        /// <returns>A ExpenseType object, null if not found</returns>
		public ExpenseType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETEXPENSETYPEBYID) )
			{
				AddParameters( cmd, pInt64( ExpenseType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all ExpenseType objects 
        /// </summary>
        /// <returns>A list of ExpenseType objects</returns>
		public ExpenseTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLEXPENSETYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ExpenseType object
        /// </summary>
        /// <param name="ExpenseTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ExpenseTypeBase expenseTypeObject, SqlDataReader reader, int start )
		{
			expenseTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			expenseTypeObject.ID = reader.GetInt64(start + 0);
            expenseTypeObject.Name = reader.GetString(start + 1);
            expenseTypeObject.DefaultValue = Convert.ToDecimal(string.Format("{0:0.##}", reader.GetDecimal(start + 2)));
            expenseTypeObject.IsLockedValue = reader.GetBoolean(start + 3);
            expenseTypeObject.IsActive = reader.GetBoolean(start + 4);
            if (!reader.IsDBNull(start + 5))
                expenseTypeObject.ForeignKey = reader.GetString(start + 5);
            
			FillBaseObject(expenseTypeObject, reader, (start + 6));
		}

		protected void FillObject( ExpenseTypeBase expenseTypeObject, SqlDataReader reader )
		{
			FillObject( expenseTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ExpenseType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ExpenseType object</returns>
		private ExpenseType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ExpenseType expenseTypeObject= new ExpenseType();
					FillObject( expenseTypeObject, reader );
					return expenseTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ExpenseType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ExpenseType objects</returns>
        private ExpenseTypeList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ExpenseTypeList list = new ExpenseTypeList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ExpenseType expenseTypeObject = new ExpenseType();
                    FillObject(expenseTypeObject, reader);

                    list.Add(expenseTypeObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

	}
}

