using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PermissionHierarchyData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_PermissionHierarchy;

		private const string INSERTPERMISSIONHIERARCHY = "InsertPermissionHierarchy";
		private const string UPDATEPERMISSIONHIERARCHY = "UpdatePermissionHierarchy";
		private const string DELETEPERMISSIONHIERARCHY = "DeletePermissionHierarchy";
		private const string GETPERMISSIONHIERARCHYBYID = "GetPermissionHierarchyByID";
		private const string GETALLPERMISSIONHIERARCHY = "GetAllPermissionHierarchy";

        #region Constructors

		public PermissionHierarchyData(UserContext context) : base(context) { LOCK_PermissionHierarchy = this; }
		public PermissionHierarchyData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_PermissionHierarchy = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="permissionHierarchyObject"></param>
		private void AddCommonParams( SqlCommand cmd, PermissionHierarchyBase permissionHierarchyObject )
		{
            AddParameter(cmd, pNVarChar(PermissionHierarchyBase.Property_ParentPermissionKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionHierarchyObject.ParentPermissionKey));
            AddParameter(cmd, pNVarChar(PermissionHierarchyBase.Property_ChildPermissionKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionHierarchyObject.ChildPermissionKey));
		}

        /// <summary>
        /// Inserts PermissionHierarchy
        /// </summary>
        /// <param name="permissionHierarchyObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( PermissionHierarchyBase permissionHierarchyObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPERMISSIONHIERARCHY );
	
				AddParameter(cmd, pInt64Out(PermissionHierarchyBase.Property_ID, permissionHierarchyObject.ID));
				AddCommonParams( cmd, permissionHierarchyObject );
				AddBaseParametersForInsert( cmd, permissionHierarchyObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					permissionHierarchyObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, PermissionHierarchyBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( permissionHierarchyObject, x );
			}
		}
		
        /// <summary>
        /// Updates PermissionHierarchy 
        /// </summary>
        /// <param name="permissionHierarchyObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( PermissionHierarchyBase permissionHierarchyObject)
		{
            lock (LOCK_PermissionHierarchy)
            {
				try
				{
                    PermissionHierarchyBase dbObject = Get(permissionHierarchyObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(permissionHierarchyObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != permissionHierarchyObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != permissionHierarchyObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(permissionHierarchyObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPERMISSIONHIERARCHY );

				AddParameter(cmd, pInt64(PermissionHierarchyBase.Property_ID, permissionHierarchyObject.ID));
					AddCommonParams( cmd, permissionHierarchyObject );
					AddBaseParametersForUpdate( cmd, permissionHierarchyObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						permissionHierarchyObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( permissionHierarchyObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes PermissionHierarchy
        /// </summary>
        /// <param name="ID">ID of the PermissionHierarchy object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPERMISSIONHIERARCHY );
	
				AddParameters( cmd, pInt64( PermissionHierarchy.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( PermissionHierarchy ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves PermissionHierarchy object using it's ID
        /// </summary>
        /// <param name="ID">The id of the PermissionHierarchy object to retrieve</param>
        /// <returns>A PermissionHierarchy object, null if not found</returns>
		public PermissionHierarchy Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPERMISSIONHIERARCHYBYID) )
			{
				AddParameters( cmd, pInt64( PermissionHierarchy.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all PermissionHierarchy objects 
        /// </summary>
        /// <returns>A list of PermissionHierarchy objects</returns>
		public PermissionHierarchyList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPERMISSIONHIERARCHY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills PermissionHierarchy object
        /// </summary>
        /// <param name="permissionHierarchyObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( PermissionHierarchyBase permissionHierarchyObject, SqlDataReader reader, int start )
		{
			permissionHierarchyObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			permissionHierarchyObject.ID = reader.GetInt64(start + 0);
            if (!reader.IsDBNull(start + 1)) permissionHierarchyObject.ParentPermissionKey = ReverseToHTMLCode(reader.GetString(start + 1));
            permissionHierarchyObject.ChildPermissionKey = ReverseToHTMLCode(reader.GetString(start + 2));
			FillBaseObject(permissionHierarchyObject, reader, (start + 3));
		}

		protected void FillObject( PermissionHierarchyBase permissionHierarchyObject, SqlDataReader reader )
		{
			FillObject( permissionHierarchyObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves PermissionHierarchy object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>PermissionHierarchy object</returns>
		private PermissionHierarchy GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					PermissionHierarchy permissionHierarchyObject= new PermissionHierarchy();
					FillObject( permissionHierarchyObject, reader );
					return permissionHierarchyObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of PermissionHierarchy objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of PermissionHierarchy objects</returns>
		private PermissionHierarchyList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			PermissionHierarchyList list = new PermissionHierarchyList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					PermissionHierarchy permissionHierarchyObject = new PermissionHierarchy();
					FillObject( permissionHierarchyObject, reader );

					list.Add( permissionHierarchyObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

