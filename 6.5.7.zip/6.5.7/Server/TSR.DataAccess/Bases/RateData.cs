﻿using System;
using System.Data.SqlClient;
using System.Linq;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.DataAccess 
{
    public class RateData : BaseDataAccess
    {
        private const string GETAll = "GetAllRate";
        private const string GETRATEBYID = "GetRateByID";
        private const string INSERTRATE = "InsertRate";
        private const string UPDATERATE = "UpdateRate";
        private const string DELETERATE = "DeleteRate";
        private const string GETRATESREPORT_BYSEARCHCRITERIA = "GetRatesReport_BySearchCriteria_New";
        private static BaseDataAccess LOCK_RATE;

        public RateData(UserContext context) : base(context)
        {
            LOCK_RATE = this;
        }

        #region Fill Data
        public RateList GetAllRate()
        {
            SqlCommand cmd = GetSPCommand(GETAll);
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        private RateList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            var list = new RateList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    var rateObj = new Rate();
                    FillObject(rateObj, reader);
                    list.Add(rateObj);
                }

                reader.Close();
            }

            return list;
        }
        #region Rate Report
        public RateReportUserList GetRateReport_BySearchCriteria(DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID,
          int? timeStatus,  int? outOfOfficeId, int UseCurrentRates)
        {
            RateReportUserList report = new RateReportUserList();
            SqlDataReader reader;

            DateTime startTime = startTimeStamp.HasValue ? startTimeStamp.Value : DateTime.MinValue;
            DateTime endTime = endTimeStamp.HasValue ? (DateTime.MaxValue.Subtract(endTimeStamp.Value).TotalDays > 1 ? endTimeStamp.Value.AddDays(1) : DateTime.MaxValue) : DateTime.MaxValue;

            long orgID = (organizationID.HasValue && organizationID > 0 ? organizationID.Value : -1);
            long projID = (projectID.HasValue && projectID > 0 ? projectID.Value : -1);
            long actID = (activityID.HasValue && activityID > 0 ? activityID.Value : -1);
            long usrGrpID = (userGroupID.HasValue && userGroupID > 0 ? userGroupID.Value : -1);
            long usrID = (userID.HasValue && userID > 0 ? userID.Value : -1);
            long projTypeID = (projectTypeID.HasValue && projectTypeID > 0 ? projectTypeID.Value : -1);
            long actTypeID = (activityTypeID.HasValue && activityTypeID > 0 ? activityTypeID.Value : -1);
            int status = timeStatus.HasValue && timeStatus > 0 ? timeStatus.Value : -1;

            string spQuery = GETRATESREPORT_BYSEARCHCRITERIA;
            using (SqlCommand cmd = GetSPCommand(spQuery))
            {
                AddParameter(cmd, pInt64(TimeEntryReport.Property_UserID, usrID));
                AddParameter(cmd, pInt64("UserGroupID", usrGrpID));
                if (startTime != DateTime.MinValue)
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_StartTimeStamp, startTime));
                else
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_StartTimeStamp, null));
                if (endTime != DateTime.MaxValue)
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_EndTimeStamp, endTime));
                else
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_EndTimeStamp, null));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_OrganizationID, orgID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ProjectID, projID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ActivityID, actID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ProjectTypeID, projTypeID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ActivityTypeID, actTypeID));
                AddParameter(cmd, pInt32(TimeEntryReport.Property_Status, status));
                AddParameter(cmd, pInt32(TimeEntryReport.Property_IsOutOfOffice, outOfOfficeId));
                AddParameter(cmd, pInt32("UseCurrentRates", UseCurrentRates));
                long result = SelectRecords(cmd, out reader);
                report = FillRateReportUser(reader, startTime, endTime.AddDays(-1), usrID);
            }
            return report;
        }
        private RateReportUserList FillRateReportUser(SqlDataReader reader, DateTime startDate, DateTime endDate, long uId)
        {
            var listReportUser = new RateReportUserList();
            RateReportUser user;
            using (reader)
            {
                try
                {
                    listReportUser.Users = new System.Collections.Generic.List<RateReportUser>();
                    while (reader.Read())
                    {
                        var userId = reader.GetInt64(4);
                        if (listReportUser.Users.Find(x => x.ID == userId)==null)
                        {
                            user = new RateReportUser
                            {
                                ID = userId,
                                StartDate = startDate,
                                EndDate = endDate,
                                UserName = reader.GetString(8),
                                Specifications = new System.Collections.Generic.List<RateReport>()
                            };
                            listReportUser.Users.Add(user);
                        }
                        else user = listReportUser.Users.Find(x => x.ID == userId);

                        var rateReportObj = new RateReport();
                        rateReportObj.UserName = user.UserName;
                        rateReportObj.StartDate = reader.GetDateTime(5);
                        rateReportObj.EndDate = reader.GetDateTime(6);
                        rateReportObj.Project = ReverseToHTMLCode( reader.GetString(1));
                        rateReportObj.Activity = ReverseToHTMLCode( reader.GetString(7));
                        rateReportObj.StartTime = rateReportObj.StartDate.ToString("t");
                        rateReportObj.EndTime = rateReportObj.EndDate.ToString("t");
                        rateReportObj.Cost = !reader.IsDBNull(2) && reader.GetDecimal(2)!=0 ? decimal.Round(reader.GetDecimal(2),2, MidpointRounding.AwayFromZero) :0;
                         
                        rateReportObj.Revenue = !reader.IsDBNull(3) && reader.GetDecimal(3)!=0 ? decimal.Round(reader.GetDecimal(3),2, MidpointRounding.AwayFromZero):0;
                        rateReportObj.Profit = decimal.Round(rateReportObj.Revenue - rateReportObj.Cost,2, MidpointRounding.AwayFromZero);// decimal.Round(( rateReportObj.Revenue - rateReportObj.Cost),2, MidpointRounding.AwayFromZero);
                        rateReportObj.Organization = reader[9]!=null ? ReverseToHTMLCode(reader.GetString(9)): string.Empty;
                       // rateReportObj.Subject = !reader.IsDBNull(4) ? ReverseToHTMLCode(reader.GetString(4)) :string.Empty;
                       // rateReportObj.Location = !reader.IsDBNull(11)  ? reader.GetString(11) : string.Empty; 
                      //  rateReportObj.RateType = !reader.IsDBNull(4) ? reader.GetInt16(4) : 0;
                        user.Specifications.Add(rateReportObj);

                        user.TotalCost += rateReportObj.Cost;
                        user.TotalRevenue += rateReportObj.Revenue;
                        user.TotalProfit += rateReportObj.Profit;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return listReportUser;
        }
        //public void CalculateSubTotal(long userId, RateReportUser user)
        //{
        //    try
        //    {
        //        User usr = null;
        //        Person p = null;
        //        using (UserData usrData = new UserData(UserContext))
        //        {
        //            usr = usrData.Get(userId);
        //        }
        //        if (usr != null && usr.PersonID.HasValue)
        //        {
        //            using (PersonData personData = new PersonData(UserContext))
        //            {
        //                p = personData.Get(usr.PersonID.Value);
        //            }
        //        }
        //        //DBRMappingTable proData = null;
        //        //using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
        //        //{
        //        //    proData = data.GetByDestinationIDEntityTypeID(userId.ToString(), ENTITY_TYPE_USER_PERSON);

        //        //    if (proData != null)
        //        //    {
        //        //        //foreignKey = proData.SourceID;
        //        //        user.UserForeignKey = proData.SourceID;
        //        //    }
        //        //}

        //        if (p != null)
        //        {
        //            user.JobTitle = p.JobTitle;
        //            user.Department = p.Department;
        //            user.FirstName = p.FirstName;
        //            user.LastName = p.LastName;
        //            user.MiddleName = p.MiddleName;
        //            user.UserName = usr.Username;
        //            user.CellPhone = p.CellPhone;
        //            user.DirectPhone = p.DirectPhone;

        //        }
        //        user.ExpenseTotal = user.Specifications.Select(x => x.Total).Aggregate((t1, t2) => t1 + t2);
        //        var expenses = user.Specifications.OrderBy(x => x.ExpenseType).ToArray();
        //        string oldExType = "";
        //        string oldExpenseForeignkey = "";
        //        decimal totalQuanttity = 0;
        //        decimal total = 0;
        //        int count = expenses.Length;
        //        for (int i = 0; i < count; i++)
        //        {
        //            var ex = expenses[i];
        //            //if (!string.IsNullOrEmpty(oldExType) && !oldExType.Equals(ex.ExpenseType, StringComparison.OrdinalIgnoreCase) &&
        //            //    !string.IsNullOrEmpty(oldExpenseForeignkey) && !oldExpenseForeignkey.Equals(ex.ExpenseForeignkey, StringComparison.OrdinalIgnoreCase))
        //            //{
        //            //    ExpenseReportUserSubTotal subTotal = new ExpenseReportUserSubTotal();
        //            //    subTotal.ExpenseType = oldExType;
        //            //    subTotal.Total = total;
        //            //    subTotal.Quantity = totalQuanttity;
        //            //    subTotal.ForeignKey = oldExpenseForeignkey;
        //            //    user.SubTotals.Add(subTotal);
        //            //    totalQuanttity = 0;
        //            //    total = 0;
        //            //}
        //            //totalQuanttity += ex.Quantity;
        //            //total += ex.Total;
        //            //oldExType = ex.ExpenseType;
        //            //oldExpenseForeignkey = ex.ExpenseForeignkey;
        //        }

        //        ExpenseReportUserSubTotal lastSubTotal = new ExpenseReportUserSubTotal();
        //        lastSubTotal.ExpenseType = oldExType;
        //        lastSubTotal.Total = total;
        //        lastSubTotal.Quantity = totalQuanttity;
        //        lastSubTotal.ForeignKey = oldExpenseForeignkey;
        //        //user.SubTotals.Add(lastSubTotal);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        #endregion
        protected void FillObject(Rate rateObj, SqlDataReader reader)
        {
            FillObject(rateObj, reader, 0);
        }
        protected void FillObject(Rate rateObj, SqlDataReader reader, int start)
        {
            rateObj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            rateObj.ID = reader.GetInt64(start + 0);
            rateObj.Cost = reader.GetDecimal(start + 2);
            rateObj.Revenue = reader.GetDecimal(start + 3);
            //FillBaseObject(rateObj, reader, (start + 4));
        }
        public Rate Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETRATEBYID))
            {
                AddParameters(cmd, pInt64(RateBase.Property_ID, ID));
                return GetObject(cmd);
            }
        }
        private Rate GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    var rateObj = new Rate();
                    FillObject(rateObj, reader);
                    return rateObj;
                }
                return null;
            }
        }
        #endregion

        #region Insert
        public long Insert(RateBase rateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTRATE);

                // AddParameter(cmd, pInt64(ActivityRate.Property_ID, activityRateObject.ID));
                AddParameter(cmd, pInt64Out(RateBase.Property_ID, rateObject.ID));
                AddParameter(cmd, pDecimal(RateBase.Property_Cost, rateObject.Cost));
                AddParameter(cmd, pDecimal(RateBase.Property_Revenue, rateObject.Revenue));
                //AddCommonParams(cmd, activityRateObject);

                AddBaseParametersForInsert(cmd, rateObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    rateObject.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                return (long)GetOutParameter(cmd, RateBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(rateObject, x);
            }
        }
        #endregion

        #region Update
        public long Update(RateBase rateObject)
        {
            lock (LOCK_RATE)
            {
                try
                {
                    var dbObject = Get(rateObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(rateObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != rateObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != projectObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(rateObject, null);

                    dbObject.CloneBase(rateObject);

                    SqlCommand cmd = GetSPCommand(UPDATERATE);

                    AddParameter(cmd, pInt64(RateBase.Property_ID, rateObject.ID));
                    AddParameter(cmd, pDecimal(RateBase.Property_Cost, rateObject.Cost));
                    AddParameter(cmd, pDecimal(RateBase.Property_Revenue, rateObject.Revenue));
                    //AddCommonParams(cmd, proRateObject);
                    AddBaseParametersForUpdate(cmd, rateObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        rateObject.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(rateObject, x);
                }
            }
        }
        #endregion

        #region Delete
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETERATE);

                AddParameters(cmd, pInt64(RateBase.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Rate), ID, x);
            }

        }
        #endregion
    }
}
