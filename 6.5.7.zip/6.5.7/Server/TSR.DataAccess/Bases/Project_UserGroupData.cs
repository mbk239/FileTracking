using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Project_UserGroupData : BaseRelationData
	{
		private const string INSERTPROJECT_USERGROUP = "InsertProject_UserGroup";
		private const string UPDATEPROJECT_USERGROUP = "UpdateProject_UserGroup";
		private const string DELETEPROJECT_USERGROUP = "DeleteProject_UserGroup";
		private const string GETPROJECT_USERGROUPBYID = "GetProject_UserGroupByID";
		private const string GETALLPROJECT_USERGROUP = "GetAllProject_UserGroup";
        private const string GETPROJECT_USERGROUPBYUSERID_PROJECTID = "GetProject_UserGroupByUserID_ProjectID";

        #region Constructors

		public Project_UserGroupData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="project_UserGroupObject"></param>
		private void AddCommonParams( SqlCommand cmd, Project_UserGroupBase project_UserGroupObject )
		{
			AddParameter(cmd, pInt64(Project_UserGroupBase.Property_ProjectID, project_UserGroupObject.ProjectID));
			AddParameter(cmd, pInt64(Project_UserGroupBase.Property_UserGroupID, project_UserGroupObject.UserGroupID));
		}

        /// <summary>
        /// Inserts Project_UserGroup
        /// </summary>
        /// <param name="project_UserGroupObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Project_UserGroupBase project_UserGroupObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPROJECT_USERGROUP );
	
				AddParameter(cmd, pInt64Out(Project_UserGroupBase.Property_ID, project_UserGroupObject.ID));
				AddCommonParams( cmd, project_UserGroupObject );
				AddBaseParametersForInsert( cmd, project_UserGroupObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Project_UserGroupBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( project_UserGroupObject, x );
			}
		}
		
        /// <summary>
        /// Updates Project_UserGroup 
        /// </summary>
        /// <param name="project_UserGroupObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Project_UserGroupBase project_UserGroupObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEPROJECT_USERGROUP );

				AddParameter(cmd, pInt64(Project_UserGroupBase.Property_ID, project_UserGroupObject.ID));
				AddCommonParams( cmd, project_UserGroupObject );
				AddBaseParametersForUpdate( cmd, project_UserGroupObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( project_UserGroupObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Project_UserGroup
        /// </summary>
        /// <param name="ID">ID of the Project_UserGroup object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECT_USERGROUP );
	
				AddParameters( cmd, pInt64( Project_UserGroup.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Project_UserGroup ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Project_UserGroup object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Project_UserGroup object to retrieve</param>
        /// <returns>A Project_UserGroup object, null if not found</returns>
		public Project_UserGroup Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPROJECT_USERGROUPBYID) )
			{
				AddParameters( cmd, pInt64( Project_UserGroup.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Project_UserGroup objects 
        /// </summary>
        /// <returns>A list of Project_UserGroup objects</returns>
		public Project_UserGroupList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPROJECT_USERGROUP ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Project_UserGroup object
        /// </summary>
        /// <param name="project_UserGroupObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Project_UserGroupBase project_UserGroupObject, SqlDataReader reader, int start )
		{
			project_UserGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			project_UserGroupObject.ID = reader.GetInt64(start + 0);
			project_UserGroupObject.ProjectID = reader.GetInt64(start + 1);
			project_UserGroupObject.UserGroupID = reader.GetInt64(start + 2);
			FillBaseObject(project_UserGroupObject, reader, (start + 3));
		}

		protected void FillObject( Project_UserGroupBase project_UserGroupObject, SqlDataReader reader )
		{
			FillObject( project_UserGroupObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Project_UserGroup object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Project_UserGroup object</returns>
		private Project_UserGroup GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Project_UserGroup project_UserGroupObject= new Project_UserGroup();
					FillObject( project_UserGroupObject, reader );
					return project_UserGroupObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Project_UserGroup objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Project_UserGroup objects</returns>
		private Project_UserGroupList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Project_UserGroupList list = new Project_UserGroupList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Project_UserGroup project_UserGroupObject = new Project_UserGroup();
					FillObject( project_UserGroupObject, reader );

					list.Add( project_UserGroupObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

