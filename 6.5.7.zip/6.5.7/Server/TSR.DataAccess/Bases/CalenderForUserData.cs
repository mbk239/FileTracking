﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    /// <summary>
    /// Partial Class: CalenderForUserData
    /// Extends: BaseDataAccess
    /// </summary>
    public partial class CalenderForUserData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_CalenderForUser;

        //define the Constants here
        private const string INSERTCALENDER = "InsertCalender";
        private const string UPDATECALENDER = "UpdateCalender";
        private const string INSERTCALENDERWORKHOUR = "InsertCalender_WorkHours";
        private const string INSERTCALENDEREXCEPTION = "InsertCalender_Exception";
        private const string UPDATECALENDEREXCEPTION = "UpdateCalender_Exception";
        private const string GETCALENDEREXCEPTIONBYID = "GetCalender_ExceptionByID";
        private const string DELETECALENDER = "DeleteCalender";
        private const string GETCALENDERWORKHOURSBYID = "GetCalender_WorkHourByID";
        private const string GETALLCALENDER = "GetAllCalender";
        private const string GETCALENDERBYID = "GetCalenderByID";
        private const string DELETECALENDAREXCEPTION = "DeleteCalenderException";

        #region Constructor

        public CalenderForUserData(UserContext context) : base(context) { LOCK_CalenderForUser = this; }
        public CalenderForUserData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_CalenderForUser = this; }

        #endregion Constructor

        /// <summary>
        /// method: AddCommonParams
        /// Adds the common parameters to an object
        /// </summary>
        /// <param name="cmd">an instance of SqlCommand</param>
        /// <param name="calenderObject">an object of CalenderForUserBase class</param>
        private void AddCommonParams(SqlCommand cmd, CalendarForUserBase calenderObject)
        {
            AddParameter(cmd, pNVarChar(CalendarForUserBase.Property_CalenderName, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, calenderObject.CalenderName));
            AddParameter(cmd, pNVarChar(CalendarForUserBase.Property_Description, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, DataTypeHelper.GetStringValue(calenderObject.Description)));
            AddParameter(cmd, pDateTime(CalendarForUserBase.Property_StartDate, calenderObject.StartDate));
            AddParameter(cmd, pDateTime(CalendarForUserBase.Property_EndDate, calenderObject.EndDate));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Mon, calenderObject.Mon));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Tue, calenderObject.Tue));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Wed, calenderObject.Wed));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Thu, calenderObject.Thu));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Fri, calenderObject.Fri));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Sat, calenderObject.Sat));
            AddParameter(cmd, pDouble(CalendarForUserBase.Property_Sun, calenderObject.Sun));
            AddParameter(cmd, pBit(CalendarForUserBase.Property_ReadOnly, DataTypeHelper.GetBooleanValue(calenderObject.ReadOnly)));
            
        }

        /// <summary>
        /// Method: AddExceptionParams
        /// Adds the specialized parameters of a derived class
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="calenderExceptionObject"></param>
        private void AddExceptionParams(SqlCommand cmd, CalenderExceptions calenderExceptionObject)
        {
            AddParameter(cmd, pInt64(CalenderExceptions.Property_CalenderID, calenderExceptionObject.CalenderID));
            AddParameter(cmd, pDateTime(CalenderExceptions.Property_ExceptionDate, calenderExceptionObject.ExceptionDate));
            AddParameter(cmd, pDouble(CalenderExceptions.Property_WorkHours, calenderExceptionObject.WorkHours));
            AddParameter(cmd, pNVarChar(CalenderExceptions.Property_Remark, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, calenderExceptionObject.Remark));
            AddParameter(cmd, pBit(CalendarForUserBase.Property_ReadOnly, false));
        }

        /// <summary>
        /// mehtod: InsertCalenderException
        /// inserts the Exceptions of a calender to the database
        /// </summary>
        /// <param name="calenderExceptionObject"></param>
        /// <returns></returns>
        public long InsertCalenderException(CalenderExceptions calenderExceptionObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTCALENDEREXCEPTION);

                AddParameter(cmd, pInt64Out(CalendarForUserBase.Property_ID, calenderExceptionObject.ID));
                AddExceptionParams(cmd, calenderExceptionObject);
                AddBaseParametersForInsert(cmd, calenderExceptionObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    calenderExceptionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ProjectBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(calenderExceptionObject, x);
            }
        }

        /// <summary>
        /// Method: InsertCalender
        /// Inserts a calender into the database
        /// </summary>
        /// <param name="calanderObject"></param>
        /// <returns></returns>
        public long InsertCalender(CalendarForUserBase calanderObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTCALENDER);

                AddParameter(cmd, pInt64Out(CalendarForUserBase.Property_ID, calanderObject.ID));
                AddCommonParams(cmd, calanderObject);
                AddBaseParametersForInsert(cmd, calanderObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    calanderObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ProjectBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(calanderObject, x);
            }
        }

        /// <summary>
        /// Method: UpdateCalender
        /// Updates a calender
        /// </summary>
        /// <param name="calanderObject"></param>
        /// <returns></returns>
        public long UpdateCalender(CalendarForUserBase calanderObject)
        {
            lock (LOCK_CalenderForUser)
            {
                try
                {
                    CalendarForUserBase dbObject = Get(calanderObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(calanderObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != calanderObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != projectObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(calanderObject, null);

                    SqlCommand cmd = GetSPCommand(UPDATECALENDER);

                    AddParameter(cmd, pInt64(CalendarForUserBase.Property_ID, calanderObject.ID));
                    AddCommonParams(cmd, calanderObject);
                    AddBaseParametersForInsert(cmd, calanderObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        calanderObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectInsertException(calanderObject, x);
                }
            }
        }

        /// <summary>
        /// Method: UpdateCalenderException
        /// updates the exceptions of a calender
        /// </summary>
        /// <param name="calenderExceptionObject"></param>
        /// <returns></returns>
        public long UpdateCalenderException(CalenderExceptions calenderExceptionObject)
        {
            //bool success = true;
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATECALENDEREXCEPTION);

                AddParameter(cmd, pInt64(CalendarForUserBase.Property_ID, calenderExceptionObject.ID));
                AddExceptionParams(cmd, calenderExceptionObject);
                AddBaseParametersForInsert(cmd, calenderExceptionObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    calenderExceptionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(calenderExceptionObject, x);
            }

        }

        /// <summary>
        /// Method: DeleteCalenderException
        /// updates the exceptions of a calender
        /// </summary>
        /// <param name="calenderExceptionObject"></param>
        /// <returns></returns>
        public long DeleteCalenderException(CalenderExceptions calenderExceptionObject)
        {
            //bool success = true;
            try
            {
                SqlCommand cmd = GetSPCommand(DELETECALENDAREXCEPTION);

                AddParameter(cmd, pInt64(CalendarForUserBase.Property_ID, calenderExceptionObject.ID));

                return DeleteRecord(cmd);
                //long result = UpdateRecord(cmd);
                //if (result > 0)
                //    calenderExceptionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                //return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(calenderExceptionObject, x);
            }

        }

        /// <summary>
        /// Method: DeleteCalenderException
        /// updates the exceptions of a calender
        /// </summary>
        /// <param name="calenderExceptionObject"></param>
        /// <returns></returns>
        public long DeleteCalender(CalenderForUser calenderObject)
        {
            //bool success = true;
            try
            {
                SqlCommand cmd = GetSPCommand(DELETECALENDER);

                AddParameter(cmd, pInt64(CalendarForUserBase.Property_ID, calenderObject.ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(calenderObject, x);
            }

        }


        /// <summary>
        /// Method: Insert
        /// Inserts a calender to the database
        /// </summary>
        /// <param name="calanderObject"></param>
        /// <returns></returns>
        public long Insert(CalendarForUserBase calanderObject)
        {
            long calenderid = InsertCalender(calanderObject);

            if (calenderid > 0)
            {
                ;//foreach()
            }

            return calenderid;
           
        }

        /// <summary>
        /// Method: FillObject
        /// Fills an object of CalenderExceptions type by the read data starting at index 'start'
        /// </summary>
        /// <param name="calenderExceptions"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject(CalenderExceptions calenderExceptions, SqlDataReader reader, int start)
        {
            calenderExceptions.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            calenderExceptions.ID = reader.GetInt64(start + 0);
            calenderExceptions.CalenderID = reader.GetInt64(start + 1);
            calenderExceptions.ExceptionDate = reader.GetDateTime(start + 2);
            calenderExceptions.WorkHours = Convert.ToDouble( reader.GetValue(start + 3) );
            if (!reader.IsDBNull(start + 4)) calenderExceptions.Remark = ReverseToHTMLCode(reader.GetString(start + 4));

            FillBaseObject(calenderExceptions, reader, (start + 6));
        }

        /// <summary>
        /// Method: FillObject
        /// Fills an object of CalenderForUserBase type with read data with dataReader starting index at start
        /// </summary>
        /// <param name="calenderObject"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject(CalendarForUserBase calenderObject, SqlDataReader reader, int start)
        {
            calenderObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            calenderObject.ID = reader.GetInt64(start + 0);
            calenderObject.CalenderName = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) calenderObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            calenderObject.StartDate = reader.GetDateTime(start + 3);
            calenderObject.EndDate = reader.GetDateTime(start + 4);
            calenderObject.Mon = Convert.ToDouble( reader.GetValue(start + 5));
            calenderObject.Tue = Convert.ToDouble(reader.GetValue(start + 6));
            calenderObject.Wed = Convert.ToDouble(reader.GetValue(start + 7));
            calenderObject.Thu = Convert.ToDouble(reader.GetValue(start + 8));
            calenderObject.Fri = Convert.ToDouble(reader.GetValue(start + 9));
            calenderObject.Sat = Convert.ToDouble(reader.GetValue(start + 10));
            calenderObject.Sun = Convert.ToDouble(reader.GetValue(start + 11));
            calenderObject.ReadOnly = reader.GetBoolean(start + 12);
            FillBaseObject(calenderObject, reader, (start + 13));
        }

        /// <summary>
        /// Method: FillObject
        /// Fills an object of CalenderForUserBase type with read data with dataReader starting froom begining
        /// </summary>
        /// <param name="calenderObject"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject(CalendarForUserBase calenderObject, SqlDataReader reader)
        {
            FillObject(calenderObject, reader, 0);
        }

        /// <summary>
        /// Method: FillObject
        /// Fills an object of CalenderExceptions type by the read data starting at the begining
        /// </summary>
        /// <param name="calenderExceptions"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject(CalenderExceptions calenderExceptionObject, SqlDataReader reader)
        {
            FillObject(calenderExceptionObject, reader, 0);
        }

        /// <summary>
        /// Method: GetCalenderExceptionList
        /// Gets the exceptions to a calender from the database
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        private CalenderExceptionList GetCalenderExceptionList(SqlCommand cmd, long rows)
        {
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            CalenderExceptionList list = new CalenderExceptionList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    CalenderExceptions calenderExceptionObj = new CalenderExceptions();
                    FillObject(calenderExceptionObj, reader);

                    list.Add(calenderExceptionObj);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;

        }

        /// <summary>
        /// method: GetList
        /// Gets the list of calenders from the database
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        private CalenderForUserList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            CalenderForUserList list = new CalenderForUserList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    CalenderForUser calenderObject = new CalenderForUser();
                    FillObject(calenderObject, reader);

                    list.Add(calenderObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        /// <summary>
        /// Method: GetAll
        /// Gets the list of Calenders
        /// </summary>
        /// <returns></returns>
        public CalenderForUserList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLCALENDER))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Method: Get
        /// Gets a calender by calender ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public CalenderForUser Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCALENDERBYID))
            {
                AddParameters(cmd, pInt64(CalenderForUser.Property_ID, ID));

                return GetObject(cmd);
            }

        }

        /// <summary>
        /// method: GetCalenderExceptions
        /// Gets a list of Calender Exceptions
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public CalenderExceptionList GetCalenderExceptions(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCALENDEREXCEPTIONBYID))
            {
                AddParameters(cmd, pInt64(CalenderExceptions.Property_CalenderID , ID));

                return GetCalenderExceptionList(cmd, ALL_AVAILABLE_RECORDS);
            }

        }

        /// <summary>
        /// Method: GetObject
        /// Gets an object of type CalenderForUser
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        private CalenderForUser GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    CalenderForUser calenderObject = new CalenderForUser();
                    FillObject(calenderObject, reader);
                    return calenderObject;
                }
                else
                {
                    return null;
                }
            }
        }


    }
}
