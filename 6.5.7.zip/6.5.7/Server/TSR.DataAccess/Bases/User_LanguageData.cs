﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class User_LanguageData : TSR.Framework.BaseDataAccess
    {
        private string DELETEUSER_LANGUAGE = "DeleteUser_Language";
        private string GETALLUSER_LANGUAGE = "GetAllUser_Language";
        private string GETUSER_LANGUAGEBYUSERNAME = "GetUser_LanguageByUsername";
        private string GETUSER_LANGUAGEBYUSERID = "GetUser_LanguageByUserID";
        private string GETUSER_LANGUAGEBYID = "GetUser_LanguageByID";
        private string INSERTUSER_LANGUAGE = "InsertUser_Language";
        private string UPDATEUSER_LANGUAGE = "UpdateUser_Language";
    
        public User_LanguageData(UserContext context) : base(context) { }
        public User_LanguageData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public User_Language Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSER_LANGUAGEBYID) )
			{
				AddParameters( cmd, pInt64( City.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        public void GetAll()
        {
            throw new System.NotImplementedException();
        }

        public User_Language GetByUserID(string userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSER_LANGUAGEBYUSERID))
            {
                AddParameter(cmd, pNVarChar(User_LanguageBase.Property_UserID, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, userID));

                return GetObject(cmd);
            }
        }

        public User_Language GetByUsername(string username)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSER_LANGUAGEBYUSERNAME))
            {
                AddParameter(cmd, pNVarChar(User_LanguageBase.Property_Username, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, username ));

                return GetObject(cmd);
            }
        }

        public void Delete()
        {
            throw new System.NotImplementedException();
        }

        public long Insert(User_LanguageBase user_LanguageObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSER_LANGUAGE );

                AddParameter(cmd, pInt64Out(User_LanguageBase.Property_ID, user_LanguageObject.ID));
				AddCommonParams( cmd, user_LanguageObject );
				AddBaseParametersForInsert( cmd, user_LanguageObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					user_LanguageObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, User_LanguageBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( user_LanguageObject, x );
			}
		}

        public long Update(User_LanguageBase user_LanguageObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATEUSER_LANGUAGE);

                AddParameter(cmd, pInt64(User_LanguageBase.Property_ID, user_LanguageObject.ID));
                AddCommonParams(cmd, user_LanguageObject);
                AddBaseParametersForUpdate(cmd, user_LanguageObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    user_LanguageObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(user_LanguageObject, x);
            }

        }

        protected void FillObject(User_LanguageBase user_LanguageObject, SqlDataReader reader, int start)
        {
            user_LanguageObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            
            user_LanguageObject.ID = reader.GetInt64(start + 0);
            user_LanguageObject.UserID = reader.GetString(start + 1);
            if (reader[start + 2] != null && reader[start + 2] != DBNull.Value)
            {
                user_LanguageObject.LanguageID = reader.GetString(start + 2);
            }
            user_LanguageObject.Username = reader.GetString(start + 3);
            user_LanguageObject.LanguageName = reader.GetString(start + 4);
            
            FillBaseObject(user_LanguageObject, reader, (start + 5));
        }

        protected void FillObject(User_LanguageBase cityObject, SqlDataReader reader)
        {
            FillObject(cityObject, reader, 0);
        }

        private User_Language GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    User_Language user_LanguageObject = new User_Language();
                    FillObject(user_LanguageObject, reader);
                    return user_LanguageObject;
                }
                else
                {
                    return null;
                }
            }
        }

        private void AddCommonParams(SqlCommand cmd, User_LanguageBase user_LanguageBaseObject)
        {
            AddParameter(cmd, pNVarChar(User_LanguageBase.Property_UserID, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, user_LanguageBaseObject.UserID));
            AddParameter(cmd, pNVarChar(User_LanguageBase.Property_Username, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, user_LanguageBaseObject.Username));
            AddParameter(cmd, pNVarChar(User_LanguageBase.Property_LanguageID, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, user_LanguageBaseObject.LanguageID));
            AddParameter(cmd, pNVarChar(User_LanguageBase.Property_LanguageName, ConstantCollection.NVARCHAR_FIELD_LENGTH_200, user_LanguageBaseObject.LanguageName));
        }
    }
}
