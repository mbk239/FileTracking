using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class UserGroupData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_UserGroup;

		private const string INSERTUSERGROUP = "InsertUserGroup";
		private const string UPDATEUSERGROUP = "UpdateUserGroup";
		private const string DELETEUSERGROUP = "DeleteUserGroup";
		private const string GETUSERGROUPBYID = "GetUserGroupByID";
		private const string GETALLUSERGROUP = "GetAllUserGroup";
        private const string INACTIVATEUSERGROUP = "InactivateUserGroup";
        //private const string DELETEUSERGROUPBYID = "DeleteUserGroupByID"
        //private const string GETALLUSERGROUPISACTIVE = "GetAllUserIsActive";

        #region Constructors

		public UserGroupData(UserContext context) : base(context) { LOCK_UserGroup = this; }
		public UserGroupData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_UserGroup = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userGroupObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserGroupBase userGroupObject )
		{
            AddParameter(cmd, pNVarChar(UserGroupBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, userGroupObject.Name));
			AddParameter(cmd, pNText(UserGroupBase.Property_Description, userGroupObject.Description));
            AddParameter(cmd, pBool(UserGroupBase.Property_IsSystemConfigurable, userGroupObject.IsSystemConfigurable));

            AddParameter(cmd, pBool(UserGroupBase.Property_IsActive, userGroupObject.IsActive));
		}

        /// <summary>
        /// Inserts UserGroup
        /// </summary>
        /// <param name="userGroupObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserGroupBase userGroupObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSERGROUP );
	
				AddParameter(cmd, pInt64Out(UserGroupBase.Property_ID, userGroupObject.ID));
				AddCommonParams( cmd, userGroupObject );
				AddBaseParametersForInsert( cmd, userGroupObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserGroupBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( userGroupObject, x );
			}
		}
		
        /// <summary>
        /// Updates UserGroup 
        /// </summary>
        /// <param name="userGroupObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserGroupBase userGroupObject)
		{
            lock (LOCK_UserGroup)
            {
				try
				{
                    UserGroupBase dbObject = Get(userGroupObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(userGroupObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != userGroupObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != userGroupObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(userGroupObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEUSERGROUP );

				    AddParameter(cmd, pInt64(UserGroupBase.Property_ID, userGroupObject.ID));
					AddCommonParams( cmd, userGroupObject );
					AddBaseParametersForUpdate( cmd, userGroupObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						userGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( userGroupObject, x );
				}
			}
		}

        public long InActivate(long userGroupID)
        {
            lock (LOCK_UserGroup)
            {
                try
                {
                    SqlCommand cmd = GetSPCommand(INACTIVATEUSERGROUP);

                    AddParameter(cmd, pInt64(UserGroupBase.Property_ID, userGroupID));

                    long result = UpdateRecord(cmd);
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(null, x);
                }
            }
        }

        /// <summary>
        /// Deletes UserGroup
        /// </summary>
        /// <param name="ID">ID of the UserGroup object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSERGROUP );
	
				AddParameters( cmd, pInt64( UserGroup.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( UserGroup ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves UserGroup object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserGroup object to retrieve</param>
        /// <returns>A UserGroup object, null if not found</returns>
		public UserGroup Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERGROUPBYID) )
			{
				AddParameters( cmd, pInt64( UserGroup.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all UserGroup objects 
        /// </summary>
        /// <returns>A list of UserGroup objects</returns>
		public UserGroupList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSERGROUP ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        ////add by tdthinh
        ///// <summary>
        ///// Retrieves all User Isactive objects
        ///// </summary>
        ///// <returns>A list of User objects</returns>
        //public UserGroupList GetAllIsActive()
        //{
        //    using (SqlCommand cmd = GetSPCommand(GETALLUSERGROUPISACTIVE))
        //    {
        //        return GetList(cmd, ALL_AVAILABLE_RECORDS);
        //    }
        //}

        /// <summary>
        /// Fills UserGroup object
        /// </summary>
        /// <param name="userGroupObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( UserGroupBase userGroupObject, SqlDataReader reader, int start )
		{
            userGroupObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            userGroupObject.ID = reader.GetInt64(start + 0);
            userGroupObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) userGroupObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            userGroupObject.IsSystemConfigurable = reader.GetBoolean(start + 3);
            FillBaseObject(userGroupObject, reader, (start + 4));
            if (!(userGroupObject.CustomProperties["IsActive"] == System.DBNull.Value))
                userGroupObject.IsActive = bool.Parse(userGroupObject.CustomProperties["IsActive"].ToString());
		}

        protected void FillObject_View(UserGroupBase userGroupObject, SqlDataReader reader)
        {
            userGroupObject.ID = reader.GetInt64(0);
            userGroupObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

		protected void FillObject( UserGroupBase userGroupObject, SqlDataReader reader )
		{
			FillObject( userGroupObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves UserGroup object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserGroup object</returns>
		private UserGroup GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					UserGroup userGroupObject= new UserGroup();
					FillObject( userGroupObject, reader );
					return userGroupObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of UserGroup objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserGroup objects</returns>
		private UserGroupList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserGroupList list = new UserGroupList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					UserGroup userGroupObject = new UserGroup();
					FillObject( userGroupObject, reader );

					list.Add( userGroupObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private UserGroupList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserGroupList list = new UserGroupList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    UserGroup userGroupObject = new UserGroup();
                    FillObject_View(userGroupObject, reader);

                    list.Add(userGroupObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        //public bool DeleteUserGroupByID(long usergroupID)
        //{
        //    try
        //    {
        //        SqlCommand cmd = GetSPCommand(DELETEUSERGROUPBYID);
        //        AddParameters(cmd, pInt64("UserGroupId", usergroupID));
        //        return DeleteRecord(cmd) >= 0;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //}
    }
}

