using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ActivityTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_ActivityType;

		private const string INSERTACTIVITYTYPE = "InsertActivityType";
		private const string UPDATEACTIVITYTYPE = "UpdateActivityType";
		private const string DELETEACTIVITYTYPE = "DeleteActivityType";
		private const string GETACTIVITYTYPEBYID = "GetActivityTypeByID";
		private const string GETALLACTIVITYTYPE = "GetAllActivityType";

        #region Constructors

		public ActivityTypeData(UserContext context) : base(context) { LOCK_ActivityType = this; }
		public ActivityTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_ActivityType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="activityTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, ActivityTypeBase activityTypeObject )
		{
            AddParameter(cmd, pNVarChar(ActivityTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, activityTypeObject.Name));
			AddParameter(cmd, pNText(ActivityTypeBase.Property_Description, activityTypeObject.Description));
			AddParameter(cmd, pBool(ActivityTypeBase.Property_ReadOnly, activityTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts ActivityType
        /// </summary>
        /// <param name="activityTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ActivityTypeBase activityTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTACTIVITYTYPE );
	
				AddParameter(cmd, pInt64Out(ActivityTypeBase.Property_ID, activityTypeObject.ID));
				AddCommonParams( cmd, activityTypeObject );
				AddBaseParametersForInsert( cmd, activityTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					activityTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ActivityTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( activityTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates ActivityType 
        /// </summary>
        /// <param name="activityTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ActivityTypeBase activityTypeObject)
		{
            lock (LOCK_ActivityType)
            {
				try
				{
                    ActivityTypeBase dbObject = Get(activityTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(activityTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != activityTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != activityTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(activityTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEACTIVITYTYPE );

				AddParameter(cmd, pInt64(ActivityTypeBase.Property_ID, activityTypeObject.ID));
					AddCommonParams( cmd, activityTypeObject );
					AddBaseParametersForUpdate( cmd, activityTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						activityTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( activityTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes ActivityType
        /// </summary>
        /// <param name="ID">ID of the ActivityType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEACTIVITYTYPE );
	
				AddParameters( cmd, pInt64( ActivityType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ActivityType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves ActivityType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ActivityType object to retrieve</param>
        /// <returns>A ActivityType object, null if not found</returns>
		public ActivityType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETACTIVITYTYPEBYID) )
			{
				AddParameters( cmd, pInt64( ActivityType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all ActivityType objects 
        /// </summary>
        /// <returns>A list of ActivityType objects</returns>
		public ActivityTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLACTIVITYTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ActivityType object
        /// </summary>
        /// <param name="activityTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ActivityTypeBase activityTypeObject, SqlDataReader reader, int start )
		{
			activityTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			activityTypeObject.ID = reader.GetInt64(start + 0);
			activityTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) activityTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			activityTypeObject.ReadOnly = reader.GetBoolean(start + 3);
			FillBaseObject(activityTypeObject, reader, (start + 4));
		}

        protected void FillObject_View(ActivityTypeBase activityTypeObject, SqlDataReader reader)
        {
            activityTypeObject.ID = reader.GetInt64(0);
            activityTypeObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

		protected void FillObject( ActivityTypeBase activityTypeObject, SqlDataReader reader )
		{
			FillObject( activityTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ActivityType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ActivityType object</returns>
		private ActivityType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ActivityType activityTypeObject= new ActivityType();
					FillObject( activityTypeObject, reader );
					return activityTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ActivityType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ActivityType objects</returns>
		private ActivityTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ActivityTypeList list = new ActivityTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					ActivityType activityTypeObject = new ActivityType();
					FillObject( activityTypeObject, reader );

					list.Add( activityTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private ActivityTypeList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ActivityTypeList list = new ActivityTypeList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ActivityType activityTypeObject = new ActivityType();
                    FillObject_View(activityTypeObject, reader);

                    list.Add(activityTypeObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

	}
}

