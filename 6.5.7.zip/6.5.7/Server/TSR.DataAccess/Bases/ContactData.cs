using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class ContactData : BaseDataAccess
    {
        private static BaseDataAccess LOCK_Contact;

        private const string INSERTCONTACT = "InsertContact";
        private const string UPDATECONTACT = "UpdateContact";
        private const string DELETECONTACT = "DeleteContact";
        private const string GETCONTACTBYID = "GetContactByID";
        private const string GETALLCONTACT = "GetAllContact";
        private const string GETALLDELETEDCONTACT = "GetAllDeletedContact";
        private const string GETCONTACTSREVERSIONFORUSER = "GetAllContactsReversionForUser";
        private const string GETCONTACT_PAGING = "GetContactForPaging";


        #region Constructors

        public ContactData(UserContext context) : base(context) { LOCK_Contact = this; }
        public ContactData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Contact = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="contactObject"></param>
        private void AddCommonParams(SqlCommand cmd, ContactBase contactObject)
        {
            AddParameter(cmd, pInt64(ContactBase.Property_ContactTypeID, contactObject.ContactTypeID));
            AddParameter(cmd, pInt64(ContactBase.Property_PersonID, contactObject.PersonID));
        }

        /// <summary>
        /// Inserts Contact
        /// </summary>
        /// <param name="contactObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(ContactBase contactObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTCONTACT);

                AddParameter(cmd, pInt64Out(ContactBase.Property_ID, contactObject.ID));
                AddCommonParams(cmd, contactObject);
                AddBaseParametersForInsert(cmd, contactObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    contactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ContactBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(contactObject, x);
            }
        }

        /// <summary>
        /// Updates Contact 
        /// </summary>
        /// <param name="contactObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(ContactBase contactObject)
        {
            lock (LOCK_Contact)
            {
                try
                {
                    ContactBase dbObject = Get(contactObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(contactObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != contactObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != contactObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(contactObject, null);

                    dbObject.CloneBase(contactObject);

                    SqlCommand cmd = GetSPCommand(UPDATECONTACT);

                    AddParameter(cmd, pInt64(ContactBase.Property_ID, contactObject.ID));
                    AddCommonParams(cmd, contactObject);
                    AddBaseParametersForUpdate(cmd, contactObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        contactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(contactObject, x);
                }
            }
        }

        /// <summary>
        /// Deletes Contact
        /// </summary>
        /// <param name="ID">ID of the Contact object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETECONTACT);

                AddParameters(cmd, pInt64(Contact.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Contact), ID, x);
            }

        }

        /// <summary>
        /// Retrieves Contact object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Contact object to retrieve</param>
        /// <returns>A Contact object, null if not found</returns>
        public Contact Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCONTACTBYID))
            {
                AddParameters(cmd, pInt64(Contact.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Contact objects 
        /// </summary>
        /// <returns>A list of Contact objects</returns>
        public ContactList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLCONTACT))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
        /// <summary>
        /// Retrieves all Deleted Contact objects 
        /// </summary>
        /// <returns>A list of Deleted Contact objects</returns>
        public ContactList GetAllDeleted()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLDELETEDCONTACT))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Contact object
        /// </summary>
        /// <param name="contactObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(ContactBase contactObject, SqlDataReader reader, int start)
        {
            contactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            contactObject.ID = reader.GetInt64(start + 0);
            contactObject.ContactTypeID = reader.GetInt64(start + 1);
            contactObject.PersonID = reader.GetInt64(start + 2);
            FillBaseObject(contactObject, reader, (start + 3));
        }

        protected void FillObject(ContactBase contactObject, SqlDataReader reader)
        {
            FillObject(contactObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Contact object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Contact object</returns>
        private Contact GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    Contact contactObject = new Contact();
                    FillObject(contactObject, reader);
                    return contactObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Contact objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Contact objects</returns>
        private ContactList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ContactList list = new ContactList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Contact contactObject = new Contact();
                    FillObject(contactObject, reader);

                    list.Add(contactObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        public ContactVersionList GetAllContactsForUser(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCONTACTSREVERSIONFORUSER))
            {
                AddParameter(cmd, pInt64("UserID", userID));
                return GetVersionList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        private ContactVersionList GetVersionList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ContactVersionList list = new ContactVersionList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ContactVersion contactVersionObject = new ContactVersion();
                    FillVersionObject(contactVersionObject, reader);

                    list.Add(contactVersionObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        private void FillVersionObject(ContactVersion contactVersionObject, SqlDataReader reader)
        {
            contactVersionObject.ContactID= reader.GetInt64(0);
            if (!reader.IsDBNull(1))
                contactVersionObject.ContactReversion = DataTypeHelper.ConvertToString(reader.GetDateTime(1));
            contactVersionObject.OrganizationID = reader.GetInt64(2);
        }

        public ContactList GetContactPaging(int startOffset, int numberOfItems, long orgID, string name, out int total)
        {
            ContactList lst = new ContactList();
            using (SqlCommand cmd = GetSPCommand(GETCONTACT_PAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                AddParameter(cmd, pInt64("OrganizationID", orgID));
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);

                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }

        private ContactList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ContactList list = new ContactList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Contact contactObject = new Contact();
                    FillObject_View(contactObject, reader);

                    list.Add(contactObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        protected void FillObject_View(Contact contactObject, SqlDataReader reader)
        {
            contactObject.ID = reader.GetInt64(0);
            contactObject.Person = new Person();
            contactObject.Person.FirstName = reader.GetString(1);
        }

    }
}

