using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class StateData : BaseDataAccess
	{
		private const string INSERTSTATE = "InsertState";
		private const string UPDATESTATE = "UpdateState";
		private const string DELETESTATE = "DeleteState";
		private const string GETSTATEBYID = "GetStateByID";
		private const string GETALLSTATE = "GetAllState";

        #region Constructors

		public StateData(UserContext context) : base(context) { }
		public StateData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="stateObject"></param>
		private void AddCommonParams( SqlCommand cmd, StateBase stateObject )
		{
			//AddParameter(cmd, pInt64(StateBase.Property_CountryID, stateObject.CountryID));
            AddParameter(cmd,  pNVarChar(StateBase.Property_CountryName,ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, stateObject.CountryName));
			AddParameter(cmd, pNVarChar(StateBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, stateObject.Name));
		}

        /// <summary>
        /// Inserts State
        /// </summary>
        /// <param name="stateObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( StateBase stateObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTSTATE );
	
				AddParameter(cmd, pInt64Out(StateBase.Property_ID, stateObject.ID));
				AddCommonParams( cmd, stateObject );
				AddBaseParametersForInsert( cmd, stateObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					stateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, StateBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( stateObject, x );
			}
		}
		
        /// <summary>
        /// Updates State 
        /// </summary>
        /// <param name="stateObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( StateBase stateObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATESTATE );

				AddParameter(cmd, pInt64(StateBase.Property_ID, stateObject.ID));
				AddCommonParams( cmd, stateObject );
				AddBaseParametersForUpdate( cmd, stateObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					stateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( stateObject, x );
			}
			
		}

        /// <summary>
        /// Deletes State
        /// </summary>
        /// <param name="ID">ID of the State object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETESTATE );
	
				AddParameters( cmd, pInt64( State.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( State ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves State object using it's ID
        /// </summary>
        /// <param name="ID">The id of the State object to retrieve</param>
        /// <returns>A State object, null if not found</returns>
		public State Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETSTATEBYID) )
			{
				AddParameters( cmd, pInt64( State.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all State objects 
        /// </summary>
        /// <returns>A list of State objects</returns>
		public StateList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLSTATE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills State object
        /// </summary>
        /// <param name="stateObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( StateBase stateObject, SqlDataReader reader, int start )
		{
			stateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			stateObject.ID = reader.GetInt64(start + 0);
			//stateObject.CountryID = reader.GetInt64(start + 1);
            stateObject.CountryName = ReverseToHTMLCode(reader.GetString(start + 1));
			stateObject.Name = ReverseToHTMLCode(reader.GetString(start + 2));
			FillBaseObject(stateObject, reader, (start + 3));
		}

		protected void FillObject( StateBase stateObject, SqlDataReader reader )
		{
			FillObject( stateObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves State object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>State object</returns>
		private State GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					State stateObject= new State();
					FillObject( stateObject, reader );
					return stateObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of State objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of State objects</returns>
		private StateList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			StateList list = new StateList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					State stateObject = new State();
					FillObject( stateObject, reader );

					list.Add( stateObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

