using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class AppConfigurationData : BaseDataAccess
	{
		private const string INSERTAPPCONFIGURATION = "InsertAppConfiguration";
		private const string UPDATEAPPCONFIGURATION = "UpdateAppConfiguration";
		private const string DELETEAPPCONFIGURATION = "DeleteAppConfiguration";
		private const string GETAPPCONFIGURATIONBYID = "GetAppConfigurationByID";
		private const string GETALLAPPCONFIGURATION = "GetAllAppConfiguration";

        #region Constructors

		public AppConfigurationData(UserContext context) : base(context) { }
		public AppConfigurationData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="appConfigurationObject"></param>
		private void AddCommonParams( SqlCommand cmd, AppConfigurationBase appConfigurationObject )
		{
			AddParameter(cmd, pVarChar(AppConfigurationBase.Property_Key, 50, appConfigurationObject.Key));
			AddParameter(cmd, pText(AppConfigurationBase.Property_Value, appConfigurationObject.Value));
		}

        /// <summary>
        /// Inserts AppConfiguration
        /// </summary>
        /// <param name="appConfigurationObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( AppConfigurationBase appConfigurationObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTAPPCONFIGURATION );
	
				AddParameter(cmd, pInt64Out(AppConfigurationBase.Property_ID, appConfigurationObject.ID));
				AddCommonParams( cmd, appConfigurationObject );
				AddBaseParametersForInsert( cmd, appConfigurationObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					appConfigurationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, AppConfigurationBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( appConfigurationObject, x );
			}
		}
		
        /// <summary>
        /// Updates AppConfiguration 
        /// </summary>
        /// <param name="appConfigurationObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( AppConfigurationBase appConfigurationObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEAPPCONFIGURATION );

				AddParameter(cmd, pInt64(AppConfigurationBase.Property_ID, appConfigurationObject.ID));
				AddCommonParams( cmd, appConfigurationObject );
				AddBaseParametersForUpdate( cmd, appConfigurationObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					appConfigurationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( appConfigurationObject, x );
			}
			
		}

        /// <summary>
        /// Deletes AppConfiguration
        /// </summary>
        /// <param name="ID">ID of the AppConfiguration object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEAPPCONFIGURATION );
	
				AddParameters( cmd, pInt64( AppConfiguration.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( AppConfiguration ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves AppConfiguration object using it's ID
        /// </summary>
        /// <param name="ID">The id of the AppConfiguration object to retrieve</param>
        /// <returns>A AppConfiguration object, null if not found</returns>
		public AppConfiguration Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETAPPCONFIGURATIONBYID) )
			{
				AddParameters( cmd, pInt64( AppConfiguration.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all AppConfiguration objects 
        /// </summary>
        /// <returns>A list of AppConfiguration objects</returns>
		public AppConfigurationList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLAPPCONFIGURATION ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills AppConfiguration object
        /// </summary>
        /// <param name="appConfigurationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( AppConfigurationBase appConfigurationObject, SqlDataReader reader, int start )
		{
			appConfigurationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			appConfigurationObject.ID = reader.GetInt64(start + 0);
			appConfigurationObject.Key = reader.GetString(start + 1);
			appConfigurationObject.Value = reader.GetString(start + 2);
			FillBaseObject(appConfigurationObject, reader, (start + 3));
		}

		protected void FillObject( AppConfigurationBase appConfigurationObject, SqlDataReader reader )
		{
			FillObject( appConfigurationObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves AppConfiguration object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>AppConfiguration object</returns>
		private AppConfiguration GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					AppConfiguration appConfigurationObject= new AppConfiguration();
					FillObject( appConfigurationObject, reader );
					return appConfigurationObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of AppConfiguration objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of AppConfiguration objects</returns>
		private AppConfigurationList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			AppConfigurationList list = new AppConfigurationList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					AppConfiguration appConfigurationObject = new AppConfiguration();
					FillObject( appConfigurationObject, reader );

					list.Add( appConfigurationObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

