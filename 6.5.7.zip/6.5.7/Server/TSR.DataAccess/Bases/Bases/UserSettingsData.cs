using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class UserSettingsData : BaseDataAccess
	{
		private const string INSERTUSERSETTINGS = "InsertUserSettings";
		private const string UPDATEUSERSETTINGS = "UpdateUserSettings";
		private const string DELETEUSERSETTINGS = "DeleteUserSettings";
		private const string GETUSERSETTINGSBYID = "GetUserSettingsByID";
		private const string GETALLUSERSETTINGS = "GetAllUserSettings";

        #region Constructors

		public UserSettingsData(UserContext context) : base(context) { }
		public UserSettingsData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userSettingsObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserSettingsBase userSettingsObject )
		{
			AddParameter(cmd, pInt64(UserSettingsBase.Property_UserID, userSettingsObject.UserID));
			AddParameter(cmd, pText(UserSettingsBase.Property_SettingsName, userSettingsObject.SettingsName));
			AddParameter(cmd, pText(UserSettingsBase.Property_SettingsValue, userSettingsObject.SettingsValue));
		}

        /// <summary>
        /// Inserts UserSettings
        /// </summary>
        /// <param name="userSettingsObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserSettingsBase userSettingsObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSERSETTINGS );
	
				AddParameter(cmd, pInt64Out(UserSettingsBase.Property_ID, userSettingsObject.ID));
				AddCommonParams( cmd, userSettingsObject );
				AddBaseParametersForInsert( cmd, userSettingsObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userSettingsObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserSettingsBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( userSettingsObject, x );
			}
		}
		
        /// <summary>
        /// Updates UserSettings 
        /// </summary>
        /// <param name="userSettingsObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserSettingsBase userSettingsObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEUSERSETTINGS );

				AddParameter(cmd, pInt64(UserSettingsBase.Property_ID, userSettingsObject.ID));
				AddCommonParams( cmd, userSettingsObject );
				AddBaseParametersForUpdate( cmd, userSettingsObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					userSettingsObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( userSettingsObject, x );
			}
			
		}

        /// <summary>
        /// Deletes UserSettings
        /// </summary>
        /// <param name="ID">ID of the UserSettings object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSERSETTINGS );
	
				AddParameters( cmd, pInt64( UserSettings.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( UserSettings ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves UserSettings object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserSettings object to retrieve</param>
        /// <returns>A UserSettings object, null if not found</returns>
		public UserSettings Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERSETTINGSBYID) )
			{
				AddParameters( cmd, pInt64( UserSettings.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all UserSettings objects 
        /// </summary>
        /// <returns>A list of UserSettings objects</returns>
		public UserSettingsList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSERSETTINGS ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills UserSettings object
        /// </summary>
        /// <param name="userSettingsObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( UserSettingsBase userSettingsObject, SqlDataReader reader, int start )
		{
			userSettingsObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			userSettingsObject.ID = reader.GetInt64(start + 0);
			userSettingsObject.UserID = reader.GetInt64(start + 1);
			userSettingsObject.SettingsName = reader.GetString(start + 2);
			userSettingsObject.SettingsValue = reader.GetString(start + 3);
			FillBaseObject(userSettingsObject, reader, (start + 4));
		}

		protected void FillObject( UserSettingsBase userSettingsObject, SqlDataReader reader )
		{
			FillObject( userSettingsObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves UserSettings object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserSettings object</returns>
		private UserSettings GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					UserSettings userSettingsObject= new UserSettings();
					FillObject( userSettingsObject, reader );
					return userSettingsObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of UserSettings objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserSettings objects</returns>
		private UserSettingsList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserSettingsList list = new UserSettingsList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					UserSettings userSettingsObject = new UserSettings();
					FillObject( userSettingsObject, reader );

					list.Add( userSettingsObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

