using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class ZipCodeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_ZipCode;

		private const string INSERTZIPCODE = "InsertZipCode";
		private const string UPDATEZIPCODE = "UpdateZipCode";
		private const string DELETEZIPCODE = "DeleteZipCode";
		private const string GETZIPCODEBYID = "GetZipCodeByID";
		private const string GETALLZIPCODE = "GetAllZipCode";

        #region Constructors

		public ZipCodeData(UserContext context) : base(context) { LOCK_ZipCode = this; }
		public ZipCodeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_ZipCode = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="zipCodeObject"></param>
		private void AddCommonParams( SqlCommand cmd, ZipCodeBase zipCodeObject )
		{
			AddParameter(cmd, pVarChar(ZipCodeBase.Property_Code, 50, zipCodeObject.Code));
			AddParameter(cmd, pInt64(ZipCodeBase.Property_StateID, zipCodeObject.StateID));
			AddParameter(cmd, pInt64(ZipCodeBase.Property_CityID, zipCodeObject.CityID));
		}

        /// <summary>
        /// Inserts ZipCode
        /// </summary>
        /// <param name="zipCodeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ZipCodeBase zipCodeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTZIPCODE );
	
				AddParameter(cmd, pInt64Out(ZipCodeBase.Property_ID, zipCodeObject.ID));
				AddCommonParams( cmd, zipCodeObject );
				AddBaseParametersForInsert( cmd, zipCodeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					zipCodeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ZipCodeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( zipCodeObject, x );
			}
		}
		
        /// <summary>
        /// Updates ZipCode 
        /// </summary>
        /// <param name="zipCodeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ZipCodeBase zipCodeObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    ZipCodeBase dbObject = Get(zipCodeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(zipCodeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != zipCodeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != zipCodeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEZIPCODE );

				AddParameter(cmd, pInt64(ZipCodeBase.Property_ID, zipCodeObject.ID));
					AddCommonParams( cmd, zipCodeObject );
					AddBaseParametersForUpdate( cmd, zipCodeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						zipCodeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( zipCodeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes ZipCode
        /// </summary>
        /// <param name="ID">ID of the ZipCode object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEZIPCODE );
	
				AddParameters( cmd, pInt64( ZipCode.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ZipCode ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves ZipCode object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ZipCode object to retrieve</param>
        /// <returns>A ZipCode object, null if not found</returns>
		public ZipCode Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETZIPCODEBYID) )
			{
				AddParameters( cmd, pInt64( ZipCode.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all ZipCode objects 
        /// </summary>
        /// <returns>A list of ZipCode objects</returns>
		public ZipCodeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLZIPCODE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ZipCode object
        /// </summary>
        /// <param name="zipCodeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ZipCodeBase zipCodeObject, SqlDataReader reader, int start )
		{
			zipCodeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			zipCodeObject.ID = reader.GetInt64(start + 0);
			zipCodeObject.Code = reader.GetString(start + 1);
			zipCodeObject.StateID = reader.GetInt64(start + 2);
			zipCodeObject.CityID = reader.GetInt64(start + 3);
			FillBaseObject(zipCodeObject, reader, (start + 4));
		}

		protected void FillObject( ZipCodeBase zipCodeObject, SqlDataReader reader )
		{
			FillObject( zipCodeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ZipCode object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ZipCode object</returns>
		private ZipCode GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ZipCode zipCodeObject= new ZipCode();
					FillObject( zipCodeObject, reader );
					return zipCodeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ZipCode objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ZipCode objects</returns>
		private ZipCodeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ZipCodeList list = new ZipCodeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					ZipCode zipCodeObject = new ZipCode();
					FillObject( zipCodeObject, reader );

					list.Add( zipCodeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

