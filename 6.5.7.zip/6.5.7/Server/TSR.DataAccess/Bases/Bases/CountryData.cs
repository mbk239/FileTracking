using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class CountryData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Country;

		private const string INSERTCOUNTRY = "InsertCountry";
		private const string UPDATECOUNTRY = "UpdateCountry";
		private const string DELETECOUNTRY = "DeleteCountry";
		private const string GETCOUNTRYBYID = "GetCountryByID";
		private const string GETALLCOUNTRY = "GetAllCountry";

        #region Constructors

		public CountryData(UserContext context) : base(context) { LOCK_Country = this; }
		public CountryData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Country = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="countryObject"></param>
		private void AddCommonParams( SqlCommand cmd, CountryBase countryObject )
		{
			AddParameter(cmd, pVarChar(CountryBase.Property_Name, 255, countryObject.Name));
		}

        /// <summary>
        /// Inserts Country
        /// </summary>
        /// <param name="countryObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( CountryBase countryObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTCOUNTRY );
	
				AddParameter(cmd, pInt64Out(CountryBase.Property_ID, countryObject.ID));
				AddCommonParams( cmd, countryObject );
				AddBaseParametersForInsert( cmd, countryObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					countryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, CountryBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( countryObject, x );
			}
		}
		
        /// <summary>
        /// Updates Country 
        /// </summary>
        /// <param name="countryObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( CountryBase countryObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    CountryBase dbObject = Get(countryObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(countryObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != countryObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != countryObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATECOUNTRY );

				AddParameter(cmd, pInt64(CountryBase.Property_ID, countryObject.ID));
					AddCommonParams( cmd, countryObject );
					AddBaseParametersForUpdate( cmd, countryObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						countryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( countryObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Country
        /// </summary>
        /// <param name="ID">ID of the Country object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETECOUNTRY );
	
				AddParameters( cmd, pInt64( Country.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Country ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Country object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Country object to retrieve</param>
        /// <returns>A Country object, null if not found</returns>
		public Country Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETCOUNTRYBYID) )
			{
				AddParameters( cmd, pInt64( Country.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Country objects 
        /// </summary>
        /// <returns>A list of Country objects</returns>
		public CountryList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLCOUNTRY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Country object
        /// </summary>
        /// <param name="countryObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( CountryBase countryObject, SqlDataReader reader, int start )
		{
			countryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			countryObject.ID = reader.GetInt64(start + 0);
			countryObject.Name = reader.GetString(start + 1);
			FillBaseObject(countryObject, reader, (start + 2));
		}

		protected void FillObject( CountryBase countryObject, SqlDataReader reader )
		{
			FillObject( countryObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Country object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Country object</returns>
		private Country GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Country countryObject= new Country();
					FillObject( countryObject, reader );
					return countryObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Country objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Country objects</returns>
		private CountryList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			CountryList list = new CountryList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Country countryObject = new Country();
					FillObject( countryObject, reader );

					list.Add( countryObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

