using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class LogData : BaseDataAccess
	{
		private const string INSERTLOG = "InsertLog";
		private const string UPDATELOG = "UpdateLog";
		private const string DELETELOG = "DeleteLog";
		private const string GETLOGBYID = "GetLogByID";
		private const string GETALLLOG = "GetAllLog";

        #region Constructors

		public LogData(UserContext context) : base(context) { }
		public LogData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="logObject"></param>
		private void AddCommonParams( SqlCommand cmd, LogBase logObject )
		{
			AddParameter(cmd, pInt64(LogBase.Property_UserID, logObject.UserID));
			AddParameter(cmd, pText(LogBase.Property_SessionID, logObject.SessionID));
			AddParameter(cmd, pText(LogBase.Property_ClientHost, logObject.ClientHost));
			AddParameter(cmd, pText(LogBase.Property_ServerIP, logObject.ServerIP));
			AddParameter(cmd, pText(LogBase.Property_Service, logObject.Service));
			AddParameter(cmd, pVarChar(LogBase.Property_Category, 256, logObject.Category));
			AddParameter(cmd, pInt32(LogBase.Property_Priority, logObject.Priority));
			AddParameter(cmd, pDateTime(LogBase.Property_LoggingTime, logObject.LoggingTime));
			AddParameter(cmd, pText(LogBase.Property_MessageSummary, logObject.MessageSummary));
			AddParameter(cmd, pText(LogBase.Property_MessageDetail, logObject.MessageDetail));
			AddParameter(cmd, pText(LogBase.Property_StackTrace, logObject.StackTrace));
		}

        /// <summary>
        /// Inserts Log
        /// </summary>
        /// <param name="logObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( LogBase logObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTLOG );
	
				AddParameter(cmd, pInt64Out(LogBase.Property_ID, logObject.ID));
				AddCommonParams( cmd, logObject );
				AddBaseParametersForInsert( cmd, logObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					logObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, LogBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( logObject, x );
			}
		}
		
        /// <summary>
        /// Updates Log 
        /// </summary>
        /// <param name="logObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( LogBase logObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATELOG );

				AddParameter(cmd, pInt64(LogBase.Property_ID, logObject.ID));
				AddCommonParams( cmd, logObject );
				AddBaseParametersForUpdate( cmd, logObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					logObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( logObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Log
        /// </summary>
        /// <param name="ID">ID of the Log object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETELOG );
	
				AddParameters( cmd, pInt64( Log.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( Log ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Log object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Log object to retrieve</param>
        /// <returns>A Log object, null if not found</returns>
		public Log Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETLOGBYID) )
			{
				AddParameters( cmd, pInt64( Log.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Log objects 
        /// </summary>
        /// <returns>A list of Log objects</returns>
		public LogList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLLOG ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Log object
        /// </summary>
        /// <param name="logObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( LogBase logObject, SqlDataReader reader, int start )
		{
			logObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			logObject.ID = reader.GetInt64(start + 0);
			logObject.UserID = reader.GetInt64(start + 1);
			if (!reader.IsDBNull(start + 2)) logObject.SessionID = reader.GetString(start + 2);
			if (!reader.IsDBNull(start + 3)) logObject.ClientHost = reader.GetString(start + 3);
			if (!reader.IsDBNull(start + 4)) logObject.ServerIP = reader.GetString(start + 4);
			if (!reader.IsDBNull(start + 5)) logObject.Service = reader.GetString(start + 5);
			if (!reader.IsDBNull(start + 6)) logObject.Category = reader.GetString(start + 6);
			if (!reader.IsDBNull(start + 7)) logObject.Priority = reader.GetInt32(start + 7);
			if (!reader.IsDBNull(start + 8)) logObject.LoggingTime = reader.GetDateTime(start + 8);
			if (!reader.IsDBNull(start + 9)) logObject.MessageSummary = reader.GetString(start + 9);
			if (!reader.IsDBNull(start + 10)) logObject.MessageDetail = reader.GetString(start + 10);
			if (!reader.IsDBNull(start + 11)) logObject.StackTrace = reader.GetString(start + 11);
			FillBaseObject(logObject, reader, (start + 12));
		}

		protected void FillObject( LogBase logObject, SqlDataReader reader )
		{
			FillObject( logObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Log object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Log object</returns>
		private Log GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Log logObject= new Log();
					FillObject( logObject, reader );
					return logObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Log objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Log objects</returns>
		private LogList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			LogList list = new LogList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Log logObject = new Log();
					FillObject( logObject, reader );

					list.Add( logObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

