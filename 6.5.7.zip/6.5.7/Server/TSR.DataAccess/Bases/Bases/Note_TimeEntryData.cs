using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class Note_TimeEntryData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Note_TimeEntry;

		private const string INSERTNOTE_TIMEENTRY = "InsertNote_TimeEntry";
		private const string UPDATENOTE_TIMEENTRY = "UpdateNote_TimeEntry";
		private const string DELETENOTE_TIMEENTRY = "DeleteNote_TimeEntry";
		private const string GETNOTE_TIMEENTRYBYID = "GetNote_TimeEntryByID";
		private const string GETALLNOTE_TIMEENTRY = "GetAllNote_TimeEntry";

        #region Constructors

		public Note_TimeEntryData(UserContext context) : base(context) { LOCK_Note_TimeEntry = this; }
		public Note_TimeEntryData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Note_TimeEntry = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="note_TimeEntryObject"></param>
		private void AddCommonParams( SqlCommand cmd, Note_TimeEntryBase note_TimeEntryObject )
		{
			AddParameter(cmd, pInt64(Note_TimeEntryBase.Property_NoteID, note_TimeEntryObject.NoteID));
			AddParameter(cmd, pGuid(Note_TimeEntryBase.Property_TimeEntryID, note_TimeEntryObject.TimeEntryID));
		}

        /// <summary>
        /// Inserts Note_TimeEntry
        /// </summary>
        /// <param name="note_TimeEntryObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Note_TimeEntryBase note_TimeEntryObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTNOTE_TIMEENTRY );
	
				AddParameter(cmd, pInt64Out(Note_TimeEntryBase.Property_ID, note_TimeEntryObject.ID));
				AddCommonParams( cmd, note_TimeEntryObject );
				AddBaseParametersForInsert( cmd, note_TimeEntryObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					note_TimeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Note_TimeEntryBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( note_TimeEntryObject, x );
			}
		}
		
        /// <summary>
        /// Updates Note_TimeEntry 
        /// </summary>
        /// <param name="note_TimeEntryObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Note_TimeEntryBase note_TimeEntryObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    Note_TimeEntryBase dbObject = Get(note_TimeEntryObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(note_TimeEntryObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != note_TimeEntryObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != note_TimeEntryObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATENOTE_TIMEENTRY );

				AddParameter(cmd, pInt64(Note_TimeEntryBase.Property_ID, note_TimeEntryObject.ID));
					AddCommonParams( cmd, note_TimeEntryObject );
					AddBaseParametersForUpdate( cmd, note_TimeEntryObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						note_TimeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( note_TimeEntryObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Note_TimeEntry
        /// </summary>
        /// <param name="ID">ID of the Note_TimeEntry object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETENOTE_TIMEENTRY );
	
				AddParameters( cmd, pInt64( Note_TimeEntry.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Note_TimeEntry ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Note_TimeEntry object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Note_TimeEntry object to retrieve</param>
        /// <returns>A Note_TimeEntry object, null if not found</returns>
		public Note_TimeEntry Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETNOTE_TIMEENTRYBYID) )
			{
				AddParameters( cmd, pInt64( Note_TimeEntry.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Note_TimeEntry objects 
        /// </summary>
        /// <returns>A list of Note_TimeEntry objects</returns>
		public Note_TimeEntryList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLNOTE_TIMEENTRY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Note_TimeEntry object
        /// </summary>
        /// <param name="note_TimeEntryObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Note_TimeEntryBase note_TimeEntryObject, SqlDataReader reader, int start )
		{
			note_TimeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			note_TimeEntryObject.ID = reader.GetInt64(start + 0);
			note_TimeEntryObject.NoteID = reader.GetInt64(start + 1);
			note_TimeEntryObject.TimeEntryID = reader.GetGuid(start + 2);
			FillBaseObject(note_TimeEntryObject, reader, (start + 3));
		}

		protected void FillObject( Note_TimeEntryBase note_TimeEntryObject, SqlDataReader reader )
		{
			FillObject( note_TimeEntryObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Note_TimeEntry object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Note_TimeEntry object</returns>
		private Note_TimeEntry GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Note_TimeEntry note_TimeEntryObject= new Note_TimeEntry();
					FillObject( note_TimeEntryObject, reader );
					return note_TimeEntryObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Note_TimeEntry objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Note_TimeEntry objects</returns>
		private Note_TimeEntryList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Note_TimeEntryList list = new Note_TimeEntryList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Note_TimeEntry note_TimeEntryObject = new Note_TimeEntry();
					FillObject( note_TimeEntryObject, reader );

					list.Add( note_TimeEntryObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

