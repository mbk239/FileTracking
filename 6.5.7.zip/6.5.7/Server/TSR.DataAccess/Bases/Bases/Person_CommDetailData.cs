using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class Person_CommDetailData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Person_CommDetail;

		private const string INSERTPERSON_COMMDETAIL = "InsertPerson_CommDetail";
		private const string UPDATEPERSON_COMMDETAIL = "UpdatePerson_CommDetail";
		private const string DELETEPERSON_COMMDETAIL = "DeletePerson_CommDetail";
		private const string GETPERSON_COMMDETAILBYID = "GetPerson_CommDetailByID";
		private const string GETALLPERSON_COMMDETAIL = "GetAllPerson_CommDetail";

        #region Constructors

		public Person_CommDetailData(UserContext context) : base(context) { LOCK_Person_CommDetail = this; }
		public Person_CommDetailData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Person_CommDetail = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="person_CommDetailObject"></param>
		private void AddCommonParams( SqlCommand cmd, Person_CommDetailBase person_CommDetailObject )
		{
			AddParameter(cmd, pInt64(Person_CommDetailBase.Property_PersonID, person_CommDetailObject.PersonID));
			AddParameter(cmd, pInt64(Person_CommDetailBase.Property_CommDetailID, person_CommDetailObject.CommDetailID));
		}

        /// <summary>
        /// Inserts Person_CommDetail
        /// </summary>
        /// <param name="person_CommDetailObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Person_CommDetailBase person_CommDetailObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPERSON_COMMDETAIL );
	
				AddParameter(cmd, pInt64Out(Person_CommDetailBase.Property_ID, person_CommDetailObject.ID));
				AddCommonParams( cmd, person_CommDetailObject );
				AddBaseParametersForInsert( cmd, person_CommDetailObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					person_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Person_CommDetailBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( person_CommDetailObject, x );
			}
		}
		
        /// <summary>
        /// Updates Person_CommDetail 
        /// </summary>
        /// <param name="person_CommDetailObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Person_CommDetailBase person_CommDetailObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    Person_CommDetailBase dbObject = Get(person_CommDetailObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(person_CommDetailObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != person_CommDetailObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != person_CommDetailObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPERSON_COMMDETAIL );

				AddParameter(cmd, pInt64(Person_CommDetailBase.Property_ID, person_CommDetailObject.ID));
					AddCommonParams( cmd, person_CommDetailObject );
					AddBaseParametersForUpdate( cmd, person_CommDetailObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						person_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( person_CommDetailObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Person_CommDetail
        /// </summary>
        /// <param name="ID">ID of the Person_CommDetail object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPERSON_COMMDETAIL );
	
				AddParameters( cmd, pInt64( Person_CommDetail.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Person_CommDetail ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Person_CommDetail object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Person_CommDetail object to retrieve</param>
        /// <returns>A Person_CommDetail object, null if not found</returns>
		public Person_CommDetail Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPERSON_COMMDETAILBYID) )
			{
				AddParameters( cmd, pInt64( Person_CommDetail.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Person_CommDetail objects 
        /// </summary>
        /// <returns>A list of Person_CommDetail objects</returns>
		public Person_CommDetailList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPERSON_COMMDETAIL ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Person_CommDetail object
        /// </summary>
        /// <param name="person_CommDetailObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Person_CommDetailBase person_CommDetailObject, SqlDataReader reader, int start )
		{
			person_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			person_CommDetailObject.ID = reader.GetInt64(start + 0);
			person_CommDetailObject.PersonID = reader.GetInt64(start + 1);
			person_CommDetailObject.CommDetailID = reader.GetInt64(start + 2);
			FillBaseObject(person_CommDetailObject, reader, (start + 3));
		}

		protected void FillObject( Person_CommDetailBase person_CommDetailObject, SqlDataReader reader )
		{
			FillObject( person_CommDetailObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Person_CommDetail object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Person_CommDetail object</returns>
		private Person_CommDetail GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Person_CommDetail person_CommDetailObject= new Person_CommDetail();
					FillObject( person_CommDetailObject, reader );
					return person_CommDetailObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Person_CommDetail objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Person_CommDetail objects</returns>
		private Person_CommDetailList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Person_CommDetailList list = new Person_CommDetailList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Person_CommDetail person_CommDetailObject = new Person_CommDetail();
					FillObject( person_CommDetailObject, reader );

					list.Add( person_CommDetailObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

