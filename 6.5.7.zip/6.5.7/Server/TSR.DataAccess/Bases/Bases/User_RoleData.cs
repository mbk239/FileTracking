using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class User_RoleData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_User_Role;

		private const string INSERTUSER_ROLE = "InsertUser_Role";
		private const string UPDATEUSER_ROLE = "UpdateUser_Role";
		private const string DELETEUSER_ROLE = "DeleteUser_Role";
		private const string GETUSER_ROLEBYID = "GetUser_RoleByID";
		private const string GETALLUSER_ROLE = "GetAllUser_Role";

        #region Constructors

		public User_RoleData(UserContext context) : base(context) { LOCK_User_Role = this; }
		public User_RoleData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_User_Role = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="user_RoleObject"></param>
		private void AddCommonParams( SqlCommand cmd, User_RoleBase user_RoleObject )
		{
			AddParameter(cmd, pInt64(User_RoleBase.Property_UserID, user_RoleObject.UserID));
			AddParameter(cmd, pInt64(User_RoleBase.Property_RoleID, user_RoleObject.RoleID));
		}

        /// <summary>
        /// Inserts User_Role
        /// </summary>
        /// <param name="user_RoleObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( User_RoleBase user_RoleObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSER_ROLE );
	
				AddParameter(cmd, pInt64Out(User_RoleBase.Property_ID, user_RoleObject.ID));
				AddCommonParams( cmd, user_RoleObject );
				AddBaseParametersForInsert( cmd, user_RoleObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					user_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, User_RoleBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( user_RoleObject, x );
			}
		}
		
        /// <summary>
        /// Updates User_Role 
        /// </summary>
        /// <param name="user_RoleObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( User_RoleBase user_RoleObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    User_RoleBase dbObject = Get(user_RoleObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(user_RoleObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != user_RoleObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != user_RoleObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEUSER_ROLE );

				AddParameter(cmd, pInt64(User_RoleBase.Property_ID, user_RoleObject.ID));
					AddCommonParams( cmd, user_RoleObject );
					AddBaseParametersForUpdate( cmd, user_RoleObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						user_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( user_RoleObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes User_Role
        /// </summary>
        /// <param name="ID">ID of the User_Role object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSER_ROLE );
	
				AddParameters( cmd, pInt64( User_Role.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( User_Role ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves User_Role object using it's ID
        /// </summary>
        /// <param name="ID">The id of the User_Role object to retrieve</param>
        /// <returns>A User_Role object, null if not found</returns>
		public User_Role Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSER_ROLEBYID) )
			{
				AddParameters( cmd, pInt64( User_Role.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all User_Role objects 
        /// </summary>
        /// <returns>A list of User_Role objects</returns>
		public User_RoleList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSER_ROLE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills User_Role object
        /// </summary>
        /// <param name="user_RoleObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( User_RoleBase user_RoleObject, SqlDataReader reader, int start )
		{
			user_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			user_RoleObject.ID = reader.GetInt64(start + 0);
			user_RoleObject.UserID = reader.GetInt64(start + 1);
			user_RoleObject.RoleID = reader.GetInt64(start + 2);
			FillBaseObject(user_RoleObject, reader, (start + 3));
		}

		protected void FillObject( User_RoleBase user_RoleObject, SqlDataReader reader )
		{
			FillObject( user_RoleObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves User_Role object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>User_Role object</returns>
		private User_Role GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					User_Role user_RoleObject= new User_Role();
					FillObject( user_RoleObject, reader );
					return user_RoleObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of User_Role objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of User_Role objects</returns>
		private User_RoleList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			User_RoleList list = new User_RoleList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					User_Role user_RoleObject = new User_Role();
					FillObject( user_RoleObject, reader );

					list.Add( user_RoleObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

