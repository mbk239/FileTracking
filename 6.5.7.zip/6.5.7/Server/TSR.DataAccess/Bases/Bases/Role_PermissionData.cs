using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class Role_PermissionData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Role_Permission;

		private const string INSERTROLE_PERMISSION = "InsertRole_Permission";
		private const string UPDATEROLE_PERMISSION = "UpdateRole_Permission";
		private const string DELETEROLE_PERMISSION = "DeleteRole_Permission";
		private const string GETROLE_PERMISSIONBYID = "GetRole_PermissionByID";
		private const string GETALLROLE_PERMISSION = "GetAllRole_Permission";

        #region Constructors

		public Role_PermissionData(UserContext context) : base(context) { LOCK_Role_Permission = this; }
		public Role_PermissionData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Role_Permission = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="role_PermissionObject"></param>
		private void AddCommonParams( SqlCommand cmd, Role_PermissionBase role_PermissionObject )
		{
			AddParameter(cmd, pInt64(Role_PermissionBase.Property_RoleID, role_PermissionObject.RoleID));
			AddParameter(cmd, pInt64(Role_PermissionBase.Property_PermissionID, role_PermissionObject.PermissionID));
		}

        /// <summary>
        /// Inserts Role_Permission
        /// </summary>
        /// <param name="role_PermissionObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Role_PermissionBase role_PermissionObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTROLE_PERMISSION );
	
				AddParameter(cmd, pInt64Out(Role_PermissionBase.Property_ID, role_PermissionObject.ID));
				AddCommonParams( cmd, role_PermissionObject );
				AddBaseParametersForInsert( cmd, role_PermissionObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					role_PermissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Role_PermissionBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( role_PermissionObject, x );
			}
		}
		
        /// <summary>
        /// Updates Role_Permission 
        /// </summary>
        /// <param name="role_PermissionObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Role_PermissionBase role_PermissionObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    Role_PermissionBase dbObject = Get(role_PermissionObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(role_PermissionObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != role_PermissionObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != role_PermissionObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEROLE_PERMISSION );

				AddParameter(cmd, pInt64(Role_PermissionBase.Property_ID, role_PermissionObject.ID));
					AddCommonParams( cmd, role_PermissionObject );
					AddBaseParametersForUpdate( cmd, role_PermissionObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						role_PermissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( role_PermissionObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Role_Permission
        /// </summary>
        /// <param name="ID">ID of the Role_Permission object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEROLE_PERMISSION );
	
				AddParameters( cmd, pInt64( Role_Permission.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Role_Permission ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Role_Permission object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Role_Permission object to retrieve</param>
        /// <returns>A Role_Permission object, null if not found</returns>
		public Role_Permission Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETROLE_PERMISSIONBYID) )
			{
				AddParameters( cmd, pInt64( Role_Permission.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Role_Permission objects 
        /// </summary>
        /// <returns>A list of Role_Permission objects</returns>
		public Role_PermissionList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLROLE_PERMISSION ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Role_Permission object
        /// </summary>
        /// <param name="role_PermissionObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Role_PermissionBase role_PermissionObject, SqlDataReader reader, int start )
		{
			role_PermissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			role_PermissionObject.ID = reader.GetInt64(start + 0);
			role_PermissionObject.RoleID = reader.GetInt64(start + 1);
			role_PermissionObject.PermissionID = reader.GetInt64(start + 2);
			FillBaseObject(role_PermissionObject, reader, (start + 3));
		}

		protected void FillObject( Role_PermissionBase role_PermissionObject, SqlDataReader reader )
		{
			FillObject( role_PermissionObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Role_Permission object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Role_Permission object</returns>
		private Role_Permission GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Role_Permission role_PermissionObject= new Role_Permission();
					FillObject( role_PermissionObject, reader );
					return role_PermissionObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Role_Permission objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Role_Permission objects</returns>
		private Role_PermissionList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Role_PermissionList list = new Role_PermissionList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Role_Permission role_PermissionObject = new Role_Permission();
					FillObject( role_PermissionObject, reader );

					list.Add( role_PermissionObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

