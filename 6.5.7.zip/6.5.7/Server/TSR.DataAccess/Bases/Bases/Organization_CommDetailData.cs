using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class Organization_CommDetailData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Organization_CommDetail;

		private const string INSERTORGANIZATION_COMMDETAIL = "InsertOrganization_CommDetail";
		private const string UPDATEORGANIZATION_COMMDETAIL = "UpdateOrganization_CommDetail";
		private const string DELETEORGANIZATION_COMMDETAIL = "DeleteOrganization_CommDetail";
		private const string GETORGANIZATION_COMMDETAILBYID = "GetOrganization_CommDetailByID";
		private const string GETALLORGANIZATION_COMMDETAIL = "GetAllOrganization_CommDetail";

        #region Constructors

		public Organization_CommDetailData(UserContext context) : base(context) { LOCK_Organization_CommDetail = this; }
		public Organization_CommDetailData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Organization_CommDetail = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organization_CommDetailObject"></param>
		private void AddCommonParams( SqlCommand cmd, Organization_CommDetailBase organization_CommDetailObject )
		{
			AddParameter(cmd, pInt64(Organization_CommDetailBase.Property_OrganizationID, organization_CommDetailObject.OrganizationID));
			AddParameter(cmd, pInt64(Organization_CommDetailBase.Property_CommDetailID, organization_CommDetailObject.CommDetailID));
		}

        /// <summary>
        /// Inserts Organization_CommDetail
        /// </summary>
        /// <param name="organization_CommDetailObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Organization_CommDetailBase organization_CommDetailObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTORGANIZATION_COMMDETAIL );
	
				AddParameter(cmd, pInt64Out(Organization_CommDetailBase.Property_ID, organization_CommDetailObject.ID));
				AddCommonParams( cmd, organization_CommDetailObject );
				AddBaseParametersForInsert( cmd, organization_CommDetailObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					organization_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Organization_CommDetailBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( organization_CommDetailObject, x );
			}
		}
		
        /// <summary>
        /// Updates Organization_CommDetail 
        /// </summary>
        /// <param name="organization_CommDetailObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Organization_CommDetailBase organization_CommDetailObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    Organization_CommDetailBase dbObject = Get(organization_CommDetailObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(organization_CommDetailObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != organization_CommDetailObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != organization_CommDetailObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEORGANIZATION_COMMDETAIL );

				AddParameter(cmd, pInt64(Organization_CommDetailBase.Property_ID, organization_CommDetailObject.ID));
					AddCommonParams( cmd, organization_CommDetailObject );
					AddBaseParametersForUpdate( cmd, organization_CommDetailObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						organization_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( organization_CommDetailObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Organization_CommDetail
        /// </summary>
        /// <param name="ID">ID of the Organization_CommDetail object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEORGANIZATION_COMMDETAIL );
	
				AddParameters( cmd, pInt64( Organization_CommDetail.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Organization_CommDetail ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Organization_CommDetail object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Organization_CommDetail object to retrieve</param>
        /// <returns>A Organization_CommDetail object, null if not found</returns>
		public Organization_CommDetail Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETORGANIZATION_COMMDETAILBYID) )
			{
				AddParameters( cmd, pInt64( Organization_CommDetail.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Organization_CommDetail objects 
        /// </summary>
        /// <returns>A list of Organization_CommDetail objects</returns>
		public Organization_CommDetailList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLORGANIZATION_COMMDETAIL ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Organization_CommDetail object
        /// </summary>
        /// <param name="organization_CommDetailObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Organization_CommDetailBase organization_CommDetailObject, SqlDataReader reader, int start )
		{
			organization_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			organization_CommDetailObject.ID = reader.GetInt64(start + 0);
			organization_CommDetailObject.OrganizationID = reader.GetInt64(start + 1);
			organization_CommDetailObject.CommDetailID = reader.GetInt64(start + 2);
			FillBaseObject(organization_CommDetailObject, reader, (start + 3));
		}

		protected void FillObject( Organization_CommDetailBase organization_CommDetailObject, SqlDataReader reader )
		{
			FillObject( organization_CommDetailObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Organization_CommDetail object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Organization_CommDetail object</returns>
		private Organization_CommDetail GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Organization_CommDetail organization_CommDetailObject= new Organization_CommDetail();
					FillObject( organization_CommDetailObject, reader );
					return organization_CommDetailObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Organization_CommDetail objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Organization_CommDetail objects</returns>
		private Organization_CommDetailList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Organization_CommDetailList list = new Organization_CommDetailList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Organization_CommDetail organization_CommDetailObject = new Organization_CommDetail();
					FillObject( organization_CommDetailObject, reader );

					list.Add( organization_CommDetailObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

