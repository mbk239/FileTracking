using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class CityData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_City;

		private const string INSERTCITY = "InsertCity";
		private const string UPDATECITY = "UpdateCity";
		private const string DELETECITY = "DeleteCity";
		private const string GETCITYBYID = "GetCityByID";
		private const string GETALLCITY = "GetAllCity";

        #region Constructors

		public CityData(UserContext context) : base(context) { LOCK_City = this; }
		public CityData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_City = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="cityObject"></param>
		private void AddCommonParams( SqlCommand cmd, CityBase cityObject )
		{
			AddParameter(cmd, pVarChar(CityBase.Property_Name, 255, cityObject.Name));
		}

        /// <summary>
        /// Inserts City
        /// </summary>
        /// <param name="cityObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( CityBase cityObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTCITY );
	
				AddParameter(cmd, pInt64Out(CityBase.Property_ID, cityObject.ID));
				AddCommonParams( cmd, cityObject );
				AddBaseParametersForInsert( cmd, cityObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					cityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, CityBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( cityObject, x );
			}
		}
		
        /// <summary>
        /// Updates City 
        /// </summary>
        /// <param name="cityObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( CityBase cityObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    CityBase dbObject = Get(cityObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(cityObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != cityObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != cityObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATECITY );

				AddParameter(cmd, pInt64(CityBase.Property_ID, cityObject.ID));
					AddCommonParams( cmd, cityObject );
					AddBaseParametersForUpdate( cmd, cityObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						cityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( cityObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes City
        /// </summary>
        /// <param name="ID">ID of the City object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETECITY );
	
				AddParameters( cmd, pInt64( City.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( City ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves City object using it's ID
        /// </summary>
        /// <param name="ID">The id of the City object to retrieve</param>
        /// <returns>A City object, null if not found</returns>
		public City Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETCITYBYID) )
			{
				AddParameters( cmd, pInt64( City.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all City objects 
        /// </summary>
        /// <returns>A list of City objects</returns>
		public CityList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLCITY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills City object
        /// </summary>
        /// <param name="cityObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( CityBase cityObject, SqlDataReader reader, int start )
		{
			cityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			cityObject.ID = reader.GetInt64(start + 0);
			cityObject.Name = reader.GetString(start + 1);
			FillBaseObject(cityObject, reader, (start + 2));
		}

		protected void FillObject( CityBase cityObject, SqlDataReader reader )
		{
			FillObject( cityObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves City object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>City object</returns>
		private City GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					City cityObject= new City();
					FillObject( cityObject, reader );
					return cityObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of City objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of City objects</returns>
		private CityList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			CityList list = new CityList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					City cityObject = new City();
					FillObject( cityObject, reader );

					list.Add( cityObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

