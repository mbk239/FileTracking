using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Base;

namespace TSR.DataAccess
{
	public partial class LanguageResourcesData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_LanguageResources;

		private const string INSERTLANGUAGERESOURCES = "InsertLanguageResources";
		private const string UPDATELANGUAGERESOURCES = "UpdateLanguageResources";
		private const string DELETELANGUAGERESOURCES = "DeleteLanguageResources";
		private const string GETLANGUAGERESOURCESBYID = "GetLanguageResourcesByID";
		private const string GETALLLANGUAGERESOURCES = "GetAllLanguageResources";

        #region Constructors

		public LanguageResourcesData(UserContext context) : base(context) { LOCK_LanguageResources = this; }
		public LanguageResourcesData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_LanguageResources = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="languageResourcesObject"></param>
		private void AddCommonParams( SqlCommand cmd, LanguageResourcesBase languageResourcesObject )
		{
			AddParameter(cmd, pVarChar(LanguageResourcesBase.Property_LanguageID, 50, languageResourcesObject.LanguageID));
			AddParameter(cmd, pText(LanguageResourcesBase.Property_ResourceKey, languageResourcesObject.ResourceKey));
			AddParameter(cmd, pText(LanguageResourcesBase.Property_ResourceValue, languageResourcesObject.ResourceValue));
		}

        /// <summary>
        /// Inserts LanguageResources
        /// </summary>
        /// <param name="languageResourcesObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( LanguageResourcesBase languageResourcesObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTLANGUAGERESOURCES );
	
				AddParameter(cmd, pInt64Out(LanguageResourcesBase.Property_ID, languageResourcesObject.ID));
				AddCommonParams( cmd, languageResourcesObject );
				AddBaseParametersForInsert( cmd, languageResourcesObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					languageResourcesObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, LanguageResourcesBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( languageResourcesObject, x );
			}
		}
		
        /// <summary>
        /// Updates LanguageResources 
        /// </summary>
        /// <param name="languageResourcesObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( LanguageResourcesBase languageResourcesObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    LanguageResourcesBase dbObject = Get(languageResourcesObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(languageResourcesObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != languageResourcesObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != languageResourcesObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

					SqlCommand cmd = GetSPCommand( UPDATELANGUAGERESOURCES );

				AddParameter(cmd, pInt64(LanguageResourcesBase.Property_ID, languageResourcesObject.ID));
					AddCommonParams( cmd, languageResourcesObject );
					AddBaseParametersForUpdate( cmd, languageResourcesObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						languageResourcesObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( languageResourcesObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes LanguageResources
        /// </summary>
        /// <param name="ID">ID of the LanguageResources object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETELANGUAGERESOURCES );
	
				AddParameters( cmd, pInt64( LanguageResources.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( LanguageResources ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves LanguageResources object using it's ID
        /// </summary>
        /// <param name="ID">The id of the LanguageResources object to retrieve</param>
        /// <returns>A LanguageResources object, null if not found</returns>
		public LanguageResources Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETLANGUAGERESOURCESBYID) )
			{
				AddParameters( cmd, pInt64( LanguageResources.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all LanguageResources objects 
        /// </summary>
        /// <returns>A list of LanguageResources objects</returns>
		public LanguageResourcesList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLLANGUAGERESOURCES ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills LanguageResources object
        /// </summary>
        /// <param name="languageResourcesObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( LanguageResourcesBase languageResourcesObject, SqlDataReader reader, int start )
		{
			languageResourcesObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			languageResourcesObject.ID = reader.GetInt64(start + 0);
			languageResourcesObject.LanguageID = reader.GetString(start + 1);
			languageResourcesObject.ResourceKey = reader.GetString(start + 2);
			languageResourcesObject.ResourceValue = reader.GetString(start + 3);
			FillBaseObject(languageResourcesObject, reader, (start + 4));
		}

		protected void FillObject( LanguageResourcesBase languageResourcesObject, SqlDataReader reader )
		{
			FillObject( languageResourcesObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves LanguageResources object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>LanguageResources object</returns>
		private LanguageResources GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					LanguageResources languageResourcesObject= new LanguageResources();
					FillObject( languageResourcesObject, reader );
					return languageResourcesObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of LanguageResources objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of LanguageResources objects</returns>
		private LanguageResourcesList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			LanguageResourcesList list = new LanguageResourcesList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					LanguageResources languageResourcesObject = new LanguageResources();
					FillObject( languageResourcesObject, reader );

					list.Add( languageResourcesObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

