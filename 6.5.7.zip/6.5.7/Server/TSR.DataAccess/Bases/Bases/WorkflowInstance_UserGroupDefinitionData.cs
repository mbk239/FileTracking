using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class WorkflowInstance_UserGroupDefinitionData : BaseDataAccess
	{
		private const string INSERTWORKFLOWINSTANCE_USERGROUPDEFINITION = "InsertWorkflowInstance_UserGroupDefinition";
		private const string UPDATEWORKFLOWINSTANCE_USERGROUPDEFINITION = "UpdateWorkflowInstance_UserGroupDefinition";
		private const string DELETEWORKFLOWINSTANCE_USERGROUPDEFINITION = "DeleteWorkflowInstance_UserGroupDefinition";
		private const string GETWORKFLOWINSTANCE_USERGROUPDEFINITIONBYID = "GetWorkflowInstance_UserGroupDefinitionByID";
		private const string GETALLWORKFLOWINSTANCE_USERGROUPDEFINITION = "GetAllWorkflowInstance_UserGroupDefinition";

        #region Constructors

		public WorkflowInstance_UserGroupDefinitionData(UserContext context) : base(context) { }
		public WorkflowInstance_UserGroupDefinitionData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="workflowInstance_UserGroupDefinitionObject"></param>
		private void AddCommonParams( SqlCommand cmd, WorkflowInstance_UserGroupDefinitionBase workflowInstance_UserGroupDefinitionObject )
		{
			AddParameter(cmd, pInt64(WorkflowInstance_UserGroupDefinitionBase.Property_WorkflowInstanceID, workflowInstance_UserGroupDefinitionObject.WorkflowInstanceID));
			AddParameter(cmd, pInt64(WorkflowInstance_UserGroupDefinitionBase.Property_UserGroupID, workflowInstance_UserGroupDefinitionObject.UserGroupID));
			AddParameter(cmd, pInt64(WorkflowInstance_UserGroupDefinitionBase.Property_UserID, workflowInstance_UserGroupDefinitionObject.UserID));
		}

        /// <summary>
        /// Inserts WorkflowInstance_UserGroupDefinition
        /// </summary>
        /// <param name="workflowInstance_UserGroupDefinitionObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( WorkflowInstance_UserGroupDefinitionBase workflowInstance_UserGroupDefinitionObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTWORKFLOWINSTANCE_USERGROUPDEFINITION );
	
				AddParameter(cmd, pInt64Out(WorkflowInstance_UserGroupDefinitionBase.Property_ID, workflowInstance_UserGroupDefinitionObject.ID));
				AddCommonParams( cmd, workflowInstance_UserGroupDefinitionObject );
				AddBaseParametersForInsert( cmd, workflowInstance_UserGroupDefinitionObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					workflowInstance_UserGroupDefinitionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, WorkflowInstance_UserGroupDefinitionBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( workflowInstance_UserGroupDefinitionObject, x );
			}
		}
		
        /// <summary>
        /// Updates WorkflowInstance_UserGroupDefinition 
        /// </summary>
        /// <param name="workflowInstance_UserGroupDefinitionObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( WorkflowInstance_UserGroupDefinitionBase workflowInstance_UserGroupDefinitionObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEWORKFLOWINSTANCE_USERGROUPDEFINITION );

				AddParameter(cmd, pInt64(WorkflowInstance_UserGroupDefinitionBase.Property_ID, workflowInstance_UserGroupDefinitionObject.ID));
				AddCommonParams( cmd, workflowInstance_UserGroupDefinitionObject );
				AddBaseParametersForUpdate( cmd, workflowInstance_UserGroupDefinitionObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					workflowInstance_UserGroupDefinitionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( workflowInstance_UserGroupDefinitionObject, x );
			}
			
		}

        /// <summary>
        /// Deletes WorkflowInstance_UserGroupDefinition
        /// </summary>
        /// <param name="ID">ID of the WorkflowInstance_UserGroupDefinition object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEWORKFLOWINSTANCE_USERGROUPDEFINITION );
	
				AddParameters( cmd, pInt64( WorkflowInstance_UserGroupDefinition.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( WorkflowInstance_UserGroupDefinition ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves WorkflowInstance_UserGroupDefinition object using it's ID
        /// </summary>
        /// <param name="ID">The id of the WorkflowInstance_UserGroupDefinition object to retrieve</param>
        /// <returns>A WorkflowInstance_UserGroupDefinition object, null if not found</returns>
		public WorkflowInstance_UserGroupDefinition Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETWORKFLOWINSTANCE_USERGROUPDEFINITIONBYID) )
			{
				AddParameters( cmd, pInt64( WorkflowInstance_UserGroupDefinition.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all WorkflowInstance_UserGroupDefinition objects 
        /// </summary>
        /// <returns>A list of WorkflowInstance_UserGroupDefinition objects</returns>
		public WorkflowInstance_UserGroupDefinitionList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLWORKFLOWINSTANCE_USERGROUPDEFINITION ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills WorkflowInstance_UserGroupDefinition object
        /// </summary>
        /// <param name="workflowInstance_UserGroupDefinitionObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( WorkflowInstance_UserGroupDefinitionBase workflowInstance_UserGroupDefinitionObject, SqlDataReader reader, int start )
		{
			workflowInstance_UserGroupDefinitionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			workflowInstance_UserGroupDefinitionObject.ID = reader.GetInt64(start + 0);
			workflowInstance_UserGroupDefinitionObject.WorkflowInstanceID = reader.GetInt64(start + 1);
			workflowInstance_UserGroupDefinitionObject.UserGroupID = reader.GetInt64(start + 2);
			workflowInstance_UserGroupDefinitionObject.UserID = reader.GetInt64(start + 3);
			FillBaseObject(workflowInstance_UserGroupDefinitionObject, reader, (start + 4));
		}

		protected void FillObject( WorkflowInstance_UserGroupDefinitionBase workflowInstance_UserGroupDefinitionObject, SqlDataReader reader )
		{
			FillObject( workflowInstance_UserGroupDefinitionObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves WorkflowInstance_UserGroupDefinition object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>WorkflowInstance_UserGroupDefinition object</returns>
		private WorkflowInstance_UserGroupDefinition GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					WorkflowInstance_UserGroupDefinition workflowInstance_UserGroupDefinitionObject= new WorkflowInstance_UserGroupDefinition();
					FillObject( workflowInstance_UserGroupDefinitionObject, reader );
					return workflowInstance_UserGroupDefinitionObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of WorkflowInstance_UserGroupDefinition objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of WorkflowInstance_UserGroupDefinition objects</returns>
		private WorkflowInstance_UserGroupDefinitionList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			WorkflowInstance_UserGroupDefinitionList list = new WorkflowInstance_UserGroupDefinitionList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					WorkflowInstance_UserGroupDefinition workflowInstance_UserGroupDefinitionObject = new WorkflowInstance_UserGroupDefinition();
					FillObject( workflowInstance_UserGroupDefinitionObject, reader );

					list.Add( workflowInstance_UserGroupDefinitionObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

