using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class TimeEntry_NoteData : BaseDataAccess
	{
		private const string INSERTTIMEENTRY_NOTE = "InsertTimeEntry_Note";
		private const string UPDATETIMEENTRY_NOTE = "UpdateTimeEntry_Note";
		private const string DELETETIMEENTRY_NOTE = "DeleteTimeEntry_Note";
		private const string GETTIMEENTRY_NOTEBYID = "GetTimeEntry_NoteByID";
		private const string GETALLTIMEENTRY_NOTE = "GetAllTimeEntry_Note";

        #region Constructors

		public TimeEntry_NoteData(UserContext context) : base(context) { }
		public TimeEntry_NoteData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="timeEntry_NoteObject"></param>
		private void AddCommonParams( SqlCommand cmd, TimeEntry_NoteBase timeEntry_NoteObject )
		{
			AddParameter(cmd, pGuid(TimeEntry_NoteBase.Property_TimeEntryID, timeEntry_NoteObject.TimeEntryID));
			AddParameter(cmd, pInt64(TimeEntry_NoteBase.Property_NoteID, timeEntry_NoteObject.NoteID));
		}

        /// <summary>
        /// Inserts TimeEntry_Note
        /// </summary>
        /// <param name="timeEntry_NoteObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( TimeEntry_NoteBase timeEntry_NoteObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTTIMEENTRY_NOTE );
	
				AddParameter(cmd, pInt64Out(TimeEntry_NoteBase.Property_ID, timeEntry_NoteObject.ID));
				AddCommonParams( cmd, timeEntry_NoteObject );
				AddBaseParametersForInsert( cmd, timeEntry_NoteObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					timeEntry_NoteObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, TimeEntry_NoteBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( timeEntry_NoteObject, x );
			}
		}
		
        /// <summary>
        /// Updates TimeEntry_Note 
        /// </summary>
        /// <param name="timeEntry_NoteObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( TimeEntry_NoteBase timeEntry_NoteObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATETIMEENTRY_NOTE );

				AddParameter(cmd, pInt64(TimeEntry_NoteBase.Property_ID, timeEntry_NoteObject.ID));
				AddCommonParams( cmd, timeEntry_NoteObject );
				AddBaseParametersForUpdate( cmd, timeEntry_NoteObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					timeEntry_NoteObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( timeEntry_NoteObject, x );
			}
			
		}

        /// <summary>
        /// Deletes TimeEntry_Note
        /// </summary>
        /// <param name="ID">ID of the TimeEntry_Note object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETETIMEENTRY_NOTE );
	
				AddParameters( cmd, pInt64( TimeEntry_Note.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( TimeEntry_Note ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves TimeEntry_Note object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeEntry_Note object to retrieve</param>
        /// <returns>A TimeEntry_Note object, null if not found</returns>
		public TimeEntry_Note Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETTIMEENTRY_NOTEBYID) )
			{
				AddParameters( cmd, pInt64( TimeEntry_Note.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all TimeEntry_Note objects 
        /// </summary>
        /// <returns>A list of TimeEntry_Note objects</returns>
		public TimeEntry_NoteList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLTIMEENTRY_NOTE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills TimeEntry_Note object
        /// </summary>
        /// <param name="timeEntry_NoteObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( TimeEntry_NoteBase timeEntry_NoteObject, SqlDataReader reader, int start )
		{
			timeEntry_NoteObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			timeEntry_NoteObject.ID = reader.GetInt64(start + 0);
			timeEntry_NoteObject.TimeEntryID = reader.GetGuid(start + 1);
			timeEntry_NoteObject.NoteID = reader.GetInt64(start + 2);
			FillBaseObject(timeEntry_NoteObject, reader, (start + 3));
		}

		protected void FillObject( TimeEntry_NoteBase timeEntry_NoteObject, SqlDataReader reader )
		{
			FillObject( timeEntry_NoteObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves TimeEntry_Note object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>TimeEntry_Note object</returns>
		private TimeEntry_Note GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					TimeEntry_Note timeEntry_NoteObject= new TimeEntry_Note();
					FillObject( timeEntry_NoteObject, reader );
					return timeEntry_NoteObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of TimeEntry_Note objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of TimeEntry_Note objects</returns>
		private TimeEntry_NoteList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			TimeEntry_NoteList list = new TimeEntry_NoteList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					TimeEntry_Note timeEntry_NoteObject = new TimeEntry_Note();
					FillObject( timeEntry_NoteObject, reader );

					list.Add( timeEntry_NoteObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

