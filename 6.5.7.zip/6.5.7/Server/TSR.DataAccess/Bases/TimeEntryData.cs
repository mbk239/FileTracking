using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class TimeEntryData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_TimeEntry;

		private const string INSERTTIMEENTRY = "InsertTimeEntry";
		private const string UPDATETIMEENTRY = "UpdateTimeEntry";
		private const string DELETETIMEENTRY = "DeleteTimeEntry";
		private const string GETTIMEENTRYBYID = "GetTimeEntryByID";
		private const string GETALLTIMEENTRY = "GetAllTimeEntry";
        private const string GETDELETEDTIMEENTRYBYID = "GetDeletedTimeEntryByID";
        private const string GETTIMEENTRYTYPE = "GetTimeEntryType";
        private const string APPROVEREJECTTIMEENTRIESFORUSER = "ApproveRejectTimeEntriesForUser";

        #region Constructors

		public TimeEntryData(UserContext context) : base(context) { LOCK_TimeEntry = this; }
		public TimeEntryData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_TimeEntry = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="timeEntryObject"></param>
		private void AddCommonParams( SqlCommand cmd, TimeEntryBase timeEntryObject )
		{
			AddParameter(cmd, pGuid(TimeEntryBase.Property_ID, timeEntryObject.ID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_UserID, timeEntryObject.UserID));
			//AddParameter(cmd, pInt64(TimeEntryBase.Property_TimeSheetID, timeEntryObject.TimeSheetID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_OrganizationID, timeEntryObject.OrganizationID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_ProjectID, timeEntryObject.ProjectID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_ActivityID, timeEntryObject.ActivityID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_TaskID, timeEntryObject.TaskID));
			AddParameter(cmd, pInt64(TimeEntryBase.Property_ContactID, timeEntryObject.ContactID));
			AddParameter(cmd, pDateTime(TimeEntryBase.Property_StartTimeStamp, timeEntryObject.StartTimeStamp));
			AddParameter(cmd, pDateTime(TimeEntryBase.Property_EndTimeStamp, timeEntryObject.EndTimeStamp));
			AddParameter(cmd, pInt32(TimeEntryBase.Property_Status, (int)timeEntryObject.Status));
			AddParameter(cmd, pNText(TimeEntryBase.Property_Subject, timeEntryObject.Subject));
			AddParameter(cmd, pNText(TimeEntryBase.Property_Body, timeEntryObject.Body));
            AddParameter(cmd, pNText(TimeEntryBase.Property_Location, timeEntryObject.Location));
            AddParameter(cmd, pInt64(TimeEntryBase.Property_SubmittedBy, timeEntryObject.SubmittedBy));
            AddParameter(cmd, pNText(TimeEntryBase.Property_Message, timeEntryObject.Message));
            AddParameter(cmd, pInt64(TimeEntryBase.Property_Revision, timeEntryObject.Revision));
            AddParameter(cmd,pBit(TimeEntryBase.Property_IsRecurring,timeEntryObject.IsRecurring));
            
            //version 6.2.1
            if (timeEntryObject.LocationID > 0)
                AddParameter(cmd, pInt64(TimeEntryBase.Property_LocationID, timeEntryObject.LocationID));
            else
                AddParameter(cmd, pInt64(TimeEntryBase.Property_LocationID, null));

            AddParameter(cmd, pBit(TimeEntryBase.Property_IsOutOfOffice, timeEntryObject.IsOutOfOffice));
		}

        /// <summary>
        /// Inserts TimeEntry
        /// </summary>
        /// <param name="timeEntryObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( TimeEntryBase timeEntryObject )
		{
			try
			{                
				SqlCommand cmd = GetSPCommand( INSERTTIMEENTRY );

				AddCommonParams( cmd, timeEntryObject );
                AddParameter(cmd, pBit(TimeEntryBase.Property_IsCreatedViaWeb, timeEntryObject.IsCreatedViaWeb));
				AddBaseParametersForInsert( cmd, timeEntryObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( timeEntryObject, x );
			}
		}
		
        /// <summary>
        /// Updates TimeEntry 
        /// </summary>
        /// <param name="timeEntryObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( TimeEntryBase timeEntryObject)
		{
            lock (LOCK_TimeEntry)
            {
				try
				{
                    TimeEntryBase dbObject = Get(timeEntryObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(timeEntryObject, null);
                    else if ((dbObject.ModifiedTimeStamp.ToString() != timeEntryObject.ModifiedTimeStamp.ToString()) && (dbObject.Status != StatusEnum.Rejected)) //(dbObject.ModifiedTimeStamp != timeEntryObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(timeEntryObject, null);
                    //check revision before updating data
                    else if (dbObject.Revision.HasValue && ((timeEntryObject.Revision.Value -1) < dbObject.Revision.Value))
                    {
                        throw new Framework.Exceptions.DataIntegrityFailedException(timeEntryObject, null);
                    }

                    dbObject.CloneBase(timeEntryObject);

                    SqlCommand cmd = GetSPCommand( UPDATETIMEENTRY );

					AddCommonParams( cmd, timeEntryObject );
					AddBaseParametersForUpdate( cmd, timeEntryObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( timeEntryObject, x );
				}
			}
		}

        public long ApproveRejectTimeEntries(ApprovalSummary appSumObject, WFAction action)
        {
            lock (LOCK_TimeEntry)
            {
                try
                {
                    SqlCommand cmd = GetSPCommand(APPROVEREJECTTIMEENTRIESFORUSER);

                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ApproverUserID, UserContext.UserID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_OrganizationID, appSumObject.OrganizationID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ProjectID, appSumObject.ProjectID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ActivityID, appSumObject.ActivityID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_UserID, appSumObject.UserID));
                    AddParameters(cmd, pDateTime(ApprovalSummary.Property_StartTimeStamp, appSumObject.StartTimeStamp));
                    AddParameters(cmd, pDateTime(ApprovalSummary.Property_EndTimeStamp, appSumObject.EndTimeStamp));
                    StatusEnum status = (action == WFAction.Approve) ? StatusEnum.Approved : StatusEnum.Rejected;
                    AddParameters(cmd, pInt32(ApprovalSummary.Property_Status, (int)status));
                    AddParameters(cmd, pBool(ApprovalSummary.Property_ShowZeroHour, appSumObject.ShowZeroHour));

                    long result = UpdateRecord(cmd);
                    return result;
                }
                catch (SqlException x)
                {
                    throw x;
                }
            }
        }

        //Added by tsrdev1
        //Added datetime 26/10/2010

        /// <summary>
        /// Overwrite TimeEntry 
        /// </summary>
        /// <param name="timeEntryObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Overwrite(TimeEntryBase timeEntryObject)
        {
            lock (LOCK_TimeEntry)
            {
                try
                {
                    TimeEntryBase dbObject = Get(timeEntryObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(timeEntryObject, null);                    

                    SqlCommand cmd = GetSPCommand(UPDATETIMEENTRY);


                    AddCommonParams(cmd, timeEntryObject);
                    AddBaseParametersForUpdate(cmd, timeEntryObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(timeEntryObject, x);
                }
            }
        }
        /// <summary>
        /// Deletes TimeEntry
        /// </summary>
        /// <param name="ID">ID of the TimeEntry object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( Guid ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETETIMEENTRY );
	
				AddParameters( cmd, pGuid( TimeEntry.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( TimeEntry ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves TimeEntry object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeEntry object to retrieve</param>
        /// <returns>A TimeEntry object, null if not found</returns>
		public TimeEntry Get( Guid ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETTIMEENTRYBYID) )
			{
				AddParameters( cmd, pGuid( TimeEntry.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        //added by tsrdev2
        /// <summary>
        /// Retrieves Deleted TimeEntry object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeEntry object to retrieve</param>
        /// <returns>A TimeEntry object, null if not found</returns>
        public TimeEntry GetDeletedTimeEntry(Guid ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDTIMEENTRYBYID))
            {
                AddParameters(cmd, pGuid(TimeEntry.Property_ID, ID));

                return GetObject(cmd);
            }
        }
        //added by tsrdev2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="orgID"></param>
        /// <param name="proID"></param>
        /// <param name="contID"></param>
        /// <returns></returns>
        public long GetTimeEntryType(long userID, long orgID, long proID, long actID, long contID)
        {
            using (SqlCommand cmd = GetSPCommand(GETTIMEENTRYTYPE))
            {
                AddParameters(cmd, pInt64(TimeEntry.Property_UserID, userID));
                AddParameters(cmd, pInt64(TimeEntry.Property_OrganizationID, orgID));
                AddParameters(cmd, pInt64(TimeEntry.Property_ProjectID, proID));
                AddParameters(cmd, pInt64(TimeEntry.Property_ActivityID, actID));
                AddParameters(cmd, pInt64(TimeEntry.Property_ContactID, contID));
                AddReturnParameter(cmd);
                ExecuteCommand(cmd);
                return GetReturnParameter(cmd);
            }
        }

        /// <summary>
        /// Retrieves all TimeEntry objects 
        /// </summary>
        /// <returns>A list of TimeEntry objects</returns>
		public TimeEntryList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLTIMEENTRY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills TimeEntry object
        /// </summary>
        /// <param name="timeEntryObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( TimeEntry timeEntryObject, SqlDataReader reader, int start )
		{
			timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			timeEntryObject.ID = reader.GetGuid(start + 0);
			timeEntryObject.UserID = reader.GetInt64(start + 1);
            //timeEntryObject.TimeSheetID = reader.GetInt64(start + 2);
            timeEntryObject.OrganizationID = reader.GetInt64(start + 2);
            timeEntryObject.ProjectID = reader.GetInt64(start + 3);
            timeEntryObject.ActivityID = reader.GetInt64(start + 4);            
            if (!reader.IsDBNull(start + 5)) timeEntryObject.TaskID = reader.GetInt64(start + 5);
            if (!reader.IsDBNull(start + 6)) timeEntryObject.ContactID = reader.GetInt64(start + 6);
            timeEntryObject.StartTimeStamp = reader.GetDateTime(start + 7);
            timeEntryObject.EndTimeStamp = reader.GetDateTime(start + 8);
            
            TimeSpan durationEntry = timeEntryObject.EndTimeStamp - timeEntryObject.StartTimeStamp;
            timeEntryObject.Duration = ((int)(durationEntry.TotalMinutes / 60)).ToString() 
                    + ":" + (durationEntry.Minutes > 9 ? durationEntry.Minutes.ToString() : ("0" + durationEntry.Minutes.ToString()));

            timeEntryObject.Status = (StatusEnum)reader.GetInt32(start + 9);
            if (!reader.IsDBNull(start + 10)) timeEntryObject.Subject = ReverseToHTMLCode(reader.GetString(start + 10));
            if (!reader.IsDBNull(start + 11)) timeEntryObject.Body = ReverseToHTMLCode(reader.GetString(start + 11));
            FillBaseObject(timeEntryObject, reader, (start + 12));

            if (timeEntryObject.CustomProperties["Location"] != null && !(timeEntryObject.CustomProperties["Location"] == System.DBNull.Value))
                timeEntryObject.Location = ReverseToHTMLCode(timeEntryObject.CustomProperties["Location"].ToString());           
            if (timeEntryObject.CustomProperties["SubmittedBy"] != null)
                if(timeEntryObject.CustomProperties["SubmittedBy"] != System.DBNull.Value)
                    timeEntryObject.SubmittedBy = Int64.Parse(timeEntryObject.CustomProperties["SubmittedBy"].ToString());
            if (timeEntryObject.CustomProperties["Message"] != null)
                if (timeEntryObject.CustomProperties["Message"] != System.DBNull.Value)
                    timeEntryObject.Message = ReverseToHTMLCode(timeEntryObject.CustomProperties["Message"].ToString());
            if (timeEntryObject.CustomProperties["Revision"] != null)
                if (timeEntryObject.CustomProperties["Revision"] != System.DBNull.Value)
                    timeEntryObject.Revision = Int64.Parse(timeEntryObject.CustomProperties["Revision"].ToString());
            if (timeEntryObject.CustomProperties["IsRecurring"] != null)
                if(timeEntryObject.CustomProperties["IsRecurring"] != System.DBNull.Value)
                    timeEntryObject.IsRecurring = Convert.ToBoolean(timeEntryObject.CustomProperties["IsRecurring"]);
            if (timeEntryObject.CustomProperties["OrganizationName"] != null)
                if (timeEntryObject.CustomProperties["OrganizationName"] != System.DBNull.Value)
                    timeEntryObject.OrganizationName = ReverseToHTMLCode(timeEntryObject.CustomProperties["OrganizationName"].ToString());
            if (timeEntryObject.CustomProperties["ProjectName"] != null)
                if (timeEntryObject.CustomProperties["ProjectName"] != System.DBNull.Value)
                    timeEntryObject.ProjectName = ReverseToHTMLCode(timeEntryObject.CustomProperties["ProjectName"].ToString());
            if (timeEntryObject.CustomProperties["ActivityName"] != null)
                if (timeEntryObject.CustomProperties["ActivityName"] != System.DBNull.Value)
                    timeEntryObject.ActivityName = ReverseToHTMLCode(timeEntryObject.CustomProperties["ActivityName"].ToString());
            if (timeEntryObject.CustomProperties["SubmitterName"] != null)
                if (timeEntryObject.CustomProperties["SubmitterName"] != System.DBNull.Value)
                    timeEntryObject.SubmitterName = ReverseToHTMLCode(timeEntryObject.CustomProperties["SubmitterName"].ToString());
            if (timeEntryObject.CustomProperties[TimeEntry.Property_LocationID] != null)
                if (timeEntryObject.CustomProperties[TimeEntry.Property_LocationID] != System.DBNull.Value)
                    timeEntryObject.LocationID = Int64.Parse(timeEntryObject.CustomProperties["LocationID"].ToString());

            if (timeEntryObject.CustomProperties[TimeEntry.Property_IsOutOfOffice] != null)
                if (timeEntryObject.CustomProperties[TimeEntry.Property_IsOutOfOffice] != System.DBNull.Value)
                    timeEntryObject.IsOutOfOffice = bool.Parse(timeEntryObject.CustomProperties["IsOutOfOffice"].ToString());
            //Add 20160223
            if (timeEntryObject.CustomProperties["LockStatus"] != null &&
                timeEntryObject.CustomProperties["LockStatus"] != System.DBNull.Value)
            {
                string lockStatus = ReverseToHTMLCode(timeEntryObject.CustomProperties["LockStatus"].ToString());
                if (!string.IsNullOrEmpty(lockStatus))
                {
                    if (lockStatus.ToLower().Equals("locked"))
                        lockStatus = ConstantResourceKey.Locked;
                    else if (lockStatus.ToLower().Equals("unlocked"))
                        lockStatus = ConstantResourceKey.Unlocked;
                    else if (lockStatus.ToLower().Equals("partlylocked"))
                        lockStatus = ConstantResourceKey.Partlylocked;
                }
                timeEntryObject.LockStatus = lockStatus;
              
            }

            if (reader.FieldCount ==34 &&  !reader.IsDBNull(start + 33))
                timeEntryObject.ExpenseStatus = ((StatusEnum)reader.GetInt32(start + 33)).ToString();
        }

        protected void FillObject_ForExport(TimeEntry timeEntryObject, SqlDataReader reader, int start)
        {
            timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            timeEntryObject.ID = reader.GetGuid(start + 0);
            timeEntryObject.UserID = reader.GetInt64(start + 1);
            //timeEntryObject.TimeSheetID = reader.GetInt64(start + 2);
            timeEntryObject.OrganizationID = reader.GetInt64(start + 2);
            timeEntryObject.ProjectID = reader.GetInt64(start + 3);
            timeEntryObject.ActivityID = reader.GetInt64(start + 4);
            if (!reader.IsDBNull(start + 5)) timeEntryObject.TaskID = reader.GetInt64(start + 5);
            if (!reader.IsDBNull(start + 6)) timeEntryObject.ContactID = reader.GetInt64(start + 6);
            timeEntryObject.StartTimeStamp = reader.GetDateTime(start + 7);
            timeEntryObject.EndTimeStamp = reader.GetDateTime(start + 8);

            TimeSpan durationEntry = timeEntryObject.EndTimeStamp - timeEntryObject.StartTimeStamp;
            timeEntryObject.Duration = ((int)(durationEntry.TotalMinutes / 60)).ToString()
                    + ":" + (durationEntry.Minutes > 9 ? durationEntry.Minutes.ToString() : ("0" + durationEntry.Minutes.ToString()));

            timeEntryObject.Status = (StatusEnum)reader.GetInt32(start + 9);
            if (!reader.IsDBNull(start + 10)) timeEntryObject.Subject = ReverseToHTMLCode(reader.GetString(start + 10));
            if (!reader.IsDBNull(start + 11)) timeEntryObject.Body = ReverseToHTMLCode(reader.GetString(start + 11));
            
            //FillBaseObject(timeEntryObject, reader, (start + 12));

            if (!reader.IsDBNull(start + 12)) timeEntryObject.Location = ReverseToHTMLCode(reader.GetString(start + 12));
            if (!reader.IsDBNull(start + 13)) timeEntryObject.SubmittedBy = reader.GetInt64(start + 13);
            if (!reader.IsDBNull(start + 14)) timeEntryObject.Message = ReverseToHTMLCode(reader.GetString(start + 14));
            if (!reader.IsDBNull(start + 15)) timeEntryObject.IsOutOfOffice = reader.GetBoolean(start + 15);
            if (!reader.IsDBNull(start + 16)) timeEntryObject.LocationName = ReverseToHTMLCode(reader.GetString(start + 16));

            timeEntryObject.Cost = !reader.IsDBNull(start + 18) && reader.GetDecimal(start + 18)!=0 ? reader.GetDecimal(start + 18) :0; 
            timeEntryObject.Revenue = !reader.IsDBNull(start + 19)  && reader.GetDecimal(start + 18)!=0 ? reader.GetDecimal(start + 19) :0;
            timeEntryObject.Profit = timeEntryObject.Revenue - timeEntryObject.Cost;//decimal.Round(timeEntryObject.Revenue -timeEntryObject.Cost,2, MidpointRounding.AwayFromZero);
        }

        protected void FillObject(TimeEntry timeEntryObject, SqlDataReader reader)
		{
			FillObject( timeEntryObject, reader,0);
		}

        /// <summary>
        /// Retrieves TimeEntry object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>TimeEntry object</returns>
		private TimeEntry GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					TimeEntry timeEntryObject= new TimeEntry();
					FillObject( timeEntryObject, reader );
                    reader.Close();
					return timeEntryObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of TimeEntry objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of TimeEntry objects</returns>
		private TimeEntryList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			TimeEntryList list = new TimeEntryList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					TimeEntry timeEntryObject = new TimeEntry();
					FillObject( timeEntryObject, reader );                    
					list.Add( timeEntryObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}


        private TimeEntryList GetList_ForExport(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            TimeEntryList list = new TimeEntryList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    TimeEntry timeEntryObject = new TimeEntry();
                    FillObject_ForExport(timeEntryObject, reader, 0);
                    list.Add(timeEntryObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        //Added by tsrdev1
        //Added datetime 02/12/2010
        /// <summary>
        /// Retrieves list of TimeEntry objects and link object from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of TimeEntry objects</returns>
        private System.Collections.Generic.Dictionary<TimeEntry, TimeEntry_OutlookAppointment> GetListForEX(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            System.Collections.Generic.Dictionary<TimeEntry, TimeEntry_OutlookAppointment> list = new System.Collections.Generic.Dictionary<TimeEntry, TimeEntry_OutlookAppointment>();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    TimeEntry timeEntryObject = new TimeEntry();
                    TimeEntry_OutlookAppointment linkObject = null;
                    FillObject(timeEntryObject,out linkObject, reader,0);

                    list.Add(timeEntryObject, linkObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        //Added by tsrdev1
        //Added datetime 02/12/2010
        /// <summary>
        /// Fills TimeEntry object and link object
        /// </summary>
        /// <param name="timeEntryObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(TimeEntryBase timeEntryObject,out TimeEntry_OutlookAppointment linkObject, SqlDataReader reader, int start)
        {
            linkObject = new TimeEntry_OutlookAppointment();

            timeEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            timeEntryObject.ID = reader.GetGuid(start + 0);
            timeEntryObject.UserID = reader.GetInt64(start + 1);
            //timeEntryObject.TimeSheetID = reader.GetInt64(start + 2);
            timeEntryObject.OrganizationID = reader.GetInt64(start + 2);
            timeEntryObject.ProjectID = reader.GetInt64(start + 3);
            timeEntryObject.ActivityID = reader.GetInt64(start + 4);
            if (!reader.IsDBNull(start + 5)) timeEntryObject.TaskID = reader.GetInt64(start + 5);
            if (!reader.IsDBNull(start + 6)) timeEntryObject.ContactID = reader.GetInt64(start + 6);
            timeEntryObject.StartTimeStamp = reader.GetDateTime(start + 7);
            timeEntryObject.EndTimeStamp = reader.GetDateTime(start + 8);
            timeEntryObject.Status = (StatusEnum)reader.GetInt32(start + 9);
            if (!reader.IsDBNull(start + 10)) timeEntryObject.Subject = ReverseToHTMLCode(reader.GetString(start + 10));
            if (!reader.IsDBNull(start + 11)) timeEntryObject.Body = ReverseToHTMLCode(reader.GetString(start + 11));
            FillBaseObject(timeEntryObject, reader, (start + 12),(start + 22));
            if (timeEntryObject.CustomProperties["Location"] != null && !(timeEntryObject.CustomProperties["Location"] == System.DBNull.Value))
                timeEntryObject.Location = ReverseToHTMLCode(timeEntryObject.CustomProperties["Location"].ToString());
            //if (!reader.IsDBNull(start + 29))
            //    timeEntryObject.Names = reader.GetString(start + 29);
            if (timeEntryObject.CustomProperties["SubmittedBy"] != null)
                if (timeEntryObject.CustomProperties["SubmittedBy"] != System.DBNull.Value)
                    timeEntryObject.SubmittedBy = Int64.Parse(timeEntryObject.CustomProperties["SubmittedBy"].ToString());

            if (timeEntryObject.CustomProperties["Message"] != null)
                if (timeEntryObject.CustomProperties["Message"] != System.DBNull.Value)
                    timeEntryObject.Message = ReverseToHTMLCode(timeEntryObject.CustomProperties["Message"].ToString());

            if (timeEntryObject.CustomProperties["Revision"] != null)
                if (timeEntryObject.CustomProperties["Revision"] != System.DBNull.Value)
                    timeEntryObject.Revision = Int64.Parse(timeEntryObject.CustomProperties["Revision"].ToString());
            if (timeEntryObject.CustomProperties["IsRecurring"] != null)
                if (timeEntryObject.CustomProperties["IsRecurring"] != System.DBNull.Value)
                    timeEntryObject.IsRecurring = Convert.ToBoolean(timeEntryObject.CustomProperties["IsRecurring"]);

            if (!reader.IsDBNull(start + 32))
                timeEntryObject.IsOutOfOffice = reader.GetBoolean(start + 32);
            else
                timeEntryObject.IsOutOfOffice = false;
            if (!reader.IsDBNull(start + 33))
                timeEntryObject.LocationID = reader.GetInt64(start + 33);
            else
                timeEntryObject.LocationID = 0;

            if (!reader.IsDBNull(start + 34))
                timeEntryObject.IsCreatedViaWeb = reader.GetBoolean(start + 34);
            else
                timeEntryObject.IsCreatedViaWeb = false;

            //Fill link object
            if (!reader.IsDBNull(start + 22))
            {                
                linkObject.ID = reader.GetInt64(start + 22);
            }
            else { linkObject = null; return; }

            linkObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            linkObject.TimeEntryID = reader.GetGuid(start + 23);
            linkObject.OutlookItemID = reader.GetString(start + 24);
            if (!reader.IsDBNull(start + 25)) linkObject.CalendarID = reader.GetString(start + 25);
            linkObject.Revision = reader.GetInt64(start + 26);

            //Fill base link object
            linkObject.CreatorID = reader.GetInt64(start + 27);
            linkObject.CreatedTimeStamp = reader.GetDateTime(start + 28);
            if (!reader.IsDBNull(start + 29))
                linkObject.ModifierID = reader.GetInt64(start + 29);
            if (!reader.IsDBNull(start + 30))
                linkObject.ModifiedTimeStamp = reader.GetDateTime(start + 30);

            if (reader.GetBoolean(start + 31))
            {
                linkObject.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
            }
            else
                linkObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
        }        
    }
}

