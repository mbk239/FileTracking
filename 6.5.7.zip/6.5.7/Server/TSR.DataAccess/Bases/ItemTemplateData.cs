﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using TSR.Entities.Bases;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class ItemTemplateData : BaseDataAccess
    {
        private const string INSERTITEMTEMPALTE = "InsertItemTemplate";
        private const string UPDATEITEMTEMPALTE = "UpdateItemTemplate";
        private const string DELETEITEMTEMPALTE = "DeleteItemTemplate";
        private const string GETITEMTEMPALTEBYID = "GetItemTemplateByID";
        private const string GETALLITEMTEMPALTE = "GetAllItemTemplate";
        private const string DELETEITEMTEMPALTEBYNAME = "DeleteItemTemplateByName";        

        #region Constructors

        public ItemTemplateData(UserContext context) : base(context) { }
        public ItemTemplateData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="ItemTemplateObject"></param>
        private void AddCommonParams(SqlCommand cmd, ItemTemplateBase ItemTemplateObject)
        {
            AddParameter(cmd, pNVarChar(ItemTemplateBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ItemTemplateObject.Name));
            AddParameter(cmd, pText(ItemTemplateBase.Property_Description, ItemTemplateObject.Description));
            AddParameter(cmd, pNText(ItemTemplateBase.Property_Subject, ItemTemplateObject.Subject));
            AddParameter(cmd, pNText(ItemTemplateBase.Property_Body, ItemTemplateObject.Body));
            AddParameter(cmd, pBit(ItemTemplateBase.Property_ReadOnly, ItemTemplateObject.ReadOnly));
            AddParameter(cmd, pBit(ItemTemplateBase.Property_IsConfigurable, ItemTemplateObject.IsConfigurable));
            AddParameter(cmd, pInt16(ItemTemplateBase.Property_NotificationType, (Int16)ItemTemplateObject.NotificationType));            

        }

        /// <summary>
        /// Inserts Item template
        /// </summary>
        /// <param name="ItemTemplateObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(ItemTemplateBase ItemTemplateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTITEMTEMPALTE);

                AddParameter(cmd, pInt64Out(ItemTemplateBase.Property_ID, ItemTemplateObject.ID));
                AddCommonParams(cmd, ItemTemplateObject);
                AddBaseParametersForInsert(cmd, ItemTemplateObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    ItemTemplateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ItemTemplateBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(ItemTemplateObject, x);
            }
        }

        /// <summary>
        /// Updates Item template
        /// </summary>
        /// <param name="ItemTemplateObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(ItemTemplateBase ItemTemplateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATEITEMTEMPALTE);

                AddParameter(cmd, pInt64(ItemTemplateBase.Property_ID, ItemTemplateObject.ID));
                AddCommonParams(cmd, ItemTemplateObject);
                AddBaseParametersForUpdate(cmd, ItemTemplateObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    ItemTemplateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(ItemTemplateObject, x);
            }

        }

        /// <summary>
        /// Deletes Item template
        /// </summary>
        /// <param name="ID">ID of the Item template object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEITEMTEMPALTE);

                AddParameters(cmd, pInt64(ItemTemplateBase.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(ItemTemplate), ID, x);
            }

        }
        //Created by tsrdev1
        //Created date: 25/06/2010
        /// <summary>
        /// Deletes Item template by name
        /// </summary>
        /// <param name="name">name of the Item template object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(string name)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEITEMTEMPALTEBYNAME);

                AddParameters(cmd, pNVarChar(ItemTemplateBase.Property_Name,TSR.DataAccess.ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, name));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(ItemTemplate), name, x);
            }

        }

        /// <summary>
        /// Retrieves Item template object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Item template object to retrieve</param>
        /// <returns>A Item template object, null if not found</returns>
        public ItemTemplate Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETITEMTEMPALTEBYID))
            {
                AddParameters(cmd, pInt64(ItemTemplateBase.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Item template objects 
        /// </summary>
        /// <returns>A list of Item template objects</returns>
        public ItemTemplateList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLITEMTEMPALTE))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Item template object
        /// </summary>
        /// <param name="ItemTemplateObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(ItemTemplateBase ItemTemplateObject, SqlDataReader reader, int start)
        {
            ItemTemplateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            ItemTemplateObject.ID = reader.GetInt64(start + 0);
            if (!reader.IsDBNull(start + 1)) ItemTemplateObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            if (!reader.IsDBNull(start + 2)) ItemTemplateObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) ItemTemplateObject.Subject = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) ItemTemplateObject.Body = ReverseToHTMLCode(reader.GetString(start + 4));
            ItemTemplateObject.ReadOnly = reader.GetBoolean(start + 5);
            ItemTemplateObject.IsConfigurable= reader.GetBoolean(start + 6);            
            FillBaseObject(ItemTemplateObject, reader, (start + 7));
            if (ItemTemplateObject.CustomProperties != null)
            {
                if (!(ItemTemplateObject.CustomProperties[ItemTemplateBase.Property_NotificationType] == System.DBNull.Value))
                    ItemTemplateObject.NotificationType = ((NotificationTypeEnum)Int32.Parse(ItemTemplateObject.CustomProperties[ItemTemplateBase.Property_NotificationType].ToString()));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ItemTemplateObject"></param>
        /// <param name="reader"></param>
        protected void FillObject(ItemTemplateBase ItemTemplateObject, SqlDataReader reader)
        {
            FillObject(ItemTemplateObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Item template object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Item template object</returns>
        private ItemTemplate GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    ItemTemplate ItemTemplateObject = new ItemTemplate();
                    FillObject(ItemTemplateObject, reader);
                    return ItemTemplateObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Item template objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Item template objects</returns>
        private ItemTemplateList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ItemTemplateList list = new ItemTemplateList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ItemTemplate ItemTemplateObject = new ItemTemplate();
                    FillObject(ItemTemplateObject, reader);

                    list.Add(ItemTemplateObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}
