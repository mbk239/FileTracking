using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Organization_ContactData : BaseRelationData
	{
		private const string INSERTORGANIZATION_CONTACT = "InsertOrganization_Contact";
		private const string UPDATEORGANIZATION_CONTACT = "UpdateOrganization_Contact";
		private const string DELETEORGANIZATION_CONTACT = "DeleteOrganization_Contact";
		private const string GETORGANIZATION_CONTACTBYID = "GetOrganization_ContactByID";
		private const string GETALLORGANIZATION_CONTACT = "GetAllOrganization_Contact";
        private const string GETALLORGANIZATION_CONTACTFORUSER = "GetAllOrganization_ContactForUser";

        #region Constructors

		public Organization_ContactData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="organization_ContactObject"></param>
		private void AddCommonParams( SqlCommand cmd, Organization_ContactBase organization_ContactObject )
		{
			AddParameter(cmd, pInt64(Organization_ContactBase.Property_OrganizationID, organization_ContactObject.OrganizationID));
			AddParameter(cmd, pInt64(Organization_ContactBase.Property_ContactID, organization_ContactObject.ContactID));
		}

        /// <summary>
        /// Inserts Organization_Contact
        /// </summary>
        /// <param name="organization_ContactObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( Organization_ContactBase organization_ContactObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTORGANIZATION_CONTACT );
	
				AddParameter(cmd, pInt64Out(Organization_ContactBase.Property_ID, organization_ContactObject.ID));
				AddCommonParams( cmd, organization_ContactObject );
				AddBaseParametersForInsert( cmd, organization_ContactObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					organization_ContactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Organization_ContactBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( organization_ContactObject, x );
			}
		}
		
        /// <summary>
        /// Updates Organization_Contact 
        /// </summary>
        /// <param name="organization_ContactObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( Organization_ContactBase organization_ContactObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEORGANIZATION_CONTACT );

				AddParameter(cmd, pInt64(Organization_ContactBase.Property_ID, organization_ContactObject.ID));
				AddCommonParams( cmd, organization_ContactObject );
				AddBaseParametersForUpdate( cmd, organization_ContactObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					organization_ContactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( organization_ContactObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Organization_Contact
        /// </summary>
        /// <param name="ID">ID of the Organization_Contact object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEORGANIZATION_CONTACT );
	
				AddParameters( cmd, pInt64( Organization_Contact.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Organization_Contact ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Organization_Contact object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Organization_Contact object to retrieve</param>
        /// <returns>A Organization_Contact object, null if not found</returns>
		public Organization_Contact Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETORGANIZATION_CONTACTBYID) )
			{
				AddParameters( cmd, pInt64( Organization_Contact.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Organization_Contact objects 
        /// </summary>
        /// <returns>A list of Organization_Contact objects</returns>
		public Organization_ContactList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLORGANIZATION_CONTACT ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Organization_Contact object
        /// </summary>
        /// <param name="organization_ContactObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( Organization_ContactBase organization_ContactObject, SqlDataReader reader, int start )
		{
			organization_ContactObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			organization_ContactObject.ID = reader.GetInt64(start + 0);
			organization_ContactObject.OrganizationID = reader.GetInt64(start + 1);
			organization_ContactObject.ContactID = reader.GetInt64(start + 2);
			FillBaseObject(organization_ContactObject, reader, (start + 3));
		}

		protected void FillObject( Organization_ContactBase organization_ContactObject, SqlDataReader reader )
		{
			FillObject( organization_ContactObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Organization_Contact object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Organization_Contact object</returns>
		private Organization_Contact GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Organization_Contact organization_ContactObject= new Organization_Contact();
					FillObject( organization_ContactObject, reader );
					return organization_ContactObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Organization_Contact objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Organization_Contact objects</returns>
		private Organization_ContactList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			Organization_ContactList list = new Organization_ContactList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Organization_Contact organization_ContactObject = new Organization_Contact();
					FillObject( organization_ContactObject, reader );

					list.Add( organization_ContactObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        public Organization_ContactList GetAllForUser(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLORGANIZATION_CONTACTFORUSER))
            {
                AddParameters(cmd, pInt64("UserID", userID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}

