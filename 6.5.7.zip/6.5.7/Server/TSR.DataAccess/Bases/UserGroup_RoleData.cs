using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class UserGroup_RoleData : BaseRelationData
	{
		private const string INSERTUSERGROUP_ROLE = "InsertUserGroup_Role";
		private const string UPDATEUSERGROUP_ROLE = "UpdateUserGroup_Role";
		private const string DELETEUSERGROUP_ROLE = "DeleteUserGroup_Role";
		private const string GETUSERGROUP_ROLEBYID = "GetUserGroup_RoleByID";
		private const string GETALLUSERGROUP_ROLE = "GetAllUserGroup_Role";

        #region Constructors

		public UserGroup_RoleData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="userGroup_RoleObject"></param>
		private void AddCommonParams( SqlCommand cmd, UserGroup_RoleBase userGroup_RoleObject )
		{
			AddParameter(cmd, pInt64(UserGroup_RoleBase.Property_UserGroupID, userGroup_RoleObject.UserGroupID));
			AddParameter(cmd, pInt64(UserGroup_RoleBase.Property_RoleID, userGroup_RoleObject.RoleID));
		}

        /// <summary>
        /// Inserts UserGroup_Role
        /// </summary>
        /// <param name="userGroup_RoleObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( UserGroup_RoleBase userGroup_RoleObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTUSERGROUP_ROLE );
	
				AddParameter(cmd, pInt64Out(UserGroup_RoleBase.Property_ID, userGroup_RoleObject.ID));
				AddCommonParams( cmd, userGroup_RoleObject );
				AddBaseParametersForInsert( cmd, userGroup_RoleObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					userGroup_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, UserGroup_RoleBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( userGroup_RoleObject, x );
			}
		}
		
        /// <summary>
        /// Updates UserGroup_Role 
        /// </summary>
        /// <param name="userGroup_RoleObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( UserGroup_RoleBase userGroup_RoleObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEUSERGROUP_ROLE );

				AddParameter(cmd, pInt64(UserGroup_RoleBase.Property_ID, userGroup_RoleObject.ID));
				AddCommonParams( cmd, userGroup_RoleObject );
				AddBaseParametersForUpdate( cmd, userGroup_RoleObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					userGroup_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( userGroup_RoleObject, x );
			}
			
		}

        /// <summary>
        /// Deletes UserGroup_Role
        /// </summary>
        /// <param name="ID">ID of the UserGroup_Role object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEUSERGROUP_ROLE );
	
				AddParameters( cmd, pInt64( UserGroup_Role.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( UserGroup_Role ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves UserGroup_Role object using it's ID
        /// </summary>
        /// <param name="ID">The id of the UserGroup_Role object to retrieve</param>
        /// <returns>A UserGroup_Role object, null if not found</returns>
		public UserGroup_Role Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETUSERGROUP_ROLEBYID) )
			{
				AddParameters( cmd, pInt64( UserGroup_Role.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all UserGroup_Role objects 
        /// </summary>
        /// <returns>A list of UserGroup_Role objects</returns>
		public UserGroup_RoleList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLUSERGROUP_ROLE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills UserGroup_Role object
        /// </summary>
        /// <param name="userGroup_RoleObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( UserGroup_RoleBase userGroup_RoleObject, SqlDataReader reader, int start )
		{
			userGroup_RoleObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			userGroup_RoleObject.ID = reader.GetInt64(start + 0);
			userGroup_RoleObject.UserGroupID = reader.GetInt64(start + 1);
			userGroup_RoleObject.RoleID = reader.GetInt64(start + 2);
			FillBaseObject(userGroup_RoleObject, reader, (start + 3));
		}

		protected void FillObject( UserGroup_RoleBase userGroup_RoleObject, SqlDataReader reader )
		{
			FillObject( userGroup_RoleObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves UserGroup_Role object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>UserGroup_Role object</returns>
		private UserGroup_Role GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					UserGroup_Role userGroup_RoleObject= new UserGroup_Role();
					FillObject( userGroup_RoleObject, reader );
					return userGroup_RoleObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of UserGroup_Role objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of UserGroup_Role objects</returns>
		private UserGroup_RoleList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			UserGroup_RoleList list = new UserGroup_RoleList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					UserGroup_Role userGroup_RoleObject = new UserGroup_Role();
					FillObject( userGroup_RoleObject, reader );

					list.Add( userGroup_RoleObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

