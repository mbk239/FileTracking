using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class CommDetailData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_CommDetail;

		private const string INSERTCOMMDETAIL = "InsertCommDetail";
		private const string UPDATECOMMDETAIL = "UpdateCommDetail";
		private const string DELETECOMMDETAIL = "DeleteCommDetail";
		private const string GETCOMMDETAILBYID = "GetCommDetailByID";
		private const string GETALLCOMMDETAIL = "GetAllCommDetail";
        
        #region Constructors

		public CommDetailData(UserContext context) : base(context) { LOCK_CommDetail = this; }
		public CommDetailData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_CommDetail = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="commDetailObject"></param>
		private void AddCommonParams( SqlCommand cmd, CommDetailBase commDetailObject )
		{
			AddParameter(cmd, pInt64(CommDetailBase.Property_CommDetailTypeID, commDetailObject.CommDetailTypeID));
			AddParameter(cmd, pBool(CommDetailBase.Property_Preferred, commDetailObject.Preferred));
            AddParameter(cmd, pNVarChar(CommDetailBase.Property_Value, ConstantCollection.NVARCHAR_FIELD_NORMAL_LENGTH, commDetailObject.Value));
		}

        /// <summary>
        /// Inserts CommDetail
        /// </summary>
        /// <param name="commDetailObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( CommDetailBase commDetailObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTCOMMDETAIL );
	
				AddParameter(cmd, pInt64Out(CommDetailBase.Property_ID, commDetailObject.ID));
				AddCommonParams( cmd, commDetailObject );
				AddBaseParametersForInsert( cmd, commDetailObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					commDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, CommDetailBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( commDetailObject, x );
			}
		}
		
        /// <summary>
        /// Updates CommDetail 
        /// </summary>
        /// <param name="commDetailObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( CommDetailBase commDetailObject)
		{
            lock (LOCK_CommDetail)
            {
				try
				{
                    CommDetailBase dbObject = Get(commDetailObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(commDetailObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != commDetailObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != commDetailObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(commDetailObject, null);

					SqlCommand cmd = GetSPCommand( UPDATECOMMDETAIL );

				    AddParameter(cmd, pInt64(CommDetailBase.Property_ID, commDetailObject.ID));
					AddCommonParams( cmd, commDetailObject );
					AddBaseParametersForUpdate( cmd, commDetailObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						commDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( commDetailObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes CommDetail
        /// </summary>
        /// <param name="ID">ID of the CommDetail object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETECOMMDETAIL );
	
				AddParameters( cmd, pInt64( CommDetail.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( CommDetail ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves CommDetail object using it's ID
        /// </summary>
        /// <param name="ID">The id of the CommDetail object to retrieve</param>
        /// <returns>A CommDetail object, null if not found</returns>
		public CommDetail Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETCOMMDETAILBYID) )
			{
				AddParameters( cmd, pInt64( CommDetail.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all CommDetail objects 
        /// </summary>
        /// <returns>A list of CommDetail objects</returns>
		public CommDetailList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLCOMMDETAIL ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills CommDetail object
        /// </summary>
        /// <param name="commDetailObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( CommDetailBase commDetailObject, SqlDataReader reader, int start )
		{
			commDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			commDetailObject.ID = reader.GetInt64(start + 0);
			commDetailObject.CommDetailTypeID = reader.GetInt64(start + 1);
			commDetailObject.Preferred = reader.GetBoolean(start + 2);
			commDetailObject.Value = ReverseToHTMLCode(reader.GetString(start + 3));
			FillBaseObject(commDetailObject, reader, (start + 4));
		}

		protected void FillObject( CommDetailBase commDetailObject, SqlDataReader reader )
		{
			FillObject( commDetailObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves CommDetail object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>CommDetail object</returns>
		private CommDetail GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					CommDetail commDetailObject= new CommDetail();
					FillObject( commDetailObject, reader );
					return commDetailObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of CommDetail objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of CommDetail objects</returns>
		private CommDetailList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			CommDetailList list = new CommDetailList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					CommDetail commDetailObject = new CommDetail();
					FillObject( commDetailObject, reader );

					list.Add( commDetailObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

