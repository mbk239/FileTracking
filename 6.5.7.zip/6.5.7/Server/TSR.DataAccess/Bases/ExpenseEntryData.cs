using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ExpenseEntryData : BaseDataAccess
	{
		private const string INSERTEXPENSEENTRY = "InsertExpenseEntry";
		private const string UPDATEEXPENSEENTRY = "UpdateExpenseEntry";
		private const string DELETEEXPENSEENTRY = "DeleteExpenseEntry";
		private const string GETEXPENSEENTRYBYID = "GetExpenseEntryByID";
        private const string GETEXPENSEENTRYBYEXPENSESHEETID = "GetExpenseEntryByExpenseSheetID";
		private const string GETALLEXPENSEENTRY = "GetAllExpenseEntry";
        private const string GETDELETEDEXPENSEENTRYBYID = "GetDeletedExpenseEntryByID";

        #region Constructors

        public ExpenseEntryData(UserContext context) : base(context) { }
        public ExpenseEntryData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="expenseEntryObject"></param>
		private void AddCommonParams( SqlCommand cmd, ExpenseEntryBase expenseEntryObject )
		{
            AddParameter(cmd, pInt64(ExpenseEntryBase.Property_ExpenseTypeID, expenseEntryObject.ExpenseTypeID));
            AddParameter(cmd, pInt64(ExpenseEntryBase.Property_ExpenseSheetID, (int)expenseEntryObject.ExpenseSheetID));
            AddParameter(cmd, pNVarChar(ExpenseEntryBase.Property_Description, ConstantCollection.NVARCHAR_FIELD_LENGTH_200, expenseEntryObject.Description));
            AddParameter(cmd, pDecimal(ExpenseEntryBase.Property_Quantity, expenseEntryObject.Quantity));
            AddParameter(cmd, pDecimal(ExpenseEntryBase.Property_Value, expenseEntryObject.Value));
            AddParameter(cmd, pDecimal(ExpenseEntryBase.Property_Total, expenseEntryObject.Total));
            AddParameter(cmd, pInt64(ExpenseEntryBase.Property_Revision, expenseEntryObject.Revision));
            AddParameter(cmd, pInt64(ExpenseEntryBase.Property_LocationID, expenseEntryObject.LocationID));
		}

        /// <summary>
        /// Inserts ExpenseEntry
        /// </summary>
        /// <param name="expenseEntryObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ExpenseEntryBase expenseEntryObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTEXPENSEENTRY );
	
				AddParameter(cmd, pInt64Out(ExpenseEntryBase.Property_ID, expenseEntryObject.ID));
				AddCommonParams( cmd, expenseEntryObject );
				AddBaseParametersForInsert( cmd, expenseEntryObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					expenseEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                expenseEntryObject.ID = (long)GetOutParameter(cmd, ExpenseEntryBase.Property_ID);
                return expenseEntryObject.ID;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( expenseEntryObject, x );
			}
		}
		
        /// <summary>
        /// Updates ExpenseEntry 
        /// </summary>
        /// <param name="expenseEntryObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ExpenseEntryBase expenseEntryObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEEXPENSEENTRY );

				AddParameter(cmd, pInt64(ExpenseEntryBase.Property_ID, expenseEntryObject.ID));
				AddCommonParams( cmd, expenseEntryObject );
				AddBaseParametersForUpdate( cmd, expenseEntryObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					expenseEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( expenseEntryObject, x );
			}
			
		}

        /// <summary>
        /// Deletes ExpenseEntry
        /// </summary>
        /// <param name="ID">ID of the ExpenseEntry object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEEXPENSEENTRY );
	
				AddParameters( cmd, pInt64( ExpenseEntry.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ExpenseEntry ), ID, x );
			}
			
		}
        /// <summary>
        /// Retrieves Deleted ExpenseEntry object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ExpenseEntry object to retrieve</param>
        /// <returns>A ExpenseEntry object, null if not found</returns>
        public ExpenseEntry GetDeletedExpenseEntry(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDEXPENSEENTRYBYID))
            {
                AddParameters(cmd, pInt64(ExpenseEntry.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves ExpenseEntry object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ExpenseEntry object to retrieve</param>
        /// <returns>A ExpenseEntry object, null if not found</returns>
		public ExpenseEntry Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETEXPENSEENTRYBYID) )
			{
				AddParameters( cmd, pInt64( ExpenseEntry.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves ExpenseEntry object using it's ExpenseSheetID
        /// </summary>
        /// <param name="ID">The id of the ExpenseEntry object to retrieve</param>
        /// <returns>A ExpenseEntry object, null if not found</returns>
        public ExpenseEntryList GetExpenseEntryByExpenseSheetID(long expenseSheetID)
        {
            using (SqlCommand cmd = GetSPCommand(GETEXPENSEENTRYBYEXPENSESHEETID))
            {
                AddParameters(cmd, pInt64(ExpenseEntry.Property_ExpenseSheetID, expenseSheetID));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Retrieves all ExpenseEntry objects 
        /// </summary>
        /// <returns>A list of ExpenseEntry objects</returns>
		public ExpenseEntryList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLEXPENSEENTRY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ExpenseEntry object
        /// </summary>
        /// <param name="ExpenseEntryObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ExpenseEntry expenseEntryObject, SqlDataReader reader, int start )
		{
			expenseEntryObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			expenseEntryObject.ID = reader.GetInt64(start + 0);
            expenseEntryObject.ExpenseTypeID = reader.GetInt64(start + 1);
            expenseEntryObject.ExpenseSheetID = reader.GetInt64(start + 2);
            expenseEntryObject.Description = reader.GetString(start + 3);
            expenseEntryObject.Quantity = reader.GetDecimal(start + 4);
            expenseEntryObject.Value = reader.GetDecimal(start + 5);
            expenseEntryObject.Total = reader.GetDecimal(start + 6);
            expenseEntryObject.Revision = reader.GetInt64(start + 7);
            
			FillBaseObject(expenseEntryObject, reader, (start + 8));

            if (expenseEntryObject.CustomProperties != null && 
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_ExpenseTypeName] != null &&
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_ExpenseTypeName] != System.DBNull.Value)
            {
                expenseEntryObject.ExpenseTypeName = ReverseToHTMLCode(expenseEntryObject.CustomProperties[ExpenseEntry.Property_ExpenseTypeName].ToString());
            }

            if (expenseEntryObject.CustomProperties != null &&
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationName] != null &&
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationName] != System.DBNull.Value)
            {
                expenseEntryObject.LocationName = ReverseToHTMLCode(expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationName].ToString());
            }

            if (expenseEntryObject.CustomProperties != null &&
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationID] != null &&
                expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationID] != System.DBNull.Value)
            {
                expenseEntryObject.LocationID = Int64.Parse(expenseEntryObject.CustomProperties[ExpenseEntry.Property_LocationID].ToString());
            }
		}

		protected void FillObject( ExpenseEntry expenseEntryObject, SqlDataReader reader )
		{
			FillObject( expenseEntryObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ExpenseEntry object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ExpenseEntry object</returns>
		private ExpenseEntry GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ExpenseEntry expenseEntryObject= new ExpenseEntry();
					FillObject( expenseEntryObject, reader );
					return expenseEntryObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ExpenseEntry objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ExpenseEntry objects</returns>
		private ExpenseEntryList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ExpenseEntryList list = new ExpenseEntryList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					ExpenseEntry expenseEntryObject = new ExpenseEntry();
					FillObject( expenseEntryObject, reader );

					list.Add( expenseEntryObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

