﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using TSR.Entities.Bases;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class NotificationData : BaseDataAccess
    {
        private const string INSERTNOTIFICATION = "InsertNotification";
        private const string UPDATENOTIFICATION = "UpdateNotification";
        private const string DELETENOTIFICATION = "DeleteNotification";
        private const string GETNOTIFICATIONBYID = "GetNotificationByID";
        private const string GETALLNOTIFICATION = "GetAllNotification";

        #region Constructors

        public NotificationData(UserContext context) : base(context) { }
        public NotificationData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="NotificationObject"></param>
        private void AddCommonParams(SqlCommand cmd, NotificationBase notificationObject)
        {
            AddParameter(cmd, pNVarChar(NotificationBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, notificationObject.Name));
            AddParameter(cmd, pInt64(NotificationBase.Property_UserID, notificationObject.UserID));
            AddParameter(cmd, pNText(NotificationBase.Property_Subject, notificationObject.Subject));
            AddParameter(cmd, pNText(NotificationBase.Property_Body, notificationObject.Body));
            AddParameter(cmd, pDateTime(NotificationBase.Property_StartDate, notificationObject.StartDate));
            AddParameter(cmd, pDateTime(NotificationBase.Property_EndDate, notificationObject.EndDate));
            AddParameter(cmd, pDateTime(NotificationBase.Property_ExecutionTimeStamp, notificationObject.ExecutionTimeStamp));
            AddParameter(cmd, pInt16(NotificationBase.Property_TransferMedium, (short)notificationObject.TransferMedium));
            AddParameter(cmd, pBool(NotificationBase.Property_IsSent, notificationObject.IsSent));
            AddParameter(cmd, pInt16(NotificationBase.Property_TryCount, notificationObject.TryCount));

        }

        /// <summary>
        /// Inserts Notification
        /// </summary>
        /// <param name="NotificationObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(NotificationBase notificationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTNOTIFICATION);

                AddParameter(cmd, pInt64Out(NotificationBase.Property_ID, notificationObject.ID));
                AddCommonParams(cmd, notificationObject);
                AddBaseParametersForInsert(cmd, notificationObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    notificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, NotificationBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(notificationObject, x);
            }
        }

        /// <summary>
        /// Updates Notification 
        /// </summary>
        /// <param name="NotificationObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(NotificationBase notificationObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATENOTIFICATION);

                AddParameter(cmd, pInt64(NotificationBase.Property_ID, notificationObject.ID));
                AddCommonParams(cmd, notificationObject);
                AddBaseParametersForUpdate(cmd, notificationObject);

                long result = UpdateRecord(cmd);
                if (result > 0)
                    notificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return result;
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectUpdateException(notificationObject, x);
            }

        }

        /// <summary>
        /// Deletes Notification
        /// </summary>
        /// <param name="ID">ID of the Notification object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETENOTIFICATION);

                AddParameters(cmd, pInt64(NotificationBase.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Notification), ID, x);
            }

        }

        /// <summary>
        /// Retrieves Notification object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Notification object to retrieve</param>
        /// <returns>A Notification object, null if not found</returns>
        public Notification Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETNOTIFICATIONBYID))
            {
                AddParameters(cmd, pInt64(NotificationBase.Property_ID, ID));

                return GetObject(cmd);
            }
        }

        /// <summary>
        /// Retrieves all Notification objects 
        /// </summary>
        /// <returns>A list of Notification objects</returns>
        public NotificationList GetAll()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLNOTIFICATION))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Notification object
        /// </summary>
        /// <param name="NotificationObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(NotificationBase notificationObject, SqlDataReader reader, int start)
        {
            notificationObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            notificationObject.ID = reader.GetInt64(start + 0);
            if (!reader.IsDBNull(start + 1)) notificationObject.Name =ReverseToHTMLCode(reader.GetString(start + 1));
            notificationObject.UserID = reader.GetInt64(start + 2);
            if (!reader.IsDBNull(start + 3)) notificationObject.Subject = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) notificationObject.Body = ReverseToHTMLCode(reader.GetString(start + 4));
            notificationObject.StartDate = reader.GetDateTime(start + 5);
            notificationObject.EndDate = reader.GetDateTime(start + 6);
            if (!reader.IsDBNull(start + 7))
                notificationObject.ExecutionTimeStamp = reader.GetDateTime(start + 7);
            else
                notificationObject.ExecutionTimeStamp = DateTime.Now;
            notificationObject.TransferMedium = (TransferMediumEnum)reader.GetInt16(start + 8);
            notificationObject.IsSent = reader.GetBoolean(start + 9);
            notificationObject.TryCount = reader.GetInt16(start + 10);
            FillBaseObject(notificationObject, reader, (start + 11));
        }

        protected void FillObject(NotificationBase NotificationObject, SqlDataReader reader)
        {
            FillObject(NotificationObject, reader, 0);
        }

        /// <summary>
        /// Retrieves Notification object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Notification object</returns>
        private Notification GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    Notification notificationObject = new Notification();
                    FillObject(notificationObject, reader);
                    return notificationObject;
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// Retrieves list of Notification objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Notification objects</returns>
        private NotificationList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            NotificationList list = new NotificationList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Notification NotificationObject = new Notification();
                    FillObject(NotificationObject, reader);

                    list.Add(NotificationObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

    }
}
