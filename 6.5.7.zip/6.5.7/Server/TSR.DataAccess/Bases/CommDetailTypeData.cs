using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class CommDetailTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_CommDetailType;

		private const string INSERTCOMMDETAILTYPE = "InsertCommDetailType";
		private const string UPDATECOMMDETAILTYPE = "UpdateCommDetailType";
		private const string DELETECOMMDETAILTYPE = "DeleteCommDetailType";
		private const string GETCOMMDETAILTYPEBYID = "GetCommDetailTypeByID";
		private const string GETALLCOMMDETAILTYPE = "GetAllCommDetailType";
       

        #region Constructors

		public CommDetailTypeData(UserContext context) : base(context) { LOCK_CommDetailType = this; }
		public CommDetailTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_CommDetailType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="commDetailTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, CommDetailTypeBase commDetailTypeObject )
		{
            AddParameter(cmd, pNVarChar(CommDetailTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, commDetailTypeObject.Name));
			AddParameter(cmd, pNText(CommDetailTypeBase.Property_Description, commDetailTypeObject.Description));
			AddParameter(cmd, pNText(CommDetailTypeBase.Property_ValidationExpression, commDetailTypeObject.ValidationExpression));
			AddParameter(cmd, pBool(CommDetailTypeBase.Property_ReadOnly, commDetailTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts CommDetailType
        /// </summary>
        /// <param name="commDetailTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( CommDetailTypeBase commDetailTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTCOMMDETAILTYPE );
	
				AddParameter(cmd, pInt64Out(CommDetailTypeBase.Property_ID, commDetailTypeObject.ID));
				AddCommonParams( cmd, commDetailTypeObject );
				AddBaseParametersForInsert( cmd, commDetailTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					commDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, CommDetailTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( commDetailTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates CommDetailType 
        /// </summary>
        /// <param name="commDetailTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( CommDetailTypeBase commDetailTypeObject)
		{
            lock (LOCK_CommDetailType)
            {
				try
				{
                    CommDetailTypeBase dbObject = Get(commDetailTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(commDetailTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != commDetailTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != commDetailTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(commDetailTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATECOMMDETAILTYPE );

				AddParameter(cmd, pInt64(CommDetailTypeBase.Property_ID, commDetailTypeObject.ID));
					AddCommonParams( cmd, commDetailTypeObject );
					AddBaseParametersForUpdate( cmd, commDetailTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						commDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( commDetailTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes CommDetailType
        /// </summary>
        /// <param name="ID">ID of the CommDetailType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETECOMMDETAILTYPE );
	
				AddParameters( cmd, pInt64( CommDetailType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( CommDetailType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves CommDetailType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the CommDetailType object to retrieve</param>
        /// <returns>A CommDetailType object, null if not found</returns>
		public CommDetailType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETCOMMDETAILTYPEBYID) )
			{
				AddParameters( cmd, pInt64( CommDetailType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all CommDetailType objects 
        /// </summary>
        /// <returns>A list of CommDetailType objects</returns>
		public CommDetailTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLCOMMDETAILTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills CommDetailType object
        /// </summary>
        /// <param name="commDetailTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( CommDetailTypeBase commDetailTypeObject, SqlDataReader reader, int start )
		{
			commDetailTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			commDetailTypeObject.ID = reader.GetInt64(start + 0);
			commDetailTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) commDetailTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
            if (!reader.IsDBNull(start + 3)) commDetailTypeObject.ValidationExpression = ReverseToHTMLCode(reader.GetString(start + 3));
			commDetailTypeObject.ReadOnly = reader.GetBoolean(start + 4);
			FillBaseObject(commDetailTypeObject, reader, (start + 5));
		}

		protected void FillObject( CommDetailTypeBase commDetailTypeObject, SqlDataReader reader )
		{
			FillObject( commDetailTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves CommDetailType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>CommDetailType object</returns>
		private CommDetailType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					CommDetailType commDetailTypeObject= new CommDetailType();
					FillObject( commDetailTypeObject, reader );
					return commDetailTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of CommDetailType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of CommDetailType objects</returns>
		private CommDetailTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			CommDetailTypeList list = new CommDetailTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					CommDetailType commDetailTypeObject = new CommDetailType();
					FillObject( commDetailTypeObject, reader );

					list.Add( commDetailTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

