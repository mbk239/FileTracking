using System;
using System.Data;
using System.Data.SqlClient;

using Contest.TSR.Framework;
using Contest.TSR.Entities;
using Contest.TSR.Entities.Base;

namespace Contest.TSR.DataAccess
{
	public partial class LanguageTypeData : BaseDataAccess
	{
		private const string INSERTLANGUAGETYPE = "InsertLanguageType";
		private const string UPDATELANGUAGETYPE = "UpdateLanguageType";
		private const string DELETELANGUAGETYPE = "DeleteLanguageType";
		private const string GETLANGUAGETYPEBYID = "GetLanguageTypeByID";
		private const string GETALLLANGUAGETYPE = "GetAllLanguageType";

        #region Constructors

		public LanguageTypeData(UserContext context) : base(context) { }
		public LanguageTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="languageTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, LanguageTypeBase languageTypeObject )
		{
			AddParameter(cmd, pVarChar(LanguageTypeBase.Property_LanguageId, 50, languageTypeObject.LanguageId));
			AddParameter(cmd, pVarChar(LanguageTypeBase.Property_Value, 255, languageTypeObject.Value));
		}

        /// <summary>
        /// Inserts LanguageType
        /// </summary>
        /// <param name="languageTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( LanguageTypeBase languageTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTLANGUAGETYPE );
	
				AddParameter(cmd, pInt64Out(LanguageTypeBase.Property_ID, languageTypeObject.ID));
				AddCommonParams( cmd, languageTypeObject );
				AddBaseParametersForInsert( cmd, languageTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					languageTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, LanguageTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectInsertException( languageTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates LanguageType 
        /// </summary>
        /// <param name="languageTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( LanguageTypeBase languageTypeObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATELANGUAGETYPE );

				AddParameter(cmd, pInt64(LanguageTypeBase.Property_ID, languageTypeObject.ID));
				AddCommonParams( cmd, languageTypeObject );
				AddBaseParametersForUpdate( cmd, languageTypeObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					languageTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectUpdateException( languageTypeObject, x );
			}
			
		}

        /// <summary>
        /// Deletes LanguageType
        /// </summary>
        /// <param name="ID">ID of the LanguageType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETELANGUAGETYPE );
	
				AddParameters( cmd, pInt64( LanguageType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Contest.TSR.Framework.Exceptions.ObjectDeleteException( typeof( LanguageType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves LanguageType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the LanguageType object to retrieve</param>
        /// <returns>A LanguageType object, null if not found</returns>
		public LanguageType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETLANGUAGETYPEBYID) )
			{
				AddParameters( cmd, pInt64( LanguageType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all LanguageType objects 
        /// </summary>
        /// <returns>A list of LanguageType objects</returns>
		public LanguageTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLLANGUAGETYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills LanguageType object
        /// </summary>
        /// <param name="languageTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( LanguageTypeBase languageTypeObject, SqlDataReader reader, int start )
		{
			languageTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			languageTypeObject.ID = reader.GetInt64(start + 0);
			languageTypeObject.LanguageId = reader.GetString(start + 1);
			languageTypeObject.Value = reader.GetString(start + 2);
			FillBaseObject(languageTypeObject, reader, (start + 3));
		}

		protected void FillObject( LanguageTypeBase languageTypeObject, SqlDataReader reader )
		{
			FillObject( languageTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves LanguageType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>LanguageType object</returns>
		private LanguageType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					LanguageType languageTypeObject= new LanguageType();
					FillObject( languageTypeObject, reader );
					return languageTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of LanguageType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of LanguageType objects</returns>
		private LanguageTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			LanguageTypeList list = new LanguageTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					LanguageType languageTypeObject = new LanguageType();
					FillObject( languageTypeObject, reader );

					list.Add( languageTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

