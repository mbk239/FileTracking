﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities.Bases;
using TSR.Entities;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class LockPeriodData : BaseDataAccess
    {
        #region[Constants for StoreProcedure]
        private const string GETLOCKPERIODBYUSERID = "GetLockPeriodByUserID";
        private const string GETLOCKPERIODBYUSERIDININTERVALDAYS = "GetLockPeriodByuUserIDInintervalDays";
        #endregion

        protected const long ALL_AVAILABLE_RECORDS = -1;

        //Constructor
        public LockPeriodData(UserContext context) : base(context) { }
        public LockPeriodData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #region Functions
        /// <summary>
        /// Fills LockPeriod object
        /// </summary>
        /// <param name="lockPeriodObject"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject(LockPeriodBase lockPeriodObject, SqlDataReader reader, int start)
        {
            lockPeriodObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            lockPeriodObject.UserID = reader.GetInt64(start + 0);
            lockPeriodObject.LockDate = reader.GetDateTime(start + 1);
            lockPeriodObject.IsLocked = reader.GetBoolean(start + 2);
            //FillBaseObject(lockPeriodObject, reader, (start + 3));
        }

        protected void FillObject(LockPeriodBase lockPeriodObject, SqlDataReader reader)
        {
            FillObject(lockPeriodObject, reader, 0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        private LockPeriodList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            var list = new LockPeriodList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    LockPeriod lockPeriodObject = new LockPeriod();
                    FillObject(lockPeriodObject, reader);

                    list.Add(lockPeriodObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        /// <summary>
        /// Retrieves all LockPeriod objects by UserID
        /// </summary>
        /// <returns>A list of LockPeriod objects</returns>
        public LockPeriodList GetLockPeriodByUserID(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCKPERIODBYUSERID))
            {
                AddParameters(cmd, pInt64(LockPeriod.Property_UserID, userID));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }


        public LockPeriodList GetLockPeriodByUserIDInIntervalDays(long userID, DateTime startDate, int intervalDays)
        {
            try
            {
                using (SqlCommand cmd = GetSPCommand(GETLOCKPERIODBYUSERIDININTERVALDAYS))
                {
                    AddParameter(cmd, pInt64(TimeEntryBase.Property_UserID, userID));
                    AddParameter(cmd, pDateTime("StartDate", startDate));
                    AddParameter(cmd, pInt32("IntervalDays", intervalDays));

                    return GetList(cmd, ALL_AVAILABLE_RECORDS);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}
