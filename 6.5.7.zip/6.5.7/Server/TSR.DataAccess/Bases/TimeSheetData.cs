using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class TimeSheetData : BaseDataAccess
	{
		private const string INSERTTIMESHEET = "InsertTimeSheet";
		private const string UPDATETIMESHEET = "UpdateTimeSheet";
		private const string DELETETIMESHEET = "DeleteTimeSheet";
		private const string GETTIMESHEETBYID = "GetTimeSheetByID";
		private const string GETALLTIMESHEET = "GetAllTimeSheet";

        #region Constructors

		public TimeSheetData(UserContext context) : base(context) { }
		public TimeSheetData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="timeSheetObject"></param>
		private void AddCommonParams( SqlCommand cmd, TimeSheetBase timeSheetObject )
		{
			AddParameter(cmd, pNVarChar(TimeSheetBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, timeSheetObject.Name));
			AddParameter(cmd, pNText(TimeSheetBase.Property_Description, timeSheetObject.Description));
			AddParameter(cmd, pDateTime(TimeSheetBase.Property_StartTimeStamp, timeSheetObject.StartTimeStamp));
			AddParameter(cmd, pDateTime(TimeSheetBase.Property_EndTimeStamp, timeSheetObject.EndTimeStamp));
		}

        /// <summary>
        /// Inserts TimeSheet
        /// </summary>
        /// <param name="timeSheetObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( TimeSheetBase timeSheetObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTTIMESHEET );
	
				AddParameter(cmd, pInt64Out(TimeSheetBase.Property_ID, timeSheetObject.ID));
				AddCommonParams( cmd, timeSheetObject );
				AddBaseParametersForInsert( cmd, timeSheetObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					timeSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, TimeSheetBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( timeSheetObject, x );
			}
		}
		
        /// <summary>
        /// Updates TimeSheet 
        /// </summary>
        /// <param name="timeSheetObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( TimeSheetBase timeSheetObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATETIMESHEET );

				AddParameter(cmd, pInt64(TimeSheetBase.Property_ID, timeSheetObject.ID));
				AddCommonParams( cmd, timeSheetObject );
				AddBaseParametersForUpdate( cmd, timeSheetObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					timeSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( timeSheetObject, x );
			}
			
		}

        /// <summary>
        /// Deletes TimeSheet
        /// </summary>
        /// <param name="ID">ID of the TimeSheet object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETETIMESHEET );
	
				AddParameters( cmd, pInt64( TimeSheet.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( TimeSheet ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves TimeSheet object using it's ID
        /// </summary>
        /// <param name="ID">The id of the TimeSheet object to retrieve</param>
        /// <returns>A TimeSheet object, null if not found</returns>
		public TimeSheet Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETTIMESHEETBYID) )
			{
				AddParameters( cmd, pInt64( TimeSheet.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all TimeSheet objects 
        /// </summary>
        /// <returns>A list of TimeSheet objects</returns>
		public TimeSheetList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLTIMESHEET ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills TimeSheet object
        /// </summary>
        /// <param name="timeSheetObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( TimeSheetBase timeSheetObject, SqlDataReader reader, int start )
		{
			timeSheetObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			timeSheetObject.ID = reader.GetInt64(start + 0);
			timeSheetObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) timeSheetObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			timeSheetObject.StartTimeStamp = reader.GetDateTime(start + 3);
			timeSheetObject.EndTimeStamp = reader.GetDateTime(start + 4);
			FillBaseObject(timeSheetObject, reader, (start + 5));
		}

		protected void FillObject( TimeSheetBase timeSheetObject, SqlDataReader reader )
		{
			FillObject( timeSheetObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves TimeSheet object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>TimeSheet object</returns>
		private TimeSheet GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					TimeSheet timeSheetObject= new TimeSheet();
					FillObject( timeSheetObject, reader );
					return timeSheetObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of TimeSheet objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of TimeSheet objects</returns>
		private TimeSheetList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			TimeSheetList list = new TimeSheetList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					TimeSheet timeSheetObject = new TimeSheet();
					FillObject( timeSheetObject, reader );

					list.Add( timeSheetObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

