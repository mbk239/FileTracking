using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ActivityData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Activity;

		private const string INSERTACTIVITY = "InsertActivity";
		private const string UPDATEACTIVITY = "UpdateActivity";
		private const string DELETEACTIVITY = "DeleteActivity";
		private const string GETACTIVITYBYID = "GetActivityByID";
		private const string GETALLACTIVITY = "GetAllActivity";
        private const string GETDELETEDACTIVITYBYID = "GetDeletedActivityByID";
        private const string GETALLDELETEDACTIVITY = "GetAllDeletedActivity";
        private const string GETALLACTIVITYFOREXPORT = "GetAllActivityForExport";

        #region Constructors

		public ActivityData(UserContext context) : base(context) { LOCK_Activity = this; }
		public ActivityData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Activity = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="activityObject"></param>
		private void AddCommonParams( SqlCommand cmd, ActivityBase activityObject)
		{
			AddParameter(cmd, pInt64(ActivityBase.Property_ActivityTypeID, activityObject.ActivityTypeID));
			AddParameter(cmd, pNVarChar(ActivityBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, activityObject.Name));
			AddParameter(cmd, pNText(ActivityBase.Property_Description, activityObject.Description));
		}

        /// <summary>
        /// Inserts Activity
        /// </summary>
        /// <param name="activityObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ActivityBase activityObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTACTIVITY );
	
				AddParameter(cmd, pInt64Out(ActivityBase.Property_ID, activityObject.ID));
				AddCommonParams( cmd, activityObject );
				AddBaseParametersForInsert( cmd, activityObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					activityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ActivityBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( activityObject, x );
			}
		}

        /// <summary>
        /// Inserts for DBR import.
        /// </summary>
        /// <param name="activityObject">The activity object.</param>
        /// <param name="error">The error.</param>
        /// <returns></returns>
        public long InsertForDBRImport(ActivityBase activityObject,out string error)
        {
            error = string.Empty;
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTACTIVITY);

                AddParameter(cmd, pInt64Out(ActivityBase.Property_ID, activityObject.ID));
                AddCommonParams(cmd, activityObject);
                AddBaseParametersForInsert(cmd, activityObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    activityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ActivityBase.Property_ID);
            }
            catch (SqlException x)
            {
                error = x.Message;
            }
            return 0;
        }
		
        /// <summary>
        /// Updates Activity 
        /// </summary>
        /// <param name="activityObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ActivityBase activityObject)
		{
            lock (LOCK_Activity)
            {
                try
                {
                    ActivityBase dbObject = Get(activityObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(activityObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != activityObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != activityObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(activityObject, null);

                    SqlCommand cmd = GetSPCommand(UPDATEACTIVITY);

                    AddParameter(cmd, pInt64(ActivityBase.Property_ID, activityObject.ID));
                    AddCommonParams(cmd, activityObject);
                    AddParameter(cmd, pBool(ActivityBase.Property_IsActivate, activityObject.IsActivate));
                    AddBaseParametersForUpdate(cmd, activityObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        activityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(activityObject, x);
                }
			}            
		}

        /// <summary>
        /// Updates for DBR import.
        /// </summary>
        /// <param name="activityObject">The activity object.</param>
        /// <param name="error">The error.</param>
        /// <returns></returns>
        public long UpdateForDBRImport(ActivityBase activityObject,out string error)
        {
            error = string.Empty;
            lock (LOCK_Activity)
            {
                try
                {
                    ActivityBase dbObject = Get(activityObject.ID);
                    if (dbObject == null)
                        error = "Not exist activity name '" + activityObject.Name + "' in database";                    

                    SqlCommand cmd = GetSPCommand(UPDATEACTIVITY);

                    dbObject.CloneBase(activityObject);

                    AddParameter(cmd, pInt64(ActivityBase.Property_ID, activityObject.ID));
                    AddParameter(cmd, pBit(ActivityBase.Property_IsActivate, activityObject.IsActivate));
                    AddCommonParams(cmd, activityObject);
                    AddBaseParametersForUpdate(cmd, activityObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        activityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    error = x.Message;
                }
            }
            return 0;
        }

        /// <summary>
        /// Deletes Activity
        /// </summary>
        /// <param name="ID">ID of the Activity object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEACTIVITY );
	
				AddParameters( cmd, pInt64( Activity.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Activity ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Activity object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Activity object to retrieve</param>
        /// <returns>A Activity object, null if not found</returns>
		public Activity Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETACTIVITYBYID) )
			{
				AddParameters( cmd, pInt64( Activity.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves Deleted Activity object using it's ID
        /// added by tsrdev2
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Activity GetDeleted(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDACTIVITYBYID))
            {
                AddParameters(cmd, pInt64(Activity.Property_ID, ID));

                return GetObject(cmd);
            }
        }      

        /// <summary>
        /// Retrieves all Activity objects 
        /// </summary>
        /// <returns>A list of Activity objects</returns>
		public ActivityList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLACTIVITY ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}
        /// <summary>
        /// Retrieves all Deleted Activity objects 
        /// </summary>
        /// <returns>A list of Deleted Activity objects</returns>
        public ActivityList GetAllDeleted()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLDELETEDACTIVITY))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Activity object
        /// </summary>
        /// <param name="activityObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ActivityBase activityObject, SqlDataReader reader, int start )
		{
			activityObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			activityObject.ID = reader.GetInt64(start + 0);
			activityObject.ActivityTypeID = reader.GetInt64(start + 1);
			activityObject.Name = ReverseToHTMLCode(reader.GetString(start + 2));
            activityObject.IsActivate = reader.GetBoolean(start + 9);
			if (!reader.IsDBNull(start + 3)) activityObject.Description = ReverseToHTMLCode(reader.GetString(start + 3));
			FillBaseObject(activityObject, reader, (start + 4));
		}

        protected void FillObject_View(ActivityBase activityObject, SqlDataReader reader)
        {
            activityObject.ID = reader.GetInt64(0);
            activityObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

		protected void FillObject( ActivityBase activityObject, SqlDataReader reader )
		{
			FillObject( activityObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Activity object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Activity object</returns>
		private Activity GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Activity activityObject= new Activity();
					FillObject( activityObject, reader );
					return activityObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Activity objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Activity objects</returns>
        private ActivityList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ActivityList list = new ActivityList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Activity activityObject = new Activity();
                    FillObject(activityObject, reader);

                    list.Add(activityObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        private ActivityList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ActivityList list = new ActivityList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Activity activityObject = new Activity();
                    FillObject_View(activityObject, reader);

                    list.Add(activityObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

	}
}

