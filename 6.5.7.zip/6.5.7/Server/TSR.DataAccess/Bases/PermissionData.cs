using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PermissionData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Permission;

		private const string INSERTPERMISSION = "InsertPermission";
		private const string UPDATEPERMISSION = "UpdatePermission";
		private const string DELETEPERMISSION = "DeletePermission";
		private const string GETPERMISSIONBYID = "GetPermissionByID";
		private const string GETALLPERMISSION = "GetAllPermission";

        #region Constructors

		public PermissionData(UserContext context) : base(context) { LOCK_Permission = this; }
		public PermissionData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Permission = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="permissionObject"></param>
		private void AddCommonParams( SqlCommand cmd, PermissionBase permissionObject )
		{
			AddParameter(cmd, pInt64(PermissionBase.Property_PermissionTypeID, permissionObject.PermissionTypeID));
            AddParameter(cmd, pNVarChar(PermissionBase.Property_PermissionKey, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionObject.PermissionKey));
            AddParameter(cmd, pNVarChar(PermissionBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, permissionObject.Name));
			AddParameter(cmd, pNText(PermissionBase.Property_Description, permissionObject.Description));
			AddParameter(cmd, pBool(PermissionBase.Property_IsUserConfigurable, permissionObject.IsUserConfigurable));
		}

        /// <summary>
        /// Inserts Permission
        /// </summary>
        /// <param name="permissionObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( PermissionBase permissionObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPERMISSION );
	
				AddParameter(cmd, pInt64Out(PermissionBase.Property_ID, permissionObject.ID));
				AddCommonParams( cmd, permissionObject );
				AddBaseParametersForInsert( cmd, permissionObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					permissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, PermissionBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( permissionObject, x );
			}
		}
		
        /// <summary>
        /// Updates Permission 
        /// </summary>
        /// <param name="permissionObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( PermissionBase permissionObject)
		{
            lock (LOCK_Permission)
            {
				try
				{
                    PermissionBase dbObject = Get(permissionObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(permissionObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != permissionObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != permissionObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(permissionObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPERMISSION );

				    AddParameter(cmd, pInt64(PermissionBase.Property_ID, permissionObject.ID));
					AddCommonParams( cmd, permissionObject );
					AddBaseParametersForUpdate( cmd, permissionObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						permissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( permissionObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes Permission
        /// </summary>
        /// <param name="ID">ID of the Permission object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPERMISSION );
	
				AddParameters( cmd, pInt64( Permission.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Permission ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Permission object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Permission object to retrieve</param>
        /// <returns>A Permission object, null if not found</returns>
		public Permission Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPERMISSIONBYID) )
			{
				AddParameters( cmd, pInt64( Permission.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Permission objects 
        /// </summary>
        /// <returns>A list of Permission objects</returns>
		public PermissionList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPERMISSION ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Permission object
        /// </summary>
        /// <param name="permissionObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( PermissionBase permissionObject, SqlDataReader reader, int start )
		{
			permissionObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			permissionObject.ID = reader.GetInt64(start + 0);
			permissionObject.PermissionTypeID = reader.GetInt64(start + 1);
			permissionObject.PermissionKey = ReverseToHTMLCode(reader.GetString(start + 2));
            permissionObject.Name = ReverseToHTMLCode(reader.GetString(start + 3));
			if (!reader.IsDBNull(start + 4)) permissionObject.Description = ReverseToHTMLCode(reader.GetString(start + 4));
			permissionObject.IsUserConfigurable = reader.GetBoolean(start + 5);
			FillBaseObject(permissionObject, reader, (start + 6));
		}

		protected void FillObject( PermissionBase permissionObject, SqlDataReader reader )
		{
			FillObject( permissionObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Permission object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Permission object</returns>
		private Permission GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Permission permissionObject= new Permission();
					FillObject( permissionObject, reader );
					return permissionObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Permission objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Permission objects</returns>
		private PermissionList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			PermissionList list = new PermissionList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Permission permissionObject = new Permission();
					FillObject( permissionObject, reader );

					list.Add( permissionObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

