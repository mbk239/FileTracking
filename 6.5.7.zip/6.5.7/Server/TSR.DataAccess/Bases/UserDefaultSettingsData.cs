﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class UserDefaultSettingsData:BaseDataAccess
    {
        private static BaseDataAccess LOCK_User;
        private const string INSERTUSERDEFAULTSETTING = "InsertUserSetting";
        private const string UPDATEUSERDEFAULTSETTING = "UpdateUserSettings";
        private const string GETUSERDEFAULTSETTINGBYID = "GetUserDefaultSettingByID";
        private const string GETAllUSERDEFAULTSETINGS = "GetAllUserDefaultSettings";
        private const string GETUSERDEFAULTSETTINGBYSETTINGNAME = "GetUserDefaultSettingBySettingName";

        #region Constructors

		public UserDefaultSettingsData(UserContext context) : base(context) { LOCK_User = this; }
        public UserDefaultSettingsData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_User = this; }

        #endregion
        public long Insert(UserDefaultSettingsBase userObject,long? UserID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTUSERDEFAULTSETTING);
                AddParameter(cmd, pInt64Out(UserDefaultSettingsBase.Property_ID,2 ));
                AddCommonParams(cmd, userObject,UserID);
                AddBaseParametersForInsert(cmd, userObject,false);
                long result = InsertRecord(cmd);
                if (result > 0)
                    userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, UserDefaultSettingsBase.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(userObject, x);
            }
        }
        public UserDefaultSetting Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETUSERDEFAULTSETTINGBYID))
            {
                AddParameters(cmd, pInt64(UserDefaultSetting.Property_ID,ID));
                return GetObject(cmd);
            }
        }
        protected void FillObject(UserDefaultSettingsBase userObject, SqlDataReader reader, int start)
        {
            userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            userObject.ID = reader.GetInt64(start + 0);

            if (!(reader.IsDBNull(start + 1))) userObject.UserID = reader.GetInt64(start + 1);
            else
                userObject.UserID = null;

            userObject.SettingsName = ReverseToHTMLCode(reader.GetString(start + 2));

            userObject.SettingsValue = ReverseToHTMLCode(reader.GetString(start + 3));                                                         
            //FillBaseObject(userObject, reader, (start + 4));
        }     

        protected void FillObject(UserDefaultSettingsBase userObject, SqlDataReader reader)
        {
            FillObject(userObject, reader, 0);
        }
        private UserDefaultSetting GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    UserDefaultSetting userObject = new UserDefaultSetting();
                    FillObject(userObject, reader);
                    return userObject;
                }
                else
                {
                    return null;
                }
            }
        }
        /// <summary>
        /// Updates User 
        /// </summary>
        /// <param name="userObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(UserDefaultSettingsBase userObject,long? UserID)
        {
            lock (LOCK_User)
            {
                try
                {                 
                    SqlCommand cmd = GetSPCommand(UPDATEUSERDEFAULTSETTING);
                    AddParameter(cmd, pInt64(UserDefaultSettingsBase.Property_ID, userObject.ID));
                    AddCommonParams(cmd, userObject, UserID);
                    AddBaseParametersForUpdate(cmd, userObject,false);
                    long result = UpdateRecord(cmd);
                    if (result > 0)
                        userObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(userObject, x);
                }
            }
        }
        private void AddCommonParams(SqlCommand cmd, UserDefaultSettingsBase userObject,long? UserID)
        {
            AddParameter(cmd, pInt64(UserDefaultSettingsBase.Property_UserID, UserID));
            AddParameter(cmd, pNText(UserDefaultSettingsBase.Property_SettingsName, userObject.SettingsName));
            AddParameter(cmd, pNText(UserDefaultSettingsBase.Property_SettingsValue, userObject.SettingsValue));            
        }
        public UserDefaultSettingList GetAllDefaultSetting(long? UserID)
        {
            using (SqlCommand cmd = GetSPCommand(GETAllUSERDEFAULTSETINGS))
            {
                AddParameter(cmd, pInt64(UserDefaultSettingsBase.Property_UserID, UserID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }       
        private UserDefaultSettingList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            UserDefaultSettingList list = new UserDefaultSettingList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    UserDefaultSetting userObject = new UserDefaultSetting();
                    FillObject(userObject, reader);

                    list.Add(userObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        public UserDefaultSetting GetUserDefaultSettingBySettingName(string settingName)
        {
            //using (SqlCommand cmd = GetSPCommand(GETUSERDEFAULTSETTINGBYSETTINGNAME))
            //{
            //    AddParameters(cmd, pVarChar(UserDefaultSetting.Property_SettingsName, 255, settingName));
            //    return GetObject(cmd);
            //}

            //because the procedure is not defined
            return null;
        }
    }
}
