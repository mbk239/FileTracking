﻿using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class Address_CommDetailData: BaseRelationData
    {
        private const string INSERTADDRESS_COMMDETAIL = "InsertAddress_CommDetail";
		private const string UPDATEADDRESS_COMMDETAIL = "UpdateAddress_CommDetail";
		private const string DELETEADDRESS_COMMDETAIL = "DeleteAddress_CommDetail";
		private const string GETADDRESS_COMMDETAILBYID = "GetAddress_CommDetailByID";
		private const string GETALLADDRESS_COMMDETAIL = "GetAllAddress_CommDetail";

        #region Constructors

		public Address_CommDetailData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="address_CommDetailObject"></param>
        private void AddCommonParams(SqlCommand cmd, Address_CommDetailBase address_CommDetailObject)
		{
            AddParameter(cmd, pInt64(Address_CommDetailBase.Property_AddressID, address_CommDetailObject.AddressID));
            AddParameter(cmd, pInt64(Address_CommDetailBase.Property_CommDetailID, address_CommDetailObject.CommDetailID));
		}

        /// <summary>
        /// Inserts Address_CommDetail
        /// </summary>
        /// <param name="address_CommDetailObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public long Insert(Address_CommDetailBase address_CommDetailObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTADDRESS_COMMDETAIL );
	
				AddParameter(cmd, pInt64Out(Address_CommDetailBase.Property_ID, address_CommDetailObject.ID));
                AddCommonParams(cmd, address_CommDetailObject);
                AddBaseParametersForInsert(cmd, address_CommDetailObject);

				long result = InsertRecord( cmd );
				if (result > 0)
                    address_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, Organization_CommDetailBase.Property_ID);
			}
			catch( SqlException x )
			{
                throw new Framework.Exceptions.ObjectInsertException(address_CommDetailObject, x);
			}
		}
		
        /// <summary>
        /// Updates Address_CommDetail 
        /// </summary>
        /// <param name="address_CommDetailObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public long Update(Address_CommDetailBase address_CommDetailObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATEADDRESS_COMMDETAIL );

                AddParameter(cmd, pInt64(Address_CommDetailBase.Property_ID, address_CommDetailObject.ID));
                AddCommonParams(cmd, address_CommDetailObject);
                AddBaseParametersForUpdate(cmd, address_CommDetailObject);
	
				long result = UpdateRecord( cmd );
				if (result > 0)
                    address_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
                throw new Framework.Exceptions.ObjectUpdateException(address_CommDetailObject, x);
			}
			
		}

        /// <summary>
        /// Deletes Address_CommDetail
        /// </summary>
        /// <param name="ID">ID of the Address_CommDetail object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEADDRESS_COMMDETAIL );
	
				AddParameters( cmd, pInt64( Address_CommDetail.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Address_CommDetail), ID, x);
			}
			
		}

        /// <summary>
        /// Retrieves Address_CommDetail object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Address_CommDetail object to retrieve</param>
        /// <returns>A Address_CommDetail object, null if not found</returns>
        public Address_CommDetail Get(long ID)
		{
			using( SqlCommand cmd = GetSPCommand( GETADDRESS_COMMDETAILBYID) )
			{
                AddParameters(cmd, pInt64(Address_CommDetail.Property_ID, ID));

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Address_CommDetail objects 
        /// </summary>
        /// <returns>A list of Address_CommDetail objects</returns>
        public Address_CommDetailList GetAll()
		{
			using( SqlCommand cmd = GetSPCommand( GETALLADDRESS_COMMDETAIL ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Address_CommDetail object
        /// </summary>
        /// <param name="address_CommDetailObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
        protected void FillObject(Address_CommDetailBase address_CommDetailObject, SqlDataReader reader, int start)
		{
            address_CommDetailObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            address_CommDetailObject.ID = reader.GetInt64(start + 0);
            address_CommDetailObject.AddressID = reader.GetInt64(start + 1);
            address_CommDetailObject.CommDetailID = reader.GetInt64(start + 2);
            FillBaseObject(address_CommDetailObject, reader, (start + 3));
		}

        protected void FillObject(Address_CommDetailBase address_CommDetailObject, SqlDataReader reader)
		{
            FillObject(address_CommDetailObject, reader, 0);
		}

        /// <summary>
        /// Retrieves Address_CommDetail object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Address_CommDetail object</returns>
        private Address_CommDetail GetObject(SqlCommand cmd)
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
                    Address_CommDetail address_CommDetailObject = new Address_CommDetail();
                    FillObject(address_CommDetailObject, reader);
                    return address_CommDetailObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Address_CommDetail objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Address_CommDetail objects</returns>
        private Address_CommDetailList GetList(SqlCommand cmd, long rows)
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
            Address_CommDetailList list = new Address_CommDetailList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
                    Address_CommDetail address_CommDetailObject = new Address_CommDetail();
                    FillObject(address_CommDetailObject, reader);

                    list.Add(address_CommDetailObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}
    }
}
