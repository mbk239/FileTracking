using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class TaskData : BaseDataAccess
	{
		private const string INSERTTASK = "InsertTask";
		private const string UPDATETASK = "UpdateTask";
		private const string DELETETASK = "DeleteTask";
		private const string GETTASKBYID = "GetTaskByID";
		private const string GETALLTASK = "GetAllTask";

        #region Constructors

		public TaskData(UserContext context) : base(context) { }
		public TaskData(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="taskObject"></param>
		private void AddCommonParams( SqlCommand cmd, TaskBase taskObject )
		{
			AddParameter(cmd, pNVarChar(TaskBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, taskObject.Name));
			AddParameter(cmd, pText(TaskBase.Property_Description, taskObject.Description));
		}

        /// <summary>
        /// Inserts Task
        /// </summary>
        /// <param name="taskObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( TaskBase taskObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTTASK );
	
				AddParameter(cmd, pInt64Out(TaskBase.Property_ID, taskObject.ID));
				AddCommonParams( cmd, taskObject );
				AddBaseParametersForInsert( cmd, taskObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					taskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, TaskBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( taskObject, x );
			}
		}
		
        /// <summary>
        /// Updates Task 
        /// </summary>
        /// <param name="taskObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( TaskBase taskObject)
		{
			try
			{
				SqlCommand cmd = GetSPCommand( UPDATETASK );

				AddParameter(cmd, pInt64(TaskBase.Property_ID, taskObject.ID));
				AddCommonParams( cmd, taskObject );
				AddBaseParametersForUpdate( cmd, taskObject );
	
				long result = UpdateRecord( cmd );
				if (result > 0)
					taskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return result;
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectUpdateException( taskObject, x );
			}
			
		}

        /// <summary>
        /// Deletes Task
        /// </summary>
        /// <param name="ID">ID of the Task object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETETASK );
	
				AddParameters( cmd, pInt64( Task.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Task ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Task object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Task object to retrieve</param>
        /// <returns>A Task object, null if not found</returns>
		public Task Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETTASKBYID) )
			{
				AddParameters( cmd, pInt64( Task.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all Task objects 
        /// </summary>
        /// <returns>A list of Task objects</returns>
		public TaskList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLTASK ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills Task object
        /// </summary>
        /// <param name="taskObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( TaskBase taskObject, SqlDataReader reader, int start )
		{
			taskObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			taskObject.ID = reader.GetInt64(start + 0);
			taskObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) taskObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			FillBaseObject(taskObject, reader, (start + 3));
		}

		protected void FillObject( TaskBase taskObject, SqlDataReader reader )
		{
			FillObject( taskObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Task object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Task object</returns>
		private Task GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Task taskObject= new Task();
					FillObject( taskObject, reader );
					return taskObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Task objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Task objects</returns>
		private TaskList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			TaskList list = new TaskList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Task taskObject = new Task();
					FillObject( taskObject, reader );

					list.Add( taskObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

	}
}

