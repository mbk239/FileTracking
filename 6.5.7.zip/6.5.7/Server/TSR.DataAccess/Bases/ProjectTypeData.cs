using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ProjectTypeData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_ProjectType;

		private const string INSERTPROJECTTYPE = "InsertProjectType";
		private const string UPDATEPROJECTTYPE = "UpdateProjectType";
		private const string DELETEPROJECTTYPE = "DeleteProjectType";
		private const string GETPROJECTTYPEBYID = "GetProjectTypeByID";
		private const string GETALLPROJECTTYPE = "GetAllProjectType";
        private const string GETPROJECTTYPE_PAGING = "GetProjectTypeForPaging";

        #region Constructors

		public ProjectTypeData(UserContext context) : base(context) { LOCK_ProjectType = this; }
		public ProjectTypeData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_ProjectType = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="projectTypeObject"></param>
		private void AddCommonParams( SqlCommand cmd, ProjectTypeBase projectTypeObject )
		{
            AddParameter(cmd, pNVarChar(ProjectTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, projectTypeObject.Name));
			AddParameter(cmd, pNText(ProjectTypeBase.Property_Description, projectTypeObject.Description));
			AddParameter(cmd, pBool(ProjectTypeBase.Property_ReadOnly, projectTypeObject.ReadOnly));
		}

        /// <summary>
        /// Inserts ProjectType
        /// </summary>
        /// <param name="projectTypeObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ProjectTypeBase projectTypeObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPROJECTTYPE );
	
				AddParameter(cmd, pInt64Out(ProjectTypeBase.Property_ID, projectTypeObject.ID));
				AddCommonParams( cmd, projectTypeObject );
				AddBaseParametersForInsert( cmd, projectTypeObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					projectTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ProjectTypeBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( projectTypeObject, x );
			}
		}
		
        /// <summary>
        /// Updates ProjectType 
        /// </summary>
        /// <param name="projectTypeObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ProjectTypeBase projectTypeObject)
		{
            lock (LOCK_ProjectType)
            {
				try
				{
                    ProjectTypeBase dbObject = Get(projectTypeObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(projectTypeObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != projectTypeObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != projectTypeObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectTypeObject, null);

					SqlCommand cmd = GetSPCommand( UPDATEPROJECTTYPE );

				AddParameter(cmd, pInt64(ProjectTypeBase.Property_ID, projectTypeObject.ID));
					AddCommonParams( cmd, projectTypeObject );
					AddBaseParametersForUpdate( cmd, projectTypeObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						projectTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( projectTypeObject, x );
				}
			}
		}

        /// <summary>
        /// Deletes ProjectType
        /// </summary>
        /// <param name="ID">ID of the ProjectType object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECTTYPE );
	
				AddParameters( cmd, pInt64( ProjectType.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( ProjectType ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves ProjectType object using it's ID
        /// </summary>
        /// <param name="ID">The id of the ProjectType object to retrieve</param>
        /// <returns>A ProjectType object, null if not found</returns>
		public ProjectType Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPROJECTTYPEBYID) )
			{
				AddParameters( cmd, pInt64( ProjectType.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves all ProjectType objects 
        /// </summary>
        /// <returns>A list of ProjectType objects</returns>
		public ProjectTypeList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPROJECTTYPE ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}

        /// <summary>
        /// Fills ProjectType object
        /// </summary>
        /// <param name="projectTypeObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ProjectTypeBase projectTypeObject, SqlDataReader reader, int start )
		{
			projectTypeObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

			projectTypeObject.ID = reader.GetInt64(start + 0);
			projectTypeObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
			if (!reader.IsDBNull(start + 2)) projectTypeObject.Description = ReverseToHTMLCode(reader.GetString(start + 2));
			projectTypeObject.ReadOnly = reader.GetBoolean(start + 3);
			FillBaseObject(projectTypeObject, reader, (start + 4));
		}

        protected void FillObject_View(ProjectTypeBase projectTypeObject, SqlDataReader reader)
        {
            projectTypeObject.ID = reader.GetInt64(0);
            projectTypeObject.Name = ReverseToHTMLCode(reader.GetString(1));
        }

		protected void FillObject( ProjectTypeBase projectTypeObject, SqlDataReader reader )
		{
			FillObject( projectTypeObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves ProjectType object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>ProjectType object</returns>
		private ProjectType GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					ProjectType projectTypeObject= new ProjectType();
					FillObject( projectTypeObject, reader );
					return projectTypeObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of ProjectType objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of ProjectType objects</returns>
		private ProjectTypeList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ProjectTypeList list = new ProjectTypeList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					ProjectType projectTypeObject = new ProjectType();
					FillObject( projectTypeObject, reader );

					list.Add( projectTypeObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private ProjectTypeList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ProjectTypeList list = new ProjectTypeList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    ProjectType projectTypeObject = new ProjectType();
                    FillObject_View(projectTypeObject, reader);

                    list.Add(projectTypeObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        public ProjectTypeList GetProjectTypePaging(int startOffset, int numberOfItems, string name, out int total)
        {
            ProjectTypeList lst = new ProjectTypeList();
            using (SqlCommand cmd = GetSPCommand(GETPROJECTTYPE_PAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);   
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);
                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }
    }
}

