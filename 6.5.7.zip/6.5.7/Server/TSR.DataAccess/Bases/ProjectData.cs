using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class ProjectData : BaseDataAccess
	{
        private static BaseDataAccess LOCK_Project;

		private const string INSERTPROJECT = "InsertProject";
		private const string UPDATEPROJECT = "UpdateProject";
		private const string DELETEPROJECT = "DeleteProject";
		private const string GETPROJECTBYID = "GetProjectByID";
		private const string GETALLPROJECT = "GetAllProject";
        private const string GETALLPROJECT_VIEW = "GetAllProject_View";
        private const string GETDELETEDPROJECTBYID = "GetDeletedProjectByID";
        private const string GETALLDELETEDPROJECT = "GetAllDeletedProject";
        private const string UPDATEMODIFIEDTIMESTAMPFORPROJECTS = "UpdateModifiedTimeStampForProjects";
        private const string GETALLPROJECTCUSTOMIZED = "GetAllProjectCustomized";
        private const string GETALLPROJECTCUSTOMIZEDBYORG = "GetAllProjectCustomizedByOrg";
        private const string GETALLPROJECTFORUSERCURRENT = "GetAllProjectForUserCurrent";

        private const string GETALLPROJECTFOREXPORT = "GetAllProjectForExport";

        private const string UPDATERATEPROJECT = "UpdateRateTypeOfProject";

        #region Constructors

		public ProjectData(UserContext context) : base(context) { LOCK_Project = this; }
		public ProjectData(SqlTransaction transaction, UserContext context) : base(transaction, context) { LOCK_Project = this; }

        #endregion

        /// <summary>
        /// Add common parameters before calling a procedure
        /// </summary>
        /// <param name="cmd">command object, where parameters will be added</param>
        /// <param name="projectObject"></param>
		private void AddCommonParams( SqlCommand cmd, ProjectBase projectObject )
		{
			AddParameter(cmd, pInt64(ProjectBase.Property_ProjectTypeID, projectObject.ProjectTypeID));
			AddParameter(cmd, pInt64(ProjectBase.Property_OrganizationID, projectObject.OrganizationID));
            AddParameter(cmd, pNVarChar(ProjectBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, projectObject.Name));
			AddParameter(cmd, pNText(ProjectBase.Property_Description, projectObject.Description));
			AddParameter(cmd, pDateTime(ProjectBase.Property_StartDate, projectObject.StartDate));
			AddParameter(cmd, pDateTime(ProjectBase.Property_EndDate, projectObject.EndDate));
			AddParameter(cmd, pInt64(ProjectBase.Property_ProjectManagerID, projectObject.ProjectManagerID));
			AddParameter(cmd, pInt32(ProjectBase.Property_ApprovalOption, projectObject.ApprovalOption));
			AddParameter(cmd, pInt64(ProjectBase.Property_ApprovalOverriderID, projectObject.ApprovalOverriderID));
			AddParameter(cmd, pInt64(ProjectBase.Property_WorkflowID, projectObject.WorkflowID));
            if (projectObject.MaxHours.HasValue) AddParameter(cmd, pFloat(ProjectBase.Property_MaxHours, projectObject.MaxHours.Value));
            if (projectObject.MinHours.HasValue) AddParameter(cmd, pFloat(ProjectBase.Property_MinHours, projectObject.MinHours.Value));
            AddParameter(cmd, pBool(ProjectBase.Property_UseManagers, projectObject.UseManagers));
        }

        /// <summary>
        /// Inserts Project
        /// </summary>
        /// <param name="projectObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
		public long Insert( ProjectBase projectObject )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( INSERTPROJECT );
	
				AddParameter(cmd, pInt64Out(ProjectBase.Property_ID, projectObject.ID));
				AddCommonParams( cmd, projectObject );
				AddBaseParametersForInsert( cmd, projectObject );

				long result = InsertRecord( cmd );
				if (result > 0)
					projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
				return (long)GetOutParameter(cmd, ProjectBase.Property_ID);
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectInsertException( projectObject, x );
			}
		}

        /// <summary>
        /// Inserts Project
        /// </summary>
        /// <param name="projectObject">Object to be inserted</param>
        /// <returns>Number of rows affected</returns>
        public string InsertForImport(ProjectBase projectObject, out long id)
        {
            id = 0;
            string error = string.Empty;
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTPROJECT);

                AddParameter(cmd, pInt64Out(ProjectBase.Property_ID, projectObject.ID));
                AddCommonParams(cmd, projectObject);
                AddBaseParametersForInsert(cmd, projectObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                if ((long)GetOutParameter(cmd, ProjectBase.Property_ID) > 0)
                {
                    id = (long)GetOutParameter(cmd, ProjectBase.Property_ID);                    
                }
                else
                    error = "No record is inserted";
            }
            catch (SqlException x)
            {
                error = x.Message;
            }
            return error;
        }

        /// <summary>
        /// Updates Project 
        /// </summary>
        /// <param name="projectObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
		public long Update( ProjectBase projectObject)
		{
            lock (LOCK_Project)
            {
				try
				{
                    ProjectBase dbObject = Get(projectObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(projectObject, null);
                    else if (dbObject.ModifiedTimeStamp.ToString() != projectObject.ModifiedTimeStamp.ToString()) //(dbObject.ModifiedTimeStamp != projectObject.ModifiedTimeStamp)
                        throw new Framework.Exceptions.DataIntegrityFailedException(projectObject, null);

                    dbObject.CloneBase(projectObject);

					SqlCommand cmd = GetSPCommand( UPDATEPROJECT );

				    AddParameter(cmd, pInt64(ProjectBase.Property_ID, projectObject.ID));
					AddCommonParams( cmd, projectObject );
					AddBaseParametersForUpdate( cmd, projectObject );
		
					long result = UpdateRecord( cmd );
					if (result > 0)
						projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
					return result;
				}
				catch( SqlException x )
				{
					throw new Framework.Exceptions.ObjectUpdateException( projectObject, x );
				}
			}
		}
        public long UpdateRateTypeOfProject(ProjectBase projectObject)
        {
            lock (LOCK_Project)
            {
                try
                {
                    SqlCommand cmd = GetSPCommand(UPDATERATEPROJECT);
                    AddParameter(cmd, pInt64(ProjectBase.Property_ID, projectObject.ID));
                    if (projectObject.RateType.HasValue) AddParameter(cmd, pFloat(ProjectBase.Property_RateType, projectObject.RateType.Value));
                    else return 1;

                    long result = ExecuteCommand(cmd); 
                    return result;
                }
                catch(SqlException ex)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(projectObject, ex);
                }
            }
        }
        /// <summary>
        /// Updates Project 
        /// </summary>
        /// <param name="projectObject">Object to be updated</param>
        /// <returns>Number of rows affected</returns>
        public string UpdateForImport(ProjectBase projectObject)
        {
            lock (LOCK_Project)
            {
                try
                {
                    ProjectBase dbObject = Get(projectObject.ID);
                    if (dbObject == null)
                        throw new Framework.Exceptions.ObjectUpdateException(projectObject, null);                    

                    SqlCommand cmd = GetSPCommand(UPDATEPROJECT);

                    AddParameter(cmd, pInt64(ProjectBase.Property_ID, projectObject.ID));
                    AddCommonParams(cmd, projectObject);
                    AddBaseParametersForUpdate(cmd, projectObject);

                    long result = UpdateRecord(cmd);
                    if (result > 0)
                    {
                        projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                        return string.Empty;
                    }
                    else                        
                        return  "No record is updated";
                    
                }
                catch (SqlException x)
                {
                    return x.Message;
                }
            }
        }

        /// <summary>
        /// Deletes Project
        /// </summary>
        /// <param name="ID">ID of the Project object that will be deleted</param>
        /// <returns>Number of rows affected</returns>
		public long Delete( long ID )
		{
			try
			{
				SqlCommand cmd = GetSPCommand( DELETEPROJECT );
	
				AddParameters( cmd, pInt64( Project.Property_ID, ID ) );

				return DeleteRecord( cmd );
			}
			catch( SqlException x )
			{
				throw new Framework.Exceptions.ObjectDeleteException( typeof( Project ), ID, x );
			}
			
		}

        /// <summary>
        /// Retrieves Project object using it's ID
        /// </summary>
        /// <param name="ID">The id of the Project object to retrieve</param>
        /// <returns>A Project object, null if not found</returns>
		public Project Get( long ID )
		{
			using( SqlCommand cmd = GetSPCommand( GETPROJECTBYID) )
			{
				AddParameters( cmd, pInt64( Project.Property_ID, ID ) );

				return GetObject(cmd);
			}
		}

        /// <summary>
        /// Retrieves Deleted Project object using it's ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Project GetDeleted(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETDELETEDPROJECTBYID))
            {
                AddParameters(cmd, pInt64(Organization.Property_ID, ID));

                return GetObject(cmd);
            }
        }
        /// <summary>
        /// Retrieves all Project objects 
        /// </summary>
        /// <returns>A list of Project objects</returns>
		public ProjectList GetAll( )
		{
			using( SqlCommand cmd = GetSPCommand( GETALLPROJECT ) )
			{
				return GetList( cmd, ALL_AVAILABLE_RECORDS );
			}
		}        

        public ProjectList GetAll_View()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLPROJECT_VIEW))
            {
                return GetList_View(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        public ProjectList GetAllForUser(long userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLPROJECTFORUSERCURRENT))
            {
                AddParameter(cmd, pInt64("UserID", userID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Retrieves all Deleted Project objects 
        /// </summary>
        /// <returns>A list of Deleted Project objects</returns>
        public ProjectList GetAllDeleted()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLDELETEDPROJECT))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        /// <summary>
        /// Fills Project object
        /// </summary>
        /// <param name="projectObject">The object to be filled</param>
        /// <param name="reader">The reader to use to fill a single object</param>
        /// <param name="start">The ordinal position from which to start reading the reader</param>
		protected void FillObject( ProjectBase projectObject, SqlDataReader reader, int start )
		{
            projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            projectObject.ID = reader.GetInt64(start + 0);
            projectObject.ProjectTypeID = reader.GetInt64(start + 1);
            projectObject.OrganizationID = reader.GetInt64(start + 2);
            projectObject.Name = ReverseToHTMLCode(reader.GetString(start + 3));
            if (!reader.IsDBNull(start + 4)) projectObject.Description = ReverseToHTMLCode(reader.GetString(start + 4));
            projectObject.StartDate = reader.GetDateTime(start + 5);
            if (!reader.IsDBNull(start + 6)) projectObject.EndDate = reader.GetDateTime(start + 6);
            projectObject.ProjectManagerID = reader.GetInt64(start + 7);
            if (!reader.IsDBNull(start + 8)) projectObject.ApprovalOption = reader.GetInt32(start + 8);
            if (!reader.IsDBNull(start + 9)) projectObject.ApprovalOverriderID = reader.GetInt64(start + 9);
            if (!reader.IsDBNull(start + 10)) projectObject.WorkflowID = reader.GetInt64(start + 10);
            if (!reader.IsDBNull(start + 11)) projectObject.MaxHours = reader.GetDouble(start + 11);
            if (!reader.IsDBNull(start + 12)) projectObject.MinHours = reader.GetDouble(start + 12);

            FillBaseObject(projectObject, reader, (start + 13));

            if (projectObject.CustomProperties != null &&
                projectObject.CustomProperties[ProjectBase.Property_UseManagers] != null)
            {
                projectObject.UseManagers = bool.Parse(projectObject.CustomProperties[ProjectBase.Property_UseManagers].ToString());

                if (reader.GetBoolean(start + 17))
                {
                    projectObject.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                }
                else
                    projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            }
		}

        /// <summary>
        /// Only fill the fields needed to view on the grid view control
        /// </summary>
        /// <param name="projectObject"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObjectForGridView(Project projectObject, SqlDataReader reader, int start)
        {
            projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            projectObject.ID = reader.GetInt64(start + 0);
            projectObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            projectObject.StartDate = reader.GetDateTime(start + 2);
            if (!reader.IsDBNull(start + 3)) projectObject.EndDate = reader.GetDateTime(start + 3);
            if (!reader.IsDBNull(start + 4)) projectObject.ProjectTypeName = ReverseToHTMLCode(reader.GetString(start + 4));
            if (!reader.IsDBNull(start + 5)) projectObject.OrganizationName = ReverseToHTMLCode(reader.GetString(start + 5));
            if (!reader.IsDBNull(start + 6)) projectObject.ProjectManagerName = ReverseToHTMLCode(reader.GetString(start + 6));
            //FillBaseObject(projectObject, reader, (start + 13));
        }

        /// <summary>
        /// Only fill two fields ID and Name to show on the Dropdownlist control
        /// </summary>
        /// <param name="projectObject"></param>
        /// <param name="reader"></param>
        /// <param name="start"></param>
        protected void FillObject_View(ProjectBase projectObject, SqlDataReader reader, int start)
        {
            //projectObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

            projectObject.ID = reader.GetInt64(start + 0);
            //projectObject.ProjectTypeID = reader.GetInt64(start + 1);
            //projectObject.OrganizationID = reader.GetInt64(start + 2);
            projectObject.Name = ReverseToHTMLCode(reader.GetString(start + 1));
            //if (!reader.IsDBNull(start + 4)) projectObject.Description = ReverseToHTMLCode(reader.GetString(start + 4));
            //projectObject.StartDate = reader.GetDateTime(start + 5);
            //if (!reader.IsDBNull(start + 6)) projectObject.EndDate = reader.GetDateTime(start + 6);
            //projectObject.ProjectManagerID = reader.GetInt64(start + 7);
            //if (!reader.IsDBNull(start + 8)) projectObject.ApprovalOption = reader.GetInt32(start + 8);
            //if (!reader.IsDBNull(start + 9)) projectObject.ApprovalOverriderID = reader.GetInt64(start + 9);
            //if (!reader.IsDBNull(start + 10)) projectObject.WorkflowID = reader.GetInt64(start + 10);
            //if (!reader.IsDBNull(start + 11)) projectObject.MaxHours = reader.GetDouble(start + 11);
            //if (!reader.IsDBNull(start + 12)) projectObject.MinHours = reader.GetDouble(start + 12);
            //FillBaseObject(projectObject, reader, (start + 13));
        }

		protected void FillObject( ProjectBase projectObject, SqlDataReader reader )
		{
			FillObject( projectObject, reader, 0 );
		}

        /// <summary>
        /// Retrieves Project object from SqlCommand, after database query
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <returns>Project object</returns>
		private Project GetObject( SqlCommand cmd )
		{
			SqlDataReader reader;
			long rows = SelectRecords( cmd, out reader );

			using( reader )
			{
				if( reader.Read() )
				{
					Project projectObject= new Project();
					FillObject( projectObject, reader );
					return projectObject;
				}
				else
				{
					return null;
				}				
			}
		}

        /// <summary>
        /// Retrieves list of Project objects from SqlCommand, after database query
        /// number of rows retrieved and returned depends upon the rows field value
        /// </summary>
        /// <param name="cmd">The command object to use for query</param>
        /// <param name="rows">Number of rows to process</param>
        /// <returns>A list of Project objects</returns>
		private ProjectList GetList( SqlCommand cmd, long rows )
		{
			// Select multiple records
			SqlDataReader reader;
			long result = SelectRecords( cmd, out reader );

			// Contruct list
			ProjectList list = new ProjectList();

			using( reader )
			{
				// Read rows until end of result or number of rows specified is reached
				while( reader.Read() && rows-- != 0 )
				{
					Project projectObject = new Project();
					FillObject( projectObject, reader );

					list.Add( projectObject);
				}
				
				// Close the reader in order to receive output parameters
				// Output parameters are not available until reader is closed.
				reader.Close();
			}

			return list;
		}

        private ProjectList GetList_View(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ProjectList list = new ProjectList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Project projectObject = new Project();
                    FillObject_View(projectObject, reader, 0);

                    list.Add(projectObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        private ProjectList GetListForGridView(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            ProjectList list = new ProjectList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    Project projectObject = new Project();
                    FillObjectForGridView(projectObject, reader, 0);

                    list.Add(projectObject);
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }

            return list;
        }

        public bool UpdateModifiedTimeStampOnProjects(long usergroupID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(UPDATEMODIFIEDTIMESTAMPFORPROJECTS);
                AddParameters(cmd, pInt64("UserGroupId", usergroupID));
                return DeleteRecord(cmd) >= 0;
            }
            catch
            {
                return false;
            }
        }
    }
}

