using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using System.Collections.Generic;
using System.Linq;

namespace TSR.DataAccess
{
    /// <summary>
    /// TimeSheetData
    /// </summary>
    public partial class ExpenseSheetData
    {
        private const string GETEXPENSESHEETBYTIMEENTRYID = "GetExpenseSheetByTimeEntryID";
        private const string APPROVEREJECTEXPENSESHEETSFORUSER = "ApproveRejectExpenseSheetsForUser";
        private const string GETEXPENSESHEETBYUSERID_TIMESPAN_CALENDARID = "GetExpenseSheetByUserID_TimeSpan_CalendarID";
        private const string GETALLEXPENSEBYDATE = "GetAllExpensesByDate";
        private const string GETEXPENSESREPORT_BYSEARCHCRITERIA = "GetExpensesReport_BySearchCriteria";
        private const string GETEXPENSESPERSONALREPORT_BYSEARCHCRITERIA = "GetExpensesPersonalReport_BySearchCriteria";
        public const int ENTITY_TYPE_USER_PERSON = 7;
        //private const string GETTIMEENTRIES_FOR_TIMESHEETSUMMARYLIST = "GetTimeEntriesForTimeSheetSummaryList";

        /// <summary>
        /// retrieves timesheet summary by time sheet id
        /// </summary>
        /// <param name="timeSheetID"></param>
        /// <returns></returns>
        public ExpenseSheet GetExpenseSheetByTimeEntryID(Guid timeEntryID)
        {
            using (SqlCommand cmd = GetSPCommand(GETEXPENSESHEETBYTIMEENTRYID))
            {
                AddParameter(cmd, pGuid(ExpenseSheet.Property_TimeEntryID, timeEntryID));

                return GetObject(cmd);
            }
        }

        public ExpenseSheetList GetExpenseSheetsByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp, string calendarID)
        {
            using (SqlCommand cmd = GetSPCommand(GETEXPENSESHEETBYUSERID_TIMESPAN_CALENDARID))
            {
                AddParameter(cmd, pInt64(TimeEntryBase.Property_UserID, userID));
                AddParameter(cmd, pDateTime(TimeEntryBase.Property_StartTimeStamp, startTimeStamp));
                AddParameter(cmd, pDateTime(TimeEntryBase.Property_EndTimeStamp, endTimeStamp));
                AddParameter(cmd, pNVarChar(TimeEntry_OutlookAppointmentBase.Property_CalendarID, 255, calendarID));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

        public long ApproveRejectExpenseSheets(ExpenseApprovalSummary appSumObject, WFAction action)
        {
            lock (LOCK_ExpenseSheet)
            {
                try
                {
                    SqlCommand cmd = GetSPCommand(APPROVEREJECTEXPENSESHEETSFORUSER);

                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ApproverUserID, UserContext.UserID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_OrganizationID, appSumObject.OrganizationID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ProjectID, appSumObject.ProjectID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_ActivityID, appSumObject.ActivityID));
                    AddParameters(cmd, pInt64(ApprovalSummary.Property_UserID, appSumObject.UserID));
                    AddParameters(cmd, pDateTime(ApprovalSummary.Property_StartTimeStamp, appSumObject.StartTimeStamp));
                    AddParameters(cmd, pDateTime(ApprovalSummary.Property_EndTimeStamp, appSumObject.EndTimeStamp));
                    StatusEnum status = (action == WFAction.Approve) ? StatusEnum.Approved : StatusEnum.Rejected;
                    AddParameters(cmd, pInt32(ApprovalSummary.Property_Status, (int)status));

                    long result = UpdateRecord(cmd);
                    return result;
                }
                catch (SqlException x)
                {
                    throw x;
                }
            }
        }

        #region reporting
        public ExpenseReportUserList GetAllExpenseByDate(DateTime startDate, DateTime endDate)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLEXPENSEBYDATE))
            {
                SqlParameter parameter = cmd.Parameters.Add("@StartDate", System.Data.SqlDbType.DateTime);
                parameter.Value = startDate;
                parameter.Direction = ParameterDirection.Input;

                parameter = cmd.Parameters.Add("@EndDate", System.Data.SqlDbType.DateTime);
                parameter.Value = endDate;
                parameter.Direction = ParameterDirection.Input;

                SqlDataReader reader;
                long rows = SelectRecords(cmd, out reader);
                ExpenseReportUserList list = new ExpenseReportUserList();
                long userId = 0;
                long oldId = 0;
                var userName = "";
                ExpenseReportUser user = new ExpenseReportUser();
                user.StartDate = startDate;
                user.EndDate = endDate;
                using (reader)
                {
                    while (reader.Read())
                    {
                        ExpenseReport expenseReportObject = new ExpenseReport();
                        userId = reader.GetInt64(0);

                        expenseReportObject.StartDate = reader.GetDateTime(1);
                        expenseReportObject.EndDate = reader.GetDateTime(2);
                        expenseReportObject.StartTime = expenseReportObject.StartDate.ToString("t");
                        expenseReportObject.EndTime = expenseReportObject.EndDate.ToString("t");
                        expenseReportObject.ExpenseType = reader.GetString(3);
                        expenseReportObject.Text = reader.GetString(4);
                        expenseReportObject.Quantity = reader.GetDecimal(5);
                        expenseReportObject.Value = reader.GetDecimal(6);
                        expenseReportObject.Total = reader.GetDecimal(7);
                        userName = reader.GetString(8);
                        expenseReportObject.Organization = reader.GetString(9);
                        expenseReportObject.Project = reader.GetString(10);
                        expenseReportObject.Location = reader.GetString(11);

                        if (oldId != 0 && oldId != userId)
                        {
                            CalculateSubTotal(oldId, user);
                            list.Users.Add(user);

                            user = new ExpenseReportUser();
                            user.StartDate = startDate;
                            user.EndDate = endDate;
                        }

                        //user.UserName = userName;
                        user.Specifications.Add(expenseReportObject);
                        oldId = userId;
                    }

                    user.UserName = userName;
                    CalculateSubTotal(userId, user);
                    list.Users.Add(user);
                }

                return list;
            }
        }

        public ExpenseReportUserList GetExpensesReport_BySearchCriteria(DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID,
               long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, int? timeStatus, bool isPersonalReport, int? outOfOfficeID)
        {
            ExpenseReportUserList report = new ExpenseReportUserList();
            SqlDataReader reader;

            DateTime startTime = startTimeStamp.HasValue ? startTimeStamp.Value : DateTime.MinValue;
            DateTime endTime = endTimeStamp.HasValue ? (DateTime.MaxValue.Subtract(endTimeStamp.Value).TotalDays > 1 ? endTimeStamp.Value.AddDays(1) : DateTime.MaxValue) : DateTime.MaxValue;

            long orgID = (organizationID.HasValue && organizationID > 0 ? organizationID.Value : -1);
            long projID = (projectID.HasValue && projectID > 0 ? projectID.Value : -1);
            long actID = (activityID.HasValue && activityID > 0 ? activityID.Value : -1);
            long usrGrpID = (userGroupID.HasValue && userGroupID > 0 ? userGroupID.Value : -1);
            long usrID = (userID.HasValue && userID > 0 ? userID.Value : -1);
            long projTypeID = (projectTypeID.HasValue && projectTypeID > 0 ? projectTypeID.Value : -1);
            long actTypeID = (activityTypeID.HasValue && activityTypeID > 0 ? activityTypeID.Value : -1);
            int status = timeStatus.HasValue && timeStatus > 0 ? timeStatus.Value : -1;

            string spQuery = GETEXPENSESREPORT_BYSEARCHCRITERIA;
            if (isPersonalReport)
                spQuery = GETEXPENSESPERSONALREPORT_BYSEARCHCRITERIA;

            using (SqlCommand cmd = GetSPCommand(spQuery))
            {
                AddParameter(cmd, pInt64(TimeEntryReport.Property_UserID, usrID));
                AddParameter(cmd, pInt64("UserGroupID", usrGrpID));
                if (startTime != DateTime.MinValue)
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_StartTimeStamp, startTime));
                else
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_StartTimeStamp, null));
                if (endTime != DateTime.MaxValue)
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_EndTimeStamp, endTime));
                else
                    AddParameter(cmd, pDateTime(TimeEntryReport.Property_EndTimeStamp, null));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_OrganizationID, orgID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ProjectID, projID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ActivityID, actID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ProjectTypeID, projTypeID));
                AddParameter(cmd, pInt64(TimeEntryReport.Property_ActivityTypeID, actTypeID));
                AddParameter(cmd, pInt32(TimeEntryReport.Property_Status, status));
                AddParameter(cmd, pInt32(TimeEntryReport.Property_IsOutOfOffice, outOfOfficeID));

                if (isPersonalReport)
                    AddParameter(cmd, pInt64("CurUserID", UserContext.UserID));

                long result = SelectRecords(cmd, out reader);
                report = FillExpenseReportUser(reader, startTime, endTime.AddDays(-1), usrID);
            }

            if (report.Users.Any())
            {
                foreach (var user in report.Users)
                {
                    using (var data = new UserDetailData(UserContext))
                    {
                        user.Person = data.GetUserDetailsByUserID(user.ID);
                    }
                }
            }

            return report;
        }

        private ExpenseReportUserList FillExpenseReportUser(SqlDataReader reader, DateTime startDate, DateTime endDate, long uId)
        {
            var listReportUser = new ExpenseReportUserList();

            using (reader)
            {
                try
                {
                    long userId = 0;
                    long oldId = 0;
                    var userName = "";
                    var user = new ExpenseReportUser();
                    user.StartDate = startDate;
                    user.EndDate = endDate;

                    while (reader.Read())
                    {
                        var expenseReportObject = new ExpenseReport();

                        userId = reader.GetInt64(0);

                        expenseReportObject.StartDate = reader.GetDateTime(1);
                        expenseReportObject.EndDate = reader.GetDateTime(2);
                        expenseReportObject.StartTime = expenseReportObject.StartDate.ToString("t");
                        expenseReportObject.EndTime = expenseReportObject.EndDate.ToString("t");
                        expenseReportObject.ExpenseType = reader.GetString(3);
                        if (!reader.IsDBNull(4))
                            expenseReportObject.ExpenseForeignkey = reader.GetString(4);
                        else
                            expenseReportObject.ExpenseForeignkey = string.Empty;
                        expenseReportObject.Text = ReverseToHTMLCode(reader.GetString(5));
                        expenseReportObject.Quantity = reader.GetDecimal(6);
                        expenseReportObject.Value = reader.GetDecimal(7);
                        expenseReportObject.Total = reader.GetDecimal(8);
                        expenseReportObject.Organization = reader.GetString(11);
                        expenseReportObject.Project = reader.GetString(12);
                        expenseReportObject.Location = reader.IsDBNull(13) ? string.Empty : reader.GetString(13);
                        userName = reader.GetString(9);

                        if (oldId != 0 && oldId != userId)
                        {
                            CalculateSubTotal(oldId, user);
                            listReportUser.Users.Add(user);

                            user = new ExpenseReportUser();
                            user.UserName = userName;
                            user.StartDate = startDate;
                            user.EndDate = endDate;
                        }

                        user.Specifications.Add(expenseReportObject);
                        user.UserName = userName;
                        user.ID = userId;

                        oldId = userId;
                    }
                    
                    if (!string.IsNullOrEmpty(userName))
                        user.UserName = userName;

                    if (user.Specifications.Any())
                        CalculateSubTotal(userId, user);

                    if (!reader.HasRows && uId > 0)
                    {
                        using (var usrData = new UserData(UserContext))
                        {
                            var usr = usrData.Get(uId);
                            user.UserName = usr.Username;
                        }
                        user.ID = uId;
                    }

                    listReportUser.Users.Add(user);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return listReportUser;
        }

        public void CalculateSubTotal(long userId, ExpenseReportUser user)
        {
            try
            {
                User usr = null;
                Person p = null;
                using (UserData usrData = new UserData(UserContext))
                {
                    usr = usrData.Get(userId);
                }
                if (usr != null && usr.PersonID.HasValue)
                {
                    using (PersonData personData = new PersonData(UserContext))
                    {
                        p = personData.Get(usr.PersonID.Value);
                    }
                }
                DBRMappingTable proData = null;
                using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
                {
                    proData = data.GetByDestinationIDEntityTypeID(userId.ToString(), ENTITY_TYPE_USER_PERSON);

                    if (proData != null)
                    {
                        //foreignKey = proData.SourceID;
                        user.UserForeignKey = proData.SourceID;
                    }
                }

                if (p != null)
                {
                    user.JobTitle = p.JobTitle;
                    user.Department = p.Department;
                    user.FirstName = p.FirstName;
                    user.LastName = p.LastName;
                    user.MiddleName = p.MiddleName;
                    user.UserName = usr.Username;
                    user.CellPhone = p.CellPhone;
                    user.DirectPhone = p.DirectPhone;

                }
                user.ExpenseTotal = user.Specifications.Select(x => x.Total).Aggregate((t1, t2) => t1 + t2);
                var expenses = user.Specifications.OrderBy(x => x.ExpenseType).ToArray();
                string oldExType = "";
                string oldExpenseForeignkey = "";
                decimal totalQuanttity = 0;
                decimal total = 0;
                int count = expenses.Length;
                for (int i = 0; i < count; i++)
                {
                    var ex = expenses[i];
                    if (!string.IsNullOrEmpty(oldExType) && !oldExType.Equals(ex.ExpenseType, StringComparison.OrdinalIgnoreCase) &&
                        !string.IsNullOrEmpty(oldExpenseForeignkey) && !oldExpenseForeignkey.Equals(ex.ExpenseForeignkey, StringComparison.OrdinalIgnoreCase))
                    {
                        ExpenseReportUserSubTotal subTotal = new ExpenseReportUserSubTotal();
                        subTotal.ExpenseType = oldExType;
                        subTotal.Total = total;
                        subTotal.Quantity = totalQuanttity;
                        subTotal.ForeignKey = oldExpenseForeignkey;
                        user.SubTotals.Add(subTotal);
                        totalQuanttity = 0;
                        total = 0;
                    }
                    totalQuanttity += ex.Quantity;
                    total += ex.Total;
                    oldExType = ex.ExpenseType;
                    oldExpenseForeignkey = ex.ExpenseForeignkey;
                }

                ExpenseReportUserSubTotal lastSubTotal = new ExpenseReportUserSubTotal();
                lastSubTotal.ExpenseType = oldExType;
                lastSubTotal.Total = total;
                lastSubTotal.Quantity = totalQuanttity;
                lastSubTotal.ForeignKey = oldExpenseForeignkey;
                user.SubTotals.Add(lastSubTotal);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}

