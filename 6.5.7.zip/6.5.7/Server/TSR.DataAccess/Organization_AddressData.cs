using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Organization_AddressData
    /// </summary>
    public partial class Organization_AddressData
    {
        private const string DELETEORGANIZATIONADDRESS_BY_ORGANIZATION_ADDRESS = "DeleteOrganizationAddressByOrganizationID_AddressID";

        /// <summary>
        /// adds relation between address and organization
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Add(long parentID, long childID)
        {
            Organization_AddressBase obj = new Organization_AddressBase();
            obj.OrganizationID = parentID;
            obj.AddressID = childID;

            return Insert(obj);
        }

        /// <summary>
        /// removes relation between address and organization
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Remove(long parentID, long childID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEORGANIZATIONADDRESS_BY_ORGANIZATION_ADDRESS);

                AddParameters(cmd, pInt64(Organization_Address.Property_OrganizationID, parentID));
                AddParameters(cmd, pInt64(Organization_Address.Property_AddressID, childID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Organization_Address), parentID, x);
            }

        }
    }
}

