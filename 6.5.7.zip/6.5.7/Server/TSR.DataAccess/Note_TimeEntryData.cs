using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class TimeEntry_NoteData
	{
        private const string DELETETIMEENTRYNOTE_BY_TIMEENTRY_NOTE = "DeleteTimeEntryNoteByTimeEntryID_NoteID";

        /// <summary>
        /// add method to add a relation between parent and child [time entry and note]
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public long Add(Guid parentID, long childID)
        {
            TimeEntry_NoteBase obj = new TimeEntry_NoteBase();
            obj.TimeEntryID = parentID;
            obj.NoteID = childID;

            return Insert(obj);
        }

        /// <summary>
        /// removes a relation between time entry and note
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public long Remove(Guid parentID, long childID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETETIMEENTRYNOTE_BY_TIMEENTRY_NOTE);

                AddParameters(cmd, pGuid(TimeEntry_Note.Property_TimeEntryID, parentID));
                AddParameters(cmd, pInt64(TimeEntry_Note.Property_NoteID, childID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Organization_Address), parentID, x);
            }

        }
    }
}

