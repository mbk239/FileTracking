﻿using System;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class LockPeriodData
    {
       
    }
}
