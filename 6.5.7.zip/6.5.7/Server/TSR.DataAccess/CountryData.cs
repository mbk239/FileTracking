using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class CountryData
	{
        private const string GETCOUNTRYBYCOUNTRYNAME = "GetCountryByCountryName";

        /// <summary>
        /// Retrieves Country by Country name
        /// </summary>
        /// <param name="CountryName"></param>
        /// <returns></returns>
        public Country GetCountryByCountryName(string CountryName)
        {
            SqlCommand cmd = GetSPCommand(GETCOUNTRYBYCOUNTRYNAME);
            AddParameters(cmd, pNVarChar(CountryBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, CountryName));
            return GetObject(cmd);
        }
	}
}

