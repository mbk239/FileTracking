﻿using System.Data.SqlClient;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.DataAccess
{
    public class ActivityRateData : BaseDataAccess
    {
        private const string GETACTIVITYRATEBYID = "GetActivityRateByID";
        private const string GETALLACTIVITYRATEBYPROJECTID = "GetAllActivityRateByProjectID";
        private const string UPDATEACTIVITYRATE = "UpdateActivityRate";
        private const string DELETEACTIVITYRATE = "DeleteActivityRate";
        private const string INSERTACTIVITYRATE = "InsertActivityRate";
        private static BaseDataAccess LOCK_ActivityRate;
        public ActivityRateData(UserContext context) : base(context)
        {
            LOCK_ActivityRate = this;
        }

        public ActivityRateData(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
            LOCK_ActivityRate = this;
        }

        #region Fill Data
        public ActivityRateList GetAllActivityRateByProjectID(long projectID)
        {
            SqlCommand cmd = GetSPCommand(GETALLACTIVITYRATEBYPROJECTID);
            AddParameters(cmd, pInt64(ProjectRate.Property_ProjectID, projectID));
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        private ActivityRateList GetList(SqlCommand cmd, long rows)
        {
            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            var list = new ActivityRateList();

            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read() && rows-- != 0)
                {
                    var activityRateObj = new ActivityRate();
                    FillObject(activityRateObj, reader);
                    list.Add(activityRateObj);
                }

                reader.Close();
            }

            return list;
        }
        protected void FillObject(ActivityRate activityRateObj, SqlDataReader reader)
        {
            FillObject(activityRateObj, reader, 0);
        }
        protected void FillObject(ActivityRate activityRateObj, SqlDataReader reader, int start)
        {
            activityRateObj.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
            activityRateObj.ID = reader.GetInt64(start + 0);
            activityRateObj.ActivityID = reader.GetInt64(start + 1);
            activityRateObj.Activity = ReverseToHTMLCode(reader.GetString(start + 2));
            activityRateObj.RateID = reader.GetInt64(start + 3);
            activityRateObj.Cost = reader[start+4]!=null ? reader.GetDecimal(start + 4) : 0;
            activityRateObj.Revenue =reader[start+5] !=null ?  reader.GetDecimal(start + 5) : 0;
            if(reader.FieldCount ==7)
            {
                activityRateObj.ProjectID = reader.GetInt64(start + 6);
               // activityRateObj.ProjectActivtyID = reader[start + 7] != null ? reader.GetInt64(start + 7) : 0;
            }
        
            //FillBaseObject(activityRateObj, reader, (start + 4));
        }
        public ActivityRate Get(long ID)
        {
            using (SqlCommand cmd = GetSPCommand(GETACTIVITYRATEBYID))
            {
                AddParameters(cmd, pInt64(ActivityRate.Property_RateID, ID));
                return GetObject(cmd);
            }
        }
        private ActivityRate GetObject(SqlCommand cmd)
        {
            SqlDataReader reader;
            long rows = SelectRecords(cmd, out reader);

            using (reader)
            {
                if (reader.Read())
                {
                    var activityRate = new ActivityRate();
                    FillObject(activityRate, reader);
                    return activityRate;
                }
                else
                {
                    return null;
                }
            }
        }
        #endregion

        #region Insert Data
        public long Insert(ActivityRate activityRateObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTACTIVITYRATE);

                AddParameter(cmd, pInt64Out(ActivityRate.Property_ID, activityRateObject.ID));
                AddParameter(cmd, pInt64Out(ActivityRate.Property_ID, activityRateObject.ProjectID));
                AddParameter(cmd, pInt64(ActivityRate.Property_ActivityID, activityRateObject.ActivityID));
                AddParameter(cmd, pInt64(ActivityRate.Property_RateID, activityRateObject.RateID));
                AddCommonParams(cmd, activityRateObject);
                AddBaseParametersForInsert(cmd, activityRateObject);

                long result = InsertRecord(cmd);
                if (result > 0)
                    activityRateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                return (long)GetOutParameter(cmd, ActivityRate.Property_ID);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectInsertException(activityRateObject, x);
            }
        }
        #endregion
        #region Update Data
        //public long Update(ActivityRate activityRateObject)
        //{
        //    lock (LOCK_ActivityRate)
        //    {
        //        try
        //        {
        //            var dbObject = Get(activityRateObject.ID);
        //            if (dbObject == null)
        //                throw new Framework.Exceptions.ObjectUpdateException(activityRateObject, null);
        //            else if (dbObject.ModifiedTimeStamp.ToString() != activityRateObject.ModifiedTimeStamp.ToString()) 
        //                throw new Framework.Exceptions.DataIntegrityFailedException(activityRateObject, null);

        //            dbObject.CloneBase(activityRateObject);

        //            SqlCommand cmd = GetSPCommand(UPDATEACTIVITYRATE);


        //            AddParameter(cmd, pInt64(ActivityRate.Property_ID, activityRateObject.ID));
        //            AddCommonParams(cmd, activityRateObject);
        //            AddBaseParametersForUpdate(cmd, activityRateObject);

        //            long result = UpdateRecord(cmd);
        //            if (result > 0)
        //                activityRateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
        //            return result;
        //        }
        //        catch (SqlException x)
        //        {
        //            throw new Framework.Exceptions.ObjectUpdateException(activityRateObject, x);
        //        }
        //    }
        //}
        public long AddOrUpdate(ActivityRate activityRateObject)
        {
            lock (LOCK_ActivityRate)
            {
                try
                {
                    SqlCommand cmd;
                    if (activityRateObject.RateID == 0)
                    {
                        cmd = GetSPCommand(INSERTACTIVITYRATE);

                    }
                    else
                    {
                        var dbObject = Get(activityRateObject.RateID);

                        //if (dbObject == null)
                        //    throw new Framework.Exceptions.ObjectUpdateException(activityRateObject, null);
                        //else if (dbObject.ModifiedTimeStamp.ToString() != activityRateObject.ModifiedTimeStamp.ToString())
                        //    throw new Framework.Exceptions.DataIntegrityFailedException(activityRateObject, null);

                        cmd = GetSPCommand(UPDATEACTIVITYRATE);
                        dbObject.CloneBase(activityRateObject);
                    }
                 
                    AddParameter(cmd, pInt64(ActivityRate.Property_ID, activityRateObject.ID));
                    AddParameter(cmd, pInt64(ActivityRate.Property_ProjectID, activityRateObject.ProjectID));
                    AddParameter(cmd, pInt64(ActivityRate.Property_ActivityID, activityRateObject.ActivityID));
                    AddParameter(cmd, pInt64(ActivityRate.Property_RateID, activityRateObject.RateID));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Cost, activityRateObject.Cost));
                    AddParameter(cmd, pDecimal(ProjectRate.Property_Revenue, activityRateObject.Revenue));

                  //  AddCommonParams(cmd, activityRateObject);

                    if (activityRateObject.RateID == 0)
                        AddBaseParametersForInsert(cmd, activityRateObject);
                    else
                        AddBaseParametersForUpdate(cmd, activityRateObject);

                    long result = ExecuteCommand(cmd);
                    if (result > 0)
                        activityRateObject.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    return result;
                }
                catch (SqlException x)
                {
                    throw new Framework.Exceptions.ObjectUpdateException(activityRateObject, x);
                }
            }
        }
        
        #endregion
        #region Add parametters
        private void AddCommonParams(SqlCommand cmd, RateBase activityObject)
        {
            AddParameter(cmd, pDateTime(RateBase.Property_CreatedTimeStamp, activityObject.CreatedTimeStamp));
            AddParameter(cmd,pInt64(RateBase.Property_ModifierID, activityObject.ModifierID));
        }
        #endregion

        #region Delete Data
        public long Delete(long ID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEACTIVITYRATE);

                AddParameters(cmd, pInt64(ActivityRate.Property_ID, ID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(ActivityRate), ID, x);
            }

        }
        #endregion
    }
}
