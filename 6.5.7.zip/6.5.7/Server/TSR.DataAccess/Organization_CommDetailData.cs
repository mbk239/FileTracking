using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Organization_CommDetailData
    /// </summary>
    public partial class Organization_CommDetailData
    {
        private const string DELETEORGANIZATIONCOMMDETAIL_BY_ORGANIZATION_COMMDETAIL = "DeleteOrganizationCommDetailByOrganizationID_CommDetailID";

        /// <summary>
        /// adds a relation between organization and communication details
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Add(long parentID, long childID)
        {
            Organization_CommDetailBase obj = new Organization_CommDetailBase();
            obj.OrganizationID = parentID;
            obj.CommDetailID = childID;

            return Insert(obj);
        }

        /// <summary>
        /// removes a relation between address and communication details
        /// </summary>
        /// <param name="parentID"></param>
        /// <param name="childID"></param>
        /// <returns></returns>
        public override long Remove(long parentID, long childID)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(DELETEORGANIZATIONCOMMDETAIL_BY_ORGANIZATION_COMMDETAIL);

                AddParameters(cmd, pInt64(Organization_CommDetail.Property_OrganizationID, parentID));
                AddParameters(cmd, pInt64(Organization_CommDetail.Property_CommDetailID, childID));

                return DeleteRecord(cmd);
            }
            catch (SqlException x)
            {
                throw new Framework.Exceptions.ObjectDeleteException(typeof(Organization_CommDetail), parentID, x);
            }

        }
    }
}

