﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Entities.Bases;
using System.Data.SqlClient;
using TSR.Entities;

namespace TSR.DataAccess
{
    public partial class CalenderForUserData
    {
        private const string GETCALENDARBYCALENDARNAME = "GetCalenderByCalenderName";

        /// <summary>
        /// Retrieves Calender by Calender name
        /// </summary>
        /// <param name="CalenderName"></param>
        /// <returns></returns>
        public CalenderForUser GetCalenderByCalenderName(string CalenderName)
        {
            SqlCommand cmd = GetSPCommand(GETCALENDARBYCALENDARNAME);
            AddParameters(cmd, pNVarChar(CalendarForUserBase.Property_CalenderName, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, CalenderName));
            return GetObject(cmd);
        }

    }
}
