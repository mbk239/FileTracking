using System;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework.Resource;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Activity_TaskData
    /// </summary>
	public partial class Activity_TaskData
	{
        public override long Add(long parentID, long childID)
        {     
            throw new Exception(ResourceManager.GetResourceString("TheMethodIsNotImplemented.","The method or operation is not implemented."));
        }
        public override long Remove(long parentID, long childID)
        {
            throw new Exception(ResourceManager.GetResourceString("TheMethodIsNotImplemented.","The method or operation is not implemented."));
        }
    }
}

