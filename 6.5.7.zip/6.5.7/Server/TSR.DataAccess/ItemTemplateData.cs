﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Entities.Bases;
using System.Data.SqlClient;
using TSR.Entities;

namespace TSR.DataAccess
{
    public partial class ItemTemplateData
    {
        private const string GETITEMTEMPLATEBYITEMTEMPLATENAME = "GetItemTemplateByItemTemplateName";

        /// <summary>
        /// Retrieves ItemTemplate by ItemTemplate name
        /// </summary>
        /// <param name="ItemTemplateName"></param>
        /// <returns></returns>
        public ItemTemplate GetItemTemplateByItemTemplateName(string ItemTemplateName)
        {
            SqlCommand cmd = GetSPCommand(GETITEMTEMPLATEBYITEMTEMPLATENAME);
            AddParameters(cmd, pNVarChar(ItemTemplateBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ItemTemplateName));
            return GetObject(cmd);
        }

    }
}
