using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PersonTypeData
	{
        private const string GETPERSONTYPEBYPERSONTYPENAME = "GetPersonTypeByPersonTypeName";

        /// <summary>
        /// Retrieves PersonType by PersonType name
        /// </summary>
        /// <param name="PersonTypeName"></param>
        /// <returns></returns>
        public PersonType GetPersonTypeByPersonTypeName(string PersonTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETPERSONTYPEBYPERSONTYPENAME);
            AddParameters(cmd, pNVarChar(PersonTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, PersonTypeName));
            return GetObject(cmd);
        }
	}
}

