using System;
using System.Collections.Generic;
using System.Text;

namespace TSR.DataAccess
{
    public partial class AppConfigurationData
    {
    }
}
