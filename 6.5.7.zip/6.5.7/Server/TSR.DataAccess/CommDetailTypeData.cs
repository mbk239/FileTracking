using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class CommDetailTypeData
	{
        private const string GETCOMMDETAILTYPEBYCOMMDETAILTYPENAME = "GetCommDetailTypeByCommDetailTypeName";
		

            /// <summary>
        /// Retrieves CommDetailType by CommDetailType name
        /// </summary>
        /// <param name="CommDetailTypeName"></param>
        /// <returns></returns>
        public CommDetailType GetCommDetailTypeByCommDetailTypeName(string CommDetailTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETCOMMDETAILTYPEBYCOMMDETAILTYPENAME);
            AddParameters(cmd, pNVarChar(CommDetailTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, CommDetailTypeName));
            return GetObject(cmd);
        }


	}
}

