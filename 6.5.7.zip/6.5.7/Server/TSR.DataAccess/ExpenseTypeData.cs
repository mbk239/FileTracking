using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// TimeSheetData
    /// </summary>
	public partial class ExpenseTypeData
    {
        private const string GETEXPENSETYPEBYSEARCHTERM = "GetExpenseTypeBySearchTerm";

        /// <summary>
        /// retrieves timesheet summary by time sheet id
        /// </summary>
        /// <param name="timeSheetID"></param>
        /// <returns></returns>
        public ExpenseTypeList GetExpenseTypeBySearchTerm(string searchTerm, bool bShowInactive)
        {
            using (SqlCommand cmd = GetSPCommand(GETEXPENSETYPEBYSEARCHTERM))
            {
                AddParameter(cmd, pNVarChar("SearchTerm",ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, searchTerm));
                AddParameter(cmd, pBool("ShowInactive", bShowInactive));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
	}
}

