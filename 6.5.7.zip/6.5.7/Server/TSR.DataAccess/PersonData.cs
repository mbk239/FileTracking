using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// Person data access.
    /// 
    /// last updated on:
    /// september 4th, 2009
    /// change description:
    /// </summary>
    public partial class PersonData
    {
    }
}

