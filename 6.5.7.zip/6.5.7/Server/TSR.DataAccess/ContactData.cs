using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// ContactData
    /// </summary>
    public partial class ContactData
    {
        private const string GETCONTACTSBYORGANIZATIONID = "GetContactsByOrganizationID";
        private const string GETALLCONTACTVIEW = "GetAllContactView";
        /// <summary>
        /// retrieves contacts by organization
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public ContactList GetContactsByOrganizationID(long organizationID)
        {
            using (SqlCommand cmd = GetSPCommand(GETCONTACTSBYORGANIZATIONID))
            {
                AddParameters(cmd, pInt64(Organization_Contact.Property_OrganizationID, organizationID));
                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }

        }
        /// <summary>
        /// retrieves all contacts view
        /// </summary>        
        /// <returns>ContactViewList</returns>
        public ContactViewList GetAllContactsView()
        {
            ContactViewList list = new ContactViewList();
            using (SqlCommand cmd = GetSPCommand(GETALLCONTACTVIEW))
            {
                SqlDataReader reader;
                long result = SelectRecords(cmd, out reader);
                long rows = ALL_AVAILABLE_RECORDS;
                using (reader)
                {
                    while (reader.Read() && rows-- != 0)
                    {
                        int start = 0;
                        ContactView contactViewObject = new ContactView();
                        contactViewObject.ID = reader.GetInt64(start + 0);
                        if (!reader.IsDBNull(start + 1)) contactViewObject.ContactForeignKey = ReverseToHTMLCode(reader.GetString(start + 1));
                        if (!reader.IsDBNull(start + 2)) contactViewObject.ContactTypeID = (long?)(reader.GetInt64(start + 2));
                        else
                            contactViewObject.ContactTypeID = null;
                        if (!reader.IsDBNull(start + 3)) contactViewObject.ContactTypeName = ReverseToHTMLCode(reader.GetString(start + 3));
                        contactViewObject.PersonID = reader.GetInt64(start + 4);
                        contactViewObject.FirstName = ReverseToHTMLCode(reader.GetString(start + 5));
                        if (!reader.IsDBNull(start + 6)) contactViewObject.LastName = ReverseToHTMLCode(reader.GetString(start + 6));
                        if (!reader.IsDBNull(start + 7)) contactViewObject.MiddleName = ReverseToHTMLCode(reader.GetString(start + 7));                        
                        if (!reader.IsDBNull(start + 8)) contactViewObject.Email = ReverseToHTMLCode(reader.GetString(start + 8));
                        if (!reader.IsDBNull(start + 9)) contactViewObject.DirectPhone = ReverseToHTMLCode(reader.GetString(start + 9));
                        if (!reader.IsDBNull(start + 10)) contactViewObject.CellPhone = ReverseToHTMLCode(reader.GetString(start + 10));
                        if (!reader.IsDBNull(start + 11)) contactViewObject.JobTitle = ReverseToHTMLCode(reader.GetString(start + 11));
                        if (!reader.IsDBNull(start + 12)) contactViewObject.Department = ReverseToHTMLCode(reader.GetString(start + 12));                                                
                        list.Add(contactViewObject);
                    }

                    reader.Close();
                }
            }
            return list;
        }
    }
}

