using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// TimeSheetData
    /// </summary>
	public partial class ExpenseEntryData
    {
        private const string GETAPPROVALEXPENSESUMMARYLIST = "GetApprovalExpenseSummaryList";

        /// <summary>
        /// retrieves expense summary by time sheet id
        /// </summary>
        /// <param name="timeSheetID"></param>
        /// <returns></returns>
        public ExpenseApprovalSummaryList GetApprovalExpenseSummaryList(DateTime startTime, DateTime endTime, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID)
        {
            using (SqlCommand cmd = GetSPCommand(GETAPPROVALEXPENSESUMMARYLIST))
            {
                long orgID = (organizationID.HasValue && organizationID > 0 ? organizationID.Value : -1);
                long projID = (projectID.HasValue && projectID > 0 ? projectID.Value : -1);
                long actID = (activityID.HasValue && activityID > 0 ? activityID.Value : -1);
                long usrGrpID = (userGroupID.HasValue && userGroupID > 0 ? userGroupID.Value : -1);
                long usrID = (userID.HasValue && userID > 0 ? userID.Value : -1);

                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_ApproverUserID, UserContext.UserID));
                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_OrganizationID, orgID));
                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_ProjectID, projID));
                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_ActivityID, actID));
                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_UserGroupID, usrGrpID));
                AddParameters(cmd, pInt64(ExpenseApprovalSummary.Property_UserID, usrID));
                AddParameters(cmd, pDateTime(ExpenseApprovalSummary.Property_StartTimeStamp, startTime));
                AddParameters(cmd, pDateTime(ExpenseApprovalSummary.Property_EndTimeStamp, endTime));

                //return GetList(cmd, ALL_AVAILABLE_RECORDS);
                SqlDataReader reader;
                long result = SelectRecords(cmd, out reader);

                ExpenseApprovalSummaryList list = new ExpenseApprovalSummaryList();
                using (reader)
                {
                    while (reader.Read())
                    {
                        ExpenseApprovalSummary appSumObject = new ExpenseApprovalSummary(orgID, projID, actID, usrGrpID, startTime, endTime);
                        appSumObject.UserID = reader.GetInt64(0);
                        if (!reader.IsDBNull(1)) appSumObject.ExpenseValue = reader.GetDecimal(1);

                        list.Add(appSumObject);
                    }
                    // Close the reader in order to receive output parameters
                    // Output parameters are not available until reader is closed.
                    reader.Close();
                }
                return list;
            }
        }
	}
}

