using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class OrganizationTypeData
	{
        private const string GETORGANIZATIONTYPEBYORGANIZATIONTYPENAME = "GetOrganizationTypeByOrganizationTypeName";

        /// <summary>
        /// Retrieves OrganizationType by OrganizationType name
        /// </summary>
        /// <param name="OrganizationTypeName"></param>
        /// <returns></returns>
        public OrganizationType GetOrganizationTypeByOrganizationTypeName(string OrganizationTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETORGANIZATIONTYPEBYORGANIZATIONTYPENAME);
            AddParameters(cmd, pNVarChar(OrganizationTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, OrganizationTypeName));
            return GetObject(cmd);
        }
	}
}

