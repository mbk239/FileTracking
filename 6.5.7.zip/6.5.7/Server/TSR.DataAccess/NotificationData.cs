﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    public partial class NotificationData
    {
        //private const string GETNOTIFICATIONBYUNIQUEPARAMS = "GetNotificationByUniqueParams";
        private const string GETNOTIFICATIONINFOFORAPPROVER = "GetNotificationInfoForApprover";

        private const string GETNOTIFICATIONBYNOTIFICATIONNAME = "GetNotificationByNotificationName";

      
        //public NotificationList GetProjectsByOrganizationID(long UserID, string Subject, string Body, DateTime StartDate, DateTime EndDate)
        //{
        //    SqlCommand cmd = GetSPCommand(GETNOTIFICATIONBYUNIQUEPARAMS);

        //    AddParameter(cmd, pInt64(Notification.Property_UserID, UserID));
        //    AddParameter(cmd, pNText(Notification.Property_Subject, Subject));
        //    AddParameter(cmd, pNText(Notification.Property_Body, Body));
        //    AddParameter(cmd, pDateTime(Notification.Property_StartDate, StartDate));
        //    AddParameter(cmd, pDateTime(Notification.Property_EndDate, EndDate));

        //    return GetList(cmd, ALL_AVAILABLE_RECORDS);
        //}

        public Notification GetNotificationForApprover(long UserID, DateTime StartDate, DateTime EndDate)
        {
            Notification notification = new Notification();
            notification.UserID = UserID;
            SqlCommand cmd = GetSPCommand(GETNOTIFICATIONINFOFORAPPROVER);

            AddParameter(cmd, pInt64(Notification.Property_UserID, UserID));
            AddParameter(cmd, pDateTime(Notification.Property_StartDate, StartDate));
            AddParameter(cmd, pDateTime(Notification.Property_EndDate, EndDate));

            // Select multiple records
            SqlDataReader reader;
            long result = SelectRecords(cmd, out reader);

            // Contruct list
            NotificationFieldList list = new NotificationFieldList();
            bool found = false;
            using (reader)
            {
                // Read rows until end of result or number of rows specified is reached
                while (reader.Read())
                {
                    found = false;
                    NotificationField notificationObject = new NotificationField();

                    //timeEntryID = reader.GetGuid(0);

                    if (!reader.IsDBNull(0))
                        notificationObject.ApprovedHours = reader.GetInt32(0);
                    else
                        notificationObject.ApprovedHours = 0;
                    if (!reader.IsDBNull(1))
                        notificationObject.WorkingHours = reader.GetInt32(1);
                    else
                        notificationObject.WorkingHours = 0;

                    if (reader.FieldCount > 2)
                    {
                        if (notificationObject.CustomProperties == null)
                            notificationObject.CustomProperties = new TSR.Framework.CustomProperties();
                        for (int i = 2; i < reader.FieldCount; i++)
                            notificationObject.CustomProperties[reader.GetName(i)] = reader.GetValue(i);
                    }

                    NotificationField nf = new NotificationField();
                    foreach (NotificationField nField in list)
                    {
                        if (nField.CustomProperties["ID"] == notificationObject.CustomProperties["ID"])
                        {
                            nf = nField;
                            found = true;
                        }
                    }

                    if (!found)
                    {
                        list.Add(notificationObject);
                    }
                    else
                    {
                        
                        if ((Convert.ToInt64(notificationObject.CustomProperties["WorkflowInstanceID"]) > Convert.ToInt64(nf.CustomProperties["WorkflowInstanceID"])) ||
                        (Convert.ToInt64(notificationObject.CustomProperties["WorkflowInstanceID"]) == Convert.ToInt64(nf.CustomProperties["WorkflowInstanceID"]) &&
                        Convert.ToInt64(notificationObject.CustomProperties["ProcessID"]) == Convert.ToInt64(nf.CustomProperties["ProcessID"]) &&
                        Convert.ToInt64(notificationObject.CustomProperties["ProcessInstanceID"]) > Convert.ToInt64(nf.CustomProperties["ProcessInstanceID"])))
                        {
                            list.Remove(nf);
                            list.Add(notificationObject);
                        }
                        else
                        {
                            list.Add(notificationObject);
                        }
                    }
                                        
                }

                // Close the reader in order to receive output parameters
                // Output parameters are not available until reader is closed.
                reader.Close();
            }
            
            notification.UserNotificationFields = list;
            
            return notification;
        }
  /// <summary>
        /// Retrieves Notification by Notification name
        /// </summary>
        /// <param name="NotificationName"></param>
        /// <returns></returns>
        public Notification GetNotificationByNotificationName(string NotificationName)
        {
            SqlCommand cmd = GetSPCommand(GETNOTIFICATIONBYNOTIFICATIONNAME);
            AddParameters(cmd, pNVarChar(NotificationBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, NotificationName));
            return GetObject(cmd);
        }
                
    }
}
