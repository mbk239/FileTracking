﻿using System;
using System.Data;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;

namespace TSR.DataAccess
{
    public partial class LocationData
    {
        private const string GETLOCATIONBYSEARCHTERM = "GetLocationBySearchTerm";
        
        public LocationList GetLocationBySearchTerm(string searchTerm, bool bShowInactivate)
        {
            using (SqlCommand cmd = GetSPCommand(GETLOCATIONBYSEARCHTERM))
            {
                AddParameter(cmd, pNVarChar("SearchTerm", ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, searchTerm));
                AddParameter(cmd, pBool("ShowInactivate", bShowInactivate));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
    }
}
