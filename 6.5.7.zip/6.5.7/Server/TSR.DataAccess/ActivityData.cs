using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// ActivityData
    /// </summary>
    public partial class ActivityData
    {
        private const string GETACTIVITIESBYPROJECTID = "GetActivitiesByProjectID";
        private const string GETACTIVITYBYACTIVITYNAME = "GETActivityByActivityName";
        private const string GETALLACTIVITYVIEW = "GetAllActivityView";
        private const string GETACTIVITYESBYACTIVITYTYPEID = "GetActivitiesByActivityTypeID";
        private const string GETACTIVITIESBYUSERINPROJECTS = "GetActivitiesForUserInProjects";
        private const string GETACTIVITY_PAGING = "GetActivityForPaging";

        /// <summary>
        /// retrieves activities by project id
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public ActivityList GetActivitiesByProjectID(long projectID)
        {
            SqlCommand cmd = GetSPCommand(GETACTIVITIESBYPROJECTID);

            AddParameters(cmd, pInt64(Project_Activity.Property_ProjectID, projectID));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

        /// <summary>
        /// Retrieves Activity by Activity name
        /// </summary>
        /// <param name="ActivityName"></param>
        /// <returns></returns>
        public Activity GetActivityByActivityName(string ActivityName)
        {
            SqlCommand cmd = GetSPCommand(GETACTIVITYBYACTIVITYNAME);
            AddParameters(cmd, pNVarChar(ActivityBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, ActivityName));
            return GetObject(cmd);
        }

        /// <summary>
        /// Retrieves All Activity View
        /// </summary>        
        /// <returns>ActivityViewList</returns> 
        public ActivityViewList GetAllActivitiesView()
        {
            ActivityViewList list = new ActivityViewList();
            using (SqlCommand cmd = GetSPCommand(GETALLACTIVITYVIEW))
            {
                SqlDataReader reader;
                long result = SelectRecords(cmd, out reader);
                long rows = ALL_AVAILABLE_RECORDS;
                using (reader)
                {
                    while (reader.Read() && rows-- != 0)
                    {
                        int start = 0;
                        ActivityView acViewObject = new ActivityView();
                        acViewObject.ID = reader.GetInt64(start + 0);
                        if (!reader.IsDBNull(start + 1)) acViewObject.ActivityForeignKey = reader.GetString(start + 1);
                        acViewObject.ActivityTypeID = reader.GetInt64(start + 2);
                        acViewObject.ActivityTypeName = ReverseToHTMLCode(reader.GetString(start + 3));
                        acViewObject.Name = ReverseToHTMLCode(reader.GetString(start + 4));
                        if (!reader.IsDBNull(start + 5)) acViewObject.Description = ReverseToHTMLCode(reader.GetString(start + 5));                        
                        list.Add(acViewObject);
                    }

                    reader.Close();
                }
            }
            return list;
        }

        public ActivityList GetActivitiesByActivityType(long activityTypeID)
        {
            SqlCommand cmd = GetSPCommand(GETACTIVITYESBYACTIVITYTYPEID);

            AddParameters(cmd, pInt64(Activity.Property_ActivityTypeID, activityTypeID));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

        public ActivityList GetActivitiesForUserInProjects(long? userID, long? organizationID, long? projectID, long? projectTypeID, long? activityTypeID)
        {
            SqlCommand cmd = GetSPCommand(GETACTIVITIESBYUSERINPROJECTS);

            AddParameters(cmd, pInt64("UserID", userID.HasValue ? userID.Value : -1));
            AddParameters(cmd, pInt64("OrganizationID", organizationID.HasValue ? organizationID.Value : -1));
            AddParameters(cmd, pInt64("ProjectID", projectID.HasValue ? projectID.Value : -1));
            AddParameters(cmd, pInt64("ProjectTypeID", projectTypeID.HasValue ? projectTypeID.Value : -1));
            AddParameters(cmd, pInt64("ActivityTypeID", activityTypeID.HasValue ? activityTypeID.Value : -1));

            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }

        public ActivityList GetActivityPaging(int startOffset, int numberOfItems, long projID, long actTypeID, string name, out int total)
        {
            ActivityList lst = new ActivityList();
            using (SqlCommand cmd = GetSPCommand(GETACTIVITY_PAGING))
            {
                AddBaseParametersForPaging(cmd, startOffset, numberOfItems, name);
                AddParameter(cmd, pInt64("ProjectID", projID));
                AddParameter(cmd, pInt64("ActivityTypeID", actTypeID));               
                lst = GetList_View(cmd, ALL_AVAILABLE_RECORDS);

                total = (int)GetOutParameter(cmd, TOTAL);
            }
            return lst;
        }

        public ActivityList GetAllActivityForExport(long actTypeId)
        {
            SqlCommand cmd = GetSPCommand(GETALLACTIVITYFOREXPORT);
            AddParameter(cmd, pInt64("ActivityTypeID", actTypeId));  
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
    }
}

