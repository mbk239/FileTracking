﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TSR.Entities;
using TSR.Framework;

namespace TSR.DataAccess
{
    public class OUALogData : BaseDataAccess
    {
        private const string INSERTOUALOG = "InsertOUALog";

        public OUALogData(UserContext context) : base(context)
        {
        }

        public OUALogData(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
        }
        #region Insert
        public long Insert(LogOUALogin ouaLogObject)
        {
            try
            {
                SqlCommand cmd = GetSPCommand(INSERTOUALOG);

                //AddParameter(cmd, pInt64Out(LogOUALogin.Property_ID, ouaLogObject.ID));
                AddParameter(cmd, pVarChar(LogOUALogin.Property_UserName, 50,ouaLogObject.UserName));
                AddParameter(cmd, pVarChar(LogOUALogin.Property_CustomerNo, 50, ouaLogObject.CustomerNo));
                AddParameter(cmd, pVarChar(LogOUALogin.Property_OUAVersion,50 ,ouaLogObject.OUAVersion));
                AddParameter(cmd, pVarChar(LogOUALogin.Property_OutlookVersion, 50, ouaLogObject.OutlookVersion));
                AddParameter(cmd, pDateTime(OUALog.Property_TimeStamp, ouaLogObject.Timestamp));
                AddParameter(cmd, pVarChar(LogOUALogin.Property_LoginStatus, 255, ouaLogObject.LoginStatus));
                AddBaseParametersForInsert(cmd, ouaLogObject);

                InsertRecord(cmd);
                return 0;
            }
            catch (SqlException x) { 
                throw new Framework.Exceptions.ObjectInsertException(ouaLogObject, x);
            }
        }
        #endregion
    }
}
