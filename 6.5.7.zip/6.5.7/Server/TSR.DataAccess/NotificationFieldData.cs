﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Entities.Lists;
using System.Data.SqlClient;
using TSR.Entities;

namespace TSR.DataAccess
{
    public partial class NotificationFieldData
    {
        private const string GETNOTIFICATIONFIELDSBYNOTIFICATIONID = "GetNotificationFieldsByNotificationID";


        /// <summary>
        /// Retrieves all Notification Field objects  using it's NotificationID
        /// </summary>
        /// <param name="ID">The id of the NotificationTemplate object to retrieve</param>
        /// <returns>A NotificationList object, null if not found</returns>
        public NotificationFieldList GetAll(long notificationID)
        {
            using (SqlCommand cmd = GetSPCommand(GETNOTIFICATIONFIELDSBYNOTIFICATIONID))
            {
                AddParameters(cmd, pInt64(NotificationField.Property_NotificationID, notificationID));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }

    }
}
