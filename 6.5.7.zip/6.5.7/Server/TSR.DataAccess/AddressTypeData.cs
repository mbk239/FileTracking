using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class AddressTypeData
	{
        private const string GETADDRESSTYPEBYADDRESSTYPENAME = "GetAddressTypeByAddressTypeName";

        /// <summary>
        /// Retrieves AddressType by AddressType name
        /// </summary>
        /// <param name="AddressTypeName"></param>
        /// <returns></returns>
        public AddressType GetAddressTypeByAddressTypeName(string AddressTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETADDRESSTYPEBYADDRESSTYPENAME);
            AddParameters(cmd, pNVarChar(AddressTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, AddressTypeName));
            return GetObject(cmd);
        }
	}
}

