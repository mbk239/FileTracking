using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
    /// <summary>
    /// AddressData:
    /// Used for various data access and manipulation of address data.
    /// 
    /// last updated on:
    /// september 4th, 2009
    /// change description:
    /// </summary>
    public partial class AddressData
    {
        private const string GETADDRESSESBYPERSONID = "GetAddressesByPersonID";
        private const string GETADDRESSESBYORGANIZATIONID = "GetAddressesByOrganizationID";
        /// <summary>
        /// Retrieve addresses for a Person (using Person ID).
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="personID"></param>
        /// <returns></returns>
        public AddressList GetAddressesByPersonID(long personID)
        {
            SqlCommand cmd = GetSPCommand(GETADDRESSESBYPERSONID);
            AddParameters(cmd, pInt64(Person_Address.Property_PersonID, personID));
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
        /// <summary>
        /// Retrieve addresses for an Organization (using Organization ID)
        /// 
        /// last updated on:
        /// september 4th, 2009
        /// change description:
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public AddressList GetAddressesByOrganizationID(long organizationID)
        {
            SqlCommand cmd = GetSPCommand(GETADDRESSESBYORGANIZATIONID);
            AddParameters(cmd, pInt64(Organization_Address.Property_OrganizationID, organizationID));
            return GetList(cmd, ALL_AVAILABLE_RECORDS);
        }
    }
}

