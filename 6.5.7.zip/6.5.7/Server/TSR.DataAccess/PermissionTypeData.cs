using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class PermissionTypeData
	{
        private const string GETPPERMISSIONTYPEBYPPERMISSIONTYPENAME = "GetPermissionTypeByPermissionTypeName";

        /// <summary>
        /// Retrieves PermissionType by PermissionType name
        /// </summary>
        /// <param name="PermissionTypeName"></param>
        /// <returns></returns>
        public PermissionType GetPermissionTypeByPermissionTypeName(string PermissionTypeName)
        {
            SqlCommand cmd = GetSPCommand(GETPPERMISSIONTYPEBYPPERMISSIONTYPENAME);
            AddParameters(cmd, pNVarChar(PermissionTypeBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, PermissionTypeName));
            return GetObject(cmd);
        }
	}
}

