using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;

namespace TSR.DataAccess
{
	public partial class CityData
	{
        private const string GETCITYBYCITYNAME = "GetCityByCityName";

        /// <summary>
        /// Retrieves City by City name
        /// </summary>
        /// <param name="CityName"></param>
        /// <returns></returns>
        public City GetCityByCityName(string CityName)
        {
            SqlCommand cmd = GetSPCommand(GETCITYBYCITYNAME);
            AddParameters(cmd, pNVarChar(CityBase.Property_Name, ConstantCollection.NVARCHAR_FIELD_MAX_LENGTH, CityName));
            return GetObject(cmd);
        }

	}
}

