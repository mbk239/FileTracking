using System;
using System.Data;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Bases;
using System.Collections.Generic;

namespace TSR.DataAccess
{
	public partial class LanguageResourcesData
	{
        private const string GETALLLANGUAGERESOURCESBYLANGUAGEID = "GetAllLanguageResourcesByLanguageId";
        private const string GETALLLANGUAGERESOURCESBYLANGUAGENAME = "GetAllLanguageResourcesByLanguageName";        
        private const string GETALLLANGUAGES = "GetAllLanguages";
        private const string GETLANGUAGEIDBYLANGUAGENAME = "GetLanguageIDByLanguageName";
        //private const string GETALLLANGUAGERESOURCES = "GetAllLanguageResources";

        /// <summary>
        /// retrieves all language resource list
        /// </summary>
        /// <param name="languageId"></param>
        /// <returns></returns>
        public LanguageResourcesList GetAllByLanguageId(String languageId)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLLANGUAGERESOURCESBYLANGUAGEID))
            {
                AddParameters(cmd, pNVarChar(LanguageResources.Property_LanguageID, 50, languageId));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
        // added by tsrdev2
        /// <summary>
        /// retrieves all language resource list        
        /// </summary>
        /// <param name="languageName"></param>
        /// <returns></returns>
        public LanguageResourcesList GetAllByLanguageName(String languageName)
        {
            using (SqlCommand cmd = GetSPCommand(GETALLLANGUAGERESOURCESBYLANGUAGENAME))
            {
                AddParameters(cmd, pNVarChar(LanguageResources.Property_LanguageName, 200, languageName));

                return GetList(cmd, ALL_AVAILABLE_RECORDS);
            }
        }
        // added by tsrdev2
        /// <summary>
        /// retrieves language id by language name        
        /// </summary>
        /// <param name="languageName"></param>
        /// <returns></returns>
        //public LanguageResourcesList GetLanguageIDByLanguageName(String languageName)
        //{
        //    using (SqlCommand cmd = GetSPCommand(GETLANGUAGEIDBYLANGUAGENAME))
        //    {
        //        AddParameters(cmd, pNVarChar(LanguageResources.Property_LanguageName, 200, languageName));

        //        return GetList(cmd, ALL_AVAILABLE_RECORDS);
        //    }
        //}
        /// <summary>
        /// retrieves list of languages
        /// </summary>
        /// <returns></returns>
        public List<String> GetLanguages()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLLANGUAGES))
            {
                SqlDataReader reader;
                long result = SelectRecords(cmd, out reader);

                // Contruct list
                List<String> list = new List<String>();

                using (reader)
                {   
                    while (reader.Read())
                    {
                        if (!reader.IsDBNull(0))
                        {
                            String languageName = ReverseToHTMLCode(reader.GetString(0));
                            list.Add(languageName);
                        }                        
                    }
                    reader.Close();
                }
                return list;
            }
        }

        /// <summary>
        /// retrieves list of language resources
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResources()
        {
            using (SqlCommand cmd = GetSPCommand(GETALLLANGUAGERESOURCES))
            {
                return GetList(cmd, ALL_AVAILABLE_RECORDS);                
            }
        }
	}
}

