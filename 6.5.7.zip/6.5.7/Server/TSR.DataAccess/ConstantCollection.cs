﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TSR.DataAccess
{
    class ConstantCollection
    {
        public static int NVARCHAR_FIELD_MAX_LENGTH = 255;
        public static int NVARCHAR_FIELD_NORMAL_LENGTH = 50;
        public static int NVARCHAR_FIELD_LENGTH128 = 128;
        public static int NVARCHAR_FIELD_LENGTH_100 = 100;
        public static int NVARCHAR_FIELD_LENGTH_200 = 200;
    }
}
