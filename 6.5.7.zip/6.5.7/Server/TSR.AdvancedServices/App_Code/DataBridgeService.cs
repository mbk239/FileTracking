﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Collections;
using System.ServiceModel.Activation;
using System.Data.SqlClient;
using System.Reflection;
using System.Web;

using TSR.Facade;
using TSR.Framework.Logging;
using TSR.Framework.Web.Security;
using TSR.Entities;
using TSR.Framework;
using TSR.Framework.Security;
using TSR.DataBridge;

// NOTE: If you change the class name "DataBridgeService" here, you must also update the reference to "DataBridgeService" in Web.config.
/// <summary>
/// WCF class, which responds to service calls from TSR CommandLine
/// </summary>
/// 
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
[ServiceBehavior(Name = "DataBridgeService", InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Single)]
public class DataBridgeService : BaseSecuredServiceLibrary, IDataBridgeService
{
    public const string PERMISSION_DATABRIDGE_KEY = "SECURED_DATABRIDGE_DATABRIDGE_ASPX";    
    /// <summary>
    /// Popublate context with NON AD Creds for client who called the service
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    private UserContext GetNONADUserContext(string userName, string password)
    {
        UserContext context;

        using (AuthenticationFacade facade = new AuthenticationFacade())
        {            
            context = facade.GetUserContext(userName, password, string.Empty);         
        }

        return context;
    }
    /// <summary>
    /// Get list field
    /// </summary>
    /// <param name="listMappingInfo"></param>
    /// <returns></returns>
    private List<String> getListField(List<EntityPropertyMappingInfo> listMappingInfo)
    {
        List<String> listField = new List<String>();
        foreach (EntityPropertyMappingInfo mapInfo in listMappingInfo)
        {            
            listField.Add(mapInfo.DestinationColumn);
        }
        return listField;
    }    
   
    /// <summary>
    /// Lock executing DBR Runtime
    /// </summary>
    /// <returns></returns>
    public bool Lock()
    {
        if (DataBridgeFacade.IsLocked)
            return false;
        else
        {
            DataBridgeFacade.IsLocked = true;
            return true;
        }
    }
    /// <summary>
    /// Unlock executing DBR Runtime
    /// </summary>
    public void UnLock()
    {
        DataBridgeFacade.IsLocked = false;
    }
    #region IDataBridgeService Members    
    /// <summary>
    /// a dummy method, just to check whether the service is up or not
    /// </summary>
    /// <returns></returns>
    public bool IsServiceUp()
    {                
        return true;
    }    
    /// <summary>
    /// Login to TSR Server
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="IsNoPermission"></param>
    /// <returns></returns>
    public ResponseMessage<bool> LogInUser(RequestMessage<string> userName, RequestMessage<string> pass, out ResponseMessage<bool> IsHasPermission)
    {
        UserContext context;
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.IsException = false;
        msg.IsSuccessful = false;
        IsHasPermission = new ResponseMessage<bool>();
        IsHasPermission.Data = false;
        TSR.Framework.Logging.LogFailedLogin logFailed = new TSR.Framework.Logging.LogFailedLogin();
        try
        {
            using (AuthenticationFacade facade = new AuthenticationFacade())
            {                
                context = facade.LogInUser(userName.Data, pass.Data, string.Empty, out logFailed);                
            }            
            //added by tsrdev2
            SaveLogFailedLogin(logFailed); //Source = OUA
            if (context != null)
            {
                if (context.HasPermission(PERMISSION_DATABRIDGE_KEY))
                    IsHasPermission.Data = true;
                else
                    IsHasPermission.Data = false;

                msg.Data = true;
                msg.IsSuccessful = true;
            }
            else
            {
                msg.ErrorMessage = GetFailedLoginMessageForDataBridge(logFailed); //include both get message and LockUser
                msg.Data = false;
            }
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.Data = false;
            msg.ErrorMessage = !string.IsNullOrEmpty(ex.Message) ? ex.Message : ex.InnerException.ToString();
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }    
    /// <summary>
    /// Export from database to delimited file content
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="profileName"></param>
    /// <returns></returns>
    public ResponseMessage<string> ExportToTextDelimitedContent(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> profileName)
    {
        ResponseMessage<string> msg = new ResponseMessage<string>();
        msg.IsSuccessful = false;
        msg.IsException = false;

        object objList;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = "Authentication failed";
                msg.Data = string.Empty;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                return msg;
            }

            if (!Lock())
            {                
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "DataBridge Runtime is busy"
                });
                msg.ErrorMessage = "DataBridge Runtime is busy";
                msg.Data = string.Empty;
                return msg;
            }
            //Get databridge settings
            DataBridgeSettings setting;
            using (DataBridgeFacade dataBridgeFacade = new DataBridgeFacade(context))
            {
                List<DataBridgeSettings> listProfile = dataBridgeFacade.GetDBRSettingsForCurrentUser();
                setting = listProfile.Find(delegate(DataBridgeSettings tmp) { return (tmp.Name == profileName.Data) && tmp.IsExport; });                
            }

            //added by tsrdev2
            //apply for field Duration of TimeEntryView
            if (setting != null && setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_TIMEENTRY)
            {
                EntityPropertyMappingInfo epmiDuration = setting.EntityMap.PropertyMappingList.Find(
                    delegate(EntityPropertyMappingInfo tmpE) { return tmpE.SourceColumn == TimeEntryView.Property_Duration; });
                if (epmiDuration != null)
                {
                    if (epmiDuration.MaxLength.Equals(DataBridgeFacade.DURATION_MAXLENG_TWOFIELD))
                    {
                        int index = setting.EntityMap.PropertyMappingList.IndexOf(epmiDuration);
                        //remove field Duration
                        setting.EntityMap.PropertyMappingList.Remove(epmiDuration);
                        //add field DurationHour
                        EntityPropertyMappingInfo tmpInfo = new EntityPropertyMappingInfo();
                        tmpInfo.DestinationColumn = TimeEntryView.Property_DurationHour;
                        tmpInfo.IsMandatory = false;
                        tmpInfo.MaxLength = "";
                        tmpInfo.SourceColumn = TimeEntryView.Property_DurationHour;
                        tmpInfo.Type = "Short";
                        tmpInfo.Width = "";
                        setting.EntityMap.PropertyMappingList.Insert(index, tmpInfo);
                        //add field DurationMinute
                        EntityPropertyMappingInfo tmpInfoMinute = new EntityPropertyMappingInfo();
                        tmpInfoMinute.DestinationColumn = TimeEntryView.Property_DurationMinute;
                        tmpInfoMinute.IsMandatory = false;
                        tmpInfoMinute.MaxLength = "";
                        tmpInfoMinute.SourceColumn = TimeEntryView.Property_DurationMinute;
                        tmpInfoMinute.Type = "Short";
                        tmpInfoMinute.Width = "";
                        setting.EntityMap.PropertyMappingList.Insert(index + 1, tmpInfoMinute);
                    }
                }

                EntityPropertyMappingInfo epmiStartTimeStamp = setting.EntityMap.PropertyMappingList.Find(
                    delegate(EntityPropertyMappingInfo tmpE) { return tmpE.SourceColumn == TimeEntryView.Property_StartTimeStamp; });

                if (epmiStartTimeStamp != null && epmiStartTimeStamp.SplitDateTime)
                {
                    int index = setting.EntityMap.PropertyMappingList.IndexOf(epmiStartTimeStamp);
                    //remove field StartTimeStamp
                    setting.EntityMap.PropertyMappingList.Remove(epmiStartTimeStamp);

                    //add field StartDate
                    EntityPropertyMappingInfo epmiStartDate = new EntityPropertyMappingInfo();
                    epmiStartDate.DestinationColumn = TimeEntryView.Property_StartDate;
                    epmiStartDate.IsMandatory = false;
                    epmiStartDate.MaxLength = "";
                    epmiStartDate.SourceColumn = TimeEntryView.Property_StartDate;
                    epmiStartDate.Type = "String";
                    epmiStartDate.Width = "";
                    epmiStartDate.SplitDateTime = true;
                    epmiStartDate.DateFormat = epmiStartTimeStamp.DateFormat;

                    setting.EntityMap.PropertyMappingList.Insert(index, epmiStartDate);

                    //add new field StartTime
                    EntityPropertyMappingInfo epmiStartTime = new EntityPropertyMappingInfo();
                    epmiStartTime.DestinationColumn = TimeEntryView.Property_StartTime;
                    epmiStartTime.IsMandatory = false;
                    epmiStartTime.MaxLength = "";
                    epmiStartTime.SourceColumn = TimeEntryView.Property_StartTime;
                    epmiStartTime.Type = "String";
                    epmiStartTime.Width = "";
                    epmiStartTime.SplitDateTime = true;
                    epmiStartTime.TimeFormat = epmiStartTimeStamp.TimeFormat;

                    setting.EntityMap.PropertyMappingList.Insert(index + 1, epmiStartTime);
                }

                EntityPropertyMappingInfo epmiEndTimeStamp = setting.EntityMap.PropertyMappingList.Find(
                    delegate(EntityPropertyMappingInfo tmpE) { return tmpE.SourceColumn == TimeEntryView.Property_EndTimeStamp; });

                if (epmiEndTimeStamp != null && epmiEndTimeStamp.SplitDateTime)
                {
                    int index = setting.EntityMap.PropertyMappingList.IndexOf(epmiEndTimeStamp);
                    //remove field EndTimeStamp
                    setting.EntityMap.PropertyMappingList.Remove(epmiEndTimeStamp);

                    //add field EndDate
                    EntityPropertyMappingInfo epmiEndDate = new EntityPropertyMappingInfo();
                    epmiEndDate.DestinationColumn = TimeEntryView.Property_EndDate;
                    epmiEndDate.IsMandatory = false;
                    epmiEndDate.MaxLength = "";
                    epmiEndDate.SourceColumn = TimeEntryView.Property_EndDate;
                    epmiEndDate.Type = "String";
                    epmiEndDate.Width = "";
                    epmiEndDate.SplitDateTime = true;
                    epmiEndDate.DateFormat = epmiEndTimeStamp.DateFormat;

                    setting.EntityMap.PropertyMappingList.Insert(index, epmiEndDate);

                    //add new field EndTime
                    EntityPropertyMappingInfo epmiEndTime = new EntityPropertyMappingInfo();
                    epmiEndTime.DestinationColumn = TimeEntryView.Property_EndTime;
                    epmiEndTime.IsMandatory = false;
                    epmiEndTime.MaxLength = "";
                    epmiEndTime.SourceColumn = TimeEntryView.Property_EndTime;
                    epmiEndTime.Type = "String";
                    epmiEndTime.Width = "";
                    epmiEndTime.SplitDateTime = true;
                    epmiEndTime.TimeFormat = epmiEndTimeStamp.TimeFormat;

                    setting.EntityMap.PropertyMappingList.Insert(index + 1, epmiEndTime);
                }
            }
            objList = GetDataForExport(context,setting);

            if ((objList == null) || (objList != null && ((IList)objList).Count == 0))
            {                
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "No available data for exporting"
                });

                msg.ErrorMessage = "No available data for exporting";
                msg.Data = string.Empty;
                return msg;
            }

            using (DataBridgeFacade dbrFacade = new DataBridgeFacade(context))
            {
                msg.Data = dbrFacade.GetTextDelimitedFileContentWithStrimmingEnter(setting.EntityMap.PropertyMappingList, ((IList)objList), setting.Delimiter, setting.Format);
            }

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";            
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            msg.IsException = true;
            LoggingHandler.LogUnhandledException(ex);
        }
        finally
        {
            UnLock();
        }
        return msg;
    }
    /// <summary>
    /// Import DBR from delimited file to Database
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="uploadFileName"></param>
    /// <param name="codePage"></param>
    /// <param name="profileName"></param>
    /// <param name="pauseIndex"></param>
    /// <returns></returns>
    public ResponseMessage<long> ImportFromDelimitedFile(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> uploadFileName, RequestMessage<int> codePage, RequestMessage<string> profileName, RequestMessage<long> pauseIndex)
    {
        ResponseMessage<long> msg = new ResponseMessage<long>();
        msg.IsSuccessful = false;
        msg.IsException = false;
        string fileName = HttpContext.Current.Server.MapPath("~/App_Data") +"/"+ uploadFileName.Data;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = "Authentication failed";
                msg.Data = -1;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                return msg;
            }
            if (!Lock())
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });

                msg.ErrorMessage = "DataBridge Runtime is busy";
                msg.Data = -1;
                return msg;
            }

            //Get databridge settings
            DataBridgeSettings setting;
            using (DataBridgeFacade dataBridgeFacade = new DataBridgeFacade(context))
            {
                List<DataBridgeSettings> listProfile = dataBridgeFacade.GetDBRSettingsForCurrentUser();
                setting = listProfile.Find(delegate(DataBridgeSettings tmp) { return (tmp.Name == profileName.Data) && !tmp.IsExport; });
            }
            
            using (DataBridgeFacade facade = new DataBridgeFacade(context))
            {
                msg.Data = facade.importFromDelimitedFileForCommandLine(fileName, Encoding.GetEncoding(codePage.Data),setting.EntityMap, setting.Delimiter, setting.ApplicationID, pauseIndex.Data);
            }

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {            
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        finally
        {
            UnLock();
        }
        return msg;              
    }

    /// <summary>
    /// Import DBR from delimited file to Database
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="uploadFileName"></param>    
    /// <param name="profileName"></param>
    /// <param name="pauseIndex"></param>
    /// <returns></returns>
    public ResponseMessage<long> ImportFromDelimitedFile(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> uploadFileName, RequestMessage<string> profileName, RequestMessage<long> pauseIndex)
    {
        ResponseMessage<long> msg = new ResponseMessage<long>();
        msg.IsSuccessful = false;
        msg.IsException = false;
        string fileName = HttpContext.Current.Server.MapPath("~/App_Data") + "/" + uploadFileName.Data;
        //string fileName = HttpContext.Current.Server.MapPath("~/App_Data") + "/" + "import_organization_01.csv";
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = "Authentication failed";
                msg.Data = -1;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                return msg;
            }
            if (!Lock())
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });

                msg.ErrorMessage = "DataBridge Runtime is busy";
                msg.Data = -1;
                return msg;
            }

            //Get databridge settings
            DataBridgeSettings setting;
            using (DataBridgeFacade dataBridgeFacade = new DataBridgeFacade(context))
            {
                List<DataBridgeSettings> listProfile = dataBridgeFacade.GetDBRSettingsForCurrentUser();
                setting = listProfile.Find(delegate(DataBridgeSettings tmp) { return (tmp.Name == profileName.Data) && !tmp.IsExport; });
            }

            using (DataBridgeFacade facade = new DataBridgeFacade(context))
            {
                msg.Data = facade.importFromDelimitedFileForCommandLine(fileName, setting.EntityMap, setting.Delimiter, setting.ApplicationID, pauseIndex.Data);
            }            

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        finally
        {
            UnLock();
        }
        
        ////Delete delimited file
        //try
        //{
        //    System.IO.File.Delete(fileName);
        //}
        //catch { }

        return msg;
    }    


    /// <summary>
    /// Get profile for current user
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="settingName"></param>
    /// <returns></returns>
    public ResponseMessage<DataBridgeSettings> GetDBRSettingsForCurrentUser(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> settingName, RequestMessage<bool> isExport)
    {
        ResponseMessage<DataBridgeSettings> msg = new ResponseMessage<DataBridgeSettings>();
        UserContext context = null;
        msg.IsSuccessful = false;
        msg.IsException = false;
        try
        {
            context = GetNONADUserContext(userName.Data,pass.Data);

            if (context == null)
            {
                msg.ErrorMessage = "Authentication failed";
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                return msg;
            }

            using (DataBridgeFacade dataBridgeFacade = new DataBridgeFacade(context))
            {
                List<DataBridgeSettings> listProfile = dataBridgeFacade.GetDBRSettingsForCurrentUser();
                DataBridgeSettings setting = listProfile.Find(delegate(DataBridgeSettings tmp) { return (tmp.Name == settingName.Data) && (tmp.IsExport == isExport.Data); });
                msg.Data = setting;                
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    /// <summary>
    /// GetLicense
    /// Get license with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<ApplicationLicense> GetLicense(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        msg.IsException = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                msg.ErrorMessage = "Authentication failed";
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                    license.Version = "5.9";

                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);

                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense6(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        msg.IsException = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                msg.ErrorMessage = "Authentication failed";
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                    license.Version = "6.1";

                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);

                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense62(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        msg.IsException = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                msg.ErrorMessage = "Authentication failed";
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                    license.Version = "6.2";

                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);

                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense63(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        msg.IsException = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = "Authentication failed"
                });
                msg.ErrorMessage = "Authentication failed";
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();

            }

            if (license != null)
            {
                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);

                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = "Database error, please contact administrator";
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsException = true;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    //Methods are used to access to static variables in DataBridgeFacade
    public bool GetOrSetIsUpdateAll(bool value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.IsUpdateAll = value;
        else
            return DataBridgeFacade.IsUpdateAll;
        return false;
    }
    public bool GetOrSetIsPausedImportProcess(bool value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.IsPausedImportProcess = value;
        else
            return DataBridgeFacade.IsPausedImportProcess;
        return false;
    }
    public string GetOrSetExternalKeyIsPaused(string value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.externalKeyIsPaused = value;
        else
            return DataBridgeFacade.externalKeyIsPaused;
        return string.Empty;
    }
    public long GetOrSetTotalRecords(long value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.totalRecords = value;
        else
            return DataBridgeFacade.totalRecords;
        return -1;
    }
    public long GetOrSetCountInserted(long value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.countInserted = value;
        else
            return DataBridgeFacade.countInserted;
        return -1;
    }
    public long GetOrSetCountUpdated(long value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.countUpdated = value;
        else
            return DataBridgeFacade.countUpdated;
        return -1;
    }
    public string GetOrSetStrInsertedLog(string value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.strInsertedLog = value;
        else
            return DataBridgeFacade.strInsertedLog;
        return string.Empty;
    }
    public string GetOrSetStrUpdatedLog(string value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.strUpdatedLog = value;
        else
            return DataBridgeFacade.strUpdatedLog;
        return string.Empty;
    }
    public string GetOrSetStrFailedLog(string value, bool isSet)
    {
        if (isSet)
            DataBridgeFacade.strFailedLog = value;
        else
            return DataBridgeFacade.strFailedLog;
        return string.Empty;
    }
    public void ResetAllImportKey()
    {
        DataBridgeFacade.totalRecords = 0;
        DataBridgeFacade.countInserted = 0;
        DataBridgeFacade.countUpdated = 0;
        DataBridgeFacade.strFailedLog = string.Empty;
        DataBridgeFacade.strUpdatedLog = string.Empty;
        DataBridgeFacade.strInsertedLog = string.Empty;
        DataBridgeFacade.IsUpdateAll = false;
        DataBridgeFacade.IsPausedImportProcess = false;
        DataBridgeFacade.externalKeyIsPaused = string.Empty;
    }

    //End
    #endregion    
    #region Private methods
    /// <summary>
    /// Get data from database for exporting
    /// </summary>
    /// <param name="context"></param>
    /// <param name="setting"></param>
    /// <returns></returns>
    private object GetDataForExport(UserContext context,DataBridgeSettings setting)
    {
        object resultSearch = null;
        if (setting.TSREntityTypeID == -1)
        {
            return null;
            
        }
        if (setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_PROJECT)
        {
            //read the project name
            //tsrdev4: rename the projectName variable -> keyWork                          
            ProjectViewList projViewList = null;
            try
            {
                using (SetupDataFacade setup = new SetupDataFacade(context))
                {
                    projViewList = setup.GetProjectsViewBySearchCriteria((ProjectSearch)setting.SearchCriteria, getListField(setting.EntityMap.PropertyMappingList));                    
                }
                if (projViewList == null)
                    return null;
                else
                    resultSearch = projViewList;

            }
            catch (Exception ex)
            {
                throw ex;
            }             
        }
        if (setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_ORGANIZATION)
        {
            try
            {
                using (SetupDataFacade setupDataFacade = new SetupDataFacade(context))
                {
                    OrganizationViewList orgViewList = null;
                    orgViewList = setupDataFacade.GetOrganizationsViewBySearchCriteria((string)setting.SearchCriteria, getListField(setting.EntityMap.PropertyMappingList));
                    if (orgViewList == null)
                        return null;
                    else
                        resultSearch = orgViewList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        if (setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_TIMEENTRY)
        {
            TimeEntryViewList list = null;
            try
            {
                using (TimeFacade timeFacade = new TimeFacade(context))
                    list = timeFacade.GetTimeEntriesViewBySearchCriteria((TimeEntrySearch)setting.SearchCriteria, getListField(setting.EntityMap.PropertyMappingList),true);
                if (list == null)
                    return null;
                else
                    resultSearch = list;              
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        if (setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_CONTACT)
        {
            try
            {
                using (SetupDataFacade setup = new SetupDataFacade(context))
                {
                    ContactViewList contactList = setup.GetContactsViewBySearchCriteria((ContactSearch)setting.SearchCriteria, getListField(setting.EntityMap.PropertyMappingList));
                    if (contactList == null)
                        return null;
                    else
                        resultSearch = contactList;   
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        if (setting.TSREntityTypeID == DataBridgeFacade.ENTITY_TYPE_ACTIVITY)
        {
            try
            {
                using (SetupDataFacade setup = new SetupDataFacade(context))
                {
                    ActivityViewList activityList = setup.GetActivitiesViewBySearchCriteria((ActivitySearch)setting.SearchCriteria, getListField(setting.EntityMap.PropertyMappingList));
                    if (activityList == null)
                        return null;
                    else
                        resultSearch = activityList;   
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        return FilterDataWithoutEmpty(resultSearch, setting.EntityMap.PropertyMappingList.ToArray());
    }

    /// <summary>
    /// Filter empty data
    /// </summary>
    /// <param name="data"></param>
    /// <param name="listMappingInfo"></param>
    /// <returns></returns>
    private object FilterDataWithoutEmpty(object data, EntityPropertyMappingInfo[] listMappingInfo)
    {
        PropertyInfo propInfo;
        string propVal;
        IList listData = (IList)data;
        List<object> listRemove = new List<object>();
        if (listData == null) return null;
        foreach (object obj in listData)
        {
            Type objType = obj.GetType();
            int countEmpty = 0;
            for (int i = 0; i < listMappingInfo.Count(); i++)
            {
                propInfo = objType.GetProperty(listMappingInfo[i].DestinationColumn);
                if (propInfo != null)
                {
                    propVal = (propInfo.GetValue(obj, null) == null) ? string.Empty : propInfo.GetValue(obj, null).ToString();
                    //quoatation marks is safe - to make sure, even if there is space inside, it will be considered as a single string
                    if (String.IsNullOrEmpty(propVal))
                        countEmpty++;
                }
            }
            if (countEmpty == listMappingInfo.Count())
                listRemove.Add(obj);
        }
        foreach (object obj in listRemove)
        {
            listData.Remove(obj);
        }
        return listData;
    }

    //added by tsrdev2
    /// <summary>
    /// Gets error message for failed login of the user
    /// </summary>
    /// <param name="logFailed"></param>
    /// <returns></returns>
    private string GetFailedLoginMessage(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        int countFailed = CountOfTimesContinuosWrongPassword(logFailedLogin.UserID, logFailedLogin.LoggingTime, 1);
        string message = string.Empty;
        switch ((TypeOfEventEnum)logFailedLogin.TyOfEvent)
        {
            case TypeOfEventEnum.UnknownUser:
                message = "Login failed. You must be a TSR user to login into this site.";
                break;
            case TypeOfEventEnum.WrongPassword:
                //after 3 failed login in one hour
                //int countFailed = CountOfTimesContinuosWrongPassword(logFailedLogin.UserID, logFailedLogin.LoggingTime, 1);
                if (countFailed < 3)
                    message = "Login failed, User Name or Password is invalid.";
                else if (countFailed < 10)
                {
                    int delay = ComputingDelay(countFailed);
                    message = "You have {0} failed attempts to login within a time span of one hour"
                                      + ". " +"Please waiting {1} seconds to try to login again.";
                    message = string.Format(message, countFailed, delay);
                }
                else //countFailed == 10
                {
                    if (LockUser(logFailedLogin.UserID))
                        message = "You have 10 failed attempts to login, your account has been locked. Please contact with TSR administrator.";
                }

                break;
            case TypeOfEventEnum.AccountLocked:
                message = "This account has been locked. Please contact with TSR administrator.";
                break;
            case TypeOfEventEnum.AccountUnlocked:
                break;
            case TypeOfEventEnum.PasswordChanged:
                break;
            default:
                break;
        }
        return message;
    }

    //added by tsrdev2
    private string GetFailedLoginMessageForDataBridge(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        string message = string.Empty;
        switch ((TypeOfEventEnum)logFailedLogin.TyOfEvent)
        {
            case TypeOfEventEnum.UnknownUser:
                message = "Login failed. You must be a TSR user to login into this site.";
                break;
            case TypeOfEventEnum.WrongPassword:
                message = "Login failed, User Name or Password is invalid.";
                break;
            case TypeOfEventEnum.AccountLocked:
                message = "This account has been locked. Please contact with TSR administrator.";
                break;
        }
        return message;
    }

    //added by tsrdev2
    private int CountOfTimesContinuosWrongPassword(long userid, DateTime currLogging, int hourSpan)
    {
        //gets template user context, have to remove template user context when not be used
        UserContext context = AuthenticationFacade.GetTempContext();
        //times of failed login
        int countOfFailedLogin = 0;
        using (SecurityFacade securityFacade = new SecurityFacade(context))
        {
            countOfFailedLogin = securityFacade.TimesOfFailedLoginOfUserInTimeSpan(userid, currLogging, hourSpan, SourceType.DataBridge);
        }
        //remove temp context
        SecurityManager.SetUserContext(null);
        return countOfFailedLogin;
    }

    //added by tsrdev
    private bool SaveLogFailedLogin(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        if (logFailedLogin != null)
        {
            logFailedLogin.Source = SourceType1.DataBridge;
            logFailedLogin.ClientIP = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]; //or HttpContext.Current.Request.UserHostAddress   
            TSR.Framework.Logging.LoggingHandler.LogFailedLoginInfo(logFailedLogin);
        }
        return true;
    }

    //added by tsrdev2
    private bool LockUser(long userID)
    {
        bool success = false;
        if (userID > 0)
        {
            User user = new User();
            //set template usercontext
            UserContext context = AuthenticationFacade.GetTempContext();
            try
            {
                using (SecurityFacade facade = new SecurityFacade(context))
                {
                    user = facade.GetUserByID(userID);

                    user.IsActive = false;
                    user.RowState = BaseBusinessEntity.RowStateEnum.InActiveRow;
                    success = facade.UpdateUser(user);
                    if (success)
                    {
                        //log changed pass for this user                        
                        if (!user.IsActive) //is inActive (locked) user
                        {
                            TSR.Framework.Logging.LoggingHandler.LogFailedLoginInfo(new TSR.Framework.Logging.LogFailedLogin
                            {
                                UserID = user.ID,
                                UserName = user.Username,
                                Source = SourceType1.WebServices,
                                TyOfEvent = TypeOfEventEnum1.AccountLocked,
                                ClientIP = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"], //or HttpContext.Current.Request.UserHostAddress 
                            });
                        }
                    }
                }
            }
            catch (TSR.Framework.Exceptions.LicenseException lexp)
            {
                TSR.Framework.Logging.LoggingHandler.LogUnhandledException(lexp.InnerException);
            }
            catch (Exception ex)
            {
                TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                //remove temp usercontext
                SecurityManager.SetUserContext(null);
            }
        }
        return success;
    }

    //added by tsrdev2
    private int ComputingDelay(int countWrongPass)
    {
        if (countWrongPass < 3 || countWrongPass >= 10)
        {
            return 0;
        }
        int delay = TSR.Framework.ConstantCollection.LOGIN_DELAY;
        return delay * Convert.ToInt32(Math.Pow(2, ((double)countWrongPass - 3)));
    }

    #endregion
}
