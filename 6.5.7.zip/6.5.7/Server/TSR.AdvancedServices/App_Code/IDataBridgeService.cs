﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using TSR.Framework.Security;
using TSR.DataBridge;

// NOTE: If you change the interface name "IDataBridgeService" here, you must also update the reference to "IDataBridgeService" in Web.config.
[ServiceContract(Name = "IDataBridgeService", Namespace = "http://tsr.advancedservices.databridgeservice", SessionMode = SessionMode.Allowed)]
//interface for databridge service
public interface IDataBridgeService
{
    [OperationContract]
    bool IsServiceUp();
    [OperationContract]
    ResponseMessage<bool> LogInUser(RequestMessage<string> userName, RequestMessage<string> pass, out ResponseMessage<bool> IsHasPermission);
    [OperationContract]
    ResponseMessage<string> ExportToTextDelimitedContent(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> profileName);
    //[OperationContract]
    //ResponseMessage<long> ImportFromDelimitedFile(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> uploadFileName, RequestMessage<int> codePage, RequestMessage<string> profileName, RequestMessage<long> pauseIndex);
    [OperationContract]
    ResponseMessage<long> ImportFromDelimitedFile(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> uploadFileName, RequestMessage<string> profileName, RequestMessage<long> pauseIndex);
    [OperationContract]
    ResponseMessage<DataBridgeSettings> GetDBRSettingsForCurrentUser(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> settingName, RequestMessage<bool> isExport);
    [OperationContract]
    bool GetOrSetIsUpdateAll(bool value, bool isSet);
    [OperationContract]
    bool GetOrSetIsPausedImportProcess(bool value, bool isSet);
    [OperationContract]
    string GetOrSetExternalKeyIsPaused(string value, bool isSet);
    [OperationContract]
    long GetOrSetTotalRecords(long value, bool isSet);
    [OperationContract]
    long GetOrSetCountInserted(long value, bool isSet);
    [OperationContract]
    long GetOrSetCountUpdated(long value, bool isSet);
    [OperationContract]
    string GetOrSetStrInsertedLog(string value, bool isSet);        
    [OperationContract]
    string GetOrSetStrUpdatedLog(string value, bool isSet);
    [OperationContract]
    string GetOrSetStrFailedLog(string value, bool isSet);
    [OperationContract]
    void ResetAllImportKey();
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense6(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense62(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense63(RequestMessage<string> userName, RequestMessage<string> pass);    
}
