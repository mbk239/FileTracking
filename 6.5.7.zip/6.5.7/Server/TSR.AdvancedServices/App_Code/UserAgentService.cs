﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Collections.Specialized;
using System.ServiceModel.Activation;
using System.Data.SqlClient;
using TSR.Facade;
using TSR.Framework.Resource;
using TSR.EFDataAccess;
using TSR.Framework.Logging;
using TSR.Framework.Web.Security;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;
using TSR.Framework.Security;
using System.Web;
using TSR.BusinessLogic;

/// <summary>
/// WCF class, which responds to service calls from TSR Outlook User Agent
/// </summary>
/// 
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
[ServiceBehavior(Name = "UserAgentService", InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Single)]
public class UserAgentService : BaseSecuredServiceLibrary, IUserAgentService
{
    /// <summary>
    /// a dummy method, just to check whether the service is up or not
    /// </summary>
    /// <returns></returns>
    public bool IsServiceUp()
    {
        return true;
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public ResponseMessage<string> GetConfiguration()
    {
        ResponseMessage<string> msg = new ResponseMessage<string>();

        return msg;
    }

    #region IUserAgentService Members - APIs for NON AD mode
    //Added by tsrdev1
    //Added datetime 28/02/2011
    /// <summary>
    /// Popublate context with NON AD Creds for client who called the service
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    private UserContext GetNONADUserContext(string userName, string password)
    {
        UserContext context;

        using (AuthenticationFacade facade = new AuthenticationFacade())
        {
            //log in as AD user and get UserContext
            //context = facade.LogInUserForOUAClient(userName, password);
            //context = facade.LogInUser(userName, password, string.Empty);
            context = facade.GetUserContext(userName, password, string.Empty);

            //context = facade.LogInUser("syedmashrur", "S-1-5-21-1876413556-1635814817-2445296839-1112");
            //context = facade.LogInUser("mahmudulislam", "S-1-5-21-1876413556-1635814817-2445296839-1142");
            //context = facade.LogInUser("likhansiddiquee", "S-1-5-21-1876413556-1635814817-2445296839-1110");
        }

        return context;
    }
    /// <summary>
    /// Log in user with NON AD Mode
    /// </summary>
    /// <returns></returns>
    public ResponseMessage<bool> LogInUser(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        UserContext context;
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        TSR.Framework.Logging.LogFailedLogin logFailed = new TSR.Framework.Logging.LogFailedLogin();
        try
        {
            using (AuthenticationFacade facade = new AuthenticationFacade())
            {
                context = facade.LogInUser(userName.Data, pass.Data, string.Empty, out logFailed);
            }
            //added by tsrdev2
            SaveLogFailedLogin(logFailed); //Source = OUA
            if (context != null)
                msg.Data = true;
            else
            {
                msg.ErrorMessage = GetFailedLoginMessageForOUA(logFailed); //include both get message and LockUser
                msg.Data = false;
            }
        }
        catch (Exception ex)
        {
            msg.Data = false;
            msg.ErrorMessage = !string.IsNullOrEmpty(ex.Message) ? ex.Message : ex.InnerException.ToString();
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }
        // Insert OUA information log  
        try
        {
            LogOUALogin logOUA = new LogOUALogin();
            logOUA.Timestamp = DateTime.Now;
            logOUA.UserName = userName.Data;
            logOUA.LoginStatus = msg.ErrorMessage;
            using (var ouaLogManager = new OUALogManager(null))
            {
                ouaLogManager.Insert(logOUA);
            }
        }
        catch (Exception ex) { }
        return msg;
    }
   
    public ResponseMessage<bool> LogInUserWithLogDB(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<LogOUALogin> request)
    {
        UserContext context;
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        TSR.Framework.Logging.LogFailedLogin logFailed = new TSR.Framework.Logging.LogFailedLogin();
        try
        {
            using (AuthenticationFacade facade = new AuthenticationFacade())
            {
                context = facade.LogInUser(userName.Data, pass.Data, string.Empty, out logFailed);
            }
            //added by tsrdev2
            SaveLogFailedLogin(logFailed); //Source = OUA
            if (context != null)
                msg.Data = true;
            else
            {
                msg.ErrorMessage = GetFailedLoginMessageForOUA(logFailed); //include both get message and LockUser
                msg.Data = false;
            }
        }
        catch (Exception ex)
        {
            msg.Data = false;
            msg.ErrorMessage = !string.IsNullOrEmpty(ex.Message) ? ex.Message : ex.InnerException.ToString();
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }
        // Insert OUA information log  
        try
        {
            if (request != null && request.Data != null)
                using (var ouaLogManager = new OUALogManager(null))
                {
                    request.Data.LoginStatus = msg.ErrorMessage;
                    ouaLogManager.Insert(request.Data);
                }
        }
        catch (Exception ex) { }
        return msg;
    }

    //added by tsrdev2
    /// <summary>
    /// Log in user with NON AD Mode, return a login record
    /// </summary>
    /// <returns></returns>
    public ResponseMessage<TSR.Framework.Logging.LogFailedLogin> LogInUserWithLog(RequestMessage<string> userName, RequestMessage<string> pass, out int delay)
    {
        UserContext context;
        delay = 0;
        ResponseMessage<TSR.Framework.Logging.LogFailedLogin> msg = new ResponseMessage<TSR.Framework.Logging.LogFailedLogin>();
        try
        {
            TSR.Framework.Logging.LogFailedLogin logFailed = new TSR.Framework.Logging.LogFailedLogin();
            using (AuthenticationFacade facade = new AuthenticationFacade())
            {
                //log in as AD user and get UserContext
                context = facade.LogInUser(userName.Data, pass.Data, string.Empty, out logFailed);
                //context = facade.LogInUser("syedmashrur", "S-1-5-21-1876413556-1635814817-2445296839-1112");
                //context = facade.LogInUser("mahmudulislam", "S-1-5-21-1876413556-1635814817-2445296839-1142");
                //context = facade.LogInUser("likhansiddiquee", "S-1-5-21-1876413556-1635814817-2445296839-1110");
            }
            //added by tsrdev2
            SaveLogFailedLogin(logFailed);

            int countFailed = CountOfTimesContinuosWrongPassword(logFailed.UserID, logFailed.LoggingTime, 1);
            delay = ComputingDelay(countFailed);
            msg.Data = logFailed;

            if (context != null)
                msg.IsSuccessful = true;
            else
            {
                msg.IsSuccessful = false;
                msg.ErrorMessage = GetFailedLoginMessage(logFailed);
            }
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = !string.IsNullOrEmpty(ex.Message) ? ex.Message : ex.InnerException.ToString();
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    /// <summary>
    /// GetSetupData
    /// Get setup data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<OrganizationList> GetSetupData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<OrganizationList> msg = new ResponseMessage<OrganizationList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetOrganizationsForUser(context.UserID, true);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<OrganizationVersionList> GetSetupDataRelation(RequestMessage<string> userName, RequestMessage<string> password)
    {
        ResponseMessage<OrganizationVersionList> msg = new ResponseMessage<OrganizationVersionList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetOrganizationsRelationForUser(context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<OrganizationList> GetSetupData_ChangedOrganizations(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged)
    {
        ResponseMessage<OrganizationList> msg = new ResponseMessage<OrganizationList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetAllOrgChanged(listChanged.Data, context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ProjectList> GetSetupData_ChangedProjects(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged)
    {
        ResponseMessage<ProjectList> msg = new ResponseMessage<ProjectList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetAllProjChanged(listChanged.Data, context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ActivityList> GetSetupData_ChangedActivities(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged)
    {
        ResponseMessage<ActivityList> msg = new ResponseMessage<ActivityList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetAllActChanged(listChanged.Data, context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ContactList> GetSetupData_ChangedContact(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged)
    {
        ResponseMessage<ContactList> msg = new ResponseMessage<ContactList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetContactsChanged(listChanged.Data, context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<ContactVersionList> GetSetupData_Contacts(RequestMessage<string> userName, RequestMessage<string> password)
    {
        ResponseMessage<ContactVersionList> msg = new ResponseMessage<ContactVersionList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetAllContactsReversion(context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<Organization_ContactList> GetSetupData_OrganizationContact(RequestMessage<string> userName, RequestMessage<string> password)
    {
        ResponseMessage<Organization_ContactList> msg = new ResponseMessage<Organization_ContactList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, password.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                msg.Data = facade.GetAllOrganization_ContactForUser(context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<OrganizationList> GetSetupData_Organization(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<OrganizationList> msg = new ResponseMessage<OrganizationList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetOrganizationsForUser(context.UserID, false);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<ProjectList> GetSetupData_Project(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<Int64> organizationID)
    {
        ResponseMessage<ProjectList> msg = new ResponseMessage<ProjectList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetProjectsForOrganizationNonUserGroup(organizationID.Data, context.UserID, true);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    
    
    /// <summary>
    /// GetOrganizationsForCheckData
    /// Get organizations for OUA check data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<OrganizationList> GetOrganizationsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<OrganizationList> msg = new ResponseMessage<OrganizationList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetOrganizationsForOUA();
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    /// <summary>
    /// GetProjectsForCheckData
    /// Get projects for OUA check data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<ProjectList> GetProjectsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ProjectList> msg = new ResponseMessage<ProjectList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetProjectsForOUA(context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    /// <summary>
    /// GetActivitiesForCheckData
    /// Get activities for OUA check data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<ActivityList> GetAcitiviesForCheckData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ActivityList> msg = new ResponseMessage<ActivityList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetActivitiesForOUA();
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    /// <summary>
    /// GetContactsForCheckData
    /// Get contacts for OUA check data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<ContactList> GetContactsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ContactList> msg = new ResponseMessage<ContactList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetContactsForOUA();
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    /// <summary>
    /// SubmitTimeEntriesWithErrorMessage
    /// Submit time entries to server and detail error message with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    public ResponseMessage<Dictionary<Guid, string>> SubmitTimeEntriesWithErrorMessage(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<TimeEntryList> request)
    {
        ResponseMessage<Dictionary<Guid, string>> listMessageDetail = new ResponseMessage<Dictionary<Guid, string>>();
        Dictionary<Guid, string> listTemp = new Dictionary<Guid, string>();
        listMessageDetail.IsSuccessful = false;
        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                listMessageDetail.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return listMessageDetail;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                listTemp = facade.SubmitTimeEntries(request.Data, out success);
                listMessageDetail.Data = listTemp;
                listMessageDetail.IsSuccessful = success;
            }
        }
        catch (SqlException sqlEx)
        {
            listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            listMessageDetail.ErrorMessage = ex.Message;
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return listMessageDetail;
    }
    /// <summary>
    /// GetTimeEntryResponse
    /// Get time entries for OUA with NON AD mode and non exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <param name="retrieveCompleted"></param>
    /// <param name="approvedTimeEntryIDs"></param>
    /// <returns></returns>
    public ResponseMessage<TimeEntryList> GetTimeEntryResponse(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<bool> retrieveCompleted, RequestMessage<List<Guid>> approvedTimeEntryIDs)
    {
        ResponseMessage<TimeEntryList> msg = new ResponseMessage<TimeEntryList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.IsSuccessful = false;
                msg.Data = null;
                return msg;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                msg.Data = facade.GetTimeEntries(start.Data, end.Data, retrieveCompleted.Data, approvedTimeEntryIDs.Data, true);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    /// <summary>
    /// GetTimeEntryResponseForEX
    /// Get time entries for OUA with NON AD mode and Exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <param name="retrieveCompleted"></param>
    /// <param name="approvedTimeEntryIDs"></param>
    /// <param name="calendarID"></param>
    /// <returns></returns>
    public ResponseMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>> GetTimeEntryResponseForEX(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<bool> retrieveCompleted, RequestMessage<List<Guid>> approvedTimeEntryIDs, RequestMessage<string> calendarID)
    {
        ResponseMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>> msg = new ResponseMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.IsSuccessful = false;
                msg.Data = null;
                return msg;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                msg.Data = facade.GetTimeEntriesForEX(start.Data, end.Data, retrieveCompleted.Data, approvedTimeEntryIDs.Data, calendarID.Data, true);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }       

    /// <summary>
    /// SaveTimeEntry_OutlookAppointmentLinks
    /// Save links between time entry and appointment to server with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="list"></param>
    /// <returns></returns>
    public ResponseMessage<List<Guid>> SaveTimeEntry_OutlookAppointmentLinks(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<TimeEntry_OutlookAppointmentList> list)
    {
        ResponseMessage<List<Guid>> message = new ResponseMessage<List<Guid>>();
        message.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                message.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                message.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return message;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                bool success = false;
                message.Data = facade.SaveTimeEntry_OutlookAppointmentLinks(list.Data, out success);
                message.IsSuccessful = success;
            }

            //if (!success)
            //    throw new Exception();
            //success = false;
            //using (WorkflowFacade facade = new WorkflowFacade(context))
            //{
            //    success = facade.StartWorkflowInstance(request.Data);
            //}

        }
        catch (SqlException sqlEx)
        {
            message.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            message.ErrorMessage = ex.Message;
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return message;
    }
    /// <summary>
    /// SaveTimeEntry_OutlookAppointmentLink
    /// Save link between time entry and appointment to server with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="obj"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveTimeEntry_OutlookAppointmentLink(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<TimeEntry_OutlookAppointment> obj)
    {
        ResponseMessage<bool> message = new ResponseMessage<bool>();
        message.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                message.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                message.Data = false;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return message;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                message.Data = facade.SaveTimeEntry_OutlookAppointmentLink(obj.Data);
                message.IsSuccessful = true;
            }
        }
        catch (SqlException sqlEx)
        {
            message.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            message.ErrorMessage = ex.Message;
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return message;
    }
    /// <summary>
    /// GetTimeEntry_OutlookAppointmentLinkByTimeEntryID
    /// Get link between time entry and appointment by time entry id with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="teID"></param>
    /// <returns></returns>
    public ResponseMessage<TimeEntry_OutlookAppointment> GetTimeEntry_OutlookAppointmentLinkByTimeEntryID(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<Guid> teID)
    {
        ResponseMessage<TimeEntry_OutlookAppointment> message = new ResponseMessage<TimeEntry_OutlookAppointment>();
        message.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                message.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                message.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return message;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                message.Data = facade.GetTimeEntry_OutlookAppointmentLinkByTimeEntryID(teID.Data);
                message.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            message.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            message.ErrorMessage = ex.Message;
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return message;
    }
    /// <summary>
    /// GetTimeEntry_OutlookAppointmentLinkByOutlookItemID
    /// Get link between time entry and appointment by outlook item id with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="outlookItemID"></param>
    /// <returns></returns>
    public ResponseMessage<TimeEntry_OutlookAppointment> GetTimeEntry_OutlookAppointmentLinkByOutlookItemID(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> outlookItemID)
    {
        ResponseMessage<TimeEntry_OutlookAppointment> message = new ResponseMessage<TimeEntry_OutlookAppointment>();
        message.IsSuccessful = false;
        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                message.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                message.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return message;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                message.Data = facade.GetTimeEntry_OutlookAppointmentByOutlookItemID(outlookItemID.Data);
                message.IsSuccessful = success;
            }

        }
        catch (SqlException sqlEx)
        {
            message.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            message.ErrorMessage = ex.Message;
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return message;
    }
    /// <summary>
    /// GetAllTimeEntry_OutlookAppointmentLinks
    /// Get all of link between time entry and appointment with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<TimeEntry_OutlookAppointmentList> GetAllTimeEntry_OutlookAppointmentLinks(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<TimeEntry_OutlookAppointmentList> message = new ResponseMessage<TimeEntry_OutlookAppointmentList>();
        message.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                message.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                message.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return message;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                message.Data = facade.GetAllTimeEntry_OutlookAppointmentLinks();
                message.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            message.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            message.ErrorMessage = ex.Message;
            message.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return message;
    }
    /// <summary>
    /// SubmitTimeEntriesForEX
    /// Submit time entries to server with NON AD mode and Exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="request"></param>
    /// <param name="listOverwriteTE"></param>
    /// <param name="listNoChange"></param>
    /// <returns></returns>
    public ResponseMessage<Dictionary<Guid, string>> SubmitTimeEntriesForEX(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>> request, out ResponseMessage<Dictionary<Guid, Guid>> listOverwriteTE,
        out ResponseMessage<List<Guid>> listNoChange)
    {
        ResponseMessage<Dictionary<Guid, string>> listMessageDetail = new ResponseMessage<Dictionary<Guid, string>>();
        listOverwriteTE = new ResponseMessage<Dictionary<Guid, Guid>>();
        listNoChange = new ResponseMessage<List<Guid>>();
        Dictionary<Guid, string> listTemp = new Dictionary<Guid, string>();
        Dictionary<Guid, Guid> listOverwriteTEData = new Dictionary<Guid, Guid>();
        List<Guid> listNoChangeData = new List<Guid>();
        listMessageDetail.IsSuccessful = false;
        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                listMessageDetail.Data = null;
                listOverwriteTE.Data = null;
                listNoChange.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return listMessageDetail;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                listTemp = facade.SubmitTimeEntriesForEX(request.Data, out listOverwriteTEData, out listNoChangeData, out success);
                listMessageDetail.Data = listTemp;
                listOverwriteTE.Data = listOverwriteTEData;
                listNoChange.Data = listNoChangeData;
                listMessageDetail.IsSuccessful = success;
            }
        }
        catch (SqlException sqlEx)
        {
            listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            listMessageDetail.ErrorMessage = ex.Message;
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return listMessageDetail;
    }
    /// <summary>
    /// SaveUserAgentDataForEX
    /// Save user agent data with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="MachineID"></param>
    /// <param name="UserSpecificData"></param>
    /// <param name="MachineSpecificData"></param>
    /// <param name="MachineSpecificSettingsData"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveUserAgentDataForEX(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<String> MachineID, RequestMessage<String> UserSpecificData,
        RequestMessage<String> MachineSpecificData, RequestMessage<String> MachineSpecificSettingsData)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }
            //Validate data before saving user agent data           

            UserAgentInfo uasData = new UserAgentInfo();

            msg.Data = uasData.SaveUserSpecficData(context.UserID, UserSpecificData.Data)
                && uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificData.Data, UserAgentInfo.UserAgentDataTypes.Appointment)
                && uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings)
                && uasData.SaveMachineSpecficDataFoxEX(context.UserID, MachineSpecificData.Data, UserAgentInfo.UserAgentDataTypes.Appointment)
                && uasData.SaveMachineSpecficDataFoxEX(context.UserID, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings);
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// SaveMachineSpecificDataForEX
    /// Save machine speccific data with NON AD mode and Exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="MachineID"></param>
    /// <param name="MachineSpecificSettingsData"></param>
    /// <param name="MachineSpecificAppointmentData"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveMachineSpecificDataForEX(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<String> MachineID, RequestMessage<String> MachineSpecificSettingsData,
        RequestMessage<String> MachineSpecificAppointmentData)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }

            UserAgentInfo uasData = new UserAgentInfo();
            bool success = true;
            if (!string.IsNullOrEmpty(MachineSpecificAppointmentData.Data))
                success = msg.Data = uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificAppointmentData.Data, UserAgentInfo.UserAgentDataTypes.Appointment)
                                     && uasData.SaveMachineSpecficDataFoxEX(context.UserID, MachineSpecificAppointmentData.Data, UserAgentInfo.UserAgentDataTypes.Appointment);
            if ((success) && (!string.IsNullOrEmpty(MachineSpecificSettingsData.Data)))
                msg.Data = uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings)
                           && uasData.SaveMachineSpecficDataFoxEX(context.UserID, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings);

            msg.IsSuccessful = msg.Data;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetMachineSpecficAppointmentDataForEX
    /// Get machine specific appointment data with NON AD mode and Exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>    
    /// <returns></returns>
    public ResponseMessage<string> GetMachineSpecficAppointmentDataForEX(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        return GetMachineSpecDataForEX(userName, pass, UserAgentInfo.UserAgentDataTypes.Appointment);
    }
    /// <summary>
    /// GetLanguageXML
    /// Get language xml for OUA with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="languageID"></param>
    /// <param name="languageResourcesList"></param>
    /// <returns></returns>
    public ResponseMessage<LanguageResourcesList> GetLanguageXML(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> languageName, RequestMessage<LanguageResourcesList> languageResourcesList)
    {
        ResponseMessage<LanguageResourcesList> msg = new ResponseMessage<LanguageResourcesList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            string languageID = ResourceManager.GetLanguageIDByLanguageName(languageName.Data);
            if (string.IsNullOrEmpty(languageID))
            {
                string STRLanguage = ResourceManager.GetResourceString("LanguagereCouldNotBeRetrievedFromLanguage", "Language resources could not be retrieved from language name '");
                string STRPlease = ResourceManager.GetResourceString("PleaseTryAgain", "'. Please try again!");
                throw new Exception(STRLanguage + languageName.Data + STRPlease);
            }
            //CultureInfo culture = CultureInfo.CreateSpecificCulture(languageName.Data); //new CultureInfo(languageName);
            LanguageResourcesList list = languageResourcesList.Data;
            foreach (LanguageResources lr in list)
            {
                lr.LanguageID = languageID;
                lr.LanguageName = languageName.Data;
                lr.ResourceValue = ResourceManager.GetResourceString(lr.ResourceKey, lr.ResourceValue, languageName.Data, languageID);
            }

            msg.Data = list;
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetLanguages
    /// Get languages that be used in TSR Server for OUA with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<StringCollection> GetLanguages(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<StringCollection> msg = new ResponseMessage<StringCollection>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            StringCollection collection = new StringCollection();
            using (ResourceFacade facade = new ResourceFacade(context))
            {
                List<String> list = facade.GetLanguages();
                foreach (String obj in list)
                {
                    String langId = facade.GetLanguageIDByLanguageName(obj);
                    collection.Add(obj);
                    collection.Add(langId);
                }
                msg.Data = collection;
                msg.IsSuccessful = true;
            }
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// SavePreferredPathsInServer
    /// Save favorites of OUA client to Server with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="UserAgentPreferredPaths"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SavePreferredPathsInServer(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<List<PreferredPath>> UserAgentPreferredPaths)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }

            UserAgentPreferredPathData ppData = new UserAgentPreferredPathData();

            msg.Data = ppData.UpdatePreferredPaths(UserAgentPreferredPaths.Data, context.UserID);
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetPreferredPathsFromServer
    /// Get favorites for OUA client with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<List<PreferredPath>> GetPreferredPathsFromServer(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<List<PreferredPath>> msg = new ResponseMessage<List<PreferredPath>>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            UserAgentPreferredPathData ppData = new UserAgentPreferredPathData();

            msg.Data = ppData.GetPreferredPathForUser(context.UserID);
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// SaveUserSettingsInServer
    /// Save user settings to server with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="UserAgentSettings"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveUserSettingsInServer(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<List<UserSetting>> UserAgentSettings)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }
            UserDefaultSettingList defaultList = new UserDefaultSettingList();
            foreach (UserSetting setting in UserAgentSettings.Data)
            {
                if (string.Compare(setting.SettingsName, "TSRAutoSyncIndex", true) == 0)
                {
                    int val;
                    if (!int.TryParse(setting.SettingsValue, out val))
                    {
                        setting.SettingsValue = ConstantCollection.MINIMUM_TIMEINTERVAL_AUTOMACTIC_SYNC.ToString();
                    }
                    else
                    {
                        if (val < 5)
                            setting.SettingsValue = ConstantCollection.MINIMUM_TIMEINTERVAL_AUTOMACTIC_SYNC.ToString();
                    }
                }
                defaultList.Add(new UserDefaultSetting
                {
                    UserID = (long?)context.UserID,
                    SettingsName = setting.SettingsName,
                    SettingsValue = setting.SettingsValue
                });

            }
            if (defaultList != null)
            {
                using (SetupDataFacade facade = new SetupDataFacade(context))
                {
                    msg.Data = facade.UpdateUserSettings(defaultList, (long?)context.UserID);
                }
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetUserSettingsFromServer
    /// Get user settings for OUA client with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="isDefault"></param>
    /// <returns></returns>
    public ResponseMessage<List<UserSetting>> GetUserSettingsFromServer(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<bool> isDefault)
    {
        ResponseMessage<List<UserSetting>> msg = new ResponseMessage<List<UserSetting>>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            UserAgentSettingsData uasData = new UserAgentSettingsData();

            if (isDefault.Data)
            {
                msg.Data = uasData.GetSettingsForUser(null);
            }
            else
            {
                msg.Data = uasData.GetSettingsForUser(context.UserID);
                if ((msg.Data == null) || ((msg.Data != null) && (msg.Data.Count == 0)))
                    msg.Data = uasData.GetSettingsForUser(null);
            }

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// SaveUserAgentData
    /// Save user agent data to server with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="MachineID"></param>
    /// <param name="UserSpecificData"></param>
    /// <param name="MachineSpecificData"></param>
    /// <param name="MachineSpecificSettingsData"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveUserAgentData(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<String> MachineID, RequestMessage<String> UserSpecificData,
        RequestMessage<String> MachineSpecificData, RequestMessage<String> MachineSpecificSettingsData)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }
            //Validate data before saving user agent data           

            UserAgentInfo uasData = new UserAgentInfo();

            msg.Data = uasData.SaveUserSpecficData(context.UserID, UserSpecificData.Data)
                && uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificData.Data, UserAgentInfo.UserAgentDataTypes.Appointment)
                && uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings);
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// SaveMachineSpecificData
    /// Save machine specific data to server with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="MachineID"></param>
    /// <param name="MachineSpecificSettingsData"></param>
    /// <param name="MachineSpecificAppointmentData"></param>
    /// <returns></returns>
    public ResponseMessage<bool> SaveMachineSpecificData(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<String> MachineID, RequestMessage<String> MachineSpecificSettingsData, RequestMessage<String> MachineSpecificAppointmentData)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                return msg;
            }

            UserAgentInfo uasData = new UserAgentInfo();
            bool success = true;
            if (!string.IsNullOrEmpty(MachineSpecificAppointmentData.Data))
                success = msg.Data = uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificAppointmentData.Data, UserAgentInfo.UserAgentDataTypes.Appointment);
            if ((success) && (!string.IsNullOrEmpty(MachineSpecificSettingsData.Data)))
                msg.Data = uasData.SaveMachineSpecficData(context.UserID, MachineID.Data, MachineSpecificSettingsData.Data, UserAgentInfo.UserAgentDataTypes.Settings);

            msg.IsSuccessful = msg.Data;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetUserSpecficData
    /// Get user specific data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<string> GetUserSpecficData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<string> msg = new ResponseMessage<string>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            UserAgentInfo uasData = new UserAgentInfo();


            msg.Data = uasData.GetUserSpecificData(context.UserID);

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// GetLicense
    /// Get license with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<ApplicationLicense> GetLicense(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                {
                    license.Version = "5.9";
                    for (int i = 0; i < license.Modules.Count; i++)
                    {
                        if (license.Modules[i].Key.Contains("TSR-EXP"))
                        {
                            license.Modules[i].FunctionalExpiryDate = DateTime.Today.AddDays(5);
                            license.NumberOfExpenseUsers = 0;
                        }
                    }
                }
                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense6(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                    license.Version = "6.1";
                
                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense62(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();
            }

            if (license != null)
            {
                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);
                //Feature 339: Support for newer version numbers if old OUA
                string[] arrSubVersion = license.Version.Split('.');
                if (arrSubVersion.Length > 0 && arrSubVersion[0] == "6")
                    license.Version = "6.2";

                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    public ResponseMessage<ApplicationLicense> GetLicense63(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ApplicationLicense> msg = new ResponseMessage<ApplicationLicense>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }
            ApplicationLicense license = new ApplicationLicense();
            using (SecurityFacade securityFacade = new SecurityFacade(context))
            {
                license = securityFacade.GetLicense();                
            }

            if (license != null)
            {
                int index = -1;
                for (int i = 0; i < license.Modules.Count; i++)
                {
                    if (license.Modules[i].Key.Contains("TSR-RATE"))
                    {
                        index = i;
                        break;
                    }
                }
                if (index > -1) license.Modules.RemoveAt(index);
                msg.Data = license;
                msg.IsSuccessful = true;
            }

        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }

    /// <summary>
    /// IsLockedUserSettings
    /// Check whether user settings is locked with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<bool> IsLockedUserSettings(RequestMessage<string> userName, RequestMessage<string> pass)
    {

        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.Data = false;
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = true;
                return msg;
            }
            bool success = true;
            using (SetupDataFacade facade = new SetupDataFacade(context))
            {
                LockUserSettings lockSettings = new LockUserSettings();
                lockSettings = facade.GetLockUserSettingsByUserID(context.UserID);
                if (lockSettings != null)
                {
                    msg.Data = lockSettings.IsLocked;
                }
                success = true;
            }
            msg.IsSuccessful = success;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            msg.Data = true;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            msg.Data = true;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    /// <summary>
    /// DeleteTimeEntries
    /// Delete time entries with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="guidString"></param>
    /// <returns></returns>
    public ResponseMessage<bool> DeleteTimeEntries(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<List<Guid>> listGuid)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.IsSuccessful = false;
        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                success = facade.DeleteTimeEntries(listGuid.Data);
            }

            //if (!success)
            //    throw new Exception();
            //success = false;
            //using (WorkflowFacade facade = new WorkflowFacade(context))
            //{
            //    success = facade.StartWorkflowInstance(request.Data);
            //}

            msg.Data = success;
            msg.IsSuccessful = success;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;

    }
    /// <summary>
    /// OverwriteTimeEntriesForEX
    /// Overwrite time entries with NON AD mode and exchange mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <param name="request"></param>
    /// <returns></returns>
    public ResponseMessage<Dictionary<Guid, string>> OverwriteTimeEntriesForEX(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<TimeEntryList> request)
    {
        ResponseMessage<Dictionary<Guid, string>> listMessageDetail = new ResponseMessage<Dictionary<Guid, string>>();
        Dictionary<Guid, string> listTemp = new Dictionary<Guid, string>();
        listMessageDetail.IsSuccessful = false;
        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return listMessageDetail;
            }

            using (TimeFacade facade = new TimeFacade(context))
            {
                listTemp = facade.OverwriteTimeEntriesForEX(request.Data, out success);
                listMessageDetail.Data = listTemp;
                listMessageDetail.IsSuccessful = success;
            }

            //if (!success)
            //    throw new Exception();
            //success = false;
            //using (WorkflowFacade facade = new WorkflowFacade(context))
            //{
            //    success = facade.StartWorkflowInstance(request.Data);
            //}

        }
        catch (SqlException sqlEx)
        {
            listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            listMessageDetail.ErrorMessage = ex.Message;
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return listMessageDetail;
    }
    public ResponseMessage<string> GetMachineSpecficSettingsDataForEX(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        return GetMachineSpecDataForEX(userName, pass, UserAgentInfo.UserAgentDataTypes.Settings);
    }
    public ResponseMessage<string> GetMachineSpecficAppointmentData(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> MachineID)
    {
        return GetMachineSpecData(userName, pass, MachineID, UserAgentInfo.UserAgentDataTypes.Appointment);
    }
    public ResponseMessage<string> GetMachineSpecficSettingsData(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> MachineID)
    {
        return GetMachineSpecData(userName, pass, MachineID, UserAgentInfo.UserAgentDataTypes.Settings);
    }
    private ResponseMessage<string> GetMachineSpecDataForEX(RequestMessage<string> userName, RequestMessage<string> pass, TSR.EFDataAccess.UserAgentInfo.UserAgentDataTypes UserAgentDataType)
    {
        ResponseMessage<string> msg = new ResponseMessage<string>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
            //{
            //    LoggingTime = DateTime.Now,
            //    CreatedTimeStamp = DateTime.Now,
            //    SessionID = string.Empty,
            //    Priority = 0,
            //    MessageSummary = "Authentication failed"
            //});
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            UserAgentInfo uasData = new UserAgentInfo();


            msg.Data = uasData.GetMachineSpecificDataForEX(context.UserID, UserAgentDataType);

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    private ResponseMessage<string> GetMachineSpecData(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<string> MachineID, TSR.EFDataAccess.UserAgentInfo.UserAgentDataTypes UserAgentDataType)
    {
        ResponseMessage<string> msg = new ResponseMessage<string>();
        msg.Data = null;
        msg.IsSuccessful = false;
        try
        {
            //TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
            //{
            //    LoggingTime = DateTime.Now,
            //    CreatedTimeStamp = DateTime.Now,
            //    SessionID = string.Empty,
            //    Priority = 0,
            //    MessageSummary = "Authentication failed"
            //});
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                return msg;
            }

            UserAgentInfo uasData = new UserAgentInfo();


            msg.Data = uasData.GetMachineSpecificData(context.UserID, MachineID.Data, UserAgentDataType);

            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }
        return msg;
    }
    //end

    //added by tsrdev2
    /// <summary>
    /// Gets error message for failed login of the user
    /// </summary>
    /// <param name="logFailed"></param>
    /// <returns></returns>
    private string GetFailedLoginMessage(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        int countFailed = CountOfTimesContinuosWrongPassword(logFailedLogin.UserID, logFailedLogin.LoggingTime, 1);
        string message = string.Empty;
        switch ((TypeOfEventEnum)logFailedLogin.TyOfEvent)
        {
            case TypeOfEventEnum.UnknownUser:
                message = ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.");
                break;
            case TypeOfEventEnum.WrongPassword:
                //after 3 failed login in one hour
                //int countFailed = CountOfTimesContinuosWrongPassword(logFailedLogin.UserID, logFailedLogin.LoggingTime, 1);
                if (countFailed < 3)
                    message = ResourceManager.GetResourceString("LoginFailedMessage", "Login failed, User Name or Password is invalid.");
                else if (countFailed < 10)
                {
                    int delay = ComputingDelay(countFailed);
                    message = ResourceManager.GetResourceString("LoginFailedSubsequent", "You have {0} failed attempts to login within a time span of one hour")
                                      + ". " + ResourceManager.GetResourceString("LoginFailedTimeDelay", "Please waiting {1} seconds to try to login again.");
                    message = string.Format(message, countFailed, delay);
                }
                else //countFailed == 10
                {
                    if (LockUser(logFailedLogin.UserID))
                        message = ResourceManager.GetResourceString("LoginFailedTenTimes", "You have 10 failed attempts to login, your account has been locked. Please contact with TSR administrator.");
                }

                break;
            case TypeOfEventEnum.AccountLocked:
                message = ResourceManager.GetResourceString("LoginLockedAccount", "This account has been locked. Please contact with TSR administrator.");
                break;
            case TypeOfEventEnum.AccountUnlocked:
                break;
            case TypeOfEventEnum.PasswordChanged:
                break;
            default:
                break;
        }
        return message;
    }

    //added by tsrdev2
    private string GetFailedLoginMessageForOUA(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        //string message = string.Empty;
        //switch ((TypeOfEventEnum)logFailedLogin.TyOfEvent)
        //{
        //    case TypeOfEventEnum.UnknownUser:
        //        message = ResourceManager.GetResourceString("NotATSRUserMsg", "Login failed. You must be a TSR user to login into this site.");
        //        break;
        //    case TypeOfEventEnum.WrongPassword:                               
        //        message = ResourceManager.GetResourceString("LoginFailedMessage", "Login failed, User Name or Password is invalid.");
        //        break;
        //    case TypeOfEventEnum.AccountLocked:
        //        message = ResourceManager.GetResourceString("LoginLockedAccount", "This account has been locked. Please contact with TSR administrator.");
        //        break;            
        //}
        //return message;
        //return index of typeOfEvent order to gets local resources on OUA
        return ((int)logFailedLogin.TyOfEvent).ToString();
    }

    //added by tsrdev2
    private int CountOfTimesContinuosWrongPassword(long userid, DateTime currLogging, int hourSpan)
    {
        //gets template user context, have to remove template user context when not be used
        UserContext context = AuthenticationFacade.GetTempContext();
        //times of failed login
        int countOfFailedLogin = 0;
        using (SecurityFacade securityFacade = new SecurityFacade(context))
        {
            countOfFailedLogin = securityFacade.TimesOfFailedLoginOfUserInTimeSpan(userid, currLogging, hourSpan, SourceType.OUA);
        }
        //remove temp context
        SecurityManager.SetUserContext(null);
        return countOfFailedLogin;
    }

    //added by tsrdev
    private bool SaveLogFailedLogin(TSR.Framework.Logging.LogFailedLogin logFailedLogin)
    {
        if (logFailedLogin != null)
        {
            logFailedLogin.Source = SourceType1.OUA;
            logFailedLogin.ClientIP = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"]; //or HttpContext.Current.Request.UserHostAddress   
            TSR.Framework.Logging.LoggingHandler.LogFailedLoginInfo(logFailedLogin);
        }
        return true;
    }

    //added by tsrdev2
    private bool LockUser(long userID)
    {
        bool success = false;
        if (userID > 0)
        {
            User user = new User();
            //set template usercontext
            UserContext context = AuthenticationFacade.GetTempContext();
            try
            {
                using (SecurityFacade facade = new SecurityFacade(context))
                {
                    user = facade.GetUserByID(userID);

                    user.IsActive = false;
                    user.RowState = BaseBusinessEntity.RowStateEnum.InActiveRow;
                    success = facade.UpdateUser(user);
                    if (success)
                    {
                        //log changed pass for this user                        
                        if (!user.IsActive) //is inActive (locked) user
                        {
                            TSR.Framework.Logging.LoggingHandler.LogFailedLoginInfo(new TSR.Framework.Logging.LogFailedLogin
                            {
                                UserID = user.ID,
                                UserName = user.Username,
                                Source = SourceType1.WebServices,
                                TyOfEvent = TypeOfEventEnum1.AccountLocked,
                                ClientIP = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"], //or HttpContext.Current.Request.UserHostAddress 
                            });
                        }
                    }
                }
            }
            catch (TSR.Framework.Exceptions.LicenseException lexp)
            {
                TSR.Framework.Logging.LoggingHandler.LogUnhandledException(lexp.InnerException);
            }
            catch (Exception ex)
            {
                TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
            }
            finally
            {
                //remove temp usercontext
                SecurityManager.SetUserContext(null);
            }
        }
        return success;
    }

    //added by tsrdev2
    private int ComputingDelay(int countWrongPass)
    {
        if (countWrongPass < 3 || countWrongPass >= 10)
        {
            return 0;
        }
        int delay = TSR.Framework.ConstantCollection.LOGIN_DELAY;
        return delay * Convert.ToInt32(Math.Pow(2, ((double)countWrongPass - 3)));
    }

    public ResponseMessage<ExpenseTypeList> GetAllExpenseTypes(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<ExpenseTypeList> msg = new ResponseMessage<ExpenseTypeList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }
            if (context.IsInExpenseLicense)
            {
                using (ExpenseFacade facade = new ExpenseFacade(context))
                {
                    //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                    msg.Data = facade.GetAllExpenseTypes();
                }
            }
            else
            {
                msg.Data = null;
                msg.IsSuccessful = false;
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<bool> UserInExpenseLicense(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = false;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            msg.Data = AuthenticationFacade.UserHasExpensePermission(context.UserID);
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<Dictionary<long, string>> SubmitExpenses(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<ExpenseSheetList> request)
    {
        ResponseMessage<Dictionary<long, string>> listMessageDetail = new ResponseMessage<Dictionary<long, string>>();
        listMessageDetail.IsSuccessful = false;

        try
        {
            bool success = false;

            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                listMessageDetail.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return listMessageDetail;
            }

            using (ExpenseFacade facade = new ExpenseFacade(context))
            {
                facade.UpdateExpensesFromOUA(request.Data, out success);

                listMessageDetail.Data = null;
                listMessageDetail.IsSuccessful = success;
            }
        }
        catch (SqlException sqlEx)
        {
            listMessageDetail.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            listMessageDetail.ErrorMessage = ex.Message;
            listMessageDetail.IsSuccessful = false;
            LoggingHandler.LogUnhandledException(ex);
        }

        return listMessageDetail;
    }

    public ResponseMessage<ExpenseSheetList> GetExpensesResponse(RequestMessage<string> userName, RequestMessage<string> pass,
        RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<string> calendarID)
    {
        ResponseMessage<ExpenseSheetList> msg = new ResponseMessage<ExpenseSheetList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.IsSuccessful = false;
                msg.Data = null;
                return msg;
            }

            using (ExpenseFacade facade = new ExpenseFacade(context))
            {
                msg.Data = facade.GetExpensesForOUA(context.UserID, start.Data, end.Data, calendarID.Data);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }


    /// <summary>
    /// GetLocationsForCheckData
    /// Get Location for OUA check data with NON AD mode
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<LocationList> GetLocationsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        var msg = new ResponseMessage<LocationList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (var facade = new LocationFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetAllLocation();
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    /// <summary>
    /// Get LockPeriod By UserID
    /// </summary>
    /// <param name="userName"></param>
    /// <param name="pass"></param>
    /// <returns></returns>
    public ResponseMessage<LockPeriodList> GetLockPeriods(RequestMessage<string> userName, RequestMessage<string> pass)
    {
        var msg = new ResponseMessage<LockPeriodList>();
        msg.IsSuccessful = false;
        try
        {
            //make sure user is authenticated tsr user
            UserContext context = GetNONADUserContext(userName.Data, pass.Data);
            if (context == null)
            {
                msg.ErrorMessage = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed");
                msg.Data = null;
                TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                {
                    LoggingTime = DateTime.Now,
                    CreatedTimeStamp = DateTime.Now,
                    SessionID = string.Empty,
                    Priority = 0,
                    MessageSummary = ResourceManager.GetResourceString("AuthenticationFailed", "Authentication failed")
                });
                return msg;
            }

            using (var facade = new LockPeriodFacade(context))
            {
                //retrieving organizations and child entities [projects, activties, etc. - which basically means setup data] for user
                msg.Data = facade.GetLockPeriodByUserID(context.UserID);
            }
            msg.IsSuccessful = true;
        }
        catch (SqlException sqlEx)
        {
            msg.ErrorMessage = ResourceManager.GetResourceString("ErrorDatabase", "Database error, please contact administrator");
            LoggingHandler.LogUnhandledException(sqlEx);
        }
        catch (Exception ex)
        {
            msg.ErrorMessage = ex.Message;
            LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }
    #endregion
}
