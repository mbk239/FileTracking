﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Activation;
using TSR.Framework.Web.Security;
using TSR.Facade;
using System.Web;
using TSR.Framework.Resource;

/// <summary>
/// Not used any more. Authentication is done with AD. Will be removed soon
/// </summary>
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
[ServiceBehavior(Name = "AuthenticationService", InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Single)]
public class AuthenticationService : BaseSecuredServiceLibrary, IAuthenticationService
{

    #region IAuthenticationService Members

    public bool IsServiceUp()
    {
        return true;
    }

    public ResponseMessage<bool> PerformLogin(string username, string password)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>(true);
        try
        {
            using (AuthenticationFacade facade = new AuthenticationFacade())
            {
                TSR.Framework.UserContext context = facade.LogInUser(username, password, HttpContext.Current.Session.SessionID);
                if (context == null)
                {
                    msg.IsSuccessful = msg.Data = false;
                    msg.ErrorMessage = ResourceManager.GetResourceString("ErrMsgInvalidUsernamePassword", "Invalid username or password.");
                    TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("ErrMsgInvalidUsernamePassword", "Invalid username or password.")
                    });
                }
                else
                {
                    msg.IsSuccessful = msg.Data = true;
                }
            }
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    public ResponseMessage<bool> PerformADLogin(string username, string ADUserSID)
    {
        ResponseMessage<bool> msg = new ResponseMessage<bool>(true);
        try
        {
            using (ADAuthenticationFacade facade = new ADAuthenticationFacade())
            {
                TSR.Framework.UserContext context = facade.LogInUser(username, ADUserSID, OperationContext.Current.SessionId);
                if (context == null)
                {
                    msg.IsSuccessful = msg.Data = false;
                    msg.ErrorMessage = ResourceManager.GetResourceString("ErrMsgInvalidUsernamePassword", "Invalid username or password.");
                    TSR.Framework.Logging.LoggingHandler.LogError(new TSR.Framework.Logging.Log
                    {
                        LoggingTime = DateTime.Now,
                        CreatedTimeStamp = DateTime.Now,
                        SessionID = string.Empty,
                        Priority = 0,
                        MessageSummary = ResourceManager.GetResourceString("ErrMsgInvalidUsernamePassword", "Invalid username or password.")
                    });
                }
                else
                {
                    msg.IsSuccessful = msg.Data = true;
                }
            }
        }
        catch (Exception ex)
        {
            msg.IsSuccessful = false;
            msg.ErrorMessage = ex.Message;
            TSR.Framework.Logging.LoggingHandler.LogUnhandledException(ex);
        }

        return msg;
    }

    #endregion
}