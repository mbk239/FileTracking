﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using TSR.Entities;
using TSR.Entities.Bases;
using TSR.Entities.Lists;
using System.Collections.Specialized;
using TSR.EFDataAccess;
using TSR.Framework.Security;

// NOTE: If you change the interface name "IUserAgentService" here, you must also update the reference to "IUserAgentService" in App.config.
[ServiceContract(Name = "IUserAgentService", Namespace = "http://tsr.advancedservices.useragentservice", SessionMode = SessionMode.Allowed)]
//interface for user agent service
public interface IUserAgentService
{
    [OperationContract]
    bool IsServiceUp();
    ResponseMessage<string> GetConfiguration();

    [OperationContract]
    ResponseMessage<OrganizationList> GetSetupData(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<OrganizationList> GetOrganizationsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ProjectList> GetProjectsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ActivityList> GetAcitiviesForCheckData(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ContactList> GetContactsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<Dictionary<Guid, string>> SubmitTimeEntriesWithErrorMessage(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<TimeEntryList> request);
    [OperationContract]
    ResponseMessage<TimeEntryList> GetTimeEntryResponse(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<bool> retrieveCompleted, RequestMessage<List<Guid>> approvedTimeEntryIDs);    
    [OperationContract]
    ResponseMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>> GetTimeEntryResponseForEX(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<bool> retrieveCompleted, RequestMessage<List<Guid>> approvedTimeEntryIDs, RequestMessage<string> calendarID);
    [OperationContract]
    ResponseMessage<List<Guid>> SaveTimeEntry_OutlookAppointmentLinks(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<TimeEntry_OutlookAppointmentList> list);
    [OperationContract]
    ResponseMessage<bool> SaveTimeEntry_OutlookAppointmentLink(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<TimeEntry_OutlookAppointment> obj);
    [OperationContract]
    ResponseMessage<TimeEntry_OutlookAppointment> GetTimeEntry_OutlookAppointmentLinkByTimeEntryID(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<Guid> teID);
    [OperationContract]
    ResponseMessage<TimeEntry_OutlookAppointment> GetTimeEntry_OutlookAppointmentLinkByOutlookItemID(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<string> outlookItemID);
    [OperationContract]
    ResponseMessage<TimeEntry_OutlookAppointmentList> GetAllTimeEntry_OutlookAppointmentLinks(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<Dictionary<Guid, string>> SubmitTimeEntriesForEX(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<Dictionary<TimeEntry, TimeEntry_OutlookAppointment>> request, out ResponseMessage<Dictionary<Guid, Guid>> listOverwriteTE, out ResponseMessage<List<Guid>> listNoChange);
    [OperationContract]
    ResponseMessage<Dictionary<Guid, string>> OverwriteTimeEntriesForEX(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<TimeEntryList> request);    
    [OperationContract]
    ResponseMessage<bool> SaveUserAgentDataForEX(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<String> MachineID, RequestMessage<String> UserSpecificData, RequestMessage<String> MachineSpecificData, RequestMessage<String> MachineSpecificSettingsData);
    [OperationContract]
    ResponseMessage<bool> SaveMachineSpecificDataForEX(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<String> MachineID, RequestMessage<String> MachineSpecificSettingsData, RequestMessage<String> MachineSpecificAppointmentData);    
    [OperationContract]
    ResponseMessage<string> GetMachineSpecficAppointmentDataForEX(RequestMessage<string> userName, RequestMessage<string> pass);    
    [OperationContract]
    ResponseMessage<LanguageResourcesList> GetLanguageXML(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<string> languageID, RequestMessage<LanguageResourcesList> languageResourcesList);    
    [OperationContract]
    ResponseMessage<StringCollection> GetLanguages(RequestMessage<string> userName, RequestMessage<string> pass);    
    [OperationContract]
    ResponseMessage<bool> SavePreferredPathsInServer(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<List<PreferredPath>> UserAgentPreferredPaths);
    [OperationContract]
    ResponseMessage<List<PreferredPath>> GetPreferredPathsFromServer(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<bool> SaveUserSettingsInServer(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<List<UserSetting>> UserAgentSettings);
    [OperationContract]
    ResponseMessage<List<UserSetting>> GetUserSettingsFromServer(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<bool> isDefault);
    [OperationContract]
    ResponseMessage<bool> SaveUserAgentData(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<String> MachineID, RequestMessage<String> UserSpecificData, RequestMessage<String> MachineSpecificData, RequestMessage<String> MachineSpecificSettingsData);
    [OperationContract]
    ResponseMessage<bool> SaveMachineSpecificData(RequestMessage<string> userName,RequestMessage<string> pass,RequestMessage<String> MachineID, RequestMessage<String> MachineSpecificSettingsData, RequestMessage<String> MachineSpecificAppointmentData);
    [OperationContract]
    ResponseMessage<string> GetUserSpecficData(RequestMessage<string> userName, RequestMessage<string> pass);        
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense6(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense62(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ApplicationLicense> GetLicense63(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<bool> IsLockedUserSettings(RequestMessage<string> userName, RequestMessage<string> pass);

    [OperationContract]
    ResponseMessage<bool> LogInUser(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<TSR.Framework.Logging.LogFailedLogin> LogInUserWithLog(RequestMessage<string> userName, RequestMessage<string> pass, out int delay);
    [OperationContract]
    ResponseMessage<bool> LogInUserWithLogDB(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<LogOUALogin> request);
 
    [OperationContract]
    ResponseMessage<bool> DeleteTimeEntries(RequestMessage<string> userName, RequestMessage<string> pass,RequestMessage<List<Guid>> guidString);
    [OperationContract]
    ResponseMessage<string> GetMachineSpecficSettingsDataForEX(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<string> GetMachineSpecficAppointmentData(RequestMessage<string> userName, RequestMessage<string> pass,RequestMessage<string> MachineID);
    [OperationContract]
    ResponseMessage<string> GetMachineSpecficSettingsData(RequestMessage<string> userName, RequestMessage<string> pass,RequestMessage<string> MachineID);
    //add by tsrdev3
    [OperationContract]
    ResponseMessage<OrganizationVersionList> GetSetupDataRelation(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ContactVersionList> GetSetupData_Contacts(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ContactList> GetSetupData_ChangedContact(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged);
    [OperationContract]
    ResponseMessage<Organization_ContactList> GetSetupData_OrganizationContact(RequestMessage<string> userName, RequestMessage<string> password);
    [OperationContract]
    ResponseMessage<OrganizationList> GetSetupData_ChangedOrganizations(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged);
    [OperationContract]
    ResponseMessage<ProjectList> GetSetupData_ChangedProjects(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged);
    [OperationContract]
    ResponseMessage<ActivityList> GetSetupData_ChangedActivities(RequestMessage<string> userName, RequestMessage<string> password, RequestMessage<Int64[]> listChanged);
    [OperationContract]
    ResponseMessage<OrganizationList> GetSetupData_Organization(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ProjectList> GetSetupData_Project(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<long> organizationID);
    [OperationContract]
    ResponseMessage<ExpenseTypeList> GetAllExpenseTypes(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<bool> UserInExpenseLicense(RequestMessage<string> userName, RequestMessage<string> pass);
    [OperationContract]
    ResponseMessage<ExpenseSheetList> GetExpensesResponse(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<DateTime> start, RequestMessage<DateTime> end, RequestMessage<string> calendarID);
    [OperationContract]
    ResponseMessage<Dictionary<long, string>> SubmitExpenses(RequestMessage<string> userName, RequestMessage<string> pass, RequestMessage<ExpenseSheetList> request);

    [OperationContract]
    ResponseMessage<LocationList> GetLocationsForCheckData(RequestMessage<string> userName, RequestMessage<string> pass);

    [OperationContract]
    ResponseMessage<LockPeriodList> GetLockPeriods(RequestMessage<string> userName, RequestMessage<string> pass);
}
