﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

// deprecated interface. remove candidate
[ServiceContract(Name = "IAuthenticationService", Namespace = "http://TSR.advancedservices.authenticationservice", SessionMode = SessionMode.Allowed)]
public interface IAuthenticationService
{
    // TODO: Add your service operations here
    [OperationContract]
    bool IsServiceUp();

    [OperationContract]
    ResponseMessage<bool> PerformLogin(string username, string password);

    [OperationContract]
    ResponseMessage<bool> PerformADLogin(string username, string ADUserSID);
}
