﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for AuthenticationMessage
/// </summary>
/// 
[DataContract]
public class AuthenticationMessage : BaseSecuredMessage
{
    public AuthenticationMessage()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}
