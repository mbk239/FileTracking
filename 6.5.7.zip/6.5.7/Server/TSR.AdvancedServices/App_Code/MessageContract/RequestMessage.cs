﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;


/// <summary>
/// Class
/// Name: RequestMessage
/// Description: This class is a Request Template Message 
/// has some own properties for a Template
/// </summary>
/// <typeparam name="T"></typeparam>
[DataContract]
public class RequestMessage<T>
{
    private T _Data;
    [DataMember]
    public T Data
    {
        get { return _Data; }
        set { _Data = value; }
    }

    private Int32 _PageNo = 0;
    [DataMember]
    public Int32 PageNo
    {
        get { return _PageNo; }
        set { _PageNo = value; }
    }

}
