﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.ServiceModel;


/// <summary>
/// Summary description for RemoteFileInfo
/// </summary>

[MessageContract]
public class RemoteFileInfo: IDisposable
{
    [MessageHeader(MustUnderstand = true)]
    //[DataMember]
    public string FileName
    {
        get;
        set;
    }

    [MessageHeader(MustUnderstand = true)]
    //[DataMember]
    public long Length
    {
        get;
        set;
    }

    [MessageBodyMember(Order = 1)]
    //[DataMember]
    public System.IO.Stream FileByteStream
    {
        get;
        set;
    }

    public void Dispose()
    {
        // close stream when the contract instance is disposed. this ensures that stream is closed when file download is complete, since download procedure is handled by the client and the stream must be closed on server.        
        if (FileByteStream != null)
        {
            FileByteStream.Close();
            FileByteStream = null;
        }
    }
}

