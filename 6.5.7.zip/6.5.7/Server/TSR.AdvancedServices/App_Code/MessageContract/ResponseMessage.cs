﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Runtime.Serialization;

/// <summary>
/// Class
/// Name: ResponseMessage
/// Description: This class is a Response Template Message 
/// who inherits BaseSecuredMessage and
/// has some own properties for a Template
/// </summary>
/// <typeparam name="T"></typeparam>
/// 
[DataContract]
public class ResponseMessage<T> : BaseSecuredMessage
{
    public ResponseMessage() { }
    public ResponseMessage(T value)
    {
        _Data = value;
    }
    private T _Data;
    [DataMember]
    public T Data
    {
        get { return _Data; }
        set { _Data = value; }
    }
    private Int32 _PageCount = 0;
    [DataMember]
    public Int32 PageCount
    {
        get { return _PageCount; }
        set { _PageCount = value; }
    }
    private Int32 _PageNo = 0;
    [DataMember]
    public Int32 PageNo
    {
        get { return _PageNo; }
        set { _PageNo = value; }
    }
}
