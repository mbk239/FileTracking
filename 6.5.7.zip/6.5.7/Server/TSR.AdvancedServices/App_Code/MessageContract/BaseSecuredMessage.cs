﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for BaseSecuredMessage
/// </summary>
/// 

[DataContract]
public class BaseSecuredMessage : BaseMessage
{
    private long _UserID;

    private Guid _SessionID;
    [DataMember]
    public long UserID
    {
        get { return _UserID; }
        set { _UserID = value; }
    }
    [DataMember]
    public Guid SessionID
    {
        get { return _SessionID; }
        set { _SessionID = value; }
    }
}
