﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Runtime.Serialization;

/// <summary>
/// Summary description for BaseMessage
/// </summary>

[DataContract]
public class BaseMessage
{
    private Boolean _IsSuccessful = true;
    [DataMember]
    public Boolean IsSuccessful
    {
        get { return _IsSuccessful; }
        set { _IsSuccessful = value; }
    }
    private String _SuccessMessage;
    [DataMember]
    public String SuccessMessage
    {
        get { return _SuccessMessage; }
        set { _SuccessMessage = value; }
    }

    private String _ErrorMessage;
    [DataMember]
    public String ErrorMessage
    {
        get { return _ErrorMessage; }
        set { _ErrorMessage = value; }
    }
    [DataMember]        
    public bool IsException
    {
        get;
        set;
    }
}
