using System;
using System.Transactions;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for TSR Contacts
    /// Contacts are usually assigned to Organizations.
    /// Contacts use the core Person data model (i.e. each Contact is also in Person table with a person type of contact, etc.)
    /// 
    /// last updated on:
    /// august 31, 2009
    /// change description:
    /// </summary>
    public class ContactManager : BaseManager
    {
        public ContactManager(UserContext context) : base(context) { }
        public ContactManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve Contact information using ID
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Contact Get(long ID)
        {
            Contact contact = new Contact();
            using (ContactData data = new ContactData(UserContext))
            {
                contact = data.Get(ID);
                if (contact != null)
                {
                    ContactType type = GetContactTypeByID(contact.ContactTypeID);
                    if (type != null)
                    {
                        contact.ContactTypeName = type.Name;
                    }
                }
            }
            return contact;
        }


        /// <summary>
        /// Retrieve list of all Contacts
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public ContactList GetAll()
        {
            return GetAll(true);
        }

        public ContactList GetAll(bool fillType)
        {
            ContactList list = new ContactList();
            using (ContactData data = new ContactData(UserContext))
            {
                list = data.GetAll();
            }
            if (list != null && fillType)
            {
                foreach (Contact obj in list)
                {
                    ContactType type = GetContactTypeByID(obj.ContactTypeID);
                    if (type != null)
                    {
                        obj.ContactTypeName = type.Name;
                    }
                }
            }
            return list;
        }
        /// <summary>
        /// Retrieve list of all deleted Contacts
        /// last updated on:
        /// April 10, 2010
        /// change description:
        /// </summary>
        /// <returns></returns>
        public ContactList GetAllDeleted()
        {
            ContactList list = new ContactList();
            using (ContactData data = new ContactData(UserContext))
            {
                list = data.GetAllDeleted();
            }
            if (list != null)
            {

                foreach (Contact obj in list)
                {
                    ContactType type = GetContactTypeByID(obj.ContactTypeID);
                    if (type != null)
                    {
                        obj.ContactTypeName = type.Name;
                    }
                }

            }
            return list;
        }

        /// <summary>
        /// Retrieve alll contact views
        /// last updated on:
        /// March 11, 2010
        /// change description:
        /// </summary>
        /// <returns>ContactViewList</returns>
        public ContactViewList GetAllContactsView()
        {
            using (ContactData data = new ContactData(UserContext))
            {
                return data.GetAllContactsView();
            }
        }

        /// <summary>
        /// data manipulation routines for Contacts.
        /// allows update, insert, delete (logical).
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="contactObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(Contact contactObject, BaseRelationData relationData, long parentID)
        {
            bool success = false;

            PersonManager personManager = new PersonManager(Transaction, UserContext);
            if ((contactObject.Person != null) && (contactObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow))
            {
                success = personManager.Update(contactObject.Person);
                if (success)
                {
                    if (contactObject.PersonID != contactObject.Person.ID)
                    {
                        contactObject.PersonID = contactObject.Person.ID;
                        if (contactObject.RowState == BaseBusinessEntity.RowStateEnum.NormalRow)
                        {
                            // update existing
                            contactObject.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                        }
                    }
                }
            }
            else
            {
                success = true;
            }

            if (success)
            {
                ContactData data = new ContactData(Transaction, UserContext);
                switch (contactObject.RowState)
                {
                    // new contact data
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        long id = data.Insert(contactObject);
                        if (id > 0)
                        {
                            contactObject.ID = id;
                            if (relationData != null)
                                success = relationData.Add(parentID, id) > 0;
                        }
                        break;
                    // update existing contact
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        success = data.Update(contactObject) > 0;
                        break;
                    // delete existing contact
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        success = data.Delete(contactObject.ID) > 0;
                        if ((success) && (relationData != null))
                        {
                            success = relationData.Remove(parentID, contactObject.ID) > 0;
                        }
                        if (success)
                        {
                            contactObject.Person.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                            success = personManager.Update(contactObject.Person);
                        }
                        break;
                    case BaseBusinessEntity.RowStateEnum.NormalRow:
                        return true;
                }
            }

            return success;
        }
        /// <summary>
        /// contactObject update function
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="contactObject"></param>
        /// <returns></returns>
        public bool Update(Contact contactObject)
        {
            return Update(contactObject, null, -1);
        }
        /// <summary>
        /// Contact update with relation data
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="list"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(ContactList list, BaseRelationData relationData, long parentID)
        {
            if (list != null)
            {
                foreach (Contact contact in list)
                {
                    if (Update(contact, relationData, parentID) == false)
                        return false;
                }
            }

            return true;
        }
        /// <summary>
        /// Retrieve detail information of a Contact
        /// Detail information also includes Person data for a Contact
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public Contact Get(long ID, bool fillChild)
        {
            Contact contact = null;
            using (ContactData data = new ContactData(UserContext))
            {
                contact = Get(ID);
            }

            // get Person information for contact
            if (contact != null)
            {
                using (PersonManager personManager = new PersonManager(UserContext))
                {
                    contact.Person = personManager.Get(contact.PersonID, fillChild);
                }
            }

            return contact;
        }
        /// <summary>
        /// Retrieve Contacts for an Organization
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public ContactList GetContactsByOrganizationID(long organizationID)
        {
            using (ContactData data = new ContactData(UserContext))
            {
                return data.GetContactsByOrganizationID(organizationID);
            }
        }

        /// <summary>
        /// Retrieve ContactTypes
        /// 
        /// last updated on:
        /// September 09, 2009
        /// change description:
        /// 
        /// </summary>/// <returns></returns>
        public ContactTypeList GetAllContactTypes()
        {
            using (ContactTypeData data = new ContactTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        public ContactType GetContactTypeByID(long id)
        {
            using (ContactTypeData data = new ContactTypeData(UserContext))
            {
                return data.Get(id);
            }
        }

        public bool Update(ContactType ContactTypeObject)
        {
            if (ContactTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                ContactType tempContactType;
                using (ContactTypeData contactTypeData = new ContactTypeData(UserContext))
                {
                    tempContactType = contactTypeData.GetContactTypeByContactTypeName(ContactTypeObject.Name);
                }

                if (tempContactType != null && tempContactType.ID != ContactTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(ContactTypeObject, new Exception(errorInfo));
                }
            }
            ContactTypeData data = new ContactTypeData(UserContext);

            // use of switch for different types of DML
            switch (ContactTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to ContactTypeObject
                    long id = data.Insert(ContactTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        ContactTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(ContactTypeObject.ID) > 0);
            }
            // update rows
            return (data.Update(ContactTypeObject) > 0);
        }

        public ContactVersionList GetAllContactsForUser(long userID)
        {
            using (ContactData data = new ContactData(UserContext))
            {
                return data.GetAllContactsForUser(userID);
            }
        }

        public ContactList GetContactPaging(int startOffset, int numberOfItems, long orgID, string name, out int total)
        {
            using (ContactData data = new ContactData(UserContext))
            {
                return data.GetContactPaging(startOffset, numberOfItems, orgID, name, out total);
            }
        }
    }
}

