﻿
using System.Data.SqlClient;
using TSR.DataAccess;
using TSR.DataAccess.Bases;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class ProjectRateManager : BaseManager
    {
        public ProjectRateManager(UserContext context) : base(context)
        {
        }

        public ProjectRateManager(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
        }

        public ProjectRateList GetProjectRateList(long ID)
        {
            var projectRateList = new ProjectRateList();
            using (Project_RateData data = new Project_RateData(UserContext))
            {
               projectRateList = data.GetProjectRateByProjectID(ID);
            }
            return projectRateList;
        }
        //public bool Insert(ProjectRate projectRateObject)
        //{

        //    using (ProjectRateData data = new ProjectRateData(UserContext))
        //    {
        //        long id = data.Insert(projectRateObject);
        //        if (id > 0)
        //        {
        //            projectRateObject.ID = id;
        //            return true;
        //        }
        //        else
        //            return false;
        //    }
        //}
        //public bool Update(ProjectRate projectRateObject)
        //{

        //    using (ProjectRateData data = new ProjectRateData(UserContext))
        //    {
        //        return (data.Update(projectRateObject) > 0);
        //    }
        //}
        public bool AddOrUpdate(ProjectRate projectRateObject)
        {
            using (ProjectRateData data = new ProjectRateData(UserContext))
            {
                return (data.AddOrUpdate(projectRateObject) > 0);
            }
        }
        public bool Delete(long ID)
        {
            using (ProjectRateData data = new ProjectRateData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
    }
}
