using System;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;


namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Tasks.
    /// Tasks are set of actions which complete an activity.  
    /// In standard project management, activities are created as part of work breakdown structure (WBS) to decompose a project into smaller work components such as activities and tasks.
    /// 
    /// last updated on:
    /// august 31, 2009
    /// change description:
    /// </summary>
    public class TaskManager : BaseManager
    {
        public TaskManager(UserContext context) : base(context) { }
        public TaskManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve task data using unique ID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Task Get(long ID)
        {
            using (TaskData data = new TaskData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve list of All Tasks
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public TaskList GetAll()
        {
            using (TaskData data = new TaskData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// Insert: insert Task object
        /// check for successful action.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="taskObject"></param>
        /// <returns></returns>
        public bool Insert(Task taskObject)
        {
            using (TaskData data = new TaskData(UserContext))
            {
                // insert task object
                long id = data.Insert(taskObject);
                // if non-zero return, successful
                if (id > 0)
                {
                    taskObject.ID = id;
                    return true;
                }
                // if zero or negative return, not successful
                else
                    return false;
            }
        }
        /// <summary>
        /// Delete: deletion of Task data
        /// logical delete done using unique ID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool Delete(long ID)
        {
            using (TaskData data = new TaskData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Update: update of Task data
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="taskObject"></param>
        /// <returns></returns>
        public bool Update(Task taskObject)
        {
            using (TaskData data = new TaskData(UserContext))
            {
                return (data.Update(taskObject) > 0);
            }
        }
    }
}

