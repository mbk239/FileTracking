using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for TSR 'Roles'.  Various Permissions are grouped together to create a Role.
    /// Roles are then assigned to Users in TSR.  
    /// Based on Roles, a User has specific authorizations to use TSR.
    /// 
    /// Last updated on:
    /// August 31, 2009
    /// Change description:
    /// </summary>
    public class RoleManager : BaseManager
    {
        public RoleManager(UserContext context) : base(context) { }
        public RoleManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve Role based on ID
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Role Get(long ID)
        {
            using (RoleData data = new RoleData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve details information for a Role.
        /// Detail information include Permissions that are assigned to a Role.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="FillChilds"></param>
        /// <returns></returns>
        public Role Get(long ID, bool FillChilds)
        {
            Role role = new Role();
            using (RoleData data = new RoleData(UserContext))
            {
                role = data.Get(ID);
            }
            // get list of permissions for this role
            PermissionList permList = new PermissionList();
            using (PermissionManager permissionManager = new PermissionManager(UserContext))
            {
                if (!role.IsDeleted)
                    //role.PermissionList = permissionManager.GetPermissionsByRoleID(role.ID);
                    permList = permissionManager.GetPermissionsByRoleID(role.ID);
                else
                    //role.PermissionList = permissionManager.GetPermissionsByInactiveRoleID(role.ID);
                    permList = permissionManager.GetPermissionsByInactiveRoleID(role.ID);
            }
            //foreach (Permission perm in permList)
            //{
            //    if (perm.PermissionKey.Equals("SECURED_LICENSING_UPDATELICENSE_ASPX"))
            //    {
            //        permList.Remove(perm);
            //        break;
            //    }
                
            //}
            role.PermissionList = permList;
            return role;
        }
        /// <summary>
        /// Retrieve list of roles and sort 
        /// Returns sorted role list.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public RoleList GetAll()
        {
            using (RoleData data = new RoleData(UserContext))
            {
                RoleList roleList = data.GetAll();
                roleList.Sort();
                return roleList;
            }
        }

        //Feature 205 - Active and Inactive Role
        //Added by tsrdev2 - 26 Sep 2012
        /// <summary>
        /// Retrieves all Inactive Role objects 
        /// </summary>
        /// <returns>A list of Inactive Role objects</returns>
        public RoleList GetAllInactiveRole()
        {
            using (RoleData data = new RoleData(UserContext))
            {
                RoleList roleList = data.GetAllInactiveRole();
                roleList.Sort();
                return roleList;
            }
        }

        ////public RoleList GetRolesByUserGroupID(long userGroupID)
        ////{
        ////    using (RoleData data = new RoleData(UserContext))
        ////    {
        ////        return data.GetRolesByUserGroupID(userGroupID);
        ////    }
        ////}
        /// <summary>
        /// Retrieve list of Roles for a User
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <param name="userGroupID"></param>
        /// <returns></returns>
        public RoleList GetRolesByUserID(long userGroupID)
        {
            using (RoleData data = new RoleData(UserContext))
            {
                return data.GetRolesByUserID(userGroupID);
            }
        }

        //public RoleList GetAllRolesNotInUserGroup(long userGroupID)
        //{
        //    using (RoleData data = new RoleData(UserContext))
        //    {
        //        return data.GetAllRolesNotInUserGroup(userGroupID);
        //    }
        //}
        /// <summary>
        /// base class for updating Roles
        /// allows DML (insert, update, logical delete)
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="roleObject"></param>
        /// <returns></returns>
        public bool UpdateBase(Role roleObject)
        {
            if (roleObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Role tempRole;
                using (RoleData roleData = new RoleData(UserContext))
                {
                    tempRole = roleData.GetRoleByRoleName(roleObject.Name);
                }

                if (tempRole != null && tempRole.ID != roleObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(roleObject, new Exception(errorInfo));
                }
            }

            RoleData data = new RoleData(Transaction, UserContext);

            switch (roleObject.RowState)
            {
                // new row insert 
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(roleObject);
                    if (id > 0)
                    {
                        roleObject.ID = id;
                        return true;
                    }
                    break;
                // delete row
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(roleObject.ID) > 0;
                // update row
                case BaseBusinessEntity.RowStateEnum.ActiveRow:                
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(roleObject) > 0;
                    //normal row
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
                case BaseBusinessEntity.RowStateEnum.InActiveRow:
                    bool succ = false;
                    if (data.Update(roleObject) > 0)
                    {
                        succ = data.Delete(roleObject.ID) > 0;
                    }
                    return succ;
            }

            return false;
        }
        /// <summary>
        /// Update Role object and associated relational data
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="roleObject"></param>
        /// <returns></returns>
        public bool Update(Role roleObject)
        {
            bool success = false;

            success = UpdateBase(roleObject);

            if (success && roleObject.PermissionList != null && roleObject.PermissionList.Count > 0)
            {
                PermissionManager permissionManager = new PermissionManager(UserContext);

                Role_PermissionData role_PermissionData = new Role_PermissionData(Transaction, UserContext);
                role_PermissionData.DeleteAllPermissionsByRoleID(roleObject.ID);

                PermissionList uniqueList = new PermissionList();

                // process each Permission from the list of Permissions
                foreach (Permission pObj in roleObject.PermissionList)
                {
                    if (pObj.IsDeleted)
                        continue;

                    PermissionList subList = permissionManager.GetChildPermissions(pObj.PermissionKey);

                    // process each sub-permission for each permission
                    foreach (Permission pSubObj in subList)
                    {
                        if (uniqueList.FindByID(pSubObj.ID) == null)
                        {
                            uniqueList.Add(pSubObj);
                        }
                    }
                }

                foreach (Permission pObj in uniqueList)
                {
                    Role_Permission obj = new Role_Permission();
                    obj.RoleID = roleObject.ID;
                    obj.PermissionID = pObj.ID;

                    if (role_PermissionData.Insert(obj) <= 0)
                        return false;
                }

                //success = permissionManager.AssignPermission(roleObject.PermissionList, role_PermissionData, roleObject.ID);
            }

            return success;

        }

        public Role GetRoleByRoleName(string roleName)
        {
            using (RoleData data = new RoleData(UserContext))
            {
                return data.GetRoleByRoleName(roleName);
            }
        }
    }
}

