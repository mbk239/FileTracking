using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing user detail types.
    /// user detail types include different types such as: email, phone, Skype, etc. which are configurable.
    /// user detail types are used for Organizations, Contacts, Persons, etc.
    /// </summary>
    public class UserDetailManager : BaseManager
    {
        public UserDetailManager(UserContext context) : base(context) { }
        public UserDetailManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve user detail types using ID
        /// 
        /// Last updated on: 
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public UserDetailType GetType(long ID)
        {
            using (UserDetailTypeData data = new UserDetailTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }
        
        /// <summary>
        /// Get a list of user detail types
        /// </summary>
        /// <returns></returns>
        public UserDetailTypeList GetAllType()
        {
            using (UserDetailTypeData data = new UserDetailTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        public UserDetailTypeList GetAllTypeIsActive()
        {
            using (UserDetailTypeData data = new UserDetailTypeData(UserContext))
            {
                return data.GetAllIsActive();
            }
        }

        /// <summary>
        /// Update AddressType Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// </summary>
        /// <param name="UserDetailTypeObject"></param>
        /// <returns></returns>
        public bool UpdateType(UserDetailType UserDetailTypeObject)
        {
            if (UserDetailTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                UserDetailType tempUserDetailType;
                using (UserDetailTypeData UserDetailTypeData = new UserDetailTypeData(UserContext))
                {
                    tempUserDetailType = UserDetailTypeData.GetUserDetailTypeByUserDetailTypeName(UserDetailTypeObject.Name);
                }

                if (tempUserDetailType != null && tempUserDetailType.ID != UserDetailTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(UserDetailTypeObject, new Exception(errorInfo));
                }
            }

            UserDetailTypeData data = new UserDetailTypeData(UserContext);

            // use of switch for different types of DML
            switch (UserDetailTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to UserDetailTypeObject
                    long id = data.Insert(UserDetailTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        UserDetailTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(UserDetailTypeObject.ID) > 0);
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }
            // update rows
            return (data.Update(UserDetailTypeObject) > 0);
        }

        /// <summary>
        /// Retrieve user detail types using ID
        /// 
        /// Last updated on: 
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public UserDetail Get(long ID)
        {
            using (UserDetailData data = new UserDetailData(UserContext))
            {
                return data.Get(ID);
            }
        }

        /// <summary>
        /// Get a list of user detail s
        /// </summary>
        /// <returns></returns>
        public UserDetailList GetAll()
        {
            using (UserDetailData data = new UserDetailData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// Get a list of user details set on a person
        /// </summary>
        /// <returns></returns>
        public UserDetailList GetUserDetailsByPersonID(long personID)
        {
            using (UserDetailData data = new UserDetailData(UserContext))
            {
                return data.GetUserDetailsByPersonID(personID);
            }
        }
        /// <summary>
        /// Get a list of user details set on a person
        /// </summary>
        /// <returns></returns>
        public UserDetail GetUserDetailByPersonID_TypeID(long personID, long userDetailTypeID)
        {
            using (UserDetailData data = new UserDetailData(UserContext))
            {
                return data.GetUserDetailByPersonID_TypeID(personID, userDetailTypeID);
            }
        }

        /// <summary>
        /// Update Address Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// </summary>
        /// <param name="UserDetailObject"></param>
        /// <returns></returns>
        public bool Update(UserDetail UserDetailObject)
        {
            if (UserDetailObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                UserDetail tempUserDetail;
                using (UserDetailData UserDetailData = new UserDetailData(UserContext))
                {
                    tempUserDetail = UserDetailData.GetUserDetailByPersonID_TypeID(UserDetailObject.PersonID, UserDetailObject.UserDetailTypeID);
                }

                if (tempUserDetail != null && tempUserDetail.ID != UserDetailObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(UserDetailObject, new Exception(errorInfo));
                }
            }

            using (UserDetailData data = new UserDetailData(UserContext))
            {

                // use of switch for different s of DML
                switch (UserDetailObject.RowState)
                {
                    // insert / new rows
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        // insert to UserDetailObject
                        long id = data.Insert(UserDetailObject);
                        // if successful, process
                        if (id > 0)
                        {
                            UserDetailObject.ID = id;
                            return true;
                        }
                        else
                            return false;
                    // delete rows
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        return (data.Delete(UserDetailObject.ID) > 0);
                    case BaseBusinessEntity.RowStateEnum.NormalRow:
                        return true;
                }
                // update rows
                return (data.Update(UserDetailObject) > 0);
            }
        }
    }
}

