﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TSR.DataAccess;
using TSR.Entities;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class OUALogManager : BaseManager
    {
        public OUALogManager(UserContext context) : base(context)
        {
        }

        public OUALogManager(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
        }

        public bool Insert(LogOUALogin ouaLogObject)
        {
            // new activity
            using (OUALogData data = new OUALogData(UserContext))
            {
                // insert to activityObject
                data.Insert(ouaLogObject);                    
            }
            return true;
        }
    }
}
