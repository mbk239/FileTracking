﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.DataAccess;
using TSR.Entities.Lists;

namespace TSR.BusinessLogic
{
    public class LocationManager : BaseManager
    {
        //Constructor
        public LocationManager(UserContext context) : base(context) { }
        public LocationManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #region[Methods]
        /// <summary>
        /// Location object
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public Location GetLocationByID(long Id)
        {
            try
            {
                using (LocationData data = new LocationData(UserContext))
                {
                    return data.Get(Id);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Location GetLocationByName(string name)
        {
            try
            {
                using (LocationData data = new LocationData(UserContext))
                {
                    return data.GetByName(name);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Location list
        /// </summary>
        /// <returns>List of Location</returns>
        public LocationList GetAllLocation()
        {
            try
            {
                using (LocationData data = new LocationData(UserContext))
                {
                    return data.GetAll();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Insert Location object
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>
        public bool InsertLocation(Location location)
        {
            try
            {
                using (LocationData data = new LocationData(UserContext))
                {
                    long id =  data.Insert(location);

                    if (id > 0)
                    {
                        location.ID = id;
                        return true;
                    }
                    else
                        return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateLocation(Location location)
        {
            try
            {
                bool result = false;

                using (LocationData data = new LocationData(UserContext))
                {
                    switch (location.RowState)
                    { 
                        case BaseBusinessEntity.RowStateEnum.NewRow:
                            result = data.Insert(location) > 0;
                            break;
                        case BaseBusinessEntity.RowStateEnum.DeletedRow:
                            result = data.Delete(location.ID) > 0;
                            break;
                        case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                            result = data.Update(location) > 0;
                            break;
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteLocation(long Id)
        {
            try
            {
                using (LocationData data = new LocationData(UserContext))
                {
                    return data.Delete(Id) > 0;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public LocationList GetLocationBySearchTerm(string searchTerm, bool bShowInactivate)
        {
            using (LocationData data = new LocationData(UserContext))
            {
                return data.GetLocationBySearchTerm(searchTerm, bShowInactivate);
            }
        }

        public LocationList GetLocationPaging(int startOffset, int numberOfItems, string name, out int total)
        {
            using (LocationData data = new LocationData(UserContext))
            {
                return data.GetLocationPaging(startOffset, numberOfItems, name, out total);
            }
        }
        #endregion
    }
}
