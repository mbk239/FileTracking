using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing communication details.
    /// Communication details include different types such as: email, phone, Skype, etc. which are configurable.
    /// Communication details are used for Organizations, Contacts, Persons, etc.
    /// 
    /// last updated on:
    /// august 31, 2009
    /// change description:
    /// 
    /// </summary>
    public class CommDetailManager : BaseManager
    {
        public CommDetailManager(UserContext context) : base(context) { }
        public CommDetailManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve communication details using ID
        /// 
        /// Last updated on: 
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public CommDetail Get(long ID)
        {
            using (CommDetailData data = new CommDetailData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Type of communication detail.
        /// For example: Email, Phone, Skype, etc. are different types of communications details
        /// 
        /// Last updated on:
        /// august 31, 2009
        /// change description:  
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public CommDetailType GetCommDetailType(long ID)
        {
            using (CommDetailTypeData data = new CommDetailTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Get a list of communication details
        /// 
        /// Last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public CommDetailList GetAll()
        {
            using (CommDetailData data = new CommDetailData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Get a list of communication detail types
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public CommDetailTypeList GetAllCommDetailTypes()
        {
            using (CommDetailTypeData data = new CommDetailTypeData(UserContext))
            {
                return data.GetAll();
            }
        }


        /// <summary>
        /// Update AddressType Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="commDetailTypeObject"></param>
        /// <returns></returns>
        public bool Update(CommDetailType commDetailTypeObject)
        {
            if (commDetailTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                CommDetailType tempCommDetailType;
                using (CommDetailTypeData commDetailTypeData = new CommDetailTypeData(UserContext))
                {
                    tempCommDetailType = commDetailTypeData.GetCommDetailTypeByCommDetailTypeName(commDetailTypeObject.Name);
                }

                if (tempCommDetailType != null && tempCommDetailType.ID != commDetailTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(commDetailTypeObject, new Exception(errorInfo));
                }
            }

            CommDetailTypeData data = new CommDetailTypeData(UserContext);

            // use of switch for different types of DML
            switch (commDetailTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to commDetailTypeObject
                    long id = data.Insert(commDetailTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        commDetailTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(commDetailTypeObject.ID) > 0);
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }
            // update rows
            return (data.Update(commDetailTypeObject) > 0);
        }

        /// <summary>
        /// Update (data manipulation) for communication details.
        /// Allows insert, delete, updates, etc.
        /// </summary>
        /// <param name="commdetailObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(CommDetail commdetailObject, BaseRelationData relationData, long parentID)
        {
            CommDetailData data = new CommDetailData(Transaction, UserContext);
            switch (commdetailObject.RowState)
            {
                // insert new communication detail
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(commdetailObject);
                    if (id > 0)
                    {
                        commdetailObject.ID = id;
                        return relationData.Add(parentID, id) > 0;
                    }
                    break;
                // update existing communication detail
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(commdetailObject) > 0;
                // delete existing communication detail
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    if (data.Delete(commdetailObject.ID) > 0 && relationData != null)
                    {
                        return (relationData.Remove(parentID, commdetailObject.ID) > 0);
                    }
                    break;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }
        /// <summary>
        /// communication detail update - relational data.
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="list"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(CommDetailList list, BaseRelationData relationData, long parentID)
        {
            if (list != null)
            {
                // repeat update for each communication detail in the list
                foreach (CommDetail commDetail in list)
                {
                    if (Update(commDetail, relationData, parentID) == false)
                        return false;
                }
            }

            return true;
        }
        /// <summary>
        /// Retrieve communication details for a Person using personID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="personID"></param>
        /// <returns></returns>
        public CommDetailList GetCommDetailsByPersonID(long personID)
        {
            using (CommDetailData data = new CommDetailData(UserContext))
            {
                return data.GetCommDetailsByPersonID(personID);
            }
        }
        /// <summary>
        /// Retrieve communication details for an Address using addressID
        /// sample use in TSR web admin's Address set up page.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description
        /// </summary>
        /// <param name="addressID"></param>
        /// <returns></returns>
        public CommDetailList GetCommDetailsByAddressID(long addressID)
        {
            using (CommDetailData data = new CommDetailData(UserContext))
            {
                return data.GetCommDetailsByAddressID(addressID);
            }
        }
    }
}

