using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;


namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Permissions
    /// Permissions are the building blocks for TSR authorization.
    /// Permissions are grouped together to create a Role.
    /// Users are assigned one or more Roles - this dictates what are of the application users have access to and what operations they can perform.
    /// 
    /// Last updated on:
    /// August 31, 2009
    /// Change description:
    /// </summary>
    public class PermissionManager : BaseManager
    {
        public PermissionManager(UserContext context) : base(context) { }
        public PermissionManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// retrieve permission using ID
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// change Description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Permission Get(long ID)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Rtrieve list of all permissions.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public PermissionList GetAll()
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Data manipulation for Permissions: inserts
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="permissionObject"></param>
        /// <returns></returns>
        public bool Insert(Permission permissionObject)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                long id = data.Insert(permissionObject);
                if (id > 0)
                {
                    permissionObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }
        /// <summary>
        /// data manipulation for Permissions: logical delete
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool Delete(long ID)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Updates of Permissions - base
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="permissionObject"></param>
        /// <returns></returns>
        public bool UpdateBase(Permission permissionObject)
        {
            if (permissionObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Permission tempPermission;
                using (PermissionData permissionData = new PermissionData(UserContext))
                {
                    tempPermission = permissionData.GetPermissionByPermissionKey(permissionObject.PermissionKey);
                }

                if (tempPermission != null && tempPermission.ID != permissionObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(permissionObject, new Exception(errorInfo));
                }
            }

            PermissionData data = new PermissionData(Transaction, UserContext);
            switch (permissionObject.RowState)
            {
                // inserts
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(permissionObject);
                    if (id > 0)
                    {
                        permissionObject.ID = id;
                        return true;
                    }
                    break;
                // deletes (logical)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(permissionObject.ID) > 0;
                // update
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(permissionObject) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }
        /// <summary>
        /// Permission object updates
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <param name="permissionObject"></param>
        /// <returns></returns>
        public bool Update(Permission permissionObject)
        {
            return UpdateBase(permissionObject);
        }
        /// <summary>
        /// Get all permissions types
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public PermissionTypeList GetAllPermissionTypes()
        {
            using (PermissionTypeData data = new PermissionTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        internal PermissionList GetPermissionsByRoleID(long roleID)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetPermissionsByRoleID(roleID);
            }
        }

        //Feature 205 - Active and Inactive Role
        //Added by tsrdev2 - 26 Sep 2012
        /// <summary>
        /// Retrieve all Permissions for a Role.        
        /// </summary>
        /// <param name="roleID">Role ID</param>
        /// <returns>List of Permissions</returns>
        public PermissionList GetPermissionsByInactiveRoleID(long roleID)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetPermissionsByInactiveRoleID(roleID);
            }
        }

        /// <summary>
        /// Retrieve Permissions for a User using User ID
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public PermissionList GetPermissionsByUserID(long userID)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetPermissionsByUserID(userID);
            }
        }
        /// <summary>
        /// Retrieve child permissions for a Permission using permission key
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="permissionKey"></param>
        /// <returns></returns>
        public PermissionList GetChildPermissions(string permissionKey)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetChildPermissionsByPermissionKey(permissionKey);
            }
        }
        /// <summary>
        /// Deprecated method. remove candidate
        /// Permission assignment to a Permission list
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="permissionList"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignPermission(PermissionList permissionList, BaseRelationData relationData, long parentID)
        {
            foreach (Permission permission in permissionList)
            {
                if (!AssignPermission(permission, relationData, parentID))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Deprecated method. remove candidate
        /// </summary>
        /// <param name="permission"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignPermission(Permission permission, BaseRelationData relationData, long parentID)
        {
            switch (permission.RowState)
            {
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    if (relationData.Add(parentID, permission.ID) <= 0)
                        return false;
                    break;
                case BaseBusinessEntity.RowStateEnum.DeletedRow:

                    if (relationData.Remove(parentID, permission.ID) <= 0)
                        return false;
                    break;
            }
            return true;
        }

        public Permission GetPermissionByPermissionKey(string key)
        {
            using (PermissionData data = new PermissionData(UserContext))
            {
                return data.GetPermissionByPermissionKey(key);
            }
        }
    }
}

