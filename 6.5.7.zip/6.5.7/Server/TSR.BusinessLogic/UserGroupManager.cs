using System;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities.Bases;
using TSR.DataAccess;
using TSR.Entities;
using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework.Security;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for User Groups.
    /// User Group is a logical representation of grouped users.  Not related to security.  User Groups are primarily used in Workflow approval setup, etc.
    /// A User can belong to multiple User Groups such as: finance, accounting, HR, etc.
    /// 
    /// Last updated on:
    /// August 30, 2009
    /// Change description:
    /// </summary>
    public class UserGroupManager : BaseManager
    {        
        public UserGroupManager(UserContext context) : base(context) { }
        public UserGroupManager(SqlTransaction transaction, UserContext context) : base(transaction, context) 
        {           
        }
        /// <summary>
        /// Retrieve User Group using ID
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public UserGroup Get(long ID)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve details of a User Group.
        /// Details include Users that are attached to the User Group, etc.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public UserGroup Get(long ID, bool fillChild)
        {
            UserGroup userGroup;
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                userGroup = data.Get(ID);
            }

            if (fillChild)
            {
                FillUserGroupWithChilds(userGroup);
            }

            return userGroup;
        }

        /// <summary>
        /// 
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <param name="readOnly">readonly data when user group inactive</param>
        /// <returns></returns>
        public UserGroup Get(long ID, bool fillChild, bool isReadOnly)
        {
            UserGroup userGroup;
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                userGroup = data.Get(ID);
            }

            if (fillChild)
            {
                FillUserGroupWithChilds(userGroup, isReadOnly);
            }

            return userGroup;
        }

        private void FillUserGroupWithChilds(UserGroup userGroup)
        {
            if (userGroup != null)
            {
                using (UserManager userManager = new UserManager(UserContext))
                {
                    // get all direct users for this User Group
                    //userGroup.UserList = userManager.GetDirectUsersByUserGroupID(userGroup.ID);

                    userGroup.UserList = userManager.GetDirectUsersByUserGroupID(userGroup.ID, userGroup.IsActive);
                }

                //using (RoleManager roleManager = new RoleManager(UserContext))
                //{
                //    userGroup.RoleList = roleManager.GetRolesByUserGroupID(ID);
                //}

            }
        }

        private void FillUserGroupWithChilds(UserGroup userGroup, bool isReadOnly)
        {
            if (userGroup != null)
            {
                using (UserManager userManager = new UserManager(UserContext))
                {
                    // get all direct users for this User Group
                    if (isReadOnly)
                        userGroup.UserList = userManager.GetDirectUsersByUserGroupID(userGroup.ID, userGroup.IsActive);
                    else
                        userGroup.UserList = userManager.GetDirectUsersByUserGroupID(userGroup.ID);
                }

                //using (RoleManager roleManager = new RoleManager(UserContext))
                //{
                //    userGroup.RoleList = roleManager.GetRolesByUserGroupID(ID);
                //}

            }
        }
        /// <summary>
        /// Retrieves user group by user id, project id 
        /// 
        /// last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public UserGroup GetUserGroupByUserID_ProjectID(long userID, long projectID)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.GetUserGroupByUserID_ProjectID(userID, projectID);
            }
        }
        //added by tsrdev2
        /// <summary>
        /// Retrieves user group by user id, project id without flag deleted        
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public UserGroup GetUserGroupByUserID_ProjectID_NotFlagDeleted(long userID, long projectID)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.GetUserGroupByUserID_ProjectID_NotFlagDeleted(userID, projectID);
            }
        }

        //public UserGroup GetUserGroupByUserID_ProjectID_ForTimeEntryApproval(long userID, long projectID)
        //{
        //    using (UserGroupData data = new UserGroupData(UserContext))
        //    {
        //        return data.GetUserGroupByUserID_ProjectID_ForTimeEntryApproval(userID, projectID);
        //    }
        //}

        public UserGroup GetDefaultUserGroupByUserID_ProjectID(long userID, long projectID)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.GetDefaultUserGroupByUserID_ProjectID(userID, projectID);
            }
        }
             

        /// <summary>
        /// Retrieve list of User Groups
        /// 
        /// last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public UserGroupList GetAll()
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                UserGroupList list = data.GetAll();
                list.Sort();
                return list;
            }
        }

        public UserGroupList GetAll(bool fillChilds)
        {
            UserGroupList list = new UserGroupList();
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                list = data.GetAll();
                //list.Sort();
            }
            if (fillChilds)
            {
                foreach (UserGroup userGroup in list)
                {
                    FillUserGroupWithChilds(userGroup);
                }
            }
            return list;
        }

        /// <summary>
        /// Retrieve User Groups associated with a Project ID
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public UserGroupList GetUserGroupsIsActive(bool fillChilds)
        {
            UserGroupList list = new UserGroupList();
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                list = data.GetUserGroupsIsActive();
            }
            if (fillChilds)
            {
                foreach (UserGroup userGroup in list)
                {
                    FillUserGroupWithChilds(userGroup);
                }
            }
            return list;
        }

        public UserGroup GetUserGroupsByGroupName(string name, bool fillChilds)
        {
            UserGroup ug = new UserGroup();
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                ug = data.GetUserGroupByUserGroupName(name);
            }
            if (fillChilds)
            {
                FillUserGroupWithChilds(ug);
            }
            return ug;
        }

        /// <summary>
        /// Retrieve User Groups associated with a Project ID
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public UserGroupList GetUserGroupsByProjectID(long projectID, bool fillChilds)
        {
            UserGroupList list = new UserGroupList();
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                list = data.GetUserGroupsByProjectID(projectID);
            }
            if (fillChilds)
            {
                foreach (UserGroup userGroup in list)
                {
                    FillUserGroupWithChilds(userGroup);
                }
            }
            return list;
        }
        /// <summary>
        /// User Group update (base object)
        /// allows data manipulation: insert, update, delete (logical)
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="userGroupObject"></param>
        /// <returns></returns>
        public bool UpdateBase(UserGroup userGroupObject)
        {
            if (userGroupObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                UserGroup tempUserGroup;
                using (UserGroupData userGroupData = new UserGroupData(UserContext))
                {
                    tempUserGroup = userGroupData.GetUserGroupByUserGroupName(userGroupObject.Name);
                }

                if (tempUserGroup != null && tempUserGroup.ID != userGroupObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("UserGroupSameNameError", "The user group name has been used in another user group and cannot be used.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(userGroupObject, new Exception(errorInfo));
                }
            }
            using (UserGroupData data = new UserGroupData(Transaction, UserContext))
            {
                switch (userGroupObject.RowState)
                {
                    // insert new row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        long id = data.Insert(userGroupObject);
                        if (id > 0)
                        {
                            userGroupObject.ID = id;
                            return true;
                        }
                        break;
                    // delete existing row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        return data.Delete(userGroupObject.ID) > 0;
                    // default case: update
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        return data.Update(userGroupObject) > 0;
                    case BaseBusinessEntity.RowStateEnum.NormalRow:
                        return true;
                    case BaseBusinessEntity.RowStateEnum.ActiveRow:

                        return data.Update(userGroupObject) > 0;
                    case BaseBusinessEntity.RowStateEnum.InActiveRow:
                        return data.Update(userGroupObject) > 0;
                }
            }
            return false;
        }

        public long InActivate(long userGroupID)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.InActivate(userGroupID);
            }
            
        }
        
        /// <summary>
        /// Business logic processing for assigning Users to a User Group
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupObject"></param>
        /// <param name="userList"></param>
        /// <returns></returns>
        public bool AssignUser(UserGroup userGroupObject, UserList userList)
        {
            if (userList != null && userList.Count > 0)
            {
                using (UserGroup_UserData usrGrp_userData = new UserGroup_UserData(Transaction, UserContext))
                {
                    foreach (User user in userList)
                    {
                        switch (user.RowState)
                        {
                            case BaseBusinessEntity.RowStateEnum.NewRow:
                                if (usrGrp_userData.Add(userGroupObject.ID, user.ID) <= 0)
                                    return false;
                                break;
                            case BaseBusinessEntity.RowStateEnum.DeletedRow:
                                if (usrGrp_userData.Remove(userGroupObject.ID, user.ID) <= 0)
                                    return false;
                                break;
                        }
                    }
                }
            }
            return true;
        }
        /// <summary>
        /// Update User Group and associated data
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="userGroupObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        //public bool Update(UserGroup userGroupObject, BaseRelationData relationData, long parentID)
        //{
        //    UserGroupData data = new UserGroupData(Transaction, UserContext);
        //    switch (userGroupObject.RowState)
        //    {
        //        // new row insert
        //        case BaseBusinessEntity.RowStateEnum.NewRow:
        //            long id = data.Insert(userGroupObject);
        //            if (id > 0)
        //            {
        //                userGroupObject.ID = id;
        //                return relationData.Add(parentID, id) > 0;
        //            }
        //            break;
        //        // update existing row
        //        case BaseBusinessEntity.RowStateEnum.UpdatedRow:
        //            return data.Update(userGroupObject) > 0;
        //        // delete existing row (logical delete)
        //        case BaseBusinessEntity.RowStateEnum.DeletedRow:
        //            return data.Delete(userGroupObject.ID) > 0;
        //        case BaseBusinessEntity.RowStateEnum.NormalRow:
        //            return true;
        //    }

        //    return false;
        //}
        /// <summary>
        /// Update relation data for User Group
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="list"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        //public bool Update(UserGroupList list, BaseRelationData relationData, long parentID)
        //{
        //    if (list != null)
        //    {
        //        foreach (UserGroup userGroup in list)
        //        {
        //            if (Update(userGroup, relationData, parentID) == false)
        //                return false;
        //        }
        //    }

        //    return true;
        //}

        //add by tdthinh
        //public long GetTotalActivedUserGroups()
        //{
        //    UserGroupData userData = new UserGroupData(UserContext);
        //    return userData.GetAllIsActive().Count;
        //}

        //public long getAddibleNumberOfUsers()
        //{
        //    return getAddibleNumberOfUsers(0);
        //}

        ///// <summary>
        ///// Overloaded method to get total number of users that can be added. This method is extended in the sense
        ///// that it considers, how many users are going to be deleted at the same time
        ///// </summary>
        ///// <param name="NumberOfUsersToBeDeleted">number of users to be deleted</param>
        ///// <returns></returns>
        //public long getAddibleNumberOfUsers(long NumberOfUsersToBeDeleted)
        //{
        //    long totalExistingUsers = GetTotalActivedUserGroups() - NumberOfUsersToBeDeleted;
        //    ApplicationLicense apLicense = LicenseManager.GetLicense();
        //    long allowedNumberOfUsers = apLicense.NumberOfUsers;
        //    return allowedNumberOfUsers - totalExistingUsers;
        //}

        /// <summary>
        /// Update User Group object
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupObject"></param>
        /// <returns></returns>
        public bool Update(UserGroup userGroupObject)
        {
            bool success = false;
            success = UpdateBase(userGroupObject);
            if (success)
                success = AssignUser(userGroupObject, userGroupObject.UserList);
            return success;
        }

        public bool Update(UserGroupList userGroupList)
        {
            bool success = true;
            foreach (UserGroup userGroupObject in userGroupList)
            {
                using (UserGroupData data = new UserGroupData(Transaction, UserContext))
                {
                    switch (userGroupObject.RowState)
                    {
                        case BaseBusinessEntity.RowStateEnum.NewRow:
                            long id = data.Insert(userGroupObject);
                            if (id > 0)
                                userGroupObject.ID = id;
                            else
                                success = false;
                            break;
                        default:
                            success = true;
                            break;
                    }
                }
                if (success)
                    success = AssignUser(userGroupObject, userGroupObject.UserList);
            }
            return success;
        }

        /// <summary>
        /// Assign User Groups function
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupList"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignUserGroup(UserGroupList userGroupList, BaseRelationData relationData, long parentID)
        {
            foreach (UserGroup userGroup in userGroupList)
            {
                if (!AssignUserGroup(userGroup, relationData, parentID))
                    return false;
            }
            return true;
        }
        /// <summary>
        /// Assign User Groups function
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupList"></param>        
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignUserGroup(UserGroupList userGroupList, long parentID)
        {
            Project_UserGroupData relationData = new Project_UserGroupData(Transaction, UserContext);
            foreach (UserGroup userGroup in userGroupList)
            {
                if (!AssignUserGroup(userGroup, relationData, parentID))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Assign User Group function with other parameters
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <param name="userGroup"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignUserGroup(UserGroup userGroup, BaseRelationData relationData, long parentID)
        {
            switch (userGroup.RowState)
            {
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    if (relationData.Add(parentID, userGroup.ID) <= 0)
                        return false;
                    break;
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    if (relationData.Remove(parentID, userGroup.ID) <= 0)
                        return false;
                    break;
            }
            return true;
        }
        /// <summary>
        /// Assign User Group function with other parameters
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// change description:
        /// </summary>
        /// <param name="userGroup"></param>        
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignUserGroup(UserGroup userGroup, long parentID)
        {
            Project_UserGroupData relationData = new Project_UserGroupData(Transaction, UserContext);
            switch (userGroup.RowState)
            {
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    if (relationData.Add(parentID, userGroup.ID) <= 0)
                        return false;
                    break;
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    if (relationData.Remove(parentID, userGroup.ID) <= 0)
                        return false;
                    break;
            }
            return true;
        }

        //Added by tsrdev1    
        ///Created time: May 12th 2010
        /// <summary>
        /// Assign user group to approver group of project
        /// </summary>
        /// <param name="projectID"></param>
        /// <param name="approverGroup"></param>
        /// <param name="useManagers"></param>
        /// <returns></returns>
        public bool AssignApproverGroup(long projectID, UserGroup approverGroup, UserGroup approverGroupDB)
        {
            Project_ApproverGroupData relationData = new Project_ApproverGroupData(Transaction, UserContext);
            UserGroupData ugData = new UserGroupData(UserContext);
            //UserGroup approverGroupDB = ugData.GetApproverGroupByProjectID(projectID);
            if (approverGroupDB == null)
            {
                if (relationData.Add(projectID, approverGroup.ID) <= 0)
                    return false;
            }
            else if ((approverGroupDB != null) && (approverGroupDB.ID != approverGroup.ID))
            {
                if (relationData.Update(projectID, approverGroup.ID) <= 0)
                    return false;
            }            
            return true;
        }
        //Added by tsrdev1        
        /// <summary>
        /// Get approver group by project id
        /// but does not fill the child fields
        /// </summary>
        /// <param name="projectID"></param>        
        /// <returns>Approver Group</returns>
        public UserGroup GetApproverGroupByProjectID(long projectID)
        {
            UserGroupData ugData = new UserGroupData(Transaction, UserContext);
            return ugData.GetApproverGroupByProjectID(projectID);
        }

        //Added by tsrdev1    
        //Created date: 24/06/2010
        /// <summary>
        /// Get approver group by project id
        /// with filling the child fields
        /// </summary>
        /// <param name="projectID"></param>        
        /// <returns>Approver Group</returns>
        public UserGroup GetApproverGroupByProjectID(long projectID,bool fillChilds)
        {
            UserGroupData ugData = new UserGroupData(Transaction, UserContext);
            UserGroup ug = ugData.GetApproverGroupByProjectID(projectID);
            if (ug != null && fillChilds)
            {
                FillUserGroupWithChilds(ug);
            }
            return ug;
        }


        //Added by tsrdev1   
        //Created date: 24/06/2010
        /// <summary>
        /// Get user list for user group
        /// </summary>
        /// <param name="userGroup"></param>        
        /// <returns>User List</returns>
        public UserList GetUsersForUserGroup(UserGroup userGroup)
        {
            FillUserGroupWithChilds(userGroup);
            return userGroup.UserList;
        }
        
        /// <summary>
        /// Get list of user group that this user is a member
        /// </summary>
        /// <param name="userID"></param>        
        /// <returns>User Group List</returns>
        public UserGroupList GetUserGroupsByUserID(long userID)
        {
            return GetUserGroupsByUserID(userID, false);
        }

        public UserGroupList GetUserGroupsByUserID(long userID, bool fillChilds)
        {
            UserGroupList list = new UserGroupList();
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                list = data.GetUserGroupsByUserID(userID);
            }

            if (list != null && list.Count > 0 && fillChilds)
            {
                foreach (UserGroup ug in list)
                {
                    FillUserGroupWithChilds(ug);
                }
            }
            return list;
        }

        public UserGroupList GetUserGroupPaging(int startOffset, int numberOfItems, long projID, string name, out int total)
        {
            using (UserGroupData data = new UserGroupData(UserContext))
            {
                return data.GetUserGroupPaging(startOffset, numberOfItems, projID, name, out total);
            }
        }
    }
}

