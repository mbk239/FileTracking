using System;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;


namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Person object
    /// Person data model is the parent of all individuals that are associated with TSR in any way.
    /// For example: Each Contact is a Person, etc.
    /// 
    /// Last updated on:
    /// August 31, 2009
    /// Change description:
    /// </summary>
    public class PersonManager : BaseManager
    {
        public PersonManager(UserContext context) : base(context) { }
        public PersonManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Get Person data using ID
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Person Get(long ID)
        {
            using (PersonData data = new PersonData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Get Deleted Person data using ID
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Person GetDeleted(long ID)
        {
            using (PersonData data = new PersonData(UserContext))
            {
                return data.GetDeleted(ID);
            }
        }
        /// <summary>
        /// Retrieve list of all Persons.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change Description:
        /// </summary>
        /// <returns></returns>
        public PersonList GetAll()
        {
            using (PersonData data = new PersonData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Update Person base class
        /// Allows data manipulation operations such as: insert, delete, update, etc.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="personObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool UpdateBase(Person personObject, BaseRelationData relationData, long parentID)
        {
            using (PersonData data = new PersonData(Transaction, UserContext))
            {
                switch (personObject.RowState)
                {
                    // insert new row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        long id = data.Insert(personObject);
                        if (id > 0)
                        {
                            personObject.ID = id;
                            if (relationData == null)
                            {
                                return true;
                            }
                            else
                            {
                                return relationData.Add(parentID, id) > 0; ;
                            }
                        }
                        break;
                    // update existing row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        return data.Update(personObject) > 0;
                    // delete existing row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        return data.Delete(personObject.ID) > 0;
                    case BaseBusinessEntity.RowStateEnum.NormalRow:
                        return true;
                    case BaseBusinessEntity.RowStateEnum.UnDeletedRow:
                        return data.UnDeleted(personObject) > 0;
                }
            }

            return false;
        }
        /// <summary>
        /// Update person Object
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="personObject"></param>
        /// <returns></returns>
        public bool Update(Person personObject)
        {
            return Update(personObject, null, -1);
        }
        /// <summary>
        /// Update Person details.
        /// Details include Person's addresses, communication details, etc.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="personObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(Person personObject, BaseRelationData relationData, long parentID)
        {
            bool success = false;

            success = UpdateBase(personObject, relationData, parentID);

            if (personObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                if (personObject.UserDetailList != null)
                {
                    // process each address in Person's address list
                    foreach (UserDetail userdetail in personObject.UserDetailList)
                    {
                        userdetail.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                    }
                }
                //if (personObject.CommDetailList != null)
                //{
                //    // process each communication detail in Person's comm detail list
                //    foreach (CommDetail commDetail in personObject.CommDetailList)
                //    {
                //        commDetail.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                //    }
                //}
            }

            // handling of addresses for Person
            //if (success && personObject.AddressList != null && personObject.AddressList.Count > 0)
            //{
            //    AddressManager addressManager = new AddressManager(Transaction, UserContext);
            //    Person_AddressData per_addrsData = new Person_AddressData(Transaction, UserContext);
            //    success = addressManager.Update(personObject.AddressList, per_addrsData, personObject.ID);
            //}

            // handling of communication details for Person
            //if (success && personObject.CommDetailList != null && personObject.CommDetailList.Count > 0)
            //{
            //    CommDetailManager commDetailManager = new CommDetailManager(Transaction, UserContext);
            //    Person_CommDetailData per_commDetailData = new Person_CommDetailData(Transaction, UserContext);
            //    success = commDetailManager.Update(personObject.CommDetailList, per_commDetailData, personObject.ID);
            //}


            if (success && personObject.UserDetailList != null && personObject.UserDetailList.Count > 0)
            {
                using (UserDetailManager udManager = new UserDetailManager(Transaction, UserContext))
                {
                    foreach (UserDetail ud in personObject.UserDetailList)
                    {
                        ud.PersonID = personObject.ID;
                        success = udManager.Update(ud);

                        ud.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;
                    }
                }
            }

            return success;
        }
        /// <summary>
        /// Person delete code
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="withChild"></param>
        /// <returns></returns>
        public bool Delete(long ID, bool withChild)
        {
            using (PersonData data = new PersonData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Retrieve detail information for a Person
        /// Details include Person general data, address data, communication details data, etc.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public Person Get(long ID, bool fillChild)
        {
            Person person = null;
            using (PersonData data = new PersonData(UserContext))
            {
                // get person using ID
                person = data.Get(ID);
            }
            if (person != null)
            {
                // retrieve address information for Person
                //using (AddressManager addressManager = new AddressManager(UserContext))
                //{
                //    person.AddressList = addressManager.GetAddressesByPersonID(person.ID);
                //}

                // retrieve communication detail information for Person
                //using (CommDetailManager commDetailManager = new CommDetailManager(UserContext))
                //{
                //    person.CommDetailList = commDetailManager.GetCommDetailsByPersonID(person.ID);
                //}

                using (UserDetailManager userDetailManager = new UserDetailManager(UserContext))
                {
                    person.UserDetailList = userDetailManager.GetUserDetailsByPersonID(person.ID);
                }
            }
            return person;
        }
       

    }
}

