﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    public class ProjectActivityManager : BaseManager
    {
        public ProjectActivityManager(UserContext context) : base(context) { }
        public ProjectActivityManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public Project_ActivityList GetAllForUser(long userID)
        {
            using (Project_ActivityData data = new Project_ActivityData(Transaction, UserContext))
            {
                return data.GetAllForUser(userID);
            }
        }
    }
}
