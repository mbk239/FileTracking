using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Notes.
    /// TSR users and approvers can enter notes with their time entry.
    /// This code handles processing logic for notes (retrieval, updates, etc.)
    /// 
    /// last updated on:
    /// september 1, 2009
    /// change description:
    /// </summary>
    public class NoteManager : BaseManager
    {
        public NoteManager(UserContext context) : base(context) { }
        public NoteManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve Note data using unique ID
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Note Get(long ID)
        {
            using (NoteData data = new NoteData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve List of All Notes
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public NoteList GetAll()
        {
            using (NoteData data = new NoteData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Retrieve Notes for a particular Time Entry.
        /// Using unique timeEntryID, allows retrieval of all notes for a Time Entry.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public NoteList GetNotesByTimeEntryID(Guid timeEntryID)
        {
            using (NoteData data = new NoteData(UserContext))
            {
                return data.GetNotesByTimeEntryID(timeEntryID);
            }
        }

        /// added by tsrdev2
        /// <summary>
        /// Retrieve Notes for a particular Time Entry.
        /// Using unique timeEntryID, allows retrieval of all notes for a Time Entry.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public NoteList GetNotesByTimeEntryID(Guid timeEntryID, bool fillChild)
        {
            using (NoteData data = new NoteData(UserContext))
            {
                NoteList list = data.GetNotesByTimeEntryID(timeEntryID);
                if (fillChild)
                {
                    if (list != null && list.Count > 0)
                    {
                        foreach (Note obj in list)
                        {
                            if (obj.UserID != null && obj.UserID > -1)
                            {
                                using (UserManager userManager = new UserManager(UserContext))
                                {
                                    User user = userManager.GetUserByIDNotFlagByActiveAndDeleted(obj.UserID, true);
                                    if (user != null)
                                    {
                                        obj.User = user;
                                    }
                                }
                            }
                        }
                    }
                }
                return list;
            }
        }
        /// <summary>
        /// Update base noteObject.
        /// Data manipulation for: inserts, updates, and logical deletes.
        /// 
        /// last updated on:
        /// september 1st, 2009
        /// change description:
        /// </summary>
        /// <param name="noteObject"></param>
        /// <returns></returns>
        public bool UpdateBase(Note noteObject)
        {
            using (NoteData data = new NoteData(Transaction, UserContext))
            {
                switch (noteObject.RowState)
                {
                    // new notes row insert
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        noteObject.ID = data.Insert(noteObject);
                        return noteObject.ID > 0;
                    // update existing notes row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        return (data.Update(noteObject) > 0);
                    // delete existing notes row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        return data.Delete(noteObject.ID) > 0;
                }
            }

            return true;
        }
        /// <summary>
        /// Update noteObject for a Time Entry.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="noteObject"></param>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public bool Update(Note noteObject, Guid timeEntryID)
        {
            BaseBusinessEntity.RowStateEnum noteState = noteObject.RowState;

            if (UpdateBase(noteObject))
            {
                using (TimeEntry_NoteData data = new TimeEntry_NoteData(Transaction, UserContext))
                {
                    // during insertion of new notes row in Time Entry
                    if (noteState == BaseBusinessEntity.RowStateEnum.NewRow)
                        return data.Add(timeEntryID, noteObject.ID) > 0;
                    // during deletion of notes row in Time Entry
                    else if (noteState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                        return data.Remove(timeEntryID, noteObject.ID) > 0;

                    return true;
                }
            }

            return false;
        }
    }
}

