﻿using System;
using System.Data.SqlClient;
using TSR.DataAccess;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class RateManager : BaseManager
    {
        public RateManager(UserContext context) : base(context)
        {
        }

        public RateManager(SqlTransaction transaction, UserContext context) : base(transaction, context)
        {
        }

        public Rate Get(long Id)
        {
            Rate rateObj;
            using (RateData data = new RateData(UserContext))
            {
                rateObj = data.Get(Id);
            }
            return rateObj;
        }
        public RateList GetAll()
        {
            RateList rateList = new RateList();
            using (RateData data = new RateData(UserContext))
            {
                rateList = data.GetAllRate();
            }
            return rateList;
        }
        public RateReportUserList GetRateReport_BySearchCriteria(DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID,
            int? timeStatus,  int? outOfOfficeId, int UseCurrentRates)
        {
            using (RateData data = new RateData(UserContext))
            {
                return data.GetRateReport_BySearchCriteria(startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus, outOfOfficeId, UseCurrentRates);

            }
        }
        public bool Insert(Rate rateObject)
        {
            // new activity
            using (RateData data = new RateData(UserContext))
            {
                // insert to activityObject
                long id = data.Insert(rateObject);
                // if successful, process
                if (id > 0)
                {
                    rateObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }
        public bool Update(Rate rateObject)
        {

            using (RateData data = new RateData(UserContext))
            {
                return (data.Update(rateObject) > 0);
            }
        }
        public bool Delete(long ID)
        {
            using (RateData data = new RateData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
    }
}
