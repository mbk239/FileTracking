﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Entities;
using TSR.DataAccess;
using TSR.Framework;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for User_Language.
    /// Manage methods to insert, update or get User_Language
    /// </summary>
    public class User_LanguageManager : TSR.Framework.BaseManager
    {
        public User_LanguageManager(UserContext context) : base(context) { }
        public User_LanguageManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public bool Insert(User_Language user_Language)
        {
            using (User_LanguageData data = new User_LanguageData(UserContext))
            {
                return (data.Insert(user_Language) > 0);
            }
        }

        public bool Update(User_Language user_Language)
        {
            using (User_LanguageData data = new User_LanguageData(UserContext))
            {
                return (data.Update(user_Language) > 0);
            }
        }

        public User_Language GetByUserID(string userID)
        {
            using (User_LanguageData data = new User_LanguageData(UserContext))
            {
                return data.GetByUserID(userID);
            }
        }

        public User_Language GetByUsername(string username)
        {
            using (User_LanguageData data = new User_LanguageData(UserContext))
            {
                return data.GetByUsername(username);
            }
        }
    }
}
