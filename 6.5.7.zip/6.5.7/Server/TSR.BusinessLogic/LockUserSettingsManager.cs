﻿using System;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic  processing for LockUserSettings
    /// This class manager lock status of the user
    /// This class will be used by OUA order to specific the user is locked or not    
    /// </summary>
    public class LockUserSettingsManager : BaseManager
    {
        public LockUserSettingsManager(UserContext context) : base(context) { }
        public LockUserSettingsManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// Get LockUserSettings object based on ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public LockUserSettings Get(long id)
        {
            LockSettingsData data = new LockSettingsData(Transaction, UserContext);
            return data.Get(id);
        }
        /// <summary>
        /// Get LockUserSettings object based on UserID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public LockUserSettings GetByUserID(long userID)
        {
            LockSettingsData data = new LockSettingsData(Transaction, UserContext);
            return data.GetByUserID(userID);
        }        

        /// <summary>
        /// Insert/Update a LockUserSettings object
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool Update(LockUserSettings obj)
        {
            bool success = false;
            if (obj.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                LockUserSettings lockUserSettingsDB = GetByUserID(obj.UserID);
                if (lockUserSettingsDB != null)
                {
                    obj.ID = lockUserSettingsDB.ID;
                    obj.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                }
                else
                    obj.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
            }
            LockSettingsData data = new LockSettingsData(Transaction, UserContext);
            switch (obj.RowState)
            {
                // new contact data
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(obj);
                    if (id > 0)
                    {
                        obj.ID = id;
                        success = true;
                    }
                    break;
                // update existing contact
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    success = data.Update(obj) > 0;
                    break;
                // delete existing contact
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    success = data.Delete(obj.ID) > 0;                  
                    break;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return success;
        }     
    }
}
