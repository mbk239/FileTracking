using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Summary description for LanguageResourcesManager.
    /// This class contains all methods to working with language resources
    /// </summary>
    public class LanguageResourcesManager : BaseManager
    {
        public LanguageResourcesManager(UserContext context) : base(context) { }
        public LanguageResourcesManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// retrieves language resource depending on id of the resource
        /// </summary>
        /// <param name="ID">id of the language resource</param>
        /// <returns></returns>
        public LanguageResources Get(long ID)
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.Get(ID);
            }
        }

        /// <summary>
        /// retrieves all language resources
        /// </summary>
        /// <returns></returns>
        public LanguageResourcesList GetAll()
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// retrieves all language resource depending on language
        /// </summary>
        /// <param name="languageId">id of language</param>
        /// <returns>list of language resource on given language</returns>
        public LanguageResourcesList GetAllByLanguageId(String languageId)
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetAllByLanguageId(languageId);
            }
        }

        /// <summary>
        /// retrieves all language resource depending on language
        /// added by tsrdev2
        /// </summary>
        /// <param name="languageId">name of language</param>
        /// <returns>list of language resource on given language</returns>
        public LanguageResourcesList GetAllByLanguageName(String languageName)
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetAllByLanguageName(languageName);
            }
        }
        /// <summary>
        /// update method for language resource, one resource at a time
        /// </summary>
        /// <param name="LanguageResourcesObject">language resource to be updated</param>
        /// <returns>true or false depending on success/failure</returns>
        public bool Update(LanguageResources LanguageResourcesObject)
        {
            LanguageResourcesData data = new LanguageResourcesData(Transaction, UserContext);
            switch (LanguageResourcesObject.RowState)//depedning on rowstate, operation will be insert,update or delete
            {
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(LanguageResourcesObject);
                    if (id > 0)//if insertion is successful, update the object with automatically generated id in database
                    {
                        LanguageResourcesObject.ID = id;
                        return true;
                    }
                    break;
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(LanguageResourcesObject) > 0;
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(LanguageResourcesObject.ID) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow://normal row, means no instruction for any changes
                    return true;
            }

            return false;
        }

        /// <summary>
        /// bulk update method for language resources
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public bool Update(LanguageResourcesList list)
        {
            if (list != null)
            {
                foreach (LanguageResources LanguageResources in list)
                {
                    //call the update method for single language resource object
                    if (Update(LanguageResources) == false)
                        return false;
                }
            }

            return true;
        }

        /// <summary>
        /// retrieves available list of languages
        /// </summary>
        /// <returns></returns>
        public List<String> GetLanguages()
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetLanguages();
            }
        }

        /// <summary>
        /// retrieves available list of resources 
        /// added by tsrdev2
        /// </summary>
        /// <returns></returns>
        public LanguageResourcesList GetLanguageResources()
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetLanguageResources();
            }
        }

        public LanguageResourcesList GetByLanguageNameAndWhereResourceKeyIn(string languageName, string whereResourceKeyIn)
        {
            using (LanguageResourcesData data = new LanguageResourcesData(UserContext))
            {
                return data.GetByLanguageNameAndWhereIn(languageName, whereResourceKeyIn);
            }
        }
    }
}


