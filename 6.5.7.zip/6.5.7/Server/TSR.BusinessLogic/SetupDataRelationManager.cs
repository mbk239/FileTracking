﻿using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

namespace TSR.BusinessLogic
{
    public class SetupDataRelationManager : BaseManager
    {
        public SetupDataRelationManager(UserContext context) : base(context) { }
        public SetupDataRelationManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public OrganizationVersionList GetAllOrganizationVersionForUser(long userID)
        {
            OrganizationVersionList lstOV = new OrganizationVersionList();
            using (SetupDataRelationData data = new SetupDataRelationData(UserContext))
            {
                lstOV = data.GetAllOrganizationVersionForUser(userID);

                if (lstOV.Count > 0)
                {
                    Project_UserGroup_ActivitiesList lstPUA = new Project_UserGroup_ActivitiesList();
                    Project_UserGroupList lstPU = new Project_UserGroupList();
                    //OrganizationVersionList lstOVBeKept = new OrganizationVersionList();
                    List<long> lstProjectIDWillBeKept = new List<long>();
                    List<long> lstProjectIDWillBeHandled = new List<long>();

                    using (ProjectManager projectManager = new ProjectManager(UserContext))
                    {
                        lstPUA = projectManager.GetProject_UserGroup_Activities_ByUserID(-1, userID);
                        if (lstPUA.Count > 0)
                        {
                            //OrganizationVersionList lstOVBeRemovedTemp = new OrganizationVersionList();

                            lstPU = projectManager.GetProject_UserGroupByUserID_ProjectID(userID, -1);
                            if (lstPU.Count > 0)
                            {
                                foreach (Project_UserGroup pu in lstPU)
                                {
                                    IEnumerable<Project_UserGroup_Activities> rs = lstPUA.Where(pua => pua.ProjectID == pu.ProjectID && pua.UserGroupID == pu.UserGroupID);
                                    if (rs == null || rs.Count() == 0)
                                    {
                                        if (!lstProjectIDWillBeKept.Contains(pu.ProjectID))
                                            lstProjectIDWillBeKept.Add(pu.ProjectID);
                                    }
                                }

                                IEnumerable<Project_UserGroup> lstPUNeedHandle = lstPU.Where(pu => !lstProjectIDWillBeKept.Contains(pu.ProjectID));
                                foreach (Project_UserGroup pu in lstPUNeedHandle)
                                {
                                    if(!lstProjectIDWillBeHandled.Contains(pu.ProjectID))
                                        lstProjectIDWillBeHandled.Add(pu.ProjectID);
                                }

                                foreach (long proID in lstProjectIDWillBeHandled)
                                {
                                    IEnumerable<Project_UserGroup_Activities> rs = lstPUA.Where(pua => pua.ProjectID == proID);
                                    if (rs != null && rs.Count() > 0)
                                    {
                                        lstOV.RemoveAll(ov => ov.ProjID == proID && rs.FirstOrDefault(pua => pua.ActivityID == ov.ActID) == null);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return lstOV;
        }
    }
}
