﻿using System;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.DataAccess;
using TSR.Entities.Bases;
using System.Data.SqlClient;
using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework.Security;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for User_UserSettings component.
    /// Manage UserSetting of user
    /// </summary>
    public class UsersSettingManager : BaseManager
    {
        /// <summary>
        /// Initializes a new instance of the UsersSettingManager class.
        /// </summary>
        /// <param name="context">The context.</param>
        public UsersSettingManager(UserContext context) : base(context) { }

        /// <summary>
        /// Initializes a new instance of the UsersSettingManager> class.
        /// </summary>
        /// <param name="transaction">The transaction.</param>
        /// <param name="context">The context.</param>
        public UsersSettingManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// Gets all user setting.
        /// </summary>
        /// <returns></returns>
        public User_UserSettingsList GetAllUserSetting()
        {
            using (UserSettingsData data = new UserSettingsData(UserContext))
            {
                return data.GetAllSeting();
            }
        }

        /// <summary>
        /// Gets User_UserSettings specified unique identifier.
        /// </summary>
        /// <param name="ID">The unique identifier.</param>
        /// <returns></returns>
        public User_UserSettings Get(long ID)
        {
            using (UserSettingsData data = new UserSettingsData(UserContext))
            {
                return data.Get(ID);
            }
        }

        /// <summary>
        /// Gets the specified unique identifier.
        /// </summary>
        /// <param name="ID">The unique identifier.</param>
        /// <param name="fillChild">if set to <c>true</c> [fill child].</param>
        /// <returns></returns>
        public User_UserSettings Get(long ID, bool fillChild)
        {
            User_UserSettings user = Get(ID);

            if ((user != null) && (fillChild))
            {
                // get Person information for this user
                using (PersonManager personManager = new PersonManager(UserContext))
                {
                    user.Person = personManager.Get(user.CreatorID, true);
                }
                // Get role information for this user.
                using (RoleManager roleManager = new RoleManager(UserContext))
                {
                    user.RoleList = roleManager.GetRolesByUserID(user.ID);
                }
            }

            return user;
        }
    }
}
