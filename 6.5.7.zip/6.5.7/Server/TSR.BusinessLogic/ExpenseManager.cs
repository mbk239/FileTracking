using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using TSR.Entities.Lists;

namespace TSR.BusinessLogic
{
    public class ExpenseManager : BaseManager
    {
        public ExpenseManager(UserContext context) : base(context) { }
        public ExpenseManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #region Expenses Sheet
        public ExpenseSheet GetExpenseSheetByID(long ID)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                return data.Get(ID);
            }
        }

        public ExpenseSheetList GetAllExpenseSheets()
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                return data.GetAll();
            }
        }

        public ExpenseSheet GetExpenseSheetByTimeEntryID(Guid timeEntryID, bool fillEntries)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                ExpenseSheet es = data.GetExpenseSheetByTimeEntryID(timeEntryID);
                if (es != null && fillEntries)
                {
                    es.ExpensesEntryList = GetExpenseEntryByExpenseSheetID(es.ID);
                }
                return es;
            }
        }

        public ExpenseSheetList GetExpenseSheetsByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp, string calendarID)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                ExpenseSheetList resultLst = new ExpenseSheetList();
                ExpenseSheetList lst = data.GetExpenseSheetsByUserID_TimeSpan(userID, startTimeStamp, endTimeStamp, calendarID);
                if (lst != null && lst.Count > 0)
                {
                    foreach (ExpenseSheet es in lst)
                    {
                        es.ExpensesEntryList = GetExpenseEntryByExpenseSheetID(es.ID);
                        if (es.ExpensesEntryList != null && es.ExpensesEntryList.Count > 0)
                        {
                            foreach (ExpenseEntry exp in es.ExpensesEntryList)
                            {
                                exp.TimeEntryID = es.TimeEntryID;
                            }
                        }
                        es.IsDeletedOnServer = es.IsDeleted;

                        if (es.IsDeleted)
                        {
                            if(lst.Any(x => x.TimeEntryID == es.TimeEntryID && x.IsDeleted == false))
                                continue;
                        }

                        resultLst.Add(es);
                    }
                }
                return resultLst;
            }
        }
        
        public bool InsertExpenseSheet(ExpenseSheet timesheetObject)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                // insert new timesheet object
                long id = data.Insert(timesheetObject);
                // check for success (non-zero return code)
                if (id > 0)
                {
                    timesheetObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }
        
        public bool DeleteExpenseSheet(long ID)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }

        public bool UpdateExpenseSheet(ExpenseSheet timesheetObject)
        {
            return UpdateExpenseSheet(timesheetObject, false);
        }

        public bool UpdateExpenseSheet(ExpenseSheet sheetObject, bool includeExpenseEntry)
        {
            bool result = false;
            sheetObject.Revision = sheetObject.Revision.HasValue ? (sheetObject.Revision + 1) : 1;
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                switch (sheetObject.RowState)
                {
                    // new expense entry row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        result = data.Insert(sheetObject) > 0;
                        break;
                    // delete existing expense entry row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        result = data.Delete(sheetObject.ID) > 0;
                        break;
                    // update existing expense entry row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        result = data.Update(sheetObject) > 0;
                        break;
                }
            }
            if (includeExpenseEntry && sheetObject.ExpensesEntryList != null)
            {
                ExpenseSheet sheet = GetExpenseSheetByTimeEntryID(sheetObject.TimeEntryID, true);
                if (sheet != null)
                {
                    foreach (ExpenseEntry exp in sheetObject.ExpensesEntryList)
                    {
                        if (sheetObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                            exp.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                        exp.ExpenseSheetID = sheet.ID;

                        result = UpdateExpenseEntry(exp);
                        if (!result)
                            break;
                    }
                }
            }

            return result;
        }               

        #endregion

        #region Expense Entry
        public ExpenseEntry GetExpenseEntryByID(long ID)
        {
            using (ExpenseEntryData data = new ExpenseEntryData(UserContext))
            {
                return data.Get(ID);
            }
        }

        public ExpenseEntryList GetExpenseEntryByExpenseSheetID(long expenseSheetID)
        {
            using (ExpenseEntryData data = new ExpenseEntryData(UserContext))
            {
                return data.GetExpenseEntryByExpenseSheetID(expenseSheetID);
            }
        }
        
        public ExpenseEntry GetDeletedExpenseEntry(long ID)
        {
            using (ExpenseEntryData data = new ExpenseEntryData(UserContext))
            {
                return data.GetDeletedExpenseEntry(ID);
            }
        }
        
        public ExpenseEntryList GetAllExpenseEntries()
        {
            using (ExpenseEntryData data = new ExpenseEntryData(UserContext))
            {
                return data.GetAll();
            }
        }

        public bool UpdateExpenseEntry(ExpenseEntry expenseEntryObject)
        {
            bool result = false;

            expenseEntryObject.Revision = expenseEntryObject.Revision.HasValue ? (expenseEntryObject.Revision + 1) : 1;
            using (ExpenseEntryData data = new ExpenseEntryData(UserContext))
            {
                switch (expenseEntryObject.RowState)
                {
                    // new expense entry row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        result = data.Insert(expenseEntryObject) > 0;
                        break;
                    // delete existing expense entry row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        result = data.Delete(expenseEntryObject.ID) > 0;
                        break;
                    // update existing expense entry row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        result = data.Update(expenseEntryObject) > 0;
                        break;
                }
            }
            return result;
        }
        #endregion

        #region Expense Type
        public ExpenseType GetExpenseTypeByID(long ID)
        {
            using (ExpenseTypeData data = new ExpenseTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }

        public ExpenseTypeList GetAllExpenseTypes()
        {
            using (ExpenseTypeData data = new ExpenseTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        public ExpenseTypeList GetExpenseTypeBySearchTerm(string searchTerm, bool bShowInactive)
        {
            using (ExpenseTypeData data = new ExpenseTypeData(UserContext))
            {
                return data.GetExpenseTypeBySearchTerm(searchTerm, bShowInactive);
            }
        }

        public bool UpdateExpenseType(ExpenseType expenseTypeObject)
        {
            bool result = false;
            using (ExpenseTypeData data = new ExpenseTypeData(UserContext))
            {
                switch (expenseTypeObject.RowState)
                {
                    // new expense type row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        result = data.Insert(expenseTypeObject) > 0;
                        break;
                    // delete existing expense type row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        result = data.Delete(expenseTypeObject.ID) > 0;
                        break;
                    // update existing expense type row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        result = data.Update(expenseTypeObject) > 0;
                        break;
                }
            }

            return result;
        }
        #endregion

        #region Approval
        public ExpenseApprovalSummaryList GetApprovalExpenseSummaryList(DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID)
        {
            ExpenseApprovalSummaryList lstApprovalSum = new ExpenseApprovalSummaryList();
            ExpenseApprovalSummaryList result = new ExpenseApprovalSummaryList();
            using (ExpenseEntryData expenseEntryData = new ExpenseEntryData(UserContext))
            {
                lstApprovalSum = expenseEntryData.GetApprovalExpenseSummaryList(startTimeStamp, endTimeStamp.AddDays(1), organizationID, projectID, activityID, userGroupID, null);
            }
            if (lstApprovalSum.Count > 0)
            {
                using (UserManager manager = new UserManager(UserContext))
                {
                    foreach (ExpenseApprovalSummary appsum in lstApprovalSum)
                    {
                        User usr = manager.Get(appsum.UserID, true);
                        if (usr != null)
                        {
                            appsum.User = usr;
                            result.Add(appsum);
                        }
                    }
                }
            }
            return result;
        }

        public bool ApprovalRejectExpensesForUserList(ExpenseApprovalSummary approvalSummaryList, WFAction wFAction)
        {
            bool result = true;
            using (ExpenseSheetData data = new ExpenseSheetData(Transaction, UserContext))
            {
                result = data.ApproveRejectExpenseSheets(approvalSummaryList, wFAction) > 0;
            }
            return result;
        }
        #endregion

        #region Expense Entries Reports
        public ExpenseReportUserList GetAllExpenseByDate(DateTime startDate, DateTime endDate)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                return data.GetAllExpenseByDate(startDate, endDate);
            }
        }

        public ExpenseReportUserList GetExpensesReport_BySearchCriteria(DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID,
                int? timeStatus, bool isPersonalReport, int? outOfOfficeId)
        {
            using (ExpenseSheetData data = new ExpenseSheetData(UserContext))
            {
                return data.GetExpensesReport_BySearchCriteria(startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus, isPersonalReport, outOfOfficeId);
            }
        }
        #endregion        
    }
}

