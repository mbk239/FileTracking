﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.DataAccess;
using TSR.Entities.Bases;
using System.Data.SqlClient;
using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework.Security;
namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for UserDefaultSetting.
    /// UserDefaultSetting is default values of UserSetting of user
    /// UserDefaultSetting will be assigned to user on OUA
    /// </summary>
    public class UserDefaultSettingManager : BaseManager
    {
        public UserDefaultSettingManager(UserContext context) : base(context) { }
        public UserDefaultSettingManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        public bool Update(UserDefaultSettingList userListObject, long? UserID, byte check)
        {
            bool success = false;

            foreach (UserDefaultSetting userObject in userListObject)
            {
                success = UpdateBase(userObject, UserID, check);
            }
            return success;
        }
        public bool Update(UserDefaultSettingList userListObject, long? UserID)
        {
            bool success = false;

            foreach (UserDefaultSetting userObject in userListObject)
            {
                success = UpdateBase(userObject, UserID);
            }
            return success;
        }
        public bool UpdateBase(UserDefaultSetting userObject, long? UserID, byte success)
        {
            bool _success = true;
            UserDefaultSettingsData data = new UserDefaultSettingsData(Transaction, UserContext);
            if (success == 0)
                userObject.ID = data.Insert(userObject, UserID);
            if (success == 1)
                userObject.ID = data.Update(userObject, UserID);
            return _success;
        }
        public bool UpdateBase(UserDefaultSetting userObject, long? UserID)
        {
            UserDefaultSettingsData userSettingData = new UserDefaultSettingsData(Transaction, UserContext);

            // use of switch statement for types of data manipulation
            switch (userObject.RowState)
            {
                // new row insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = userSettingData.Insert(userObject, UserID);
                    if (id > 0)
                    {
                        userObject.ID = id;
                        return true;
                    }
                    break;
                // delete existing row
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return true;
                // update existing row
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return (userSettingData.Update(userObject, UserID) > 0);
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }
            return false;
        }
        public UserDefaultSetting Get(long ID)
        {
            using (UserDefaultSettingsData data = new UserDefaultSettingsData(UserContext))
            {
                return data.Get(ID);
            }
        }
        public UserDefaultSettingList GetAllUserDefaultSeting(long? UserID)
        {
            using (UserDefaultSettingsData data = new UserDefaultSettingsData(UserContext))
            {
                return data.GetAllDefaultSetting(UserID);
            }
        }
        public UserDefaultSetting Get(long ID, bool fillChild)
        {
            UserDefaultSetting user = Get(ID);

            //if ((user != null) && (fillChild))
            //{
            //    if (user.CreatorID.HasValue)
            //    {
            //        // get Person information for this user
            //        using (PersonManager personManager = new PersonManager(UserContext))
            //        {
            //            user.UserID = personManager.Get(user.UserID.Value, true);
            //        }
            //    }
            //    // Get role information for this user.
            //    using (RoleManager roleManager = new RoleManager(UserContext))
            //    {
            //        user.RoleList = roleManager.GetRolesByUserID(user.ID);
            //    }
            //}

            return user;
        }

        public UserDefaultSetting GetUserDefaultSettingBySettingName(string settingName)
        {
            using (UserDefaultSettingsData data = new UserDefaultSettingsData(UserContext))
            {
                return data.GetUserDefaultSettingBySettingName(settingName);
            }
        }
    }
}
