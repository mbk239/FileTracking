﻿using System;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// class CalenderUserManager
    /// Extends BaseManager
    /// It handles logics necessary to maintain calenders that are used to track work hours of the employees
    /// and hece managing notification
    /// </summary>
    public class CalenderUserManager : BaseManager
    {
        public CalenderUserManager(UserContext context) : base(context) { }
        public CalenderUserManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// method GetAll
        /// gets all the calenders form the database
        /// this is a wrapper method for CalenderForUserData.GetAll method 
        /// </summary>
        /// <returns></returns>
        public CalenderForUserList GetAll()
        {
            using (CalenderForUserData data = new CalenderForUserData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// method UpdateBase
        /// handles update or insert of calender
        /// </summary>
        /// <param name="calenderObject"></param>
        /// <returns></returns>
        public bool UpdateBase(CalenderForUser calenderObject)
        {
            if (calenderObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                CalenderForUser tempCalenderForUser;
                using (CalenderForUserData calenderForUserData = new CalenderForUserData(UserContext))
                {
                    tempCalenderForUser = calenderForUserData.GetCalenderByCalenderName(calenderObject.CalenderName);
                }

                if (tempCalenderForUser != null && tempCalenderForUser.ID != calenderObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(calenderObject, new Exception(errorInfo));
                }
            }

            CalenderForUserData calenderData = new CalenderForUserData(Transaction, UserContext);

            // use of switch statement for types of data manipulation
            switch (calenderObject.RowState)
            {
                // new row insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = calenderData.Insert(calenderObject);
                    if (id > 0)
                    {
                        calenderObject.ID = id;
                        return true;
                    }
                    break;
                // update row
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    {
                        long ret = calenderData.UpdateCalender(calenderObject);
                        if (ret > 0)
                        {
                            return true;
                        }
                    }
                    break;

                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    {
                        long ret = calenderData.DeleteCalender(calenderObject);
                    }
                    break;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
                ////delete existing row
                //case BaseBusinessEntity.RowStateEnum.DeletedRow:
                //    return calenderData.Delete(calenderObject.ID) > 0;
                //// update existing row
                //case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                //    return (calenderData.Update(calenderObject) > 0);
            }
            return false;
        }

        /// <summary>
        /// method UpdateCalenderException
        /// handles update or insert of any exception added to the calender for a single object
        /// </summary>
        /// <param name="calExObj"></param>
        /// <returns></returns>
        public bool UpdateCalenderException(CalenderExceptions calExObj)
        {
            bool success = false;

            CalenderForUserData calenderData = new CalenderForUserData(Transaction, UserContext);

            if (calExObj.ID < 0) // this is  a new exception added to the calender
            {
                long id = calenderData.InsertCalenderException(calExObj);
                if (id > 0)
                {
                    return true;
                }
            }
            else // this is only an updated exception
            {
                long id = calenderData.UpdateCalenderException(calExObj);
                if (id > 0)
                {
                    return true;
                }
            }

            return success;
        }

        /// <summary>
        /// method UpdateCalenderException
        /// handles update or insert of any exception added to the calender for a list of object
        /// </summary>
        /// <param name="calExObj"></param>
        /// <returns></returns>
        public bool UpdateCalenderException(CalenderExceptionList calList)
        {
            bool success = false;

            CalenderForUserData calenderData = new CalenderForUserData(Transaction, UserContext);

            foreach (CalenderExceptions calExObj in calList)
            {

                if (calExObj.RowState == BaseBusinessEntity.RowStateEnum.NewRow) // this is a new exception
                {
                    long id = calenderData.InsertCalenderException(calExObj);
                    if (id > 0)
                    {
                        success = true;
                    }
                    else
                    {
                        success = false;
                    }
                }
                else if (calExObj.RowState == BaseBusinessEntity.RowStateEnum.UpdatedRow) // this is only an update to some existing exception
                {
                    long id = calenderData.UpdateCalenderException(calExObj);
                    if (id > 0)
                    {
                        success = true;
                    }
                    else
                    {
                        success = false;
                    }
                }
                else if (calExObj.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow) // this is a deleted row
                {
                    long id = calenderData.DeleteCalenderException(calExObj);
                    if (id > 0)
                    {
                        success = true;
                    }
                    else
                    {
                        success = false;
                    }
                }
                else if (calExObj.RowState == BaseBusinessEntity.RowStateEnum.NormalRow)
                {
                    success = true;
                }
            }

            return success;
        }

        /// <summary>
        /// method Update
        /// handles any change to the calender object
        /// </summary>
        /// <param name="calenderObject"></param>
        /// <returns></returns>
        public bool Update(CalenderForUser calenderObject, CalenderExceptionList lstCalException)
        {
            bool success = false;

            success = UpdateBase(calenderObject);
            if (lstCalException.Count > 0)
            {
                bool temp = UpdateCalenderException(lstCalException);
                if (success && temp)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }

            return success;
        }

        /// <summary>
        /// method GetCalenderExceptionByID
        /// returns a list of calender exception for the calender pointed by the calender ID 
        /// </summary>
        /// <param name="ID">calender ID</param>
        /// <returns></returns>
        public CalenderExceptionList GetCalenderExceptionByID(long ID)
        {
            using (CalenderForUserData data = new CalenderForUserData(Transaction, UserContext))
            {
                return data.GetCalenderExceptions(ID);
            }
        }

        /// <summary>
        /// method GetCalenderByID
        /// gets a calender provided it's ID
        /// </summary>
        /// <param name="ID">ID of the calender</param>
        /// <param name="FillChild"></param>
        /// <returns></returns>
        public CalenderForUser GetCalenderByID(long ID, bool FillChild)
        {
            CalenderForUser calender;
            using (CalenderForUserData data = new CalenderForUserData(UserContext))
            {
                calender = data.Get(ID);
            }

            return calender;
        }

        public CalenderForUser GetCalenderByCalenderName(string calName)
        {
            CalenderForUser calender = null;
            using (CalenderForUserData data = new CalenderForUserData(UserContext))
            {
                calender = data.GetCalenderByCalenderName(calName);
            }
            return calender;
        }
    }
}
