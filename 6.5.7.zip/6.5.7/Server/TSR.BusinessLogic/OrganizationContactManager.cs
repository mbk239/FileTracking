﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    public class OrganizationContactManager : BaseManager
    {
        public OrganizationContactManager(UserContext context) : base(context) { }
        public OrganizationContactManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public Organization_ContactList GetAllForUser(long userID)
        {
            Organization_ContactList orgList = new Organization_ContactList();
            using (Organization_ContactData data = new Organization_ContactData(Transaction, UserContext))
            {
                return data.GetAllForUser(userID);
            }
        }
    }
}
