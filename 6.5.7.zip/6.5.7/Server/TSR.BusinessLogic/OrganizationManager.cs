using System;
using System.Collections.Generic;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for TSR Organization.
    /// Logic for:
    /// 1. Retrieving list of Organizations
    /// 2. Retrieving details of an Organization
    /// 3. Data manipulation (CRUD) for Organization: base and details
    /// 
    /// Last updated on:
    /// Change description:
    /// </summary>
    public class OrganizationManager : BaseManager
    {
        public OrganizationManager(UserContext context) : base(context) { }
        public OrganizationManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve detail information for an Organization.
        /// Detail information: Organization, Contacts, Addresses, Communication Details for the Organization. 
        /// 
        /// Last updated on:
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="FillChilds"></param>
        /// <returns></returns>
        public Organization Get(long ID, bool FillChilds)
        {
            Organization organization;
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                organization = data.Get(ID);
            }
           //get SourceIP and AppycationID
            GetSourceIDAndApplicationID(organization);

            if (FillChilds && (organization != null))
            {
                // Retrieve list of Contacts for the Organization.
                using (ContactManager contactManager = new ContactManager(UserContext))
                {
                    organization.ContactList = contactManager.GetContactsByOrganizationID(ID);

                    for (int index = 0; index < organization.ContactList.Count; index++)
                    {
                        organization.ContactList[index] = contactManager.Get(organization.ContactList[index].ID, true);
                    }
                }

                // Retrieve Addresses for the Organization.
                using (AddressManager addressManager = new AddressManager(UserContext))
                {
                    organization.AddressList = addressManager.GetAddressesByOrganizationID(ID);
                }

                //// Retrieve Communication Details for the Organization.
                //using (CommDetailManager commDetailManager = new CommDetailManager(UserContext))
                //{
                //    organization.CommDetailList = commDetailManager.GetCommDetailsByOrganizationID(ID);
                //}
            }

            return organization;
        }
        
        /// <summary>
        /// Get SourceID And ApplicationID
        /// </summary>
        /// <param name="organization"></param>
        private void GetSourceIDAndApplicationID(Organization organization)
        {
            if (organization == null)
            {
                return;
            }
            using (DBRMappingTableData dbrData = new DBRMappingTableData(UserContext))
            {
                DBRMappingTable dbrObj = dbrData.GetByDestinationIDEntityTypeID(organization.ID.ToString(), (int)DBREntityTypeEnum.ENTITY_TYPE_ORGANIZATION);
                if (dbrObj != null)
                {
                    organization.SourceID = dbrObj.SourceID;
                    organization.ApplicationID = dbrObj.ApplicationID;
                }
            }
        }


        public Organization GetDeleted(long ID, bool FillChilds)
        {
            Organization organization;
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                organization = data.GetDeleted(ID);
            }
            //get SourceIP and AppycationID
            GetSourceIDAndApplicationID(organization);

            if (FillChilds && (organization != null))
            {
                // Retrieve list of Contacts for the Organization.
                using (ContactManager contactManager = new ContactManager(UserContext))
                {
                    organization.ContactList = contactManager.GetContactsByOrganizationID(ID);

                    for (int index = 0; index < organization.ContactList.Count; index++)
                    {
                        organization.ContactList[index] = contactManager.Get(organization.ContactList[index].ID, true);
                    }
                }

                // Retrieve Addresses for the Organization.
                using (AddressManager addressManager = new AddressManager(UserContext))
                {
                    organization.AddressList = addressManager.GetAddressesByOrganizationID(ID);
                }

                //// Retrieve Communication Details for the Organization.
                //using (CommDetailManager commDetailManager = new CommDetailManager(UserContext))
                //{
                //    organization.CommDetailList = commDetailManager.GetCommDetailsByOrganizationID(ID);
                //}
            }

            return organization;
        }


        /// <summary>
        /// Retrieve Organization Types.
        /// Different organization types are allowed, for example: postal, primary, secondary, etc.
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public OrganizationType GetOrganizationType(long ID)
        {
            using (OrganizationTypeData data = new OrganizationTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }

        /// <summary>
        /// Retrieves all organization types
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public OrganizationTypeList GetAllOrganizationTypes()
        {
            using (OrganizationTypeData data = new OrganizationTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// Retrieve list of Organizations.
        /// Used for Organization search in TSR web application.
        /// Last updated on:
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public OrganizationList GetAll()
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetAll();
                foreach (Organization org in orgList)
                {
                    //get SourceIP and AppycationID
                    GetSourceIDAndApplicationID(org);
                }
            }
            return orgList;
        }

        /// <summary>
        /// Get all orgnization for user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public OrganizationList GetAllOrganizationForUser(long userId)
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetAllOrganizationForUser(userId);
            }
            return orgList;
        }
        public OrganizationList GetAllForReport()
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetAll();                
            }
            return orgList;
        }

        /// <summary>
        /// Retrieve list of Deleted Organizations.        
        /// </summary>
        /// <returns></returns>
        public OrganizationList GetAllDeleted()
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetAllDeleted();
                foreach (Organization org in orgList)
                {
                    //get SourceIP and AppycationID
                    GetSourceIDAndApplicationID(org);
                }
            }
            return orgList;
        }
        //added by tsrdev2
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public OrganizationList GetOrganizationsForUser(long userID)
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetOrganizationsForUser(userID);
            }
            foreach (Organization org in orgList)
            {
                //get SourceIP and AppycationID
                GetSourceIDAndApplicationID(org);
            }
            return orgList;
        }
        

        /// <summary>
        /// Retrieve list of Organizations View.
        /// Used for Organization view search in TSR web application.        
        /// </summary>
        /// <returns></returns>
        public OrganizationViewList GetAllOrganizationsView()
        {
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                return data.GetAllOrganizationsView();
            }
        }
        /// <summary>
        /// Organization DML (insert, delete, update) for base object.
        /// Performs data manipulation logic for Organization (base object) inserts, updates, and deletes.
        /// Last updated on:
        /// Change Description:
        /// </summary>
        /// <param name="organizationObject"></param>
        /// <returns></returns>
        private bool UpdateBase(Organization organizationObject)
        {
            if (organizationObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Organization tempOrganization;
                using (OrganizationData organizationData = new OrganizationData(UserContext))
                {
                    tempOrganization = organizationData.GetOrganizationByOrganizationName(organizationObject.Name);
                }

                if (tempOrganization != null && tempOrganization.ID != organizationObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(organizationObject, new Exception(errorInfo));
                }
            }
            OrganizationData orgData = new OrganizationData(Transaction, UserContext);

            switch (organizationObject.RowState)
            {   // Organization insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = orgData.Insert(organizationObject);
                    if (id > 0)
                    {
                        organizationObject.ID = id;
                        return true;
                    }
                    break;
                // Organization delete (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return orgData.Delete(organizationObject.ID) > 0;
                // Organization update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return orgData.Update(organizationObject) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }

        /// <summary>
        /// added by tsrdev2
        /// Organization DML (insert, delete, update) for base object.
        /// Performs data manipulation logic for Organization (base object) inserts, updates, and deletes.
        /// Last updated on:
        /// Change Description:
        /// </summary>
        /// <param name="organizationObject"></param>
        /// <returns></returns>
        public string UpdateBaseForImport(Organization organizationObject)
        {
            string errorMessage = string.Empty;
            if (organizationObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Organization tempOrganization;
                using (OrganizationData organizationData = new OrganizationData(UserContext))
                {
                    tempOrganization = organizationData.GetOrganizationByOrganizationName(organizationObject.Name);
                }

                if (tempOrganization != null && tempOrganization.ID != organizationObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    return errorInfo;
                    //return ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE;
                }
            }
            OrganizationData orgData = new OrganizationData(Transaction, UserContext);

            switch (organizationObject.RowState)
            {   // Organization insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = orgData.Insert(organizationObject);
                    if (id > 0)
                    {
                        organizationObject.ID = id;
                        return string.Empty;
                    }
                    else
                        return "No record is inserted";                    
                
                // Organization update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return orgData.UpdateForImport(organizationObject);
                     
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return string.Empty;
            }
            return "Operation is unsuccessful";
        }
        /// <summary>
        /// Organization details updates.
        /// Updates addresses, communication details, contacts for an Organization.
        /// Last updated on:
        /// Change description:
        /// </summary>
        /// <param name="organizationObject"></param>
        /// <returns></returns>
        public bool Update(Organization organizationObject)
        {
            bool success = false;

            success = UpdateBase(organizationObject);
            // Address updates
            if (success && organizationObject.AddressList != null && organizationObject.AddressList.Count > 0)
            {
                if (organizationObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                {
                    foreach (Address address in organizationObject.AddressList)
                    {
                        address.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                    }
                }
                AddressManager addressManager = new AddressManager(Transaction, UserContext);
                Organization_AddressData org_addrsData = new Organization_AddressData(Transaction, UserContext);
                success = addressManager.Update(organizationObject.AddressList, org_addrsData, organizationObject.ID);
            }            
            // Contacts updates
            if (success && organizationObject.ContactList != null && organizationObject.ContactList.Count > 0)
            {
                if (organizationObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                {
                    foreach (Contact  ct in organizationObject.ContactList)
                    {
                        ct.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                    }
                }
                ContactManager contactManager = new ContactManager(Transaction, UserContext);
                Organization_ContactData org_ContactData = new Organization_ContactData(Transaction, UserContext);
                success = contactManager.Update(organizationObject.ContactList, org_ContactData, organizationObject.ID);
            }
            return success;
        }
        /// <summary>
        /// Organization details updates.
        /// Updates addresses, communication details, contacts for an Organization.
        /// Last updated on:
        /// Change description:
        /// </summary>
        /// <param name="organizationObject"></param>
        /// <returns></returns>
        public bool Update(OrganizationType organizationTypeObject)
        {
            if (organizationTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                OrganizationType tempOrganizationType;
                using (OrganizationTypeData organizationTypeData = new OrganizationTypeData(UserContext))
                {
                    tempOrganizationType = organizationTypeData.GetOrganizationTypeByOrganizationTypeName(organizationTypeObject.Name);
                }

                if (tempOrganizationType != null && tempOrganizationType.ID != organizationTypeObject.ID)
                {
                    // handling of unique constraint violation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(organizationTypeObject, new Exception(errorInfo));
                }
            }

            OrganizationTypeData data = new OrganizationTypeData(UserContext);

            // use of switch for different types of DML
            switch (organizationTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to projectTypeObject
                    long id = data.Insert(organizationTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        organizationTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(organizationTypeObject.ID) > 0);
            }
            // update rows
            return (data.Update(organizationTypeObject) > 0);
        }

        public string UpdateForDBRImport(Organization organizationObject)
        {
            bool success = false;
            string error = string.Empty;
            error = UpdateBaseForImport(organizationObject);
            if (string.IsNullOrEmpty(error))
            {
                success = true;
            }
            // Address updates
            if (success && organizationObject.AddressList != null && organizationObject.AddressList.Count > 0)
            {
                AddressManager addressManager = new AddressManager(Transaction, UserContext);
                Organization_AddressData org_addrsData = new Organization_AddressData(Transaction, UserContext);
                success = addressManager.Update(organizationObject.AddressList, org_addrsData, organizationObject.ID);
                if (!success)
                {
                    error = "Can not import address";
                }
            }            
            return error;
        }

        public OrganizationList GetOrganizationPaging(int startOffset, int numberOfItems, string name, out int total)
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetOrganizationPaging(startOffset, numberOfItems, name, out total);
            }
            return orgList;
        }

        public OrganizationList GetOrganizationsForUserPaging(long userID, int startOffset, int numberOfItems, string name, out int total)
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetOrganizationsForUserPaging(userID, startOffset, numberOfItems, name, out total);
            }
            return orgList;
        }

        public OrganizationList GetAllOrganizationsForExport()
        {
            OrganizationList orgList = new OrganizationList();
            using (OrganizationData data = new OrganizationData(UserContext))
            {
                orgList = data.GetAllOrganizationsForExport();
            }
            return orgList;
        }

        public Organization GetOrganizationByOrganizationName(string name)
        {
            using (OrganizationData organizationData = new OrganizationData(UserContext))
            {
                return organizationData.GetOrganizationByOrganizationName(name);
            }
        }
    }
}

