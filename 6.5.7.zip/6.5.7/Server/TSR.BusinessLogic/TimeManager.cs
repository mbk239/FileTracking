using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using TSR.Entities.Lists;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Time Entry.
    /// Logic for Time Entry summary, retrieval, time entry details, time sheet, reports and data manipulation for time entries.
    /// 
    /// last updated on:
    /// september 1, 2009
    /// change description:
    /// 
    /// </summary>
    public class TimeManager : BaseManager
    {
        public TimeManager(UserContext context) : base(context) { }
        public TimeManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        // start of code region for Time Sheet (grouped Time Entries to a single Time Sheet)
        // One or more Time Entry transactions make up a Timesheet which is basically a grouping of Time Entries submitted by a End-User.  
        // This approach makes it easy to manage TSR transactions and allows reporting flexibilities and allows batch approval, etc. - as well as various performance improvements are achieved in this way.
        #region Time Sheet
        /// <summary>
        /// Retrieve TimeSheet by unique ID
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public TimeSheet GetTimeSheetByID(long ID)
        {
            using (TimeSheetData data = new TimeSheetData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve list of All TimeSheets 
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public TimeSheetList GetAllTimeSheets()
        {
            using (TimeSheetData data = new TimeSheetData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// New TimeSheet insertion logic.
        /// check for successful new entry.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timesheetObject"></param>
        /// <returns></returns>
        public bool InsertTimeSheet(TimeSheet timesheetObject)
        {
            using (TimeSheetData data = new TimeSheetData(UserContext))
            {
                // insert new timesheet object
                long id = data.Insert(timesheetObject);
                // check for success (non-zero return code)
                if (id > 0)
                {
                    timesheetObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }
        /// <summary>
        /// Delete TimeSheet data.
        /// check for success on deletion.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DeleteTimeSheet(long ID)
        {
            using (TimeSheetData data = new TimeSheetData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Update timesheet Object
        /// check for successful update.
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timesheetObject"></param>
        /// <returns></returns>
        public bool UpdateTimeSheet(TimeSheet timesheetObject)
        {
            using (TimeSheetData data = new TimeSheetData(UserContext))
            {
                return (data.Update(timesheetObject) > 0);
            }
        }               

        #endregion
        // end of Time Sheet region

        // start of code region Time Entry
        #region Time Entry
        /// <summary>
        /// Retrieve Time Entry using unique ID
        /// Each Outlook Appointment/Calendar item is a Time Entry in TSR.  
        /// For example: a Time-Entry User may report/submit time for a 1 hour activity for a certain Organization/Project on a day.  
        /// This data is stored in TSR backend DB servers TimeEntry table (which is the detail table for Timesheet).
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public TimeEntry GetTimeEntry(Guid ID)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.Get(ID);
            }
        }
        //added by tsrdev2
        /// <summary>
        /// Retrieve Deleted Time Entry using unique ID
        /// Each Outlook Appointment/Calendar item is a Time Entry in TSR.  
        /// For example: a Time-Entry User may report/submit time for a 1 hour activity for a certain Organization/Project on a day.  
        /// This data is stored in TSR backend DB servers TimeEntry table (which is the detail table for Timesheet).
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public TimeEntry GetDeletedTimeEntry(Guid ID)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetDeletedTimeEntry(ID);
            }
        }

        //Added by tsrdev1
        //Added date time 03/11/2010
        /// <summary>
        /// Get time entry by outlook appointment id and start time stamp
        /// </summary>
        /// <param name="outlookAppointmentID"></param>
        /// <param name="startTime"></param>
        /// <returns></returns>
        public TimeEntry GetTimeEntryByOutlookAppointmentIDAndStartTime(string outlookAppointmentID, DateTime startTime)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetTimeEntryByOutlookAppointmentIDAndStartTime(outlookAppointmentID,startTime);
            }
        }

        /// <summary>
        /// Retrieve list of all Time Entries
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public TimeEntryList GetAllTimeEntries()
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetAll();
            }
        }

        public TimeEntryList GetTimeEntriesByOrganizationID(long orgID)
        {
            TimeEntryList teOrgList = new TimeEntryList();
            TimeEntryList teList = GetAllTimeEntries();
            foreach (TimeEntry te in teList)
            {
                if (te.OrganizationID == orgID)
                {
                    teOrgList.Add(te);
                }
            }
            return teOrgList;            
        }

        public TimeEntryList GetTimeEntriesByProjectID(long projectID)
        {
            TimeEntryList teProjectList = new TimeEntryList();
            TimeEntryList teList = GetAllTimeEntries();
            foreach (TimeEntry te in teList)
            {
                if (te.ProjectID == projectID)
                {
                    teProjectList.Add(te);
                }
            }
            return teProjectList;            
        }

        public TimeEntryList GetTimeEntriesByActivityID(long actID)
        {
            TimeEntryList teActList = new TimeEntryList();
            TimeEntryList teList = GetAllTimeEntries();
            foreach (TimeEntry te in teList)
            {
                if (te.ActivityID == actID)
                {
                    teActList.Add(te);
                }
            }
            return teActList;
        }

        public TimeEntryList GetTimeEntriesByContactID(long cntID)
        {
            TimeEntryList teActList = new TimeEntryList();
            TimeEntryList teList = GetAllTimeEntries();
            foreach (TimeEntry te in teList)
            {
                if (te.ContactID == cntID)
                {
                    teActList.Add(te);
                }
            }
            return teActList;
        }
        /// <summary>
        /// Retrieve Time Entries for a TimeSheet using timesheetID
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timeSheetID"></param>
        /// <returns></returns>
        public TimeEntryList GetTimeEntriesByTimeSheetID(long timeSheetID)
        {
            throw new Exception("Not Implemented");
        }
        /// <summary>
        /// Retrieve time entries for a User for a timespan.
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <returns></returns>
        public TimeEntryList GetTimeEntriesByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                // get time entry for the user and start & end time span
                return data.GetTimeEntriesByUserID_TimeSpan(userID, startTimeStamp, endTimeStamp);
            }
        }
        //Added by tsrdev1
        //Added datetime 02/12/2010
        /// <summary>
        /// Retrieve time entries and links for a User for a timespan.
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="calendarID"></param>
        /// <returns></returns>
        public Dictionary<TimeEntry,TimeEntry_OutlookAppointment> GetTimeEntriesByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp,string calendarID)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                // get time entry for the user and start & end time span
                return data.GetTimeEntriesByUserID_TimeSpan(userID, startTimeStamp, endTimeStamp,calendarID);
            }
        }
        //Added by tsrdev1
        //Added datetime 02/12/2010

        //added by tsrdev2
        /// <summary>
        /// Retrieve deleted time entries for a User for a timespan.
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <returns></returns>
        public TimeEntryList GetDeletedTimeEntriesByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                // get time entry for the user and start & end time span
                return data.GetDeletedTimeEntriesByUserID_TimeSpan(userID, startTimeStamp, endTimeStamp);
            }
        }

        //tsr dev4 13/09/2010
        public TimeEntryList GetApprovedOrRejectedTimeEntriesByUserID_TimeSpan(long userID, DateTime startTimeStamp, DateTime endTimeStamp)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                // get time entry for the user and start & end time span
                return data.GetApprovedOrRejectedTimeEntriesByUserID_TimeSpan(userID, startTimeStamp, endTimeStamp);
            }
        }

        /// <summary>
        /// Retrieve time entries based on User, Org, Proj, Act, Grp, Subject, Status
        /// </summary>
        /// added by tsrdev2        
        /// <param name="userID"></param>
        /// <param name="OrganizationId"></param>
        /// <param name="ProjectID"></param>
        /// <param name="ActivityID"></param>
        /// <param name="UserGroupID"></param>
        /// <param name="subject"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        //public TimeEntryList GetTimeEntriesBySearchCriteria(Int64 userID, DateTime startDate, DateTime endDate, Int64 organizationId, Int64 projectID, Int64 activityID, Int64 userGroupID, string subject, int status)
        //{
        //    using (TimeEntryData data = new TimeEntryData(UserContext))
        //    {
        //        endDate = (endDate < DateTime.MaxValue.AddDays(-1) ? endDate.AddDays(1) : DateTime.MaxValue);
        //        return data.GetTimeEntriesBySearchCriteria(userID, startDate, endDate, organizationId, projectID, activityID, userGroupID, subject, status);
        //    }
        //}
        public TimeEntryList GetTimeEntriesBySearchCriteria(Int64 userID, DateTime startDate, DateTime endDate, Int64 organizationId, Int64 projectID, Int64 activityID, Int64 userGroupID, string subject, int status,
        int? isValid, int? isActive)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                endDate = (endDate < DateTime.MaxValue.AddDays(-1) ? endDate.AddDays(1) : DateTime.MaxValue);
                return data.GetTimeEntriesBySearchCriteria(userID, startDate, endDate, organizationId, projectID, activityID, userGroupID, subject, status, isValid, isActive);
            }
        }


        public TimeEntryList GetTimeEntriesBySearchCriteria_ForExport(Int64 userID, DateTime startDate, DateTime endDate, Int64 organizationId, Int64 projectID, Int64 activityID, Int64 userGroupID, string subject, int status, int outOfOffice, int UseCurrentRates, bool isProfit=false)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                endDate = (endDate < DateTime.MaxValue.AddDays(-1) ? endDate.AddDays(1) : DateTime.MaxValue);
                if (userID > 0) userGroupID = -1;
                return data.GetTimeEntriesBySearchCriteria_ForExport(userID, startDate, endDate, organizationId, projectID, activityID, userGroupID, subject, status, outOfOffice, UseCurrentRates, isProfit);
            }
        }

        //Add 20151121
        public TimeEntryList GetTimeEntriesInIntervalDays(long userID, long organizationID, long projectID, long activityID, DateTime startDate, int intervalDays)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetTimeEntriesInIntervalDays(userID, organizationID, projectID, activityID, startDate, intervalDays);
            }
        }

        public long SubmitUnsubmittedTimeEntriesInIntervalDays(long userID, long organizationID, long projectID, long activityID, DateTime startDate, int intervalDays)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.SubmitUnsubmittedTimeEntriesInIntervalDays(userID, organizationID, projectID, activityID, startDate, intervalDays);
            }
        }
        //End

        //Add 20160202
        /// <summary>
        /// Submit timeEntry of userId on startDate
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="checkedMatrixViewListData"></param>
        /// <param name="formatDate">format date</param> 
        /// <param name="isLocked">System Lock Period Flag</param> 
        /// <param name="bWarningOut">if exist locked timeentry -> set equal true </param> 
        /// <returns></returns>
        public long SubmitTimeEntriesInADay(long userId, ArrayList checkedMatrixViewListData, TimeEntryList selectedTimeEntryList, string formatDate, bool isLocked, ref bool bWarningOut)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.SubmitTimeEntriesInADay(userId, checkedMatrixViewListData, selectedTimeEntryList, formatDate, isLocked, ref bWarningOut);
            }
        }
        //End add 20160202

        //End add 20160202

        /// <summary>
        /// Add 20160216: Get all time entries by userGroupId from startDate to endDate for locking or unlocking
        /// </summary>
        /// <param name="userGroupId">User group id</param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public LockAndUnlockPeriodItemList GetTimeEntriesByGroupUserAndInterval(long userGroupId, DateTime startDate, DateTime endDate)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetTimeEntriesByGroupUserAndInterval(userGroupId, startDate, endDate);
            }
        }

        //Add 20160218
        /// <summary>
        /// Lock or unlock Users's Time Entries from startDate to endDate
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="isLockTimeEntry">true: Lock all time entries of userId in this period; false: unlock all time entries of userId in this period</param>
        /// <returns></returns>
        public long LockUnlockUserTimeEntriesInterval(long userId, DateTime startDate, DateTime endDate, bool isLockTimeEntry)
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.LockUnlockUserTimeEntriesInterval(userId, startDate, endDate, isLockTimeEntry);
            }
        }

        /// <summary>
        /// Add 20160223
        /// Retrieve time entries (list) for a timesheet summary
        /// Add more lock status column and filter by "Show only locked" and "Show zero hours"
        /// </summary>
        /// <param name="userID">User Id</param>
        /// <param name="startTimeStamp">timespan start time</param>
        /// <param name="endTimeStamp">timespan end time</param>
        /// <param name="organizationID">Organization ID</param>
        /// <param name="projectID">Project ID</param>
        /// <param name="activityID">Activity ID</param>
        /// <param name="userGroupID">User Group ID</param>
        /// <para name="showOnlyLocked">only show timeEntry locked</para>
        /// <returns></returns>
        public TimeSheetSummary GetTimeEntriesForTimeSheetSummaryListWithLockPeriod(long userID, DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, bool showOnlyLocked)
        { 
            TimeEntryList timeEntries;
            TimeSheetSummary timeSheetSummary = new TimeSheetSummary();
            // create time entry list for the specified parameters
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                endTimeStamp = (endTimeStamp < DateTime.MaxValue ? endTimeStamp.AddDays(1) : DateTime.MaxValue);
                timeEntries = timeEntryData.GetTimeEntriesForTimeSheetSummaryListWithLockPeriod(userID, startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, showOnlyLocked);
            }
            // if not null, create summary
            if (timeEntries != null && timeEntries.Count > 0)
            {
                timeSheetSummary = CreateTimesheetSummary(timeEntries, userID);
            }
            return timeSheetSummary;
        }

        //added by tsrdev2
        /// <summary>
        /// Is valid time entry
        /// </summary>
        /// <param name="te"></param>
        /// <returns></returns>
        public long GetTimeEntryType(TimeEntry te)
        {
            Int64 contactID = te.ContactID.HasValue ? te.ContactID.Value : -1;
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                // get time entry for the user and start & end time span
                return data.GetTimeEntryType(te.UserID,te.OrganizationID,te.ProjectID,te.ActivityID, contactID);
            }
        }

        /// <summary>
        /// Update TimeEntry Object.
        /// data manipulation: inserts, updates, deletes.
        /// also includes updates to notes for Time Entry
        /// 
        /// last updated on:
        /// september 1st, 2009
        /// change description:
        /// </summary>
        /// <param name="timeentryObject"></param>
        /// <returns></returns>
        public bool UpdateTimeEntry(TimeEntry timeentryObject)
        {
            bool result = true;
            timeentryObject.Revision = timeentryObject.Revision.HasValue ? (timeentryObject.Revision + 1) : 1;
            if (timeentryObject.Status == StatusEnum.InSubmissionQueue || timeentryObject.Status == StatusEnum.InProgress)
                if(timeentryObject.SubmittedBy == null) timeentryObject.SubmittedBy = UserContext.UserID;

            using (TimeEntryData data = new TimeEntryData(Transaction, UserContext))
            {
                switch (timeentryObject.RowState)
                {
                    // new time entry row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        result = data.Insert(timeentryObject) > 0;
                        break;
                    // delete existing time entry row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        result = data.Delete(timeentryObject.ID) > 0;
                        break;
                    // update existing time entry row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        result = data.Update(timeentryObject) > 0;
                        break;
                }
            }

            //if (result && 
            //    (timeentryObject.Status == StatusEnum.InProgress || timeentryObject.Status == StatusEnum.Approved 
            //    || timeentryObject.Status == StatusEnum.Rejected))
            //{
            //    using (TimeEntry_LogData logData = new TimeEntry_LogData(UserContext))
            //    {
            //        logData.Update(timeentryObject);
            //    }
            //}

            if (result)
            {
                // check to see if any note attached to the tim entry 
                if (timeentryObject.Notes != null)
                {
                    // process notes for time entry 
                    using (NoteManager noteManager = new NoteManager(Transaction, UserContext))
                    {
                        // loop through all notes for the time entry and process
                        foreach (Note note in timeentryObject.Notes)
                        {
                            if (note.UserID == 0)
                                //note.UserID = UserContext.UserID;
                                //edited by tsrdev2
                                //submit time entry for other
                                note.UserID = timeentryObject.UserID;

                            // update notes for time entry
                            if (noteManager.Update(note, timeentryObject.ID) == false)
                            {
                                result = false;
                                break;
                            }
                        }
                    }
                }
            }

            return result;
        }

        public bool ApproveRejectTimeEntriesByApprovalSummary(ApprovalSummary appSumObject, WFAction wFAction)
        {
            bool result = true;
            using (TimeEntryData data = new TimeEntryData(Transaction, UserContext))
            {
                result = data.ApproveRejectTimeEntries(appSumObject, wFAction) > 0;
            }
            return result;
        }

        //Added by tsrdev1
        //Added datetime 26/10/2010

        /// <summary>
        /// Overwrite TimeEntry Object.        
        /// </summary>
        /// <param name="timeentryObject"></param>
        /// <returns></returns>
        public bool OverwriteTimeEntry(TimeEntry timeentryObject)
        {
            bool result = true;
            timeentryObject.Revision = timeentryObject.Revision.HasValue ? (timeentryObject.Revision + 1) : 1;
            if (timeentryObject.Status == StatusEnum.InSubmissionQueue || timeentryObject.Status == StatusEnum.InProgress)
                if (timeentryObject.SubmittedBy == null) timeentryObject.SubmittedBy = UserContext.UserID;

            using (TimeEntryData data = new TimeEntryData(Transaction, UserContext))
            {
                // overwrite existing time entry row
                result = data.Overwrite(timeentryObject) > 0;
            }
            //if (result)
            //{
            //    using (TimeEntry_LogData logData = new TimeEntry_LogData(UserContext))
            //    {
            //        logData.Update(timeentryObject);
            //    }
            //}
            if (result)
            {
                // check to see if any note attached to the tim entry 
                if (timeentryObject.Notes != null)
                {
                    // process notes for time entry 
                    using (NoteManager noteManager = new NoteManager(Transaction, UserContext))
                    {
                        // loop through all notes for the time entry and process
                        foreach (Note note in timeentryObject.Notes)
                        {
                            if (note.UserID == 0)
                                //note.UserID = UserContext.UserID;
                                //edited by tsrdev2
                                //submit time entry for other
                                note.UserID = timeentryObject.UserID;

                            // update notes for time entry
                            if (noteManager.Update(note, timeentryObject.ID) == false)
                            {
                                result = false;
                                break;
                            }
                        }
                    }
                }
            }
            return result;
        }
        #endregion

        #region Time Sheet Summary
        /// <summary>
        /// Retrieve Time Entries for TimeSheet summary list: 
        /// Start time, End time, Organization, Project ID, Activity ID,and user group ID
        /// 
        /// last updated on:
        /// september 1 2009
        /// change description:
        /// </summary>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <param name="userGroupID"></param>
        /// <returns></returns>
        public TimeSheetSummaryList GetTimeEntriesForTimeSheetSummaryList(DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID)
        {
            TimeEntryList timeEntryList;
            TimeSheetSummaryList timeSheetSummaryList = new TimeSheetSummaryList();
            Int64 userID = -1;

            // create time entry list for the specified parameters
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                timeEntryList = timeEntryData.GetTimeEntriesForTimeSheetSummaryList(startTimeStamp, endTimeStamp.AddDays(1), organizationID, projectID, activityID, userGroupID, userID);
            }
            if (timeEntryList != null && timeEntryList.Count > 0)
            {
                timeSheetSummaryList = CreateTimesheetSummaries(timeEntryList);
            }
            return timeSheetSummaryList;
        }

        public ApprovalSummaryList GetApprovalTimeSheetSummaryList(DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, bool? showOnlyLocked, bool? showZeroHours)
        {
            ApprovalSummaryList lstApprovalSum = new ApprovalSummaryList();
            ApprovalSummaryList result = new ApprovalSummaryList();
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                lstApprovalSum = timeEntryData.GetApprovalTimeSheetSummaryList(startTimeStamp, endTimeStamp.AddDays(1), organizationID, projectID, activityID, userGroupID, null, showOnlyLocked, showZeroHours);
            }
            if (lstApprovalSum.Count > 0)
            {
                using (UserManager manager = new UserManager(UserContext))
                {
                    foreach (ApprovalSummary appsum in lstApprovalSum)
                    {
                        User usr = manager.Get(appsum.UserID, true);
                        if (usr != null)
                        {
                            appsum.User = usr;                            
                            result.Add(appsum);
                        }
                    }
                }
            }
            return result;
        } 

        public ApprovalSummary GetApprovalTimeSheetSummary(DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userID, bool? showOnlyLocked, bool? showZeroHours)
        {
            ApprovalSummaryList lstApprovalSum = new ApprovalSummaryList();
            ApprovalSummary result = new ApprovalSummary();
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                lstApprovalSum = timeEntryData.GetApprovalTimeSheetSummaryList(startTimeStamp, endTimeStamp.AddDays(1), organizationID, projectID, activityID, null, userID, showOnlyLocked, showZeroHours);
            }
            if (lstApprovalSum.Count > 0)
            {
                result = lstApprovalSum[0];
                using (UserManager manager = new UserManager(UserContext))
                {
                    User usr = manager.Get(result.UserID, true);
                    if (usr != null)
                    {
                        result.User = usr;
                        return result;
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Retrieve Approval Time Entries for approver: 
        /// Start time, End time, and approver ID
        /// 
        /// last updated on:
        /// september 1 2009
        /// change description:
        /// </summary>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <param name="userGroupID"></param>       
        /// <param name="approverID"></param>        
        /// <returns></returns>
        public TimeEntryList GetTimeEntries(DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? approverID)
        {
            //Buoc 2
            TimeEntryList timeEntryList;
            Int64 userID = -1;
            // create time entry list for the specified parameters
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                timeEntryList = timeEntryData.GetTimeEntriesForNotificationApprovers(startTimeStamp, endTimeStamp.AddDays(1), organizationID, projectID, activityID, userGroupID, userID, approverID);
            }
            return timeEntryList;
        }
        /// <summary>
        /// TimeSheet Summary List
        /// Process each row
        /// 
        /// last updated on:
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public TimeSheetSummaryList CreateTimesheetSummaries(TimeEntryList list)
        {
            TimeSheetSummaryList summaryList = new TimeSheetSummaryList();
            foreach (TimeEntry te in list)
            {
                TimeSheetSummary summary = summaryList.FindByUserID(te.UserID);
                if (summary == null)
                {
                    summary = new TimeSheetSummary();
                    using (UserManager manager = new UserManager(UserContext))
                    {
                        summary.User = manager.Get(te.UserID, true);
                    }
                    //add to summary list
                    summaryList.Add(summary);
                }
                // if not time entry in summary 
                if (summary.TimeEntries == null)
                    summary.TimeEntries = new TimeEntryList();

                TimeEntry res = summary.TimeEntries.FindByID(te.ID);
                if (res == null)
                {
                    summary.TimeEntries.Add(te);
                }
                if (summary.HoursPendingApproval == 0)
                    summaryList.Remove(summary);
            }
            return summaryList;
        }

        public TimeEntryList GetTimeEntriesForExpenseSummaryList(DateTime startTime, DateTime endTime, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID)
        {
            TimeEntryList timeEntries;
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                endTime = (endTime < DateTime.MaxValue ? endTime.AddDays(1) : DateTime.MaxValue);
                timeEntries = timeEntryData.GetTimeEntriesForExpenseSummaryList(startTime, endTime, organizationID, projectID, activityID, userGroupID, userID);
            }

            return timeEntries;
        }

        public TimeSheetSummary GetTimeSheetSummary(Int64 userID, DateTime startTimeStamp, DateTime endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID)
        {
            TimeEntryList timeEntries;
            TimeSheetSummary timeSheetSummary = new TimeSheetSummary();
            // create time entry list for the specified parameters
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                endTimeStamp = (endTimeStamp < DateTime.MaxValue ? endTimeStamp.AddDays(1) : DateTime.MaxValue);
                timeEntries = timeEntryData.GetTimeEntriesForTimeSheetSummaryList(startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID);
            }
            // if not null, create summary
            if (timeEntries != null && timeEntries.Count > 0)
            {
                timeSheetSummary = CreateTimesheetSummary(timeEntries, userID);
            }
            return timeSheetSummary;
        }

        private TimeSheetSummary CreateTimesheetSummary(TimeEntryList list, long userID)
        {
            TimeSheetSummary summary = new TimeSheetSummary();
            if (summary.TimeEntries == null)
                summary.TimeEntries = new TimeEntryList();
            foreach (TimeEntry te in list)
            {
                if (summary.TimeEntries.FindByID(te.ID) == null)
                    summary.TimeEntries.Add(te);
            }
            using(UserManager userManager = new UserManager(UserContext))
            {
                summary.User = userManager.Get(userID, true);
            }
            return summary;
        }

        #endregion
        /// <summary>
        /// Retrieve time entries for time sheet based on User ID, Approver ID
        /// show summary list
        /// 
        /// last updated on
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timeSheetID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        //public TimeSheetSummary GetTimeEntriesByTimeSheetID_UserID_ApproverUserID(long timeSheetID, long userID)
        //{
        //    // get time entry data
        //    using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
        //    {
        //        // create the list for time entries
        //        TimeEntryList list = timeEntryData.GetTimeEntriesByTimeSheetID_UserID_ApproverUserID(timeSheetID, userID);
        //        if (list != null && list.Count > 0)
        //            // return summary list
        //            return CreateTimesheetSummaries(list)[0];
        //        else
        //            return null;
        //    }
        //}

        /// <summary>
        /// Retriev e time entries by Approver
        /// 
        /// last updated on: 
        /// september 1, 2009
        /// change description:
        /// </summary>
        /// <param name="timeEntryID"></param>
        /// <returns></returns>
        public TimeEntry GetTimeEntryByTimeEntryID_ApproverUserID(Guid timeEntryID)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntryByTimeEntryID_ApproverUserID(timeEntryID);
            }
        }

        #region Time Entries Reports
        /// <summary>
        /// Time Entries Report processing logic
        /// 
        /// last updated on:
        /// september 2, 2009
        /// change description:
        /// </summary>
        /// <param name="reportID"></param>
        /// <returns></returns>
        public TimeEntryReportList GetTimeEntriesReport(short reportID)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReport(reportID);
            }
        }

        public TimeEntryReportList GetTimeEntriesReportBySearchCriteria(short reportID, DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, int? timeStatus, bool splitUser, int? outOfOfficeId)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReportBySearchCriteria(reportID, startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus, splitUser, outOfOfficeId);
                //list = timeManger.GetTimeEntriesReportForPendingSubmission(reportID);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reportID"></param>
        /// <param name="startTimeStamp"></param>
        /// <param name="endTimeStamp"></param>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="activityID"></param>
        /// <param name="userGroupID"></param>
        /// <param name="userID"></param>
        /// <param name="projectTypeID"></param>
        /// <param name="activityTypeID"></param>
        /// <param name="timeStatus"></param>
        /// <param name="splitUser"></param>
        /// <returns></returns>
        public TimeEntryReportList GetTimeEntriesReportBySearchCriteria_Paging(short reportID, DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, int? timeStatus, bool splitUser, int pageSize, int startIndex, out int total)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReportBySearchCriteria_Paging(reportID, startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus, splitUser, pageSize, startIndex, out total);
                //list = timeManger.GetTimeEntriesReportForPendingSubmission(reportID);
            }
        }


        public TimeEntryReportTotal GetTimeEntriesReportBySearchCriteria_Total(short reportID, DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, int? timeStatus)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReportBySearchCriteria_Total(reportID, startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus);
            }
        }

        /// <summary>
        /// As method GetTimeEntriesReport, retrieve time entry reports list. But ORDER BY Username
        /// </summary>
        /// <param name="reportID"></param>
        /// <returns></returns>
        public TimeEntryReportList GetTimeEntriesReport_SplitUser(short reportID)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReport_SplitUser(reportID);
            }
        }

        public TimeEntryReportList GetTimeEntriesReportForPendingSubmission(short reportID)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReportForPendingSubmission(reportID);
            }
        }
        #endregion

        #region Time Entries Views
        /// <summary>
        /// Retriev all time entry views
        /// 
        /// last updated on: 
        /// March 11, 2010
        /// change description:
        /// </summary>        
        /// <returns>TimeEntryViews</returns>
        public TimeEntryViewList GetAllTimeEntriesView()
        {
            using (TimeEntryData data = new TimeEntryData(UserContext))
            {
                return data.GetAllTimeEntriesView();
            }
        }

        public TimeEntryViewList GetTimeEntriesViewBySearchCriteria(DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, short? timeStatus)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesViewBySearchCriteria(startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus);
            }
        }

        #endregion

        //Added by tsrdev1
        //Added datetime 14/10/2010
        #region TimeEntry_OutlookAppointment
        /// <summary>
        /// 
        /// </summary>
        /// <param name="te_app"></param>
        /// <returns></returns>
        public bool UpdateTimeEntry_OutlookAppointment(TimeEntry_OutlookAppointment te_app)
        {
            bool result = true;
            using (TimeEntry_OutlookAppointmentData data = new TimeEntry_OutlookAppointmentData(Transaction, UserContext))
            {
                switch (te_app.RowState)
                {
                    // new time entry row
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        result = data.InsertTimeEntry_OutlookAppointment(te_app) > 0;
                        break;
                    // delete existing time entry row
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        result = data.DeleteTimeEntry_OutlookAppointment(te_app.ID) > 0;
                        break;
                    // update existing time entry row
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        result = data.UpdateTimeEntry_OutlookAppointment(te_app) > 0;
                        break;
                }
            }
            return result;            
        }
        public TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByTimeEntryID(Guid teID)
        {
            using (TimeEntry_OutlookAppointmentData data = new TimeEntry_OutlookAppointmentData(UserContext))
            {
                return data.GetTimeEntry_OutlookAppointmentByTimeEntryID(teID);
            }
        }
        public TimeEntry_OutlookAppointment GetTimeEntry_OutlookAppointmentByOutlookItemID(string outlookItemID)
        {
            using (TimeEntry_OutlookAppointmentData data = new TimeEntry_OutlookAppointmentData(UserContext))
            {
                return data.GetTimeEntry_OutlookAppointmentByOutlookItemID(outlookItemID);
            }
        }
        public TimeEntry_OutlookAppointmentList GetAllTimeEntry_OutlookAppointment()
        {
            using (TimeEntry_OutlookAppointmentData data = new TimeEntry_OutlookAppointmentData(UserContext))
            {
                return data.GetAllTimeEntry_OutlookAppointment();
            }
        }

        #endregion
        //End       

        public TimeEntryReportChartList GetTimeEntriesReportBySearchCriteria_Chart(short reportID, DateTime? startTimeStamp, DateTime? endTimeStamp, long? organizationID, long? projectID, long? activityID, long? userGroupID, long? userID, long? projectTypeID, long? activityTypeID, int? timeStatus, string groupBy)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetTimeEntriesReportBySearchCriteria_Chart(reportID, startTimeStamp, endTimeStamp, organizationID, projectID, activityID, userGroupID, userID, projectTypeID, activityTypeID, timeStatus, groupBy);
            }
        }

        //Add 20160224
        /// <summary>
        /// If in the duration (startTimeEntry - endTimeEntry), there's atleast one day is locked => return false
        /// </summary>
        /// <param name="id">TimeEntry Id</param> 
        /// <returns></returns>
        public bool CheckIfDurationWasLocked(long userId, Guid timeEntryId, DateTime startTimeEntry)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.CheckIfDurationWasLocked(userId, timeEntryId, startTimeEntry);
            }
        }

        //Add 20160511
        /// <summary>
        /// Get all locked dates by userId
        /// </summary>
        /// <param name="userId">User Id</param>
        /// <param name="formatDate">format date string</param>
        /// <returns></returns>
        public string GetLockedDatesByUserId(long userId, string formatDate)
        {
            using (TimeEntryData timeEntryData = new TimeEntryData(UserContext))
            {
                return timeEntryData.GetLockedDatesByUserId(userId, formatDate);
            }
        }
    }
}

