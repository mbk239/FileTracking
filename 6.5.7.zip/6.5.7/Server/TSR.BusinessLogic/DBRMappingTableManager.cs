﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.DataAccess;


namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing DBRMappingTable.
    /// Get Data Bridge mapping table
    /// This class extend on class BaseManager
    /// </summary>
    public class DBRMappingTableManager : BaseManager
    {
        public DBRMappingTableManager(UserContext context) : base(context) { }
        public DBRMappingTableManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        public DBRMappingTableList GetDBRMappingTableByOrganizationID(long organizationID, int entityTypeID)
        {
            DBRMappingTableList objList = new DBRMappingTableList();
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                DBRMappingTable item = data.GetByDestinationIDEntityTypeID(organizationID.ToString(), entityTypeID);
                if (item != null)
                {
                    objList.Add(item);
                }
            }
            return objList;
        }

        public DBRMappingTable GetByDestinationIDEntityTypeID(string destinationID, int entityTypeID)
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetByDestinationIDEntityTypeID(destinationID, entityTypeID);
            }
        }

        public DBRMappingTableList GetAllBySourceIDApplicationIDEntityTypeID(string applicationID, string sourceID, int entityTypeID)
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetAllBySourceIDApplicationIDEntityTypeID(sourceID, applicationID, entityTypeID);
            }
        }

        public DBRMappingTableList GetAllBySourceIDEntityTypeID(string sourceID, int entityTypeID)
        {
            return GetAllBySourceIDApplicationIDEntityTypeID(sourceID, string.Empty, entityTypeID);
        }

        public DBRMappingTable GetBySourceIDApplicationID(string applicationID, string sourceID)
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetBySourceIDApplicationID(sourceID, applicationID);
            }
        }

        public DBRMappingTable GetBySourceIDApplicationIDEntityTypeID(string applicationID, string sourceID, int entityTypeID)
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetBySourceIDApplicationIDEntityTypeID(sourceID, applicationID, entityTypeID);
            }
        }

        public long Update(DBRMappingTable dbrMapping)
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                switch (dbrMapping.RowState)
                {
                    case BaseBusinessEntity.RowStateEnum.NormalRow:
                        return 0;
                    case BaseBusinessEntity.RowStateEnum.NewRow:
                        return data.Insert(dbrMapping);
                    case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                        return data.Update(dbrMapping);
                    case BaseBusinessEntity.RowStateEnum.DeletedRow:
                        return data.Delete(dbrMapping.ID);
                    default:
                        break;
                }
            }
            return -1;
        }

        public DBRMappingTableList GetDBRMappingOrganizationForExport()
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetDBRMappingOrganizationForExport();
            }
        }

        public DBRMappingTableList GetDBRMappingProjectForExport()
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetDBRMappingProjectForExport();
            }
        }

        public DBRMappingTableList GetDBRMappingActivityForExport()
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetDBRMappingActivityForExport();
            }
        }

        public DBRMappingTableList GetDBRMappingContactForExport()
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetDBRMappingContactForExport();
            }
        }

        public DBRMappingTableList GetDBRMappingUserForExport()
        {
            using (DBRMappingTableData data = new DBRMappingTableData(UserContext))
            {
                return data.GetDBRMappingUserForExport();
            }
        }
    }
}
