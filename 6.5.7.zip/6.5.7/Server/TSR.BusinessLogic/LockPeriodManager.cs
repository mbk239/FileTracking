﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TSR.DataAccess;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class LockPeriodManager : BaseManager
    {
        //Constructor
        public LockPeriodManager(UserContext context) : base(context) { }
        public LockPeriodManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #region Functions
        public LockPeriodList GetLockPeriodByUserID(long userID)
        {
            using (LockPeriodData data = new LockPeriodData(UserContext))
            {
                return data.GetLockPeriodByUserID(userID);
            }
        }


        public LockPeriodList GetLockPeriodByUserIDInIntervalDays(long userID, DateTime startDate, int intervalDays)
        {
            using (LockPeriodData data = new LockPeriodData(UserContext))
            {
                return data.GetLockPeriodByUserIDInIntervalDays(userID, startDate, intervalDays);
            }
        }
        #endregion

    }
}
