using System;
using System.Collections.Generic;
using System.Linq;
using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;
using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework.Security;
namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for TSR Users.
    /// Code for retrieving user list, user details, updates of users, assignment of roles, etc.
    /// 
    /// Last updated on: 
    /// August 30, 2009
    /// Change description:
    /// </summary>
    public class UserManager : BaseManager
    {
        public UserManager(UserContext context) : base(context) { }
        public UserManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve user information based on ID
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public User Get(long ID)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve detail information for a User
        /// Details include Person information, Roles attached to the user.
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public User Get(long ID, bool fillChild)
        {
            User user = Get(ID);

            if ((user != null) && (fillChild))
            {
                if (user.PersonID.HasValue)
                {
                    // get Person information for this user
                    using (PersonManager personManager = new PersonManager(UserContext))
                    {
                        user.Person = personManager.Get(user.PersonID.Value, true);
                    }
                }
                // Get role information for this user.
                using (RoleManager roleManager = new RoleManager(UserContext))
                {
                    user.RoleList = roleManager.GetRolesByUserID(user.ID);
                }
            }

            return user;
        }

        public User GetUserPerson(long ID)
        {
            User user = Get(ID);

            if (user != null)
            {
                if (user.PersonID.HasValue)
                {
                    // get Person information for this user
                    using (PersonManager personManager = new PersonManager(UserContext))
                    {
                        user.Person = personManager.Get(user.PersonID.Value);
                    }
                }
            }

            return user;
        }

        /// <summary>
        /// added by tsrdev2
        /// </summary>
        /// <param name="ADSID"></param>
        /// <returns></returns>
        public User GetDeletedADUser(string ADSID)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetDeletedADUser(ADSID);
            }
        }
        /// <summary>
        /// added by tsrdev2
        /// </summary>
        /// <param name="ADSID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public User GetDeletedADUser(string ADSID, bool fillChild)
        {
            User user = GetDeletedADUser(ADSID);

            if ((user != null) && (fillChild))
            {
                if (user.PersonID.HasValue)
                {
                    // get Person information for this user
                    using (PersonManager personManager = new PersonManager(UserContext))
                    {
                        user.Person = personManager.Get(user.PersonID.Value, true);
                    }
                }
                // Get role information for this user.
                using (RoleManager roleManager = new RoleManager(UserContext))
                {
                    user.RoleList = roleManager.GetRolesByUserID(user.ID);
                }
            }

            return user;
        }

        /// <summary>
        /// gets deleted user by user id
        /// </summary>
        /// added by tsrdev2
        /// <param name="ADSID"></param>
        /// <returns></returns>
        public User GetDeletedUserByUserID(Int64 id)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetDeletedUserByUserID(id);
            }
        }

        /// <summary>
        /// gets deleted user by user id with person info
        /// </summary>
        /// added by tsrdev2
        /// <param name="ADSID"></param>
        /// <returns></returns>
        public User GetDeletedUserByUserID(long id, bool fillChild)
        {
            User user = GetDeletedUserByUserID(id);

            if ((user != null) && (fillChild))
            {
                if (user.PersonID.HasValue)
                {
                    // get Person information for this user
                    using (PersonManager personManager = new PersonManager(UserContext))
                    {
                        user.Person = personManager.Get(user.PersonID.Value, true);
                    }
                }               
            }

            return user;
        }
        /// <summary>
        /// Retrieve / Search user by username (both active and inactive - not deleted)
        /// 
        /// last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public User GetUserByUsername(string username)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetUserByUsername(username);
            }
        }

        /// <summary>
        /// Retrieve / Search user by username
        /// 
        /// last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public User GetActiveUserByUsername(string username)
        {
            using (UserData data = new UserData(UserContext))
            {
                User user = data.GetUserByUsername(username);
                if (user == null)
                    return null;
                else
                {
                    if (user.IsActive)
                        return user;
                    else
                        return null;
                }
            }
        }

        public User GetActiveUserByUsername(string username, bool fillChild)
        {
            using (UserData data = new UserData(UserContext))
            {
                User user = data.GetUserByUsername(username);
                if (user == null)
                    return null;
                else
                {
                    if (user.IsActive)
                    {
                        if ((user != null) && (fillChild))
                        {
                            if (user.PersonID.HasValue)
                            {
                                // get Person information for this user
                                using (PersonManager personManager = new PersonManager(UserContext))
                                {
                                    user.Person = personManager.Get(user.PersonID.Value, true);
                                }
                            }
                            // Get role information for this user.
                            using (RoleManager roleManager = new RoleManager(UserContext))
                            {
                                user.RoleList = roleManager.GetRolesByUserID(user.ID);
                            }
                        }
                        return user;
                    }
                    else
                        return null;
                }
            }
        }
        /// <summary>
        /// Retrieve list of Users (all users).
        /// 
        /// last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public UserList GetAll()
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Retrieve list of Users Isactive (all users).
        /// 
        /// last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public UserList GetAllIsActive()
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetAllIsActive();
            }
        }       
        
        /// <summary>
        /// Used for retrieving direct users by User Group ID
        /// 
        /// Last updated on: 
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupID"></param>
        /// <returns></returns>
        public UserList GetDirectUsersByUserGroupID(long userGroupID)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetDirectUsersByUserGroupID(userGroupID);
            }
        }

        public UserList GetDirectUsersByUserGroupID(long userGroupID, bool isActive)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetDirectUsersByUserGroupID(userGroupID, isActive);
            }
        }
        /// <summary>
        /// Used for retrieving users by user group ID.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <param name="userGroupID"></param>
        /// <returns></returns>
        public UserList GetUsersByUserGroupID(long userGroupID)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetUsersByUserGroupID(userGroupID);
            }
        }

        /// by tsrdev2
        /// <summary>
        /// Retrieves a User by id not flag by active and deleted
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public User GetUserByIDNotFlagByActiveAndDeleted(Int64 id)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetUserByIDNotFlagByActiveAndDeleted(id);
            }
        }
        /// added by tsrdev2
        /// <summary>
        /// Retrieves a User by id not flag by active and deleted
        /// </summary>
        /// <param name="id"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public User GetUserByIDNotFlagByActiveAndDeleted(long id, bool fillChild)
        {
            User user = GetUserByIDNotFlagByActiveAndDeleted(id);

            if ((user != null) && (fillChild))
            {
                if (user.PersonID.HasValue)
                {
                    // get Person information for this user
                    using (PersonManager personManager = new PersonManager(UserContext))
                    {
                        user.Person = personManager.Get(user.PersonID.Value, true);
                    }
                }
            }

            return user;
        }
        /// <summary>
        /// Used for retrieving active users by user group ID.
        /// 
        /// Last updated on:
        /// May 03, 2010
        /// Change description:
        /// </summary>
        /// <param name="userGroupID"></param>
        /// <returns></returns>
        public UserList GetActiveUsersByUserGroupID(long userGroupID)
        {
            using (UserData data = new UserData(UserContext))
            {
                return data.GetAllActiveUsersByUserGroupID(userGroupID);
            }
        }

        /// <summary>
        /// gets a list of active users that submit timesheet by current user.
        /// </summary>
        /// added by tsrdev2
        /// <returns></returns>
        public UserList GetActiveUsersByCurrentContext()
        {
            if (UserContext != null)
            {
                long currentUserID = UserContext.UserID;
                UserGroupList groupList = new UserGroupList();
                UserList userList = new UserList();
                UserList allUser = GetAllIsActive();                

                using (UserGroupData userGroupData = new UserGroupData(UserContext))
                {
                    groupList = userGroupData.GetUserGroupsByUserID(currentUserID); 
                }
                foreach (User usr in allUser)
                {
                    foreach (UserGroup grp in groupList)
                    {
                        if (usr.RequestedSubmissionUserGroupID == grp.ID)
                        {
                            if (userList.FindByID(usr.ID) == null)
                            {
                                userList.Add(usr);
                            }                            
                            break;
                        }
                    }                    
                }                

                return userList;
            }
            return null;
        }

        public User_RoleList GetRoleUserList()
        {
            User_RoleList roleList = new User_RoleList();
            using (User_RoleData listRoleData = new User_RoleData(Transaction, UserContext))
            {
               roleList= listRoleData.GetAll();
            }
            return roleList;            
        }
        public bool UpdateRoleUser(User_Role roleObj)
        {
            using (User_RoleData listRoleData = new User_RoleData(Transaction, UserContext))
            {
                listRoleData.Delete(roleObj.ID);
            }
            return true;
        }
        /// <summary>
        /// Data manipulation (updates, etc.) for User object (base)
        /// </summary>
        /// <param name="userObject"></param>
        /// <returns></returns>
        
        public bool UpdateBase(User userObject)
        {
            
            bool success = true;

            if ((userObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow) && (userObject.ID == UserContext.UserID))
            {
                throw new Exception(ResourceManager.GetResourceString("CannotRemoveOwnUserMsg", "Cannot remove your own user"));
            }
            else if ((userObject.RowState == BaseBusinessEntity.RowStateEnum.ActiveRow) && (userObject.ID == UserContext.UserID))
            {
                throw new Exception(ResourceManager.GetResourceString("CannotActivateOwnUserMsg", "Cannot activate your own user"));
            }
            else if ((userObject.RowState == BaseBusinessEntity.RowStateEnum.InActiveRow) && (userObject.ID == UserContext.UserID))
            {
                throw new Exception(ResourceManager.GetResourceString("CannotInactivateOwnUserMsg", "Cannot inactivate your own user"));
            }
   
            if (userObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                User tempUser;
                using (UserData userData = new UserData(Transaction, UserContext))
                {
                    tempUser = userData.GetUserByUsername(userObject.Username);
                }
                if (tempUser != null && tempUser.ID != userObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new UniqueConstraintException(userObject, new Exception(errorInfo));
                }
            }
            if (userObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
                success = UpdateUsersPerson(userObject);

            if (success)
            {
                using (UserData data = new UserData(Transaction, UserContext))
                {
                    // handling of different types of data manipulation (insert, update, delete)
                    switch (userObject.RowState)
                    {
                        // Insert new row
                        case BaseBusinessEntity.RowStateEnum.NewRow:
                            {
                                userObject.ID = data.Insert(userObject);
                                if (userObject.ID > 0)
                                    success = true;
                            }
                            break;
                        // update existing row
                        case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                            success = data.Update(userObject) > 0;
                            break;
                        // delete (logical) existing row
                        case BaseBusinessEntity.RowStateEnum.DeletedRow:
                            {
                                success = data.Delete(userObject.ID) > 0;
                                if (userObject.Person != null)
                                {
                                    userObject.Person.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                                    success = success && UpdateUsersPerson(userObject);
                                }
                                break;
                            }
                        //undeleted row already exist in TST but IsDeleted = true
                        case BaseBusinessEntity.RowStateEnum.UnDeletedRow:
                            {
                                success = data.UnDeleted(userObject) > 0;
                            }
                            break;
                        case BaseBusinessEntity.RowStateEnum.ActiveRow:
                            success = data.Update(userObject) > 0;
                            break;
                        case BaseBusinessEntity.RowStateEnum.InActiveRow:
                            success = Inactivate(userObject);
                            break;
                    }
                }
            }
            return success;
        }
        public bool Inactivate(User userObject)
        {
            bool success = false;
            if (userObject != null)
            {
                using (UserData userData = new UserData(Transaction,UserContext))
                {
                    success = userData.Update(userObject) > 0;
                }                
                if (success)
                {
                    success = RemoveUserGroupUserByUserID(userObject.ID);
                }
            }
            return success;
        }
        private bool RemoveUserGroupUserByUserID(long userID)
        {
            using (UserGroup_UserData ug_usr = new UserGroup_UserData(Transaction,UserContext))
            {
                return ug_usr.RemoveByUserID(userID) >= 0;
            }
        }
        /// <summary>
        /// updates person for user
        /// </summary>
        /// <param name="userObject">user object</param>
        /// <returns></returns>
        private bool UpdateUsersPerson(User userObject)
        {
            if (userObject.Person != null)
            {
                using (PersonManager personManager = new PersonManager(Transaction, UserContext))
                {
                    if (personManager.Update(userObject.Person) == false)
                    {
                        return false;
                    }
                    else
                    {
                        //after updating person of user, person id needs to be updated too
                        userObject.PersonID = userObject.Person.ID;
                        if (userObject.RowState == BaseBusinessEntity.RowStateEnum.NormalRow)
                        {
                            userObject.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Role assignment for Users
        /// </summary>
        /// <param name="userObject"></param>
        /// <param name="roleList"></param>
        /// <returns></returns>
        public bool AssignRole(User userObject, RoleList roleList)
        {
            if (userObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                foreach (Role role in roleList)
                {
                    role.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                }
            }

            if (roleList != null && roleList.Count > 0)
            {
                User_RoleData user_roleData = new User_RoleData(Transaction, UserContext);

                // for loop for each role
                foreach (Role role in roleList)
                {
                    switch (role.RowState)
                    {
                        // assign new role
                        case BaseBusinessEntity.RowStateEnum.NewRow:
                            if (user_roleData.Add(userObject.ID, role.ID) <= 0)
                                return false;
                            break;
                        // delete / remove roles from user
                        case BaseBusinessEntity.RowStateEnum.DeletedRow:
                            if (user_roleData.Remove(userObject.ID, role.ID) <= 0)
                            {
                                return false;
                            }
                            //if (usr_role != null)
                            //    if (user_roleData.Delete(usr_role.ID) <= 0)
                            //        return false;
                            break;
                    }
                }
            }

            return true;
        }

        public bool AddRolesForMultipleUsers(RoleList roles, UserList users)
        {
            bool success = false;
            User userToUpdate;
            RoleList rolesToBeAdded = new RoleList();


            foreach (User user in users)
            {
                if (user.RoleList == null)
                {
                    userToUpdate = Get(user.ID, true);
                    userToUpdate.RowState = user.RowState;
                }
                else
                    userToUpdate = user;

                foreach (Role role in roles)
                {
                    if (!userToUpdate.RoleList.Contains(role))
                    {
                        role.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                    }
                    else
                        role.RowState = BaseBusinessEntity.RowStateEnum.NormalRow;

                    rolesToBeAdded.Add(role);

                }
                success = AssignRole(userToUpdate, rolesToBeAdded);
                if (!success)
                    break;
                rolesToBeAdded = new RoleList();
            }

            return success;
        }

        /// <summary>
        /// User object update.
        /// Handles license check as well during user updates.
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="userObject"></param>
        /// <returns></returns>
        public bool Update(User userObject)
        {            
            bool success = false;            
            if ((userObject.RowState == BaseBusinessEntity.RowStateEnum.NewRow) ||
                userObject.RowState == BaseBusinessEntity.RowStateEnum.ActiveRow ||
                userObject.RowState == BaseBusinessEntity.RowStateEnum.UnDeletedRow)
            {
                long addableNumberOFUsers = getAddibleNumberOfUsers();
                if ((addableNumberOFUsers - 1) < 0)
                    // license check for total number of users allowed
                    throw new LicenseException(new Exception(ResourceManager.GetResourceString("OverflowUsers", "User(s) can not be added. Cannot exceed total number of licensed users.")));
            }

            success = UpdateBase(userObject);

            if (success)
                success = AssignRole(userObject, userObject.RoleList);

            return success;
        }
        /// <summary>
        /// Total Users count.
        /// 
        /// Last updated on:
        /// August 31, 2009
        /// Change description:
        /// </summary>
        /// <returns></returns>
        public long GetTotalUsers()
        {
            UserData userData = new UserData(UserContext);
            //comment by tsrdev2 - hosted version
            //return userData.GetAll().FindAllADUsers().Count;
            
            //added by tsrdev2 - hosted version
            return userData.GetAll().Count;
        }

        public long GetTotalActivedUsers()
        {
            UserData userData = new UserData(UserContext);
            return userData.GetAllIsActive().Count;
        }

        public long GetTotalExpenseUsers()
        {
            using (UserData userData = new UserData(UserContext))
            {
                UserList lst = userData.GetAllIsActive();
                return lst.Where(u => u.UseExpenses).Count();
            }
        }
        /// <summary>
        /// Number of Users that can be added to TSR system - based on license, etc.
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public long getAddibleNumberOfUsers()
        {
            return getAddibleNumberOfUsers(0);
        }

        /// <summary>
        /// Overloaded method to get total number of users that can be added. This method is extended in the sense
        /// that it considers, how many users are going to be deleted at the same time
        /// </summary>
        /// <param name="NumberOfUsersToBeDeleted">number of users to be deleted</param>
        /// <returns></returns>
        public long getAddibleNumberOfUsers(long NumberOfUsersToBeDeleted)
        {
            long totalExistingUsers = GetTotalActivedUsers() - NumberOfUsersToBeDeleted;
            ApplicationLicense apLicense = LicenseManager.GetLicense();
            long allowedNumberOfUsers = apLicense.NumberOfUsers;
            return allowedNumberOfUsers - totalExistingUsers;
        }

        public long getAddibleNumberOfUsers(UserList userListObject)
        {
            // total deleted users count
            long totalDeletedUsers = userListObject.FindAllDeletedUsers().Count;
            // total updated users count
            long totalNewUsers = userListObject.FindAllNewUsers().Count;
            //total undeleted users count
            long totalUnDeletedUsers = userListObject.FindAllUnDeletedUsers().Count;  

            //total inactive
            long totalInActiveUsers = userListObject.FindAllInActiveUsers().Count;
            //total active
            long totalActiveUsers = userListObject.FindAllActiveUsers().Count;

            //total existed
            long totalExists = GetTotalActivedUsers();

            ApplicationLicense apLicense = LicenseManager.GetLicense();
            long allowedNumberOfUsers = apLicense.NumberOfUsers;
            return allowedNumberOfUsers - (totalExists +totalNewUsers + totalUnDeletedUsers + totalActiveUsers - totalDeletedUsers -totalInActiveUsers);
        }
        /// <summary>
        /// Update of User List
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="userListObject"></param>
        /// <returns></returns>
        public bool Update(UserList userListObject)
        {
            
            bool success = false;            
            if (getAddibleNumberOfUsers(userListObject) < 0)
                //&&numberOfUserThatCanBeAdded>=0)
            {
                // licensed users check
                throw new LicenseException(new Exception(ResourceManager.GetResourceString("OverflowUsers", "User(s) can not be added. Cannot exceed total number of licensed users.")));
            }

            foreach (User userObject in userListObject)
            {                
                success = UpdateBase(userObject);

                if (success)
                    success = AssignRole(userObject, userObject.RoleList);
                if (!success)
                {
                    return success;
                }
            }
            return success;
        }

        /// <summary>
        /// Update of User List
        /// 
        /// Last updated on:
        /// August 30, 2009
        /// Change description:
        /// </summary>
        /// <param name="userListObject"></param>
        /// <returns></returns>
        public bool UpdateExpenseUser(UserList userListObject)
        {

            bool success = false;
            
            foreach (User userObject in userListObject)
            {
                success = UpdateBase(userObject);

                if (success)
                    success = AssignRole(userObject, userObject.RoleList);
                if (!success)
                {
                    return success;
                }
            }
            return success;
        }

        public bool ImportUser(User userObject)
        {
            bool success = false;
            success = UpdateBase(userObject);
            if (success)
                success = AssignRole(userObject, userObject.RoleList);
            return success;
        }

        //added by tsrdev2
        /// <summary>
        /// Retrieve list of SupperUsers
        /// </summary>
        /// <returns></returns>
        public UserList GetAllSuperUsers()
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetAllSuperUser();
            }
        }
        //added by tsrdev2
        /// <summary>
        /// Retrieve one SuperUser by username
        /// </summary>
        /// <returns></returns>
        public User GetSuperUserByUserName(string username)
        {
            using (UserData userData = new UserData(UserContext))
            {
                UserList listSuperUsers = userData.GetAllSuperUser();
                return listSuperUsers.FindByUserName(username);
            }
        }

        //added by tsrdev2
        /// <summary>
        /// Retrieve list of users was approved time sheet
        /// </summary>
        /// <returns></returns>
        public UserList GetUsersApproved()
        {
            ///comment for removing workflow module
            //WorkflowInstance_UserGroupDefinitionList wfiList = new WorkflowInstance_UserGroupDefinitionList();
            //List<long> userIDList = new List<long>();
            //UserList userList = new UserList();
            //using (WorkflowInstance_UserGroupDefinitionData wfiData = new WorkflowInstance_UserGroupDefinitionData(UserContext))
            //{
            //    wfiList = wfiData.GetAll();
            //}
            //if (wfiList != null && wfiList.Count > 0)
            //{
            //    foreach (WorkflowInstance_UserGroupDefinition wfi in wfiList)
            //    {
            //        if (!userIDList.Contains(wfi.UserID))
            //        {
            //            userIDList.Add(wfi.UserID);
            //        }
            //    }
            //}            
            //foreach (int userId in userIDList)
            //{
            //    User usr = Get(userId, true);
            //    if (usr != null && usr.IsActive)
            //    {
            //        userList.Add(usr);
            //    }
            //}

            UserList list = new UserList();
            using (UserData data = new UserData(UserContext))
            {
                list = data.GetAllApproverUser();
                foreach (User user in list)
                {
                    if (user != null)
                    {
                        if (user.PersonID.HasValue)
                        {
                            // get Person information for this user
                            using (PersonManager personManager = new PersonManager(UserContext))
                            {
                                user.Person = personManager.Get(user.PersonID.Value, false);
                            }
                        }
                    }
                }                
            }
            return list;
        }

        //added by tsrdev2
        public UserList GetUsersApprovedOrRejectedTimeEntriesByTimeSpan(DateTime start, DateTime end)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUsersApprovedOrRejectedTimeEntriesByTimeSpan(start, end);
            }
        }

        /// <summary>
        /// Get users can become project manager. 
        /// (add by tsrdev2 - feature 229)
        /// </summary>
        /// <returns></returns>      
        public UserList GetUserHasProjectManagerPermission()
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUserHasProjectManagerPermission();
            }
        }

        public UserList GetUsersByUserGroupIDForPaging(int startOffset, int numberOfItems, long ugID, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUsersByUserGroupIDForPaging(startOffset, numberOfItems, ugID, name, out total);
            }
        }

        public UserList GetUsersInExpenseAprroverByUserGroupIDForPaging(int startOffset, int numberOfItems, long ugID, long curUserID, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUsersInExpenseAprroverByUserGroupIDForPaging(startOffset, numberOfItems, ugID, curUserID, name, out total);
            }
        }

        public UserList GetUserByProjectIDForPaging(int startOffset, int numberOfItems, long projID, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUserByProjectIDForPaging(startOffset, numberOfItems, projID, name, out total);
            }
        }

        public UserList GetUserInExpenseAprroverByProjectIDForPaging(int startOffset, int numberOfItems, long projID, long curUserID, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUserInExpenseAprroverByProjectIDForPaging(startOffset, numberOfItems, projID, curUserID, name, out total);
            }
        }

        public UserList GetUserForPaging(int startOffset, int numberOfItems, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUserForPaging(startOffset, numberOfItems, name, out total);
            }
        }

        public UserList GetUserInExpenseAprroverForPaging(int startOffset, int numberOfItems, long curUserID, string name, out int total)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetUserInExpenseAprroverForPaging(startOffset, numberOfItems, curUserID, name, out total);
            }
        }
        
        public UserList GetActiveUsersByCurrentContextForPaging(long userID, int startOffset, int numberOfItems, string name, out int totalRecords)
        {
            using (UserData userData = new UserData(UserContext))
            {
                return userData.GetActiveUsersByCurrentContextForPaging(userID, startOffset, numberOfItems, name, out totalRecords);
            }
        }

        public UserList GetUsersPersonForExport(long userGroupID)
        {
            UserList lst = new UserList();
            using (UserData userData = new UserData(UserContext))
            {
                lst = userData.GetUsersPersonForExport(userGroupID);
            }
            if (lst.Count > 0)
            {
                using (UserDetailManager userdetailManager = new UserDetailManager(UserContext))
                {
                    foreach (User usr in lst)
                    {
                        if (usr.Person != null)
                            usr.Person.UserDetailList = userdetailManager.GetUserDetailsByPersonID(usr.Person.ID);
                    }
                }
            }
            return lst;
        }
    }
}

