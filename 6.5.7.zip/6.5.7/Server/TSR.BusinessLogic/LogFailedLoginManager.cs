﻿using System;
using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;
using TSR.Framework.Exceptions;
using TSR.Framework.Resource;
using TSR.Framework.Security;
namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Log of Failed Login.    
    /// Manage status of Login action, that will be log into database and file
    /// added by tsrdev2
    /// </summary>
    public class LogFailedLoginManager : BaseManager
    {
        public LogFailedLoginManager(UserContext context) : base(context) { }
        public LogFailedLoginManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
      
        public LogFailedLogin Get(long ID)
        {
            using (LogFailedLoginData data = new LogFailedLoginData(UserContext))
            {
                return data.Get(ID);
            }
        }

        public LogFailedLoginList GetAll()
        {
            LogFailedLoginList result = new LogFailedLoginList();
            using (LogFailedLoginData data = new LogFailedLoginData(UserContext))
            {
                result = data.GetAll();
            }
            PopulateUserName(result);
            return result;
        }       
        //added by tsrdev2
        /// <summary>
        /// Gets log of failed login (not contain 'Success' log)
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="source"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public LogFailedLoginList GetLogFailedLoginBySearch(long userID, DateTime start, DateTime end, int source, int type)
        {
            LogFailedLoginList result = new LogFailedLoginList();
            using (LogFailedLoginData data = new LogFailedLoginData(UserContext))
            {
                result = data.GetLogFailedLoginBySearchCriteria(userID, start, end, source, type);
            }
            PopulateUserName(result);
            return result;
        }

        //added by tsrdev2
        /// <summary>
        /// Gets log of login (include 'Success' log)
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="source"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public LogFailedLoginList GetLogLoginByTimeSpan(long userID, DateTime start, DateTime end, int source, int type)
        {
            LogFailedLoginList result = new LogFailedLoginList();
            using (LogFailedLoginData data = new LogFailedLoginData(UserContext))
            {
                result = data.GetLogLoginByTimeSpan(userID, start, end, source, type);
            }
            PopulateUserName(result);
            return result;
        }

        private void PopulateUserName(LogFailedLoginList list)
        {
            if (list != null)
            {
                foreach (LogFailedLogin log in list)
                {
                    //if userName is not unknown user
                    if (string.IsNullOrEmpty(log.UserName) && log.UserID > 0)
                    {
                        using (UserManager userManager = new UserManager(UserContext))
                        {
                            User user = userManager.Get(log.UserID);
                            if (user != null)
                            {
                                log.UserName = user.Username;
                            }
                        }
                    }
                }
            }
        }

    }
}