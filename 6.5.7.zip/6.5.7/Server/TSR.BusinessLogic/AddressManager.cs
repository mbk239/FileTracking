using System;

using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Data.SqlClient;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Address component.
    /// Reusable Address component with enhanced functionalities and dynamic controls.
    /// Logic processing includes various data retrieval and manipulation functions.
    /// 
    /// Last updated on:
    /// August 30, 2009
    /// Change description:
    /// </summary>
    public class AddressManager : BaseManager
    {
        public AddressManager(UserContext context) : base(context) { }
        public AddressManager(System.Data.SqlClient.SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve address using unique ID
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Address Get(long ID)
        {
            using (AddressData data = new AddressData(UserContext))
            {
                Address addr = data.Get(ID);
                // Retrieve Communication Details for the Address.
                using (CommDetailManager commDetailManager = new CommDetailManager(UserContext))
                {
                    addr.CommDetailList = commDetailManager.GetCommDetailsByAddressID(ID);
                }
                return addr;
            }
            
        }
        /// <summary>
        /// Retrieve Address Types.
        /// Different address types are allowed, for example: postal, primary, secondary, etc.
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public AddressType GetAddressType(long ID)
        {
            using (AddressTypeData data = new AddressTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrievs Country data for use with Address component.
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Country GetCountry(long ID)
        {
            using (CountryData data = new CountryData(UserContext))
            {
                return data.Get(ID);
            }
        }
        /// <summary>
        /// Retrieve list of Addresses
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public AddressList GetAll()
        {
            using (AddressData data = new AddressData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Retrieve list of all countries for use by address component
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public CountryList GetAllCountries()
        {
            using (CountryData data = new CountryData(UserContext))
            {
                return data.GetAll();
            }
        }
        /// <summary>
        /// Retrieves all address types
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public AddressTypeList GetAllAddressTypes()
        {
            using (AddressTypeData data = new AddressTypeData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// Update AddressType Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="addressTypeObject"></param>
        /// <returns></returns>
        public bool Update(AddressType addressTypeObject)
        {
            if (addressTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                AddressType tempAddressType;
                using (AddressTypeData addressTypeData = new AddressTypeData(UserContext))
                {
                    tempAddressType = addressTypeData.GetAddressTypeByAddressTypeName(addressTypeObject.Name);
                }

                if (tempAddressType != null && tempAddressType.ID != addressTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");                    
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(addressTypeObject, new Exception(errorInfo));
                    //throw new TSR.Framework.Exceptions.UniqueConstraintException(addressTypeObject, new Exception(ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE));
                }
            }

            AddressTypeData data = new AddressTypeData(UserContext);

            // use of switch for different types of DML
            switch (addressTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to addressTypeObject
                    long id = data.Insert(addressTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        addressTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(addressTypeObject.ID) > 0);
            }
            // update rows
            return (data.Update(addressTypeObject) > 0);
        }

        /// <summary>
        /// Update logic for address Object.
        /// Data manipulation: insert, update, delete.
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="addressObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(Address addressObject, BaseRelationData relationData, long parentID)
        {
            AddressData data = new AddressData(Transaction, UserContext);
            // switch statement for different DML scenarios (insert, update, delete)
            //Add new standard address type if standard address type is null
            if (addressObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                long idAddressType = -1;
                if (addressObject.AddressTypeID == TSR.Framework.ConstantCollection.AdressTypeID)
                {
                    if (GetAddressType(TSR.Framework.ConstantCollection.AdressTypeID) == null)
                    {
                        AddressType addressType = new AddressType();
                        addressType.ID = TSR.Framework.ConstantCollection.AdressTypeID;
                        addressType.Name = TSR.Framework.ConstantCollection.AdressTypeName;                        
                        addressType.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                        //addressType.Description = typedesc;                           
                        AddressTypeData addressTypeData = new AddressTypeData(UserContext);
                        idAddressType = addressTypeData.Insert(addressType);
                        if (idAddressType < 0)
                            return false;
                    }
                }
            }
            switch (addressObject.RowState)
            {
                // insert new 
                case BaseBusinessEntity.RowStateEnum.NewRow:                   
                    long id = data.Insert(addressObject);
                    if (id > 0)
                    {
                        addressObject.ID = id;
                        return relationData.Add(parentID, id) > 0;
                    }
                    break;
                // update existing
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(addressObject) > 0;
                // delete existing (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    //TODO: delete the relations
                    if (data.Delete(addressObject.ID) > 0 && relationData != null)
                    {
                        return (relationData.Remove(parentID, addressObject.ID) > 0);
                    }
                    break;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }
        /// <summary>
        /// Update AddressList (list object)
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="list"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(AddressList list, BaseRelationData relationData, long parentID)
        {
            if (list != null)
            {
                bool success = false;
                // loop through each element in the address list
                foreach (Address address in list)
                {
                    success = Update(address, relationData, parentID);
                    if (!success)
                        return false;
                    // Communication details updates
                    if (address.CommDetailList != null && address.CommDetailList.Count > 0)
                    {
                        if (address.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                        {
                            foreach (CommDetail comm in address.CommDetailList)
                            {
                                comm.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                            }
                        }
                        CommDetailManager commDetailManager = new CommDetailManager(Transaction, UserContext);
                        Address_CommDetailData addr_commDetailData = new Address_CommDetailData(Transaction, UserContext);
                        success = commDetailManager.Update(address.CommDetailList, addr_commDetailData, address.ID);
                    }
                    if (!success)
                        return false;
                }
            }

            return true;
        }
        /// <summary>
        /// Retrieve addresses for a Person using personID
        /// 
        /// last updated on: 
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="personID"></param>
        /// <returns></returns>
        public AddressList GetAddressesByPersonID(long personID)
        {
            using (AddressData data = new AddressData(UserContext))
            {
                return (data.GetAddressesByPersonID(personID));
            }
        }
        /// <summary>
        /// Retrieves addresses associated with an Organization
        /// Data retrieval using Organization ID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public AddressList GetAddressesByOrganizationID(long organizationID)
        {
            using (AddressData data = new AddressData(UserContext))
            {
                AddressList myList = data.GetAddressesByOrganizationID(organizationID);
                foreach (Address item in myList)
                {
                    using (CommDetailManager commDetailManager = new CommDetailManager(UserContext))
                    {
                        item.CommDetailList = commDetailManager.GetCommDetailsByAddressID(item.ID);
                    }
                }
                return myList;
            }
        }
    }
}

