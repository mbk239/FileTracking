﻿using TSR.DataAccess;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class EntryRateManager : BaseManager
    {
        public EntryRateManager(UserContext context) : base(context)
        {
        }
        public EntryRateList GetAllEntryRate()
        {
            using (EntryRateData rateData = new EntryRateData(UserContext))
            {
                return rateData.GetAllEntryRate();
            }
        }
        public long Insert(EntryRate entryRateObject)
        {
            using (EntryRateData rateData = new EntryRateData(UserContext))
            {
                return rateData.Insert(entryRateObject);
            }
        }
    }
}
