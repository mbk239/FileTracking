using System;
using System.Data.SqlClient;
using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Collections.Generic;
using TSR.Framework.Resource;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Projects in TSR
    /// Projects are used for TSR Users to enter/report time on.  Projects are created in TSR web admin.  Users/User Groups are assigned to projects.
    /// In addition to assigning users to projects, each project contains various Activities.
    /// Time-Entry Approval rules are also set up in project component.
    /// 
    /// last updated on:
    /// august 30, 2009
    /// change description:
    /// </summary>
    public class ProjectManager : BaseManager
    {
        public ProjectManager(UserContext context) : base(context) { }
        public ProjectManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        /// <summary>
        /// Retrieve Project based on ID
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Project Get(long ID)
        {
            Project project;
            using (ProjectData data = new ProjectData(UserContext))
            {
                project = data.Get(ID);
            }
            GetSourceIDAndApplicationID(project);
            return project;
        }


        /// <summary>
        /// Get SourceID And ApplicationID
        /// </summary>
        /// <param name="organization"></param>
        private void GetSourceIDAndApplicationID(Project proj)
        {
            if (proj == null)
            {
                return;
            }
            using (DBRMappingTableData dbrData = new DBRMappingTableData(UserContext))
            {
                DBRMappingTable dbrObj = dbrData.GetByDestinationIDEntityTypeID(proj.ID.ToString(), (int)DBREntityTypeEnum.ENTITY_TYPE_PROJECT);
                if (dbrObj != null)
                {
                    proj.SourceID = dbrObj.SourceID;
                    proj.ApplicationID = dbrObj.ApplicationID;
                }
            }
        }

        /// <summary>
        /// Retrieve Deleted Project Base by ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Project GetDeleted(long ID)
        {
            Project project;
            using (ProjectData data = new ProjectData(UserContext))
            {
                project = data.GetDeleted(ID);
            }
            GetSourceIDAndApplicationID(project);
            return project;
        }
        /// <summary>
        /// Retrieve detail information for a project.
        /// Detail child data includes:
        /// 1. User Groups
        /// 2. Activities associated with a project
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="fillChild"></param>
        /// <returns></returns>
        public Project Get(long ID, bool fillChild)
        {
            Project project;
            using (ProjectData data = new ProjectData(UserContext))
            {
                project = data.Get(ID);
            }
            GetSourceIDAndApplicationID(project);
            // populate child data for a project (user groups and activites)
            if (fillChild)
            {
                // populate child data for a project (user groups and activites)
                FillProjectWithChilds(project, false);
            }

            return project;
        }
        public int GetRateTypeOfProject(long projectID)
        {
            int rateType = 0;
            using (ProjectData data = new ProjectData(UserContext))
            {
                rateType = data.GetRateTypeOfProject(projectID);
            }
            return rateType;
        }
        /// <summary>
        /// Retrieve list of all projects
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="fillChilds">if fillChilds is true it will populate the child entities of the projects</param>
        /// <returns></returns>
        public ProjectList GetAll(bool fillChilds)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetAll();
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, false);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        /// <summary>
        /// Retrieve list of all projects with condition 
        /// 
        /// last updated on:
        /// august 19, 2015
        /// change description:
        /// </summary>
        /// <param name="fillChilds">if fillChilds is true it will populate the child entities of the projects</param>
        /// <returns></returns>
        public ProjectList GetAllProjectPagingSorting(bool fillChilds, int pageSize, int startIndex,
            long organizationID, long projectManagerID, long projectTypeID,
            DateTime? startDate, DateTime? endDate, string name,
            string keyword, string sortExpression, out int total)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                string fieldOrder = string.Empty, sortOrder = string.Empty;
                GetSortParas(sortExpression, out fieldOrder, out sortOrder);

                projList = data.GetAllProjectPagingSorting(pageSize, startIndex, organizationID, projectManagerID, projectTypeID,
                                    startDate, endDate, name, keyword, fieldOrder, sortOrder, out total);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, false);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        public int GetAllProject_Total(long organizationID, long projectManagerID, long projectTypeID,
            DateTime? startDate, DateTime? endDate, string name, string keyword)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetAllProject_Total(organizationID, projectManagerID, projectTypeID, startDate, endDate, name, keyword);
            }
        }

        void GetSortParas(string sortExpression, out string fieldOrder, out string sortOrder)
        {
            fieldOrder = string.Empty;
            sortOrder = string.Empty;
            string[] str = sortExpression.Split(new char[] { ' ' });
            if (sortExpression.Length == 0 || str.Length == 0)
            {
                fieldOrder = Project.Property_Name;
                sortOrder = "ASC";
            }
            else if (str.Length == 1)
            {
                fieldOrder = str[0];
                sortOrder = "ASC";
            }
            else
            {
                fieldOrder = str[0];
                sortOrder = str[1];
            }
        }

        public ProjectList GetAll(long userID)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetAllForUser(userID);
            }
        }

        public ProjectList GetAllForReport()
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetAll();
            }
            return projList;
        }

        /// <summary>
        /// Retrieve list of all projects
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="fillChilds">if fillChilds is true it will populate the child entities of the projects</param>
        /// <returns></returns>
        public ProjectList GetAllDeleted()
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetAllDeleted();
                foreach (Project project in projList)
                {
                    GetSourceIDAndApplicationID(project);
                }
            }
            return projList;
        }
        /// <summary>
        /// Retrieve list of Projects View.
        /// Used for Project view search in TSR web application.        
        /// </summary>
        /// <returns></returns>
        public ProjectViewList GetAllProjectsView()
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetAllProjectsView();
            }
        }

        /// <summary>
        /// populates a project with its child entities [activity and usergroup]
        /// </summary>
        /// <param name="project"></param>
        public void FillProjectWithChilds(Project project, bool fillChilds)
        {
            // populate child data for a project (user groups and activites)
            if (project != null)
            {
                // Retrieve User Groups for the Project using ProjectID
                using (UserGroupManager userGroupManager = new UserGroupManager(UserContext))
                {
                    project.UserGroupList = userGroupManager.GetUserGroupsByProjectID(project.ID, fillChilds);
                }

                // Retrieve Activities for the Project using ProjectID
                using (ActivityManager activityManager = new ActivityManager(UserContext))
                {
                    project.ActivityList = activityManager.GetActivitiesByProjectID(project.ID);
                }

                ///Retrieve Default Approver User Group using Project Manager ID and Project ID
                using (UserGroupManager ugNamager = new UserGroupManager(UserContext))
                {
                    //UserGroup.IsSystemConfigurable is not set in current.
                    //project.DefaultApproverUserGroup = ugNamager.GetDefaultUserGroupByUserID_ProjectID(project.ProjectManagerID, project.ID);
                    project.DefaultApproverUserGroup = ugNamager.GetApproverGroupByProjectID(project.ID, fillChilds);
                }

                ProjectType type = GetProjectType(project.ProjectTypeID);
                if (type != null)
                    project.ProjectTypeName = type.Name;
            }
        }

        public void FillProjectWithChildsNonUserGroup(Project project)
        {
            // populate child data for a project (user groups and activites)
            if (project != null)
            {
                // Retrieve Activities for the Project using ProjectID
                using (ActivityManager activityManager = new ActivityManager(UserContext))
                {
                    project.ActivityList = activityManager.GetActivitiesByProjectID(project.ID);
                }
                ProjectType type = GetProjectType(project.ProjectTypeID);
                if (type != null)
                    project.ProjectTypeName = type.Name;
            }
        }

        /// <summary>
        /// Update base object for Project
        /// Data manipulation: insert, update, delete.
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="projectObject"></param>
        /// <returns></returns>
        public bool UpdateBase(Project projectObject)
        {
            if (projectObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Project tempProject;
                using (ProjectData projectData = new ProjectData(UserContext))
                {
                    tempProject = projectData.GetProjectByProjectName(projectObject.Name);
                }

                if (tempProject != null && tempProject.ID != projectObject.ID)
                {
                    // if the two projects in the same Organization are not the same name
                    if (tempProject.OrganizationID == projectObject.OrganizationID)
                    {
                        // handling of unique constraint violoation
                        string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                        throw new TSR.Framework.Exceptions.UniqueConstraintException(projectObject, new Exception(errorInfo));
                    }
                }
            }

            ProjectData data = new ProjectData(Transaction, UserContext);

            // use of switch statement for types of data manipulation
            switch (projectObject.RowState)
            {
                // new row insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(projectObject);
                    if (id > 0)
                    {
                        projectObject.ID = id;
                        return true;
                    }
                    break;
                // delete existing row
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(projectObject.ID) > 0;
                // update existing row
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return (data.Update(projectObject) > 0);
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }
            return false;
        }

        public bool  UpdateRateTypeOfProject(Project projectObject)
        {
            using (ProjectData projectData = new ProjectData(UserContext))
            {
                return projectData.UpdateRateTypeOfProject(projectObject) >0;
            }
        }

        /// <summary>
        /// Update base object for Project
        /// Data manipulation: insert, update, delete.
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="projectObject"></param>
        /// <returns></returns>
        public string UpdateBaseForImportProject(Project projectObject)
        {
            bool success = false;
            if (projectObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                using (ProjectData projectData = new ProjectData(UserContext))
                {
                    //tempProject = projectData.GetProjectsByOrganizationID(projectObject.Name);
                    ProjectList projList = projectData.GetProjectsByOrganizationID(projectObject.OrganizationID);
                    foreach (Project proj in projList)
                    {
                        if (proj.Name.Equals(projectObject.Name))
                        {
                            if (projectObject.RowState == BaseBusinessEntity.RowStateEnum.NewRow)
                            {
                                // handling of unique constraint violoation
                                //return  "Project with same name and same organization already exists.";
                                return ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "An object with the same name already exists");
                            }
                            else if (projectObject.RowState == BaseBusinessEntity.RowStateEnum.UpdatedRow && proj.ID != projectObject.ID)
                            {
                                // handling of unique constraint violoation
                                //return  "Project with same name and same organization already exists.";
                                return ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "An object with the same name already exists");
                            }
                        }
                    }
                }
            }

            ProjectData data = new ProjectData(Transaction, UserContext);

            string err = string.Empty;
            // use of switch statement for types of data manipulation
            switch (projectObject.RowState)
            {
                // new row insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = 0;
                    err = data.InsertForImport(projectObject, out id);
                    if (id > 0)
                    {
                        projectObject.ID = id;
                        success = true;
                    }
                    break;
                // delete existing row
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    success = data.Delete(projectObject.ID) > 0;
                    break;
                // update existing row
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    err = data.UpdateForImport(projectObject);
                    break;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    success = true;
                    break;
            }
            return err;
        }
        /// <summary>
        /// Update ProjectType Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="projectTypeObject"></param>
        /// <returns></returns>
        public bool Update(ProjectType projectTypeObject)
        {

            if (projectTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                ProjectType tempProjectType;
                using (ProjectTypeData projectTypeData = new ProjectTypeData(UserContext))
                {
                    tempProjectType = projectTypeData.GetProjectTypeByProjectTypeName(projectTypeObject.Name);
                }

                if (tempProjectType != null && tempProjectType.ID != projectTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(projectTypeObject, new Exception(errorInfo));
                }
            }

            ProjectTypeData data = new ProjectTypeData(UserContext);

            // use of switch for different types of DML
            switch (projectTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to projectTypeObject
                    long id = data.Insert(projectTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        projectTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(projectTypeObject.ID) > 0);
            }
            // update rows
            return (data.Update(projectTypeObject) > 0);
        }


        /// <summary>
        /// Update project object and child data (user groups and activities)
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="projectObject"></param>
        /// <returns></returns>
        public bool Update(Project projectObject)
        {
            bool success = false;

            success = UpdateBase(projectObject);

            // User groups for the project
            if (success && projectObject.UserGroupList != null && projectObject.UserGroupList.Count > 0)
            {
                //if (projectObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                //{
                //    foreach (UserGroup grp in projectObject.UserGroupList)
                //    {
                //        grp.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                //    }
                //}
                UserGroupManager userGroupManager = new UserGroupManager(Transaction, UserContext);
                Project_UserGroupData project_UserGroupData = new Project_UserGroupData(Transaction, UserContext);
                success = userGroupManager.AssignUserGroup(projectObject.UserGroupList, project_UserGroupData, projectObject.ID);
            }

            // Activities for the project
            if (success && projectObject.ActivityList != null && projectObject.ActivityList.Count > 0)
            {
                //if (projectObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                //{
                //    foreach (Activity act in projectObject.ActivityList)
                //    {
                //        act.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                //    }
                //}
                ActivityManager activityManager = new ActivityManager(Transaction, UserContext);
                Project_ActivityData project_ActivityData = new Project_ActivityData(Transaction, UserContext);
                success = activityManager.AssignActivity(projectObject.ActivityList, project_ActivityData, projectObject.ID);
            }

            ///Default Approver User Group for the project
            if (success && projectObject.DefaultApproverUserGroup != null)
            {
                //if (projectObject.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                //{
                //    projectObject.DefaultApproverUserGroup.RowState = BaseBusinessEntity.RowStateEnum.DeletedRow;
                //}
                UserGroupManager userGroupManager = new UserGroupManager(Transaction, UserContext);
                Project_UserGroupData project_UserGroupData = new Project_UserGroupData(Transaction, UserContext);

                if (projectObject.DefaultApproverUserGroup.RowState == BaseBusinessEntity.RowStateEnum.UpdatedRow)
                {
                    projectObject.DefaultApproverUserGroup.RowState = BaseBusinessEntity.RowStateEnum.NewRow;
                    success = userGroupManager.AssignUserGroup(projectObject.DefaultApproverUserGroup, project_UserGroupData, projectObject.ID);
                    projectObject.DefaultApproverUserGroup.RowState = BaseBusinessEntity.RowStateEnum.UpdatedRow;
                }
                else if (projectObject.DefaultApproverUserGroup.RowState == BaseBusinessEntity.RowStateEnum.DeletedRow)
                {
                    success = userGroupManager.AssignUserGroup(projectObject.DefaultApproverUserGroup, project_UserGroupData, projectObject.ID);
                }
            }

            return success;
        }
        /// <summary>
        /// Retrieve Projects for an Organization using organizationID
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public ProjectList GetProjectsByOrganizationID(long organizationID, bool fillChilds)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetProjectsByOrganizationID(organizationID);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, fillChilds);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        public ProjectList GetProjectsForOrganization_PagingSorting(long organizationID, int pageSize, int startIndex, string sortExpression, out int total)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                string fieldOrder = string.Empty, sortOrder = string.Empty;
                GetSortParas(sortExpression, out fieldOrder, out sortOrder);

                return data.GetProjectsForOrganization_PagingSorting(organizationID, pageSize, startIndex, fieldOrder, sortOrder, out total);
            }
        }

        public ProjectList GetProjectsForReport(long organizationID, long projectTypeID)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetProjectsForReport(organizationID, projectTypeID);
            }
            return projList;
        }
        //added by tsrdev
        /// <summary>
        /// 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="fillChilds"></param>
        /// <returns></returns>
        public ProjectList GetProjectsByOrganizationIDNonUserGroup(long organizationID, long userId, bool fillChilds)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetProjectsByOrganizationAndUser(organizationID, userId);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChildsNonUserGroup(project);
                        //GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }


        //added by tsrdev2
        /// <summary>
        /// Get projects by user has userID that he is project manager
        /// or in approver group
        /// or in a user group attached to the project
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public ProjectList GetProjectsByUserID(Int64 userID, bool fillChilds)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetProjectsByUserID(userID);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, fillChilds);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        public ProjectList GetProjectsByUserIDPagingSorting(Int64 userID, bool fillChilds, int pageSize, int startIndex,
            long organizationID, long projectManagerID, long projectTypeID,
            DateTime? startDate, DateTime? endDate, string name,
            string keyword, string sortExpression, out int total)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                string fieldOrder = string.Empty, sortOrder = string.Empty;
                GetSortParas(sortExpression, out fieldOrder, out sortOrder);

                projList = data.GetProjectsByUserIDPagingSorting(userID, pageSize, startIndex, organizationID,
                            projectManagerID, projectTypeID, startDate, endDate, name, keyword, fieldOrder, sortOrder, out total);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, fillChilds);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        //added by tsrdev2
        /// <summary>
        /// Get projects by organization and user has userID that he is project manager
        /// or in approver group
        /// or in a user group attached to the project
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="userID"></param>
        /// <param name="fillChilds"></param>
        /// <returns></returns>
        public ProjectList GetProjectsForOrganization_OnlyShowOwnProject(long organizationID, long userID, bool fillChilds)
        {
            ProjectList projList = new ProjectList();
            using (ProjectData data = new ProjectData(UserContext))
            {
                projList = data.GetProjectsForOrganization_OnlyShowOwnProject(organizationID, userID);
                if (fillChilds)
                {
                    foreach (Project project in projList)
                    {
                        // populate child data for a project (user groups and activites)
                        FillProjectWithChilds(project, fillChilds);
                        GetSourceIDAndApplicationID(project);
                    }
                }
            }
            return projList;
        }

        public ProjectList GetProjectsByActivityID(long actID)
        {
            ProjectList listAll = new ProjectList();
            ProjectList projList = new ProjectList();
            //using (ProjectData data = new ProjectData(UserContext))
            //{
            listAll = GetAll(true);
            foreach (Project obj in listAll)
            {
                if (obj.ActivityList != null && obj.ActivityList.Count > 0)
                {
                    if (obj.ActivityList.FindByID(actID) != null)
                    {
                        projList.Add(obj);
                    }
                }
                GetSourceIDAndApplicationID(obj);
            }
            //}
            return projList;
        }

        ///// <summary>
        ///// Retrieves list of projects that contains at least one usergroup from the given list
        ///// </summary>
        ///// <param name="UserGroupIDs">list of usergroup ids</param>
        ///// <returns></returns>
        //public ProjectList GetProjectsForUserGroups(List<long> UserGroupIDs)
        //{
        //    ProjectList projList = GetAll(true);
        //    ProjectList projForUserGroups = new ProjectList();
        //    foreach (Project project in projList)
        //    {
        //        if (project.UserGroupList != null)
        //        {
        //            foreach (UserGroup usergroup in project.UserGroupList)
        //            {
        //                if (UserGroupIDs.Contains(usergroup.ID))
        //                {
        //                    projForUserGroups.Add(project);
        //                    //if the project has at least one usergroup from the given list, 
        //                    //it is suffice to add the project in list
        //                    break;
        //                }
        //            }
        //        }
        //    }
        //    return projForUserGroups;
        //}

        public bool Delete(long ID, bool withChild)
        {
            using (PersonData data = new PersonData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Retrieve ALL project types (example: internal, sales, etc.)
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public ProjectTypeList GetAllProjectTypes()
        {
            using (ProjectTypeData projectTypeData = new ProjectTypeData(UserContext))
            {
                return projectTypeData.GetAll();
            }
        }
        /// <summary>
        /// Retrieve project types (example: internal, sales, etc.)
        /// 
        /// last updated on:
        /// august 30, 2009
        /// change description:
        /// </summary>
        /// <param name="projectTypeId"></param>
        /// <returns></returns>
        public ProjectType GetProjectType(long projectTypeId)
        {
            using (ProjectTypeData projectTypeData = new ProjectTypeData(UserContext))
            {
                return projectTypeData.Get(projectTypeId);
            }
        }

        /// <summary>
        /// Get projects by user who is project manager
        /// (added by tsrdev - feature 229)
        /// </summary>
        /// <param name="userID">Project manager id</param>
        /// <returns></returns>
        public ProjectList GetProjectsByProjectManager(long userID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectsByProjectManager(userID);
            }
        }

        public ProjectList GetProjectsHasProjectManagerIsLossRight(long roleID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectsHasProjectManagerIsLossRight(roleID);
            }
        }

        public bool UserGroupIsApproverGroup(long approverGroupID)
        {
            using (Project_ApproverGroupData data = new Project_ApproverGroupData(Transaction, UserContext))
            {
                return data.UserGroupIsApproverGroup(approverGroupID);
            }
        }

        public ProjectList GetProjectsForPersonalReport(long? userID, long? orgID, long? projectTypeID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectsForUserInUserGroupList(userID, orgID, projectTypeID);
            }
        }

        public ProjectList GetProjectPaging(int startOffset, int numberOfItems, long orgID, long projTypeID, string text, out int total)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectPaging(startOffset, numberOfItems, orgID, projTypeID, text, out total);
            }
        }

        public ProjectList GetProjectByUserPaging(long userId, int startOffset, int numberOfItems, long orgID, long projTypeID, string text, out int total)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectByUserPaging(userId, startOffset, numberOfItems, orgID, projTypeID, text, out total);
            }
        }

        public ProjectTypeList GetProjectTypePaging(int startOffset, int numberOfItems, string name, out int total)
        {
            using (ProjectTypeData data = new ProjectTypeData(UserContext))
            {
                return data.GetProjectTypePaging(startOffset, numberOfItems, name, out total);
            }
        }

        public ProjectList GetProjectsByUserGroupID(long userGroupID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectsByUserGroupID(userGroupID);
            }
        }

        public bool IsUserGroupInProjects(long userGroupId)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.IsUserGroupInProjects(userGroupId);
            }
        }

        public bool UpdateModifiedTimeStampOnProjects(long usergroupID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.UpdateModifiedTimeStampOnProjects(usergroupID);
            }
        }

        public ProjectList GetProjectForPaging(int startOffset, int numberOfItems, long orgID, string text, out int totalRecords)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetProjectForPaging(startOffset, numberOfItems, orgID, text, out totalRecords);
            }
        }

        public ProjectList GetAllProjectForExport(long organizationID, long projectTypeID)
        {
            using (ProjectData data = new ProjectData(UserContext))
            {
                return data.GetAllProjectsForExport(organizationID, projectTypeID);
            }
        }

        public Project_UserGroup_ActivitiesList GetProject_UserGroup_Activities(long projectID, long userGroupID)
        {
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                return data.Get(projectID, userGroupID, -1);
            }
        }

        public Project_UserGroup_ActivitiesList GetProject_UserGroup_Activities_ByUserID(long? projectID, long userID)
        {
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                return data.GetByUserID(projectID, userID);
            }
        }

        public bool UpdateProject_UserGroup_Activities(long projectID, long userGroupID, long activityID)
        {
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                if (data.Get(projectID, userGroupID, activityID).Count > 0)
                    return data.Add(projectID, userGroupID, activityID) > 0;
                else return true;
            }
        }

        public bool UpdateProject_UserGroup_ActivitiesForDBRImport(long projectID, long userGroupID, long activityID)
        {
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                //remove all activities of project and usergroup before add new one via DBR Importing
                if (data.Remove(projectID, userGroupID, -1) > 0)
                {
                    return data.Add(projectID, userGroupID, activityID) > 0;
                }
                else return false;
            }
        }

        public bool UpdateProject_UserGroup_ActivitiesForDBRImport(long projectID, long userGroupID, List<long> lstActivityID)
        {
            bool success = true;
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                //remove all activities of project and usergroup before add new one via DBR Importing
                data.Remove(projectID, userGroupID, -1);

                foreach (long activityID in lstActivityID)
                {
                    success = data.Add(projectID, userGroupID, activityID) > 0;
                    if (!success)
                        break;
                }
            }
            return success;
        }

        public bool UpdateProject_UserGroup_ActivitiesForProject(long projectID, List<Project_UserGroup_Activities> lst)
        {
            bool success = true;
            //if (lst.Count == 0) return success;

            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                //remove all linked data of the project before adding new ones
                data.Remove(projectID, -1, -1);

                if (lst.Count > 0)
                {
                    foreach (Project_UserGroup_Activities pua in lst)
                    {
                        success = data.Add(pua.ProjectID, pua.UserGroupID, pua.ActivityID) > 0;
                        if (!success)
                            break;
                    }
                }
            }

            return success;
        }

        public Project_UserGroupList GetProject_UserGroupByUserID_ProjectID(long userID, long projectID)
        {
            using (Project_UserGroupData data = new Project_UserGroupData(Transaction, UserContext))
            {
                return data.GetProject_UserGroupByUserID_ProjectID(userID, projectID);
            }
        }

        public Project_UserGroup_ActivitiesList Project_UserGroup_Activities_GetByUserID(long? projectID, long userID)
        {
            using (Project_UserGroup_ActivitiesData data = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                return data.GetByUserID(projectID, userID);
            }
        }
    }
}

