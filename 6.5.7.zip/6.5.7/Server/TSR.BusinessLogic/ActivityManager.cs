using System;
using System.Data.SqlClient;
using System.Linq;
using TSR.Framework;
using TSR.Entities;
using TSR.DataAccess;
using System.Collections.Generic;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for Activities.
    /// Activities are set of actions which complete a project.  
    /// In standard project management, activities are created as part of work breakdown structure (WBS) to decompose a project into smaller work components such as activities and tasks.  
    /// 
    /// last updated on:
    /// august 31, 2009
    /// change description:
    /// 
    /// </summary>
    public class ActivityManager : BaseManager
    {
        public ActivityManager(UserContext context) : base(context) { }
        public ActivityManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }
        /// <summary>
        /// Retrieve Activity data using unique ID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Activity Get(long ID)
        {
            Activity activity;
            using (ActivityData data = new ActivityData(UserContext))
            {
                activity = data.Get(ID);
            }

            GetSourceIDAndApplicationID(activity);
            return activity;
        }

        public Activity Get(long ID, bool fillChilds)
        {
            Activity activity;
            using (ActivityData data = new ActivityData(UserContext))
            {
                activity = data.Get(ID);

                if (fillChilds)
                {
                    GetSourceIDAndApplicationID(activity);
                    //
                    ActivityType type = GetActivityType(activity.ActivityTypeID);
                    if (type != null)
                        activity.ActivityTypeName = type.Name;
                }
            }
            return activity;
        }

        private void GetSourceIDAndApplicationID(Activity activity)
        {
            if (activity == null)
            {
                return;
            }
            using (DBRMappingTableData dbrData = new DBRMappingTableData(UserContext))
            {
                DBRMappingTable dbrObj = dbrData.GetByDestinationIDEntityTypeID(activity.ID.ToString(), (int)DBREntityTypeEnum.ENTITY_TYPE_ACTIVITY);
                if (dbrObj != null)
                {
                    activity.SourceID = dbrObj.SourceID;
                    activity.ApplicationID = dbrObj.ApplicationID;
                }
            }
        }

        /// <summary>
        /// Retrieve deleted activity by ID
        /// added by tsrdev2
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public Activity GetDeleted(long ID)
        {
            Activity activity;
            using (ActivityData data = new ActivityData(UserContext))
            {
                activity = data.GetDeleted(ID);
            }
            GetSourceIDAndApplicationID(activity);
            return activity;
        }
        /// <summary>
        /// Retrieve list of ALL Activities.
        /// no parameters required to be passed in.
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public ActivityList GetAll()
        {
            return GetAll(true);
        }

        public ActivityList GetAll(bool fillChild)
        {
            ActivityList activityList = new ActivityList();
            using (ActivityData data = new ActivityData(UserContext))
            {
                activityList = data.GetAll();
                if (fillChild)
                {
                    foreach (Activity activity in activityList)
                    {
                        GetSourceIDAndApplicationID(activity);
                    }
                }
            }
            return activityList;
        }

        /// <summary>
        /// Retrieve list of ALL Deleted Activities.        
        /// </summary>
        /// <returns></returns>
        public ActivityList GetAllDeleted()
        {
            ActivityList activityList = new ActivityList();
            using (ActivityData data = new ActivityData(UserContext))
            {
                activityList = data.GetAllDeleted();
            }
            foreach (Activity activity in activityList)
            {
                GetSourceIDAndApplicationID(activity);
            }
            return activityList;
        }

        /// <summary>
        /// Retrieve Activities for a Project using projectID
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="projectID"></param>
        /// <returns></returns>
        public ActivityList GetActivitiesByProjectID(long projectID)
        {
            ActivityList activityList = new ActivityList();
            using (ActivityData data = new ActivityData(UserContext))
            {
                activityList = data.GetActivitiesByProjectID(projectID);
            }
            foreach (Activity activity in activityList)
            {
                GetSourceIDAndApplicationID(activity);

                //get activity type name for the activity
                ActivityType type = GetActivityType(activity.ActivityTypeID);
                if (type != null)
                    activity.ActivityTypeName = type.Name;
            }
            return activityList;
        }

        public ActivityList GetActivitiesByActivityTypeID(long activityTypeID)
        {
            ActivityList activityList = new ActivityList();
            using (ActivityData data = new ActivityData(UserContext))
            {
                activityList = data.GetActivitiesByActivityType(activityTypeID);
            }
            foreach (Activity activity in activityList)
            {
                GetSourceIDAndApplicationID(activity);
            }
            return activityList;
        }

        public Activity GetActivityByActivityName(string ActivityName)
        {
            using (ActivityData data = new ActivityData(UserContext))
            {
                return data.GetActivityByActivityName(ActivityName);
            }
        }

        /// <summary>
        /// Retrieve all Activity Types
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <returns></returns>
        public ActivityTypeList GetAllActivityTypes()
        {
            using (ActivityTypeData Data = new ActivityTypeData(UserContext))
            {
                return Data.GetAll();
            }
        }
        /// <summary>
        /// Retrieve all Activity views
        /// 
        /// last updated on:
        /// March 11, 2010        
        /// </summary>
        /// <returns>ActivityViewList</returns>
        public ActivityViewList GetAllActivitiesView()
        {
            using (ActivityData data = new ActivityData(UserContext))
            {
                return data.GetAllActivitiesView();
            }
        }

        /// <summary>
        /// Retrieve ActivityType data using unique ID
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public ActivityType GetActivityType(long ID)
        {
            using (ActivityTypeData data = new ActivityTypeData(UserContext))
            {
                return data.Get(ID);
            }
        }

        /// <summary>
        /// Insert new activity.
        /// data manipulation for insertion of Activities
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="activityObject"></param>
        /// <returns></returns>
        public bool Insert(Activity activityObject)
        {
            // new activity
            using (ActivityData data = new ActivityData(UserContext))
            {
                // insert to activityObject
                long id = data.Insert(activityObject);
                // if successful, process
                if (id > 0)
                {
                    activityObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }

        public string InsertForDBRImport(Activity activityObject)
        {
            string error = string.Empty;
            // new activity
            using (ActivityData data = new ActivityData(UserContext))
            {
                // insert to activityObject
                long id = data.InsertForDBRImport(activityObject, out error);
                // if successful, process
                if (id > 0)
                {
                    activityObject.ID = id;
                }
            }
            return error;
        }
        /// <summary>
        /// Delete operation for Activities
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool Delete(long ID)
        {
            using (ActivityData data = new ActivityData(UserContext))
            {
                // return if code > 0
                return (data.Delete(ID) > 0);
            }
        }
        /// <summary>
        /// Update Activity Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="activityObject"></param>
        /// <returns></returns>
        public bool Update(Activity activityObject)
        {
            if (activityObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Activity tempActivity;
                using (ActivityData activityData = new ActivityData(UserContext))
                {
                    tempActivity = activityData.GetActivityByActivityName(activityObject.Name);
                }

                if (tempActivity != null && tempActivity.ID != activityObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    //throw new TSR.Framework.Exceptions.UniqueConstraintException(activityObject, new Exception(ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE));
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(activityObject, new Exception(errorInfo));
                }
            }

            // use of switch for different types of DML
            switch (activityObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    return Insert(activityObject);
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return Delete(activityObject.ID);
            }
            // update rows
            using (ActivityData data = new ActivityData(UserContext))
            {
                return (data.Update(activityObject) > 0);
            }
        }
        public string UpdateForDBRImport(Activity activityObject)
        {
            string error = string.Empty;
            if (activityObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Activity tempActivity;
                using (ActivityData activityData = new ActivityData(UserContext))
                {
                    tempActivity = activityData.GetActivityByActivityName(activityObject.Name);
                }

                if (tempActivity != null && tempActivity.ID != activityObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    //return ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE;
                    return errorInfo;
                }
            }

            // use of switch for different types of DML
            switch (activityObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    return InsertForDBRImport(activityObject);
            }
            // update rows
            using (ActivityData data = new ActivityData(UserContext))
            {
                data.UpdateForDBRImport(activityObject, out error);
                return error;
            }
        }

        /// <summary>
        /// Update ActivityType Object.
        /// Data manipulation processing for: new, deleted, updated activities
        /// 
        /// last updated on:
        /// September 03, 2009
        /// change description:
        /// </summary>
        /// <param name="activityObject"></param>
        /// <returns></returns>
        public bool Update(ActivityType activityTypeObject)
        {

            if (activityTypeObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                ActivityType tempActivityType;
                using (ActivityTypeData activityTypeData = new ActivityTypeData(UserContext))
                {
                    tempActivityType = activityTypeData.GetActivityTypeByActivityTypeName(activityTypeObject.Name);
                }

                if (tempActivityType != null && tempActivityType.ID != activityTypeObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    //throw new TSR.Framework.Exceptions.UniqueConstraintException(activityTypeObject, new Exception(ConstantCollection.UNIQUE_CONSTRAINT_EXCEPTION_MESSAGE));
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(activityTypeObject, new Exception(errorInfo));
                }
            }

            ActivityTypeData data = new ActivityTypeData(UserContext);

            // use of switch for different types of DML
            switch (activityTypeObject.RowState)
            {
                // insert / new rows
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    // insert to activityObject
                    long id = data.Insert(activityTypeObject);
                    // if successful, process
                    if (id > 0)
                    {
                        activityTypeObject.ID = id;
                        return true;
                    }
                    else
                        return false;
                // delete rows
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return (data.Delete(activityTypeObject.ID) > 0);
            }
            // update rows
            return (data.Update(activityTypeObject) > 0);
        }

        /// <summary>
        /// Update Activity data 
        /// </summary>
        /// <param name="activityObject"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(Activity activityObject, BaseRelationData relationData, long parentID)
        {
            ActivityData data = new ActivityData(Transaction, UserContext);
            switch (activityObject.RowState)
            {
                // new row / insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(activityObject);
                    if (id > 0)
                    {
                        activityObject.ID = id;
                        return relationData.Add(parentID, id) > 0;
                    }
                    break;
                // updates to a row
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(activityObject) > 0;
                // row delete
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(activityObject.ID) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }
            return false;
        }
        /// <summary>
        /// Update list object: ActivityList
        /// Loop through the list for update of each row.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="list"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool Update(ActivityList list, BaseRelationData relationData, long parentID)
        {
            // check to see if the list is null
            if (list != null)
            {
                // loop through the list for each activity and perform operation for each item
                foreach (Activity activity in list)
                {
                    if (Update(activity, relationData, parentID) == false)
                        return false;
                }
            }

            return true;
        }
        /// <summary>
        /// Activity Assignment to projects: activityList
        /// Used for activity assignments to projects.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="activityList"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignActivity(ActivityList activityList, BaseRelationData relationData, long parentID)
        {
            foreach (Activity activity in activityList)
            {
                if (!AssignActivity(activity, relationData, parentID))
                    return false;
            }
            return true;
        }
        /// <summary>
        /// Activity Assignment to projects: activityList
        /// Used for activity assignments to projects.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="activityList"></param>        
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignActivity(ActivityList activityList, long parentID)
        {
            Project_ActivityData relationData = new Project_ActivityData(Transaction, UserContext);
            foreach (Activity activity in activityList)
            {
                if (!AssignActivity(activity, relationData, parentID))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Activity assignment to projects: Activity data
        /// Allows add and remove during assignment.
        /// 
        /// last updated on:
        /// august 31, 2009
        /// change description:
        /// </summary>
        /// <param name="activity"></param>
        /// <param name="relationData"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AssignActivity(Activity activity, BaseRelationData relationData, long parentID)
        {
            switch (activity.RowState)
            {
                // new row assignment
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    if (relationData.Add(parentID, activity.ID) <= 0)
                        return false;
                    break;
                // delete row from assignment
                case BaseBusinessEntity.RowStateEnum.DeletedRow:

                    if (relationData.Remove(parentID, activity.ID) <= 0)
                        return false;
                    break;
            }
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool RemoveAllActivity(long parentID)
        {
            Project_ActivityData data = new Project_ActivityData(Transaction, UserContext);
            return (data.DeleteByProjectID(parentID) > 0);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="organizationID"></param>
        /// <param name="projectID"></param>
        /// <param name="projectTypeID"></param>
        /// <param name="activityTypeID"></param>
        /// <returns></returns>
        public ActivityList GetActivityForPersonalReport(long? userID, long? organizationID, long? projectID, long? projectTypeID, long? activityTypeID)
        {
            using (ActivityData data = new ActivityData(UserContext))
            {
                return data.GetActivitiesForUserInProjects(userID, organizationID, projectID, projectTypeID, activityTypeID);
            }
        }

        public ActivityTypeList GetActivityTypePaging(int startOffset, int numberOfItems, string name, out int total)
        {
            using (ActivityTypeData data = new ActivityTypeData(UserContext))
            {
                return data.GetActivityTypePaging(startOffset, numberOfItems, name, out total);
            }
        }

        public ActivityList GetActivityPaging(int startOffset, int numberOfItems, long userID, long projID, long actTypeID, string name, out int total)
        {
            ActivityList lst = new ActivityList();
            ActivityList lstResult = new ActivityList();

            using (ActivityData data = new ActivityData(UserContext))
            {
                lst = data.GetActivityPaging(startOffset, numberOfItems, projID, actTypeID, name, out total);
            }
            if (numberOfItems == ConstantCollection.LOADING_COUNT_ITEMS_5000 && userID > 0)
            {
                if (lst.Count > 0)
                {
                    Project_UserGroup_ActivitiesList lstPUA = new Project_UserGroup_ActivitiesList();
                    Project_UserGroupList lstPU = new Project_UserGroupList();

                    using (ProjectManager projectManager = new ProjectManager(UserContext))
                    {
                        lstPUA = projectManager.GetProject_UserGroup_Activities_ByUserID(projID, userID);
                        if (lstPUA.Count > 0)
                        {
                            lstPU = projectManager.GetProject_UserGroupByUserID_ProjectID(userID, projID);
                            foreach (Project_UserGroup pu in lstPU)
                            {
                                 IEnumerable<Project_UserGroup_Activities> rs = lstPUA.Where(pua => pua.UserGroupID == pu.UserGroupID);
                                 if (rs.Count() > 0)
                                 {
                                     foreach (Project_UserGroup_Activities r in rs)
                                     {
                                         Activity act = lst.FirstOrDefault(a => a.ID == r.ActivityID);
                                         if (act != null && act.ID > 0)
                                         {
                                             Activity existedAct = lstResult.FirstOrDefault(a => a.ID == act.ID);
                                             if (existedAct == null || existedAct.ID < 1)
                                                 lstResult.Add(act);
                                         }
                                     }
                                 }
                                 else
                                 {
                                     return lst;
                                 }
                            }
                        }
                    }
                }
            }
            if (lstResult.Count > 0) 
                return lstResult;
            return lst;
        }

        public ActivityList GetAllActivityForExport(long actTypeId)
        {
            using (ActivityData data = new ActivityData(UserContext))
            {
                return data.GetAllActivityForExport(actTypeId);
            }
        }

        public bool AssignActivity(ActivityList activityList, long projectID, long userGroupID)
        {
            using (Project_UserGroup_ActivitiesData relationData = new Project_UserGroup_ActivitiesData(Transaction, UserContext))
            {
                foreach (Activity activity in activityList)
                {
                    switch (activity.RowState)
                    {
                        // new row assignment
                        case BaseBusinessEntity.RowStateEnum.NewRow:
                            if (relationData.Add(projectID, userGroupID, activity.ID) <= 0)
                                return false;
                            break;
                        // delete row from assignment
                        case BaseBusinessEntity.RowStateEnum.DeletedRow:

                            if (relationData.Remove(projectID, userGroupID, activity.ID) <= 0)
                                return false;
                            break;
                    }
                    return false;
                }
            }
            return true;
        }
    }
}

