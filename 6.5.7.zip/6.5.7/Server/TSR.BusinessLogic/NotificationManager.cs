﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TSR.Framework;
using System.Data.SqlClient;
using TSR.Entities;
using TSR.DataAccess;
using TSR.Entities.Lists;

namespace TSR.BusinessLogic
{
    /// <summary>
    /// Business logic processing for TSR Notification.
    /// Logic for:
    /// 1. Retrieving list of Notifications
    /// 2. Retrieving details of an Notification
    /// 3. Data manipulation (CRUD) for Notification: base and details
    /// 
    /// Last updated on:
    /// Change description:
    /// </summary>
    public class NotificationManager : BaseManager
    {
        #region Constructors

        public NotificationManager(UserContext context) : base(context) { }
        public NotificationManager(SqlTransaction transaction, UserContext context) : base(transaction, context) { }

        #endregion
        

       /// <summary>
        /// retrieves a single Notification object depending on its ID, populating child entities are optional
       /// </summary>
        /// <param name="ID">id of Notification object to be retrieved</param>
       /// <param name="FillChilds">whether to populate child entities or not, boolean value</param>
       /// <returns></returns>
        public Notification Get(long ID, bool FillChilds)
        {
            Notification notification;
            using (NotificationData data = new NotificationData(UserContext))
            {
                notification = data.Get(ID);
            }

            if (FillChilds && (notification != null))
            {
                // Retrieve list of Notifications for the Notification.
                using (NotificationFieldData notificationData = new NotificationFieldData(UserContext))
                {
                    notification.UserNotificationFields = notificationData.GetAll(notification.ID);
                }
            }

            if (FillChilds && (notification != null))
            {
                // Retrieve User information for the Notification.
                using (UserManager userManager = new UserManager(UserContext))
                {
                    notification.NotifyUser = userManager.Get(notification.UserID, true);
                }
            }

            return notification;
        }

        public Notification GetNotificationForApprover(Int64 UserID, DateTime StartDate, DateTime EndDate)
        {
            Notification notification;
            using (NotificationData data = new NotificationData(UserContext))
            {
                notification = data.GetNotificationForApprover(UserID, StartDate, EndDate.AddDays(1));
            }
            return notification;
        }

        //public Notification
        /// <summary>
        /// retrieves all NotificationFields
        /// </summary>
        /// <returns></returns>
        public NotificationFieldList GetAllNotificationField()
        {
            using (NotificationFieldData data = new NotificationFieldData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// retrieves all TemplateMappingTableList
        /// </summary>
        /// <returns></returns>
        public TemplateMappingTableList GetAllTemplateMappingTable()
        {
            using (TemplateMappingTableData data = new TemplateMappingTableData(UserContext))
            {
                return data.GetAll();
            }
        }

        /// <summary>
        /// retrieves Notification object by ID
        /// </summary>
        /// <param name="ID">ID of Notification object</param>
        /// <returns></returns>
        public NotificationField GetNotificationFieldByID(long ID)
        {
            using (NotificationFieldData data = new NotificationFieldData(UserContext))
            {
                return data.Get(ID);
            }
        }


        /// <summary>
        /// retrieves all Notifications from database
        /// </summary>
        /// <returns></returns>
        public NotificationList GetAllNotification()
        {
            using (NotificationData data = new NotificationData(UserContext))
            {
                return data.GetAll();
            }
        }


       /// <summary>
        /// update method for a single NotificationField object
       /// </summary>
       /// <param name="notificationFieldObject"></param>
       /// <returns></returns>
        private bool UpdateBase(NotificationField notificationFieldObject)
        {
            NotificationFieldData data = new NotificationFieldData(Transaction, UserContext);

            switch (notificationFieldObject.RowState)
            {   // Notification insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(notificationFieldObject);
                    if (id > 0)
                    {
                        notificationFieldObject.ID = id;
                        return true;
                    }
                    break;
                // Notification delete (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(notificationFieldObject.ID) > 0;
                // Notification update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(notificationFieldObject) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }


        /// <summary>
        /// update method for a single TemplateMappingTable object
        /// </summary>
        /// <param name="templateMappingTableObject"></param>
        /// <returns></returns>
        private bool UpdateBase(TemplateMappingTable templateMappingTableObject)
        {
            TemplateMappingTableData data = new TemplateMappingTableData(Transaction, UserContext);

            switch (templateMappingTableObject.RowState)
            {   // TemplateMappingTable insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(templateMappingTableObject);
                    if (id > 0)
                    {
                        templateMappingTableObject.ID = id;
                        return true;
                    }
                    break;
                // TemplateMappingTable delete (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(templateMappingTableObject.ID) > 0;
                // TemplateMappingTable update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(templateMappingTableObject) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }

        /// <summary>
        /// update method single Notification object. no child entities [if exists or added later] will be considered
        /// </summary>
        /// <param name="notificationObject">Notification object to be updated</param>
        /// <returns></returns>
        private bool UpdateBase(Notification notificationObject)
        {
            if (notificationObject.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                Notification tempNotification;
                using (NotificationData notificationData = new NotificationData(UserContext))
                {
                    tempNotification = notificationData.GetNotificationByNotificationName(notificationObject.Name);
                }

                if (tempNotification != null && tempNotification.ID != notificationObject.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(notificationObject, new Exception(errorInfo));
                }
            }
            NotificationData data = new NotificationData(Transaction, UserContext);

            switch (notificationObject.RowState)
            {   // Notification insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(notificationObject);
                    if (id > 0)
                    {
                        notificationObject.ID = id;
                        return true;
                    }
                    break;
                // Notification delete (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(notificationObject.ID) > 0;
                // Notification update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(notificationObject) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }

        /// <summary>
        /// update method for single Notification object
        /// </summary>
        /// <param name="notificationObject"></param>
        /// <returns></returns>
        public bool Update(Notification notificationObject)
        {
            bool success = false;

            success = UpdateBase(notificationObject);
            // Notification Field updates
            if (success && notificationObject.UserNotificationFields != null && notificationObject.UserNotificationFields.Count > 0)
            {
                NotificationFieldData notificationData = new NotificationFieldData(Transaction, UserContext);
                success = Update(notificationObject.UserNotificationFields, notificationObject.ID);
            }

            return success;
        }

        /// <summary>
        /// update method for single TemplateMappingTable object
        /// </summary>
        /// <param name="templateMappingTableObject"></param>
        /// <returns></returns>
        public bool Update(TemplateMappingTable templateMappingTableObject)
        {
            bool success = false;

            success = UpdateBase(templateMappingTableObject);

            return success;
        }


        public bool Update(TemplateMappingTableList templateMappingTableList)
        {
            bool success = false;
            foreach (TemplateMappingTable templateMappingTableObject in templateMappingTableList)
            {
                success = UpdateBase(templateMappingTableObject);
                if (!success)
                    break;
            }
            return success;
        }

       /// <summary>
        /// bulk update method for list of Notification objects
       /// </summary>
       /// <param name="notificationList"></param>
       /// <returns></returns>
        public bool Update(NotificationList notificationList)
        {
            bool success = false;

            foreach (Notification template in notificationList)
            {
                //for each Notification in list, calls single update method 
                success = Update(template);
                if (!success)
                    return success;
            }

            return success;
        }

        /// <summary>
        /// bulk update method for notification fields
        /// </summary>
        /// <param name="notificationFields"></param>
        /// <returns></returns>
        public bool Update(NotificationFieldList notificationFields)
        {
            bool success = false;

            foreach (NotificationField obj in notificationFields)
            {
                //for each NotificationField, call update method for single NotificationField
                success = UpdateBase(obj);
                if (!success)
                    return success;
            }

            return success;
        }

        /// <summary>
        /// bulk update method for notification field
        /// </summary>
        /// <param name="notificationFieldList"></param>
        /// <returns></returns>
        public bool Update(NotificationFieldList notificationFieldList, long parentID)
        {            

            foreach (NotificationField obj in notificationFieldList)
            {
                obj.NotificationID = parentID;                
            }

            return Update(notificationFieldList);
        }

        /// <summary>
        /// update method for notification field
        /// </summary>
        /// <param name="notificationField"></param>
        /// <returns></returns>
        public bool Update(NotificationField notificationField)
        {
            return UpdateBase(notificationField);
        }

       /// <summary>
       /// bulk update method for ItemTemplate
       /// </summary>
       /// <param name="itemTemplates"></param>
       /// <returns></returns>
        public bool Update(ItemTemplateList itemTemplates)
        {
            bool success = false;

            foreach (ItemTemplate obj in itemTemplates)
            {
                //for each item teplate in given list, call update method for single ItemTemplate
                success = UpdateBase(obj);
                if (!success)
                    return success;
            }

            return success;
        }

        /// <summary>
        /// update method for single ItemTemplate
        /// </summary>
        /// <param name="notificationTemplate"></param>
        /// <returns></returns>
        public bool Update(ItemTemplate itemTemplate)
        {
            return UpdateBase(itemTemplate);
        }

        /// <summary>
        /// update method for ItemTemplate only, no child entities [if exists, or added later] will be considered
        /// </summary>
        /// <param name="itemTemplate"></param>
        /// <returns></returns>
        private bool UpdateBase(ItemTemplate itemTemplate)
        {
            if (itemTemplate.RowState != BaseBusinessEntity.RowStateEnum.DeletedRow)
            {
                ItemTemplate tempItemTemplate;
                using (ItemTemplateData itemTemplateData= new ItemTemplateData(UserContext))
                {
                    tempItemTemplate = itemTemplateData.GetItemTemplateByItemTemplateName(itemTemplate.Name);
                }

                if (tempItemTemplate != null && tempItemTemplate.ID != itemTemplate.ID)
                {
                    // handling of unique constraint violoation
                    string errorInfo = TSR.Framework.Resource.ResourceManager.GetResourceString("DUPLICATE_MESSAGE_KEY", "Object with same name already exists.");
                    throw new TSR.Framework.Exceptions.UniqueConstraintException(itemTemplate, new Exception(errorInfo));
                }
            }
            ItemTemplateData data = new ItemTemplateData(Transaction, UserContext);

            switch (itemTemplate.RowState)
            {   // Item template insert
                case BaseBusinessEntity.RowStateEnum.NewRow:
                    long id = data.Insert(itemTemplate);
                    if (id > 0)
                    {
                        itemTemplate.ID = id;
                        return true;
                    }
                    break;
                // Item template delete (logical delete)
                case BaseBusinessEntity.RowStateEnum.DeletedRow:
                    return data.Delete(itemTemplate.ID) > 0;
                // Item template update / data change
                case BaseBusinessEntity.RowStateEnum.UpdatedRow:
                    return data.Update(itemTemplate) > 0;
                case BaseBusinessEntity.RowStateEnum.NormalRow:
                    return true;
            }

            return false;
        }
        //Created by tsrdev1
        //Created date: 25/06/2010
        /// <summary>
        /// Delete method for ItemTemplate 
        /// </summary>
        /// <param name="name"></param>
        /// <returns>bool</returns>
        public bool DeleteItemTemplateByName(string name)
        {
            ItemTemplateData templateData = new ItemTemplateData(Transaction, UserContext);
            return templateData.Delete(name) > 0;            
        }
       
        //Created by tsrdev1
        //Created date: 25/06/2010
        /// <summary>
        /// Delete method for TemplateMappingTable 
        /// </summary>
        /// <param name="templateName"></param>
        /// <returns>bool</returns>
        public bool DeleteTemplateMappingTableByTemplateName(string templateName)
        {
            TemplateMappingTableData mappingData = new TemplateMappingTableData(Transaction, UserContext);
            return mappingData.Delete(templateName) > 0;
        }
       
        /// <summary>
        /// retrieves ItemTemplate depending on ID
        /// </summary>
        /// <param name="ID">ID of ItemTemplate</param>
        /// <returns></returns>
        public ItemTemplate GetItemTemplateByID(long ID)
        {
            using (ItemTemplateData data = new ItemTemplateData(UserContext))
            {
                return data.Get(ID);
            }
        }
        //Created by tsrdev1
        /// <summary>
        /// retrieves ItemTemplate depending on ID with filling childs
        /// </summary>
        /// <param name="ID">ID of ItemTemplate</param>
        /// <param name="fillChilds"></param>
        /// <returns>ItemTemplate</returns>
        public ItemTemplate GetItemTemplateByID(long ID,bool fillChilds)
        {
            ItemTemplate itemTemplate = null;
            using (ItemTemplateData data = new ItemTemplateData(UserContext))
            {
                itemTemplate = data.Get(ID);
            }
            if (itemTemplate != null && fillChilds)
            {
                using (TemplateMappingTableData mappingData = new TemplateMappingTableData(UserContext))
                {
                    itemTemplate.MappingTable = mappingData.GetAllByTemplateName(itemTemplate.Name);
                }
            }
            return itemTemplate;

        }
        //Created by tsrdev1
        /// <summary>
        /// retrieves ItemTemplate depending on name
        /// </summary>
        /// <param name="ID">name of ItemTemplate</param>
        /// <returns>ItemTemplate</returns>
        public ItemTemplate GetItemTemplateByName(string name)
        {
            ItemTemplate itemTemplate = null;
            using (ItemTemplateData data = new ItemTemplateData(UserContext))
            {                
                itemTemplate = data.GetItemTemplateByItemTemplateName(name);
            }
            return itemTemplate;
        }

        //Created by tsrdev1
        /// <summary>
        /// retrieves ItemTemplate depending on name with filling childs
        /// </summary>
        /// <param name="ID">name of ItemTemplate</param>
        /// <param name="fillChilds"></param>
        /// <returns>ItemTemplate</returns>
        public ItemTemplate GetItemTemplateByName(string name, bool fillChilds)
        {
            ItemTemplate itemTemplate = GetItemTemplateByName(name);

            if (itemTemplate != null && fillChilds)
            {
                using (TemplateMappingTableData mappingData = new TemplateMappingTableData(UserContext))
                {
                    itemTemplate.MappingTable = mappingData.GetAllByTemplateName(itemTemplate.Name);
                }
            }
            return itemTemplate;
        }

        /// <summary>
        /// retrieves all ItemTemplates
        /// </summary>
        /// <returns></returns>
        public ItemTemplateList GetAllItemTemplate()
        {
            using (ItemTemplateData data = new ItemTemplateData(UserContext))
            {
                return data.GetAll();
            }
        }

    }
}
