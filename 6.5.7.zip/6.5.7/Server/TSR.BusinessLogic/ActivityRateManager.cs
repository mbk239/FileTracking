﻿using System;
using TSR.DataAccess;
using TSR.Entities;
using TSR.Entities.Lists;
using TSR.Framework;

namespace TSR.BusinessLogic
{
    public class ActivityRateManager : BaseManager
    {
        public ActivityRateManager(UserContext context) : base(context)
        {
        }
        public ActivityRateList GetAllActivityRateByProjectID(long projectID)
        {
            var projectRateList = new ActivityRateList();
            using (ActivityRateData data = new ActivityRateData(UserContext))
            {
                projectRateList = data.GetAllActivityRateByProjectID(projectID);
            }
            return projectRateList;
        }
        private bool Insert(ActivityRate activityRateObject)
        {
            // new activity
            using (ActivityRateData data = new ActivityRateData(UserContext))
            {
                // insert to activityObject
                long id = data.Insert(activityRateObject);
                // if successful, process
                if (id > 0)
                {
                    activityRateObject.ID = id;
                    return true;
                }
                else
                    return false;
            }
        }
        //private bool Update(ActivityRate rateObject)
        //{

        //    using (ActivityRateData data = new ActivityRateData(UserContext))
        //    {
        //        return (data.Update(rateObject) > 0);
        //    }
        //}
        public bool AddOrUpdate(ActivityRate activityRateObject)
        {
            using (ActivityRateData data = new ActivityRateData(UserContext))
            {
                return (data.AddOrUpdate(activityRateObject) > 0);
            }
        }

        public bool Delete(long ID)
        {
            using (ActivityRateData data = new ActivityRateData(UserContext))
            {
                return (data.Delete(ID) > 0);
            }
        }
    }
}
